"""
分形图量子系统 —— 纯粹探索玩具（内存安全版）
从 Sierpinski 分形关系图生成量子多体系统，无预设目标诊断。
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import networkx as nx

# =============================================
# 公理一：关系本体论 —— 分形图生成 & 编译为哈密顿量（稀疏版）
# =============================================
def sierpinski_graph(level):
    """生成 Sierpinski 三角形分形图 (节点数: 3, 6, 15, 42...)"""
    G = nx.Graph()
    def add_triangle(a, b, c):
        G.add_edge(a, b, weight=1.0)
        G.add_edge(b, c, weight=1.0)
        G.add_edge(c, a, weight=1.0)

    def sierpinski_rec(v1, v2, v3, depth):
        if depth == 0:
            add_triangle(v1, v2, v3)
        else:
            m12 = max(G.nodes) + 1 if G.nodes else 0
            G.add_node(m12)
            m23 = m12 + 1
            G.add_node(m23)
            m31 = m23 + 1
            G.add_node(m31)
            sierpinski_rec(v1, m12, m31, depth-1)
            sierpinski_rec(v2, m23, m12, depth-1)
            sierpinski_rec(v3, m31, m23, depth-1)

    G.add_nodes_from([0, 1, 2])
    sierpinski_rec(0, 1, 2, level)
    return G

def graph_to_hamiltonian_sparse(G):
    """
    关系图编译为量子哈密顿量 (每条边 → XX+YY+ZZ)
    内存安全版本：直接构建稀疏矩阵，不生成密集中间数组
    """
    N = G.number_of_nodes()
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)

    # 预计算每个格点的单粒子算符在希尔伯特空间中的非零元
    # 我们直接在稀疏矩阵上操作，而不是用kron构建密集矩阵
    for i, j, w in G.edges(data='weight'):
        w = w if w else 1.0
        # 对于自旋-1/2系统，XX+YY+ZZ 算符只在少数几个态之间耦合
        # 我们遍历计算基矢，找到耦合态并直接设置矩阵元
        # 这种方法虽然 O(2^N) 次循环，但每次只处理稀疏的非零元
        for state in range(dim):
            # 提取i和j的位
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            # XX + YY 项：翻转两个自旋
            flipped_state = state ^ (1 << i) ^ (1 << j)
            H[state, flipped_state] += w  # XX+YY 贡献 1.0 (自旋翻转)
            # ZZ 项：对角贡献
            if bit_i == bit_j:
                H[state, state] += w  # 平行自旋贡献 +1
            else:
                H[state, state] -= w  # 反平行自旋贡献 -1
    return H.tocsc()

# =============================================
# 公理二：矛盾动力论 —— 植入矛盾边
# =============================================
def introduce_contradiction(G, edge, strength):
    G_mod = G.copy()
    if G_mod.has_edge(*edge):
        G_mod[edge[0]][edge[1]]['weight'] = strength
    else:
        G_mod.add_edge(edge[0], edge[1], weight=strength)
    return G_mod

# =============================================
# 公理三：实践介入论 —— 粗粒化与精细诊断
# =============================================
def diagnose(G, num_eig=5):
    H = graph_to_hamiltonian_sparse(G)
    N = G.number_of_nodes()
    energies, states = eigsh(H, k=min(num_eig, 2**N-1), which='SA')
    gap = energies[1] - energies[0] if len(energies) > 1 else np.nan
    return energies, gap, states[:, 0]

def coarse_diagnosis(N, gs):
    """粗粒化诊断：平均磁化强度（内存安全版）"""
    # 直接从波函数计算，不构建大矩阵
    mag = 0.0
    for state, amplitude in enumerate(gs):
        prob = np.abs(amplitude)**2
        # 计算该状态的磁化
        for i in range(N):
            bit = (state >> i) & 1
            mag += prob * (1 - 2*bit)  # up=+1, down=-1
    return abs(mag / (N * len(gs)))  # 归一化

def fine_diagnosis(G, gs):
    """精细诊断：边关联涨落（标准差）"""
    N = G.number_of_nodes()
    corrs = []
    for i, j in G.edges():
        # 计算 <σ^z_i σ^z_j>
        corr = 0.0
        for state, amplitude in enumerate(gs):
            prob = np.abs(amplitude)**2
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            val_i = 1 - 2*bit_i
            val_j = 1 - 2*bit_j
            corr += prob * val_i * val_j
        corrs.append(corr)
    return np.std(corrs) if corrs else 0.0

# =============================================
# 公理四 & 五：谐振调谐 + 元反思审计 + 探索入口
# =============================================
def explore(level=2, contradiction_edge=None, strengths=None):
    """纯粹探索：扫描矛盾强度，观察分形量子系统的响应"""
    print(f"=== 分形图量子系统探索 (Sierpinski level {level}) ===")
    G = sierpinski_graph(level)
    N = G.number_of_nodes()
    print(f"节点数: {N}, 边数: {G.number_of_edges()}")
    print(f"希尔伯特空间维度: {2**N}")

    if contradiction_edge is None:
        contradiction_edge = (0, 2) if G.has_edge(0,2) else (0,1)
    if strengths is None:
        strengths = np.linspace(0.0, 3.0, 13)

    gaps, coarse_vals, fine_vals = [], [], []
    audit_gaps = []

    print("矛盾强度扫描 (无预设目标)...")
    for s in strengths:
        G_mod = introduce_contradiction(G, contradiction_edge, s)
        _, gap, gs = diagnose(G_mod, num_eig=5)
        coarse = coarse_diagnosis(N, gs)
        fine = fine_diagnosis(G_mod, gs)

        gaps.append(gap)
        coarse_vals.append(coarse)
        fine_vals.append(fine)

        # 元反思审计：用不同本征值数量再次诊断
        _, gap2, _ = diagnose(G_mod, num_eig=6)
        audit_gaps.append(abs(gap - gap2))

        print(f"  s={s:.2f}: gap={gap:.4f}, coarse={coarse:.4f}, fine={fine:.4f}, audit_diff={audit_gaps[-1]:.6f}")

    # 保存探索数据
    np.savetxt('sierpinski_explore.csv',
               np.column_stack((strengths, gaps, coarse_vals, fine_vals, audit_gaps)),
               header='strength,gap,coarse,fine,audit_gap_diff', delimiter=',')

    # 绘制诊断图（并排展示不同介入视角）
    fig, ax1 = plt.subplots(figsize=(10,6))
    ax1.plot(strengths, coarse_vals, 'o-', color='#1f77b4', label='Coarse Diagnosis')
    ax2 = ax1.twinx()
    ax2.plot(strengths, fine_vals, 's-', color='#d62728', label='Fine Diagnosis')
    ax1.set_xlabel('Contradiction Strength'); ax1.set_ylabel('Coarse Metric')
    ax2.set_ylabel('Fine Metric'); ax1.legend(loc='upper left'); ax2.legend(loc='upper right')
    plt.title(f'Fractal Quantum Exploration (Sierpinski Lv.{level}, N={N})')
    plt.tight_layout()
    plt.savefig('sierpinski_explore.png', dpi=150)
    print("探索数据已保存至 sierpinski_explore.csv 和 sierpinski_explore.png")

if __name__ == "__main__":
    explore(level=2)