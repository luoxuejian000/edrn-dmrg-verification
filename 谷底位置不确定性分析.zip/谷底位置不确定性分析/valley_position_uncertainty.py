"""
谷底位置不确定性分析 —— 金箍棒 3.0 ED
多次重复扫描，收集每次扫描的谷底位置
用重复数据构建位置分布和置信区间
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# =============================================
# 哈密顿量构建（泡利矩阵版，标准Heisenberg）
# =============================================
def build_hamiltonian_pauli(N, edges, contradiction_edge, contradiction_strength):
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)

    def to_full(op, site):
        ops = [I2] * N
        ops[site] = op
        result = ops[0]
        for k in range(1, N):
            result = np.kron(result, ops[k])
        return result

    for (i, j, w) in edges:
        if (i, j) == contradiction_edge or (j, i) == contradiction_edge:
            w = contradiction_strength
        H += w * (to_full(sx, i) @ to_full(sx, j)).real
        H += w * (to_full(sy, i) @ to_full(sy, j)).real
        H += w * (to_full(sz, i) @ to_full(sz, j)).real
    return H.tocsc()


def fine_diagnosis(N, edges, gs):
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    corrs = []
    for (i, j, w) in edges:
        ops = [I2] * N
        ops[i] = sz
        ops[j] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        corr = np.real(gs.conj().T @ op_full @ gs)
        corrs.append(corr)
    return np.std(corrs) if corrs else 0.0


def path_edges(N):
    return [(i, i+1, 1.0) for i in range(N-1)]

def binary_tree_edges(N):
    edges = []
    for i in range(N):
        left = 2*i + 1
        right = 2*i + 2
        if left < N:
            edges.append((i, left, 1.0))
        if right < N:
            edges.append((i, right, 1.0))
    return edges

def random_tree_edges(N, seed):
    np.random.seed(seed)
    edges = []
    for i in range(1, N):
        parent = np.random.randint(0, i)
        edges.append((parent, i, 1.0))
    return edges


def find_valley_position(N, edges, contradiction_edge, s_grid, num_points=151):
    """在给定s网格上扫描，返回谷底位置（最小精细诊断值对应的s）"""
    fine_vals = []
    for s in s_grid:
        H = build_hamiltonian_pauli(N, edges, contradiction_edge, s)
        energies, states = eigsh(H, k=3, which='SA')
        gs = states[:, 0]
        fine = fine_diagnosis(N, edges, gs)
        fine_vals.append(fine)
    fine_vals = np.array(fine_vals)
    # 找到最小值位置，排除端点
    interior = (np.argmin(fine_vals) > 0) and (np.argmin(fine_vals) < num_points-1)
    if not interior:
        return None, fine_vals
    return s_grid[np.argmin(fine_vals)], fine_vals


def analyze_position_uncertainty(N, edges, contradiction_edge, num_repeats=20, num_points=151):
    """多次重复扫描，收集谷底位置分布"""
    s_grid = np.linspace(0.0, 3.0, num_points)
    positions = []
    for repeat in range(num_repeats):
        np.random.seed(repeat * 42)
        pos, _ = find_valley_position(N, edges, contradiction_edge, s_grid, num_points)
        if pos is not None:
            positions.append(pos)
    positions = np.array(positions)
    return positions, s_grid


if __name__ == "__main__":
    print("=== 谷底位置不确定性分析 ===\n")
    
    # 路径图 N=7
    N = 7
    path_edges_list = path_edges(N)
    path_contrad = (N//2 - 1, N//2)
    print(f"路径图 N={N}，矛盾边={path_contrad}")
    path_pos, s_grid = analyze_position_uncertainty(N, path_edges_list, path_contrad, num_repeats=20)
    if len(path_pos) > 0:
        print(f"  谷底位置重复数: {len(path_pos)}")
        print(f"  位置中位数: {np.median(path_pos):.4f}")
        print(f"  位置标准差: {np.std(path_pos):.4f}")
        print(f"  位置四分位区间: [{np.percentile(path_pos, 25):.4f}, {np.percentile(path_pos, 75):.4f}]")
    else:
        print("  未找到内部谷底")
    
    # 二叉树 N=7
    bt_edges_list = binary_tree_edges(N)
    bt_contrad = (0, 1)
    print(f"\n二叉树 N={N}，矛盾边={bt_contrad}")
    bt_pos, _ = analyze_position_uncertainty(N, bt_edges_list, bt_contrad, num_repeats=20)
    if len(bt_pos) > 0:
        print(f"  谷底位置重复数: {len(bt_pos)}")
        print(f"  位置中位数: {np.median(bt_pos):.4f}")
        print(f"  位置标准差: {np.std(bt_pos):.4f}")
        print(f"  位置四分位区间: [{np.percentile(bt_pos, 25):.4f}, {np.percentile(bt_pos, 75):.4f}]")
    else:
        print("  未找到内部谷底")
    
    # 随机树 N=7（三种不同实例）
    for rt_seed in [42, 43, 44]:
        rt_edges_list = random_tree_edges(N, rt_seed)
        rt_contrad = (0, 1)
        print(f"\n随机树 N={N}（种子={rt_seed}），矛盾边={rt_contrad}")
        rt_pos, _ = analyze_position_uncertainty(N, rt_edges_list, rt_contrad, num_repeats=20)
        if len(rt_pos) > 0:
            print(f"  谷底位置重复数: {len(rt_pos)}")
            print(f"  位置中位数: {np.median(rt_pos):.4f}")
            print(f"  位置标准差: {np.std(rt_pos):.4f}")
            print(f"  位置四分位区间: [{np.percentile(rt_pos, 25):.4f}, {np.percentile(rt_pos, 75):.4f}]")
        else:
            print("  未找到内部谷底")
    
    # 保存关键统计
    results = {
        'path_position_median': np.median(path_pos) if len(path_pos)>0 else np.nan,
        'path_position_std': np.std(path_pos) if len(path_pos)>0 else np.nan,
        'binary_tree_position_median': np.median(bt_pos) if len(bt_pos)>0 else np.nan,
        'binary_tree_position_std': np.std(bt_pos) if len(bt_pos)>0 else np.nan,
    }
    np.savez('valley_position_uncertainty.npz', **results)
    print("\n统计结果已保存到 valley_position_uncertainty.npz")