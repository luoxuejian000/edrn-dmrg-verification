"""
黄金分割探针 —— 精确对角化版本
φ = 0.618，不是数，是关系比值
检验：矛盾边强度调谐到φ时，关系场是否有特殊响应？
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh

# =============================================
# 哈密顿量构建（泡利矩阵版，标准Heisenberg）
# =============================================
def build_hamiltonian(N, contradiction_edge, contradiction_strength):
    """使用泡利矩阵构建标准各向同性Heisenberg模型"""
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)

    def to_full(op, site):
        ops = [I2] * N
        ops[site] = op
        result = ops[0]
        for k in range(1, N):
            result = np.kron(result, ops[k])
        return result

    for i in range(N-1):
        J = contradiction_strength if (i, i+1) == contradiction_edge or (i+1, i) == contradiction_edge else 1.0
        H += J * (to_full(sx, i) @ to_full(sx, i+1)).real
        H += J * (to_full(sy, i) @ to_full(sy, i+1)).real
        H += J * (to_full(sz, i) @ to_full(sz, i+1)).real

    return H.tocsc()


def compute_diagnostics(N, contradiction_edge, s, num_eig=5):
    """用ED精确计算基态，返回能隙、默认诊断和精细诊断"""
    H = build_hamiltonian(N, contradiction_edge, s)
    energies, states = eigsh(H, k=min(num_eig, 2**N-1), which='SA')
    gap = energies[1] - energies[0] if len(energies) > 1 else np.nan
    gs = states[:, 0]

    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    mag = 0.0
    for i in range(N):
        ops = [I2] * N
        ops[i] = sz
        op_full = ops[0]
        for k in range(1, N): op_full = np.kron(op_full, ops[k])
        mag += np.real(gs.conj().T @ op_full @ gs)
    coarse = abs(mag / N)

    corrs = []
    for i in range(N-1):
        ops = [I2] * N
        ops[i] = sz; ops[i+1] = sz
        op_full = ops[0]
        for k in range(1, N): op_full = np.kron(op_full, ops[k])
        corr = np.real(gs.conj().T @ op_full @ gs)
        corrs.append(corr)
    fine = np.std(corrs) if corrs else 0.0

    return gap, coarse, fine


def scan_s_values(N, contradiction_edge, s_values, label):
    """扫描指定s值列表，返回诊断数据"""
    gaps, coarse_vals, fine_vals = [], [], []
    print(f"\n=== {label} ===")
    for s in s_values:
        gap, coarse, fine = compute_diagnostics(N, contradiction_edge, s)
        gaps.append(gap); coarse_vals.append(coarse); fine_vals.append(fine)
        print(f"s={s:.4f}: gap={gap:.6f}, coarse={coarse:.4f}, fine={fine:.6f}")
    return np.array(s_values), np.array(gaps), np.array(coarse_vals), np.array(fine_vals)

if __name__ == "__main__":
    N = 6
    contradiction_edge = (N//2 - 1, N//2)  # (2,3)
    phi = (1 + np.sqrt(5)) / 2 - 1  # φ ≈ 0.618034

    # === 均匀基准扫描：s从0到3，13个点 ===
    s_uniform = np.linspace(0.0, 3.0, 13)
    s_u, gaps_u, coarse_u, fine_u = scan_s_values(N, contradiction_edge, s_uniform, "均匀基准扫描")

    # === φ加密探针：在φ附近加密，同时覆盖两端 ===
    # 构造一个非均匀网格：0到φ-0.3均匀稀疏，φ附近加密，φ+0.3到3.0均匀稀疏
    s_before = np.linspace(0.0, phi - 0.2, 5)
    s_phi_dense = np.linspace(phi - 0.2, phi + 0.2, 9)  # φ附近加密
    s_after = np.linspace(phi + 0.2, 3.0, 5)
    s_probe = np.unique(np.concatenate([s_before, s_phi_dense, s_after]))
    
    s_p, gaps_p, coarse_p, fine_p = scan_s_values(N, contradiction_edge, s_probe, "φ加密探针扫描")
    
    # === 数据保存 ===
    np.savetxt('golden_uniform.csv', 
               np.column_stack((s_u, gaps_u, coarse_u, fine_u)), 
               header='s,gap,coarse,fine', delimiter=',')
    np.savetxt('golden_probe.csv', 
               np.column_stack((s_p, gaps_p, coarse_p, fine_p)), 
               header='s,gap,coarse,fine', delimiter=',')
    
    # === 对比图 ===
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
    
    ax1.plot(s_u, fine_u, 'o-', label='Uniform scan', color='#1f77b4', lw=2, ms=6)
    ax1.plot(s_p, fine_p, 's-', label='φ-probe scan', color='#d62728', lw=1.5, ms=4)
    ax1.axvline(phi, color='gold', ls='--', lw=2, label=f'φ={phi:.4f}')
    ax1.set_xlabel('Contradiction strength s'); ax1.set_ylabel('Fine diagnosis')
    ax1.set_title('Golden Ratio Probe: Enhanced Diagnosis')
    ax1.legend(fontsize=8); ax1.grid(True, alpha=0.3)
    
    ax2.plot(s_u, coarse_u, 'o-', label='Uniform scan', color='#1f77b4', lw=2, ms=6)
    ax2.plot(s_p, coarse_p, 's-', label='φ-probe scan', color='#d62728', lw=1.5, ms=4)
    ax2.axvline(phi, color='gold', ls='--', lw=2, label=f'φ={phi:.4f}')
    ax2.set_xlabel('Contradiction strength s'); ax2.set_ylabel('Coarse diagnosis')
    ax2.set_title('Golden Ratio Probe: Default Diagnosis')
    ax2.legend(fontsize=8); ax2.grid(True, alpha=0.3)
    
    plt.suptitle('Golden Ratio Probe (N=6, Heisenberg, ED)')
    plt.tight_layout()
    plt.savefig('golden_ratio_probe.png', dpi=150)
    print("\nDone. Data saved to golden_uniform.csv / golden_probe.csv")