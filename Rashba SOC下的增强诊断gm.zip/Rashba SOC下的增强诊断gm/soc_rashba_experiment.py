"""
Rashba SOC 下的沉默失谐诊断器（独立实验脚本）
新规则：每条边贡献 Heisenberg + DM (Rashba型)
DM向量沿 y 轴：D * (σ_i^z σ_j^x - σ_i^x σ_j^z)
"""
import numpy as np
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import networkx as nx

def build_graph(graph_type, N):
    if graph_type == 'chain':
        G = nx.Graph()
        G.add_nodes_from(range(N))
        for i in range(N-1):
            G.add_edge(i, i+1, weight=1.0)
        return G
    raise ValueError(f"Unknown graph type: {graph_type}")

def graph_to_hamiltonian_sparse(G, J=1.0, D=0.3):
    N = G.number_of_nodes()
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    
    for i, j, w in G.edges(data='weight'):
        w = w if w else 1.0
        for state in range(dim):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            
            # Heisenberg 项 (XX+YY+ZZ)
            flipped = state ^ (1 << i) ^ (1 << j)
            H[state, flipped] += J * w
            
            if bit_i == bit_j:
                H[state, state] += J * w
            else:
                H[state, state] -= J * w
                
            # Rashba DM 项 (D沿y轴): D * (σ_i^z σ_j^x - σ_i^x σ_j^z)
            flipped_j = state ^ (1 << j)
            sign_i = 1.0 if bit_i == 0 else -1.0
            H[state, flipped_j] += D * w * sign_i
            
            flipped_i = state ^ (1 << i)
            sign_j = 1.0 if bit_j == 0 else -1.0
            H[state, flipped_i] -= D * w * sign_j

    return H.tocsc()

def introduce_contradiction(G, edge, strength):
    G_mod = G.copy()
    if G_mod.has_edge(*edge):
        G_mod[edge[0]][edge[1]]['weight'] = strength
    else:
        G_mod.add_edge(edge[0], edge[1], weight=strength)
    return G_mod

def diagnose(G, J=1.0, D=0.3, num_eig=5):
    H = graph_to_hamiltonian_sparse(G, J=J, D=D)
    N = G.number_of_nodes()
    energies, states = eigsh(H, k=min(num_eig, 2**N-1), which='SA')
    gap = energies[1] - energies[0] if len(energies) > 1 else np.nan
    return energies, gap, states[:, 0]

def coarse_diagnosis(N, gs):
    mag = 0.0
    dim = len(gs)
    for state in range(dim):
        prob = np.abs(gs[state])**2
        bits = [(state >> k) & 1 for k in range(N)]
        mag += prob * sum(1 - 2*b for b in bits)
    return abs(mag / N)

def fine_diagnosis(G, gs):
    N = G.number_of_nodes()
    dim = len(gs)
    corrs = []
    for i, j in G.edges():
        corr = 0.0
        for state in range(dim):
            prob = np.abs(gs[state])**2
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            corr += prob * (1 - 2*bit_i) * (1 - 2*bit_j)
        corrs.append(corr)
    return np.std(corrs) if corrs else 0.0

def run_comparison():
    graph_type = 'chain'
    N = 6
    J = 1.0
    D_values = [0.0, 0.3]  # 0.0 = 纯Heisenberg基线, 0.3 = Rashba SOC
    contradiction_edge = (0, 1)
    strengths = np.linspace(0.0, 3.0, 9)
    
    plt.figure(figsize=(12, 5))
    
    for idx, D in enumerate(D_values):
        print(f"\n=== D={D} {'(纯Heisenberg)' if D==0 else '(Rashba SOC)'} ===")
        G_base = build_graph(graph_type, N)
        
        coarse_vals, fine_vals = [], []
        for s in strengths:
            G = introduce_contradiction(G_base, contradiction_edge, s)
            _, _, gs = diagnose(G, J=J, D=D, num_eig=5)
            coarse = coarse_diagnosis(N, gs)
            fine = fine_diagnosis(G, gs)
            coarse_vals.append(coarse)
            fine_vals.append(fine)
            print(f"  s={s:.2f}: coarse={coarse:.4f}, fine={fine:.4f}")
        
        color = '#d62728' if D == 0 else '#1f77b4'
        label = 'Heisenberg (D=0)' if D == 0 else f'Rashba SOC (D={D})'
        plt.plot(strengths, fine_vals, 'o-', color=color, label=label, linewidth=2, markersize=6)
    
    plt.xlabel('Contradiction strength s')
    plt.ylabel('Enhanced Diagnosis (fine)')
    plt.title('Silent Discordance under Rashba SOC')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('soc_rashba_comparison.png', dpi=150)
    print("\n对比图已保存至 soc_rashba_comparison.png")

if __name__ == "__main__":
    run_comparison()