"""
独立周期驱动量子时钟实验
不依赖金箍棒，直接测试关系场的记忆效应（滞后回线）
"""
import numpy as np
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh
import matplotlib.pyplot as plt
import networkx as nx

def build_graph(graph_type, N):
    if graph_type == 'chain':
        G = nx.Graph()
        G.add_nodes_from(range(N))
        for i in range(N-1):
            G.add_edge(i, i+1, weight=1.0)
        return G
    raise ValueError(f"Unknown graph type: {graph_type}")

def graph_to_hamiltonian_sparse(G, rule='heisenberg'):
    N = G.number_of_nodes()
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    for i, j, w in G.edges(data='weight'):
        w = w if w else 1.0
        for state in range(dim):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            flipped = state ^ (1 << i) ^ (1 << j)
            if rule in ['heisenberg', 'xy', 'xxz']:
                H[state, flipped] += w
            if rule in ['heisenberg', 'ising', 'xxz']:
                if bit_i == bit_j:
                    H[state, state] += w
                else:
                    H[state, state] -= w
    return H.tocsc()

def introduce_contradiction(G, edge, strength):
    G_mod = G.copy()
    if G_mod.has_edge(*edge):
        G_mod[edge[0]][edge[1]]['weight'] = strength
    else:
        G_mod.add_edge(edge[0], edge[1], weight=strength)
    return G_mod

def diagnose(G, rule='heisenberg', num_eig=5):
    H = graph_to_hamiltonian_sparse(G, rule=rule)
    N = G.number_of_nodes()
    energies, states = eigsh(H, k=min(num_eig, 2**N-1), which='SA')
    gap = energies[1] - energies[0] if len(energies) > 1 else np.nan
    return energies, gap, states[:, 0]

def coarse_diagnosis(N, gs):
    mag = 0.0
    dim = len(gs)
    for state in range(dim):
        prob = np.abs(gs[state])**2
        bits = [(state >> k) & 1 for k in range(N)]
        mag += prob * sum(1 - 2*b for b in bits)
    return abs(mag / N)

def fine_diagnosis(G, gs):
    N = G.number_of_nodes()
    dim = len(gs)
    corrs = []
    for i, j in G.edges():
        corr = 0.0
        for state in range(dim):
            prob = np.abs(gs[state])**2
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            corr += prob * (1 - 2*bit_i) * (1 - 2*bit_j)
        corrs.append(corr)
    return np.std(corrs) if corrs else 0.0

def run():
    graph_type = 'chain'
    N = 6
    rule = 'heisenberg'
    contradiction_edge = (0, 1)
    
    n_cycles = 3
    n_points_per_half = 10
    s_descending = np.linspace(1.0, 0.5, n_points_per_half, endpoint=False)
    s_ascending = np.linspace(0.5, 1.0, n_points_per_half, endpoint=True)
    s_one_cycle = np.concatenate([s_descending, s_ascending])
    s_vals = np.tile(s_one_cycle, n_cycles)
    
    print(f"周期驱动实验: {graph_type} N={N} {n_cycles}个周期, 共{len(s_vals)}个点")
    
    G_base = build_graph(graph_type, N)
    gaps, coarse_vals, fine_vals = [], [], []
    
    for idx, s in enumerate(s_vals):
        G = introduce_contradiction(G_base, contradiction_edge, s)
        _, gap, gs = diagnose(G, rule=rule, num_eig=5)
        coarse = coarse_diagnosis(N, gs)
        fine = fine_diagnosis(G, gs)
        gaps.append(gap)
        coarse_vals.append(coarse)
        fine_vals.append(fine)
        cycle_num = idx // len(s_one_cycle) + 1
        print(f"  周期{cycle_num} s={s:.3f}: gap={gap:.4f}, coarse={coarse:.4f}, fine={fine:.4f}")
    
    # 可视化
    fig, axes = plt.subplots(1, 2, figsize=(14, 5.5))
    
    ax = axes[0]
    ax.plot(s_vals, coarse_vals, 'o-', color='#1f77b4', markersize=3)
    ax.set_xlabel('Contradiction strength s')
    ax.set_ylabel('Default Diagnosis (coarse)')
    ax.set_title('Default Diagnosis: Blind to cycles')
    ax.grid(True, alpha=0.3)
    
    ax = axes[1]
    colors = ['#d62728', '#2ca02c', '#ff7f0e']
    for cycle in range(n_cycles):
        start = cycle * len(s_one_cycle)
        end = start + len(s_one_cycle)
        ax.plot(s_vals[start:end], fine_vals[start:end], 'o-', 
                color=colors[cycle], markersize=3, label=f'Cycle {cycle+1}')
    ax.set_xlabel('Contradiction strength s')
    ax.set_ylabel('Enhanced Diagnosis (fine)')
    ax.set_title('Enhanced Diagnosis: Memory traces?')
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    plt.suptitle(f'Quantum Clock Experiment: {graph_type} N={N} {n_cycles} cycles')
    plt.tight_layout()
    plt.savefig('quantum_clock.png', dpi=150)
    print("数据已保存至 quantum_clock.png")

if __name__ == "__main__":
    run()