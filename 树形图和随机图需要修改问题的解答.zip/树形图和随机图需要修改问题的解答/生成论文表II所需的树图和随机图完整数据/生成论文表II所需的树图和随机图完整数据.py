"""
生成论文表II所需的树图和随机图完整数据
严格遵循：关系本体论、严防工具理性悖论、反对对齐
- 图定义内嵌，种子固定，完全可复现
- 扫描范围 s∈[0,3]，与原表II一致
- 扫描所有边，记录每条边的谷位置和深度
- 选取最深谷进行多种子审计（3 seeds）
- 输出完整数据表 JSON / CSV，并绘制英文图
"""

import numpy as np
import networkx as nx
import itertools
import json
import os
import pandas as pd
import matplotlib.pyplot as plt
from scipy.sparse import lil_matrix, csr_matrix
from scipy.sparse.linalg import eigsh

# ========== 图定义（内嵌，保证可复现） ==========
def generate_tree_N15():
    """N=15 tree, 14 edges, seed=42"""
    tree = nx.random_tree(15, seed=42)
    tree = nx.relabel_nodes(tree, {old: new for new, old in enumerate(tree.nodes())})
    return tree

def generate_random_N15():
    """N=15 random graph, 27 edges, seed=42"""
    random_graph = nx.gnm_random_graph(15, 27, seed=42)
    random_graph = nx.relabel_nodes(random_graph, {old: new for new, old in enumerate(random_graph.nodes())})
    return random_graph

# ========== 哈密顿量构建（固定磁化扇区） ==========
def build_hamiltonian_sector(N, edges, J_vals, N_up):
    """Build Heisenberg Hamiltonian in fixed Sz sector."""
    basis_states = list(itertools.combinations(range(N), N_up))
    state_to_idx = {st: i for i, st in enumerate(basis_states)}
    dim = len(basis_states)
    H = lil_matrix((dim, dim), dtype=float)

    for (i, j), J in zip(edges, J_vals):
        # diagonal: sigma_z^i sigma_z^j
        for idx, state in enumerate(basis_states):
            si = 1 if i in state else -1
            sj = 1 if j in state else -1
            H[idx, idx] += J * si * sj

        # off-diagonal: 2*(sigma_i^+ sigma_j^- + sigma_i^- sigma_j^+)
        for idx, state in enumerate(basis_states):
            i_up = i in state
            j_up = j in state
            if i_up and not j_up:
                ns = list(state)
                ns.remove(i)
                ns.append(j)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2 * J
            elif j_up and not i_up:
                ns = list(state)
                ns.remove(j)
                ns.append(i)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2 * J

    return csr_matrix(H), basis_states

def compute_enhanced_diagnostic(N, edges, J_vals, N_up, seed=0):
    """Compute the enhanced diagnosis E(s) for given couplings."""
    H, basis = build_hamiltonian_sector(N, edges, J_vals, N_up)
    rng = np.random.default_rng(seed)
    v0 = rng.standard_normal(H.shape[0])
    evals, evecs = eigsh(H, k=1, which='SA', v0=v0)
    psi = evecs[:, 0]

    corrs = []
    for (i, j) in edges:
        sp = np.array([(1 if i in state else -1)*(1 if j in state else -1) for state in basis])
        corrs.append(np.sum(np.abs(psi)**2 * sp))
    return np.std(np.array(corrs))

# ========== 单条边扫描 ==========
def scan_edge(N, edges, edge_idx, s_values, N_up, seed=0):
    """Scan contradiction edge edge_idx over s_values, return E(s) curve."""
    J_vals = np.ones(len(edges))
    E_curve = []
    for s in s_values:
        J_vals[edge_idx] = s
        E = compute_enhanced_diagnostic(N, edges, J_vals, N_up, seed=seed)
        E_curve.append(E)
        J_vals[edge_idx] = 1.0
    return np.array(E_curve)

def detect_valley(s_values, E_values):
    """Return (s, depth, is_internal). Depth = E(s=0) - E(min)."""
    min_idx = np.argmin(E_values)
    if min_idx == 0 or min_idx == len(E_values) - 1:
        return None, None, False
    if E_values[min_idx] < E_values[min_idx-1] and E_values[min_idx] < E_values[min_idx+1]:
        depth = E_values[0] - E_values[min_idx]
        return s_values[min_idx], depth, True
    return None, None, False

# ========== 主扫描函数：扫描所有边，选出最深谷，多种子审计 ==========
def scan_graph_all_edges(G, graph_name, s_values, N_up, output_prefix):
    N = G.number_of_nodes()
    edges = list(G.edges())
    print(f"\n=== {graph_name}: N={N}, {len(edges)} edges, s∈[{s_values[0]}, {s_values[-1]}] ===")

    edge_records = []
    best_edge_idx = None
    best_valley_s = None
    best_depth = -1.0

    # 1. 单种子扫描所有边
    for edge_idx, edge in enumerate(edges):
        E_curve = scan_edge(N, edges, edge_idx, s_values, N_up, seed=0)
        s_val, depth, is_internal = detect_valley(s_values, E_curve)

        # 记录，不筛选
        record = {
            'edge': [int(u), int(v) for u, v in edge],
            'valley_s': float(s_val) if s_val is not None else None,
            'depth': float(depth) if depth is not None else None,
            'is_internal': bool(is_internal)
        }
        edge_records.append(record)

        s_str = f"{s_val:.4f}" if s_val is not None else "None"
        d_str = f"{depth:.6f}" if depth is not None else "None"
        print(f"  Edge {edge}: s={s_str}, depth={d_str}, internal={is_internal}")

        if is_internal and depth is not None and depth > best_depth:
            best_depth = depth
            best_valley_s = s_val
            best_edge_idx = edge_idx

    # 2. 多种子审计最深谷
    multi_results = None
    if best_edge_idx is not None:
        best_edge = edges[best_edge_idx]
        print(f"\n  Deepest valley: edge {best_edge}, s={best_valley_s:.4f}, depth={best_depth:.6f}")

        depths_multi = []
        positions_multi = []
        for seed in range(3):
            E_curve = scan_edge(N, edges, best_edge_idx, s_values, N_up, seed=seed)
            s_val, depth, is_internal = detect_valley(s_values, E_curve)
            if is_internal and depth is not None:
                depths_multi.append(depth)
                positions_multi.append(s_val)

        if depths_multi:
            mean_depth = np.mean(depths_multi)
            std_depth = np.std(depths_multi, ddof=1) if len(depths_multi) > 1 else 0.0
            mean_pos = np.mean(positions_multi) if positions_multi else None
            std_pos = np.std(positions_multi, ddof=1) if len(positions_multi) > 1 else 0.0
            multi_results = {
                'best_edge': [int(u), int(v) for u, v in best_edge],
                'valley_s_single': float(best_valley_s),
                'depth_single': float(best_depth),
                'depth_multi_mean': float(mean_depth),
                'depth_multi_std': float(std_depth),
                'pos_multi_mean': float(mean_pos) if mean_pos is not None else None,
                'pos_multi_std': float(std_pos),
                'n_valid_seeds': len(depths_multi)
            }
            print(f"  Multi-seed ({len(depths_multi)} valid): depth {mean_depth:.6f} ± {std_depth:.6f}")
            print(f"  Position: {mean_pos:.4f} ± {std_pos:.4f}")
        else:
            multi_results = {
                'best_edge': [int(u), int(v) for u, v in best_edge],
                'valley_s_single': float(best_valley_s),
                'depth_single': float(best_depth),
                'depth_multi_mean': None,
                'depth_multi_std': None,
                'pos_multi_mean': None,
                'pos_multi_std': None,
                'n_valid_seeds': 0
            }

    # 3. 保存完整结果
    output = {
        'graph': graph_name,
        'N': N,
        'n_edges': len(edges),
        's_min': float(s_values[0]),
        's_max': float(s_values[-1]),
        's_points': len(s_values),
        'N_up': N_up,
        'seed_scan': 0,
        'all_edge_records': edge_records,
        'best_edge_summary': multi_results
    }

    with open(f"{output_prefix}_full.json", 'w') as f:
        json.dump(output, f, indent=2)
    print(f"  Full JSON saved to {output_prefix}_full.json")

    # 4. 保存每边记录 CSV
    df_records = pd.DataFrame(edge_records)
    df_records.to_csv(f"{output_prefix}_all_edges.csv", index=False)
    print(f"  Edge CSV saved to {output_prefix}_all_edges.csv")

    return output

# ========== 绘图函数 ==========
def plot_edge_depths(G, graph_name, edge_records, output_png):
    """Draw bar plot of valley depths for all edges."""
    edges_list = [tuple(rec['edge']) for rec in edge_records]
    depths = [rec['depth'] if rec['depth'] is not None else 0.0 for rec in edge_records]
    labels = [f"({u},{v})" for u, v in edges_list]

    plt.figure(figsize=(12, 5))
    bars = plt.bar(range(len(depths)), depths, color='steelblue', edgecolor='black')
    plt.xticks(range(len(depths)), labels, rotation=90, fontsize=8)
    plt.ylabel('Valley depth (E(0) - E(min))')
    plt.xlabel('Edge')
    plt.title(f'{graph_name}: valley depth for each contradiction edge')
    plt.tight_layout()
    plt.savefig(output_png, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  Plot saved to {output_png}")

# ========== 主程序 ==========
if __name__ == "__main__":
    # 固定参数
    N = 15
    N_up = 7
    s_values = np.linspace(0.0, 3.0, 61)  # 原表II范围，61点
    outdir = "table2_full_data"
    os.makedirs(outdir, exist_ok=True)

    # 树图
    tree_G = generate_tree_N15()
    tree_result = scan_graph_all_edges(
        tree_G, "tree", s_values, N_up,
        os.path.join(outdir, "tree")
    )
    if tree_result['best_edge_summary']:
        plot_edge_depths(
            tree_G, "Tree (N=15)",
            tree_result['all_edge_records'],
            os.path.join(outdir, "tree_depths_en.png")
        )

    # 随机图
    random_G = generate_random_N15()
    random_result = scan_graph_all_edges(
        random_G, "random", s_values, N_up,
        os.path.join(outdir, "random")
    )
    if random_result['best_edge_summary']:
        plot_edge_depths(
            random_G, "Random graph (N=15)",
            random_result['all_edge_records'],
            os.path.join(outdir, "random_depths_en.png")
        )

    print("\n=== FINAL SUMMARY ===")
    if tree_result['best_edge_summary']:
        s = tree_result['best_edge_summary']
        print(f"Tree: best edge {s['best_edge']}, single depth {s['depth_single']:.4f}, "
              f"multi depth {s['depth_multi_mean']:.4f} ± {s['depth_multi_std']:.4f}")
    else:
        print("Tree: no internal valley found")
    if random_result['best_edge_summary']:
        s = random_result['best_edge_summary']
        print(f"Random: best edge {s['best_edge']}, single depth {s['depth_single']:.4f}, "
              f"multi depth {s['depth_multi_mean']:.4f} ± {s['depth_multi_std']:.4f}")
    else:
        print("Random: no internal valley found")