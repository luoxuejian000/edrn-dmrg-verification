import networkx as nx
import json

print("=" * 70)
print("生成 N=15 树图（14条边）和随机图（27条边）的全新定义")
print("用于论文表II，确保可复现性")
print("=" * 70)

# =============================================
# 1. 树图：15节点，14条边
# =============================================
tree = nx.random_tree(15, seed=42)
tree = nx.relabel_nodes(tree, {old: new for new, old in enumerate(tree.nodes())})
tree_edges = sorted(tuple(sorted(e)) for e in tree.edges())

print("\n【树图】N=15，14条边")
print("生成器: nx.random_tree(15, seed=42)")
print("边列表（无向，节点编号0-14）：")
print("edges_tree = [")
for i, (u, v) in enumerate(tree_edges):
    if i < len(tree_edges) - 1:
        print(f"    ({u},{v}),")
    else:
        print(f"    ({u},{v})")
print("]")

# =============================================
# 2. 随机图：15节点，27条边
# =============================================
random_graph = nx.gnm_random_graph(15, 27, seed=42)
random_graph = nx.relabel_nodes(random_graph, {old: new for new, old in enumerate(random_graph.nodes())})
random_edges = sorted(tuple(sorted(e)) for e in random_graph.edges())

print("\n" + "=" * 70)
print("【随机图】N=15，27条边")
print("生成器: nx.gnm_random_graph(15, 27, seed=42)")
print("边列表（无向，节点编号0-14）：")
print("edges_random = [")
for i, (u, v) in enumerate(random_edges):
    if i < len(random_edges) - 1:
        print(f"    ({u},{v}),")
    else:
        print(f"    ({u},{v})")
print("]")

# =============================================
# 3. 保存边列表到文件
# =============================================
output = {
    "tree_N15_edges": [[int(u), int(v)] for u, v in tree_edges],
    "random_N15_edges": [[int(u), int(v)] for u, v in random_edges],
    "tree_seed": 42,
    "random_seed": 42,
    "tree_generator": "nx.random_tree(15, seed=42)",
    "random_generator": "nx.gnm_random_graph(15, 27, seed=42)"
}

with open("graph_edge_lists.json", "w") as f:
    json.dump(output, f, indent=2)

print("\n边列表已保存至 graph_edge_lists.json")
print("=" * 70)