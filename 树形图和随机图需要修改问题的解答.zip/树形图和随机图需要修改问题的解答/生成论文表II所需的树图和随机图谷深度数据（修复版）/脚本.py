import numpy as np
import networkx as nx
import json
import itertools
from scipy.sparse import csr_matrix
from scipy.sparse.linalg import eigsh
import os

# 图定义
def generate_tree_N15():
    tree = nx.random_tree(15, seed=42)
    return nx.relabel_nodes(tree, {old: new for new, old in enumerate(tree.nodes())})

def generate_random_N15():
    random_graph = nx.gnm_random_graph(15, 27, seed=42)
    return nx.relabel_nodes(random_graph, {old: new for new, old in enumerate(random_graph.nodes())})

# 预计算固定磁化扇区中的每条边算符，避免每次扫描重复构造哈密顿量
def prepare_sector_operators(N, edges, N_up):
    basis_states = list(itertools.combinations(range(N), N_up))
    state_to_idx = {st: i for i, st in enumerate(basis_states)}
    dim = len(basis_states)
    up = np.zeros((dim, N), dtype=bool)
    for idx, state in enumerate(basis_states):
        up[idx, list(state)] = True

    edge_ops = []
    zz_diags = []
    for i, j in edges:
        zz = (2 * up[:, i].astype(np.int8) - 1) * (2 * up[:, j].astype(np.int8) - 1)
        rows = []
        cols = []
        vals = []
        for idx, state in enumerate(basis_states):
            i_up = i in state
            j_up = j in state
            if i_up and not j_up:
                ns = list(state)
                ns.remove(i)
                ns.append(j)
                rows.append(idx)
                cols.append(state_to_idx[tuple(sorted(ns))])
                vals.append(2.0)
            elif j_up and not i_up:
                ns = list(state)
                ns.remove(j)
                ns.append(i)
                rows.append(idx)
                cols.append(state_to_idx[tuple(sorted(ns))])
                vals.append(2.0)
        r = np.concatenate((np.arange(dim), np.asarray(rows, dtype=int)))
        c = np.concatenate((np.arange(dim), np.asarray(cols, dtype=int)))
        v = np.concatenate((zz.astype(float), np.asarray(vals, dtype=float)))
        edge_ops.append(csr_matrix((v, (r, c)), shape=(dim, dim)))
        zz_diags.append(zz.astype(float))

    H_base = sum(edge_ops[1:], edge_ops[0].copy()) if edge_ops else csr_matrix((dim, dim), dtype=float)
    return basis_states, edge_ops, zz_diags, H_base

def compute_enhanced_diagnostic(N, edges, J_vals, N_up, seed=0, prepared=None, v0=None):
    if prepared is None:
        prepared = prepare_sector_operators(N, edges, N_up)
    _, edge_ops, zz_diags, H_base = prepared
    H = H_base.copy()
    for J, op in zip(J_vals, edge_ops):
        if J != 1.0:
            H = H + (J - 1.0) * op
    rng = np.random.default_rng(seed)
    if v0 is None:
        v0 = rng.standard_normal(H.shape[0])
    _, evecs = eigsh(H, k=1, which='SA', v0=v0, tol=1e-9, maxiter=2000)
    psi = evecs[:, 0]
    prob = np.abs(psi) ** 2
    corrs = np.array([np.dot(prob, zz) for zz in zz_diags])
    return np.std(corrs), psi

def scan_edge(N, edges, edge_idx, s_values, N_up, seed=0, prepared=None):
    if prepared is None:
        prepared = prepare_sector_operators(N, edges, N_up)
    _, edge_ops, zz_diags, H_base = prepared
    rng = np.random.default_rng(seed)
    v0 = rng.standard_normal(H_base.shape[0])
    results = []
    for s in s_values:
        H = H_base + (float(s) - 1.0) * edge_ops[edge_idx]
        _, evecs = eigsh(H, k=1, which='SA', v0=v0, tol=1e-9, maxiter=2000)
        psi = evecs[:, 0]
        v0 = psi
        prob = np.abs(psi) ** 2
        corrs = np.array([np.dot(prob, zz) for zz in zz_diags])
        results.append(np.std(corrs))
    return np.array(results)

def detect_valley(s_values, E_values):
    min_idx = int(np.argmin(E_values))
    if min_idx == 0 or min_idx == len(E_values) - 1:
        return None, None, False
    if E_values[min_idx] < E_values[min_idx - 1] and E_values[min_idx] < E_values[min_idx + 1]:
        return float(s_values[min_idx]), float(E_values[0] - E_values[min_idx]), True
    return None, None, False

def scan_all_edges_and_select(G, gname, s_values, N_up, output_file):
    N = G.number_of_nodes()
    edges = list(G.edges())
    prepared = prepare_sector_operators(N, edges, N_up)
    print(f"\n=== {gname}: 扫描所有 {len(edges)} 条边 ===")

    best_edge = None
    best_valley = None
    best_depth = -1.0
    edge_results = []

    for edge_idx, edge in enumerate(edges):
        E_arr = scan_edge(N, edges, edge_idx, s_values, N_up, seed=0, prepared=prepared)
        s_val, depth, is_internal = detect_valley(s_values, E_arr)
        s_str = f"{s_val:.4f}" if s_val is not None else "None"
        d_str = f"{depth:.6f}" if depth is not None else "None"
        print(f"  边 {edge}: 谷位置={s_str}, 深度={d_str}, 内部={is_internal}")

        if is_internal and depth is not None and depth > best_depth:
            best_depth = depth
            best_valley = s_val
            best_edge = edge

        edge_results.append({
            'edge': [int(u) for u in edge],
            'valley_s': s_val,
            'depth': depth,
            'is_internal': bool(is_internal)
        })

    if best_edge is None:
        print(f"\n{gname} 未检测到内部谷。")
        return None

    print(f"\n最深谷: 边 {best_edge}, 位置 s={best_valley:.4f}, 深度 {best_depth:.6f}")
    edge_idx = edges.index(best_edge)
    depths_multi = []
    positions_multi = []
    for seed in range(3):
        E_arr = scan_edge(N, edges, edge_idx, s_values, N_up, seed=seed, prepared=prepared)
        s_val, depth, is_internal = detect_valley(s_values, E_arr)
        if is_internal and depth is not None:
            depths_multi.append(depth)
        if is_internal and s_val is not None:
            positions_multi.append(s_val)

    depths_multi = np.asarray(depths_multi, dtype=float)
    positions_multi = np.asarray(positions_multi, dtype=float)
    depth_std = float(depths_multi.std(ddof=1)) if len(depths_multi) > 1 else None
    position_std = float(positions_multi.std(ddof=1)) if len(positions_multi) > 1 else None

    if len(depths_multi) > 0:
        print(f"多种子审计（{len(depths_multi)}个有效种子）：")
        print(f"  深度: 均值 {depths_multi.mean():.6f}, 标准差 {depth_std:.6f}" if depth_std is not None else f"  深度: 均值 {depths_multi.mean():.6f}, 标准差 None")
        if len(positions_multi) > 0:
            print(f"  位置: 均值 {positions_multi.mean():.4f}, 标准差 {position_std:.4f}" if position_std is not None else f"  位置: 均值 {positions_multi.mean():.4f}, 标准差 None")

    result = {
        'graph': gname,
        'best_edge': [int(u) for u in best_edge],
        'valley_s_single': float(best_valley),
        'depth_single': float(best_depth),
        'depth_multi_mean': float(depths_multi.mean()) if len(depths_multi) > 0 else None,
        'depth_multi_std': depth_std,
        'position_multi_mean': float(positions_multi.mean()) if len(positions_multi) > 0 else None,
        'position_multi_std': position_std,
        'all_edge_results': edge_results
    }
    with open(output_file, 'w') as f:
        json.dump(result, f, indent=2, ensure_ascii=False)
    return result

s_values = np.linspace(0.0, 2.0, 41)
N = 15
N_up = 7
tree_G = generate_tree_N15()
random_G = generate_random_N15()
os.makedirs("table2_new_data", exist_ok=True)

tree_result = scan_all_edges_and_select(tree_G, "tree", s_values, N_up, "table2_new_data/tree_result.json")
random_result = scan_all_edges_and_select(random_G, "random", s_values, N_up, "table2_new_data/random_result.json")

print("\n=== 摘要 ===")
if tree_result:
    tree_std = tree_result['depth_multi_std']
    print(f"树图: 边 {tree_result['best_edge']}, 位置 {tree_result['valley_s_single']}, 深度 {tree_result['depth_single']:.4f}, 多种子深度 {tree_result['depth_multi_mean']:.4f}±{tree_std:.4f}" if tree_std is not None else f"树图: 边 {tree_result['best_edge']}, 位置 {tree_result['valley_s_single']}, 深度 {tree_result['depth_single']:.4f}, 多种子深度 {tree_result['depth_multi_mean']:.4f}±None")
if random_result:
    random_std = random_result['depth_multi_std']
    print(f"随机图: 边 {random_result['best_edge']}, 位置 {random_result['valley_s_single']}, 深度 {random_result['depth_single']:.4f}, 多种子深度 {random_result['depth_multi_mean']:.4f}±{random_std:.4f}" if random_std is not None else f"随机图: 边 {random_result['best_edge']}, 位置 {random_result['valley_s_single']}, 深度 {random_result['depth_single']:.4f}, 多种子深度 {random_result['depth_multi_mean']:.4f}±None")