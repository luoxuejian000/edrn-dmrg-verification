"""
生成论文表II所需的树图和随机图谷深度数据（修复版）
严格遵循：关系本体论、防工具理性、反对对齐
- 图定义内嵌，不依赖外部文件
- 修复 depth=None 时的格式化错误
- 扫描每条边作为矛盾边，选出谷最深的边
- 多种子审计，输出均值和标准差
"""
import numpy as np
import networkx as nx
import json
import itertools
from scipy.sparse import lil_matrix, csr_matrix
from scipy.sparse.linalg import eigsh
import os

# =============================================
# 1. 图定义（内嵌，种子固定，确保可复现）
# =============================================
def generate_tree_N15():
    """N=15的树，14条边，种子42"""
    tree = nx.random_tree(15, seed=42)
    tree = nx.relabel_nodes(tree, {old: new for new, old in enumerate(tree.nodes())})
    return tree

def generate_random_N15():
    """N=15的随机图，27条边，种子42"""
    random_graph = nx.gnm_random_graph(15, 27, seed=42)
    random_graph = nx.relabel_nodes(random_graph, {old: new for new, old in enumerate(random_graph.nodes())})
    return random_graph

# =============================================
# 2. 哈密顿量构建（固定磁化扇区）
# =============================================
def build_hamiltonian_sector(N, edges, J_vals, N_up):
    basis_states = list(itertools.combinations(range(N), N_up))
    state_to_idx = {st: i for i, st in enumerate(basis_states)}
    dim = len(basis_states)
    H = lil_matrix((dim, dim), dtype=float)

    for (i, j), J in zip(edges, J_vals):
        # 对角项 sigma_z^i sigma_z^j
        for idx, state in enumerate(basis_states):
            si = 1 if i in state else -1
            sj = 1 if j in state else -1
            H[idx, idx] += J * si * sj

        # 非对角项 2(sigma_i^+ sigma_j^- + sigma_i^- sigma_j^+)
        for idx, state in enumerate(basis_states):
            i_up = i in state
            j_up = j in state
            if i_up and not j_up:
                ns = list(state)
                ns.remove(i)
                ns.append(j)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2 * J
            elif j_up and not i_up:
                ns = list(state)
                ns.remove(j)
                ns.append(i)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2 * J

    return csr_matrix(H), basis_states

def compute_enhanced_diagnostic(N, edges, J_vals, N_up, seed=0):
    H, basis = build_hamiltonian_sector(N, edges, J_vals, N_up)
    rng = np.random.default_rng(seed)
    v0 = rng.standard_normal(H.shape[0])
    evals, evecs = eigsh(H, k=1, which='SA', v0=v0)
    psi = evecs[:, 0]

    corrs = []
    for (i, j) in edges:
        sp = np.array([(1 if i in s else -1)*(1 if j in s else -1) for s in basis])
        corrs.append(np.sum(np.abs(psi)**2 * sp))
    return np.std(np.array(corrs))

# =============================================
# 3. 扫描单条矛盾边
# =============================================
def scan_edge(N, edges, edge_idx, s_values, N_up, seed=0):
    J_vals = np.ones(len(edges))
    results = []
    for s in s_values:
        J_vals[edge_idx] = s
        E = compute_enhanced_diagnostic(N, edges, J_vals, N_up, seed=seed)
        results.append(E)
        J_vals[edge_idx] = 1.0
    return np.array(results)

def detect_valley(s_values, E_values):
    """寻找内部极小值，返回 (位置, 深度, 是否内部)"""
    min_idx = np.argmin(E_values)
    if min_idx == 0 or min_idx == len(E_values)-1:
        return None, None, False
    if E_values[min_idx] < E_values[min_idx-1] and E_values[min_idx] < E_values[min_idx+1]:
        depth = E_values[0] - E_values[min_idx]
        return s_values[min_idx], depth, True
    return None, None, False

# =============================================
# 4. 全图扫描所有边，选出最深谷
# =============================================
def scan_all_edges_and_select(G, gname, s_values, N_up, output_file):
    N = G.number_of_nodes()
    edges = list(G.edges())
    print(f"\n=== {gname}: 扫描所有 {len(edges)} 条边 ===")

    best_edge = None
    best_valley = None
    best_depth = -1.0
    edge_results = []

    for edge_idx in range(len(edges)):
        E_arr = scan_edge(N, edges, edge_idx, s_values, N_up, seed=0)
        s_val, depth, is_internal = detect_valley(s_values, E_arr)

        # 修复：条件格式化，避免 None 报错
        s_str = f"{s_val:.4f}" if s_val is not None else "None"
        d_str = f"{depth:.6f}" if depth is not None else "None"
        print(f"  边 {edges[edge_idx]}: 谷位置={s_str}, 深度={d_str}, 内部={is_internal}")

        if is_internal and depth is not None and depth > best_depth:
            best_depth = depth
            best_valley = s_val
            best_edge = edges[edge_idx]

        edge_results.append({
            'edge': [int(u), int(v) for u, v in edges[edge_idx]],
            'valley_s': float(s_val) if s_val is not None else None,
            'depth': float(depth) if depth is not None else None,
            'is_internal': bool(is_internal)
        })

    if best_edge is not None:
        print(f"\n最深谷: 边 {best_edge}, 位置 s={best_valley:.4f}, 深度 {best_depth:.6f}")

        edge_idx = edges.index(best_edge)
        depths_multi = []
        positions_multi = []
        for seed in range(3):
            E_arr = scan_edge(N, edges, edge_idx, s_values, N_up, seed=seed)
            s_val, depth, _ = detect_valley(s_values, E_arr)
            if depth is not None:
                depths_multi.append(depth)
            if s_val is not None:
                positions_multi.append(s_val)

        depths_multi = np.array(depths_multi)
        positions_multi = np.array(positions_multi)

        if len(depths_multi) > 0:
            print(f"多种子审计（{len(depths_multi)}个有效种子）：")
            print(f"  深度: 均值 {depths_multi.mean():.6f}, 标准差 {depths_multi.std(ddof=1):.6f}")
            if len(positions_multi) > 0:
                print(f"  位置: 均值 {positions_multi.mean():.4f}, 标准差 {positions_multi.std(ddof=1):.4f}")

        result = {
            'graph': gname,
            'best_edge': [int(u), int(v) for u, v in best_edge],
            'valley_s_single': float(best_valley) if best_valley is not None else None,
            'depth_single': float(best_depth),
            'depth_multi_mean': float(depths_multi.mean()) if len(depths_multi)>0 else None,
            'depth_multi_std': float(depths_multi.std(ddof=1)) if len(depths_multi)>1 else None,
            'all_edge_results': edge_results
        }
        with open(output_file, 'w') as f:
            json.dump(result, f, indent=2)
        return result
    else:
        print(f"\n{ gname } 未检测到内部谷。")
        return None

# =============================================
# 5. 主流程
# =============================================
if __name__ == "__main__":
    s_values = np.linspace(0.0, 2.0, 41)
    N = 15
    N_up = 7

    tree_G = generate_tree_N15()
    random_G = generate_random_N15()

    os.makedirs("table2_new_data", exist_ok=True)

    tree_result = scan_all_edges_and_select(
        tree_G, "tree", s_values, N_up,
        "table2_new_data/tree_result.json"
    )

    random_result = scan_all_edges_and_select(
        random_G, "random", s_values, N_up,
        "table2_new_data/random_result.json"
    )

    print("\n=== 摘要 ===")
    if tree_result:
        print(f"树图: 边 {tree_result['best_edge']}, 位置 {tree_result['valley_s_single']}, "
              f"深度 {tree_result['depth_single']:.4f}, "
              f"多种子深度 {tree_result['depth_multi_mean']:.4f}±{tree_result['depth_multi_std']:.4f}")
    if random_result:
        print(f"随机图: 边 {random_result['best_edge']}, 位置 {random_result['valley_s_single']}, "
              f"深度 {random_result['depth_single']:.4f}, "
              f"多种子深度 {tree_result['depth_multi_mean']:.4f}±{tree_result['depth_multi_std']:.4f}")