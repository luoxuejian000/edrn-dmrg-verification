"""
记忆驱动的分形折叠 —— 金箍棒 3.0 DMRG
矛盾边选择基于累积涨落（当前+历史）
检验：记忆是否是关系场涌现复杂性的关键？
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tenpy.models.model import CouplingMPOModel
from tenpy.models.lattice import Chain
from tenpy.networks.site import SpinHalfSite
from tenpy.networks.mps import MPS
from tenpy.algorithms import dmrg

class FoldModel(CouplingMPOModel):
    """链式Heisenberg模型，矛盾边位置和强度可独立设置"""
    def __init__(self, model_params):
        L = model_params.get('L', 10)
        self.contradiction_strength = model_params.get('contradiction_strength', 0.5)
        self.contradiction_edge = model_params.get('contradiction_edge', (L//2 - 1, L//2))
        lat = Chain(L, SpinHalfSite(conserve='Sz'), bc='open')
        model_params['lattice'] = lat
        CouplingMPOModel.__init__(self, model_params)

    def init_terms(self, model_params):
        L = self.lat.N_sites
        for i in range(L-1):
            if (i, i+1) == self.contradiction_edge or (i+1, i) == self.contradiction_edge:
                J = self.contradiction_strength
            else:
                J = 1.0
            self.add_coupling_term(J * 0.5, i, i+1, 'Sp', 'Sm', plus_hc=True)
            self.add_coupling_term(J, i, i+1, 'Sz', 'Sz')


def compute_diagnostics(L, contradiction_edge, s, chi_max=100):
    """用DMRG计算基态，返回能隙、默认诊断、精细诊断和边关联涨落列表"""
    M = FoldModel(dict(
        L=L, contradiction_edge=contradiction_edge,
        contradiction_strength=s, bc_MPS='finite', conserve='Sz'
    ))
    init = ['up', 'down'] * (L // 2)
    if L % 2 == 1:
        init.append('up')
    psi = MPS.from_product_state(M.lat.mps_sites(), init, bc='finite')
    dmrg_params = {'mixer': True, 'chi_max': chi_max, 'max_sweeps': 50, 'verbose': 0}
    eng = dmrg.run(psi, M, dmrg_params)
    E0 = eng['E']
    
    init_ex = init.copy()
    center = L // 2
    init_ex[center] = 'down' if init_ex[center] == 'up' else 'up'
    psi_ex = MPS.from_product_state(M.lat.mps_sites(), init_ex, bc='finite')
    eng_ex = dmrg.run(psi_ex, M, dmrg_params)
    E1 = eng_ex['E']
    gap = E1 - E0

    Sz = psi.expectation_value('Sz')
    coarse = np.mean(np.abs(Sz))
    
    corrs = []
    for i in range(L - 1):
        corr = psi.correlation_function('Sz', 'Sz', [i], [i+1])
        corrs.append(corr[0])
    fine = np.std(corrs) if corrs else 0.0
    
    return gap, coarse, fine, corrs


def update_cumulative_correlations(cumulative, current, alpha=0.5):
    """用指数加权更新累积涨落: C_new = alpha*C_old + (1-alpha)*|current|"""
    if cumulative is None:
        return np.abs(current)
    return alpha * cumulative + (1 - alpha) * np.abs(current)


def find_edge_from_cumulative(cumulative):
    """找到累积涨落最大的边"""
    max_idx = np.argmax(cumulative)
    return (max_idx, max_idx + 1)


def run_memory_fold(L=10, fold_steps=20, alpha=0.5, contradiction_strength=0.5, chi_max=100):
    """
    有记忆的自折叠实验：
    用累积涨落（当前+历史）选择下一步矛盾边
    """
    gaps, coarse_vals, fine_vals = [], [], []
    fold_path = []
    
    current_edge = (L//2 - 1, L//2)
    cumulative = None  # 初始无记忆
    
    print(f"记忆参数 alpha = {alpha}")
    for step in range(fold_steps):
        gap, coarse, fine, corrs = compute_diagnostics(L, current_edge, contradiction_strength, chi_max)
        gaps.append(gap)
        coarse_vals.append(coarse)
        fine_vals.append(fine)
        fold_path.append(current_edge)
        
        # 更新累积涨落并选择下一条边
        cumulative = update_cumulative_correlations(cumulative, corrs, alpha)
        next_edge = find_edge_from_cumulative(cumulative)
        
        print(f"Step {step}: edge={current_edge}, gap={gap:.6f}, fine={fine:.6f}, next→{next_edge}")
        current_edge = next_edge
    
    return np.array(gaps), np.array(coarse_vals), np.array(fine_vals), fold_path


if __name__ == "__main__":
    L = 10
    fold_steps = 20
    alphas = [0.0, 0.3, 0.5, 0.7, 0.9]
    contradiction_strength = 0.5
    
    all_results = {}
    
    for alpha in alphas:
        print(f"\n=== α = {alpha} ===")
        gaps, coarse_vals, fine_vals, fold_path = run_memory_fold(
            L, fold_steps, alpha, contradiction_strength, chi_max=100
        )
        all_results[alpha] = (gaps, coarse_vals, fine_vals, fold_path)
        
        # 保存数据
        np.savetxt(f'memory_fold_alpha{alpha:.1f}.csv',
                   np.column_stack((np.arange(fold_steps), gaps, coarse_vals, fine_vals)),
                   header='step,gap,coarse,fine', delimiter=',')
        with open(f'memory_fold_path_alpha{alpha:.1f}.txt', 'w') as f:
            f.write("step,edge_i,edge_j\n")
            for step, (i, j) in enumerate(fold_path):
                f.write(f"{step},{i},{j}\n")
    
    # 对比图：不同α下的精细诊断序列
    fig, axes = plt.subplots(len(alphas), 1, figsize=(12, 3*len(alphas)))
    if len(alphas) == 1:
        axes = [axes]
    steps = np.arange(fold_steps)
    for ax, alpha in zip(axes, alphas):
        _, _, fine_vals, _ = all_results[alpha]
        ax.plot(steps, fine_vals, 's-', label=f'α={alpha:.1f}')
        ax.set_xlabel('Step')
        ax.set_ylabel('Fine metric')
        ax.set_title(f'Memory-driven folding (α={alpha:.1f})')
        ax.grid(True, alpha=0.3)
        ax.legend()
    plt.tight_layout()
    plt.savefig('memory_fold_comparison.png', dpi=150)
    
    # 自相似性报告
    print("\n=== 自相似性分析 ===")
    for alpha in alphas:
        _, _, fine_vals, fold_path = all_results[alpha]
        print(f"\nα={alpha:.1f}:")
        print(f"  折叠路径: {fold_path}")
        # 检查峰值和谷底
        peaks = [i for i in range(1, len(fine_vals)-1) if fine_vals[i] > fine_vals[i-1] and fine_vals[i] > fine_vals[i+1]]
        valleys = [i for i in range(1, len(fine_vals)-1) if fine_vals[i] < fine_vals[i-1] and fine_vals[i] < fine_vals[i+1]]
        if len(peaks) >= 2:
            peak_intervals = np.diff(peaks)
            print(f"  峰值位置: {peaks}, 间隔: {peak_intervals}")
        if len(valleys) >= 2:
            valley_intervals = np.diff(valleys)
            print(f"  谷底位置: {valleys}, 间隔: {valley_intervals}")
        # 检查是否落入简单吸引子（如两条边之间振荡）
        edges_set = set(fold_path)
        print(f"  不同边数: {len(edges_set)}")
    
    print("\nDone. 所有数据已保存。")