"""
关系场自折叠实验 —— 金箍棒 3.0 DMRG
矛盾边动态移动：系统自己决定折叠方向
检验：关系场自折叠是否涌现分形特征？
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tenpy.models.model import CouplingMPOModel
from tenpy.models.lattice import Chain
from tenpy.networks.site import SpinHalfSite
from tenpy.networks.mps import MPS
from tenpy.algorithms import dmrg

class FoldModel(CouplingMPOModel):
    """链式Heisenberg模型，矛盾边位置和强度可独立设置"""
    def __init__(self, model_params):
        L = model_params.get('L', 10)
        self.contradiction_strength = model_params.get('contradiction_strength', 0.5)
        self.contradiction_edge = model_params.get('contradiction_edge', (L//2 - 1, L//2))
        lat = Chain(L, SpinHalfSite(conserve='Sz'), bc='open')
        model_params['lattice'] = lat
        CouplingMPOModel.__init__(self, model_params)

    def init_terms(self, model_params):
        L = self.lat.N_sites
        for i in range(L-1):
            if (i, i+1) == self.contradiction_edge or (i+1, i) == self.contradiction_edge:
                J = self.contradiction_strength
            else:
                J = 1.0
            self.add_coupling_term(J * 0.5, i, i+1, 'Sp', 'Sm', plus_hc=True)
            self.add_coupling_term(J, i, i+1, 'Sz', 'Sz')


def compute_diagnostics(L, contradiction_edge, s, chi_max=100):
    """用DMRG计算基态，返回能隙、默认诊断、精细诊断和边关联涨落列表"""
    M = FoldModel(dict(
        L=L, contradiction_edge=contradiction_edge,
        contradiction_strength=s, bc_MPS='finite', conserve='Sz'
    ))
    init = ['up', 'down'] * (L // 2)
    if L % 2 == 1:
        init.append('up')
    psi = MPS.from_product_state(M.lat.mps_sites(), init, bc='finite')
    dmrg_params = {'mixer': True, 'chi_max': chi_max, 'max_sweeps': 50, 'verbose': 0}
    eng = dmrg.run(psi, M, dmrg_params)
    E0 = eng['E']
    
    init_ex = init.copy()
    center = L // 2
    init_ex[center] = 'down' if init_ex[center] == 'up' else 'up'
    psi_ex = MPS.from_product_state(M.lat.mps_sites(), init_ex, bc='finite')
    eng_ex = dmrg.run(psi_ex, M, dmrg_params)
    E1 = eng_ex['E']
    gap = E1 - E0

    Sz = psi.expectation_value('Sz')
    coarse = np.mean(np.abs(Sz))
    
    corrs = []
    for i in range(L - 1):
        corr = psi.correlation_function('Sz', 'Sz', [i], [i+1])
        corrs.append(corr[0])
    fine = np.std(corrs) if corrs else 0.0
    
    return gap, coarse, fine, corrs


def find_max_correlation_edge(corrs):
    """找到关联涨落最大的边，作为下一步的折叠方向"""
    abs_corrs = np.abs(corrs)
    max_idx = np.argmax(abs_corrs)
    return (max_idx, max_idx + 1)


def run_fold_experiment(L=10, fold_steps=10, contradiction_strength=0.5, chi_max=100):
    """
    关系场自折叠实验：
    从中心键开始，每次矛盾驱动后，计算边关联涨落，
    选择涨落最大的边作为下一步的矛盾边（模拟自折叠）
    """
    gaps, coarse_vals, fine_vals = [], [], []
    fold_path = []  # 记录矛盾边的移动路径
    
    # 初始矛盾边：中心键
    current_edge = (L//2 - 1, L//2)
    print(f"初始矛盾边: {current_edge}")
    
    for step in range(fold_steps):
        gap, coarse, fine, corrs = compute_diagnostics(L, current_edge, contradiction_strength, chi_max)
        gaps.append(gap)
        coarse_vals.append(coarse)
        fine_vals.append(fine)
        fold_path.append(current_edge)
        
        # 找到关联涨落最大的边，作为下一步的折叠方向
        next_edge = find_max_correlation_edge(corrs)
        print(f"Step {step}: edge={current_edge}, gap={gap:.6f}, coarse={coarse:.4f}, fine={fine:.6f}, next→{next_edge}")
        
        current_edge = next_edge
    
    return np.array(gaps), np.array(coarse_vals), np.array(fine_vals), fold_path


if __name__ == "__main__":
    L = 10
    fold_steps = 15
    contradiction_strength = 0.5
    
    print(f"=== 关系场自折叠实验 (L={L}, steps={fold_steps}) ===")
    print("系统从中心键开始，每次折叠后自动选择下一步的折叠方向\n")
    
    gaps, coarse_vals, fine_vals, fold_path = run_fold_experiment(
        L, fold_steps, contradiction_strength, chi_max=100
    )
    
    # 保存数据
    np.savetxt('fold_universe_results.csv',
               np.column_stack((np.arange(fold_steps), gaps, coarse_vals, fine_vals)),
               header='step,gap,coarse,fine', delimiter=',')
    
    # 保存折叠路径
    with open('fold_path.txt', 'w') as f:
        f.write("step,edge_i,edge_j\n")
        for step, (i, j) in enumerate(fold_path):
            f.write(f"{step},{i},{j}\n")
    
    # 诊断图
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
    
    steps = np.arange(fold_steps)
    ax1.plot(steps, coarse_vals, 'o-', label='Default diagnosis', color='#1f77b4')
    ax1.set_xlabel('Fold step')
    ax1.set_ylabel('Coarse metric')
    ax1.set_title('Default Diagnosis (Entity-level)')
    ax1.grid(True, alpha=0.3)
    
    ax2.plot(steps, fine_vals, 's-', label='Enhanced diagnosis', color='#d62728')
    ax2.set_xlabel('Fold step')
    ax2.set_ylabel('Fine metric')
    ax2.set_title('Enhanced Diagnosis (Relation-level)')
    ax2.grid(True, alpha=0.3)
    
    # 标注自相似性：寻找重复模式
    for i in range(2, len(fine_vals)-2):
        if abs(fine_vals[i] - fine_vals[i-2]) < 0.001:
            ax2.axvspan(i-2, i, alpha=0.15, color='green')
    
    plt.suptitle(f'Relation-Field Self-Folding (L={L}, {fold_steps} steps)')
    plt.tight_layout()
    plt.savefig('fold_universe_diagnosis.png', dpi=150)
    
    # 自相似性报告
    print("\n=== 自相似性分析 ===")
    print(f"折叠路径: {fold_path}")
    
    # 检查精细诊断是否出现周期性的非单调响应
    peaks = []
    valleys = []
    for i in range(1, len(fine_vals)-1):
        if fine_vals[i] > fine_vals[i-1] and fine_vals[i] > fine_vals[i+1]:
            peaks.append(i)
        if fine_vals[i] < fine_vals[i-1] and fine_vals[i] < fine_vals[i+1]:
            valleys.append(i)
    
    if len(peaks) >= 2:
        peak_intervals = np.diff(peaks)
        print(f"增强诊断峰值位置: {peaks}")
        print(f"峰值间隔: {peak_intervals}")
        if len(np.unique(peak_intervals)) == 1:
            print(f"发现周期性自相似: 峰值间隔恒为 {peak_intervals[0]}")
    if len(valleys) >= 2:
        valley_intervals = np.diff(valleys)
        print(f"增强诊断谷底位置: {valleys}")
        print(f"谷底间隔: {valley_intervals}")
    
    print("\nDone. 数据已保存。")