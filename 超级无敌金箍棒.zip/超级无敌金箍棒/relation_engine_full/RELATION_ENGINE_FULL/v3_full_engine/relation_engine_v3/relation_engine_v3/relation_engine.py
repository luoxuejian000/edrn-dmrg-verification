#!/usr/bin/env python3
"""
Relation Structure Analysis Engine v3.0
========================================
Core: 任意图结构 → 海森堡模型 → 全诊断量扫描

诊断量:
  1. 增强诊断 (Enhanced Diagnosis)     - 沉默失谐检测
  2. 默认诊断 (Default Diagnosis)       - 粗粒度关联
  3. 纠缠熵 (Entanglement Entropy)       - 关系纠缠深度
  4. 保真度 (Fidelity)                  - 结构脆弱性
  5. 拓扑纠缠熵 (Topological Entanglement Entropy) - 全局秩序
  6. 逾渗阈值 (Percolation Threshold)   - 信息传播临界点
  7. 量子失谐 (Quantum Discord)         - 关联断裂

Author: Based on user's theoretical framework
"""

import numpy as np
from scipy.sparse.linalg import eigsh
import json
import os
import time
import warnings
warnings.filterwarnings('ignore')

# Import optimized Hamiltonian builder
from hamiltonian_core import build_hamiltonian


# ============================================================
# 2. 可观测量计算
# ============================================================

def compute_zz_correlations(psi, N):
    """
    计算所有节点对的 <σ_i^z σ_j^z> 关联
    返回: dict {(i,j): <σ_i^z σ_j^z>}
    """
    dim = 2**N
    # 用稀疏作用方式计算，避免构建大矩阵
    correlations = {}
    
    for i in range(N):
        for j in range(i+1, N):
            # <σ_i^z σ_j^z> = Σ |ψ_α|² * (-1)^{α_i + α_j}
            val = 0.0
            for alpha in range(dim):
                zi = (alpha >> i) & 1
                zj = (alpha >> j) & 1
                sign = 1.0 if (zi == zj) else -1.0
                val += abs(psi[alpha])**2 * sign
            correlations[(i, j)] = float(val)
    
    return correlations


def enhanced_diagnosis(correlations, edges):
    """增强诊断: 最近邻 zz 关联的标准差"""
    vals = [correlations.get(e, 0) for e in edges]
    return float(np.std(vals))


def default_diagnosis(correlations, edges):
    """默认诊断: 平均绝对 zz 关联"""
    vals = [abs(correlations.get(e, 0)) for e in edges]
    return float(np.mean(vals)) if vals else 0.0


def entanglement_entropy(psi, N, subsystem_nodes):
    """
    纠缠熵: 对指定子系统的约化密度矩阵求冯·诺依曼熵
    S = -Tr(ρ_A log₂ ρ_A)
    """
    if not subsystem_nodes:
        return 0.0
    
    dim = 2**N
    dA = 2**len(subsystem_nodes)
    rho_A = np.zeros((dA, dA), dtype=np.complex128)
    
    # Build mapping: full basis index → subsystem basis index
    # subsystem_nodes are bit positions
    sub_node_list = sorted(subsystem_nodes)
    env_nodes = sorted(set(range(N)) - set(subsystem_nodes))
    
    for i in range(dim):
        # Extract subsystem bits
        idx_i = 0
        for k, node in enumerate(sub_node_list):
            if (i >> node) & 1:
                idx_i |= (1 << k)
        
        amp_i = psi[i]
        if abs(amp_i) < 1e-15:
            continue
        
        for j in range(dim):
            # Check environment bits match
            env_match = True
            for node in env_nodes:
                if ((i >> node) & 1) != ((j >> node) & 1):
                    env_match = False
                    break
            
            if env_match:
                idx_j = 0
                for k, node in enumerate(sub_node_list):
                    if (j >> node) & 1:
                        idx_j |= (1 << k)
                rho_A[idx_i, idx_j] += amp_i * np.conj(psi[j])
    
    # Eigenvalues of Hermitian matrix
    eigvals = np.linalg.eigvalsh(rho_A.real)  # rho is Hermitian, diagonalize real part
    eigvals = eigvals[eigvals > 1e-14]
    
    if len(eigvals) == 0:
        return 0.0
    
    eigvals = eigvals / eigvals.sum()
    entropy = -np.sum(eigvals * np.log2(eigvals))
    return float(entropy)


def topological_entanglement_entropy(psi, N, edges):
    """
    拓扑纠缠熵 (Kitaev-Preskill): 
    S_topo = S_A + S_B + S_C - S_AB - S_AC - S_BC + S_ABC
    """
    nodes = list(range(N))
    n = max(N // 3, 1)
    
    region_A = nodes[:n]
    region_B = nodes[n:2*n] if 2*n <= N else nodes[n:]
    region_C = nodes[2*n:] if 2*n < N else nodes[:max(1, N-2*n)]
    
    S_A = entanglement_entropy(psi, N, region_A)
    S_B = entanglement_entropy(psi, N, region_B)
    S_C = entanglement_entropy(psi, N, region_C)
    
    S_AB = entanglement_entropy(psi, N, region_A + region_B)
    S_AC = entanglement_entropy(psi, N, region_A + region_C)
    S_BC = entanglement_entropy(psi, N, region_B + region_C)
    
    S_ABC = entanglement_entropy(psi, N, region_A + region_B + region_C)
    
    S_topo = S_A + S_B + S_C - S_AB - S_AC - S_BC + S_ABC
    return float(S_topo)


def fidelity(psi1, psi2):
    """保真度: |⟨ψ1|ψ2⟩|²"""
    f = abs(np.vdot(psi1, psi2))**2
    return float(min(f, 1.0))


def quantum_discord_proxy(psi, N, bipartition=None):
    """
    量子失谐代理: 测量一个子系统后纠缠的变化
    简化: 比较原始纠缠熵与去相干后的纠缠熵之差
    """
    if bipartition is None:
        bipartition = list(range(N // 2))
    
    # Original entanglement
    S_orig = entanglement_entropy(psi, N, bipartition)
    
    # Decohered state: |ψ⟩ → diagonal density matrix
    dim = 2**N
    rho_diag = np.zeros((dim, dim), dtype=np.complex128)
    for i in range(dim):
        rho_diag[i, i] = abs(psi[i])**2
    
    # Partial trace over environment
    sub_nodes = sorted(bipartition)
    dA = 2**len(sub_nodes)
    rho_A_deco = np.zeros((dA, dA), dtype=np.complex128)
    
    env_nodes = sorted(set(range(N)) - set(sub_nodes))
    
    for i in range(dim):
        idx_i = 0
        for k, node in enumerate(sub_nodes):
            if (i >> node) & 1:
                idx_i |= (1 << k)
        rho_A_deco[idx_i, idx_i] += abs(psi[i])**2
    
    eigvals = np.linalg.eigvalsh(rho_A_deco.real)
    eigvals = eigvals[eigvals > 1e-14]
    if len(eigvals) == 0:
        return 0.0
    eigvals = eigvals / eigvals.sum()
    S_deco = -np.sum(eigvals * np.log2(eigvals))
    
    return float(abs(S_orig - S_deco))


def energy_gap_from_H(H, psi_ground):
    """能隙: 用 Lanczos 求第一激发态（小矩阵用全对角化）"""
    dim = H.shape[0]
    if dim <= 4096:
        eigvals = np.linalg.eigvalsh(H)
        eigvals = np.sort(eigvals)
        return float(eigvals[1] - eigvals[0])
    else:
        # Use eigsh for larger matrices
        v0 = np.random.RandomState(42).randn(dim)
        v0 /= np.linalg.norm(v0)
        try:
            eigvals = eigsh(H, k=2, which='SA', v0=v0, return_eigenvectors=False)
            return float(np.sort(eigvals)[1] - np.sort(eigvals)[0])
        except:
            return 0.0


# ============================================================
# 3. 图构建
# ============================================================

def build_graph_from_adjacency(adj_matrix):
    """从邻接矩阵构建图，返回 (N, edges)"""
    adj = np.array(adj_matrix)
    N = adj.shape[0]
    edges = []
    for i in range(N):
        for j in range(i+1, N):
            if adj[i, j] != 0:
                edges.append((i, j))
    return N, edges


# ============================================================
# 4. 全边扫描引擎
# ============================================================

def scan_all_edges(N, edges, s_range, seeds=3, use_sparse=False, 
                   compute_full_diagnostics=True, verbose=True):
    """
    对每条边轮流作为矛盾边，进行全扫描
    
    返回: results dict
    """
    dim = 2**N
    use_dense = (dim <= 4096) and not use_sparse
    # build_hamiltonian uses 'sparse=True' to invoke sparse mode
    sparse_flag = not use_dense
    
    results = {
        'N': N,
        'edges': [list(e) for e in edges],
        's_range': s_range.tolist(),
        'method': 'full_ed' if use_dense else 'lanczos',
        'seeds': seeds,
        'edge_results': {},
        'scan_time': 0,
    }
    
    total_start = time.time()
    
    for edge_idx, edge in enumerate(edges):
        if verbose:
            print(f"  [{edge_idx+1}/{len(edges)}] 扫描边 {edge}...", end=' ', flush=True)
        
        edge_start = time.time()
        edge_data = {
            'enhanced_diagnosis': [],
            'default_diagnosis': [],
            'entanglement_entropy': [],
            'fidelity_curve': [],
            'topological_ee': [],
            'quantum_discord': [],
            'energy_gap': [],
            's_values': s_range.tolist(),
        }
        
        prev_psi = None
        
        for s_idx, s_val in enumerate(s_range):
            enh_vals = []
            def_vals = []
            ee_vals = []
            topo_vals = []
            discord_vals = []
            gap_vals = []
            psi_ensemble = []
            
            for seed in range(seeds):
                # Build and diagonalize
                H = build_hamiltonian(N, edges, J=1.0, s=s_val, 矛盾边=edge, 
                                       sparse=sparse_flag)
                
                if use_dense:
                    eigvals, eigvecs = np.linalg.eigh(H)
                    idx = np.argsort(eigvals)
                    eigvals = eigvals[idx]
                    eigvecs = eigvecs[:, idx]
                    psi = eigvecs[:, 0]
                else:
                    v0 = np.random.RandomState(seed * 1000 + s_idx).randn(H.shape[0])
                    v0 /= np.linalg.norm(v0)
                    try:
                        eigvals, eigvecs = eigsh(H, k=2, which='SA', v0=v0)
                        idx = np.argsort(eigvals)
                        eigvals = eigvals[idx]
                        eigvecs = eigvecs[:, idx]
                        psi = eigvecs[:, 0]
                    except:
                        psi = prev_psi if prev_psi is not None else np.zeros(H.shape[0])
                        eigvals = np.array([0, 1])
                
                # Normalize
                psi = psi / np.linalg.norm(psi)
                psi_ensemble.append(psi)
                
                # Compute observables
                corr = compute_zz_correlations(psi, N)
                enh = enhanced_diagnosis(corr, edges)
                def_d = default_diagnosis(corr, edges)
                gap = float(eigvals[1] - eigvals[0])
                
                enh_vals.append(enh)
                def_vals.append(def_d)
                gap_vals.append(gap)
                
                if compute_full_diagnostics:
                    sub = list(range(N // 2))
                    ee = entanglement_entropy(psi, N, sub)
                    ee_vals.append(ee)
                    
                    topo = topological_entanglement_entropy(psi, N, edges)
                    topo_vals.append(topo)
                    
                    discord = quantum_discord_proxy(psi, N, sub)
                    discord_vals.append(discord)
            
            # Average over seeds
            edge_data['enhanced_diagnosis'].append(float(np.mean(enh_vals)))
            edge_data['default_diagnosis'].append(float(np.mean(def_vals)))
            edge_data['energy_gap'].append(float(np.mean(gap_vals)))
            
            if compute_full_diagnostics:
                edge_data['entanglement_entropy'].append(float(np.mean(ee_vals)))
                edge_data['topological_ee'].append(float(np.mean(topo_vals)))
                edge_data['quantum_discord'].append(float(np.mean(discord_vals)))
            
            # Fidelity with previous s-point
            if prev_psi is not None:
                f = fidelity(prev_psi, psi_ensemble[0])
                edge_data['fidelity_curve'].append(f)
            else:
                edge_data['fidelity_curve'].append(1.0)
            
            prev_psi = psi_ensemble[0]
        
        edge_time = time.time() - edge_start
        
        # Detect valleys in enhanced diagnosis
        enh_curve = np.array(edge_data['enhanced_diagnosis'])
        valleys = detect_valleys(enh_curve, s_range)
        
        edge_data['valleys'] = valleys
        edge_data['scan_time'] = edge_time
        
        edge_data['summary'] = {
            'enhanced_range': float(np.max(enh_curve) - np.min(enh_curve)),
            'enhanced_max': float(np.max(enh_curve)),
            'enhanced_min': float(np.min(enh_curve)),
            'num_valleys': len(valleys),
            'deepest_valley_depth': float(max([v['depth'] for v in valleys], default=0)),
        }
        
        results['edge_results'][f"edge_{edge[0]}_{edge[1]}"] = edge_data
        
        if verbose:
            print(f"完成 ({edge_time:.1f}s, 极差={edge_data['summary']['enhanced_range']:.4f})")
    
    results['scan_time'] = time.time() - total_start
    return results


def detect_valleys(curve, s_range, window=3, min_depth=0.005):
    """检测增强诊断曲线中的局部极小值（谷值）"""
    valleys = []
    n = len(curve)
    
    for i in range(window, n - window):
        is_valley = True
        for j in range(i - window, i + window + 1):
            if j == i:
                continue
            if curve[i] >= curve[j] - 1e-10:
                is_valley = False
                break
        
        if is_valley:
            depth_left = curve[i - window] - curve[i]
            depth_right = curve[i + window] - curve[i]
            depth = min(depth_left, depth_right)
            if depth >= min_depth:
                valleys.append({
                    's_position': float(s_range[i]),
                    'value': float(curve[i]),
                    'depth': float(depth),
                    'index': int(i),
                })
    
    return valleys


# ============================================================
# 5. 逾渗分析
# ============================================================

def percolation_analysis(N, edges, s_range, results):
    """逾渗阈值分析: 增强诊断梯度峰值"""
    percolation_data = {}
    
    for edge_key, edge_data in results['edge_results'].items():
        enh_curve = np.array(edge_data['enhanced_diagnosis'])
        
        gradient = np.abs(np.diff(enh_curve))
        if len(gradient) > 0:
            threshold_idx = np.argmax(gradient)
            percolation_data[edge_key] = {
                'percolation_threshold_s': float(s_range[threshold_idx + 1]),
                'percolation_strength': float(gradient[threshold_idx]),
                'transition_sharpness': float(np.std(gradient)),
            }
        else:
            percolation_data[edge_key] = {
                'percolation_threshold_s': None,
                'percolation_strength': 0.0,
                'transition_sharpness': 0.0,
            }
    
    return percolation_data


# ============================================================
# 6. 全局汇总
# ============================================================

def generate_summary(results, percolation_data):
    """生成全局汇总报告"""
    n_edges = len(results['edge_results'])
    
    summary = {
        'graph_info': {
            'N': results['N'],
            'num_edges': len(results['edges']),
            'method': results['method'],
            'total_scan_time': results['scan_time'],
        },
        'silence_dissonance': {
            'edges_with_valleys': 0,
            'total_edges': n_edges,
            'max_enhanced_range': 0.0,
            'most_dissonant_edge': None,
            'valley_details': [],
        },
        'entanglement': {
            'max_entanglement_edge': None,
            'max_entanglement_value': 0.0,
            'avg_entanglement': 0.0,
        },
        'fidelity_collapse': {
            'edges_with_collapse': 0,
            'max_collapse_edge': None,
            'max_collapse_value': 0.0,
            'min_fidelity': 1.0,
        },
        'topological_order': {
            'max_topo_ee_edge': None,
            'max_topo_ee_value': 0.0,
            'avg_topo_ee': 0.0,
        },
        'percolation': {
            'edges_with_threshold': 0,
            'earliest_threshold': None,
            'latest_threshold': None,
        },
        'quantum_discord': {
            'max_discord_edge': None,
            'max_discord_value': 0.0,
            'avg_discord': 0.0,
        },
    }
    
    ent_sum = 0.0
    topo_sum = 0.0
    discord_sum = 0.0
    earliest_s = float('inf')
    latest_s = -1.0
    
    for edge_key, edge_data in results['edge_results'].items():
        enh = np.array(edge_data['enhanced_diagnosis'])
        fid = np.array(edge_data['fidelity_curve'])
        
        # 沉默失谐
        num_v = edge_data['summary']['num_valleys']
        enh_range = edge_data['summary']['enhanced_range']
        if num_v > 0:
            summary['silence_dissonance']['edges_with_valleys'] += 1
            for v in edge_data['valleys']:
                summary['silence_dissonance']['valley_details'].append({
                    'edge': edge_key,
                    's': v['s_position'],
                    'depth': v['depth'],
                })
        if enh_range > summary['silence_dissonance']['max_enhanced_range']:
            summary['silence_dissonance']['max_enhanced_range'] = enh_range
            summary['silence_dissonance']['most_dissonant_edge'] = edge_key
        
        # 纠缠熵
        if 'entanglement_entropy' in edge_data:
            ee = np.array(edge_data['entanglement_entropy'])
            max_ee = float(np.max(ee))
            avg_ee = float(np.mean(ee))
            ent_sum += avg_ee
            if max_ee > summary['entanglement']['max_entanglement_value']:
                summary['entanglement']['max_entanglement_value'] = max_ee
                summary['entanglement']['max_entanglement_edge'] = edge_key
        
        # 保真度崩塌
        min_fid = float(np.min(fid))
        if min_fid < summary['fidelity_collapse']['min_fidelity']:
            summary['fidelity_collapse']['min_fidelity'] = min_fid
            summary['fidelity_collapse']['max_collapse_edge'] = edge_key
            summary['fidelity_collapse']['max_collapse_value'] = 1.0 - min_fid
        if min_fid < 0.5:
            summary['fidelity_collapse']['edges_with_collapse'] += 1
        
        # 拓扑纠缠熵
        if 'topological_ee' in edge_data:
            topo = np.array(edge_data['topological_ee'])
            max_topo = float(np.max(np.abs(topo)))
            avg_topo = float(np.mean(np.abs(topo)))
            topo_sum += avg_topo
            if max_topo > summary['topological_order']['max_topo_ee_value']:
                summary['topological_order']['max_topo_ee_value'] = max_topo
                summary['topological_order']['max_topo_ee_edge'] = edge_key
        
        # 量子失谐
        if 'quantum_discord' in edge_data:
            qd = np.array(edge_data['quantum_discord'])
            max_qd = float(np.max(qd))
            avg_qd = float(np.mean(qd))
            discord_sum += avg_qd
            if max_qd > summary['quantum_discord']['max_discord_value']:
                summary['quantum_discord']['max_discord_value'] = max_qd
                summary['quantum_discord']['max_discord_edge'] = edge_key
        
        # 逾渗阈值
        if edge_key in percolation_data:
            pt = percolation_data[edge_key]['percolation_threshold_s']
            if pt is not None:
                summary['percolation']['edges_with_threshold'] += 1
                if pt < earliest_s:
                    earliest_s = pt
                if pt > latest_s:
                    latest_s = pt
    
    summary['entanglement']['avg_entanglement'] = ent_sum / n_edges if n_edges else 0
    summary['topological_order']['avg_topo_ee'] = topo_sum / n_edges if n_edges else 0
    summary['quantum_discord']['avg_discord'] = discord_sum / n_edges if n_edges else 0
    
    if earliest_s != float('inf'):
        summary['percolation']['earliest_threshold'] = earliest_s
        summary['percolation']['latest_threshold'] = latest_s
    
    return summary


# ============================================================
# 7. 数据导出
# ============================================================

def save_results(results, percolation_data, summary, output_dir):
    """保存所有结果到文件"""
    os.makedirs(output_dir, exist_ok=True)
    
    full_data = {'results': results, 'percolation': percolation_data, 'summary': summary}
    
    with open(os.path.join(output_dir, 'full_data.json'), 'w') as f:
        json.dump(full_data, f, indent=2)
    
    # Text summary
    sd = summary['silence_dissonance']
    ent = summary['entanglement']
    fc = summary['fidelity_collapse']
    topo = summary['topological_order']
    perc = summary['percolation']
    qd = summary['quantum_discord']
    
    with open(os.path.join(output_dir, 'summary.txt'), 'w') as f:
        f.write("=" * 60 + "\n")
        f.write("RELATION STRUCTURE ANALYSIS ENGINE v3.0\n")
        f.write("=" * 60 + "\n\n")
        
        f.write("--- Graph Info ---\n")
        f.write(f"Nodes: {summary['graph_info']['N']}\n")
        f.write(f"Edges: {summary['graph_info']['num_edges']}\n")
        f.write(f"Method: {summary['graph_info']['method']}\n")
        f.write(f"Total scan time: {summary['graph_info']['total_scan_time']:.1f}s\n\n")
        
        f.write("--- 1. Silence Dissonance (沉默失谐) ---\n")
        pct = 100*sd['edges_with_valleys']/sd['total_edges'] if sd['total_edges'] else 0
        f.write(f"Edges with valleys: {sd['edges_with_valleys']}/{sd['total_edges']} ({pct:.0f}%)\n")
        f.write(f"Max enhanced range: {sd['max_enhanced_range']:.6f}\n")
        f.write(f"Most dissonant edge: {sd['most_dissonant_edge']}\n")
        if sd['valley_details']:
            f.write(f"\nTop 5 valleys:\n")
            sorted_v = sorted(sd['valley_details'], key=lambda x: -x['depth'])[:5]
            for v in sorted_v:
                f.write(f"  {v['edge']}: s={v['s']:.2f}, depth={v['depth']:.4f}\n")
        f.write("\n")
        
        f.write("--- 2. Entanglement Entropy (纠缠熵) ---\n")
        f.write(f"Max: {ent['max_entanglement_value']:.4f} (edge {ent['max_entanglement_edge']})\n")
        f.write(f"Avg: {ent['avg_entanglement']:.4f}\n\n")
        
        f.write("--- 3. Fidelity Collapse (保真度崩塌) ---\n")
        f.write(f"Min fidelity: {fc['min_fidelity']:.6f}\n")
        f.write(f"Max collapse: {fc['max_collapse_value']:.4f} (edge {fc['max_collapse_edge']})\n")
        f.write(f"Edges with collapse: {fc['edges_with_collapse']}\n\n")
        
        f.write("--- 4. Topological Entanglement Entropy (拓扑纠缠熵) ---\n")
        f.write(f"Max: {topo['max_topo_ee_value']:.4f} (edge {topo['max_topo_ee_edge']})\n")
        f.write(f"Avg: {topo['avg_topo_ee']:.4f}\n\n")
        
        f.write("--- 5. Percolation Threshold (逾渗阈值) ---\n")
        f.write(f"Edges with threshold: {perc['edges_with_threshold']}/{sd['total_edges']}\n")
        if perc['earliest_threshold'] is not None:
            f.write(f"Range: s ∈ [{perc['earliest_threshold']:.2f}, {perc['latest_threshold']:.2f}]\n")
        f.write("\n")
        
        f.write("--- 6. Quantum Discord (量子失谐) ---\n")
        f.write(f"Max: {qd['max_discord_value']:.4f} (edge {qd['max_discord_edge']})\n")
        f.write(f"Avg: {qd['avg_discord']:.4f}\n")
    
    # LaTeX table
    with open(os.path.join(output_dir, 'summary_table.tex'), 'w') as f:
        f.write("\\begin{table}[h]\n\\centering\n")
        f.write("\\begin{tabular}{lc}\n\\hline\n")
        f.write("Diagnostic & Result \\\\\n\\hline\n")
        f.write(f"Silence Dissonance (valley edges) & {sd['edges_with_valleys']}/{sd['total_edges']} \\\\\n")
        f.write(f"Max Enhanced Range & {sd['max_enhanced_range']:.4f} \\\\\n")
        f.write(f"Max Entanglement Entropy & {ent['max_entanglement_value']:.4f} \\\\\n")
        f.write(f"Min Fidelity & {fc['min_fidelity']:.4f} \\\\\n")
        f.write(f"Max Topological EE & {topo['max_topo_ee_value']:.4f} \\\\\n")
        f.write(f"Max Quantum Discord & {qd['max_discord_value']:.4f} \\\\\n")
        if perc['earliest_threshold'] is not None:
            f.write(f"Percolation Range & [{perc['earliest_threshold']:.2f}, {perc['latest_threshold']:.2f}] \\\\\n")
        f.write("\\hline\n\\end{tabular}\n")
        f.write("\\caption{Relation Structure Analysis Summary (Engine v3.0)}\n\\end{table}\n")
    
    print(f"\n✅ 结果已保存到 {output_dir}/")
    print(f"   - full_data.json")
    print(f"   - summary.txt")
    print(f"   - summary_table.tex")


# ============================================================
# 8. 主入口
# ============================================================

def run_analysis(N, edges, s_min=0, s_max=3, num_points=61, 
                 seeds=3, method='auto', output_dir='output',
                 compute_full_diagnostics=True, verbose=True,
                 use_sparse=False):
    """
    一键运行完整分析
    """
    s_range = np.linspace(s_min, s_max, num_points)
    dim = 2**N
    
    if method == 'auto':
        method = 'full' if dim <= 4096 else 'lanczos'
    
    if use_sparse:
        method = 'lanczos'
    
    use_sparse_internal = (method == 'lanczos') and (dim > 4096 or use_sparse)
    
    if verbose:
        print("=" * 60)
        print("RELATION STRUCTURE ANALYSIS ENGINE v3.0")
        print("=" * 60)
        print(f"节点数 N = {N}, 边数 = {len(edges)}")
        print(f"希尔伯特空间维度 = 2^{N} = {dim}")
        print(f"扫描范围 s ∈ [{s_min}, {s_max}], {num_points} 点")
        print(f"种子数 = {seeds}")
        print(f"对角化方法 = {method}")
        diag_str = '全部 (7种)' if compute_full_diagnostics else '基础 (2种)'
        print(f"诊断量 = {diag_str}")
        print(f"预计扫描次数 = {len(edges)} × {num_points} = {len(edges)*num_points}")
        print("=" * 60 + "\n")
    
    results = scan_all_edges(
        N, edges, s_range, seeds=seeds, 
        use_sparse=use_sparse_internal,
        compute_full_diagnostics=compute_full_diagnostics, 
        verbose=verbose
    )
    
    if verbose:
        print("\n📊 计算逾渗阈值分析...")
    percolation_data = percolation_analysis(N, edges, s_range, results)
    
    if verbose:
        print("📋 生成汇总报告...")
    summary = generate_summary(results, percolation_data)
    
    save_results(results, percolation_data, summary, output_dir)
    
    # Print key results
    if verbose:
        print("\n" + "=" * 60)
        print("KEY RESULTS")
        print("=" * 60)
        
        sd = summary['silence_dissonance']
        pct = 100*sd['edges_with_valleys']/sd['total_edges'] if sd['total_edges'] else 0
        print(f"\n1️⃣  沉默失谐: {sd['edges_with_valleys']}/{sd['total_edges']} 条边有谷 ({pct:.0f}%)")
        print(f"   最大增强极差: {sd['max_enhanced_range']:.4f}")
        
        ent = summary['entanglement']
        print(f"\n2️⃣  纠缠熵: 最大={ent['max_entanglement_value']:.4f}, 平均={ent['avg_entanglement']:.4f}")
        
        fc = summary['fidelity_collapse']
        print(f"\n3️⃣  保真度崩塌: {fc['edges_with_collapse']} 条边, 最低={fc['min_fidelity']:.4f}")
        
        topo = summary['topological_order']
        print(f"\n4️⃣  拓扑纠缠熵: 最大={topo['max_topo_ee_value']:.4f}, 平均={topo['avg_topo_ee']:.4f}")
        
        perc = summary['percolation']
        print(f"\n5️⃣  逾渗阈值: {perc['edges_with_threshold']} 条边检测到阈值")
        if perc['earliest_threshold'] is not None:
            print(f"   范围: s ∈ [{perc['earliest_threshold']:.2f}, {perc['latest_threshold']:.02f}]")
        
        qd = summary['quantum_discord']
        print(f"\n6️⃣  量子失谐: 最大={qd['max_discord_value']:.4f}, 平均={qd['avg_discord']:.4f}")
        
        print(f"\n⏱️  总耗时: {summary['graph_info']['total_scan_time']:.1f}s")
    
    return summary


# ============================================================
# 9. 命令行接口
# ============================================================

if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='Relation Structure Analysis Engine v3.0')
    parser.add_argument('--adj-matrix', type=str, help='邻接矩阵 JSON 文件路径')
    parser.add_argument('--N', type=int, help='节点数')
    parser.add_argument('--edges', type=str, help='边列表 JSON 文件路径')
    parser.add_argument('--s-min', type=float, default=0.0)
    parser.add_argument('--s-max', type=float, default=3.0)
    parser.add_argument('--num-points', type=int, default=41)
    parser.add_argument('--seeds', type=int, default=3)
    parser.add_argument('--method', type=str, default='auto', choices=['auto', 'full', 'lanczos'])
    parser.add_argument('--output-dir', type=str, default='output')
    parser.add_argument('--basic-only', action='store_true', help='只算基础诊断量')
    parser.add_argument('--use-sparse', action='store_true', help='强制使用稀疏矩阵')
    
    args = parser.parse_args()
    
    if args.adj_matrix:
        with open(args.adj_matrix, 'r') as f:
            adj = json.load(f)
        N, edges = build_graph_from_adjacency(adj)
    elif args.edges:
        with open(args.edges, 'r') as f:
            edges = json.load(f)
        N = args.N or max(max(e) for e in edges) + 1
    else:
        print("⚠️  未指定图结构，使用默认演示图（分形图 L2）")
        N = 8
        edges = [(0,1),(0,2),(0,3),(1,2),(1,4),(2,3),(2,5),(3,6),(4,5),(4,7),(5,6),(6,7)]
    
    run_analysis(
        N=N, edges=edges,
        s_min=args.s_min, s_max=args.s_max,
        num_points=args.num_points, seeds=args.seeds,
        method=args.method, output_dir=args.output_dir,
        compute_full_diagnostics=not args.basic_only,
    )
