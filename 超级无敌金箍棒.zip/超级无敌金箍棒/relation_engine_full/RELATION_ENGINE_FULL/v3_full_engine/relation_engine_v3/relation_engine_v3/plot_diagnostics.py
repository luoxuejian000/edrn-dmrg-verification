#!/usr/bin/env python3
"""
Plot all diagnostics from Relation Engine v3.0 output
Generates 8 visualization figures
"""

import json
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.patches import FancyArrowPatch
import os

plt.rcParams['font.family'] = 'WenQuanYi Micro Hei'
plt.rcParams['axes.unicode_minus'] = False


def load_data(data_file):
    with open(data_file, 'r') as f:
        return json.load(f)


def plot_all(data_file, output_dir='plots'):
    """生成全部图表"""
    data = load_data(data_file)
    results = data['results']
    percolation = data['percolation']
    summary = data['summary']
    
    os.makedirs(output_dir, exist_ok=True)
    
    edges = [tuple(e) for e in results['edges']]
    s_range = np.array(results['s_values'] if 's_values' in results else 
                       results['edge_results'][list(results['edge_results'].keys())[0]]['s_values'])
    
    # ============================================================
    # Figure 1: 全诊断量总览 (2x3 子图)
    # ============================================================
    fig, axes = plt.subplots(2, 3, figsize=(18, 12))
    fig.suptitle('Relation Structure Analysis Engine v3.0\nFull Diagnostics Overview', 
                 fontsize=16, fontweight='bold')
    
    edge_keys = list(results['edge_results'].keys())
    colors = plt.cm.tab10(np.linspace(0, 1, len(edge_keys)))
    
    # (1) 增强诊断
    ax = axes[0, 0]
    for i, (key, color) in enumerate(zip(edge_keys, colors)):
        curve = results['edge_results'][key]['enhanced_diagnosis']
        ax.plot(s_range, curve, color=color, label=key, linewidth=1.5)
        # 标注谷值
        for v in results['edge_results'][key].get('valleys', []):
            ax.axvline(x=v['s_position'], color=color, linestyle=':', alpha=0.4)
            ax.annotate(f"{v['s_position']:.2f}", xy=(v['s_position'], v['value']),
                       fontsize=7, color=color)
    ax.set_title('① 增强诊断 (沉默失谐)', fontweight='bold')
    ax.set_xlabel('s (矛盾边耦合)')
    ax.set_ylabel('标准差 ⟨σᶻσᶻ⟩')
    ax.legend(fontsize=7, ncol=2)
    ax.grid(True, alpha=0.3)
    
    # (2) 默认诊断
    ax = axes[0, 1]
    for key, color in zip(edge_keys, colors):
        curve = results['edge_results'][key]['default_diagnosis']
        ax.plot(s_range, curve, color=color, label=key, linewidth=1.5)
    ax.set_title('② 默认诊断 (粗粒度关联)', fontweight='bold')
    ax.set_xlabel('s')
    ax.set_ylabel('平均 |⟨σᶻσᶻ⟩|')
    ax.legend(fontsize=7, ncol=2)
    ax.grid(True, alpha=0.3)
    
    # (3) 纠缠熵
    ax = axes[0, 2]
    for key, color in zip(edge_keys, colors):
        if 'entanglement_entropy' in results['edge_results'][key]:
            curve = results['edge_results'][key]['entanglement_entropy']
            ax.plot(s_range, curve, color=color, label=key, linewidth=1.5)
    ax.set_title('③ 纠缠熵 (关系纠缠深度)', fontweight='bold')
    ax.set_xlabel('s')
    ax.set_ylabel('S = -Tr(ρ log ρ)')
    ax.legend(fontsize=7, ncol=2)
    ax.grid(True, alpha=0.3)
    
    # (4) 保真度
    ax = axes[1, 0]
    for key, color in zip(edge_keys, colors):
        curve = results['edge_results'][key]['fidelity_curve']
        ax.plot(s_range, curve, color=color, label=key, linewidth=1.5)
        # 标注最低点
        min_idx = np.argmin(curve)
        if curve[min_idx] < 0.9:
            ax.annotate(f"{curve[min_idx]:.3f}", 
                       xy=(s_range[min_idx], curve[min_idx]),
                       fontsize=7, color=color, fontweight='bold')
    ax.set_title('④ 保真度 (结构脆弱性)', fontweight='bold')
    ax.set_xlabel('s')
    ax.set_ylabel('F = |⟨ψ(s)|ψ(s+Δs)⟩|²')
    ax.set_ylim([0, 1.05])
    ax.legend(fontsize=7, ncol=2)
    ax.grid(True, alpha=0.3)
    
    # (5) 拓扑纠缠熵
    ax = axes[1, 1]
    for key, color in zip(edge_keys, colors):
        if 'topological_ee' in results['edge_results'][key]:
            curve = results['edge_results'][key]['topological_ee']
            ax.plot(s_range, curve, color=color, label=key, linewidth=1.5)
    ax.axhline(y=0, color='gray', linestyle='-', alpha=0.3)
    ax.set_title('⑤ 拓扑纠缠熵 (全局秩序)', fontweight='bold')
    ax.set_xlabel('s')
    ax.set_ylabel('S_topo (Kitaev-Preskill)')
    ax.legend(fontsize=7, ncol=2)
    ax.grid(True, alpha=0.3)
    
    # (6) 量子失谐
    ax = axes[1, 2]
    for key, color in zip(edge_keys, colors):
        if 'quantum_discord' in results['edge_results'][key]:
            curve = results['edge_results'][key]['quantum_discord']
            ax.plot(s_range, curve, color=color, label=key, linewidth=1.5)
    ax.set_title('⑥ 量子失谐 (关联断裂)', fontweight='bold')
    ax.set_xlabel('s')
    ax.set_ylabel('D = |S_orig - S_decohered|')
    ax.legend(fontsize=7, ncol=2)
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, '01_full_diagnostics.png'), dpi=150, bbox_inches='tight')
    plt.close()
    print("✅ 01_full_diagnostics.png")
    
    # ============================================================
    # Figure 2: 逾渗阈值分析
    # ============================================================
    fig, ax = plt.subplots(figsize=(12, 6))
    
    perc_strengths = []
    perc_positions = []
    edge_labels = []
    
    for key in edge_keys:
        if key in percolation:
            pt = percolation[key]
            if pt['percolation_threshold_s'] is not None:
                perc_positions.append(pt['percolation_threshold_s'])
                perc_strengths.append(pt['percolation_strength'])
                edge_labels.append(key)
    
    if perc_positions:
        colors_bar = plt.cm.viridis(np.linspace(0, 1, len(perc_positions)))
        bars = ax.barh(range(len(perc_positions)), perc_strengths, color=colors_bar, alpha=0.8)
        ax.set_yticks(range(len(perc_positions)))
        ax.set_yticklabels(perc_positions)
        ax.set_xlabel('逾渗强度 (梯度峰值)', fontsize=12)
        ax.set_ylabel('逾渗阈值 s 位置', fontsize=12)
        ax.set_title('⑦ 逾渗阈值分析 (信息传播临界点)', fontsize=14, fontweight='bold')
        
        # 标注边名
        for i, (bar, label) in enumerate(zip(bars, edge_labels)):
            ax.text(bar.get_width() + 0.001, i, label, va='center', fontsize=9)
        
        # 标注阈值线
        earliest = summary['percolation'].get('earliest_threshold')
        latest = summary['percolation'].get('latest_threshold')
        if earliest is not None:
            ax.axvline(x=earliest, color='red', linestyle='--', alpha=0.5, label=f'最早阈值={earliest:.2f}')
            ax.axvline(x=latest, color='orange', linestyle='--', alpha=0.5, label=f'最晚阈值={latest:.2f}')
            ax.legend()
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, '02_percolation.png'), dpi=150, bbox_inches='tight')
    plt.close()
    print("✅ 02_percolation.png")
    
    # ============================================================
    # Figure 3: 能隙扫描
    # ============================================================
    fig, ax = plt.subplots(figsize=(12, 6))
    
    for key, color in zip(edge_keys, colors):
        gap_curve = results['edge_results'][key]['energy_gap']
        ax.plot(s_range, gap_curve, color=color, label=key, linewidth=1.5)
    
    ax.set_title('⑧ 能隙扫描 (基态-第一激发态)', fontsize=14, fontweight='bold')
    ax.set_xlabel('s (矛盾边耦合)', fontsize=12)
    ax.set_ylabel('ΔE = E₁ - E₀', fontsize=12)
    ax.legend(fontsize=8, ncol=3)
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, '03_energy_gap.png'), dpi=150, bbox_inches='tight')
    plt.close()
    print("✅ 03_energy_gap.png")
    
    # ============================================================
    # Figure 4: 汇总对比雷达图
    # ============================================================
    fig, ax = plt.subplots(figsize=(10, 10), subplot_kw=dict(polar=True))
    
    categories = ['沉默失谐\n(极差)', '纠缠熵\n(最大)', '保真度崩塌\n(1-最小)', 
                  '拓扑纠缠熵\n(最大)', '量子失谐\n(最大)', '逾渗强度\n(最大)']
    N_cat = len(categories)
    
    # 归一化数据
    max_sd = summary['silence_dissonance']['max_enhanced_range'] or 1
    max_ent = summary['entanglement']['max_entanglement_value'] or 1
    max_fid = 1 - summary['fidelity_collapse']['min_fidelity'] or 1
    max_topo = summary['topological_order']['max_topo_ee_value'] or 1
    max_qd = summary['quantum_discord']['max_discord_value'] or 1
    max_perc = max([percolation[k].get('percolation_strength', 0) for k in percolation], default=1) or 1
    
    values = [
        summary['silence_dissonance']['max_enhanced_range'] / max_sd,
        summary['entanglement']['max_entanglement_value'] / max_ent,
        max_fid,
        summary['topological_order']['max_topo_ee_value'] / max_topo,
        summary['quantum_discord']['max_discord_value'] / max_qd,
        max([percolation[k].get('percolation_strength', 0) for k in percolation], default=0) / max_perc,
    ]
    values += values[:1]
    
    angles = [n / float(N_cat) * 2 * np.pi for n in range(N_cat)]
    angles += angles[:1]
    
    ax.plot(angles, values, 'o-', linewidth=2, color='#e74c3c')
    ax.fill(angles, values, alpha=0.25, color='#e74c3c')
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(categories, fontsize=11)
    ax.set_title('全诊断量汇总雷达图', fontsize=14, fontweight='bold', pad=20)
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, '04_radar_summary.png'), dpi=150, bbox_inches='tight')
    plt.close()
    print("✅ 04_radar_summary.png")
    
    # ============================================================
    # Figure 5: 沉默失谐深度排序
    # ============================================================
    fig, ax = plt.subplots(figsize=(12, 6))
    
    valley_depths = []
    valley_labels = []
    for key in edge_keys:
        valleys = results['edge_results'][key].get('valleys', [])
        if valleys:
            max_depth = max(v['depth'] for v in valleys)
            valley_depths.append(max_depth)
            valley_labels.append(key)
        else:
            valley_depths.append(0)
            valley_labels.append(key + ' (无谷)')
    
    # 排序
    sorted_idx = np.argsort(valley_depths)[::-1]
    valley_depths = [valley_depths[i] for i in sorted_idx]
    valley_labels = [valley_labels[i] for i in sorted_idx]
    
    colors_bar = ['#e74c3c' if d > 0 else '#bdc3c7' for d in valley_depths]
    ax.barh(range(len(valley_depths)), valley_depths, color=colors_bar, alpha=0.8)
    ax.set_yticks(range(len(valley_depths)))
    ax.set_yticklabels(valley_labels)
    ax.set_xlabel('谷深度 (增强诊断极差)', fontsize=12)
    ax.set_title('沉默失谐深度排序', fontsize=14, fontweight='bold')
    ax.invert_yaxis()
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, '05_valley_depth.png'), dpi=150, bbox_inches='tight')
    plt.close()
    print("✅ 05_valley_depth.png")
    
    # ============================================================
    # Figure 6: 增强诊断 vs 默认诊断 对比
    # ============================================================
    fig, axes = plt.subplots(1, len(edge_keys), figsize=(4*len(edge_keys), 5), sharey=False)
    if len(edge_keys) == 1:
        axes = [axes]
    
    for ax, key in zip(axes, edge_keys):
        enh = results['edge_results'][key]['enhanced_diagnosis']
        default = results['edge_results'][key]['default_diagnosis']
        
        ax.plot(s_range, enh, 'r-', linewidth=2, label='增强诊断')
        ax.plot(s_range, default, 'b--', linewidth=2, label='默认诊断')
        ax.set_title(f'边 {key}', fontsize=11)
        ax.set_xlabel('s')
        ax.legend(fontsize=8)
        ax.grid(True, alpha=0.3)
        
        # 标注谷
        for v in results['edge_results'][key].get('valleys', []):
            ax.axvline(x=v['s_position'], color='gray', linestyle=':', alpha=0.5)
    
    fig.suptitle('增强诊断 vs 默认诊断 逐边对比', fontsize=14, fontweight='bold')
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, '06_enhanced_vs_default.png'), dpi=150, bbox_inches='tight')
    plt.close()
    print("✅ 06_enhanced_vs_default.png")
    
    # ============================================================
    # Figure 7: 交叉验证（保真度 + 能隙联合）
    # ============================================================
    fig, ax1 = plt.subplots(figsize=(12, 6))
    
    ax2 = ax1.twinx()
    
    for key, color in zip(edge_keys, colors):
        fid = results['edge_results'][key]['fidelity_curve']
        gap = results['edge_results'][key]['energy_gap']
        
        ax1.plot(s_range, fid, color=color, linewidth=1.5, alpha=0.7, label=f'{key} 保真度')
        ax2.plot(s_range, gap, color=color, linewidth=2.5, linestyle='--', alpha=0.5, 
                label=f'{key} 能隙')
    
    ax1.set_xlabel('s', fontsize=12)
    ax1.set_ylabel('保真度 F', fontsize=12, color='darkred')
    ax2.set_ylabel('能隙 ΔE', fontsize=12, color='darkblue')
    ax1.set_ylim([0, 1.05])
    ax1.set_title('保真度崩塌 vs 能隙关闭 (相变联合检测)', fontsize=14, fontweight='bold')
    
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, fontsize=7, ncol=2)
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, '07_fidelity_gap_joint.png'), dpi=150, bbox_inches='tight')
    plt.close()
    print("✅ 07_fidelity_gap_joint.png")
    
    print(f"\n📊 全部 7 张图表已保存到 {output_dir}/")


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', type=str, default='output/full_data.json')
    parser.add_argument('--output-dir', type=str, default='plots')
    args = parser.parse_args()
    
    plot_all(args.data, args.output_dir)
