#!/usr/bin/env python3
"""
Fast Hamiltonian construction using recursive Kronecker products.
Much faster than the iterative loop approach.
"""

import numpy as np
from scipy.sparse import csr_matrix, kron
import time

# Pauli matrices
SX = np.array([[0, 1], [1, 0]], dtype=np.complex128)
SY = np.array([[0, -1j], [1j, 0]], dtype=np.complex128)
SZ = np.array([[1, 0], [0, -1]], dtype=np.complex128)
ID = np.array([[1, 0], [0, 1]], dtype=np.complex128)


def _build_two_site_op(N, i, j, sigma):
    """Build σ_i ⊗ σ_j as a dense matrix using recursive Kronecker product."""
    # We need: I ⊗ ... ⊗ sigma ⊗ ... ⊗ sigma ⊗ ... ⊗ I
    # indexed by position in [0, N-1]
    # Use np.kron tree approach for efficiency
    
    # Build left part (nodes 0..i-1)
    if i > 0:
        left = np.eye(2**i, dtype=np.complex128)
    else:
        left = None
    
    # Middle: sigma at i, then identities until j-1, then sigma at j
    # Build as: sigma ⊗ I ⊗ ... ⊗ I ⊗ sigma
    mid_nodes = j - i - 1
    if mid_nodes >= 0:
        mid = sigma.copy()
        for k in range(mid_nodes):
            mid = np.kron(mid, ID)
        mid = np.kron(mid, sigma)
    else:
        mid = kron(sigma, sigma)
    
    # Build right part (nodes j+1..N-1)
    right_nodes = N - j - 1
    if right_nodes > 0:
        right = np.eye(2**right_nodes, dtype=np.complex128)
    else:
        right = None
    
    # Combine
    if left is not None and right is not None:
        result = np.kron(left, np.kron(mid, right))
    elif left is not None:
        result = np.kron(left, mid)
    elif right is not None:
        result = np.kron(mid, right)
    else:
        result = mid
    
    return result


def build_heisenberg_fast(N, edges, J=1.0, s=1.0,矛盾边=None):
    """
    Fast construction of Heisenberg Hamiltonian using optimized Kronecker products.
    H = Σ J_ij (σ^xσ^x + σ^yσ^y + σ^zσ^z)
    """
    dim = 2**N
    H = np.zeros((dim, dim), dtype=np.complex128)
    
    for (i, j) in edges:
        if 矛盾边 is not None:
            if (i, j) == 矛盾边 or (j, i) == 矛盾边:
                J_ij = s
            else:
                J_ij = J
        else:
            J_ij = J
        
        # Build σ_i^x σ_j^x + σ_i^y σ_j^y + σ_i^z σ_j^z
        # For each Pauli: op = I⊗...⊗σ⊗...⊗σ⊗...⊗I
        op_x = _build_two_site_op(N, min(i,j), max(i,j), SX)
        op_y = _build_two_site_op(N, min(i,j), max(i,j), SY)
        op_z = _build_two_site_op(N, min(i,j), max(i,j), SZ)
        
        H += J_ij * (op_x + op_y + op_z)
    
    # Ensure Hermiticity
    H = (H + H.conj().T) / 2
    return H


def build_heisenberg_ultrafast(N, edges, J=1.0, s=1.0,矛盾边=None):
    """
    Ultra-fast: precompute all single-site sigma matrices, then combine.
    Uses the fact that for N=8, dim=256, we can build a lookup table.
    """
    dim = 2**N
    H = np.zeros((dim, dim), dtype=np.complex128)
    
    # Precompute single-site operators for each node and each Pauli
    # op[node][pauli_idx] = full operator matrix
    ops = {}
    for node in range(N):
        ops[(node, 'x')] = _build_single_site_op(N, node, SX)
        ops[(node, 'y')] = _build_single_site_op(N, node, SY)
        ops[(node, 'z')] = _build_single_site_op(N, node, SZ)
    
    for (i, j) in edges:
        if 矛盾边 is not None:
            if (i, j) == 矛盾边 or (j, i) == 矛盾边:
                J_ij = s
            else:
                J_ij = J
        else:
            J_ij = J
        
        H += J_ij * (ops[(i, 'x')] @ ops[(j, 'x')] +
                     ops[(i, 'y')] @ ops[(j, 'y')] +
                     ops[(i, 'z')] @ ops[(j, 'z')])
    
    H = (H + H.conj().T) / 2
    return H


def _build_single_site_op(N, site, sigma):
    """Build full N-site operator with sigma at given site."""
    # Start from sigma, build outward
    # left: sites 0..site-1, right: sites site+1..N-1
    result = sigma.copy()
    
    # Add identities to the right (sites after 'site')
    for _ in range(N - site - 1):
        result = np.kron(result, ID)
    
    # Add identities to the left (sites before 'site')
    for _ in range(site):
        result = np.kron(ID, result)
    
    return result


# ============================================================
# Sparse version for larger N
# ============================================================

def build_heisenberg_sparse_fast(N, edges, J=1.0, s=1.0, 矛盾边=None):
    """
    Sparse Hamiltonian construction. Efficient for N up to ~14.
    """
    dim = 2**N
    # Start with empty COO data
    from scipy.sparse import lil_matrix
    H = lil_matrix((dim, dim), dtype=np.complex128)
    
    # For sparse, we use the fact that σ^x and σ^z are sparse
    # Build action on basis states directly (more efficient)
    
    for (i, j) in edges:
        if 矛盾边 is not None:
            if (i, j) == 矛盾边 or (j, i) == 矛盾边:
                J_ij = s
            else:
                J_ij = J
        else:
            J_ij = J
        
        # For each basis state |α⟩, compute (σ_i^x σ_j^x + σ_i^y σ_j^y + σ_i^z σ_j^z)|α⟩
        # σ^x|α⟩ = |α with bit i flipped⟩ (off-diagonal)
        # σ^y|α⟩ = i(-1)^{α_i} |α with bit i flipped⟩ (off-diagonal, with phase)
        # σ^z|α⟩ = (-1)^{α_i} |α⟩ (diagonal)
        
        for alpha in range(dim):
            # Diagonal part: σ^zσ^z
            zi = (alpha >> i) & 1
            zj = (alpha >> j) & 1
            diag_val = ((-1)**zi) * ((-1)**zj)  # +1 if same, -1 if different
            H[alpha, alpha] += J_ij * diag_val
            
            # Off-diagonal part: σ^xσ^x flips both i and j
            flipped = alpha ^ ((1 << i) | (1 << j))
            H[alpha, flipped] += J_ij * 1.0  # σ^xσ^x gives +1
            
            # σ^yσ^y: flips both with phase i*(-1)^{α_i} * i*(-1)^{α_j} = - (-1)^{α_i+α_j}
            phase = -((-1)**(zi + zj))
            H[alpha, flipped] += J_ij * phase
    
    H = H.tocsr()
    H = (H + H.conj().T) / 2
    return H


if __name__ == '__main__':
    # Benchmark
    N = 8
    edges = [(0,1),(0,2),(0,3),(1,2),(1,4),(2,3),(2,5),(3,6),(4,5),(4,7),(5,6),(6,7)]
    
    for method_name, method in [
        ("Original kron loop", lambda: None),  # too slow
        ("Fast (two-site)", lambda: build_heisenberg_fast(N, edges)),
        ("Ultrafast (lookup)", lambda: build_heisenberg_ultrafast(N, edges)),
        ("Sparse (basis action)", lambda: build_heisenberg_sparse_fast(N, edges)),
    ]:
        if method_name.startswith("Original"):
            continue
        t0 = time.time()
        H = method()
        t1 = time.time()
        print(f"{method_name}: {t1-t0:.4f}s, shape={H.shape}")
        if hasattr(H, 'nnz'):
            print(f"  nnz={H.nnz}")
    
    # Verify correctness: compare fast vs sparse
    H1 = build_heisenberg_ultrafast(N, edges)
    H2 = build_heisenberg_sparse_fast(N, edges)
    diff = np.max(np.abs(H1 - H2.toarray()))
    print(f"\nDense vs Sparse max diff: {diff:.2e}")
    
    # Test with矛盾边
    H3 = build_heisenberg_ultrafast(N, edges, s=2.0, 矛盾边=(2,5))
    H4 = build_heisenberg_sparse_fast(N, edges, s=2.0, 矛盾边=(2,5))
    diff2 = np.max(np.abs(H3 - H4.toarray()))
    print(f"With矛盾边 max diff: {diff2:.2e}")
