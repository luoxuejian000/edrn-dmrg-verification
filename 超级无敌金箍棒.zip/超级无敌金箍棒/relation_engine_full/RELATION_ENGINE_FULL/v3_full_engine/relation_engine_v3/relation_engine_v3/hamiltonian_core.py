#!/usr/bin/env python3
"""
Hamiltonian construction - optimized and verified.
Uses the dense approach with fast Kronecker products for N <= 12.
For N > 12, uses sparse basis-action approach.
"""

import numpy as np
from scipy.sparse import lil_matrix, csr_matrix
import time

# Pauli matrices
_SX = np.array([[0, 1], [1, 0]], dtype=np.complex128)
_SY = np.array([[0, -1j], [1j, 0]], dtype=np.complex128)
_SZ = np.array([[1, 0], [0, -1]], dtype=np.complex128)
_ID = np.array([[1, 0], [0, 1]], dtype=np.complex128)


def _kron_chain(*matrices):
    """Compute Kronecker product of a chain of 2x2 matrices."""
    result = matrices[0]
    for m in matrices[1:]:
        result = np.kron(result, m)
    return result


def build_single_site_op(N, site, sigma):
    """Build full N-qubit operator with 'sigma' at 'site', identity elsewhere.
    site ranges from 0 (leftmost/least significant) to N-1 (rightmost/most significant).
    """
    # Build chain: ID ⊗ ... ⊗ ID ⊗ sigma ⊗ ID ⊗ ... ⊗ ID
    # In our convention: site 0 corresponds to the rightmost bit (least significant)
    # We build left-to-right: sites N-1, N-2, ..., 0
    mats = []
    for s in range(N - 1, -1, -1):
        if s == site:
            mats.append(sigma)
        else:
            mats.append(_ID)
    return _kron_chain(*mats)


def build_two_site_op(N, i, j, sigma_i, sigma_j):
    """Build operator sigma_i ⊗ sigma_j at sites i and j."""
    mats = []
    for s in range(N - 1, -1, -1):
        if s == i:
            mats.append(sigma_i)
        elif s == j:
            mats.append(sigma_j)
        else:
            mats.append(_ID)
    return _kron_chain(*mats)


def build_hamiltonian(N, edges, J=1.0, s=1.0,矛盾边=None, sparse=False):
    """
    Build Heisenberg Hamiltonian: H = Σ J_ij (σ^xσ^x + σ^yσ^y + σ^zσ^z)
    
    Uses precomputed single-site operators for speed.
    For N=8 (dim=256), completes in <0.01s per call.
    For N=10 (dim=1024), completes in ~0.1s per call.
    For N=12 (dim=4096), completes in ~5s per call.
    """
    dim = 2**N
    
    if dim <= 4096 and not sparse:
        # Dense approach
        # Precompute single-site operators
        sx_ops = [build_single_site_op(N, k, _SX) for k in range(N)]
        sy_ops = [build_single_site_op(N, k, _SY) for k in range(N)]
        sz_ops = [build_single_site_op(N, k, _SZ) for k in range(N)]
        
        H = np.zeros((dim, dim), dtype=np.complex128)
        
        for (i, j) in edges:
            if 矛盾边 is not None:
                if (i, j) == 矛盾边 or (j, i) == 矛盾边:
                    J_ij = s
                else:
                    J_ij = J
            else:
                J_ij = J
            
            H += J_ij * (sx_ops[i] @ sx_ops[j] +
                         sy_ops[i] @ sy_ops[j] +
                         sz_ops[i] @ sz_ops[j])
        
        H = (H + H.conj().T) / 2
        return H
    else:
        # Sparse approach: build action on basis states
        return _build_sparse(N, edges, J, s,矛盾边)


def _build_sparse(N, edges, J, s,矛盾边):
    """Sparse Hamiltonian via basis state action."""
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=np.complex128)
    
    for (i, j) in edges:
        if 矛盾边 is not None:
            if (i, j) == 矛盾边 or (j, i) == 矛盾边:
                J_ij = s
            else:
                J_ij = J
        else:
            J_ij = J
        
        for alpha in range(dim):
            zi = (alpha >> i) & 1
            zj = (alpha >> j) & 1
            
            # Diagonal: σ^z_i σ^z_j |α⟩ = (-1)^{α_i + α_j} |α⟩
            diag = 1.0 if (zi == zj) else -1.0
            H[alpha, alpha] += J_ij * diag
            
            # Off-diagonal: σ^x_i σ^x_j flips both bits
            flipped = alpha ^ ((1 << i) | (1 << j))
            H[alpha, flipped] += J_ij * 1.0  # σ^xσ^x contributes +1
            
            # σ^y_i σ^y_j: flips both with phase
            # σ^y|α⟩ = i*(-1)^{α_i} |~α⟩, so σ^y_i σ^y_j|α⟩ = (i)^2 (-1)^{α_i+α_j} |flipped⟩ = -(-1)^{α_i+α_j}
            phase = -1.0 if (zi == zj) else 1.0
            H[alpha, flipped] += J_ij * phase
    
    H = H.tocsr()
    H = (H + H.conj().T) / 2
    return H


if __name__ == '__main__':
    N = 8
    edges = [(0,1),(0,2),(0,3),(1,2),(1,4),(2,3),(2,5),(3,6),(4,5),(4,7),(5,6),(6,7)]
    
    # Time it
    t0 = time.time()
    H = build_hamiltonian(N, edges)
    t1 = time.time()
    print(f"Dense N={N}, dim={2**N}: {t1-t0:.4f}s")
    print(f"H shape: {H.shape}, dtype: {H.dtype}")
    print(f"H Hermitian: {np.allclose(H, H.conj().T)}")
    print(f"H diagonal real: {np.allclose(H.diagonal().imag, 0)}")
    
    # Verify with explicit slow construction
    dim = 256
    H_slow = np.zeros((dim, dim), dtype=np.complex128)
    for (i, j) in edges:
        # Build σ_i^x ⊗ σ_j^x
        op = 1.0 + 0j
        for k in range(N):
            if k == i:
                op = np.kron(op, _SX)
            elif k == j:
                op = np.kron(op, _SX)
            else:
                op = np.kron(op, _ID)
        H_slow += op
        
        op = 1.0 + 0j
        for k in range(N):
            if k == i:
                op = np.kron(op, _SY)
            elif k == j:
                op = np.kron(op, _SY)
            else:
                op = np.kron(op, _ID)
        H_slow += op
        
        op = 1.0 + 0j
        for k in range(N):
            if k == i:
                op = np.kron(op, _SZ)
            elif k == j:
                op = np.kron(op, _SZ)
            else:
                op = np.kron(op, _ID)
        H_slow += op
    
    H_slow = (H_slow + H_slow.conj().T) / 2
    diff = np.max(np.abs(H - H_slow))
    print(f"\nVerification vs slow construction: max diff = {diff:.2e}")
    
    # Test with矛盾边
    H2 = build_hamiltonian(N, edges, s=2.0, 矛盾边=(2,5))
    eigvals1 = np.linalg.eigvalsh(H)
    eigvals2 = np.linalg.eigvalsh(H2)
    print(f"\nUniform J=1: ground state = {eigvals1[0]:.6f}")
    print(f"Edge (2,5) s=2: ground state = {eigvals2[0]:.6f}")
    print(f"Energy gap (uniform): {eigvals1[1]-eigvals1[0]:.6f}")
    
    # Benchmark N=10
    edges_10 = [(i, (i+1)%10) for i in range(10)] + [(i, (i+2)%10) for i in range(5)]
    t0 = time.time()
    H10 = build_hamiltonian(10, edges_10)
    t1 = time.time()
    print(f"\nDense N=10, dim=1024: {t1-t0:.4f}s")
    
    # Benchmark N=12
    edges_12 = [(i, (i+1)%12) for i in range(12)] + [(i, (i+3)%12) for i in range(6)]
    t0 = time.time()
    H12 = build_hamiltonian(12, edges_12)
    t1 = time.time()
    print(f"Dense N=12, dim=4096: {t1-t0:.4f}s")
