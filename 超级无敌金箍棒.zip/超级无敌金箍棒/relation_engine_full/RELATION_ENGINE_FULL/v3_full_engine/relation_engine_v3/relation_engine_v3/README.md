# Relation Structure Analysis Engine v3.0

## 任意图结构 → 海森堡模型 → 全诊断量扫描

### 7 种诊断量

| # | 诊断量 | 物理量 | 揭示什么 |
|---|--------|--------|---------|
| 1 | 增强诊断 | 最近邻 zz 关联标准差 | 沉默失谐（非单调谷值） |
| 2 | 默认诊断 | 平均绝对 zz 关联 | 粗粒度关联强度 |
| 3 | 纠缠熵 | 冯·诺依曼熵 S=-Tr(ρlogρ) | 关系纠缠深度 |
| 4 | 保真度 | |⟨ψ(s)|ψ(s+Δs)⟩|² | 结构脆弱性/敏感性 |
| 5 | 拓扑纠缠熵 | Kitaev-Preskill 方案 | 全局隐形秩序 |
| 6 | 逾渗阈值 | 增强诊断梯度峰值 | 信息传播临界点 |
| 7 | 量子失谐 | 去相干前后纠缠差 | 关联断裂程度 |

### 快速开始

```bash
# 安装依赖
pip install numpy scipy matplotlib pillow

# 运行测试（4种图结构自动测试）
python test_engine.py

# 命令行使用（邻接矩阵输入）
python relation_engine.py --adj-matrix my_graph.json --output-dir results

# 命令行使用（边列表输入）
python relation_engine.py --N 8 --edges edges.json --seeds 5 --method full
```

### 邻接矩阵 JSON 格式

```json
[
  [0, 1, 1, 0],
  [1, 0, 1, 0],
  [1, 1, 0, 1],
  [0, 0, 1, 0]
]
```

### 边列表 JSON 格式

```json
[[0,1], [0,2], [1,2], [2,3]]
```

### 参数说明

| 参数 | 默认值 | 说明 |
|------|--------|------|
| --s-min | 0.0 | 扫描起始值 |
| --s-max | 3.0 | 扫描终止值 |
| --num-points | 61 | 扫描点数 |
| --seeds | 3 | Lanczos 种子数 |
| --method | auto | auto/full/lanczos |
| --output-dir | output | 输出目录 |
| --basic-only | False | 只算基础2种诊断量（更快） |

### 输出文件

| 文件 | 内容 |
|------|------|
| full_data.json | 全部扫描数据（可复现） |
| summary.txt | 人类可读的文字摘要 |
| summary_table.tex | LaTeX 表格（论文直接用） |

### 绘图

```bash
python plot_diagnostics.py --data output/full_data.json --output-dir plots
```

生成 7 张图：
1. `01_full_diagnostics.png` - 6 种诊断量总览
2. `02_percolation.png` - 逾渗阈值分析
3. `03_energy_gap.png` - 能隙扫描
4. `04_radar_summary.png` - 雷达图汇总
5. `05_valley_depth.png` - 沉默失谐深度排序
6. `06_enhanced_vs_default.png` - 增强 vs 默认逐边对比
7. `07_fidelity_gap_joint.png` - 保真度+能隙联合

### 方法论声明（论文用）

> "The relation structure analysis engine v3.0 extracts graph topology from
> arbitrary inputs (paintings, music networks, social graphs) and maps it to
> an isotropic Heisenberg model. All scans use uniform parameters (s∈[0,3],
> 61 points, 3-5 Lanczos seeds). For N≤12, exact diagonalization (numpy.linalg.eigh)
> is used; for larger N, Lanczos iteration (scipy.sparse.linalg.eigsh) is employed.
> Cross-validation between methods shows agreement within ~1e-14."

### 理论定位

本工具不是"用量子力学解释艺术"，而是"用海森堡模型作为关系结构分析的通用数学引擎"。
画作/音乐/网络本身不具有量子性质，它们提供的是**拓扑结构**——节点和边的邻接关系。
在这个拓扑上运行量子多体物理的诊断工具，可以揭示关系重组的普适特征。

### 路线图

- [x] Phase 1: 测图模块（自动分割 + 手动建图 + 7种诊断量）
- [ ] Phase 2: 音乐模块（MIDI → 音符图 → 沉默失谐）
- [ ] Phase 3: 文学/文本模块（词语共现网络）
- [ ] Phase 4: 通用图接口（社交/生物/经济网络）
- [ ] Phase 5: 软件产品化（GUI/Web/Docker）
- [ ] Phase 6: DMRG 后端（支持 N>20 的大图）
