#!/usr/bin/env python3
"""
Test Suite for Relation Engine v3.0
测试三种图结构: 模拟画作拓扑 / 分形图 L2 / 小世界图
"""

import sys
import os
import json
import time

sys.path.insert(0, os.path.dirname(__file__))
from relation_engine import run_analysis, build_graph_from_adjacency


def test_1_simulated_painting():
    """测试1: 模拟立体主义画作拓扑（类似毕加索《阅读》）"""
    print("\n" + "=" * 60)
    print("TEST 1: 模拟立体主义画作拓扑 (N=10)")
    print("=" * 60)
    
    N = 10
    edges = [
        (0, 1), (0, 2), (0, 3),
        (1, 2), (1, 4),
        (2, 3), (2, 5),
        (3, 6),
        (4, 5), (4, 7),
        (5, 6), (6, 7),
        (3, 5), (1, 7),
    ]
    
    # N=10, dim=1024, 用 Lanczos
    summary = run_analysis(
        N=N, edges=edges,
        s_min=0, s_max=3, num_points=21,
        seeds=3, method='lanczos', use_sparse=True,
        output_dir='test_output/painting',
        compute_full_diagnostics=True,
    )
    return summary


def test_2_fractal_L2():
    """测试2: 分形图 L2（论文验证, N=8, dim=256）"""
    print("\n" + "=" * 60)
    print("TEST 2: 分形图 L2 (N=8, 论文验证)")
    print("=" * 60)
    
    N = 8
    edges = [
        (0, 1), (0, 2), (0, 3),
        (1, 2), (1, 4),
        (2, 3), (2, 5),
        (3, 6),
        (4, 5), (4, 7),
        (5, 6), (6, 7),
    ]
    
    summary = run_analysis(
        N=N, edges=edges,
        s_min=0, s_max=3, num_points=31,
        seeds=5, method='full',
        output_dir='test_output/fractal_L2',
        compute_full_diagnostics=True,
    )
    return summary


def test_3_small_world():
    """测试3: Watts-Strogatz 小世界图"""
    print("\n" + "=" * 60)
    print("TEST 3: Watts-Strogatz 小世界图 (N=10)")
    print("=" * 60)
    
    import numpy as np
    N = 10
    k = 4
    p = 0.3
    np.random.seed(42)
    
    edges_set = set()
    for i in range(N):
        for j in range(1, k//2 + 1):
            j_node = (i + j) % N
            edges_set.add(tuple(sorted([i, j_node])))
    
    edges_list = list(edges_set)
    for idx_edge, (i, j) in enumerate(edges_list):
        if np.random.random() < p:
            new_j = np.random.randint(0, N)
            if new_j != i and tuple(sorted([i, new_j])) not in edges_set:
                edges_set.remove((i, j))
                edges_set.add(tuple(sorted([i, new_j])))
    
    edges = [tuple(e) for e in edges_set]
    
    summary = run_analysis(
        N=N, edges=edges,
        s_min=0, s_max=3, num_points=21,
        seeds=3, method='lanczos', use_sparse=True,
        output_dir='test_output/small_world',
        compute_full_diagnostics=True,
    )
    return summary


def test_4_adjacency_input():
    """测试4: 从邻接矩阵 JSON 输入"""
    print("\n" + "=" * 60)
    print("TEST 4: 邻接矩阵 JSON 输入 (N=6)")
    print("=" * 60)
    
    adj = [
        [0, 1, 1, 0, 0, 0],
        [1, 0, 1, 1, 0, 0],
        [1, 1, 0, 0, 1, 0],
        [0, 1, 0, 0, 1, 1],
        [0, 0, 1, 1, 0, 1],
        [0, 0, 0, 1, 1, 0],
    ]
    
    os.makedirs('test_output', exist_ok=True)
    with open('test_output/test_adj.json', 'w') as f:
        json.dump(adj, f)
    
    N, edges = build_graph_from_adjacency(adj)
    print(f"从邻接矩阵加载: N={N}, edges={edges}")
    
    summary = run_analysis(
        N=N, edges=edges,
        s_min=0, s_max=2, num_points=21,
        seeds=3, method='full',
        output_dir='test_output/adj_test',
        compute_full_diagnostics=True,
    )
    return summary


def run_all_tests():
    """运行全部测试"""
    print("=" * 60)
    print("RELATION STRUCTURE ANALYSIS ENGINE v3.0")
    print("完整测试套件")
    print("=" * 60)
    
    start_time = time.time()
    results = {}
    
    try:
        results['fractal_L2'] = test_2_fractal_L2()    # 最快的先跑 (N=8)
        results['adj_input'] = test_4_adjacency_input()  # N=6, 很小
        results['painting'] = test_1_simulated_painting()  # N=10, sparse
        results['small_world'] = test_3_small_world()     # N=10, sparse
    except Exception as e:
        print(f"\n❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return
    
    total_time = time.time() - start_time
    
    # 跨测试汇总
    print("\n" + "=" * 60)
    print("CROSS-TEST SUMMARY")
    print("=" * 60)
    header = f"{'测试':<18} {'N':>3} {'边':>3} {'沉默失谐':>8} {'纠缠熵':>8} {'保真度':>8} {'拓扑EE':>8} {'失谐':>8}"
    print(header)
    print("-" * 70)
    
    for name, s in results.items():
        sd = s['silence_dissonance']
        ent = s['entanglement']
        fc = s['fidelity_collapse']
        topo = s['topological_order']
        qd = s['quantum_discord']
        
        valley_info = f"{sd['edges_with_valleys']}/{sd['total_edges']}"
        print(f"{name:<18} {s['graph_info']['N']:>3} {s['graph_info']['num_edges']:>3} "
              f"{valley_info:>8} {ent['max_entanglement_value']:>8.3f} "
              f"{fc['min_fidelity']:>8.3f} {topo['max_topo_ee_value']:>8.3f} "
              f"{qd['max_discord_value']:>8.3f}")
    
    print(f"\n总测试耗时: {total_time:.1f}s")
    print(f"测试数量: {len(results)}/4 通过")
    
    with open('test_output/cross_test_summary.json', 'w') as f:
        json.dump({
            'total_time': total_time,
            'tests_passed': len(results),
            'results': results,
        }, f, indent=2)
    
    print("\n✅ 全部测试完成！")
    print("📁 输出目录: test_output/")
    for d in ['painting', 'fractal_L2', 'small_world', 'adj_test']:
        print(f"   - {d}/")


if __name__ == '__main__':
    run_all_tests()
