# 关系结构分析引擎 · 测图模块 v2.0

> 将任意画作/图片表示为量子图，用海森堡模型探测"沉默失谐"现象

## 文件清单

| 文件 | 说明 |
|------|------|
| `art_graph_v2.py` | 主脚本：图像分割 → 拓扑构建 → 全边扫描 → 统计分析 |
| `plot_art_graph_v2.py` | 绘图脚本：6 张图（拓扑/全扫描/汇总/对比/精细审计/交叉验证） |
| `test_art_v2.py` | 端到端测试套件（6 项测试） |
| `ROADMAP.md` | 产品路线图（测图→音乐→文学→通用→产品化） |
| `README_v2.md` | 本说明文件 |

## 快速开始

```bash
# 1. 安装依赖
pip install numpy scipy opencv-python-headless scikit-image matplotlib pillow

# 2. 自动分割模式（推荐先试这个）
python art_graph_v2.py --image your_painting.jpg --n-segments 8

# 3. 手动建图模式（跳过分割，直接给邻接矩阵）
python art_graph_v2.py --adj-matrix my_graph.csv

# 4. 绘图
python plot_art_graph_v2.py --data art_graph_output/full_data.json
```

## 参数说明

### 输入（二选一）
| 参数 | 说明 |
|------|------|
| `--image` | 图片路径 (jpg/png/bmp/...) |
| `--adj-matrix` | 手动邻接矩阵 (CSV 邻接矩阵/边列表, 或 JSON) |

### 分割参数
| 参数 | 默认值 | 说明 |
|------|--------|------|
| `--n-segments` | 8 | 超像素数量（色块数） |
| `--seg-method` | slic | 分割算法: `slic` / `felzenszwalb` / `watershed` |
| `--compactness` | 10 | SLIC 紧致度（越大色块越规整） |
| `--adj-method` | delaunay | 邻接构建: `delaunay` / `distance` / `knn` |
| `--max-edge-frac` | 0.35 | 最大边长度（占图像对角线比例） |

### 扫描参数
| 参数 | 默认值 | 说明 |
|------|--------|------|
| `--s-min` / `--s-max` | 0 / 3 | 矛盾边强度扫描范围 |
| `--step` | 0.05 | s 步长 |
| `--n-seeds` | 3 | Lanczos 种子数（多种子审计） |

### 高级选项
| 参数 | 说明 |
|------|------|
| `--fine-audit` | 启用精细审计（Top-N 边自动缩小步长重扫） |
| `--top-n` | 精细审计的边数（默认 3） |
| `--fine-step` | 精细审计步长（默认 0.005） |
| `--cross-validate` | 启用交叉验证（Lanczos vs Full ED） |
| `--backend` | 计算后端: `auto` / `lanczos` / `full` |

### 输出
| 参数 | 默认值 | 说明 |
|------|--------|------|
| `--output-dir` | art_graph_output | 输出目录 |

## 输出文件

| 文件 | 说明 |
|------|------|
| `full_data.json` | 完整数据（s 扫描 × N 边 × M 种子） |
| `summary.txt` | 文本汇总表 |
| `table_diagnostics.tex` | 论文级 LaTeX 表格 |
| `01_topology.png` | 拓扑结构图（节点=色块，边=邻接） |
| `02_all_edges.png` | 所有边增强诊断扫描曲线 |
| `03_summary.png` | 汇总对比图（极差柱状图 + 谷位置 + 能隙热力图） |
| `04_enhanced_vs_default.png` | Top 边增强诊断 vs 默认诊断 |
| `05_fine_audit.png` | 精细审计结果（仅 --fine-audit 时） |
| `06_cross_validation.png` | 交叉验证结果（仅 --cross-validate 时） |

## 物理原理

```
画作/图片 → 色块分割 → 邻接图 G=(V,E) → 海森堡模型
  H = Σ J_ij (σ^xσ^x + σ^yσ^y + σ^zσ^z)
       ↓
  精确对角化（Lanczos / Full ED）
       ↓
  增强诊断 E(s) = std(⟨σ^z_i σ^z_j⟩)   ← 细粒度
  默认诊断 D(s) = mean(|⟨σ^z_i σ^z_j⟩|)  ← 粗粒度
       ↓
  沉默失谐检测：E(s) 出现非单调谷值 & D(s) 平滑 → 关系重组信号
```

## 手动建图格式

### CSV 邻接矩阵
```
0,1,0,1,0
1,0,1,0,0
0,1,0,1,0
1,0,1,0,1
0,0,0,1,0
```

### CSV 边列表
```
0,1
1,2
0,3
2,3
3,4
```

### JSON
```json
{
  "n_nodes": 5,
  "edges": [[0,1],[1,2],[0,3],[2,3],[3,4]],
  "centers": [[0.2,0.3],[0.5,0.2],[0.7,0.6],[0.3,0.7],[0.6,0.8]],
  "colors": [[200,50,50],[50,200,50],[50,50,200],[200,200,50],[200,50,200]]
}
```

## 测试

```bash
python test_art_v2.py
```

包含 6 项测试：
1. 自动分割模式（SLIC + Delaunay）
2. 手动建图模式（CSV 邻接矩阵）
3. 多种分割算法对比（SLIC vs Felzenszwalb）
4. 多种邻接构建方法（Delaunay vs Distance vs KNN）
5. LaTeX 表格导出
6. 交叉验证精度（Lanczos vs Full ED，差异 < 1e-14）

## 计算规模参考

| 节点数 N | Hilbert 维度 | 推荐后端 | 预估耗时（5边×61点×3种子） |
|---------|-------------|---------|---------------------------|
| 5 | 32 | Lanczos | ~10s |
| 8 | 256 | Lanczos | ~30s |
| 10 | 1024 | Lanczos | ~2min |
| 12 | 4096 | Lanczos/Full | ~5min |
| 15 | 32768 | Lanczos only | ~15min |
| 20 | 1048576 | Lanczos only | ~2h（需优化） |

## 路线图

详见 `ROADMAP.md`，核心路径：
- **Phase 1**（当前）：测图模块打磨到可发布 ✅
- **Phase 2**：音乐模块（MIDI/音频 → 图 → 沉默失谐）
- **Phase 3**：文学/文本模块（词语共现网络）
- **Phase 4**：通用图接口（社交/生物/经济网络）
- **Phase 5**：软件产品化（GUI/Web）

## 论文引用建议

> "The automated graph extraction pipeline was independently implemented
> based on the methodology described in this paper. Core physical
> computations (Hamiltonian construction, Lanczos/ED diagonalization,
> enhanced/default diagnosis) follow the same procedures as the main text.
> For images with gradient-based painting techniques (e.g., sfumato),
> topological adjacency was constructed manually with human verification."
