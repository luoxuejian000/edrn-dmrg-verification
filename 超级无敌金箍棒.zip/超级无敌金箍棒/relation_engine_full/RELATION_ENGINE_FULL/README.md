# 关系结构分析引擎 · 完整交付包

> 任意图结构 → 海森堡模型 → 全诊断量扫描

## 版本演进

### v1.0 — 绘画图专用版 (v1_painting/)
- 输入：图片 → SLIC 超像素分割 → 邻接图
- 诊断量：增强诊断（沉默失谐）+ 默认诊断
- 输出：6 张图 + JSON 数据 + 文本摘要
- 适合：色块分明的画作（立体主义、几何抽象、平面设计）

### v2.0 — 艺术图增强版 (v2_art_graph/)
- 三种分割算法：SLIC / Felzenszwalb / Watershed
- 三种邻接构建：Delaunay / Distance / KNN
- 手动建图模式（CSV/JSON 邻接矩阵，跳过分割）
- 精细审计（Top-N 边自动缩小步长）
- 交叉验证（Lanczos vs Full ED，差异 ~1e-14）
- LaTeX 表格导出
- 文件：`relation_engine_v2.zip`（含 art_graph_v2.py + plot_art_graph_v2.py + test_art_v2.py + ROADMAP.md）

### v3.0 — 全诊断量通用引擎 (v3_full_engine/)
- 支持任意图输入（邻接矩阵 / 边列表 / JSON）
- **7 种诊断量**：
  1. 增强诊断 → 沉默失谐
  2. 默认诊断 → 粗粒度关联
  3. 纠缠熵 → 关系纠缠深度
  4. 保真度 → 结构脆弱性
  5. 拓扑纠缠熵 → 全局隐形秩序
  6. 逾渗阈值 → 信息传播临界点
  7. 量子失谐 → 关联断裂程度
- 自动后端切换：N≤12 Full ED，N>12 Lanczos
- 文件：`relation_engine_v3.zip`（含 relation_engine.py + hamiltonian_core.py + fast_hamiltonian.py + plot_diagnostics.py + test_engine.py）

## 快速开始

### v3.0 一键测试（推荐先跑这个）
```bash
pip install numpy scipy matplotlib pillow
unzip relation_engine_v3.zip -d engine/
cd engine
python test_engine.py
```

### v2.0 测图（传入图片）
```bash
pip install numpy scipy opencv-python-headless scikit-image matplotlib pillow
unzip relation_engine_v2.zip -d art/
cd art
python art_graph_v2.py --image your_painting.jpg --n-segments 8 --fine-audit --cross-validate
```

## 参数统一说明

| 参数 | 默认值 | 说明 |
|------|--------|------|
| s-min / s-max | 0 / 3 | 矛盾边耦合扫描范围 |
| num-points / step | 61 / 0.05 | 扫描点数或步长 |
| seeds | 3 | Lanczos 种子数（多种子审计） |
| method | auto | auto / full / lanczos |
| output-dir | output | 输出目录 |

## 路线图

- [x] Phase 1: 测图模块（v1.0 → v2.0 已完成）
- [x] Phase 1.5: 全诊断量通用引擎（v3.0 已完成）
- [ ] Phase 2: 音乐模块（MIDI → 音符图 → 沉默失谐）
- [ ] Phase 3: 文学/文本模块（词语共现网络）
- [ ] Phase 4: 通用图接口（社交/生物/经济网络）
- [ ] Phase 5: 软件产品化（GUI/Web/Docker）
- [ ] Phase 6: DMRG 后端（支持 N>20 的大图）

## 论文引用建议

> "The relation structure analysis engine v3.0 extracts graph topology from
> arbitrary inputs and maps it to an isotropic Heisenberg model. All scans use
> uniform parameters (s∈[0,3], 61 points, 3-5 Lanczos seeds). For N≤12, exact
> diagonalization (numpy.linalg.eigh) is used; for larger N, Lanczos iteration
> (scipy.sparse.linalg.eigsh) is employed. Cross-validation between methods
> shows agreement within ~1e-14."

## 理论定位

本工具不是"用量子力学解释艺术"，而是"用海森堡模型作为关系结构分析的通用数学引擎"。
画作/音乐/网络本身不具有量子性质，它们提供的是**拓扑结构**——节点和边的邻接关系。
在这个拓扑上运行量子多体物理的诊断工具，可以揭示关系重组的普适特征。
