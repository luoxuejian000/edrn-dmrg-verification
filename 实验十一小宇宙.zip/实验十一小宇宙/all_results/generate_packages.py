with open('generate_packages.py', 'w', encoding='utf-8') as f: f.write(''' 
