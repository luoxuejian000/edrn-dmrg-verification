"""
独立实验：chain_ising
直接运行: python run.py
"""
import sys, os, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from custom_universe import build_graph, introduce_contradiction, diagnose, coarse_diagnosis, fine_diagnosis

name = 'chain_ising'
graph_type = 'chain'
N = 6
rule = 'ising'

print(f"=== 实验：{name} ===")

G = build_graph(graph_type, N)
edge = (0, 1) if G.has_edge(0, 1) else list(G.edges())[0]
strengths = np.linspace(0.0, 3.0, 9)

gaps, coarse_vals, fine_vals, audit_gaps = [], [], [], []
for s in strengths:
    G_mod = introduce_contradiction(G, edge, s)
    _, gap, gs = diagnose(G_mod, rule=rule, delta=1.0, num_eig=5)
    coarse = coarse_diagnosis(N, gs)
    fine = fine_diagnosis(G_mod, gs)
    _, gap2, _ = diagnose(G_mod, rule=rule, delta=1.0, num_eig=6)
    gaps.append(gap); coarse_vals.append(coarse); fine_vals.append(fine)
    audit_gaps.append(abs(gap - gap2))
    print(f"  s={s:.2f}: gap={gap:.4f}, coarse={coarse:.4f}, fine={fine:.4f}")

np.savetxt(f'{name}.csv', np.column_stack((strengths, gaps, coarse_vals, fine_vals, audit_gaps)),
           header='strength,gap,coarse,fine,audit_gap_diff', delimiter=',', comments='')

fig, ax1 = plt.subplots(figsize=(10,6))
ax1.plot(strengths, coarse_vals, 'o-', color='#1f77b4', label='Coarse Diagnosis')
ax2 = ax1.twinx()
ax2.plot(strengths, fine_vals, 's-', color='#d62728', label='Fine Diagnosis')
ax1.set_xlabel('Contradiction Strength'); ax1.set_ylabel('Coarse Metric')
ax2.set_ylabel('Fine Metric'); ax1.legend(loc='upper left'); ax2.legend(loc='upper right')
plt.title(name)
plt.tight_layout()
plt.savefig(f'{name}.png', dpi=150)
print(f"完成。数据: {name}.csv, 图表: {name}.png")
