"""
自定义宇宙规则 —— 纯粹探索玩具
从关系图和生成规则编译量子多体系统，探索规则本身对物理的塑造。
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import networkx as nx

# =============================================
# 公理一：关系图生成
# =============================================
def build_graph(graph_type, N, **kwargs):
    if graph_type == 'chain':
        G = nx.Graph()
        G.add_nodes_from(range(N))
        for i in range(N-1):
            G.add_edge(i, i+1, weight=1.0)
        return G
    elif graph_type == 'star':
        G = nx.star_graph(N-1)
        for u, v in G.edges(): G[u][v]['weight'] = 1.0
        return G
    elif graph_type == 'ring':
        G = nx.cycle_graph(N)
        for u, v in G.edges(): G[u][v]['weight'] = 1.0
        return G
    elif graph_type == 'small_world':
        k = kwargs.get('k', 4)
        p = kwargs.get('p', 0.1)
        G = nx.watts_strogatz_graph(N, k, p)
        for u, v in G.edges(): G[u][v]['weight'] = 1.0
        return G
    else:
        raise ValueError(f"Unknown graph type: {graph_type}")

# =============================================
# 公理一（续）：多规则哈密顿量编译（内存安全版）
# =============================================
def graph_to_hamiltonian_sparse(G, rule='heisenberg', delta=1.0):
    """
    关系图编译为量子哈密顿量。
    rule: 'heisenberg' (XX+YY+ZZ), 'ising' (ZZ), 'xy' (XX+YY), 'xxz' (XX+YY+Δ*ZZ)
    """
    N = G.number_of_nodes()
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    for i, j, w in G.edges(data='weight'):
        w = w if w else 1.0
        for state in range(dim):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            flipped = state ^ (1 << i) ^ (1 << j)
            if rule in ['heisenberg', 'xy', 'xxz']:
                # XX+YY 项
                H[state, flipped] += w
            if rule in ['heisenberg', 'ising', 'xxz']:
                # ZZ 项
                zz_factor = delta if rule == 'xxz' else 1.0
                if bit_i == bit_j:
                    H[state, state] += w * zz_factor
                else:
                    H[state, state] -= w * zz_factor
    return H.tocsc()

# =============================================
# 公理二：矛盾动力论 —— 植入矛盾边
# =============================================
def introduce_contradiction(G, edge, strength):
    G_mod = G.copy()
    if G_mod.has_edge(*edge):
        G_mod[edge[0]][edge[1]]['weight'] = strength
    else:
        G_mod.add_edge(edge[0], edge[1], weight=strength)
    return G_mod

# =============================================
# 公理三：实践介入论 —— 粗粒化与精细诊断
# =============================================
def diagnose(G, rule='heisenberg', delta=1.0, num_eig=5):
    H = graph_to_hamiltonian_sparse(G, rule=rule, delta=delta)
    N = G.number_of_nodes()
    energies, states = eigsh(H, k=min(num_eig, 2**N-1), which='SA')
    gap = energies[1] - energies[0] if len(energies) > 1 else np.nan
    return energies, gap, states[:, 0]

def coarse_diagnosis(N, gs):
    mag = 0.0
    dim = len(gs)
    for state in range(dim):
        prob = np.abs(gs[state])**2
        bits = [(state >> k) & 1 for k in range(N)]
        magnetization = sum(1 - 2*b for b in bits)
        mag += prob * magnetization
    return abs(mag / N)

def fine_diagnosis(G, gs):
    N = G.number_of_nodes()
    dim = len(gs)
    corrs = []
    for i, j in G.edges():
        corr = 0.0
        for state in range(dim):
            prob = np.abs(gs[state])**2
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            corr += prob * (1 - 2*bit_i) * (1 - 2*bit_j)
        corrs.append(corr)
    return np.std(corrs) if corrs else 0.0

# =============================================
# 公理四 & 五：谐振调谐 + 元反思审计 + 探索入口
# =============================================
def explore_custom(graph_type='chain', N=6, rule='heisenberg', delta=1.0,
                   contradiction_edge=None, strengths=None):
    """纯粹探索：在自定义宇宙中扫描矛盾强度"""
    print(f"=== 自定义宇宙探索 ===")
    print(f"关系图: {graph_type}, N={N}, 生成规则: {rule}", end='')
    if rule == 'xxz':
        print(f" (Δ={delta})")
    else:
        print()
    G = build_graph(graph_type, N)
    print(f"边数: {G.number_of_edges()}, 维度: {2**N}")

    if contradiction_edge is None:
        contradiction_edge = (0, 1) if G.has_edge(0, 1) else list(G.edges())[0]
    if strengths is None:
        strengths = np.linspace(0.0, 3.0, 9)

    gaps, coarse_vals, fine_vals = [], [], []
    audit_gaps = []

    print("矛盾强度扫描 (无预设目标)...")
    for s in strengths:
        G_mod = introduce_contradiction(G, contradiction_edge, s)
        _, gap, gs = diagnose(G_mod, rule=rule, delta=delta, num_eig=5)
        coarse = coarse_diagnosis(N, gs)
        fine = fine_diagnosis(G_mod, gs)

        gaps.append(gap)
        coarse_vals.append(coarse)
        fine_vals.append(fine)

        # 元反思审计
        _, gap2, _ = diagnose(G_mod, rule=rule, delta=delta, num_eig=6)
        audit_gaps.append(abs(gap - gap2))

        print(f"  s={s:.2f}: gap={gap:.4f}, coarse={coarse:.4f}, fine={fine:.4f}, audit={audit_gaps[-1]:.6f}")

    # 保存数据
    np.savetxt('custom_universe_explore.csv',
               np.column_stack((strengths, gaps, coarse_vals, fine_vals, audit_gaps)),
               header='strength,gap,coarse,fine,audit_gap_diff', delimiter=',')

    # 可视化
    fig, ax1 = plt.subplots(figsize=(10,6))
    ax1.plot(strengths, coarse_vals, 'o-', color='#1f77b4', label='Coarse Diagnosis')
    ax2 = ax1.twinx()
    ax2.plot(strengths, fine_vals, 's-', color='#d62728', label='Fine Diagnosis')
    ax1.set_xlabel('Contradiction Strength'); ax1.set_ylabel('Coarse Metric')
    ax2.set_ylabel('Fine Metric'); ax1.legend(loc='upper left'); ax2.legend(loc='upper right')
    plt.title(f'Custom Universe: {graph_type} N={N} rule={rule}')
    plt.tight_layout()
    plt.savefig('custom_universe_explore.png', dpi=150)
    print("探索数据已保存至 custom_universe_explore.csv 和 custom_universe_explore.png")

if __name__ == "__main__":
    # 默认：链式图 + Heisenberg 规则
    explore_custom(graph_type='chain', N=6, rule='heisenberg')