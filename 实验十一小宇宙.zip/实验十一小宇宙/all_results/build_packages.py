"""
一键生成所有独立实验包
每个实验包包含：专属 run.py 脚本 + 对应 CSV 数据 + PNG 图表
"""
import os
import shutil

# 六个实验的配置
experiments = [
    {'name': 'chain_heisenberg',   'graph_type': 'chain',       'N': 6, 'rule': 'heisenberg'},
    {'name': 'chain_ising',        'graph_type': 'chain',       'N': 6, 'rule': 'ising'},
    {'name': 'chain_xy',           'graph_type': 'chain',       'N': 6, 'rule': 'xy'},
    {'name': 'smallworld_heisenberg', 'graph_type': 'small_world', 'N': 6, 'rule': 'heisenberg', 'seed': 42},
    {'name': 'smallworld_ising',      'graph_type': 'small_world', 'N': 6, 'rule': 'ising',      'seed': 42},
    {'name': 'smallworld_xy',         'graph_type': 'small_world', 'N': 6, 'rule': 'xy',         'seed': 42},
]

# run.py 的模板
script_template = '''"""
独立实验：{name}
直接运行: python run.py
"""
import sys, os, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# 确保能找到 custom_universe.py
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))

from custom_universe import build_graph, introduce_contradiction, diagnose, coarse_diagnosis, fine_diagnosis

name = '{name}'
graph_type = '{graph_type}'
N = {N}
rule = '{rule}'

print(f"=== 实验：{{name}} ===")

# 构建关系图
{seed_lines}
G = build_graph(graph_type, N{seed_arg})
edge = (0, 1) if G.has_edge(0, 1) else list(G.edges())[0]
strengths = np.linspace(0.0, 3.0, 9)

gaps, coarse_vals, fine_vals, audit_gaps = [], [], [], []
for s in strengths:
    G_mod = introduce_contradiction(G, edge, s)
    _, gap, gs = diagnose(G_mod, rule=rule, delta=1.0, num_eig=5)
    coarse = coarse_diagnosis(N, gs)
    fine = fine_diagnosis(G_mod, gs)
    _, gap2, _ = diagnose(G_mod, rule=rule, delta=1.0, num_eig=6)
    gaps.append(gap); coarse_vals.append(coarse); fine_vals.append(fine)
    audit_gaps.append(abs(gap - gap2))
    print(f"  s={{s:.2f}}: gap={{gap:.4f}}, coarse={{coarse:.4f}}, fine={{fine:.4f}}")

# 保存 CSV
np.savetxt(f'{{name}}.csv', np.column_stack((strengths, gaps, coarse_vals, fine_vals, audit_gaps)),
           header='strength,gap,coarse,fine,audit_gap_diff', delimiter=',', comments='')

# 保存 PNG
fig, ax1 = plt.subplots(figsize=(10,6))
ax1.plot(strengths, coarse_vals, 'o-', color='#1f77b4', label='Coarse Diagnosis')
ax2 = ax1.twinx()
ax2.plot(strengths, fine_vals, 's-', color='#d62728', label='Fine Diagnosis')
ax1.set_xlabel('Contradiction Strength'); ax1.set_ylabel('Coarse Metric')
ax2.set_ylabel('Fine Metric'); ax1.legend(loc='upper left'); ax2.legend(loc='upper right')
plt.title(name)
plt.tight_layout()
plt.savefig(f'{{name}}.png', dpi=150)
print(f"完成。数据: {{name}}.csv, 图表: {{name}}.png")
'''

# 开始创建
for exp in experiments:
    name = exp['name']
    folder = os.path.join(os.getcwd(), name)
    os.makedirs(folder, exist_ok=True)

    # 处理随机种子（仅小世界图需要）
    if 'seed' in exp:
        seed_lines = f"import networkx as nx\nnp.random.seed({exp['seed']})"
        seed_arg = ''
    else:
        seed_lines = ''
        seed_arg = ''

    # 填充模板
    code = script_template.format(
        name=name,
        graph_type=exp['graph_type'],
        N=exp['N'],
        rule=exp['rule'],
        seed_lines=seed_lines,
        seed_arg=seed_arg
    )

    # 写入 run.py
    with open(os.path.join(folder, 'run.py'), 'w', encoding='utf-8') as f:
        f.write(code)

    # 复制已有的 CSV 和 PNG
    for ext in ['.csv', '.png']:
        src = os.path.join(os.getcwd(), f'{name}{ext}')
        if os.path.exists(src):
            shutil.copy(src, os.path.join(folder, f'{name}{ext}'))

    print(f'✓ 实验包已生成: {folder}')

print('\n全部完成！每个子文件夹内都有独立的 run.py，可直接运行。')