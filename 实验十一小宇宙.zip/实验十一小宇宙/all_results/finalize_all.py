"""
最终整理脚本：重跑所有实验，生成完全自包含的独立实验包。
每个包文件夹包含：custom_universe.py, run.py, 数据.csv, 图表.png
"""
import os
import shutil
import sys

# 确保能导入 custom_universe.py（从上级目录或当前目录）
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from custom_universe import (
    build_graph, introduce_contradiction, diagnose,
    coarse_diagnosis, fine_diagnosis
)
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# 六个实验的配置
experiments = [
    {'name': 'chain_heisenberg',   'graph_type': 'chain',       'N': 6, 'rule': 'heisenberg'},
    {'name': 'chain_ising',        'graph_type': 'chain',       'N': 6, 'rule': 'ising'},
    {'name': 'chain_xy',           'graph_type': 'chain',       'N': 6, 'rule': 'xy'},
    {'name': 'smallworld_heisenberg', 'graph_type': 'small_world', 'N': 6, 'rule': 'heisenberg', 'seed': 42},
    {'name': 'smallworld_ising',      'graph_type': 'small_world', 'N': 6, 'rule': 'ising',      'seed': 42},
    {'name': 'smallworld_xy',         'graph_type': 'small_world', 'N': 6, 'rule': 'xy',         'seed': 42},
]

# 创建全新的输出根目录
final_dir = os.path.join(current_dir, 'final_packages')
os.makedirs(final_dir, exist_ok=True)

# run.py 模板
run_script_template = '''"""
独立实验：{name}
直接运行: python run.py
"""
import sys, os, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from custom_universe import build_graph, introduce_contradiction, diagnose, coarse_diagnosis, fine_diagnosis

name = '{name}'
graph_type = '{graph_type}'
N = {N}
rule = '{rule}'

print(f"=== 实验：{{name}} ===")
{seed_lines}
G = build_graph(graph_type, N{seed_arg})
edge = (0, 1) if G.has_edge(0, 1) else list(G.edges())[0]
strengths = np.linspace(0.0, 3.0, 9)

gaps, coarse_vals, fine_vals, audit_gaps = [], [], [], []
for s in strengths:
    G_mod = introduce_contradiction(G, edge, s)
    _, gap, gs = diagnose(G_mod, rule=rule, delta=1.0, num_eig=5)
    coarse = coarse_diagnosis(N, gs)
    fine = fine_diagnosis(G_mod, gs)
    _, gap2, _ = diagnose(G_mod, rule=rule, delta=1.0, num_eig=6)
    gaps.append(gap); coarse_vals.append(coarse); fine_vals.append(fine)
    audit_gaps.append(abs(gap - gap2))
    print(f"  s={{s:.2f}}: gap={{gap:.4f}}, coarse={{coarse:.4f}}, fine={{fine:.4f}}")

np.savetxt(f'{{name}}.csv', np.column_stack((strengths, gaps, coarse_vals, fine_vals, audit_gaps)),
           header='strength,gap,coarse,fine,audit_gap_diff', delimiter=',', comments='')

fig, ax1 = plt.subplots(figsize=(10,6))
ax1.plot(strengths, coarse_vals, 'o-', color='#1f77b4', label='Coarse Diagnosis')
ax2 = ax1.twinx()
ax2.plot(strengths, fine_vals, 's-', color='#d62728', label='Fine Diagnosis')
ax1.set_xlabel('Contradiction Strength'); ax1.set_ylabel('Coarse Metric')
ax2.set_ylabel('Fine Metric'); ax1.legend(loc='upper left'); ax2.legend(loc='upper right')
plt.title(name)
plt.tight_layout()
plt.savefig(f'{{name}}.png', dpi=150)
print(f"完成。数据: {{name}}.csv, 图表: {{name}}.png")
'''

for exp in experiments:
    name = exp['name']
    print(f"\n====== 重跑：{name} ======")

    # 创建独立文件夹
    pkg_folder = os.path.join(final_dir, name)
    os.makedirs(pkg_folder, exist_ok=True)

    # 1. 复制核心引擎 custom_universe.py
    src_engine = os.path.join(current_dir, 'custom_universe.py')
    if os.path.exists(src_engine):
        shutil.copy(src_engine, pkg_folder)
    else:
        # 尝试从上级目录找
        src_engine2 = os.path.join(parent_dir, 'custom_universe.py')
        if os.path.exists(src_engine2):
            shutil.copy(src_engine2, pkg_folder)

    # 2. 准备随机种子（如有）
    if 'seed' in exp:
        np.random.seed(exp['seed'])
        seed_code = 'np.random.seed({})'.format(exp['seed'])
    else:
        seed_code = ''

    # 3. 生成 run.py
    run_code = run_script_template.format(
        name=name,
        graph_type=exp['graph_type'],
        N=exp['N'],
        rule=exp['rule'],
        seed_lines=seed_code,
        seed_arg=''
    )
    with open(os.path.join(pkg_folder, 'run.py'), 'w', encoding='utf-8') as f:
        f.write(run_code)

    # 4. 运行实验并保存结果到包内
    G = build_graph(exp['graph_type'], exp['N'])
    edge = (0, 1) if G.has_edge(0, 1) else list(G.edges())[0]
    strengths = np.linspace(0.0, 3.0, 9)

    gaps, coarse_vals, fine_vals, audit_gaps = [], [], [], []
    for s in strengths:
        G_mod = introduce_contradiction(G, edge, s)
        _, gap, gs = diagnose(G_mod, rule=exp['rule'], delta=1.0, num_eig=5)
        coarse = coarse_diagnosis(exp['N'], gs)
        fine = fine_diagnosis(G_mod, gs)
        _, gap2, _ = diagnose(G_mod, rule=exp['rule'], delta=1.0, num_eig=6)
        gaps.append(gap)
        coarse_vals.append(coarse)
        fine_vals.append(fine)
        audit_gaps.append(abs(gap - gap2))
        print(f"  s={s:.2f}: gap={gap:.4f}, coarse={coarse:.4f}, fine={fine:.4f}")

    # 保存 CSV 和 PNG 到包内
    csv_path = os.path.join(pkg_folder, f'{name}.csv')
    np.savetxt(csv_path, np.column_stack((strengths, gaps, coarse_vals, fine_vals, audit_gaps)),
               header='strength,gap,coarse,fine,audit_gap_diff', delimiter=',', comments='')

    fig, ax1 = plt.subplots(figsize=(10,6))
    ax1.plot(strengths, coarse_vals, 'o-', color='#1f77b4', label='Coarse Diagnosis')
    ax2 = ax1.twinx()
    ax2.plot(strengths, fine_vals, 's-', color='#d62728', label='Fine Diagnosis')
    ax1.set_xlabel('Contradiction Strength'); ax1.set_ylabel('Coarse Metric')
    ax2.set_ylabel('Fine Metric'); ax1.legend(loc='upper left'); ax2.legend(loc='upper right')
    plt.title(name)
    plt.tight_layout()
    png_path = os.path.join(pkg_folder, f'{name}.png')
    plt.savefig(png_path, dpi=150)
    plt.close()

print(f"\n全部实验包已生成至: {final_dir}")