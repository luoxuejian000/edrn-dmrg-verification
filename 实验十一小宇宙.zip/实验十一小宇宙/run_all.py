"""
关系先于实体：完整实验矩阵
一次运行，完整归档，互不覆盖
"""
import os
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from datetime import datetime

# 导入你的宇宙编译器
from custom_universe import (
    build_graph, introduce_contradiction, diagnose, 
    coarse_diagnosis, fine_diagnosis
)

# 实验矩阵配置：你需要探索的所有规则和关系图组合
EXPERIMENTS = [
    {'graph_type': 'chain', 'N': 6, 'rule': 'heisenberg', 'label': 'chain_heisenberg'},
    {'graph_type': 'chain', 'N': 6, 'rule': 'ising', 'label': 'chain_ising'},
    {'graph_type': 'chain', 'N': 6, 'rule': 'xy', 'label': 'chain_xy'},
    {'graph_type': 'small_world', 'N': 6, 'rule': 'heisenberg', 'label': 'smallworld_heisenberg'},
    {'graph_type': 'small_world', 'N': 6, 'rule': 'ising', 'label': 'smallworld_ising'},
    {'graph_type': 'small_world', 'N': 6, 'rule': 'xy', 'label': 'smallworld_xy'},
]

# 创建用于存放所有结果的文件夹
RESULTS_DIR = 'all_results'
os.makedirs(RESULTS_DIR, exist_ok=True)

# 矛盾强度扫描参数（与之前实验完全一致）
STRENGTHS = np.linspace(0.0, 3.0, 9)

def run_single_experiment(config):
    """运行单个实验，并自动保存为带标签的文件"""
    label = config['label']
    graph_type = config['graph_type']
    N = config['N']
    rule = config['rule']
    
    print(f"\n{'='*60}")
    print(f"正在运行：{label} (图: {graph_type}, N: {N}, 规则: {rule})")
    print(f"{'='*60}")
    
    # 构建关系图
    G = build_graph(graph_type, N)
    # 选择默认矛盾边
    contradiction_edge = (0, 1) if G.has_edge(0, 1) else list(G.edges())[0]
    
    gaps, coarse_vals, fine_vals, audit_gaps = [], [], [], []
    
    for s in STRENGTHS:
        G_mod = introduce_contradiction(G, contradiction_edge, s)
        _, gap, gs = diagnose(G_mod, rule=rule, delta=1.0, num_eig=5)
        coarse = coarse_diagnosis(N, gs)
        fine = fine_diagnosis(G_mod, gs)
        _, gap2, _ = diagnose(G_mod, rule=rule, delta=1.0, num_eig=6)
        
        gaps.append(gap)
        coarse_vals.append(coarse)
        fine_vals.append(fine)
        audit_gaps.append(abs(gap - gap2))
        print(f"   s={s:.2f}: gap={gap:.4f}, coarse={coarse:.4f}, fine={fine:.4f}")

    # 1. 保存CSV数据
    csv_path = os.path.join(RESULTS_DIR, f'{label}.csv')
    np.savetxt(csv_path, np.column_stack((STRENGTHS, gaps, coarse_vals, fine_vals, audit_gaps)),
               header='strength,gap,coarse,fine,audit_gap_diff', delimiter=',', comments='')
    print(f"   ✓ 数据已保存至 {csv_path}")

    # 2. 生成并保存图片
    fig, ax1 = plt.subplots(figsize=(10,6))
    ax1.plot(STRENGTHS, coarse_vals, 'o-', color='#1f77b4', label='Coarse Diagnosis')
    ax2 = ax1.twinx()
    ax2.plot(STRENGTHS, fine_vals, 's-', color='#d62728', label='Fine Diagnosis')
    ax1.set_xlabel('Contradiction Strength'); ax1.set_ylabel('Coarse Metric')
    ax2.set_ylabel('Fine Metric'); ax1.legend(loc='upper left'); ax2.legend(loc='upper right')
    plt.title(f'Custom Universe: {label}')
    plt.tight_layout()
    png_path = os.path.join(RESULTS_DIR, f'{label}.png')
    plt.savefig(png_path, dpi=150)
    plt.close()
    print(f"   ✓ 图表已保存至 {png_path}")

def run_all():
    start_time = datetime.now()
    print(f"开始完整实验矩阵扫描，共 {len(EXPERIMENTS)} 个实验。")
    for i, config in enumerate(EXPERIMENTS):
        print(f"\n进度：{i+1}/{len(EXPERIMENTS)}")
        run_single_experiment(config)
    print(f"\n全部实验完成。所有结果已归档至 '{RESULTS_DIR}' 文件夹。")
    print(f"总耗时：{datetime.now() - start_time}")

if __name__ == "__main__":
    run_all()