"""
树边(5,10)流形平均扫描_双视角.py

实验目的：
    解决DanceNitra指出的树边(5,10)数据分歧：
    - full-data scan：无谷
    - repaired CSV：谷在s=0.15，深度0.010517

    本实验用正确的流形平均方法重新扫描这条边，确定它到底有没有谷。

两种视角并排：
    标准物理视角（流形平均）：
        扫描所有简并扇区，对简并流形中的所有态等权平均。
        这是DanceNitra确认的修复版CSV方法。
        输出：流形平均的E(s)曲线和谷底参数。

    理论精髓视角（原始多种子）：
        每个Lanczos种子返回简并流形中的一个方向。
        不做任何平均，保留每个种子的原始E(s)曲线。
        输出：每个种子的谷底参数，不做筛选。

关键设置：
    - 生成器：nx.random_labeled_tree(15, seed=42)
    - 扫描网格：41点[0,2]，步长0.05
    - 简并扇区：[7,8]（树图基态）
    - 显式v0：每次Lanczos都传入明确种子
    - 大k：n_eigs=8覆盖简并流形

理论精髓落实：
    - 关系本体论：谷底是关系场在观测介入下的显现。不同观测方式可能不同。
    - 实践介入论：流形平均和原始多种子是两种介入，结果并排。
    - 谐振调谐论：不预设(5,10)必须有谷或无谷。让数据说话。
    - 元反思律：如果两种视角给出不同答案，说明这条边的谷底是观测依赖的。

输出：
    tree_edge_5_10_dual_view.json
"""

import numpy as np
import networkx as nx
import itertools
from scipy.sparse import lil_matrix, csr_matrix
from scipy.sparse.linalg import eigsh
import json
import warnings
warnings.filterwarnings('ignore')

# ========== 参数 ==========
N = 15
S_MIN, S_MAX = 0.0, 2.0
N_POINTS = 41  # 41点[0,2]，步长0.05
EPS_DEGEN = 1e-8
N_EIGS = 8  # 求8个本征态以覆盖简并流形
N_V0 = 5  # 多种子

tree_edges = [
    (0, 7), (0, 11), (1, 6), (1, 10), (1, 12),
    (2, 3), (2, 11), (3, 4), (3, 9), (4, 8),
    (5, 10), (10, 11), (11, 14), (13, 14)
]

def build_hamiltonian_sector(N, edges, J_vals, N_up):
    basis = list(itertools.combinations(range(N), N_up))
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = lil_matrix((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, st in enumerate(basis):
            si = 1 if i in st else -1
            sj = 1 if j in st else -1
            H[idx, idx] += J * si * sj
        for idx, st in enumerate(basis):
            i_up = i in st
            j_up = j in st
            if i_up and not j_up:
                ns = list(st); ns.remove(i); ns.append(j)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2.0 * J
            elif j_up and not i_up:
                ns = list(st); ns.remove(j); ns.append(i)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2.0 * J
    return csr_matrix(H), basis

def lanczos_sa_multi_explicit_v0(H, n_eigs, v0_seed, maxiter=15000):
    """显式v0的Lanczos求解"""
    dim = H.shape[0]
    if dim == 0:
        return None, None, False
    rng = np.random.default_rng(v0_seed)
    v0 = rng.standard_normal(dim)
    k = min(n_eigs, dim)
    try:
        evals, evecs = eigsh(H, k=k, which='SA', v0=v0, maxiter=maxiter, tol=1e-10)
        idx = np.argsort(evals)
        return evals[idx], evecs[:, idx], True
    except Exception:
        return None, None, False

def compute_edge_corrs_from_psi(N, edges, psi, basis):
    corrs = []
    for (i, j) in edges:
        diag = np.array([(1 if i in st else -1)*(1 if j in st else -1) for st in basis])
        corrs.append(np.sum(np.abs(psi)**2 * diag))
    return np.array(corrs)

def compute_fine_projected(N, edges, J_vals, degen_sectors, v0_seed=0):
    """流形平均：扫描所有简并扇区，对简并流形中所有态等权平均"""
    n_edges = len(edges)
    corr_sum = np.zeros(n_edges)
    n_states = 0

    # 动态确定每个扇区的简并态
    sector_evals = {}
    for N_up in degen_sectors:
        H, basis = build_hamiltonian_sector(N, edges, J_vals, N_up)
        if H.shape[0] == 0:
            continue
        dim = H.shape[0]
        if dim <= 2000:
            evals = np.linalg.eigh(H.toarray())[0]
            sector_evals[N_up] = evals
        else:
            evals, evecs, ok = lanczos_sa_multi_explicit_v0(H, n_eigs=N_EIGS, v0_seed=v0_seed)
            if ok:
                sector_evals[N_up] = evals

    if not sector_evals:
        return None

    E0_local = min(evals[0] for evals in sector_evals.values())

    for N_up, evals in sector_evals.items():
        H, basis = build_hamiltonian_sector(N, edges, J_vals, N_up)
        if H.shape[0] == 0:
            continue
        dim = H.shape[0]
        if dim <= 2000:
            _, evecs = np.linalg.eigh(H.toarray())
            for idx, E in enumerate(evals):
                if abs(E - E0_local) < EPS_DEGEN:
                    psi = evecs[:, idx]
                    n_states += 1
                    corr = compute_edge_corrs_from_psi(N, edges, psi, basis)
                    corr_sum += corr
        else:
            _, evecs, ok = lanczos_sa_multi_explicit_v0(H, n_eigs=N_EIGS, v0_seed=v0_seed)
            if not ok:
                continue
            for idx in range(len(evals)):
                if abs(evals[idx] - E0_local) < EPS_DEGEN:
                    psi = evecs[:, idx]
                    n_states += 1
                    corr = compute_edge_corrs_from_psi(N, edges, psi, basis)
                    corr_sum += corr

    if n_states == 0:
        return None
    corr_avg = corr_sum / n_states
    return np.std(corr_avg)

def compute_fine_single(N, edges, J_vals, N_up, v0_seed=0):
    """单态计算：只取一个本征态"""
    H, basis = build_hamiltonian_sector(N, edges, J_vals, N_up)
    evals, evecs, ok = lanczos_sa_multi_explicit_v0(H, n_eigs=1, v0_seed=v0_seed)
    if not ok:
        return None
    psi = evecs[:, 0]
    corrs = compute_edge_corrs_from_psi(N, edges, psi, basis)
    return np.std(corrs)

def find_all_valleys(s_values, e_values):
    """找到所有内部极小值，包括负深度"""
    valid = np.where(~np.isnan(e_values))[0]
    if len(valid) < 3:
        return []
    valleys = []
    for idx in range(1, len(valid)-1):
        curr = valid[idx]
        if e_values[curr] < e_values[valid[idx-1]] and e_values[curr] < e_values[valid[idx+1]]:
            depth = e_values[valid[0]] - e_values[curr]
            valleys.append({
                's': float(s_values[curr]),
                'depth': float(depth),
                'type': 'internal_minimum' if depth > 0 else 'internal_minimum_negative_depth'
            })
    return valleys

def main():
    print("=== 树边(5,10)流形平均扫描：双视角 ===")
    print(f"生成器：nx.random_labeled_tree(15, seed=42)")
    print(f"扫描网格：{N_POINTS}点 [{S_MIN}, {S_MAX}]，步长0.05")
    print(f"多种子：{N_V0}个")
    print()

    edges = [tuple(sorted(e)) for e in tree_edges]
    target_edge = (5, 10)
    if target_edge not in edges:
        print(f"警告：边 {target_edge} 不在边列表中")
        return
    edge_idx = edges.index(target_edge)

    s_values = np.linspace(S_MIN, S_MAX, N_POINTS)

    # 预扫描确定简并扇区
    print("预扫描确定简并扇区...")
    J_vals_probe = np.ones(len(edges))
    sector_energies = {}
    for N_up in range(N+1):
        H, basis = build_hamiltonian_sector(N, edges, J_vals_probe, N_up)
        if H.shape[0] == 0:
            continue
        dim = H.shape[0]
        if dim <= 2000:
            evals = np.linalg.eigh(H.toarray())[0]
            E0 = evals[0]
        else:
            evals, evecs, ok = lanczos_sa_multi_explicit_v0(H, n_eigs=1, v0_seed=0)
            if not ok:
                sector_energies[N_up] = np.inf
                continue
            E0 = evals[0]
        sector_energies[N_up] = E0
    min_E = min(sector_energies.values())
    degen_sectors = [nup for nup, E in sector_energies.items() if abs(E-min_E) < EPS_DEGEN]
    print(f"  简并扇区：{degen_sectors}")
    print()

    # ===== 标准物理视角：流形平均 =====
    print("=== 标准物理视角（流形平均） ===")
    J_vals = np.ones(len(edges))
    fine_projected_curve = np.full(N_POINTS, np.nan)

    for si, s in enumerate(s_values):
        J_vals[edge_idx] = s
        fine = compute_fine_projected(N, edges, J_vals, degen_sectors, v0_seed=0)
        if fine is not None:
            fine_projected_curve[si] = fine
        J_vals[edge_idx] = 1.0

    valleys_projected = find_all_valleys(s_values, fine_projected_curve)
    if valleys_projected:
        deepest = max(valleys_projected, key=lambda x: x['depth'])
        print(f"  最深谷底 s={deepest['s']:.2f}, 深度={deepest['depth']:.6f}, "
              f"类型={deepest['type']}")
        print(f"  所有谷底：")
        for v in valleys_projected:
            print(f"    s={v['s']:.2f}, 深度={v['depth']:.6f}, 类型={v['type']}")
    else:
        print(f"  无内部极小值")

    # ===== 理论精髓视角：原始多种子 =====
    print(f"\n=== 理论精髓视角（{N_V0}个原始种子，不平均） ===")
    N_up_single = degen_sectors[0] if degen_sectors else N // 2
    raw_seed_valleys = []

    for v0 in range(N_V0):
        J_vals = np.ones(len(edges))
        fine_raw = np.full(N_POINTS, np.nan)

        for si, s in enumerate(s_values):
            J_vals[edge_idx] = s
            fine = compute_fine_single(N, edges, J_vals, N_up_single, v0_seed=v0)
            if fine is not None:
                fine_raw[si] = fine
            J_vals[edge_idx] = 1.0

        valleys_raw = find_all_valleys(s_values, fine_raw)
        raw_seed_valleys.append({
            'v0_seed': v0,
            'valleys': valleys_raw
        })

        if valleys_raw:
            deepest_raw = max(valleys_raw, key=lambda x: x['depth'])
            print(f"  v0={v0}: 最深谷底 s={deepest_raw['s']:.2f}, "
                  f"深度={deepest_raw['depth']:.6f}, 类型={deepest_raw['type']}")
        else:
            print(f"  v0={v0}: 无内部极小值")

    # ===== 保存 =====
    output = {
        'graph': 'tree_N15_seed42',
        'edge': list(target_edge),
        'edge_idx': edge_idx,
        's_values': s_values.tolist(),
        'degen_sectors': degen_sectors,
        'standard_physics_view': {
            'method': 'manifold_average',
            'fine_curve': fine_projected_curve.tolist(),
            'valleys': valleys_projected
        },
        'theoretical_view': {
            'method': 'raw_single_states',
            'n_seeds': N_V0,
            'raw_valleys': raw_seed_valleys
        }
    }

    with open('tree_edge_5_10_dual_view.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)

    print("\n结果已保存至 tree_edge_5_10_dual_view.json")
    print("\n=== 判断要点 ===")
    print("1. 如果流形平均和多种子单态都无谷 → 边(5,10)无稳定谷")
    print("2. 如果流形平均有谷但单态无谷 → 谷是混合态性质")
    print("3. 如果两者都有谷且位置一致 → 边(5,10)有稳定谷")
    print("4. 如果流形平均有谷但深度极小 → 可能是伪影，需要进一步检验")

if __name__ == "__main__":
    main()