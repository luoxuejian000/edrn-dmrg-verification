"""
边(8,14)固定扇区n_up=7流形平均扫描_双视角.py

实验目的：
    复现DanceNitra给出的关键数字：固定扇区n_up=7流形平均深度0.050837。
    这个数字出现在s=1.20，是修复版CSV的随机边(8,14)深度。

    同时并排原始多种子单态视角，展示单态与流形平均的差异。

关键设置（与DanceNitra确认一致）：
    - 生成器：nx.gnm_random_graph(15, 27, seed=42)
    - 扫描网格：41点[0,2]，步长0.05
    - 固定扇区：n_up=7
    - 流形平均：对n_up=7内所有简并态等权平均
    - 显式v0，大k（n_eigs=8）
    - 双v0交叉验证

标准物理视角（流形平均）：
    只扫描n_up=7扇区，对该扇区内的简并流形做等权平均。
    这是修复版CSV的方法。
    输出：完整E(s)曲线、谷底位置、深度。

理论精髓视角（原始多种子）：
    每个Lanczos种子在n_up=7扇区内返回一个纯态。
    不做任何平均。
    输出：每个种子的谷底位置和深度，不筛除。

理论精髓落实：
    - 关系本体论：深度是关系场在特定观测方式下的显现。
    - 实践介入论：流形平均和原始单态是两种介入，结果并排。
    - 谐振调谐论：不预设0.050837一定复现。让数据说话。
    - 元反思律：如果流形平均与0.050837不符，必须如实报告。

输出：
    edge_8_14_fixed_n7_dual_view.json
"""

import numpy as np
import networkx as nx
import itertools
from scipy.sparse import lil_matrix, csr_matrix
from scipy.sparse.linalg import eigsh
import json
import warnings
warnings.filterwarnings('ignore')

# ========== 参数 ==========
N = 15
S_MIN, S_MAX = 0.0, 2.0
N_POINTS = 41  # 41点[0,2]，步长0.05
EPS_DEGEN = 1e-8
N_EIGS = 8  # 求8个本征态覆盖简并流形
N_V0 = 5  # 多种子
N_UP_FIXED = 7  # 固定扇区

def generate_random_N15(seed=42):
    G = nx.gnm_random_graph(15, 27, seed=seed)
    G = nx.relabel_nodes(G, {old: new for new, old in enumerate(G.nodes())})
    return [tuple(sorted(e)) for e in G.edges()]

def build_hamiltonian_sector(N, edges, J_vals, N_up):
    basis = list(itertools.combinations(range(N), N_up))
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = lil_matrix((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, st in enumerate(basis):
            si = 1 if i in st else -1
            sj = 1 if j in st else -1
            H[idx, idx] += J * si * sj
        for idx, st in enumerate(basis):
            i_up = i in st
            j_up = j in st
            if i_up and not j_up:
                ns = list(st); ns.remove(i); ns.append(j)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2.0 * J
            elif j_up and not i_up:
                ns = list(st); ns.remove(j); ns.append(i)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2.0 * J
    return csr_matrix(H), basis

def lanczos_sa_multi_explicit_v0(H, n_eigs, v0_seed, maxiter=15000):
    """显式v0的Lanczos求解"""
    dim = H.shape[0]
    if dim == 0:
        return None, None, False
    rng = np.random.default_rng(v0_seed)
    v0 = rng.standard_normal(dim)
    k = min(n_eigs, dim)
    try:
        evals, evecs = eigsh(H, k=k, which='SA', v0=v0, maxiter=maxiter, tol=1e-10)
        idx = np.argsort(evals)
        return evals[idx], evecs[:, idx], True
    except Exception:
        return None, None, False

def compute_edge_corrs_from_psi(N, edges, psi, basis):
    corrs = []
    for (i, j) in edges:
        diag = np.array([(1 if i in st else -1)*(1 if j in st else -1) for st in basis])
        corrs.append(np.sum(np.abs(psi)**2 * diag))
    return np.array(corrs)

def compute_E_from_corrs(corrs):
    return np.std(corrs)

def compute_fine_manifold_fixed_n7(N, edges, J_vals, v0_seed=0):
    """
    标准物理视角：固定扇区n_up=7内的流形平均。
    只扫描n_up=7扇区，对该扇区内所有简并态等权平均。
    """
    N_up = N_UP_FIXED
    H, basis = build_hamiltonian_sector(N, edges, J_vals, N_up)
    if H.shape[0] == 0:
        return None

    # 求大k本征态
    evals, evecs, ok = lanczos_sa_multi_explicit_v0(H, n_eigs=N_EIGS, v0_seed=v0_seed)
    if not ok:
        return None

    # 找出该扇区内的简并态
    E0 = evals[0]
    corr_sum = np.zeros(len(edges))
    n_states = 0
    for idx in range(len(evals)):
        if abs(evals[idx] - E0) < EPS_DEGEN:
            psi = evecs[:, idx]
            corrs = compute_edge_corrs_from_psi(N, edges, psi, basis)
            corr_sum += corrs
            n_states += 1

    if n_states == 0:
        return None
    corr_avg = corr_sum / n_states
    return compute_E_from_corrs(corr_avg)

def compute_fine_single_fixed_n7(N, edges, J_vals, v0_seed=0):
    """
    理论精髓视角：固定扇区n_up=7内的单态。
    每个种子返回一个纯态，不做平均。
    """
    N_up = N_UP_FIXED
    H, basis = build_hamiltonian_sector(N, edges, J_vals, N_up)
    if H.shape[0] == 0:
        return None

    evals, evecs, ok = lanczos_sa_multi_explicit_v0(H, n_eigs=1, v0_seed=v0_seed)
    if not ok:
        return None

    psi = evecs[:, 0]
    corrs = compute_edge_corrs_from_psi(N, edges, psi, basis)
    return compute_E_from_corrs(corrs)

def find_all_valleys(s_values, e_values):
    """找到所有内部极小值，包括负深度"""
    valid = np.where(~np.isnan(e_values))[0]
    if len(valid) < 3:
        return []
    valleys = []
    for idx in range(1, len(valid)-1):
        curr = valid[idx]
        if e_values[curr] < e_values[valid[idx-1]] and e_values[curr] < e_values[valid[idx+1]]:
            depth = e_values[valid[0]] - e_values[curr]
            valleys.append({
                's': float(s_values[curr]),
                'depth': float(depth),
                'type': 'internal_minimum' if depth > 0 else 'internal_minimum_negative_depth'
            })
    return valleys

def main():
    print("=== 边(8,14)固定扇区n_up=7流形平均扫描：双视角 ===")
    print(f"生成器：nx.gnm_random_graph(15, 27, seed=42)")
    print(f"扫描网格：{N_POINTS}点 [{S_MIN}, {S_MAX}]，步长0.05")
    print(f"固定扇区：n_up={N_UP_FIXED}")
    print(f"多种子：{N_V0}个")
    print()

    edges = generate_random_N15(seed=42)
    target_edge = (8, 14)
    if target_edge not in edges:
        print(f"警告：边 {target_edge} 不在边列表中")
        return
    edge_idx = edges.index(target_edge)

    s_values = np.linspace(S_MIN, S_MAX, N_POINTS)

    # 确认n_up=7是基态扇区之一
    print("确认n_up=7是否是基态扇区之一...")
    J_vals_probe = np.ones(len(edges))
    H_probe, basis_probe = build_hamiltonian_sector(N, edges, J_vals_probe, N_UP_FIXED)
    evals_probe, evecs_probe, ok_probe = lanczos_sa_multi_explicit_v0(H_probe, n_eigs=1, v0_seed=0)
    if ok_probe:
        print(f"  n_up=7最低能量：{evals_probe[0]:.8f}")
    print()

    # ===== 标准物理视角：流形平均 =====
    print("=== 标准物理视角（固定扇区n_up=7流形平均） ===")
    print("用两个v0分别计算，要求一致到1e-12\n")

    manifold_curves = {}
    for v0_check in [0, 1]:
        J_vals = np.ones(len(edges))
        fine_curve = np.full(N_POINTS, np.nan)

        for si, s in enumerate(s_values):
            J_vals[edge_idx] = s
            fine = compute_fine_manifold_fixed_n7(N, edges, J_vals, v0_seed=v0_check)
            if fine is not None:
                fine_curve[si] = fine
            J_vals[edge_idx] = 1.0

        manifold_curves[v0_check] = fine_curve.tolist()

        if v0_check == 0:
            valleys_manifold = find_all_valleys(s_values, fine_curve)
            if valleys_manifold:
                deepest = max(valleys_manifold, key=lambda x: x['depth'])
                print(f"  v0=0: 最深谷底 s={deepest['s']:.2f}, 深度={deepest['depth']:.6f}, "
                      f"类型={deepest['type']}")
                print(f"  所有谷底：")
                for v in valleys_manifold:
                    print(f"    s={v['s']:.2f}, 深度={v['depth']:.6f}, 类型={v['type']}")
            else:
                print(f"  v0=0: 无内部极小值")

    # 双v0交叉验证
    curve0 = np.array(manifold_curves[0])
    curve1 = np.array(manifold_curves[1])
    valid_both = ~np.isnan(curve0) & ~np.isnan(curve1)
    if np.any(valid_both):
        max_diff = np.max(np.abs(curve0[valid_both] - curve1[valid_both]))
        print(f"\n  双v0交叉验证：E(s)曲线最大差异 = {max_diff:.2e}")
        if max_diff < 1e-12:
            print("  ✅ 通过：流形平均对v0不敏感")
        else:
            print("  ⚠ 未完全通过：流形平均对v0有微小依赖")

    # ===== 理论精髓视角：原始多种子 =====
    print(f"\n=== 理论精髓视角（{N_V0}个原始种子，不平均） ===")
    raw_seed_valleys = []
    raw_seed_curves = []

    for v0 in range(N_V0):
        J_vals = np.ones(len(edges))
        fine_raw = np.full(N_POINTS, np.nan)

        for si, s in enumerate(s_values):
            J_vals[edge_idx] = s
            fine = compute_fine_single_fixed_n7(N, edges, J_vals, v0_seed=v0)
            if fine is not None:
                fine_raw[si] = fine
            J_vals[edge_idx] = 1.0

        valleys_raw = find_all_valleys(s_values, fine_raw)
        raw_seed_valleys.append({
            'v0_seed': v0,
            'valleys': valleys_raw
        })
        raw_seed_curves.append(fine_raw.tolist())

        if valleys_raw:
            deepest_raw = max(valleys_raw, key=lambda x: x['depth'])
            print(f"  v0={v0}: 最深谷底 s={deepest_raw['s']:.2f}, "
                  f"深度={deepest_raw['depth']:.6f}, 类型={deepest_raw['type']}")
        else:
            print(f"  v0={v0}: 无内部极小值")

    # ===== 保存 =====
    output = {
        'graph': 'random_graph_N15_seed42',
        'edge': list(target_edge),
        'edge_idx': edge_idx,
        's_values': s_values.tolist(),
        'fixed_sector': N_UP_FIXED,
        'standard_physics_view': {
            'method': 'manifold_average_fixed_n7',
            'manifold_curves_v0_0': manifold_curves[0],
            'manifold_curves_v0_1': manifold_curves[1],
            'valleys': valleys_manifold
        },
        'theoretical_view': {
            'method': 'raw_single_states_fixed_n7',
            'n_seeds': N_V0,
            'raw_curves': raw_seed_curves,
            'raw_valleys': raw_seed_valleys
        }
    }

    with open('edge_8_14_fixed_n7_dual_view.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)

    print("\n结果已保存至 edge_8_14_fixed_n7_dual_view.json")
    print("\n=== 判断要点 ===")
    print("1. 流形平均深度应接近0.050837（DanceNitra的修复版CSV数字）")
    print("2. 原始单态深度应在正负之间波动，体现简并流形中的方向依赖")
    print("3. 流形平均是单态波动的平均，不是任何单个纯态的性质")
    print("4. 如果流形平均深度与0.050837相差很大，需要检查网格或方法")

if __name__ == "__main__":
    main()