"""
守恒律破缺-沉默失谐诊断脚本
检验文小刚"局域算子代数决定统计"框架与沉默失谐的关联
α参数：调控矛盾边上的守恒律破缺程度
"""
import numpy as np
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def chain_graph(N=6):
    edges = [(i, i+1, 1.0) for i in range(N-1)]
    return edges

def graph_to_hamiltonian_with_alpha(N, edges, contradiction_edge, s, alpha=0.0):
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    for (i, j, w) in edges:
        if (i, j) == contradiction_edge or (j, i) == contradiction_edge:
            w = s
        for state in range(dim):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            flipped = state ^ (1 << i) ^ (1 << j)
            H[state, flipped] += w
        zz_weight = w * (1.0 - alpha)
        for state in range(dim):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i == bit_j:
                H[state, state] += zz_weight
            else:
                H[state, state] -= zz_weight
    return H.tocsc()

def diagnose(N, edges, contradiction_edge, s, alpha=0.0, num_eig=5):
    H = graph_to_hamiltonian_with_alpha(N, edges, contradiction_edge, s, alpha)
    energies, states = eigsh(H, k=min(num_eig, 2**N-1), which='SA')
    gap = energies[1] - energies[0] if len(energies) > 1 else np.nan
    gs = states[:, 0]
    mag = 0.0
    dim = len(gs)
    for state in range(dim):
        prob = np.abs(gs[state])**2
        bits = [(state >> k) & 1 for k in range(N)]
        magnetization = sum(1 - 2*b for b in bits)
        mag += prob * magnetization
    coarse = abs(mag / N)
    corrs = []
    for (i, j, w) in edges:
        corr = 0.0
        for state in range(dim):
            prob = np.abs(gs[state])**2
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            corr += prob * (1 - 2*bit_i) * (1 - 2*bit_j)
        corrs.append(corr)
    fine = np.std(corrs) if corrs else 0.0
    return gap, coarse, fine

# =============================================
# 主扫描函数与入口
# =============================================
def run_conservation_breaking_scan(N=6, alpha_values=None, strengths=None):
    if alpha_values is None:
        alpha_values = np.linspace(0.0, 1.0, 5)
    if strengths is None:
        strengths = np.linspace(0.0, 3.0, 9)

    edges = chain_graph(N)
    contradiction_edge = (0, 1)

    valley_depths = []
    valley_positions = []

    for alpha in alpha_values:
        print(f"\n=== α={alpha:.2f} ===")
        fine_vals = []
        for s in strengths:
            gap, coarse, fine = diagnose(N, edges, contradiction_edge, s, alpha, num_eig=5)
            fine_vals.append(fine)
            print(f"s={s:.2f}: gap={gap:.6f}, coarse={coarse:.4f}, fine={fine:.4f}")

        fine_vals = np.array(fine_vals)
        valley_idx = np.argmin(fine_vals)
        valley_depth = fine_vals[valley_idx]
        valley_position = strengths[valley_idx]
        valley_depths.append(valley_depth)
        valley_positions.append(valley_position)

        csv_name = f"conservation_alpha_{alpha:.2f}.csv"
        np.savetxt(csv_name,
                   np.column_stack((strengths, fine_vals)),
                   header='strength,fine', delimiter=',')

    summary = np.column_stack((alpha_values, valley_depths, valley_positions))
    np.savetxt('conservation_breaking_summary.csv', summary,
               header='alpha,valley_depth,valley_position', delimiter=',')
    print("\n汇总数据已保存: conservation_breaking_summary.csv")

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
    ax1.plot(alpha_values, valley_depths, 'o-', color='red', markersize=8)
    ax1.set_xlabel('Conservation-breaking parameter α')
    ax1.set_ylabel('Valley depth (fine at minimum)')
    ax1.set_title('Valley Depth vs α')
    ax1.grid(True, alpha=0.3)

    ax2.plot(alpha_values, valley_positions, 's-', color='blue', markersize=8)
    ax2.set_xlabel('Conservation-breaking parameter α')
    ax2.set_ylabel('Valley position s')
    ax2.set_title('Valley Position vs α')
    ax2.grid(True, alpha=0.3)

    plt.suptitle('Silent Discordance under Conservation-law Breaking')
    plt.tight_layout()
    plt.savefig('conservation_breaking_sd.png', dpi=150)
    print("诊断图已保存: conservation_breaking_sd.png")


if __name__ == "__main__":
    run_conservation_breaking_scan(N=6)