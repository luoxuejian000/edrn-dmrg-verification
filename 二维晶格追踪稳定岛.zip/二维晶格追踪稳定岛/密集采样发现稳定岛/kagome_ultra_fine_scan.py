"""
二维超密集稳定岛探测器 —— 金箍棒 3.0 DMRG (Kagome)
在 Kagome 晶格的尾部区域 (Δ=2.0-3.0) 以步长 0.002 进行超精细扫描，
检验“冻结”是否为真实的稳定岛。
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tenpy.models.model import CouplingMPOModel
from tenpy.models.lattice import Chain
from tenpy.networks.site import SpinHalfSite
from tenpy.networks.mps import MPS
from tenpy.algorithms import dmrg
import warnings
warnings.filterwarnings('ignore')

# =============================================
# 公理一：构建 Kagome 晶格（复用已验证的构建方式）
# =============================================
def build_kagome_lattice(Lx=2, Ly=2):
    a = 1.0
    basis = np.array([[a, 0], [a/2, a*np.sqrt(3)/2]])
    unit_cell = np.array([
        [0, 0],
        [a/2, 0],
        [a/4, a*np.sqrt(3)/4]
    ])
    sites = []
    for ix in range(Lx):
        for iy in range(Ly):
            for atom in unit_cell:
                pos = ix * basis[0] + iy * basis[1] + atom
                sites.append(pos)
    N = len(sites)
    edges = set()
    for i in range(N):
        for j in range(i+1, N):
            dist = np.linalg.norm(sites[i] - sites[j])
            if abs(dist - 0.5) < 0.1:
                edges.add((i, j, 1.0))
    edges = list(edges)
    print(f"Kagome晶格：{N}个格点，{len(edges)}条边")
    return N, edges

class KagomeModel(CouplingMPOModel):
    """Kagome晶格上的Heisenberg模型"""
    def __init__(self, model_params):
        L = model_params.get('L', 12)
        self.edges = model_params.get('edges', [])
        self.contradiction_edge = model_params.get('contradiction_edge', None)
        self.contradiction_strength = model_params.get('contradiction_strength', 1.0)
        lat = Chain(L, SpinHalfSite(conserve='Sz'), bc='open')
        model_params['lattice'] = lat
        CouplingMPOModel.__init__(self, model_params)

    def init_terms(self, model_params=None):
        if model_params is None:
            model_params = {}
        for (i, j, w) in self.edges:
            J = self.contradiction_strength if (i, j) == self.contradiction_edge or (j, i) == self.contradiction_edge else w
            self.add_coupling_term(J * 0.5, i, j, 'Sp', 'Sm', plus_hc=True)
            self.add_coupling_term(J, i, j, 'Sz', 'Sz')

def compute_diagnostics(L, edges, contradiction_edge, s, chi_max=200, max_sweeps=100):
    M = KagomeModel(dict(
        L=L, edges=edges,
        contradiction_edge=contradiction_edge,
        contradiction_strength=s,
        bc_MPS='finite', conserve='Sz'
    ))
    init = ['up', 'down'] * (L // 2)
    if L % 2 == 1:
        init.append('up')
    np.random.shuffle(init)
    psi = MPS.from_product_state(M.lat.mps_sites(), init, bc='finite')
    dmrg_params = {
        'mixer': True,
        'chi_max': chi_max,
        'max_sweeps': max_sweeps,
        'verbose': 0,
        'combine': True
    }
    try:
        eng = dmrg.run(psi, M, dmrg_params)
        E0 = eng['E']
        init_ex = init.copy()
        center = L // 2
        init_ex[center] = 'down' if init_ex[center] == 'up' else 'up'
        psi_ex = MPS.from_product_state(M.lat.mps_sites(), init_ex, bc='finite')
        eng_ex = dmrg.run(psi_ex, M, dmrg_params)
        E1 = eng_ex['E']
        gap = E1 - E0
        Sz = psi.expectation_value('Sz')
        coarse = np.mean(np.abs(Sz))
        corrs = []
        for (i, j, w) in edges:
            corr = psi.correlation_function('Sz', 'Sz', [i], [j])
            corrs.append(corr[0])
        fine = np.std(corrs) if corrs else 0.0
        return gap, coarse, fine
    except Exception as e:
        print(f"DMRG failed at s={s:.3f}: {e}")
        return np.nan, np.nan, np.nan

# =============================================
# 稳定岛自动识别（防工具理性：预设定量标准）
# =============================================
def identify_stable_islands(delta_vals, fine_vals, global_std, window_size=10):
    """
    自动识别稳定岛：滑动窗口，若窗口内标准差低于全局标准差的10%，
    则标记为一个候选稳定岛。
    """
    islands = []
    for i in range(len(delta_vals) - window_size + 1):
        window_fine = fine_vals[i:i+window_size]
        if np.nanstd(window_fine) < 0.1 * global_std:
            islands.append((delta_vals[i], delta_vals[i+window_size-1], np.nanstd(window_fine)))
    return merge_islands(islands)

def merge_islands(islands):
    """合并相邻的候选岛"""
    if not islands:
        return []
    merged = [islands[0]]
    for island in islands[1:]:
        prev = merged[-1]
        if island[0] <= prev[1] + 0.005:  # 相邻或重叠
            merged[-1] = (prev[0], island[1], max(prev[2], island[2]))
        else:
            merged.append(island)
    return merged

if __name__ == "__main__":
    # 构建晶格
    Lx, Ly = 2, 2
    N, edges = build_kagome_lattice(Lx, Ly)
    contradiction_edge = (edges[0][0], edges[0][1])
    print(f"矛盾边：{contradiction_edge}")

    # 超精细扫描参数：Δ ∈ [2.0, 3.0]，步长 0.002
    delta_start = 2.0
    delta_end = 3.0
    delta_step = 0.002
    delta_vals = np.arange(delta_start, delta_end + delta_step/2, delta_step)
    num_points = len(delta_vals)
    print(f"超精细扫描：Δ从{delta_start}到{delta_end}，步长{delta_step}，共{num_points}个点")

    gaps, coarse_vals, fine_vals = [], [], []
    print("\n开始超精细扫描...")
    for idx, delta in enumerate(delta_vals):
        gap, coarse, fine = compute_diagnostics(N, edges, contradiction_edge, delta, chi_max=200, max_sweeps=100)
        gaps.append(gap)
        coarse_vals.append(coarse)
        fine_vals.append(fine)
        if idx % 50 == 0 or delta == delta_end:
            print(f"Δ={delta:.3f}: gap={gap:.6f}, coarse={coarse:.4f}, fine={fine:.6f}")

    # 保存数据
    data = np.column_stack((delta_vals, gaps, coarse_vals, fine_vals))
    np.savetxt('kagome_ultra_fine_tail.csv', data,
               header='delta,gap,coarse,fine', delimiter=',')

    # 识别稳定岛
    global_std = np.nanstd(fine_vals)
    print(f"\n全局精细诊断标准差: {global_std:.6f}")
    if global_std > 0:
        islands = identify_stable_islands(delta_vals, fine_vals, global_std, window_size=10)
        if islands:
            print(f"发现 {len(islands)} 个候选稳定岛：")
            for start, end, std in islands:
                print(f"  Δ∈[{start:.3f}, {end:.3f}], 宽度={end-start:.3f}, 岛内标准差={std:.6f}")
        else:
            print("未发现满足标准的稳定岛。")

    # 绘图
    fig, ax1 = plt.subplots(figsize=(10, 6))
    ax1.plot(delta_vals, fine_vals, linewidth=0.5, color='#d62728', label='Fine diagnosis')
    # 高亮稳定岛
    if 'islands' in locals() and islands:
        for start, end, _ in islands:
            ax1.axvspan(start, end, alpha=0.3, color='green', label='Stable Island' if start == islands[0][0] else "")
    ax2 = ax1.twinx()
    ax2.plot(delta_vals, coarse_vals, linewidth=0.5, color='#1f77b4', alpha=0.5, label='Coarse diagnosis')
    ax1.set_xlabel('Contradiction strength Δ')
    ax1.set_ylabel('Fine diagnosis')
    ax2.set_ylabel('Coarse diagnosis')
    ax1.set_title(f'Kagome Ultra-Fine Scan (Δ∈[{delta_start},{delta_end}], step={delta_step})')
    ax1.legend(loc='upper left')
    ax2.legend(loc='upper right')
    ax1.grid(True, alpha=0.2)
    plt.tight_layout()
    plt.savefig('kagome_ultra_fine_tail.png', dpi=150)

    print("\n扫描完成。数据已保存。")