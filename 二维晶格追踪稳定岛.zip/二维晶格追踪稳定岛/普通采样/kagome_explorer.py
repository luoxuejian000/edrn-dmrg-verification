"""
二维稳定岛探索者 —— 金箍棒 3.0 DMRG (Kagome 晶格)
在二维关系拓扑中寻找稳定岛，检验“关系先于实体”的普适性
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tenpy.models.model import CouplingMPOModel
from tenpy.models.lattice import Lattice
from tenpy.networks.site import SpinHalfSite
from tenpy.networks.mps import MPS
from tenpy.algorithms import dmrg
import warnings
warnings.filterwarnings('ignore')

# =============================================
# 公理一：构建 Kagome 晶格
# =============================================
def build_kagome_lattice(Lx=2, Ly=2):
    """构建 Kagome 晶格，Lx和Ly控制超胞大小"""
    # Kagome 晶格的基矢和格点位置
    a = 1.0
    basis = np.array([[a, 0], [a/2, a*np.sqrt(3)/2]])  # 两个基矢
    
    # 每个单元胞内有3个格点，位置由Kagome结构决定
    unit_cell = np.array([
        [0, 0],                    # A格点
        [a/2, 0],                  # B格点
        [a/4, a*np.sqrt(3)/4]      # C格点
    ])
    
    # 手动构建格点坐标
    sites = []
    for ix in range(Lx):
        for iy in range(Ly):
            for atom in unit_cell:
                pos = ix * basis[0] + iy * basis[1] + atom
                sites.append(pos)
    
    N = len(sites)
    # 最近邻连接：根据Kagome晶格几何，每个格点有4个最近邻
    edges = set()
    for i in range(N):
        for j in range(i+1, N):
            dist = np.linalg.norm(sites[i] - sites[j])
            # 最近邻距离约 a/2 = 0.5
            if abs(dist - 0.5) < 0.1:
                edges.add((i, j, 1.0))
    
    edges = list(edges)
    print(f"Kagome晶格：{N}个格点，{len(edges)}条边")
    return N, edges, sites

# =============================================
# 公理一：构建哈密顿量（使用CouplingMPOModel）
# =============================================
class KagomeModel(CouplingMPOModel):
    """Kagome晶格上的Heisenberg模型，矛盾边强度可调"""
    def __init__(self, model_params):
        L = model_params.get('L', 12)  # 格点总数
        self.edges = model_params.get('edges', [])
        self.contradiction_edge = model_params.get('contradiction_edge', None)
        self.contradiction_strength = model_params.get('contradiction_strength', 1.0)
        
        # 创建一维链晶格作为占位，实际连接通过add_coupling_term实现
        from tenpy.models.lattice import Chain
        lat = Chain(L, SpinHalfSite(conserve='Sz'), bc='open')
        model_params['lattice'] = lat
        CouplingMPOModel.__init__(self, model_params)

    def init_terms(self, model_params=None):
        if model_params is None:
            model_params = {}
        for (i, j, w) in self.edges:
            J = self.contradiction_strength if (i, j) == self.contradiction_edge or (j, i) == self.contradiction_edge else w
            # 使用add_coupling_term添加任意格点对之间的耦合
            self.add_coupling_term(J * 0.5, i, j, 'Sp', 'Sm', plus_hc=True)
            self.add_coupling_term(J, i, j, 'Sz', 'Sz')

# =============================================
# 诊断函数
# =============================================
def compute_diagnostics_kagome(L, edges, contradiction_edge, s, chi_max=200, max_sweeps=100):
    M = KagomeModel(dict(
        L=L, edges=edges,
        contradiction_edge=contradiction_edge,
        contradiction_strength=s,
        bc_MPS='finite', conserve='Sz'
    ))
    
    # 随机初态以探测多分支
    init = ['up', 'down'] * (L // 2)
    if L % 2 == 1:
        init.append('up')
    # 随机扰动避免陷入局部极小
    np.random.shuffle(init)
    psi = MPS.from_product_state(M.lat.mps_sites(), init, bc='finite')
    
    dmrg_params = {
        'mixer': True,
        'chi_max': chi_max,
        'max_sweeps': max_sweeps,
        'verbose': 0,
        'combine': True
    }
    
    try:
        eng = dmrg.run(psi, M, dmrg_params)
        E0 = eng['E']
        
        # 激发态（简化：翻转中心自旋）
        init_ex = init.copy()
        center = L // 2
        init_ex[center] = 'down' if init_ex[center] == 'up' else 'up'
        psi_ex = MPS.from_product_state(M.lat.mps_sites(), init_ex, bc='finite')
        eng_ex = dmrg.run(psi_ex, M, dmrg_params)
        E1 = eng_ex['E']
        gap = E1 - E0

        Sz = psi.expectation_value('Sz')
        coarse = np.mean(np.abs(Sz))
        
        # 精细诊断：边关联涨落标准差
        corrs = []
        for (i, j, w) in edges:
            corr = psi.correlation_function('Sz', 'Sz', [i], [j])
            corrs.append(corr[0])
        fine = np.std(corrs) if corrs else 0.0
        
        return gap, coarse, fine
    except Exception as e:
        print(f"DMRG failed at s={s:.3f}: {e}")
        return np.nan, np.nan, np.nan

# =============================================
# 主程序
# =============================================
if __name__ == "__main__":
    # 构建 Kagome 晶格 (2x2 超胞 = 12格点)
    Lx, Ly = 2, 2
    N, edges, sites = build_kagome_lattice(Lx, Ly)
    
    # 选择一条边作为矛盾边（例如第一条边）
    contradiction_edge = (edges[0][0], edges[0][1])
    print(f"矛盾边：{contradiction_edge}")
    
    # 超精细扫描参数
    delta_start = 0.0
    delta_end = 3.0
    delta_step = 0.01  # 可调整为0.002进行超精细扫描，但会很慢
    delta_vals = np.arange(delta_start, delta_end + delta_step, delta_step)
    num_points = len(delta_vals)
    print(f"扫描参数：Δ从{delta_start}到{delta_end}，步长{delta_step}，共{num_points}个点")
    
    gaps, coarse_vals, fine_vals = [], [], []
    
    print("\n开始扫描...")
    for idx, delta in enumerate(delta_vals):
        gap, coarse, fine = compute_diagnostics_kagome(
            N, edges, contradiction_edge, delta, chi_max=200, max_sweeps=100
        )
        gaps.append(gap)
        coarse_vals.append(coarse)
        fine_vals.append(fine)
        
        if idx % 10 == 0 or delta == delta_end:
            print(f"Δ={delta:.3f}: gap={gap:.6f}, coarse={coarse:.4f}, fine={fine:.6f}")
    
    # 保存数据
    data = np.column_stack((delta_vals, gaps, coarse_vals, fine_vals))
    np.savetxt('kagome_scan_results.csv', data,
               header='delta,gap,coarse,fine', delimiter=',')
    
    # 绘图
    fig, ax1 = plt.subplots(figsize=(10, 6))
    ax1.plot(delta_vals, fine_vals, linewidth=0.5, color='#d62728', label='Fine diagnosis')
    ax2 = ax1.twinx()
    ax2.plot(delta_vals, coarse_vals, linewidth=0.5, color='#1f77b4', alpha=0.5, label='Coarse diagnosis')
    ax1.set_xlabel('Contradiction strength Δ')
    ax1.set_ylabel('Fine diagnosis')
    ax2.set_ylabel('Coarse diagnosis')
    ax1.set_title(f'Kagome Lattice (2x2, {N} sites)')
    ax1.legend(loc='upper left')
    ax2.legend(loc='upper right')
    ax1.grid(True, alpha=0.2)
    plt.tight_layout()
    plt.savefig('kagome_scan.png', dpi=150)
    
    print("\n扫描完成。数据已保存至 kagome_scan_results.csv 和 kagome_scan.png")
    
    # 自动识别稳定岛（简单版本：寻找精细诊断局部波动极小区间）
    global_std = np.nanstd(fine_vals)
    print(f"全局精细诊断标准差: {global_std:.6f}")
    if global_std > 0:
        print("尝试识别稳定岛...")
        # 这里可以调用之前的稳定岛识别函数，但为了简洁，只输出统计信息
        print(f"精细诊断最小值: {np.nanmin(fine_vals):.6f} (Δ={delta_vals[np.nanargmin(fine_vals)]:.3f})")
        print(f"精细诊断最大值: {np.nanmax(fine_vals):.6f} (Δ={delta_vals[np.nanargmax(fine_vals)]:.3f})")