"""
PXP 中心缺陷超高分辨率扫描 —— 审计合理补充1
目标：检验 PXP L=18 中心缺陷位置，在 μ∈[0,3] 范围内，
      以步长 0.01（301点）的精细分辨率，
      是否存在先前 13 点扫描遗漏的窄共振峰。
方法：5个独立 Lanczos 种子，对每个 μ 做独立对角化，
      记录半链纠缠谱标准差（增强诊断）和平均绝对关联（默认诊断）。
严格遵循：关系本体论、防工具理性、反对齐
"""
import numpy as np
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import time
import os
import json

# =============================================
# 公理一：PXP 模型哈密顿量构建
# =============================================
def generate_valid_states(L):
    """生成 PXP 约束下的有效态（无相邻↑）"""
    valid = []
    for n in range(2**L):
        s = n
        ok = True
        prev = 0
        for _ in range(L):
            bit = s & 1
            if bit == 1 and prev == 1:
                ok = False
                break
            prev = bit
            s >>= 1
        if ok:
            valid.append(n)
    return np.array(valid, dtype=int)

def build_pxp_hamiltonian_sparse(valid, state_to_idx, L, mu_defect, defect_site):
    """构建带化学势缺陷的 PXP 哈密顿量（稀疏矩阵）"""
    N = len(valid)
    H = lil_matrix((N, N), dtype=float)
    
    for idx, s in enumerate(valid):
        # 化学势缺陷项
        bit_center = (s >> defect_site) & 1
        H[idx, idx] -= mu_defect * bit_center
        
        # 动力学项
        for j in range(L):
            left_occ  = ((s >> (j-1)) & 1) if j > 0 else 0
            right_occ = ((s >> (j+1)) & 1) if j < L-1 else 0
            if left_occ or right_occ:
                continue
            new_s = s ^ (1 << j)
            if new_s in state_to_idx:
                jdx = state_to_idx[new_s]
                H[idx, jdx] += 1.0
    return H.tocsc()

# =============================================
# 公理三：诊断函数
# =============================================
def compute_enhanced(psi, L_sub, valid, state_to_idx):
    """半链纠缠谱标准差"""
    N = len(valid)
    rho_A = np.zeros((N, N), dtype=complex)
    for i in range(N):
        for j in range(N):
            si, sj = valid[i], valid[j]
            left_i = si & ((1 << L_sub) - 1)
            left_j = sj & ((1 << L_sub) - 1)
            right_i = si >> L_sub
            right_j = sj >> L_sub
            if right_i == right_j:
                rho_A[left_i, left_j] += psi[i] * np.conj(psi[j])
    eigvals = np.linalg.eigvalsh(rho_A)
    eigvals = np.sort(np.abs(eigvals))[::-1]
    eigvals = eigvals[eigvals > 1e-12]
    return np.std(eigvals) if len(eigvals) > 0 else 0.0

def compute_default(psi, L, valid, state_to_idx):
    """平均绝对自旋关联（默认诊断）"""
    corr_sum = 0.0
    corr_count = 0
    for i in range(L):
        for j in range(i+1, L):
            corr = 0.0
            for k, s in enumerate(valid):
                bit_i = (s >> i) & 1
                bit_j = (s >> j) & 1
                val_i = 1 - 2 * bit_i
                val_j = 1 - 2 * bit_j
                corr += np.abs(psi[k])**2 * val_i * val_j
            corr_sum += abs(corr)
            corr_count += 1
    return corr_sum / corr_count if corr_count > 0 else 0.0

# =============================================
# 主审计函数：超高分辨率 + 多种子
# =============================================
def run_highres_audit(L=18, defect_site=9, mu_start=0.0, mu_end=3.0,
                      n_points=301, n_seeds=5, use_seed=None):
    """
    高分辨率扫描 + 多种子审计
    use_seed: 如果指定，只运行该种子（用于调试）
    """
    print("=" * 70)
    print("PXP 中心缺陷超高分辨率扫描")
    print(f"L={L}, 缺陷位置={defect_site}")
    print(f"μ扫描: [{mu_start}, {mu_end}], {n_points}点")
    print(f"种子数: {n_seeds}")
    print("=" * 70)
    
    # 预构建有效态和索引（只做一次）
    valid = generate_valid_states(L)
    state_to_idx = {s: i for i, s in enumerate(valid)}
    N_valid = len(valid)
    L_sub = L // 2
    print(f"有效态数量: {N_valid}")
    print(f"半链长度: {L_sub}")
    
    mu_vals = np.linspace(mu_start, mu_end, n_points)
    
    all_enhanced = []
    all_default = []
    
    for seed in range(n_seeds):
        np.random.seed(seed)
        print(f"\n种子 {seed} 开始...")
        enhanceds = []
        defaults = []
        
        start_time = time.time()
        for idx, mu in enumerate(mu_vals):
            H = build_pxp_hamiltonian_sparse(valid, state_to_idx, L, mu, defect_site)
            
            # 独立随机初始向量
            v0 = np.random.randn(N_valid)
            v0 /= np.linalg.norm(v0)
            
            evals, evecs = eigsh(H, k=1, which='SA', v0=v0)
            psi = evecs[:, 0]
            
            ent_std = compute_enhanced(psi, L_sub, valid, state_to_idx)
            mean_corr = compute_default(psi, L, valid, state_to_idx)
            
            enhanceds.append(ent_std)
            defaults.append(mean_corr)
            
            if (idx + 1) % 50 == 0:
                elapsed = time.time() - start_time
                print(f"  [{idx+1}/{n_points}] μ={mu:.2f}: enhanced={ent_std:.6f}, "
                      f"default={mean_corr:.6f} (elapsed {elapsed:.0f}s)")
        
        enhanceds = np.array(enhanceds)
        defaults = np.array(defaults)
        all_enhanced.append(enhanceds)
        all_default.append(defaults)
        
        # 检测该种子中的最强非单调特征
        # 计算一阶差分
        diff = np.diff(enhanceds)
        max_jump_idx = np.argmax(np.abs(diff))
        max_jump = diff[max_jump_idx]
        print(f"  种子{seed}完成: 最大一阶差分 {max_jump:.6f} at μ≈{mu_vals[max_jump_idx]:.3f}")
    
    # =============================================
    # 统计汇总
    # =============================================
    print("\n" + "=" * 70)
    print("统计汇总")
    print("=" * 70)
    
    enhanced_array = np.array(all_enhanced)
    default_array = np.array(all_default)
    mean_enhanced = enhanced_array.mean(axis=0)
    std_enhanced = enhanced_array.std(axis=0)
    mean_default = default_array.mean(axis=0)
    
    print(f"\n增强诊断平均值范围: [{mean_enhanced.min():.6f}, {mean_enhanced.max():.6f}]")
    print(f"增强诊断跨种子标准差: 均值={std_enhanced.mean():.6f}, "
          f"最大={std_enhanced.max():.6f} at μ={mu_vals[np.argmax(std_enhanced)]:.3f}")
    print(f"默认诊断平均值范围: [{mean_default.min():.6f}, {mean_default.max():.6f}]")
    
    # 检测平均曲线上的非单调特征
    diff_mean = np.diff(mean_enhanced)
    # 找所有大于3倍标准差的跳变
    threshold = 3 * np.std(diff_mean)
    significant_jumps = []
    for i in range(len(diff_mean)):
        if abs(diff_mean[i]) > threshold:
            significant_jumps.append((mu_vals[i], diff_mean[i]))
    
    if significant_jumps:
        print(f"\n检测到 {len(significant_jumps)} 个超过3σ的跳变:")
        for mu, jump in significant_jumps[:10]:
            print(f"  μ={mu:.3f}: Δ={jump:.6f}")
    else:
        print("\n未检测到超过3σ的跳变")
    
    # 保存数据
    output_dir = 'pxp_highres_audit'
    os.makedirs(output_dir, exist_ok=True)
    
    # 保存汇总数据
    np.savetxt(f'{output_dir}/mu_vals.csv', mu_vals, delimiter=',', header='mu', comments='')
    np.savetxt(f'{output_dir}/mean_enhanced.csv', mean_enhanced, delimiter=',', header='mean_enhanced', comments='')
    np.savetxt(f'{output_dir}/std_enhanced.csv', std_enhanced, delimiter=',', header='std_enhanced', comments='')
    np.savetxt(f'{output_dir}/mean_default.csv', mean_default, delimiter=',', header='mean_default', comments='')
    
    # 保存各种子完整数据
    for seed in range(n_seeds):
        np.savetxt(f'{output_dir}/enhanced_seed{seed}.csv', all_enhanced[seed], delimiter=',', header='enhanced', comments='')
        np.savetxt(f'{output_dir}/default_seed{seed}.csv', all_default[seed], delimiter=',', header='default', comments='')
    
    # 绘图
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    
    # 图1: 所有种子的增强诊断
    for seed in range(n_seeds):
        axes[0,0].plot(mu_vals, all_enhanced[seed], '-', lw=0.8, alpha=0.7, label=f'Seed {seed}')
    axes[0,0].plot(mu_vals, mean_enhanced, 'k-', lw=2, label='Mean')
    axes[0,0].set_xlabel('μ')
    axes[0,0].set_ylabel('Enhanced diagnosis')
    axes[0,0].set_title('All Seeds: Enhanced Diagnosis')
    axes[0,0].legend(fontsize=7)
    axes[0,0].grid(True, alpha=0.3)
    
    # 图2: 平均增强诊断 + 3σ区间
    axes[0,1].plot(mu_vals, mean_enhanced, 'k-', lw=2)
    axes[0,1].fill_between(mu_vals, mean_enhanced - 3*std_enhanced, 
                           mean_enhanced + 3*std_enhanced, alpha=0.3, color='gray')
    axes[0,1].set_xlabel('μ')
    axes[0,1].set_ylabel('Mean enhanced diagnosis')
    axes[0,1].set_title('Mean ± 3σ')
    axes[0,1].grid(True, alpha=0.3)
    
    # 图3: 默认诊断
    axes[1,0].plot(mu_vals, mean_default, 'b-', lw=2)
    axes[1,0].set_xlabel('μ')
    axes[1,0].set_ylabel('Default diagnosis')
    axes[1,0].set_title('Mean Default Diagnosis')
    axes[1,0].grid(True, alpha=0.3)
    
    # 图4: 一阶差分
    axes[1,1].plot(mu_vals[:-1], diff_mean, 'r-', lw=1)
    axes[1,1].axhline(y=0, color='black', lw=1, ls='--')
    axes[1,1].axhline(y=threshold, color='orange', lw=1, ls='--', label=f'3σ={threshold:.6f}')
    axes[1,1].axhline(y=-threshold, color='orange', lw=1, ls='--')
    axes[1,1].set_xlabel('μ')
    axes[1,1].set_ylabel('First derivative')
    axes[1,1].set_title('First Derivative of Mean Enhanced Diagnosis')
    axes[1,1].legend(fontsize=8)
    axes[1,1].grid(True, alpha=0.3)
    
    plt.suptitle(f'PXP L={L} High-Resolution Audit (defect site {defect_site})', fontsize=14)
    plt.tight_layout()
    plt.savefig(f'{output_dir}/highres_audit.png', dpi=150)
    print(f"\n图表已保存: {output_dir}/highres_audit.png")
    print(f"所有数据已保存至: {output_dir}/")
    
    return mu_vals, mean_enhanced, std_enhanced, mean_default, all_enhanced, all_default

if __name__ == "__main__":
    # 合理补充1：中心位置超高分辨率+5种子
    run_highres_audit(
        L=18, 
        defect_site=9, 
        mu_start=0.0, 
        mu_end=3.0, 
        n_points=301, 
        n_seeds=5
    )