"""
马拉特隧穿实验 —— 金箍棒 3.0 DMRG（API 修复版）
研究结构隧穿：d(t)的尖峰是否出现在fine的峰值之前？
加入纵向磁场打破Sz守恒，验证默认诊断的盲视性。
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tenpy.models.model import CouplingMPOModel
from tenpy.models.lattice import Chain
from tenpy.networks.site import SpinHalfSite
from tenpy.networks.mps import MPS
from tenpy.algorithms import dmrg

class TunnelingModel(CouplingMPOModel):
    """链式Heisenberg模型 + 纵向磁场，矛盾边位置和强度可独立设置"""
    def __init__(self, model_params):
        L = model_params.get('L', 10)
        self.contradiction_strength = model_params.get('contradiction_strength', 0.5)
        self.contradiction_edge = model_params.get('contradiction_edge', (L//2 - 1, L//2))
        self.hz = model_params.get('hz', 0.0)  # 纵向磁场强度
        lat = Chain(L, SpinHalfSite(conserve=None), bc='open')  # 不守恒Sz
        model_params['lattice'] = lat
        CouplingMPOModel.__init__(self, model_params)

    def init_terms(self, model_params=None):
        if model_params is None:
            model_params = {}
        L = self.lat.N_sites
        # 构建耦合强度数组（与 destiny_test.py 一致的数组形式）
        J_arr = np.ones(L - 1)
        edge_i, edge_j = self.contradiction_edge
        if 0 <= edge_i < L - 1:
            J_arr[edge_i] = self.contradiction_strength
        # XX+YY 项 (非对角)
        self.add_coupling(J_arr * 0.5, 0, 'Sp', 0, 'Sm', dx=[1], plus_hc=True)
        # ZZ 项 (对角)
        self.add_coupling(J_arr, 0, 'Sz', 0, 'Sz', dx=[1])
        # 纵向磁场（破缺项）
        for i in range(L):
            self.add_onsite_term(-self.hz, i, 'Sz')


def compute_diagnostics(L, contradiction_edge, s, hz, chi_max=100):
    """用DMRG计算基态，返回能隙、默认诊断、精细诊断和边关联涨落列表"""
    M = TunnelingModel(dict(
        L=L, contradiction_edge=contradiction_edge,
        contradiction_strength=s, hz=hz,
        bc_MPS='finite', conserve=None  # 不守恒Sz
    ))
    init = ['up', 'down'] * (L // 2)
    if L % 2 == 1: init.append('up')
    psi = MPS.from_product_state(M.lat.mps_sites(), init, bc='finite')
    dmrg_params = {'mixer': True, 'chi_max': chi_max, 'max_sweeps': 50, 'verbose': 0}
    eng = dmrg.run(psi, M, dmrg_params)
    E0 = eng['E']
    
    init_ex = init.copy()
    center = L // 2
    init_ex[center] = 'down' if init_ex[center] == 'up' else 'up'
    psi_ex = MPS.from_product_state(M.lat.mps_sites(), init_ex, bc='finite')
    eng_ex = dmrg.run(psi_ex, M, dmrg_params)
    E1 = eng_ex['E']
    gap = E1 - E0

    Sz = psi.expectation_value('Sz')
    coarse = np.mean(np.abs(Sz))
    
    corrs = []
    for i in range(L - 1):
        corr = psi.correlation_function('Sz', 'Sz', [i], [i+1])
        corrs.append(corr[0])
    fine = np.std(corrs) if corrs else 0.0
    
    return gap, coarse, fine, corrs


def find_max_correlation_edge(corrs):
    """找到关联涨落最大的边"""
    abs_corrs = np.abs(corrs)
    max_idx = np.argmax(abs_corrs)
    return (max_idx, max_idx + 1)


def run_tunneling_experiment(L=10, fold_steps=30, contradiction_strength=0.5, 
                            hz=0.1, epsilon=0.1, seed=42, chi_max=100):
    """
    马拉特隧穿实验：
    自折叠 + 纵向磁场 + 随机探索。
    记录每一步的(gap, coarse, fine)，用于后续计算位移向量d(t)。
    """
    np.random.seed(seed)
    gaps, coarse_vals, fine_vals = [], [], []
    fold_path = []
    
    current_edge = (L//2 - 1, L//2)
    print(f"初始矛盾边: {current_edge}, hz={hz}, epsilon={epsilon}")
    
    for step in range(fold_steps):
        gap, coarse, fine, corrs = compute_diagnostics(L, current_edge, contradiction_strength, hz, chi_max)
        gaps.append(gap)
        coarse_vals.append(coarse)
        fine_vals.append(fine)
        fold_path.append(current_edge)
        
        # 选择下一步：以概率epsilon随机，否则选最大涨落边
        if np.random.random() < epsilon:
            # 随机探索：随机选一条边（共L-1条边）
            next_idx = np.random.randint(0, L - 1)
            next_edge = (next_idx, next_idx + 1)
        else:
            next_edge = find_max_correlation_edge(corrs)
        
        print(f"Step {step}: edge={current_edge}, gap={gap:.6f}, coarse={coarse:.4f}, fine={fine:.6f}, next→{next_edge}")
        current_edge = next_edge
    
    return np.array(gaps), np.array(coarse_vals), np.array(fine_vals), fold_path


if __name__ == "__main__":
    L = 10
    fold_steps = 30
    contradiction_strength = 0.5
    hz = 0.1
    epsilon_values = [0.10, 0.15, 0.20, 0.25, 0.30]
    seeds = [42, 43, 44, 45, 46]  # 每个ε用不同种子
    
    all_results = {}
    
    for epsilon, seed in zip(epsilon_values, seeds):
        print(f"\n{'='*60}")
        print(f"=== 马拉特隧穿实验 (L={L}, hz={hz}, epsilon={epsilon}) ===")
        print(f"检验：d(t)的尖峰是否出现在fine的峰值之前")
        print(f"{'='*60}\n")
        
        gaps, coarse_vals, fine_vals, fold_path = run_tunneling_experiment(
            L, fold_steps, contradiction_strength, hz, epsilon, seed, chi_max=100
        )
        
        # 保存每个ε的原始数据
        np.savetxt(f'marat_tunneling_epsilon_{epsilon:.2f}.csv',
                   np.column_stack((np.arange(fold_steps), gaps, coarse_vals, fine_vals)),
                   header='step,gap,coarse,fine', delimiter=',')
        
        # 保存折叠路径
        with open(f'marat_tunneling_path_epsilon_{epsilon:.2f}.txt', 'w') as f:
            f.write("step,edge_i,edge_j\n")
            for step, (i, j) in enumerate(fold_path):
                f.write(f"{step},{i},{j}\n")
        
        # 计算位移向量d(t)
        d_t = np.zeros(fold_steps)
        for t in range(1, fold_steps):
            delta = np.array([gaps[t] - gaps[t-1], 
                              coarse_vals[t] - coarse_vals[t-1], 
                              fine_vals[t] - fine_vals[t-1]])
            d_t[t] = np.sqrt(np.sum(delta**2))
        
        # 寻找d(t)的局部峰值
        d_peaks = []
        for t in range(2, fold_steps - 2):
            if d_t[t] > d_t[t-1] and d_t[t] > d_t[t-2] and d_t[t] > d_t[t+1] and d_t[t] > d_t[t+2]:
                d_peaks.append(t)
        
        # 寻找fine的局部峰值
        fine_peaks = []
        for t in range(2, fold_steps - 2):
            if fine_vals[t] > fine_vals[t-1] and fine_vals[t] > fine_vals[t-2] and fine_vals[t] > fine_vals[t+1] and fine_vals[t] > fine_vals[t+2]:
                fine_peaks.append(t)
        
        # 检查d(t)峰值是否在fine峰值之前
        tunneling_events = []
        for fpeak in fine_peaks:
            preceding_d = [d for d in d_peaks if d < fpeak]
            if preceding_d:
                tunneling_events.append((preceding_d[-1], fpeak))
        
        all_results[epsilon] = {
            'd_peaks': d_peaks,
            'fine_peaks': fine_peaks,
            'tunneling_events': tunneling_events,
            'd_t': d_t,
            'fine_vals': fine_vals,
            'coarse_vals': coarse_vals,
            'gaps': gaps
        }
        
        print(f"\n=== ε={epsilon:.2f} 结构隧穿分析 ===")
        print(f"位移向量d(t)的峰值位置: {d_peaks}")
        print(f"增强诊断fine的峰值位置: {fine_peaks}")
        print(f"隧穿事件数量: {len(tunneling_events)}")
    
    # 保存ε阈值扫描汇总
    with open('epsilon_threshold_summary.csv', 'w') as f:
        f.write("epsilon,d_peak_count,fine_peak_count,tunneling_event_count\n")
        for eps, results in all_results.items():
            f.write(f"{eps:.2f},{len(results['d_peaks'])},{len(results['fine_peaks'])},{len(results['tunneling_events'])}\n")
    
    # 汇总图：ε阈值扫描
    fig, axes = plt.subplots(2, 3, figsize=(18, 10))
    
    for idx, (epsilon, results) in enumerate(all_results.items()):
        row = idx // 3
        col = idx % 3
        ax = axes[row, col]
        steps = np.arange(fold_steps)
        
        ax.plot(steps, results['fine_vals'], 's-', label='fine', color='#d62728')
        ax_right = ax.twinx()
        ax_right.plot(steps, results['d_t'], '^-', label='d(t)', color='#2ca02c', markersize=4)
        
        # 标注隧穿事件
        for d_p, f_p in results['tunneling_events']:
            ax.axvspan(d_p, f_p, alpha=0.15, color='orange')
        
        ax.set_title(f'ε = {epsilon:.2f} (events: {len(results["tunneling_events"])})')
        ax.set_xlabel('Step'); ax.set_ylabel('fine', color='#d62728')
        ax_right.set_ylabel('d(t)', color='#2ca02c')
        ax.grid(True, alpha=0.3)
    
    plt.suptitle(f'ε-Threshold Scan: d(t) vs fine (L={L}, hz={hz})')
    plt.tight_layout()
    plt.savefig('epsilon_threshold_scan.png', dpi=150)
    
    # 关键汇总图：隧穿事件数量 vs ε
    fig, ax = plt.subplots(figsize=(10, 6))
    eps_list = sorted(all_results.keys())
    event_counts = [len(all_results[e]['tunneling_events']) for e in eps_list]
    d_peak_counts = [len(all_results[e]['d_peaks']) for e in eps_list]
    
    ax.plot(eps_list, event_counts, 'o-', color='#d62728', lw=2, ms=8, label='Tunneling events')
    ax.plot(eps_list, d_peak_counts, 's-', color='#2ca02c', lw=2, ms=8, label='d(t) peaks')
    ax.set_xlabel('ε (exploration probability)'); ax.set_ylabel('Count')
    ax.set_title('ε-Threshold: d(t) Peak Count vs Tunneling Events')
    ax.legend(); ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('epsilon_threshold_summary.png', dpi=150)
    
    print("\n=== ε阈值扫描汇总 ===")
    for eps in eps_list:
        print(f"ε={eps:.2f}: d(t)峰值={len(all_results[eps]['d_peaks'])}, fine峰值={len(all_results[eps]['fine_peaks'])}, 隧穿事件={len(all_results[eps]['tunneling_events'])}")
    
    print("\nDone. 全部数据已保存。")
