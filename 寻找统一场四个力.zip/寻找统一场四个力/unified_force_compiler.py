"""
统一力场关系编译器 —— 金箍棒 4.0
检验：四大基本力是否可统一为同一种底层关系动力学在不同ε下的四种稳定模式？
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tenpy.models.model import CouplingMPOModel
from tenpy.models.lattice import Chain
from tenpy.networks.site import SpinHalfSite
from tenpy.networks.mps import MPS
from tenpy.algorithms import dmrg

class UnifiedForceModel(CouplingMPOModel):
    """统一力场模型：同一张关系图 + 同一套编译规则 + 不同随机探索强度ε"""
    def __init__(self, model_params):
        L = model_params.get('L', 12)
        self.rule = model_params.get('rule', 'heisenberg')
        self.delta = model_params.get('delta', 1.0)
        self.D = model_params.get('D', 0.0)
        self.epsilon = model_params.get('epsilon', 0.0)
        self.contradiction_edge = model_params.get('contradiction_edge', (L//2 - 1, L//2))
        self.contradiction_strength = model_params.get('contradiction_strength', 1.0)
        if self.epsilon > 0 and np.random.random() < self.epsilon:
            all_edges = [(i, i+1) for i in range(L-1)]
            self.contradiction_edge = all_edges[np.random.randint(0, len(all_edges))]
        lat = Chain(L, SpinHalfSite(conserve='Sz'), bc='open')
        model_params['lattice'] = lat
        CouplingMPOModel.__init__(self, model_params)

    def init_terms(self, model_params=None):
        if model_params is None:
            model_params = {}
        L = self.lat.N_sites
        for i in range(L-1):
            if (i, i+1) == self.contradiction_edge or (i+1, i) == self.contradiction_edge:
                J = self.contradiction_strength
            else:
                J = 1.0
            if self.rule in ['heisenberg', 'xy', 'xxz']:
                self.add_coupling_term(J * 0.5, i, i+1, 'Sp', 'Sm', plus_hc=True)
            if self.rule in ['heisenberg', 'ising', 'xxz']:
                zz = self.delta if self.rule == 'xxz' else 1.0
                self.add_coupling_term(J * zz, i, i+1, 'Sz', 'Sz')
            if self.D != 0.0:
                self.add_coupling_term(self.D * 0.5, i, i+1, 'Sz', 'Sp', plus_hc=True)
                self.add_coupling_term(-self.D * 0.5, i, i+1, 'Sz', 'Sm', plus_hc=True)


def compute_force_diagnostics(L, contradiction_edge, s, epsilon=0.0, rule='heisenberg', D=0.0, chi_max=100):
    """计算关联衰减斜率、相位相干长度、局域化深度"""
    n_folds = 10
    correlation_decays, coherence_lengths, localization_depths = [], [], []
    current_edge = contradiction_edge
    for fold in range(n_folds):
        M = UnifiedForceModel(dict(L=L, contradiction_edge=current_edge,
            contradiction_strength=s, epsilon=epsilon, rule=rule, D=D,
            bc_MPS='finite', conserve='Sz'))
        init = ['up', 'down'] * (L // 2)
        if L % 2 == 1: init.append('up')
        psi = MPS.from_product_state(M.lat.mps_sites(), init, bc='finite')
        dmrg_params = {'mixer': True, 'chi_max': chi_max, 'max_sweeps': 50, 'verbose': 0}
        eng = dmrg.run(psi, M, dmrg_params)
        corr_dist = []
        for r in range(1, L):
            corr = psi.correlation_function('Sz', 'Sz', [0], [r])
            corr_dist.append(abs(corr[0, 0]))
        corr_dist = np.array(corr_dist)
        valid = corr_dist > 1e-10
        if np.sum(valid) >= 3:
            r_vals = np.arange(1, L)[valid]
            log_corr = np.log(corr_dist[valid])
            slope, _ = np.polyfit(r_vals, log_corr, 1)
            correlation_decays.append(slope)
        sign_changes = np.where(np.diff(np.sign(corr_dist)))[0]
        if len(sign_changes) > 0:
            coherence_lengths.append(sign_changes[0] + 1)
        max_corr = np.max(corr_dist)
        if max_corr > 0:
            threshold = 0.1 * max_corr
            localized = np.where(corr_dist < threshold)[0]
            if len(localized) > 0:
                localization_depths.append(localized[0] + 1)
        corrs_local = []
        for i in range(L - 1):
            corr = psi.correlation_function('Sz', 'Sz', [i], [i+1])
            corrs_local.append(abs(corr[0, 0]))
        max_idx = np.argmax(corrs_local)
        current_edge = (max_idx, max_idx + 1)
    return {
        'decay_mean': np.mean(correlation_decays) if correlation_decays else np.nan,
        'decay_std': np.std(correlation_decays) if correlation_decays else np.nan,
        'coherence_mean': np.mean(coherence_lengths) if coherence_lengths else np.nan,
        'coherence_std': np.std(coherence_lengths) if coherence_lengths else np.nan,
        'localization_mean': np.mean(localization_depths) if localization_depths else np.nan,
        'localization_std': np.std(localization_depths) if localization_depths else np.nan,
        'n_folds': n_folds, 'epsilon': epsilon
    }


def scan_epsilon_phase_diagram(L=12, s=1.0, epsilon_values=None, rule='heisenberg', chi_max=100):
    """扫描ε参数，构建统一力场相图"""
    if epsilon_values is None:
        epsilon_values = [0.0, 0.05, 0.10, 0.20, 0.30, 0.50, 0.70]
    contradiction_edge = (L//2 - 1, L//2)
    results = []
    print(f"=== 统一力场相图扫描 (L={L}, s={s}) ===")
    for eps in epsilon_values:
        np.random.seed(42)
        print(f"\nε = {eps:.2f}")
        diag = compute_force_diagnostics(L, contradiction_edge, s, epsilon=eps, rule=rule, chi_max=chi_max)
        results.append(diag)
        print(f"  关联衰减斜率: {diag['decay_mean']:.4f} ± {diag['decay_std']:.4f}")
        print(f"  相位相干长度: {diag['coherence_mean']:.2f} ± {diag['coherence_std']:.2f}")
        print(f"  局域化深度: {diag['localization_mean']:.2f} ± {diag['localization_std']:.2f}")
    return epsilon_values, results


def diagnose_four_forces(epsilon_values, results):
    """诊断四种力是否在不同ε区间涌现（启发式标准）"""
    print("\n=== 四种力涌现诊断 ===")
    decays = [r['decay_mean'] for r in results]
    coherences = [r['coherence_mean'] for r in results]
    localizations = [r['localization_mean'] for r in results]
    valid_decays = [(i, d) for i, d in enumerate(decays) if not np.isnan(d)]
    valid_coherences = [(i, c) for i, c in enumerate(coherences) if not np.isnan(c)]
    valid_localizations = [(i, l) for i, l in enumerate(localizations) if not np.isnan(l)]
    print(f"有效衰减数据点: {len(valid_decays)}/{len(decays)}")
    print(f"有效相干数据点: {len(valid_coherences)}/{len(coherences)}")
    print(f"有效局域化数据点: {len(valid_localizations)}/{len(localizations)}")
    if len(valid_decays) >= 4:
        decay_range = max(decays) - min(decays)
        if decay_range > 1.0:
            print("关联衰减跨度 > 1.0：四种力可能对应不同的衰减模式")
    if len(valid_coherences) >= 4:
        coh_range = max(coherences) - min(coherences)
        if coh_range > 2.0:
            print("相位相干跨度 > 2.0：四种力可能对应不同的相干特征")
    print("注：以上诊断基于启发式标准，不构成对统一四力的证明或否证。")
    print("本实验的目的不是'验证统一四力'，而是'检验统一四力作为ε-相图涌现模式的可行性'。")


if __name__ == "__main__":
    L = 12
    s = 1.0
    epsilon_values = [0.0, 0.05, 0.10, 0.20, 0.30, 0.50, 0.70]

    eps_vals, results = scan_epsilon_phase_diagram(L, s, epsilon_values, rule='heisenberg', chi_max=100)

    with open('unified_force_phase_diagram.csv', 'w') as f:
        f.write('epsilon,decay_mean,decay_std,coherence_mean,coherence_std,localization_mean,localization_std\n')
        for eps, r in zip(eps_vals, results):
            f.write(f"{eps:.2f},{r['decay_mean']:.6f},{r['decay_std']:.6f},{r['coherence_mean']:.6f},{r['coherence_std']:.6f},{r['localization_mean']:.6f},{r['localization_std']:.6f}\n")

    diagnose_four_forces(eps_vals, results)

    decays = [r['decay_mean'] for r in results]
    coherences = [r['coherence_mean'] for r in results]
    localizations = [r['localization_mean'] for r in results]

    fig, axes = plt.subplots(1, 3, figsize=(18, 5))

    axes[0].plot(eps_vals, decays, 'o-', color='#1f77b4', lw=2, ms=8)
    axes[0].set_xlabel('ε (random exploration strength)')
    axes[0].set_ylabel('Correlation decay slope')
    axes[0].set_title('Force 1: Correlation Decay (Gravity-like vs Strong-like)')
    axes[0].grid(True, alpha=0.3)

    axes[1].plot(eps_vals, coherences, 's-', color='#d62728', lw=2, ms=8)
    axes[1].set_xlabel('ε (random exploration strength)')
    axes[1].set_ylabel('Phase coherence length')
    axes[1].set_title('Force 2: Phase Coherence (EM-like)')
    axes[1].grid(True, alpha=0.3)

    axes[2].plot(eps_vals, localizations, '^-', color='#2ca02c', lw=2, ms=8)
    axes[2].set_xlabel('ε (random exploration strength)')
    axes[2].set_ylabel('Localization depth')
    axes[2].set_title('Force 3: Localization (Strong-like confinement)')
    axes[2].grid(True, alpha=0.3)

    plt.suptitle(f'Unified Force Field Phase Diagram (L={L}, Heisenberg)')
    plt.tight_layout()
    plt.savefig('unified_force_phase_diagram.png', dpi=150)

    print("\nDone. 统一力场相图已保存。")
