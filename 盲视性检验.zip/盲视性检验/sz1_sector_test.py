"""
Sz=1 扇区沉默失谐诊断 (稳健版)
检验：默认诊断的盲视性是否由 Sz=0 扇区的对称性锁死？
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tenpy.models.model import CouplingMPOModel
from tenpy.models.lattice import Chain
from tenpy.networks.site import SpinHalfSite
from tenpy.networks.mps import MPS
from tenpy.algorithms import dmrg

class SzSectorModel(CouplingMPOModel):
    """链式Heisenberg模型，矛盾边强度可独立设置"""
    def __init__(self, model_params):
        # 确保 'lattice' 参数存在
        if 'lattice' not in model_params:
            L = model_params.get('L', 8)
            site = SpinHalfSite(conserve='Sz')
            lat = Chain(L, site, bc='open')
            model_params['lattice'] = lat
        
        self.contradiction_strength = model_params.get('contradiction_strength', 1.0)
        self.contradiction_edge = model_params.get('contradiction_edge', (0, 1))
        
        # 预计算所有最近邻键的强度数组
        L = model_params.get('L', 8)
        J_vals = np.ones(L - 1)
        ci, cj = self.contradiction_edge
        # 矛盾边在数组中的位置（键 (i,i+1) 对应数组索引 i）
        if ci < L - 1 and cj == ci + 1:
            J_vals[ci] = self.contradiction_strength
        
        self.J_vals = J_vals
        
        CouplingMPOModel.__init__(self, model_params)

    def init_terms(self, model_params=None):
        L = self.lat.N_sites
        # Heisenberg 项：XX+YY (使用数组形式的强度，unit_cell=0，dx=[1])
        self.add_coupling(self.J_vals * 0.5, 0, 'Sp', 0, 'Sm', dx=[1], plus_hc=True)
        # Heisenberg 项：ZZ (同样使用数组形式)
        self.add_coupling(self.J_vals, 0, 'Sz', 0, 'Sz', dx=[1])


def run_sz_sector_scan(L, contradiction_edge, s_values, target_sz=0, chi_max=100):
    """扫描矛盾强度，返回诊断数据"""
    gaps, coarse_vals, fine_vals = [], [], []
    print(f"\n=== Sz={target_sz} 扇区扫描 ===")
    
    for s in s_values:
        # 构建参数
        model_params = {
            'L': L,
            'lattice': Chain(L, SpinHalfSite(conserve='Sz'), bc='open'),
            'contradiction_edge': contradiction_edge,
            'contradiction_strength': s,
            'bc_MPS': 'finite',
            'conserve': 'Sz'
        }
        M = SzSectorModel(model_params)
        
        # 构造指定Sz的初态
        if target_sz == 0:
            init = ['up', 'down'] * (L // 2)
            if L % 2 == 1: init.append('up')
        elif target_sz == 1:
            init = ['up', 'down'] * (L // 2)
            if L % 2 == 1: init.append('up')
            # 确保净Sz=1
            init[-1] = 'up' if init[-1] == 'down' else 'down'
        
        psi = MPS.from_product_state(M.lat.mps_sites(), init, bc='finite')
        dmrg_params = {'mixer': True, 'chi_max': chi_max, 'max_sweeps': 50, 'verbose': 0}
        
        eng = dmrg.run(psi, M, dmrg_params)
        E0 = eng['E']
        
        # 激发态
        init_ex = init.copy()
        center = L // 2
        init_ex[center] = 'down' if init_ex[center] == 'up' else 'up'
        psi_ex = MPS.from_product_state(M.lat.mps_sites(), init_ex, bc='finite')
        eng_ex = dmrg.run(psi_ex, M, dmrg_params)
        E1 = eng_ex['E']
        gap = E1 - E0

        # 诊断
        Sz_exp = psi.expectation_value('Sz')
        coarse = np.mean(np.abs(Sz_exp))
        corrs = []
        for i in range(L - 1):
            corr = psi.correlation_function('Sz', 'Sz', [i], [i+1])
            corrs.append(corr[0])
        fine = np.std(corrs) if corrs else 0.0
        
        gaps.append(gap); coarse_vals.append(coarse); fine_vals.append(fine)
        print(f"s={s:.2f}: gap={gap:.6f}, coarse={coarse:.4f}, fine={fine:.4f}")
    
    return np.array(s_values), np.array(gaps), np.array(coarse_vals), np.array(fine_vals)


if __name__ == "__main__":
    L = 8
    contradiction_edge = (L//2 - 1, L//2)  # (3,4)
    s_values = np.linspace(0.0, 3.0, 13)
    
    # Sz=0 扇区（基准）
    s0, gaps0, coarse0, fine0 = run_sz_sector_scan(L, contradiction_edge, s_values, target_sz=0, chi_max=100)
    
    # Sz=1 扇区（检验盲视性）
    s1, gaps1, coarse1, fine1 = run_sz_sector_scan(L, contradiction_edge, s_values, target_sz=1, chi_max=100)
    
    # 保存数据
    np.savetxt('sz0_sector.csv', np.column_stack((s0, gaps0, coarse0, fine0)), header='s,gap,coarse,fine', delimiter=',')
    np.savetxt('sz1_sector.csv', np.column_stack((s1, gaps1, coarse1, fine1)), header='s,gap,coarse,fine', delimiter=',')
    
    # 对比图
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
    
    ax1.plot(s0, fine0, 'o-', label='Sz=0', color='#1f77b4', lw=2, ms=6)
    ax1.plot(s1, fine1, 's-', label='Sz=1', color='#d62728', lw=2, ms=6)
    ax1.set_xlabel('Contradiction strength s'); ax1.set_ylabel('Enhanced diagnosis (fine)')
    ax1.set_title('Enhanced Diagnosis: Sz=0 vs Sz=1'); ax1.legend(); ax1.grid(True, alpha=0.3)
    
    ax2.plot(s0, coarse0, 'o-', label='Sz=0', color='#1f77b4', lw=2, ms=6)
    ax2.plot(s1, coarse1, 's-', label='Sz=1', color='#d62728', lw=2, ms=6)
    ax2.set_xlabel('Contradiction strength s'); ax2.set_ylabel('Default diagnosis (coarse)')
    ax2.set_title('Default Diagnosis: Sz=0 vs Sz=1'); ax2.legend(); ax2.grid(True, alpha=0.3)
    
    plt.suptitle(f'Sz-Sector Blindness Test (N={L}, Heisenberg)')
    plt.tight_layout(); plt.savefig('sz_sector_test.png', dpi=150)
    
    # 定量对比
    print("\n=== 盲视性检验 ===")
    coarse_diff = np.abs(coarse0 - coarse1)
    max_diff = np.max(coarse_diff)
    print(f"Sz=0与Sz=1默认诊断的最大偏差: {max_diff:.6f}")
    if max_diff < 0.01:
        print("结论: 默认诊断在Sz=1扇区内仍然盲视 → 盲视性是沉默失谐的真实特征")
    else:
        print("结论: 默认诊断在Sz=1扇区内不再盲视 → Sz=0扇区的零是对称性锁死")
    
    print("\nDone.")