"""
边(8,14)与边(6,11)重生成_双视角并置.py

实验目的：
    重新生成随机图边(8,14)和(6,11)的数据，并解决以下问题：
    山谷数值是由关系场整体结构唯一决定，还是依赖于观测者在简并流形中的基态选择？

两种视角并排放置：

    标准物理视角（投影平均）：
        将简并流形中所有基态等权混合，得到一个确定的密度矩阵。
        这是标准物理为解决简并态“任意性”而采用的方法。
        输出：投影平均后的 E(s) 曲线和谷底参数。

    理论精髓视角（原始多种子）：
        每个 Lanczos 种子返回简并流形中的一个方向。
        不同种子看到的山谷可能不同。这种多样性本身是真相的一部分。
        输出：每个种子的原始 E(s) 曲线、所有谷底参数，不做平均、不筛除。

理论精髓落实：
    - 关系本体论：山谷是否唯一，取决于关系场的结构，而非我们是否平均。
    - 实践介入论：投影平均是一种介入，多种子不平均也是一种介入。两者并列。
    - 谐振调谐论：不预设哪种视角“更正确”。让数据说话。
    - 元反思律：如果原始多种子显示多样性，而投影平均抹平了它，那么
      之前用投影平均解决“稳定性”的做法就存在对齐嫌疑，必须诚实记录。

输出：
    regenerated_edges_dual_view.json
"""

import numpy as np
import networkx as nx
import itertools
from scipy.sparse import lil_matrix, csr_matrix
from scipy.sparse.linalg import eigsh
import json
import warnings
warnings.filterwarnings('ignore')

# ========== 参数 ==========
N = 15
S_VALUES = np.linspace(0.0, 2.0, 41)  # 41点 [0,2]，步长0.05
EPS_DEGEN = 1e-8
N_EIGS = 6
N_V0 = 5  # 多种子，让多样性有机会显现

def generate_random_N15(seed=42):
    """生成与论文一致的随机图（N=15，27条边）"""
    G = nx.gnm_random_graph(15, 27, seed=seed)
    G = nx.relabel_nodes(G, {old: new for new, old in enumerate(G.nodes())})
    return [tuple(sorted(e)) for e in G.edges()]

def build_hamiltonian_sector(N, edges, J_vals, N_up):
    """构建固定 S_z 扇区的哈密顿量"""
    basis = list(itertools.combinations(range(N), N_up))
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = lil_matrix((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, st in enumerate(basis):
            si = 1 if i in st else -1
            sj = 1 if j in st else -1
            H[idx, idx] += J * si * sj
        for idx, st in enumerate(basis):
            i_up = i in st
            j_up = j in st
            if i_up and not j_up:
                ns = list(st); ns.remove(i); ns.append(j)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2.0 * J
            elif j_up and not i_up:
                ns = list(st); ns.remove(j); ns.append(i)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2.0 * J
    return csr_matrix(H), basis

def lanczos_sa_multi(H, n_eigs=6, v0_seed=0, maxiter=10000):
    """SA模式 Lanczos，求前 n_eigs 个本征态"""
    dim = H.shape[0]
    if dim == 0:
        return None, None, False
    rng = np.random.default_rng(v0_seed)
    v0 = rng.standard_normal(dim)
    k = min(n_eigs, dim)
    try:
        evals, evecs = eigsh(H, k=k, which='SA', v0=v0, maxiter=maxiter, tol=1e-9)
        idx = np.argsort(evals)
        return evals[idx], evecs[:, idx], True
    except Exception:
        return None, None, False

def prescan_degenerate_sectors(N, edges, J_vals):
    """扫描全部扇区，找到全局最低能量和简并扇区列表"""
    sector_energies = {}
    for N_up in range(N+1):
        H, basis = build_hamiltonian_sector(N, edges, J_vals, N_up)
        if H.shape[0] == 0:
            continue
        dim = H.shape[0]
        if dim <= 2000:
            evals = np.linalg.eigh(H.toarray())[0]
            E0 = evals[0]
        else:
            evals, evecs, ok = lanczos_sa_multi(H, n_eigs=1, v0_seed=0)
            if not ok:
                sector_energies[N_up] = np.inf
                continue
            E0 = evals[0]
        sector_energies[N_up] = E0
    if not sector_energies:
        return [], np.inf
    min_E = min(sector_energies.values())
    degen = [nup for nup, E in sector_energies.items() if abs(E-min_E) < EPS_DEGEN]
    return degen, min_E

def compute_fine_projected(N, edges, J_vals, degen_sectors, v0_seed=0):
    """
    标准物理视角：投影平均。
    对简并流形中所有态等权平均，得到一个确定的 fine 值。
    """
    n_edges = len(edges)
    corr_sum = np.zeros(n_edges)
    n_states = 0
    sector_evals = {}
    for N_up in degen_sectors:
        H, basis = build_hamiltonian_sector(N, edges, J_vals, N_up)
        if H.shape[0] == 0:
            continue
        dim = H.shape[0]
        if dim <= 2000:
            evals = np.linalg.eigh(H.toarray())[0]
            sector_evals[N_up] = evals
        else:
            evals, evecs, ok = lanczos_sa_multi(H, n_eigs=N_EIGS, v0_seed=v0_seed)
            if ok:
                sector_evals[N_up] = evals
    if not sector_evals:
        return None
    E0_local = min(evals[0] for evals in sector_evals.values())
    for N_up, evals in sector_evals.items():
        H, basis = build_hamiltonian_sector(N, edges, J_vals, N_up)
        if H.shape[0] == 0:
            continue
        dim = H.shape[0]
        if dim <= 2000:
            _, evecs = np.linalg.eigh(H.toarray())
            for idx, E in enumerate(evals):
                if abs(E - E0_local) < EPS_DEGEN:
                    psi = evecs[:, idx]
                    n_states += 1
                    for e_idx, (i, j) in enumerate(edges):
                        diag = np.array([(1 if i in st else -1)*(1 if j in st else -1) for st in basis])
                        corr_sum[e_idx] += np.sum(np.abs(psi)**2 * diag)
        else:
            _, evecs, ok = lanczos_sa_multi(H, n_eigs=N_EIGS, v0_seed=v0_seed)
            if not ok:
                continue
            for idx in range(len(evals)):
                if abs(evals[idx] - E0_local) < EPS_DEGEN:
                    psi = evecs[:, idx]
                    n_states += 1
                    for e_idx, (i, j) in enumerate(edges):
                        diag = np.array([(1 if i in st else -1)*(1 if j in st else -1) for st in basis])
                        corr_sum[e_idx] += np.sum(np.abs(psi)**2 * diag)
    if n_states == 0:
        return None
    corr_avg = corr_sum / n_states
    return np.std(corr_avg)

def compute_fine_raw_single(N, edges, J_vals, N_up, v0_seed=0):
    """
    理论精髓视角：原始单态。
    每个种子返回简并流形中的一个方向。
    不对简并态做任何平均。
    """
    H, basis = build_hamiltonian_sector(N, edges, J_vals, N_up)
    evals, evecs, ok = lanczos_sa_multi(H, n_eigs=1, v0_seed=v0_seed)
    if not ok:
        return None
    psi = evecs[:, 0]
    corrs = []
    for (i, j) in edges:
        diag = np.array([(1 if i in st else -1)*(1 if j in st else -1) for st in basis])
        corrs.append(np.sum(np.abs(psi)**2 * diag))
    return np.std(np.array(corrs))

def find_all_valleys(s_values, e_values):
    """找到所有内部极小值，包括负深度"""
    valid = np.where(~np.isnan(e_values))[0]
    if len(valid) < 3:
        return []
    valleys = []
    for idx in range(1, len(valid)-1):
        curr = valid[idx]
        if e_values[curr] < e_values[valid[idx-1]] and e_values[curr] < e_values[valid[idx+1]]:
            depth = e_values[valid[0]] - e_values[curr]
            valleys.append({
                's': float(s_values[curr]),
                'depth': float(depth),
                'type': 'internal_minimum' if depth > 0 else 'internal_minimum_negative_depth'
            })
    return valleys

def main():
    print("=== 边(8,14)与边(6,11)重生成：双视角并置 ===")
    print(f"网格：41点 [0,2]，步长0.05")
    print(f"多种子：{N_V0}个")
    print()

    edges = generate_random_N15(seed=42)
    print(f"边数：{len(edges)}")

    # 确认关键边存在
    target_edges = [(8,14), (6,11)]
    for e in target_edges:
        if e not in edges:
            print(f"警告：边 {e} 不在边列表中")

    # 预扫描确定简并扇区
    J_vals_probe = np.ones(len(edges))
    degen, E0 = prescan_degenerate_sectors(N, edges, J_vals_probe)
    print(f"简并扇区：{degen}")
    print(f"均匀点基态能量：{E0:.8f}\n")

    # 标准视角的固定扇区（取简并扇区列表中的第一个）
    N_up_projected = degen[0] if degen else N // 2

    results = {}

    for target_edge in target_edges:
        if target_edge not in edges:
            continue
        edge_idx = edges.index(target_edge)
        print(f"\n=== 边 {target_edge} ===")

        # ===== 标准物理视角：投影平均 =====
        print("标准物理视角（投影平均）：")
        J_vals = np.ones(len(edges))
        fine_projected_curve = np.full(len(S_VALUES), np.nan)
        for si, s in enumerate(S_VALUES):
            J_vals[edge_idx] = s
            fine = compute_fine_projected(N, edges, J_vals, degen, v0_seed=0)
            if fine is not None:
                fine_projected_curve[si] = fine
            J_vals[edge_idx] = 1.0

        valleys_projected = find_all_valleys(S_VALUES, fine_projected_curve)
        if valleys_projected:
            deepest = max(valleys_projected, key=lambda x: x['depth'])
            print(f"  最深谷底 s={deepest['s']:.2f}, 深度={deepest['depth']:.6f}, "
                  f"类型={deepest['type']}")
        else:
            print(f"  无内部极小值")

        # ===== 理论精髓视角：原始多种子 =====
        print(f"理论精髓视角（{N_V0}个原始种子，不平均）：")
        raw_seed_curves = []
        raw_seed_valleys = []
        for v0 in range(N_V0):
            J_vals = np.ones(len(edges))
            fine_raw = np.full(len(S_VALUES), np.nan)
            for si, s in enumerate(S_VALUES):
                J_vals[edge_idx] = s
                fine = compute_fine_raw_single(N, edges, J_vals, N_up_projected, v0_seed=v0)
                if fine is not None:
                    fine_raw[si] = fine
                J_vals[edge_idx] = 1.0

            valleys_raw = find_all_valleys(S_VALUES, fine_raw)
            raw_seed_curves.append(fine_raw.tolist())
            raw_seed_valleys.append({
                'v0_seed': v0,
                'valleys': valleys_raw
            })

            if valleys_raw:
                deepest_raw = max(valleys_raw, key=lambda x: x['depth'])
                print(f"  v0={v0}: 最深谷底 s={deepest_raw['s']:.2f}, "
                      f"深度={deepest_raw['depth']:.6f}, 类型={deepest_raw['type']}")
            else:
                print(f"  v0={v0}: 无内部极小值")

        results[str(target_edge)] = {
            'edge': list(target_edge),
            'edge_idx': edge_idx,
            'standard_physics_view': {
                'method': 'projection_average',
                'fine_curve': fine_projected_curve.tolist(),
                'valleys': valleys_projected
            },
            'theoretical_view': {
                'method': 'raw_single_states',
                'n_seeds': N_V0,
                'raw_curves': raw_seed_curves,
                'raw_valleys': raw_seed_valleys
            }
        }

    output = {
        'graph': 'random_graph_N15_seed42',
        's_values': S_VALUES.tolist(),
        'degen_sectors': degen,
        'N_up_projected': N_up_projected,
        'results': results
    }

    with open('regenerated_edges_dual_view.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)

    print("\n结果已保存至 regenerated_edges_dual_view.json")
    print("\n=== 判断要点 ===")
    print("1. 如果原始多种子的谷底深度与投影平均不同，说明简并流形中的方向选择影响显现。")
    print("2. 如果原始多种子之间有波动，说明山谷在简并流形中不是唯一的。")
    print("3. 投影平均抹平了这种多样性，这本身就是一个需要诚实记录的对齐操作。")

if __name__ == "__main__":
    main()