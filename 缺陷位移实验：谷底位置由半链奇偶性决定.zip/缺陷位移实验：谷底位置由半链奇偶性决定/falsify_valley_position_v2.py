"""
沉默失谐证伪探针 v2（温和版）
只诚实地报告谷底位置随系统尺寸的演化趋势，不做粗暴的"证伪"判定。
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tenpy.models.model import CouplingMPOModel
from tenpy.models.lattice import Chain
from tenpy.networks.site import SpinHalfSite
from tenpy.networks.mps import MPS
from tenpy.algorithms import dmrg

class ChainModel(CouplingMPOModel):
    def __init__(self, model_params):
        L = model_params.get('L', 6)
        self.contradiction_strength = model_params.get('contradiction_strength', 1.0)
        self.contradiction_edge = model_params.get('contradiction_edge', (L//2 - 1, L//2))
        # 预计算所有最近邻键的强度数组
        J_vals = np.ones(L - 1)
        ci, cj = self.contradiction_edge
        if ci < L - 1 and cj == ci + 1:
            J_vals[ci] = self.contradiction_strength
        self.J_vals = J_vals
        lat = Chain(L, SpinHalfSite(conserve='Sz'), bc='open')
        model_params['lattice'] = lat
        CouplingMPOModel.__init__(self, model_params)

    def init_terms(self, model_params=None):
        if model_params is None:
            model_params = {}
        # Heisenberg 项：XX+YY (使用数组形式的强度，unit_cell=0，dx=[1])
        self.add_coupling(self.J_vals * 0.5, 0, 'Sp', 0, 'Sm', dx=[1], plus_hc=True)
        # Heisenberg 项：ZZ (同样使用数组形式)
        self.add_coupling(self.J_vals, 0, 'Sz', 0, 'Sz', dx=[1])

def compute_fine(L, contradiction_edge, s, chi_max=200):
    M = ChainModel(dict(L=L, contradiction_edge=contradiction_edge, contradiction_strength=s,
                        bc_MPS='finite', conserve='Sz'))
    init = ['up','down']*(L//2) + (['up'] if L%2 else [])
    psi = MPS.from_product_state(M.lat.mps_sites(), init, bc='finite')
    dmrg_params = {'mixer': True, 'chi_max': chi_max, 'max_sweeps': 100, 'verbose': 0}
    eng = dmrg.run(psi, M, dmrg_params)
    corrs = []
    for i in range(L-1):
        corr = psi.correlation_function('Sz','Sz', [i], [i+1])
        corrs.append(corr[0])
    return np.std(corrs)

def find_valley(s_values, fine_values):
    """返回精细诊断最小值对应的s"""
    idx = np.argmin(fine_values)
    return s_values[idx], fine_values[idx]

if __name__ == "__main__":
    N_list = [6, 8, 10, 12]
    s_values = np.linspace(0.0, 3.0, 25)
    valley_positions = []
    valley_depths = []

    for N in N_list:
        edge = (N//2 - 1, N//2)
        fine_vals = []
        print(f"\n=== N={N} ===")
        for s in s_values:
            fine = compute_fine(N, edge, s, chi_max=200)
            fine_vals.append(fine)
            print(f"s={s:.3f}, fine={fine:.6f}")
        s_star, depth = find_valley(s_values, fine_vals)
        valley_positions.append(s_star)
        valley_depths.append(depth)
        print(f"  >> 谷底位置 s*={s_star:.3f}, 深度={depth:.6f}")

    np.savetxt('valley_convergence_v2.csv',
               np.column_stack((N_list, valley_positions, valley_depths)),
               header='N,s_star,depth', delimiter=',')

    print("\n=== 趋势报告 ===")
    print(f"N: {N_list}")
    print(f"s*: {[f'{v:.3f}' for v in valley_positions]}")
    print(f"谷底位置变化量: {[f'{d:.3f}' for d in np.abs(np.diff(valley_positions))]}")
    print("（理论预测：谷底位置应随N平滑变化，趋势可由有限尺寸效应解释）")
    print("（证伪阈值：谷底突然消失，或谷底位置出现无规律的剧烈跳动）")

    fig, ax = plt.subplots(figsize=(8,5))
    ax.plot(N_list, valley_positions, 'o-', label='Valley position s*')
    ax.set_xlabel('System size N')
    ax.set_ylabel('Valley position s*')
    ax.set_title('Valley Position vs System Size')
    ax.legend()
    ax.grid(True)
    plt.tight_layout()
    plt.savefig('falsify_valley_position_v2.png')
    plt.show()
