"""
平凡零检测器 —— 金箍棒 3.0 ED
三个任务：
1. 星形图 s=1.0 处谷底是否机器精度零？
2. 路径图/二叉树/随机树在 s=1.0 处的谷底是否远离零？
3. 固定 v0 重复运行，测量诊断器的数值误差地板
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# =============================================
# 哈密顿量构建（泡利矩阵版，标准Heisenberg）
# =============================================
def build_hamiltonian_pauli(N, edges, contradiction_edge, contradiction_strength):
    """使用泡利矩阵构建标准各向同性Heisenberg模型，支持任意图拓扑"""
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)

    def to_full(op, site):
        ops = [I2] * N
        ops[site] = op
        result = ops[0]
        for k in range(1, N):
            result = np.kron(result, ops[k])
        return result

    for (i, j, w) in edges:
        if (i, j) == contradiction_edge or (j, i) == contradiction_edge:
            w = contradiction_strength
        H += w * (to_full(sx, i) @ to_full(sx, j)).real
        H += w * (to_full(sy, i) @ to_full(sy, j)).real
        H += w * (to_full(sz, i) @ to_full(sz, j)).real

    return H.tocsc()


# =============================================
# 图拓扑工厂
# =============================================
def star_edges(N):
    """星形图：中心节点0连接所有叶子节点"""
    return [(0, i, 1.0) for i in range(1, N)]

def path_edges(N):
    """路径图：链式"""
    return [(i, i+1, 1.0) for i in range(N-1)]

def binary_tree_edges(N):
    """二叉树：根节点0，每个节点最多两个子节点"""
    edges = []
    for i in range(N):
        left = 2*i + 1
        right = 2*i + 2
        if left < N:
            edges.append((i, left, 1.0))
        if right < N:
            edges.append((i, right, 1.0))
    return edges

def random_tree_edges(N, seed=42):
    """随机树：任意连接的非环图"""
    np.random.seed(seed)
    edges = []
    for i in range(1, N):
        parent = np.random.randint(0, i)
        edges.append((parent, i, 1.0))
    return edges


# =============================================
# 精细诊断（修复版：不含假零行）
# =============================================
def fine_diagnosis(N, edges, gs):
    """计算边关联涨落的标准差"""
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    corrs = []
    for (i, j, w) in edges:
        ops = [I2] * N
        ops[i] = sz
        ops[j] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        corr = np.real(gs.conj().T @ op_full @ gs)
        corrs.append(corr)
    return np.std(corrs) if corrs else 0.0


def compute_valley_at_s1(N, edges, contradiction_edge, num_seeds=5):
    """
    在 s=1.0 处计算精细诊断值，使用多个Lanczos种子
    返回每个种子的精细诊断值
    """
    fine_values = []
    for seed in range(num_seeds):
        H = build_hamiltonian_pauli(N, edges, contradiction_edge, 1.0)
        # 使用不同随机种子运行Lanczos
        np.random.seed(seed * 42)
        v0 = np.random.randn(2**N)
        energies, states = eigsh(H, k=3, which='SA', v0=v0)
        gs = states[:, 0]
        fine = fine_diagnosis(N, edges, gs)
        fine_values.append(fine)
    return fine_values


def measure_numerical_floor(N, edges, contradiction_edge, s_fixed, num_repeats=50):
    """
    固定s值，重复运行，测量精细诊断值的数值误差地板
    所有运行使用相同哈密顿量，不同Lanczos种子
    """
    fine_values = []
    for repeat in range(num_repeats):
        np.random.seed(repeat * 42)
        v0 = np.random.randn(2**N)
        H = build_hamiltonian_pauli(N, edges, contradiction_edge, s_fixed)
        energies, states = eigsh(H, k=3, which='SA', v0=v0)
        gs = states[:, 0]
        fine = fine_diagnosis(N, edges, gs)
        fine_values.append(fine)
    return fine_values


if __name__ == "__main__":
    print("=== 平凡零检测器 ===\n")
    
    # =============================================
    # 任务1：星形图在 s=1.0 处谷底是否机器精度零？
    # =============================================
    N_star = 7
    star_edge_list = star_edges(N_star)
    star_contradiction_edge = (0, 1)  # 星形图中任意一条边
    print(f"任务1：星形图 N={N_star}，矛盾边={star_contradiction_edge}，s=1.0")
    star_fine = compute_valley_at_s1(N_star, star_edge_list, star_contradiction_edge, num_seeds=5)
    print(f"  5个种子的精细诊断值: {star_fine}")
    print(f"  均值: {np.mean(star_fine):.6e}")
    print(f"  机器精度判断: {'是平凡零' if np.mean(star_fine) < 1e-10 else '不是平凡零'}\n")
    
    # =============================================
    # 任务2：对照组在 s=1.0 处的谷底是否远离零？
    # =============================================
    # 路径图 N=7
    N_path = 7
    path_edge_list = path_edges(N_path)
    path_contradiction_edge = (N_path//2 - 1, N_path//2)
    print(f"任务2a：路径图 N={N_path}，矛盾边={path_contradiction_edge}，s=1.0")
    path_fine = compute_valley_at_s1(N_path, path_edge_list, path_contradiction_edge, num_seeds=5)
    print(f"  5个种子的精细诊断值: {path_fine}")
    print(f"  均值: {np.mean(path_fine):.6f}")
    print(f"  是否远离零: {'是' if np.mean(path_fine) > 1e-3 else '否'}\n")
    
    # 二叉树 N=7
    N_bt = 7
    bt_edge_list = binary_tree_edges(N_bt)
    bt_contradiction_edge = (0, 1)
    print(f"任务2b：二叉树 N={N_bt}，矛盾边={bt_contradiction_edge}，s=1.0")
    bt_fine = compute_valley_at_s1(N_bt, bt_edge_list, bt_contradiction_edge, num_seeds=5)
    print(f"  5个种子的精细诊断值: {bt_fine}")
    print(f"  均值: {np.mean(bt_fine):.6f}")
    print(f"  是否远离零: {'是' if np.mean(bt_fine) > 1e-3 else '否'}\n")
    
    # 随机树 N=7
    N_rt = 7
    rt_edge_list = random_tree_edges(N_rt, seed=42)
    rt_contradiction_edge = (0, 1)
    print(f"任务2c：随机树 N={N_rt}，矛盾边={rt_contradiction_edge}，s=1.0")
    rt_fine = compute_valley_at_s1(N_rt, rt_edge_list, rt_contradiction_edge, num_seeds=5)
    print(f"  5个种子的精细诊断值: {rt_fine}")
    print(f"  均值: {np.mean(rt_fine):.6f}")
    print(f"  是否远离零: {'是' if np.mean(rt_fine) > 1e-3 else '否'}\n")
    
    # =============================================
    # 任务3：测量数值误差地板
    # =============================================
    print(f"任务3：数值误差地板（固定s=1.0，50次重复）")
    print(f"  星形图:")
    star_floor = measure_numerical_floor(N_star, star_edge_list, star_contradiction_edge, 1.0, num_repeats=50)
    print(f"    均值: {np.mean(star_floor):.6e}")
    print(f"    标准差: {np.std(star_floor):.6e}")
    
    print(f"  路径图:")
    path_floor = measure_numerical_floor(N_path, path_edge_list, path_contradiction_edge, 1.0, num_repeats=50)
    print(f"    均值: {np.mean(path_floor):.6f}")
    print(f"    标准差: {np.std(path_floor):.6f}")
    
    print(f"  二叉树:")
    bt_floor = measure_numerical_floor(N_bt, bt_edge_list, bt_contradiction_edge, 1.0, num_repeats=50)
    print(f"    均值: {np.mean(bt_floor):.6f}")
    print(f"    标准差: {np.std(bt_floor):.6f}")
    
    # =============================================
    # 保存结果
    # =============================================
    results = {
        'star_s1_fine': star_fine,
        'path_s1_fine': path_fine,
        'binary_tree_s1_fine': bt_fine,
        'random_tree_s1_fine': rt_fine,
        'star_floor': star_floor,
        'path_floor': path_floor,
        'binary_tree_floor': bt_floor,
    }
    np.savez('trivial_zero_detector_results.npz', **results)
    print("\n结果已保存到 trivial_zero_detector_results.npz")
    print("Done.")