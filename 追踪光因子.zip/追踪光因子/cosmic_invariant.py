"""
宇宙时空转换因子密集探索 —— 金箍棒 3.0 DMRG
超高密度扫描各向异性参数Δ (Δ=0.00→1.00, 步长0.01, 共101点)
检验：是否存在关系场自身的“光速”——即绝对的转换因子？
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tenpy.models.model import CouplingMPOModel
from tenpy.models.lattice import Chain
from tenpy.networks.site import SpinHalfSite
from tenpy.networks.mps import MPS
from tenpy.algorithms import dmrg

class XXZModel(CouplingMPOModel):
    """链式XXZ模型，各向异性参数Δ和矛盾边强度可独立设置"""
    def __init__(self, model_params):
        L = model_params.get('L', 8)
        self.delta = model_params.get('delta', 1.0)
        self.contradiction_strength = model_params.get('contradiction_strength', 1.5)
        self.contradiction_edge = model_params.get('contradiction_edge', (L//2 - 1, L//2))
        lat = Chain(L, SpinHalfSite(conserve='Sz'), bc='open')
        model_params['lattice'] = lat
        CouplingMPOModel.__init__(self, model_params)

    def init_terms(self, model_params=None):
        if model_params is None:
            model_params = {}
        L = self.lat.N_sites
        for i in range(L-1):
            if (i, i+1) == self.contradiction_edge or (i+1, i) == self.contradiction_edge:
                J = self.contradiction_strength
            else:
                J = 1.0
            # XY项（翻转项）
            self.add_coupling(J * 0.5, i, 'Sp', i+1, 'Sm', plus_hc=True)
            # Ising项（对角项），乘以各向异性参数Δ
            self.add_coupling(J * self.delta, i, 'Sz', i+1, 'Sz')

def compute_diagnostics(L, contradiction_edge, s, delta, chi_max=100):
    M = XXZModel(dict(
        L=L, contradiction_edge=contradiction_edge,
        contradiction_strength=s, delta=delta,
        bc_MPS='finite', conserve='Sz'
    ))
    init = ['up', 'down'] * (L // 2)
    if L % 2 == 1: init.append('up')
    psi = MPS.from_product_state(M.lat.mps_sites(), init, bc='finite')
    dmrg_params = {'mixer': True, 'chi_max': chi_max, 'max_sweeps': 50, 'verbose': 0}
    eng = dmrg.run(psi, M, dmrg_params)
    E0 = eng['E']
    
    init_ex = init.copy()
    center = L // 2
    init_ex[center] = 'down' if init_ex[center] == 'up' else 'up'
    psi_ex = MPS.from_product_state(M.lat.mps_sites(), init_ex, bc='finite')
    eng_ex = dmrg.run(psi_ex, M, dmrg_params)
    E1 = eng_ex['E']
    gap = E1 - E0

    Sz = psi.expectation_value('Sz')
    coarse = np.mean(np.abs(Sz))
    
    corrs = []
    for i in range(L - 1):
        corr = psi.correlation_function('Sz', 'Sz', [i], [i+1])
        corrs.append(corr[0])
    fine = np.std(corrs) if corrs else 0.0
    
    return gap, coarse, fine

if __name__ == "__main__":
    L = 8
    contradiction_edge = (L//2 - 1, L//2)
    contradiction_strength = 1.5
    
    # 超级密集扫描：从0.00到1.00，步长0.01，共101个点
    delta_values = np.linspace(0.0, 1.0, 101)
    
    gaps, coarse_vals, fine_vals = [], [], []
    print(f"=== 宇宙转换因子密集探索 (L={L}, s={contradiction_strength}, 步长=0.01) ===")
    print("扫描各向异性参数 Δ: 0.00 → 1.00\n")
    
    for delta in delta_values:
        gap, coarse, fine = compute_diagnostics(L, contradiction_edge, contradiction_strength, delta, chi_max=100)
        gaps.append(gap); coarse_vals.append(coarse); fine_vals.append(fine)
        # 每10个点打印一次进度，避免刷屏
        if int(delta*100) % 10 == 0:
            print(f"Δ={delta:.2f}: gap={gap:.6f}, coarse={coarse:.4f}, fine={fine:.6f}")
    
    print("\n扫描完成，正在进行不变性分析...")
    
    # 保存数据
    np.savetxt('cosmic_invariant_dense_results.csv',
               np.column_stack((delta_values, gaps, coarse_vals, fine_vals)),
               header='delta,gap,coarse,fine', delimiter=',')
    
    # 诊断图：超高分辨率曲线
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))
    
    # 默认诊断
    ax1.plot(delta_values, coarse_vals, '-', color='#1f77b4', linewidth=1.0, alpha=0.8)
    ax1.set_xlabel('Anisotropy Δ', fontsize=12)
    ax1.set_ylabel('Coarse metric', fontsize=12)
    ax1.set_title(f'Default Diagnosis (Entity-level, L={L})')
    ax1.grid(True, alpha=0.3, linestyle='--')
    # 如果存在平坦区域，自动标注
    coarse_arr = np.array(coarse_vals)
    ax1.axhline(y=np.mean(coarse_arr), color='gray', linestyle=':', alpha=0.5, label='Mean')
    ax1.legend()
    
    # 增强诊断
    ax2.plot(delta_values, fine_vals, '-', color='#d62728', linewidth=1.0, alpha=0.8)
    ax2.set_xlabel('Anisotropy Δ', fontsize=12)
    ax2.set_ylabel('Fine metric', fontsize=12)
    ax2.set_title(f'Enhanced Diagnosis (Relation-level, L={L})')
    ax2.grid(True, alpha=0.3, linestyle='--')
    fine_arr = np.array(fine_vals)
    ax2.axhline(y=np.mean(fine_arr), color='gray', linestyle=':', alpha=0.5, label='Mean')
    ax2.legend()
    
    plt.suptitle(f'Ultra-Dense Cosmic Invariant Search (L={L}, s={contradiction_strength})', fontsize=14, fontweight='bold')
    plt.tight_layout()
    plt.savefig('cosmic_invariant_dense_diagnosis.png', dpi=200)
    print("诊断图已保存至 cosmic_invariant_dense_diagnosis.png")
    
    # 精细的不变性分析
    print("\n=== 密集扫描不变性分析 ===")
    fine_mean = np.mean(fine_arr)
    fine_std = np.std(fine_arr)
    fine_range = np.max(fine_arr) - np.min(fine_arr)
    relative_range = fine_range / fine_mean if fine_mean > 0 else np.inf
    
    print(f"精细诊断统计: 均值={fine_mean:.6f}, 标准差={fine_std:.6f}, 范围={fine_range:.6f}")
    print(f"相对波动: {relative_range*100:.4f}%")
    
    # 检查是否存在平坦区域（连续多个点的变化小于阈值）
    flat_regions = []
    threshold = 0.001  # 变化阈值
    min_length = 5     # 至少连续5个点变化极小才算平坦
    
    start = 0
    for i in range(1, len(fine_arr)):
        if abs(fine_arr[i] - fine_arr[i-1]) > threshold:
            if i - start >= min_length:
                flat_regions.append((delta_values[start], delta_values[i-1]))
            start = i
    if len(fine_arr) - start >= min_length:
        flat_regions.append((delta_values[start], delta_values[-1]))
    
    if flat_regions:
        print("\n✓ 发现精细诊断平坦区域（可能存在转换因子）:")
        for region_start, region_end in flat_regions:
            print(f"  Δ = {region_start:.2f} 到 Δ = {region_end:.2f}")
    else:
        print("\n✗ 未发现显著的精细诊断平坦区域。")
        print("  在当前参数下，精细诊断随Δ连续变化，未涌现绝对的转换因子。")
    
    # 默认诊断的对比
    coarse_mean = np.mean(coarse_arr)
    coarse_range = np.max(coarse_arr) - np.min(coarse_arr)
    coarse_relative = coarse_range / coarse_mean if coarse_mean > 0 else np.inf
    print(f"\n默认诊断统计: 均值={coarse_mean:.6f}, 范围={coarse_range:.6f}, 相对波动: {coarse_relative*100:.4f}%")
    
    # 如果默认诊断变化很大而精细诊断变化很小，则是不变性最强的证据
    if relative_range < 0.05 and coarse_relative > 0.1:
        print("\n★★★ 重大发现：默认诊断剧烈变化，但精细诊断保持恒定！")
        print("    这强烈暗示存在一个独立于具体物理规则的、绝对的关系场转换因子。")
    
    print("\nDone. 原始数据已保存至 cosmic_invariant_dense_results.csv")