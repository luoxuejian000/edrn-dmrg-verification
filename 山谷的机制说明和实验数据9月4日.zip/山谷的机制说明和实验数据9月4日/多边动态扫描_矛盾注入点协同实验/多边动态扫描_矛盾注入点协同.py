"""
多边动态扫描_矛盾注入点协同.py

实验目的：
    检验谷底是否是多条矛盾边同时扰动时产生的非线性协同现象。
    通过同时扫描两条矛盾边的强度 (s1, s2)，观察增强诊断 E(s1, s2)
    是否能由单边扫描结果线性预测，还是出现了新的非线性结构。

核心问题：
    如果 E(s1, s2) ≈ E1(s1) + E2(s2) - E(1,1)（可分离），则谷底是单边效应的简单叠加。
    如果 E_diff = E(s1, s2) - E_pred(s1, s2) 显著非零，则存在多边协同。

理论精髓视角：
    - 关系本体论：两条矛盾边之间的关系本身是研究对象。单边扫描看不到边与边之间的协同。
    - 矛盾动力论：多个矛盾同时存在时彼此影响。矛盾注入点之间的关系决定关系场如何重排。
    - 实践介入论：多边同时扫描是一种与单边扫描本质不同的介入方式，被明确标注。
    - 谐振调谐论：不预设多边扫描会出现什么。线性叠加和非线性涌现都是有效结果。
    - 元反思律：如果多边结果不能从单边预测，说明单边机制不完整，需要关系层面的新机制。

标准物理视角：
    - 只报告 E(s1, s2) 的数值和谷底位置。
    - 检查是否能隙闭合或其他已知现象解释非线性。

两种视角并排放置。

输出：
    multi_edge_scan_results.json
    E_multi_heatmap.csv
    E_diff_heatmap.csv
"""

import numpy as np
import networkx as nx
import itertools
from scipy.sparse import lil_matrix, csr_matrix
from scipy.sparse.linalg import eigsh
import json
import warnings
warnings.filterwarnings('ignore')

# ========== 参数 ==========
S_GRID_SIZE = 21  # 每条边的扫描点数（21×21=441个点）
S_MIN, S_MAX = 0.0, 3.0
EPS_DEGEN = 1e-8
N_EIGS = 6

# ========== 图定义 ==========
smallworld_edges = [
    (3, 4), (4, 6), (0, 2), (1, 6), (0, 8),
    (2, 5), (1, 9), (6, 8), (4, 5), (5, 6),
    (0, 1), (2, 4), (1, 8), (7, 9), (6, 7),
    (3, 5), (0, 9), (1, 4), (2, 3), (7, 8)
]

tree_edges = [
    (0, 7), (0, 11), (1, 6), (1, 10), (1, 12),
    (2, 3), (2, 11), (3, 4), (3, 9), (4, 8),
    (5, 10), (10, 11), (11, 14), (13, 14)
]

def make_graph(edges):
    G = nx.Graph()
    G.add_nodes_from(range(max(max(u, v) for u, v in edges) + 1))
    G.add_edges_from(edges)
    return G

# ========== 哈密顿量构建 ==========
def build_hamiltonian_sector(N, edges, J_vals, N_up):
    basis_states = list(itertools.combinations(range(N), N_up))
    state_to_idx = {st: i for i, st in enumerate(basis_states)}
    dim = len(basis_states)
    H = lil_matrix((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis_states):
            si = 1 if i in state else -1
            sj = 1 if j in state else -1
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis_states):
            i_up = i in state
            j_up = j in state
            if i_up and not j_up:
                ns = list(state)
                ns.remove(i); ns.append(j)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2.0 * J
            elif j_up and not i_up:
                ns = list(state)
                ns.remove(j); ns.append(i)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2.0 * J
    return csr_matrix(H), basis_states

def lanczos_sa_multi(H, n_eigs=6, v0_seed=0, maxiter=10000):
    dim = H.shape[0]
    if dim == 0:
        return None, None, False
    rng = np.random.default_rng(v0_seed)
    v0 = rng.standard_normal(dim)
    k = min(n_eigs, dim)
    try:
        evals, evecs = eigsh(H, k=k, which='SA', v0=v0, maxiter=maxiter, tol=1e-9)
        idx = np.argsort(evals)
        return evals[idx], evecs[:, idx], True
    except Exception:
        return None, None, False

# ========== 预扫描确定简并扇区 ==========
def prescan_degenerate_sectors(N, edges, J_vals):
    sector_energies = {}
    for N_up in range(N + 1):
        H, basis = build_hamiltonian_sector(N, edges, J_vals, N_up)
        if H.shape[0] == 0:
            continue
        dim = H.shape[0]
        if dim <= 1500:
            evals = np.linalg.eigh(H.toarray())[0]
            E0 = evals[0]
        else:
            evals, evecs, ok = lanczos_sa_multi(H, n_eigs=1, v0_seed=0)
            if not ok:
                sector_energies[N_up] = np.inf
                continue
            E0 = evals[0]
        sector_energies[N_up] = E0
    if not sector_energies:
        return [], np.inf
    min_E = min(sector_energies.values())
    degen = [nup for nup, E in sector_energies.items() if abs(E - min_E) < EPS_DEGEN]
    return degen, min_E

# ========== 理论视角：对称投影平均边关联 ==========
def compute_edge_correlations_projected(N, edges, J_vals, degen_sectors, v0_seed=0):
    n_edges = len(edges)
    corr_sum = np.zeros(n_edges)
    n_states = 0
    sector_evals = {}
    for N_up in degen_sectors:
        H, basis = build_hamiltonian_sector(N, edges, J_vals, N_up)
        if H.shape[0] == 0:
            continue
        dim = H.shape[0]
        if dim <= 1500:
            evals = np.linalg.eigh(H.toarray())[0]
            sector_evals[N_up] = evals
        else:
            evals, evecs, ok = lanczos_sa_multi(H, n_eigs=N_EIGS, v0_seed=v0_seed)
            if ok:
                sector_evals[N_up] = evals
    if not sector_evals:
        return None, 0
    E0_local = min(evals[0] for evals in sector_evals.values())
    for N_up, evals in sector_evals.items():
        H, basis = build_hamiltonian_sector(N, edges, J_vals, N_up)
        if H.shape[0] == 0:
            continue
        dim = H.shape[0]
        if dim <= 1500:
            _, evecs = np.linalg.eigh(H.toarray())
            for idx, E in enumerate(evals):
                if abs(E - E0_local) < EPS_DEGEN:
                    psi = evecs[:, idx]
                    n_states += 1
                    for e_idx, (i, j) in enumerate(edges):
                        diag = np.array([(1 if i in st else -1) * (1 if j in st else -1) for st in basis])
                        corr_sum[e_idx] += np.sum(np.abs(psi)**2 * diag)
        else:
            _, evecs, ok = lanczos_sa_multi(H, n_eigs=N_EIGS, v0_seed=v0_seed)
            if not ok:
                continue
            for idx in range(len(evals)):
                if abs(evals[idx] - E0_local) < EPS_DEGEN:
                    psi = evecs[:, idx]
                    n_states += 1
                    for e_idx, (i, j) in enumerate(edges):
                        diag = np.array([(1 if i in st else -1) * (1 if j in st else -1) for st in basis])
                        corr_sum[e_idx] += np.sum(np.abs(psi)**2 * diag)
    if n_states == 0:
        return None, 0
    return corr_sum / n_states, n_states

# ========== 标准视角：单态边关联 ==========
def compute_edge_correlations_single(N, edges, J_vals, N_up, v0_seed=0):
    H, basis = build_hamiltonian_sector(N, edges, J_vals, N_up)
    evals, evecs, ok = lanczos_sa_multi(H, n_eigs=1, v0_seed=v0_seed)
    if not ok:
        return None
    psi = evecs[:, 0]
    corrs = []
    for (i, j) in edges:
        diag = np.array([(1 if i in st else -1) * (1 if j in st else -1) for st in basis])
        corrs.append(np.sum(np.abs(psi)**2 * diag))
    return np.array(corrs)

# ========== 单边扫描 ==========
def scan_single_edge(N, edges, edge_idx, s_values, degen_sectors, N_up_standard, v0_seed=0):
    """扫描单条矛盾边，返回 E(s) 和 C_defect(s)、C̄(s)。"""
    J_vals = np.ones(len(edges))
    e_proj = np.full(len(s_values), np.nan)
    e_single = np.full(len(s_values), np.nan)
    c_defect_proj = np.full(len(s_values), np.nan)
    c_defect_single = np.full(len(s_values), np.nan)
    c_mean_proj = np.full(len(s_values), np.nan)
    c_mean_single = np.full(len(s_values), np.nan)

    for si, s in enumerate(s_values):
        J_vals[edge_idx] = s

        corrs_proj, _ = compute_edge_correlations_projected(N, edges, J_vals, degen_sectors, v0_seed)
        if corrs_proj is not None:
            e_proj[si] = np.std(corrs_proj)
            c_defect_proj[si] = corrs_proj[edge_idx]
            c_mean_proj[si] = np.mean(corrs_proj)

        corrs_single = compute_edge_correlations_single(N, edges, J_vals, N_up_standard, v0_seed)
        if corrs_single is not None:
            e_single[si] = np.std(corrs_single)
            c_defect_single[si] = corrs_single[edge_idx]
            c_mean_single[si] = np.mean(corrs_single)

        J_vals[edge_idx] = 1.0

    return {
        'e_proj': e_proj,
        'e_single': e_single,
        'c_defect_proj': c_defect_proj,
        'c_defect_single': c_defect_single,
        'c_mean_proj': c_mean_proj,
        'c_mean_single': c_mean_single
    }

# ========== 多边同时扫描 ==========
def scan_multi_edges(N, edges, edge_idx1, edge_idx2, s_grid, degen_sectors, N_up_standard, v0_seed=0):
    """同时扫描两条矛盾边，返回 E(s1,s2) 等二维数据。"""
    n_points = len(s_grid)
    e_proj_2d = np.full((n_points, n_points), np.nan)
    e_single_2d = np.full((n_points, n_points), np.nan)
    c1_proj_2d = np.full((n_points, n_points), np.nan)
    c2_proj_2d = np.full((n_points, n_points), np.nan)
    c1_single_2d = np.full((n_points, n_points), np.nan)
    c2_single_2d = np.full((n_points, n_points), np.nan)
    c_mean_proj_2d = np.full((n_points, n_points), np.nan)
    c_mean_single_2d = np.full((n_points, n_points), np.nan)

    J_vals = np.ones(len(edges))
    for i, s1 in enumerate(s_grid):
        for j, s2 in enumerate(s_grid):
            J_vals[edge_idx1] = s1
            J_vals[edge_idx2] = s2

            corrs_proj, _ = compute_edge_correlations_projected(N, edges, J_vals, degen_sectors, v0_seed)
            if corrs_proj is not None:
                e_proj_2d[i, j] = np.std(corrs_proj)
                c1_proj_2d[i, j] = corrs_proj[edge_idx1]
                c2_proj_2d[i, j] = corrs_proj[edge_idx2]
                c_mean_proj_2d[i, j] = np.mean(corrs_proj)

            corrs_single = compute_edge_correlations_single(N, edges, J_vals, N_up_standard, v0_seed)
            if corrs_single is not None:
                e_single_2d[i, j] = np.std(corrs_single)
                c1_single_2d[i, j] = corrs_single[edge_idx1]
                c2_single_2d[i, j] = corrs_single[edge_idx2]
                c_mean_single_2d[i, j] = np.mean(corrs_single)

            J_vals[edge_idx1] = 1.0
            J_vals[edge_idx2] = 1.0

        if (i+1) % 5 == 0:
            print(f"    多边扫描进度: {i+1}/{n_points}")

    return {
        'e_proj_2d': e_proj_2d,
        'e_single_2d': e_single_2d,
        'c1_proj_2d': c1_proj_2d,
        'c2_proj_2d': c2_proj_2d,
        'c1_single_2d': c1_single_2d,
        'c2_single_2d': c2_single_2d,
        'c_mean_proj_2d': c_mean_proj_2d,
        'c_mean_single_2d': c_mean_single_2d
    }

# ========== 线性预测 ==========
def linear_prediction(e1_single, e2_single, e_ref):
    """
    基于单边扫描结果构建可分离预测：
    E_pred(s1, s2) = E1(s1) + E2(s2) - E_ref
    其中 E_ref 是两条边都在参考点时的 E 值。
    """
    n1, n2 = len(e1_single), len(e2_single)
    E_pred = np.full((n1, n2), np.nan)
    for i in range(n1):
        for j in range(n2):
            E_pred[i, j] = e1_single[i] + e2_single[j] - e_ref
    return E_pred

# ========== 主程序 ==========
def main():
    print("=== 多边动态扫描：矛盾注入点协同 ===")
    print(f"网格：{S_GRID_SIZE}×{S_GRID_SIZE}，范围 [{S_MIN}, {S_MAX}]\n")

    s_grid = np.linspace(S_MIN, S_MAX, S_GRID_SIZE)

    # 目标：小世界图的两条边
    # 选 (0,1)（谷底s=1.5）和 (6,8)（谷底s=1.4）
    edges = [tuple(sorted(e)) for e in smallworld_edges]
    N = 10
    N_up_standard = N // 2

    edge_idx1 = edges.index((0, 1))
    edge_idx2 = edges.index((6, 8))

    print(f"图：小世界 N={N}")
    print(f"矛盾边1：{edges[edge_idx1]}（单边谷底约s=1.5）")
    print(f"矛盾边2：{edges[edge_idx2]}（单边谷底约s=1.4）")

    # 预扫描确定简并扇区（均匀点 s=1）
    J_vals_probe = np.ones(len(edges))
    degen, E0 = prescan_degenerate_sectors(N, edges, J_vals_probe)
    print(f"简并扇区：{degen}")

    # 单边扫描（参考）
    print("\n单边扫描边1...")
    single1 = scan_single_edge(N, edges, edge_idx1, s_grid, degen, N_up_standard, v0_seed=0)
    print("单边扫描边2...")
    single2 = scan_single_edge(N, edges, edge_idx2, s_grid, degen, N_up_standard, v0_seed=0)

    # 参考值：s=1 处两条边都均匀时的 E
    # 在单边扫描中，另一个边保持在 s=1（因为 J_vals 初始化为1）
    ref_idx = np.argmin(np.abs(s_grid - 1.0))
    e_ref_proj = single1['e_proj'][ref_idx]
    e_ref_single = single1['e_single'][ref_idx]

    # 多边同时扫描
    print("\n多边同时扫描...")
    multi = scan_multi_edges(N, edges, edge_idx1, edge_idx2, s_grid, degen, N_up_standard, v0_seed=0)

    # 线性预测
    print("\n构建线性预测...")
    pred_proj = linear_prediction(single1['e_proj'], single2['e_proj'], e_ref_proj)
    pred_single = linear_prediction(single1['e_single'], single2['e_single'], e_ref_single)

    # 差值分析
    diff_proj = multi['e_proj_2d'] - pred_proj
    diff_single = multi['e_single_2d'] - pred_single

    # 统计非线性度
    nonlin_proj_abs = np.nanmean(np.abs(diff_proj))
    nonlin_single_abs = np.nanmean(np.abs(diff_single))
    nonlin_proj_max = np.nanmax(np.abs(diff_proj))
    nonlin_single_max = np.nanmax(np.abs(diff_single))

    print(f"\n=== 非线性度量化（理论视角） ===")
    print(f"平均 |E_diff|: {nonlin_proj_abs:.6f}")
    print(f"最大 |E_diff|: {nonlin_proj_max:.6f}")
    print(f"E 值范围: {np.nanmin(multi['e_proj_2d']):.6f} 到 {np.nanmax(multi['e_proj_2d']):.6f}")

    print(f"\n=== 非线性度量化（标准视角） ===")
    print(f"平均 |E_diff|: {nonlin_single_abs:.6f}")
    print(f"最大 |E_diff|: {nonlin_single_max:.6f}")
    print(f"E 值范围: {np.nanmin(multi['e_single_2d']):.6f} 到 {np.nanmax(multi['e_single_2d']):.6f}")

    # 判断
    threshold = 0.01  # 非线性显著阈值（可根据数据调整）
    print("\n=== 判断 ===")
    if nonlin_proj_abs > threshold:
        print("理论视角：存在显著非线性协同。谷底不能被单边扫描线性预测。")
    else:
        print("理论视角：非线性度低。谷底接近单边效应的线性叠加。")

    if nonlin_single_abs > threshold:
        print("标准视角：存在显著非线性协同。")
    else:
        print("标准视角：非线性度低。")

    # 保存结果
    output = {
        's_grid': s_grid.tolist(),
        'edges': {'edge1': list(edges[edge_idx1]), 'edge2': list(edges[edge_idx2])},
        'single_scan': {
            'e1_proj': single1['e_proj'].tolist(),
            'e1_single': single1['e_single'].tolist(),
            'e2_proj': single2['e_proj'].tolist(),
            'e2_single': single2['e_single'].tolist()
        },
        'multi_scan': {
            'e_proj_2d': multi['e_proj_2d'].tolist(),
            'e_single_2d': multi['e_single_2d'].tolist()
        },
        'linear_prediction': {
            'pred_proj': pred_proj.tolist(),
            'pred_single': pred_single.tolist()
        },
        'diff': {
            'diff_proj': diff_proj.tolist(),
            'diff_single': diff_single.tolist()
        },
        'nonlinearity': {
            'mean_abs_diff_proj': float(nonlin_proj_abs),
            'max_abs_diff_proj': float(nonlin_proj_max),
            'mean_abs_diff_single': float(nonlin_single_abs),
            'max_abs_diff_single': float(nonlin_single_max)
        }
    }

    with open('multi_edge_scan_results.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)

    print("\n结果已保存至 multi_edge_scan_results.json")

    # 保存热图 CSV
    np.savetxt('E_multi_heatmap.csv', multi['e_proj_2d'], delimiter=',')
    np.savetxt('E_diff_heatmap.csv', diff_proj, delimiter=',')

    print("热图已保存至 E_multi_heatmap.csv 和 E_diff_heatmap.csv")

if __name__ == "__main__":
    main()