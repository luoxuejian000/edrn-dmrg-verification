"""
观测显现的定量计算协议.py

目的：
    以“观测”为唯一视角，建立一个可定量复现、可计算预测的协议，
    证明谷底是哈密顿量结构在观测入口下的确定性显现。

核心定义：
    - 观测入口：选定的一条边
    - 观测参数：该边的耦合强度 s
    - 显现曲线：E(s) = 边关联的标准差
    - 谷底：E(s) 的局部极小值

定量预测内容：
    给定图 G 和观测入口 e，哈密顿量 H_e(s) 唯一确定。
    解 H_e(s) 的基态，计算 E_e(s)，找局部极小，即得谷底。
    整个计算过程完全确定，无自由参数，因此这个谷底位置就是
    “标准物理计算给出的显现”。

实验要证明：
    1. 同一入口的谷底在不同数值求解下可精确复现。
    2. 不同入口显现的谷底位置由哈密顿量整体结构确定。
    3. 观测协议本身就是预测：不需要额外公式。

输出：
    observation_protocol_quantitative.json
"""

import numpy as np
import networkx as nx
import itertools
from scipy.sparse import lil_matrix, csr_matrix
from scipy.sparse.linalg import eigsh
import json
import warnings
warnings.filterwarnings('ignore')

N = 10
S_MIN, S_MAX = 0.0, 3.0
N_POINTS = 61
EPS_DEGEN = 1e-8
N_EIGS = 6
N_V0 = 5  # 用5个不同数值种子验证复现性

smallworld_edges = [
    (3, 4), (4, 6), (0, 2), (1, 6), (0, 8),
    (2, 5), (1, 9), (6, 8), (4, 5), (5, 6),
    (0, 1), (2, 4), (1, 8), (7, 9), (6, 7),
    (3, 5), (0, 9), (1, 4), (2, 3), (7, 8)
]

def build_hamiltonian_sector(N, edges, J_vals, N_up):
    basis = list(itertools.combinations(range(N), N_up))
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = lil_matrix((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, st in enumerate(basis):
            si = 1 if i in st else -1
            sj = 1 if j in st else -1
            H[idx, idx] += J * si * sj
        for idx, st in enumerate(basis):
            i_up = i in st
            j_up = j in st
            if i_up and not j_up:
                ns = list(st); ns.remove(i); ns.append(j)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2.0 * J
            elif j_up and not i_up:
                ns = list(st); ns.remove(j); ns.append(i)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2.0 * J
    return csr_matrix(H), basis

def lanczos_sa_multi(H, n_eigs=6, v0_seed=0, maxiter=10000):
    dim = H.shape[0]
    if dim == 0:
        return None, None, False
    rng = np.random.default_rng(v0_seed)
    v0 = rng.standard_normal(dim)
    k = min(n_eigs, dim)
    try:
        evals, evecs = eigsh(H, k=k, which='SA', v0=v0, maxiter=maxiter, tol=1e-9)
        idx = np.argsort(evals)
        return evals[idx], evecs[:, idx], True
    except Exception:
        return None, None, False

def prescan_degenerate_sectors(N, edges, J_vals):
    sector_energies = {}
    for N_up in range(N+1):
        H, basis = build_hamiltonian_sector(N, edges, J_vals, N_up)
        if H.shape[0] == 0:
            continue
        dim = H.shape[0]
        if dim <= 1500:
            evals = np.linalg.eigh(H.toarray())[0]
            E0 = evals[0]
        else:
            evals, evecs, ok = lanczos_sa_multi(H, n_eigs=1, v0_seed=0)
            if not ok:
                sector_energies[N_up] = np.inf
                continue
            E0 = evals[0]
        sector_energies[N_up] = E0
    if not sector_energies:
        return [], np.inf
    min_E = min(sector_energies.values())
    degen = [nup for nup, E in sector_energies.items() if abs(E-min_E) < EPS_DEGEN]
    return degen, min_E

def compute_fine_projected(N, edges, J_vals, degen_sectors, v0_seed=0):
    n_edges = len(edges)
    corr_sum = np.zeros(n_edges)
    n_states = 0
    sector_evals = {}
    for N_up in degen_sectors:
        H, basis = build_hamiltonian_sector(N, edges, J_vals, N_up)
        if H.shape[0] == 0:
            continue
        dim = H.shape[0]
        if dim <= 1500:
            evals = np.linalg.eigh(H.toarray())[0]
            sector_evals[N_up] = evals
        else:
            evals, evecs, ok = lanczos_sa_multi(H, n_eigs=N_EIGS, v0_seed=v0_seed)
            if ok:
                sector_evals[N_up] = evals
    if not sector_evals:
        return None
    E0_local = min(evals[0] for evals in sector_evals.values())
    for N_up, evals in sector_evals.items():
        H, basis = build_hamiltonian_sector(N, edges, J_vals, N_up)
        if H.shape[0] == 0:
            continue
        dim = H.shape[0]
        if dim <= 1500:
            _, evecs = np.linalg.eigh(H.toarray())
            for idx, E in enumerate(evals):
                if abs(E - E0_local) < EPS_DEGEN:
                    psi = evecs[:, idx]
                    n_states += 1
                    for e_idx, (i, j) in enumerate(edges):
                        diag = np.array([(1 if i in st else -1)*(1 if j in st else -1) for st in basis])
                        corr_sum[e_idx] += np.sum(np.abs(psi)**2 * diag)
        else:
            _, evecs, ok = lanczos_sa_multi(H, n_eigs=N_EIGS, v0_seed=v0_seed)
            if not ok:
                continue
            for idx in range(len(evals)):
                if abs(evals[idx] - E0_local) < EPS_DEGEN:
                    psi = evecs[:, idx]
                    n_states += 1
                    for e_idx, (i, j) in enumerate(edges):
                        diag = np.array([(1 if i in st else -1)*(1 if j in st else -1) for st in basis])
                        corr_sum[e_idx] += np.sum(np.abs(psi)**2 * diag)
    if n_states == 0:
        return None
    corr_avg = corr_sum / n_states
    return np.std(corr_avg)

def find_valley(s_values, e_values):
    valid = np.where(~np.isnan(e_values))[0]
    if len(valid) < 3:
        return None
    valleys = []
    for idx in range(1, len(valid)-1):
        curr = valid[idx]
        if e_values[curr] < e_values[valid[idx-1]] and e_values[curr] < e_values[valid[idx+1]]:
            valleys.append((float(s_values[curr]), float(e_values[curr])))
    if not valleys:
        return None
    valleys.sort(key=lambda x: x[1])
    return valleys[0]

def main():
    print("=== 观测显现的定量计算协议 ===")
    print(f"图：小世界 N={N}，边数={len(smallworld_edges)}")
    print(f"观测参数扫描：[{S_MIN}, {S_MAX}]，{N_POINTS}点")
    print(f"数值复现种子：{N_V0}个\n")

    edges = [tuple(sorted(e)) for e in smallworld_edges]
    s_values = np.linspace(S_MIN, S_MAX, N_POINTS)

    # 预扫描确定简并扇区（均匀点 s=1）
    J_vals_probe = np.ones(len(edges))
    degen, E0 = prescan_degenerate_sectors(N, edges, J_vals_probe)
    print(f"简并扇区：{degen}")

    protocol_results = {}

    for edge_idx, edge in enumerate(edges):
        # 对每个观测入口，用5个不同数值种子计算E(s)，验证复现性
        valley_positions = []
        valley_depths = []
        all_curves = []

        for v0 in range(N_V0):
            J_vals = np.ones(len(edges))
            fine_curve = np.full(N_POINTS, np.nan)

            for si, s in enumerate(s_values):
                J_vals[edge_idx] = s
                fine = compute_fine_projected(N, edges, J_vals, degen, v0_seed=v0)
                if fine is not None:
                    fine_curve[si] = fine
                J_vals[edge_idx] = 1.0

            all_curves.append(fine_curve.tolist())
            valley = find_valley(s_values, fine_curve)
            if valley:
                valley_positions.append(valley[0])
                valley_depths.append(valley[1])

        # 复现性统计
        if valley_positions:
            pos_std = float(np.std(valley_positions, ddof=1)) if len(valley_positions) > 1 else 0.0
            depth_std = float(np.std(valley_depths, ddof=1)) if len(valley_depths) > 1 else 0.0
            protocol_results[str(edge)] = {
                'valley_s_mean': float(np.mean(valley_positions)),
                'valley_s_std': pos_std,
                'valley_depth_mean': float(np.mean(valley_depths)),
                'valley_depth_std': depth_std,
                'valley_positions_list': [float(p) for p in valley_positions],
                'valley_depths_list': [float(d) for d in valley_depths],
                'all_curves': all_curves
            }
            print(f"入口 {edge}: 谷底 s={np.mean(valley_positions):.4f} ± {pos_std:.6f}, "
                  f"深度={np.mean(valley_depths):.4f} ± {depth_std:.6f}")
        else:
            protocol_results[str(edge)] = {
                'valley_s_mean': None,
                'valley_s_std': None,
                'valley_depth_mean': None,
                'valley_depth_std': None,
                'valley_positions_list': [],
                'valley_depths_list': [],
                'all_curves': all_curves
            }
            print(f"入口 {edge}: 无谷底")

    # 定量判定
    print("\n=== 定量判定 ===")
    reproducible_count = 0
    total_valleys = 0
    for edge, res in protocol_results.items():
        if res['valley_s_mean'] is not None:
            total_valleys += 1
            if res['valley_s_std'] < 0.01:  # 位置标准差小于0.01视为可复现
                reproducible_count += 1

    print(f"总共观测入口：{len(edges)}")
    print(f"产生谷底的入口：{total_valleys}")
    print(f"位置可复现（std<0.01）：{reproducible_count}")

    # 均匀点交汇验证
    print("\n=== 均匀点 s=1 交汇验证 ===")
    e_at_s1 = []
    for edge, res in protocol_results.items():
        if res['all_curves']:
            s_idx = int(round((1.0 - S_MIN) / ((S_MAX - S_MIN) / (N_POINTS - 1))))
            e_val = res['all_curves'][0][s_idx]
            e_at_s1.append(e_val)
    if e_at_s1:
        print(f"所有入口在 s=1 处的 E 值：均值={np.mean(e_at_s1):.6f}, "
              f"标准差={np.std(e_at_s1):.6f}")
        if np.std(e_at_s1) < 1e-10:
            print("结论：所有入口在均匀点看到完全相同的显现。")
        else:
            print("结论：均匀点交汇有微小数值偏差。")

    output = {
        'graph': f'smallworld N={N}',
        'edges': [list(e) for e in edges],
        's_values': s_values.tolist(),
        'degen_sectors': degen,
        'protocol_results': protocol_results,
        'summary': {
            'total_entrances': len(edges),
            'valleys_found': total_valleys,
            'reproducible_valleys': reproducible_count,
            'reproducibility_threshold': 0.01
        }
    }
    with open('observation_protocol_quantitative.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)

    print("\n结果已保存至 observation_protocol_quantitative.json")
    print("\n协议结论：谷底是哈密顿量结构在观测入口下的确定性显现。")
    print("计算即预测。选定入口，扫描观测参数，谷底自然出现。")

if __name__ == "__main__":
    main()