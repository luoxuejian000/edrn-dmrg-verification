"""
流代数结构转变沉默失谐诊断
基于白宇霆-Phillips Sugawara型流代数哈密顿量 (Eq.23)
U参数驱动SU(2)→U(1)代数结构转变
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tenpy.models.model import CouplingMPOModel
from tenpy.models.lattice import Chain
from tenpy.networks.site import SpinHalfSite
from tenpy.networks.mps import MPS
from tenpy.algorithms import dmrg

class SugawaraModel(CouplingMPOModel):
    """Sugawara型流代数哈密顿量：H = vF/(2πL) Σ ϱ² - U Σ ϱ^z"""
    def __init__(self, model_params):
        L = model_params.get('L', 8)
        self.vF = model_params.get('vF', 1.0)
        self.U = model_params.get('U', 0.0)
        lat = Chain(L, SpinHalfSite(conserve='Sz'), bc='open')
        model_params['lattice'] = lat
        CouplingMPOModel.__init__(self, model_params)

    def init_terms(self, model_params):
        L = self.lat.N_sites
        for i in range(L-1):
            self.add_coupling_term(self.vF * 0.5, i, i+1, 'Sp', 'Sm', plus_hc=True)
            self.add_coupling_term(self.vF, i, i+1, 'Sz', 'Sz')
        for i in range(L):
            self.add_local_term(-self.U, [('Sz', [i, 0])])


def run_current_algebra_scan(L=8, vF=1.0, U_values=None, chi_max=100):
    if U_values is None:
        U_values = np.linspace(0.0, 3.0, 13)
    
    gaps, coarse_vals, fine_vals = [], [], []
    print(f"\n=== 流代数沉默失谐诊断 (L={L}, vF={vF}) ===")
    
    for U in U_values:
        M = SugawaraModel(dict(L=L, vF=vF, U=U, bc_MPS='finite', conserve='Sz'))
        init = ['up', 'down'] * (L // 2)
        if L % 2 == 1:
            init.append('up')
        psi = MPS.from_product_state(M.lat.mps_sites(), init, bc='finite')
        dmrg_params = {'mixer': True, 'chi_max': chi_max, 'max_sweeps': 50, 'verbose': 0}
        
        eng = dmrg.run(psi, M, dmrg_params)
        E0 = eng['E']
        
        init_ex = init.copy()
        center = L // 2
        init_ex[center] = 'down' if init[center] == 'up' else 'up'
        psi_ex = MPS.from_product_state(M.lat.mps_sites(), init_ex, bc='finite')
        eng_ex = dmrg.run(psi_ex, M, dmrg_params)
        E1 = eng_ex['E']
        gap = E1 - E0

        Sz = psi.expectation_value('Sz')
        coarse = np.mean(np.abs(Sz))
        corrs = []
        for i in range(L - 1):
            corr = psi.correlation_function('Sz', 'Sz', [i], [i+1])
            corrs.append(corr[0])
        fine = np.std(corrs) if corrs else 0.0
        
        gaps.append(gap)
        coarse_vals.append(coarse)
        fine_vals.append(fine)
        print(f"U={U:.2f}: gap={gap:.6f}, coarse={coarse:.4f}, fine={fine:.4f}")
    
    return np.array(U_values), np.array(gaps), np.array(coarse_vals), np.array(fine_vals)


if __name__ == "__main__":
    L = 8
    vF = 1.0
    U_values = np.linspace(0.0, 3.0, 13)
    
    U_vals, gaps, coarse, fine = run_current_algebra_scan(L, vF, U_values, chi_max=100)
    
    np.savetxt('current_algebra_sd.csv',
               np.column_stack((U_vals, gaps, coarse, fine)),
               header='U,gap,coarse,fine', delimiter=',')
    
    fig, ax1 = plt.subplots(figsize=(10,6))
    ax1.plot(U_vals, coarse, 'o-', label='Default diagnosis')
    ax2 = ax1.twinx()
    ax2.plot(U_vals, fine, 's-', color='red', label='Enhanced diagnosis')
    ax1.set_xlabel('U (Zeeman splitting)')
    ax1.set_ylabel('Default metric')
    ax2.set_ylabel('Enhanced metric')
    ax1.legend(loc='upper left')
    ax2.legend(loc='upper right')
    plt.title(f'Silent Discordance in Current Algebra (L={L})')
    plt.tight_layout()
    plt.savefig('current_algebra_sd.png')
    print("Done.")