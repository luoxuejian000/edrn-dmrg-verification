"""
延长轨迹隧穿实验 —— 金箍棒 3.0 DMRG
检验：ε=0.30下，结构隧穿事件是否重复出现？三维轨迹是否闭合？
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tenpy.models.model import CouplingMPOModel
from tenpy.models.lattice import Chain
from tenpy.networks.site import SpinHalfSite
from tenpy.networks.mps import MPS
from tenpy.algorithms import dmrg

class TunnelingModel(CouplingMPOModel):
    """链式Heisenberg模型 + 纵向磁场，矛盾边位置和强度可独立设置"""
    def __init__(self, model_params):
        L = model_params.get('L', 10)
        self.contradiction_strength = model_params.get('contradiction_strength', 0.5)
        self.contradiction_edge = model_params.get('contradiction_edge', (L//2 - 1, L//2))
        self.hz = model_params.get('hz', 0.0)
        
        # 预计算所有最近邻键的强度数组
        J_vals = np.ones(L - 1)
        ci, cj = self.contradiction_edge
        # 矛盾边在数组中的位置（键 (i,i+1) 对应数组索引 i）
        if ci < L - 1 and cj == ci + 1:
            J_vals[ci] = self.contradiction_strength
        
        self.J_vals = J_vals
        
        lat = Chain(L, SpinHalfSite(conserve=None), bc='open')
        model_params['lattice'] = lat
        CouplingMPOModel.__init__(self, model_params)

    def init_terms(self, model_params=None):
        if model_params is None:
            model_params = {}
        L = self.lat.N_sites
        # Heisenberg 项：XX+YY (使用数组形式的强度，unit_cell=0，dx=[1])
        self.add_coupling(self.J_vals * 0.5, 0, 'Sp', 0, 'Sm', dx=[1], plus_hc=True)
        # Heisenberg 项：ZZ (同样使用数组形式)
        self.add_coupling(self.J_vals, 0, 'Sz', 0, 'Sz', dx=[1])
        # 纵向磁场
        for i in range(L):
            self.add_onsite_term(-self.hz, i, 'Sz')


def compute_diagnostics(L, contradiction_edge, s, hz, chi_max=100):
    """用DMRG计算基态，返回能隙、默认诊断、精细诊断和边关联涨落列表"""
    M = TunnelingModel(dict(
        L=L, contradiction_edge=contradiction_edge,
        contradiction_strength=s, hz=hz,
        bc_MPS='finite', conserve=None
    ))
    init = ['up', 'down'] * (L // 2)
    if L % 2 == 1: init.append('up')
    psi = MPS.from_product_state(M.lat.mps_sites(), init, bc='finite')
    dmrg_params = {'mixer': True, 'chi_max': chi_max, 'max_sweeps': 50, 'verbose': 0}
    eng = dmrg.run(psi, M, dmrg_params)
    E0 = eng['E']

    init_ex = init.copy()
    center = L // 2
    init_ex[center] = 'down' if init_ex[center] == 'up' else 'up'
    psi_ex = MPS.from_product_state(M.lat.mps_sites(), init_ex, bc='finite')
    eng_ex = dmrg.run(psi_ex, M, dmrg_params)
    E1 = eng_ex['E']
    gap = E1 - E0

    Sz = psi.expectation_value('Sz')
    coarse = np.mean(np.abs(Sz))

    corrs = []
    for i in range(L - 1):
        corr = psi.correlation_function('Sz', 'Sz', [i], [i+1])
        corrs.append(corr[0])
    fine = np.std(corrs) if corrs else 0.0

    return gap, coarse, fine, corrs


def find_max_correlation_edge(corrs):
    """找到关联涨落最大的边"""
    abs_corrs = np.abs(corrs)
    max_idx = np.argmax(abs_corrs)
    return (max_idx, max_idx + 1)


def run_long_trajectory(L=10, fold_steps=120, contradiction_strength=0.5,
                         hz=0.1, epsilon=0.30, seed=42, chi_max=100):
    """
    延长轨迹隧穿实验：
    记录每一步的状态向量 (gap, coarse, fine)，用于三维轨迹分析。
    """
    np.random.seed(seed)
    gaps, coarse_vals, fine_vals = [], [], []
    fold_path = []

    current_edge = (L//2 - 1, L//2)
    print(f"延长轨迹实验：N={L}, hz={hz}, epsilon={epsilon}, 步数={fold_steps}")
    
    for step in range(fold_steps):
        gap, coarse, fine, corrs = compute_diagnostics(L, current_edge, contradiction_strength, hz, chi_max)
        gaps.append(gap)
        coarse_vals.append(coarse)
        fine_vals.append(fine)
        fold_path.append(current_edge)

        if np.random.random() < epsilon:
            next_idx = np.random.randint(0, L - 1)
            next_edge = (next_idx, next_idx + 1)
        else:
            next_edge = find_max_correlation_edge(corrs)

        if step % 10 == 0:
            print(f"Step {step}: edge={current_edge}, gap={gap:.6f}, coarse={coarse:.4f}, fine={fine:.6f}")
        current_edge = next_edge

    return np.array(gaps), np.array(coarse_vals), np.array(fine_vals), fold_path


if __name__ == "__main__":
    L = 10
    fold_steps = 120
    contradiction_strength = 0.5
    hz = 0.1
    epsilon = 0.30
    seed = 42

    print(f"=== 延长轨迹隧穿实验 (L={L}, hz={hz}, epsilon={epsilon}, steps={fold_steps}) ===")
    gaps, coarse_vals, fine_vals, fold_path = run_long_trajectory(
        L, fold_steps, contradiction_strength, hz, epsilon, seed, chi_max=100
    )

    # 保存原始数据
    np.savetxt('long_trajectory_120steps.csv',
               np.column_stack((np.arange(fold_steps), gaps, coarse_vals, fine_vals)),
               header='step,gap,coarse,fine', delimiter=',')

    # 保存折叠路径
    with open('long_trajectory_path_120steps.txt', 'w') as f:
        f.write("step,edge_i,edge_j\n")
        for step, (i, j) in enumerate(fold_path):
            f.write(f"{step},{i},{j}\n")

    # =============================================
    # 三维轨迹可视化
    # =============================================
    fig = plt.figure(figsize=(12, 10))
    ax = fig.add_subplot(111, projection='3d')
    
    # 颜色映射：用步数作为颜色，观察时间演化
    steps = np.arange(fold_steps)
    colors = plt.cm.viridis(steps / fold_steps)
    
    for t in range(fold_steps - 1):
        ax.plot(gaps[t:t+2], coarse_vals[t:t+2], fine_vals[t:t+2], 
                color=colors[t], lw=0.8, alpha=0.7)
    
    # 标记起点和终点
    ax.scatter(*[gaps[0], coarse_vals[0], fine_vals[0]], 
               color='green', s=100, marker='o', label='Start')
    ax.scatter(*[gaps[-1], coarse_vals[-1], fine_vals[-1]], 
               color='red', s=100, marker='s', label='End')
    
    ax.set_xlabel('Gap'); ax.set_ylabel('Coarse'); ax.set_zlabel('Fine')
    ax.set_title(f'3D Trajectory (120 steps, ε={epsilon})')
    ax.legend()
    plt.tight_layout()
    plt.savefig('long_trajectory_3d.png', dpi=150)
    print("三维轨迹图已保存至 long_trajectory_3d.png")

    # =============================================
    # 闭合性分析
    # =============================================
    # 计算起点到终点的欧氏距离
    start_point = np.array([gaps[0], coarse_vals[0], fine_vals[0]])
    end_point = np.array([gaps[-1], coarse_vals[-1], fine_vals[-1]])
    start_end_distance = np.linalg.norm(end_point - start_point)
    
    # 计算轨迹的总长度
    total_length = 0.0
    for t in range(fold_steps - 1):
        p1 = np.array([gaps[t], coarse_vals[t], fine_vals[t]])
        p2 = np.array([gaps[t+1], coarse_vals[t+1], fine_vals[t+1]])
        total_length += np.linalg.norm(p2 - p1)
    
    # 闭合性指标：起点-终点距离 / 总长度
    # 该比值越小，轨迹越接近闭合
    closure_ratio = start_end_distance / total_length
    
    print("\n=== 三维轨迹闭合性分析 ===")
    print(f"起点位置: ({gaps[0]:.4f}, {coarse_vals[0]:.4f}, {fine_vals[0]:.4f})")
    print(f"终点位置: ({gaps[-1]:.4f}, {coarse_vals[-1]:.4f}, {fine_vals[-1]:.4f})")
    print(f"起点-终点距离: {start_end_distance:.6f}")
    print(f"轨迹总长度: {total_length:.6f}")
    print(f"闭合性比值 (距离/总长): {closure_ratio:.6f}")
    
    if closure_ratio < 0.1:
        print("结论: 轨迹趋向闭合 → 沉默失谐对应稳定的吸引子（极限环）")
    elif closure_ratio < 0.3:
        print("结论: 轨迹部分闭合 → 可能为缓慢漂移的吸引子")
    else:
        print("结论: 轨迹明显漂移 → 沉默失谐可能是暂态或混沌吸引子")

    # =============================================
    # 探索事件周期性分析
    # =============================================
    # 计算位移向量d(t)
    d_t = np.zeros(fold_steps)
    for t in range(1, fold_steps):
        delta = np.array([gaps[t] - gaps[t-1], 
                          coarse_vals[t] - coarse_vals[t-1], 
                          fine_vals[t] - fine_vals[t-1]])
        d_t[t] = np.sqrt(np.sum(delta**2))
    
    # 寻找d(t)的局部峰值
    d_peaks = []
    for t in range(2, fold_steps - 2):
        if d_t[t] > d_t[t-1] and d_t[t] > d_t[t-2] and d_t[t] > d_t[t+1] and d_t[t] > d_t[t+2]:
            d_peaks.append(t)
    
    # 计算峰值间隔的均值和标准差
    if len(d_peaks) >= 2:
        peak_intervals = np.diff(d_peaks)
        mean_interval = np.mean(peak_intervals)
        std_interval = np.std(peak_intervals)
        print(f"\n=== 探索事件周期性分析 ===")
        print(f"d(t)峰值数量: {len(d_peaks)}")
        print(f"峰值位置: {d_peaks}")
        print(f"峰值间隔均值: {mean_interval:.2f} ± {std_interval:.2f} 步")
        if std_interval < 0.3 * mean_interval:
            print("结论: d(t)峰值呈现明显周期性")
        else:
            print("结论: d(t)峰值间隔波动较大，周期性不明显")
    else:
        print(f"\n=== 探索事件周期性分析 ===")
        print(f"d(t)峰值数量: {len(d_peaks)} (不足2个，无法计算间隔)")

    # 保存闭合性分析结果
    with open('long_trajectory_closure_analysis.txt', 'w') as f:
        f.write(f"Start point: ({gaps[0]:.6f}, {coarse_vals[0]:.6f}, {fine_vals[0]:.6f})\n")
        f.write(f"End point: ({gaps[-1]:.6f}, {coarse_vals[-1]:.6f}, {fine_vals[-1]:.6f})\n")
        f.write(f"Start-end distance: {start_end_distance:.6f}\n")
        f.write(f"Total trajectory length: {total_length:.6f}\n")
        f.write(f"Closure ratio (distance/length): {closure_ratio:.6f}\n")
        f.write(f"d(t) peaks: {d_peaks}\n")
        if len(d_peaks) >= 2:
            f.write(f"Peak intervals mean: {mean_interval:.2f}, std: {std_interval:.2f}\n")
    
    print("\nDone. 全部数据已保存。")
