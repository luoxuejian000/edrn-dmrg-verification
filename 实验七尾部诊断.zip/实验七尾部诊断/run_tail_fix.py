import numpy as np
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')

def generate_valid_states(L):
    valid = []
    for n in range(2**L):
        s, ok, prev = n, True, 0
        for _ in range(L):
            bit = s & 1
            if bit == 1 and prev == 1:
                ok = False
                break
            prev = bit
            s >>= 1
        if ok:
            valid.append(n)
    return np.array(valid, dtype=int)

def build_hamiltonian(L, mu_defect, defect_site):
    valid = generate_valid_states(L)
    N = len(valid)
    state_to_idx = {s: i for i, s in enumerate(valid)}
    H = lil_matrix((N, N))
    for idx, s in enumerate(valid):
        bit_at_defect = (s >> defect_site) & 1
        H[idx, idx] -= mu_defect * bit_at_defect
        for j in range(L):
            left  = (s >> (j-1)) & 1 if j > 0 else 0
            right = (s >> (j+1)) & 1 if j < L-1 else 0
            if left or right: continue
            new_s = s ^ (1 << j)
            if new_s in state_to_idx:
                jdx = state_to_idx[new_s]
                H[idx, jdx] += 1.0
    return H.tocsc(), valid, state_to_idx

def compute_entanglement_spectrum(psi, L_sub, valid, state_to_idx):
    N = len(valid)
    rho_A = np.zeros((N, N), dtype=complex)
    for i in range(N):
        for j in range(N):
            si, sj = valid[i], valid[j]
            left_i = si & ((1 << L_sub) - 1)
            left_j = sj & ((1 << L_sub) - 1)
            right_i = si >> L_sub
            right_j = sj >> L_sub
            if right_i == right_j:
                rho_A[left_i, left_j] += psi[i] * np.conj(psi[j])
    eigvals = np.linalg.eigvalsh(rho_A)
    eigvals = np.sort(np.abs(eigvals))[::-1]
    return eigvals[eigvals > 1e-12]

def compute_correlation_matrix(L, psi, valid, state_to_idx):
    C = np.zeros((L, L))
    sz_exp = np.zeros(L)
    for i, s in enumerate(valid):
        prob = np.abs(psi[i])**2
        for j in range(L):
            bit = (s >> j) & 1
            sz_exp[j] += prob * (1 - 2*bit)
    for i in range(L):
        for j in range(L):
            corr = 0.0
            for k, s in enumerate(valid):
                bit_i = (s >> i) & 1
                bit_j = (s >> j) & 1
                val_i = 1.0 - 2.0*bit_i
                val_j = 1.0 - 2.0*bit_j
                corr += np.abs(psi[k])**2 * val_i * val_j
            C[i, j] = corr - sz_exp[i]*sz_exp[j]
    return C

def compute_tail_slope(eigvals, start_idx=2, end_idx=5):
    if len(eigvals) <= end_idx:
        return np.nan
    x = np.arange(start_idx, end_idx)
    y = np.log(eigvals[start_idx:end_idx])
    slope, _ = np.polyfit(x, y, 1)
    return slope

def run_diagnosis():
    L = 18
    L_sub = L // 2
    defect_site = L // 2
    mu_vals = np.linspace(0, 2.0, 15)

    print("纠缠谱尾部诊断器启动 (PXP L=18) - 修复版")
    H0, valid, stoi = build_hamiltonian(L, 0.0, defect_site)
    ev0, st0 = eigsh(H0, k=1, which='SA')

    results = []
    for mu in mu_vals:
        H, valid, stoi = build_hamiltonian(L, mu, defect_site)
        ev, st = eigsh(H, k=1, which='SA')
        psi = st[:, 0]

        C = compute_correlation_matrix(L, psi, valid, stoi)
        default_metric = np.mean(np.abs(C))
        eigs = compute_entanglement_spectrum(psi, L_sub, valid, stoi)
        enhanced_metric = np.std(eigs)
        tail_slope = compute_tail_slope(eigs, start_idx=2, end_idx=5) if len(eigs) > 5 else float('nan')

        results.append([mu, default_metric, enhanced_metric, tail_slope])
        print(f"  mu={mu:.2f}: mean|C|={default_metric:.4f}, ent_std={enhanced_metric:.6f}, tail_slope={tail_slope:.4f}")

    results = np.array(results)
    np.savetxt('tail_diagnosis_fix.csv', results,
               header='mu,mean_abs_C,entanglement_spectrum_std,tail_slope',
               delimiter=',', comments='')
    print("数据已保存至 tail_diagnosis_fix.csv")

    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    axes[0].plot(results[:,0], results[:,1], 'o-'); axes[0].set_title('Default')
    axes[1].plot(results[:,0], results[:,2], 's-'); axes[1].set_title('Enhanced')
    axes[2].plot(results[:,0], results[:,3], '^-'); axes[2].set_title('Tail Slope')
    plt.suptitle('Tail Diagnosis (PXP L=18)')
    plt.tight_layout()
    plt.savefig('tail_diagnosis_fix.png', dpi=150)
    print("图片已保存至 tail_diagnosis_fix.png")

if __name__ == "__main__":
    run_diagnosis()