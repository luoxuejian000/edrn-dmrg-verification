"""
马拉特隧穿实验 —— 金箍棒 3.0 DMRG（API 修复版）
研究结构隧穿：d(t)的尖峰是否出现在fine的峰值之前？
加入纵向磁场打破Sz守恒，验证默认诊断的盲视性。
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tenpy.models.model import CouplingMPOModel
from tenpy.models.lattice import Chain
from tenpy.networks.site import SpinHalfSite
from tenpy.networks.mps import MPS
from tenpy.algorithms import dmrg

class TunnelingModel(CouplingMPOModel):
    """链式Heisenberg模型 + 纵向磁场，矛盾边位置和强度可独立设置"""
    def __init__(self, model_params):
        L = model_params.get('L', 10)
        self.contradiction_strength = model_params.get('contradiction_strength', 0.5)
        self.contradiction_edge = model_params.get('contradiction_edge', (L//2 - 1, L//2))
        self.hz = model_params.get('hz', 0.0)  # 纵向磁场强度
        lat = Chain(L, SpinHalfSite(conserve=None), bc='open')  # 不守恒Sz
        model_params['lattice'] = lat
        CouplingMPOModel.__init__(self, model_params)

    def init_terms(self, model_params=None):
        if model_params is None:
            model_params = {}
        L = self.lat.N_sites
        # 构建耦合强度数组（与 destiny_test.py 一致的数组形式）
        J_arr = np.ones(L - 1)
        edge_i, edge_j = self.contradiction_edge
        if 0 <= edge_i < L - 1:
            J_arr[edge_i] = self.contradiction_strength
        # XX+YY 项 (非对角)
        self.add_coupling(J_arr * 0.5, 0, 'Sp', 0, 'Sm', dx=[1], plus_hc=True)
        # ZZ 项 (对角)
        self.add_coupling(J_arr, 0, 'Sz', 0, 'Sz', dx=[1])
        # 纵向磁场（破缺项）
        for i in range(L):
            self.add_onsite_term(-self.hz, i, 'Sz')


def compute_diagnostics(L, contradiction_edge, s, hz, chi_max=100):
    """用DMRG计算基态，返回能隙、默认诊断、精细诊断和边关联涨落列表"""
    M = TunnelingModel(dict(
        L=L, contradiction_edge=contradiction_edge,
        contradiction_strength=s, hz=hz,
        bc_MPS='finite', conserve=None  # 不守恒Sz
    ))
    init = ['up', 'down'] * (L // 2)
    if L % 2 == 1: init.append('up')
    psi = MPS.from_product_state(M.lat.mps_sites(), init, bc='finite')
    dmrg_params = {'mixer': True, 'chi_max': chi_max, 'max_sweeps': 50, 'verbose': 0}
    eng = dmrg.run(psi, M, dmrg_params)
    E0 = eng['E']
    
    init_ex = init.copy()
    center = L // 2
    init_ex[center] = 'down' if init_ex[center] == 'up' else 'up'
    psi_ex = MPS.from_product_state(M.lat.mps_sites(), init_ex, bc='finite')
    eng_ex = dmrg.run(psi_ex, M, dmrg_params)
    E1 = eng_ex['E']
    gap = E1 - E0

    Sz = psi.expectation_value('Sz')
    coarse = np.mean(np.abs(Sz))
    
    corrs = []
    for i in range(L - 1):
        corr = psi.correlation_function('Sz', 'Sz', [i], [i+1])
        corrs.append(corr[0])
    fine = np.std(corrs) if corrs else 0.0
    
    return gap, coarse, fine, corrs


def find_max_correlation_edge(corrs):
    """找到关联涨落最大的边"""
    abs_corrs = np.abs(corrs)
    max_idx = np.argmax(abs_corrs)
    return (max_idx, max_idx + 1)


def run_tunneling_experiment(L=10, fold_steps=30, contradiction_strength=0.5, 
                            hz=0.1, epsilon=0.1, seed=42, chi_max=100):
    """
    马拉特隧穿实验：
    自折叠 + 纵向磁场 + 随机探索。
    记录每一步的(gap, coarse, fine)，用于后续计算位移向量d(t)。
    """
    np.random.seed(seed)
    gaps, coarse_vals, fine_vals = [], [], []
    fold_path = []
    
    current_edge = (L//2 - 1, L//2)
    print(f"初始矛盾边: {current_edge}, hz={hz}, epsilon={epsilon}")
    
    for step in range(fold_steps):
        gap, coarse, fine, corrs = compute_diagnostics(L, current_edge, contradiction_strength, hz, chi_max)
        gaps.append(gap)
        coarse_vals.append(coarse)
        fine_vals.append(fine)
        fold_path.append(current_edge)
        
        # 选择下一步：以概率epsilon随机，否则选最大涨落边
        if np.random.random() < epsilon:
            # 随机探索：随机选一条边（共L-1条边）
            next_idx = np.random.randint(0, L - 1)
            next_edge = (next_idx, next_idx + 1)
        else:
            next_edge = find_max_correlation_edge(corrs)
        
        print(f"Step {step}: edge={current_edge}, gap={gap:.6f}, coarse={coarse:.4f}, fine={fine:.6f}, next→{next_edge}")
        current_edge = next_edge
    
    return np.array(gaps), np.array(coarse_vals), np.array(fine_vals), fold_path


if __name__ == "__main__":
    L = 10
    fold_steps = 30
    contradiction_strength = 0.5
    hz = 0.1
    epsilon = 0.1
    seed = 42
    
    print(f"=== 马拉特隧穿实验 (L={L}, hz={hz}, epsilon={epsilon}) ===")
    print("检验：d(t)的尖峰是否出现在fine的峰值之前\n")
    
    gaps, coarse_vals, fine_vals, fold_path = run_tunneling_experiment(
        L, fold_steps, contradiction_strength, hz, epsilon, seed, chi_max=100
    )
    
    # 保存原始数据
    np.savetxt('marat_tunneling_results.csv',
               np.column_stack((np.arange(fold_steps), gaps, coarse_vals, fine_vals)),
               header='step,gap,coarse,fine', delimiter=',')
    
    # 保存折叠路径
    with open('marat_tunneling_path.txt', 'w') as f:
        f.write("step,edge_i,edge_j\n")
        for step, (i, j) in enumerate(fold_path):
            f.write(f"{step},{i},{j}\n")
    
    # =============================================
    # 马拉特的结构隧穿分析：计算位移向量d(t)
    # =============================================
    d_t = np.zeros(fold_steps)
    for t in range(1, fold_steps):
        delta = np.array([gaps[t] - gaps[t-1], 
                          coarse_vals[t] - coarse_vals[t-1], 
                          fine_vals[t] - fine_vals[t-1]])
        d_t[t] = np.sqrt(np.sum(delta**2))
    
    # 寻找d(t)的局部峰值（两侧比它低的点）
    d_peaks = []
    for t in range(2, fold_steps - 2):
        if d_t[t] > d_t[t-1] and d_t[t] > d_t[t-2] and d_t[t] > d_t[t+1] and d_t[t] > d_t[t+2]:
            d_peaks.append(t)
    
    # 寻找fine的局部峰值（两侧比它低的点）
    fine_peaks = []
    for t in range(2, fold_steps - 2):
        if fine_vals[t] > fine_vals[t-1] and fine_vals[t] > fine_vals[t-2] and fine_vals[t] > fine_vals[t+1] and fine_vals[t] > fine_vals[t+2]:
            fine_peaks.append(t)
    
    print("\n=== 结构隧穿分析 ===")
    print(f"位移向量d(t)的峰值位置: {d_peaks}")
    print(f"增强诊断fine的峰值位置: {fine_peaks}")
    
    # 检查d(t)峰值是否在fine峰值之前
    tunneling_events = []
    for fpeak in fine_peaks:
        preceding_d = [d for d in d_peaks if d < fpeak]
        if preceding_d:
            tunneling_events.append((preceding_d[-1], fpeak))
    
    if tunneling_events:
        print(f"\n发现结构隧穿事件: d(t)峰值 → fine峰值 的时间顺序")
        for d_p, f_p in tunneling_events:
            print(f"  d(t)峰值在step {d_p}, fine峰值在step {f_p} (超前 {f_p - d_p} 步)")
    else:
        print("\n未检测到d(t)在fine之前的峰值。")
    
    # =============================================
    # 诊断图：位移向量 vs 增强诊断
    # =============================================
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
    
    steps = np.arange(fold_steps)
    
    # 左图：默认诊断
    ax1.plot(steps, coarse_vals, 'o-', label='Default diagnosis (coarse)', color='#1f77b4')
    ax1.set_xlabel('Fold step'); ax1.set_ylabel('Coarse metric')
    ax1.set_title(f'Entity Blindness Test (hz={hz})')
    ax1.grid(True, alpha=0.3)
    
    # 右图：增强诊断 + 位移向量（双轴）
    ax2.plot(steps, fine_vals, 's-', label='Enhanced diagnosis (fine)', color='#d62728')
    ax2.set_xlabel('Fold step'); ax2.set_ylabel('Fine metric', color='#d62728')
    ax2.tick_params(axis='y', labelcolor='#d62728')
    
    ax2_right = ax2.twinx()
    ax2_right.plot(steps, d_t, '^-', label='Displacement d(t)', color='#2ca02c', markersize=4)
    ax2_right.set_ylabel('Displacement d(t)', color='#2ca02c')
    ax2_right.tick_params(axis='y', labelcolor='#2ca02c')
    
    # 标注隧穿事件
    for d_p, f_p in tunneling_events:
        ax2.axvspan(d_p, f_p, alpha=0.15, color='orange')
        ax2.annotate(f'd→fine', (d_p, fine_vals[d_p]),
                     textcoords="offset points", xytext=(0,10), ha='center', fontsize=8)
    
    lines1, labels1 = ax2.get_legend_handles_labels()
    lines2, labels2 = ax2_right.get_legend_handles_labels()
    ax2.legend(lines1 + lines2, labels1 + labels2, fontsize=8)
    ax2.set_title('Structural Tunneling: d(t) vs fine')
    ax2.grid(True, alpha=0.3)
    
    plt.suptitle(f'Marat Tunneling Experiment (L={L}, hz={hz}, epsilon={epsilon})')
    plt.tight_layout()
    plt.savefig('marat_tunneling_diagnosis.png', dpi=150)
    
    print("\nDone. 数据已保存。")
