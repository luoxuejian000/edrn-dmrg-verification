"""
随机扫描对照实验 —— 金箍棒 3.0 DMRG
随机打乱s值顺序，每个s值用随机初始波函数独立计算
严格检验：关系场的状态是否不由路径决定？
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tenpy.models.model import CouplingMPOModel
from tenpy.models.lattice import Chain
from tenpy.networks.site import SpinHalfSite
from tenpy.networks.mps import MPS
from tenpy.algorithms import dmrg

class RandomScanModel(CouplingMPOModel):
    """链式Heisenberg模型，矛盾边强度可独立设置"""
    def __init__(self, model_params):
        L = model_params.get('L', 8)
        self.contradiction_strength = model_params.get('contradiction_strength', 1.0)
        self.contradiction_edge = model_params.get('contradiction_edge', (L//2 - 1, L//2))
        lat = Chain(L, SpinHalfSite(conserve='Sz'), bc='open')
        model_params['lattice'] = lat
        CouplingMPOModel.__init__(self, model_params)

    def init_terms(self, model_params):
        L = self.lat.N_sites
        for i in range(L-1):
            if (i, i+1) == self.contradiction_edge or (i+1, i) == self.contradiction_edge:
                J = self.contradiction_strength
            else:
                J = 1.0
            self.add_coupling_term(J * 0.5, i, i+1, 'Sp', 'Sm', plus_hc=True)
            self.add_coupling_term(J, i, i+1, 'Sz', 'Sz')


def random_initial_state(L):
    """生成完全随机的初始自旋构型，不依赖于任何前序计算结果"""
    spins = []
    for _ in range(L):
        spins.append(np.random.choice(['up', 'down']))
    return spins


def run_random_scan(L, contradiction_edge, s_values, chi_max=100):
    """随机扫描：每个s值用随机初始波函数独立计算"""
    s_shuffled = s_values.copy()
    np.random.shuffle(s_shuffled)
    
    print(f"随机扫描顺序: {s_shuffled}")
    
    results = {}
    
    for s in s_shuffled:
        M = RandomScanModel(dict(
            L=L,
            contradiction_edge=contradiction_edge,
            contradiction_strength=s,
            bc_MPS='finite', conserve='Sz'
        ))
        
        init = random_initial_state(L)
        psi = MPS.from_product_state(M.lat.mps_sites(), init, bc='finite')
        dmrg_params = {'mixer': True, 'chi_max': chi_max, 'max_sweeps': 50, 'verbose': 0}
        
        try:
            eng = dmrg.run(psi, M, dmrg_params)
            E0 = eng['E']
            
            init_ex = random_initial_state(L)
            psi_ex = MPS.from_product_state(M.lat.mps_sites(), init_ex, bc='finite')
            eng_ex = dmrg.run(psi_ex, M, dmrg_params)
            E1 = eng_ex['E']
            gap = E1 - E0

            Sz = psi.expectation_value('Sz')
            coarse = np.mean(np.abs(Sz))
            corrs = []
            for i in range(L - 1):
                corr = psi.correlation_function('Sz', 'Sz', [i], [i+1])
                corrs.append(corr[0])
            fine = np.std(corrs) if corrs else 0.0
            
            results[s] = (gap, coarse, fine)
            print(f"s={s:.2f}: gap={gap:.6f}, coarse={coarse:.4f}, fine={fine:.4f}")
        except Exception as e:
            print(f"s={s:.2f}: DMRG failed ({e}), retrying with different random init...")
            init_retry = random_initial_state(L)
            psi_retry = MPS.from_product_state(M.lat.mps_sites(), init_retry, bc='finite')
            eng_retry = dmrg.run(psi_retry, M, dmrg_params)
            E0 = eng_retry['E']
            init_ex_retry = random_initial_state(L)
            psi_ex_retry = MPS.from_product_state(M.lat.mps_sites(), init_ex_retry, bc='finite')
            eng_ex_retry = dmrg.run(psi_ex_retry, M, dmrg_params)
            E1 = eng_ex_retry['E']
            gap = E1 - E0
            Sz = psi_retry.expectation_value('Sz')
            coarse = np.mean(np.abs(Sz))
            corrs = []
            for i in range(L - 1):
                corr = psi_retry.correlation_function('Sz', 'Sz', [i], [i+1])
                corrs.append(corr[0])
            fine = np.std(corrs) if corrs else 0.0
            results[s] = (gap, coarse, fine)
            print(f"s={s:.2f} (retry): gap={gap:.6f}, coarse={coarse:.4f}, fine={fine:.4f}")
    
    s_sorted = sorted(results.keys())
    gaps = [results[s][0] for s in s_sorted]
    coarse_vals = [results[s][1] for s in s_sorted]
    fine_vals = [results[s][2] for s in s_sorted]
    
    return np.array(s_sorted), np.array(gaps), np.array(coarse_vals), np.array(fine_vals)


if __name__ == "__main__":
    L = 8
    contradiction_edge = (L//2 - 1, L//2)
    s_values = np.linspace(0.0, 3.0, 13)
    
    print("=== 随机扫描对照实验 (L=8, Heisenberg) ===")
    print("每个s值使用完全随机的初始波函数，独立计算")
    print("扫描顺序已随机打乱，消除任何路径依赖\n")
    
    s_random, gaps_random, coarse_random, fine_random = run_random_scan(
        L, contradiction_edge, s_values, chi_max=100
    )
    
    # 保存数据
    np.savetxt('random_scan_results.csv',
               np.column_stack((s_random, gaps_random, coarse_random, fine_random)),
               header='s,gap,coarse,fine', delimiter=',')
    print("\n数据已保存: random_scan_results.csv")
    
    # 如果之前跑过正向扫描，加载并对比
    try:
        fwd_data = np.loadtxt('time_arrow_forward.csv', delimiter=',', skiprows=1)
        s_fwd = fwd_data[:, 0]
        fine_fwd = fwd_data[:, 3]
        
        bwd_data = np.loadtxt('time_arrow_backward.csv', delimiter=',', skiprows=1)
        s_bwd = bwd_data[:, 0]
        fine_bwd = bwd_data[:, 3]
        
        # 对比图：随机 vs 正向 vs 逆向
        fig, ax = plt.subplots(figsize=(10, 6))
        ax.plot(s_fwd, fine_fwd, 'o-', label='Forward (0→3)', color='#1f77b4', markersize=6)
        ax.plot(s_bwd, fine_bwd, 's--', label='Backward (3→0)', color='#d62728', markersize=6)
        ax.plot(s_random, fine_random, '^:', label='Random (shuffled)', color='#2ca02c', markersize=8)
        ax.set_xlabel('Contradiction strength s')
        ax.set_ylabel('Enhanced diagnosis (fine)')
        ax.set_title('Path Independence Test: Random vs Ordered Scan')
        ax.legend()
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig('random_scan_control.png', dpi=150)
        print("对比图已保存: random_scan_control.png")
        
        # 定量对比：随机扫描与正向扫描的最大偏差
        max_dev = 0.0
        for s_val, f_random in zip(s_random, fine_random):
            idx = np.argmin(np.abs(s_fwd - s_val))
            f_fwd = fine_fwd[idx]
            dev = abs(f_random - f_fwd)
            if dev > max_dev:
                max_dev = dev
        print(f"\n随机扫描与正向扫描的最大偏差: {max_dev:.6f}")
        print(f"（如果此值在DMRG收敛精度范围内，则路径无关性成立）")
        
    except FileNotFoundError:
        print("（未找到正向/逆向扫描数据，仅保存随机扫描结果）")
    
    print("\nDone.")