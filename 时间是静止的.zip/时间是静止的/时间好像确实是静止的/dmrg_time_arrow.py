"""
DMRG 时间箭头检验 —— 金箍棒 3.0 DMRG
正向扫描 vs 逆向扫描 vs 随机扫描
检验：关系场在N=12上是否仍然路径无关？
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tenpy.models.model import CouplingMPOModel
from tenpy.models.lattice import Chain
from tenpy.networks.site import SpinHalfSite
from tenpy.networks.mps import MPS
from tenpy.algorithms import dmrg

class TimeArrowModel(CouplingMPOModel):
    """链式Heisenberg模型，矛盾边强度可独立设置"""
    def __init__(self, model_params):
        L = model_params.get('L', 12)
        self.contradiction_strength = model_params.get('contradiction_strength', 1.0)
        self.contradiction_edge = model_params.get('contradiction_edge', (L//2 - 1, L//2))
        lat = Chain(L, SpinHalfSite(conserve='Sz'), bc='open')
        model_params['lattice'] = lat
        CouplingMPOModel.__init__(self, model_params)

    def init_terms(self, model_params):
        L = self.lat.N_sites
        for i in range(L-1):
            if (i, i+1) == self.contradiction_edge or (i+1, i) == self.contradiction_edge:
                J = self.contradiction_strength
            else:
                J = 1.0
            self.add_coupling_term(J * 0.5, i, i+1, 'Sp', 'Sm', plus_hc=True)
            self.add_coupling_term(J, i, i+1, 'Sz', 'Sz')


def random_initial_state(L):
    """生成完全随机的初始自旋构型"""
    spins = []
    for _ in range(L):
        spins.append(np.random.choice(['up', 'down']))
    return spins


def compute_diagnostics(L, contradiction_edge, s, chi_max=100, use_random_init=False):
    """用DMRG计算基态，返回能隙、默认诊断和精细诊断"""
    M = TimeArrowModel(dict(
        L=L,
        contradiction_edge=contradiction_edge,
        contradiction_strength=s,
        bc_MPS='finite', conserve='Sz'
    ))
    
    if use_random_init:
        init = random_initial_state(L)
    else:
        init = ['up', 'down'] * (L // 2)
        if L % 2 == 1:
            init.append('up')
    
    psi = MPS.from_product_state(M.lat.mps_sites(), init, bc='finite')
    dmrg_params = {'mixer': True, 'chi_max': chi_max, 'max_sweeps': 50, 'verbose': 0}
    
    eng = dmrg.run(psi, M, dmrg_params)
    E0 = eng['E']
    
    init_ex = init.copy()
    center = L // 2
    init_ex[center] = 'down' if init_ex[center] == 'up' else 'up'
    psi_ex = MPS.from_product_state(M.lat.mps_sites(), init_ex, bc='finite')
    eng_ex = dmrg.run(psi_ex, M, dmrg_params)
    E1 = eng_ex['E']
    gap = E1 - E0

    Sz = psi.expectation_value('Sz')
    coarse = np.mean(np.abs(Sz))
    corrs = []
    for i in range(L - 1):
        corr = psi.correlation_function('Sz', 'Sz', [i], [i+1])
        corrs.append(corr[0])
    fine = np.std(corrs) if corrs else 0.0
    
    return gap, coarse, fine


def run_ordered_scan(L, contradiction_edge, s_values, label, chi_max=100, use_random_init=False):
    """沿指定s序列扫描，返回诊断数据"""
    gaps, coarse_vals, fine_vals = [], [], []
    print(f"\n=== {label} ===")
    for s in s_values:
        gap, coarse, fine = compute_diagnostics(L, contradiction_edge, s, chi_max, use_random_init)
        gaps.append(gap)
        coarse_vals.append(coarse)
        fine_vals.append(fine)
        print(f"s={s:.2f}: gap={gap:.6f}, coarse={coarse:.4f}, fine={fine:.4f}")
    return np.array(gaps), np.array(coarse_vals), np.array(fine_vals)


if __name__ == "__main__":
    L = 12
    contradiction_edge = (L//2 - 1, L//2)  # (5,6)
    s_values = np.linspace(0.0, 3.0, 13)
    
    # === 正向扫描 ===
    s_fwd = s_values.copy()
    gaps_fwd, coarse_fwd, fine_fwd = run_ordered_scan(L, contradiction_edge, s_fwd, "正向扫描 (s: 0→3)", chi_max=100)
    
    # === 逆向扫描 ===
    s_bwd = s_values[::-1].copy()
    gaps_bwd, coarse_bwd, fine_bwd = run_ordered_scan(L, contradiction_edge, s_bwd, "逆向扫描 (s: 3→0)", chi_max=100)
    
    # === 随机扫描（3组独立随机顺序，使用随机初始态）===
    all_random_fine = []
    for run_id in range(1, 4):
        np.random.seed(run_id * 42)
        s_random = s_values.copy()
        np.random.shuffle(s_random)
        gaps_rnd, coarse_rnd, fine_rnd = run_ordered_scan(
            L, contradiction_edge, s_random,
            f"随机扫描 #{run_id} (随机初始态)", chi_max=100, use_random_init=True
        )
        sort_idx = np.argsort(s_random)
        all_random_fine.append((s_random[sort_idx], fine_rnd[sort_idx], coarse_rnd[sort_idx]))
    
    # === 保存数据 ===
    np.savetxt('dmrg_forward.csv',
               np.column_stack((s_fwd, gaps_fwd, coarse_fwd, fine_fwd)),
               header='s,gap,coarse,fine', delimiter=',')
    np.savetxt('dmrg_backward.csv',
               np.column_stack((s_bwd, gaps_bwd, coarse_bwd, fine_bwd)),
               header='s,gap,coarse,fine', delimiter=',')
    for run_id, (s_rnd, fine_rnd, coarse_rnd) in enumerate(all_random_fine, start=1):
        np.savetxt(f'dmrg_random_run{run_id}.csv',
                   np.column_stack((s_rnd, fine_rnd, coarse_rnd)),
                   header='s,fine,coarse', delimiter=',')
    
    # === 对比图 ===
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
    
    ax1.plot(s_fwd, fine_fwd, 'o-', label='Forward', color='#1f77b4', lw=2)
    ax1.plot(s_bwd, fine_bwd, 's--', label='Backward', color='#d62728', lw=2)
    colors = ['#2ca02c', '#9467bd', '#8c564b']
    for run_id, (s_rnd, fine_rnd, _) in enumerate(all_random_fine):
        ax1.plot(s_rnd, fine_rnd, '^:', label=f'Random #{run_id+1}', color=colors[run_id], ms=5)
    ax1.set_xlabel('s')
    ax1.set_ylabel('Fine diagnosis')
    ax1.set_title(f'DMRG Time Arrow Test: Enhanced Diagnosis (N={L})')
    ax1.legend(fontsize=7)
    ax1.grid(True, alpha=0.3)
    
    ax2.plot(s_fwd, coarse_fwd, 'o-', label='Forward', color='#1f77b4', lw=2)
    ax2.plot(s_bwd, coarse_bwd, 's--', label='Backward', color='#d62728', lw=2)
    for run_id, (s_rnd, _, coarse_rnd) in enumerate(all_random_fine):
        ax2.plot(s_rnd, coarse_rnd, '^:', label=f'Random #{run_id+1}', color=colors[run_id], ms=5)
    ax2.set_xlabel('s')
    ax2.set_ylabel('Coarse diagnosis')
    ax2.set_title(f'DMRG Time Arrow Test: Default Diagnosis (N={L})')
    ax2.legend(fontsize=7)
    ax2.grid(True, alpha=0.3)
    
    plt.suptitle(f'DMRG Time Arrow Test (N={L}, Heisenberg)')
    plt.tight_layout()
    plt.savefig('dmrg_time_arrow_test.png', dpi=150)
    
    # === 定量统计 ===
    print("\n=== 定量对比 ===")
    for run_id, (s_rnd, fine_rnd, _) in enumerate(all_random_fine, start=1):
        max_dev = np.max(np.abs(fine_rnd - fine_fwd))
        mean_dev = np.mean(np.abs(fine_rnd - fine_fwd))
        print(f"随机扫描#{run_id} vs 正向扫描: 最大偏差={max_dev:.6f}, 平均偏差={mean_dev:.6f}")
    
    print("\nDone. 所有数据已保存。")