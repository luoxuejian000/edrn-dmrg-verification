"""
时间箭头诊断 —— 金箍棒 3.0 DMRG
正向扫描(s=0→3) vs 逆向扫描(s=3→0)
检验：时间在关系场中是流动的(不可逆)还是静止的(可逆)？
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tenpy.models.model import CouplingMPOModel
from tenpy.models.lattice import Chain
from tenpy.networks.site import SpinHalfSite
from tenpy.networks.mps import MPS
from tenpy.algorithms import dmrg

class TimeArrowModel(CouplingMPOModel):
    """链式Heisenberg模型，矛盾边强度可独立设置"""
    def __init__(self, model_params):
        L = model_params.get('L', 8)
        self.contradiction_strength = model_params.get('contradiction_strength', 1.0)
        self.contradiction_edge = model_params.get('contradiction_edge', (L//2 - 1, L//2))
        lat = Chain(L, SpinHalfSite(conserve='Sz'), bc='open')
        model_params['lattice'] = lat
        CouplingMPOModel.__init__(self, model_params)

    def init_terms(self, model_params):
        L = self.lat.N_sites
        for i in range(L-1):
            if (i, i+1) == self.contradiction_edge or (i+1, i) == self.contradiction_edge:
                J = self.contradiction_strength
            else:
                J = 1.0
            self.add_coupling_term(J * 0.5, i, i+1, 'Sp', 'Sm', plus_hc=True)
            self.add_coupling_term(J, i, i+1, 'Sz', 'Sz')


def run_scan(L, contradiction_edge, s_values, chi_max=100):
    """沿指定s序列扫描，返回诊断数据"""
    gaps, coarse_vals, fine_vals = [], [], []
    
    for s in s_values:
        M = TimeArrowModel(dict(
            L=L,
            contradiction_edge=contradiction_edge,
            contradiction_strength=s,
            bc_MPS='finite', conserve='Sz'
        ))
        init = ['up', 'down'] * (L // 2)
        if L % 2 == 1:
            init.append('up')
        psi = MPS.from_product_state(M.lat.mps_sites(), init, bc='finite')
        dmrg_params = {'mixer': True, 'chi_max': chi_max, 'max_sweeps': 50, 'verbose': 0}
        
        eng = dmrg.run(psi, M, dmrg_params)
        E0 = eng['E']
        
        init_ex = init.copy()
        center = L // 2
        init_ex[center] = 'down' if init[center] == 'up' else 'up'
        psi_ex = MPS.from_product_state(M.lat.mps_sites(), init_ex, bc='finite')
        eng_ex = dmrg.run(psi_ex, M, dmrg_params)
        E1 = eng_ex['E']
        gap = E1 - E0

        Sz = psi.expectation_value('Sz')
        coarse = np.mean(np.abs(Sz))
        corrs = []
        for i in range(L - 1):
            corr = psi.correlation_function('Sz', 'Sz', [i], [i+1])
            corrs.append(corr[0])
        fine = np.std(corrs) if corrs else 0.0
        
        gaps.append(gap)
        coarse_vals.append(coarse)
        fine_vals.append(fine)
        print(f"s={s:.2f}: gap={gap:.6f}, coarse={coarse:.4f}, fine={fine:.4f}")
    
    return np.array(gaps), np.array(coarse_vals), np.array(fine_vals)


if __name__ == "__main__":
    L = 8
    contradiction_edge = (L//2 - 1, L//2)
    
    # 正向扫描：s从0到3
    s_forward = np.linspace(0.0, 3.0, 13)
    print("=== 正向扫描 (s: 0 → 3) ===")
    gaps_fwd, coarse_fwd, fine_fwd = run_scan(L, contradiction_edge, s_forward, chi_max=100)
    
    # 逆向扫描：s从3到0
    s_backward = np.linspace(3.0, 0.0, 13)
    print("\n=== 逆向扫描 (s: 3 → 0) ===")
    gaps_bwd, coarse_bwd, fine_bwd = run_scan(L, contradiction_edge, s_backward, chi_max=100)
    
    # 保存数据
    np.savetxt('time_arrow_forward.csv',
               np.column_stack((s_forward, gaps_fwd, coarse_fwd, fine_fwd)),
               header='s,gap,coarse,fine', delimiter=',')
    np.savetxt('time_arrow_backward.csv',
               np.column_stack((s_backward, gaps_bwd, coarse_bwd, fine_bwd)),
               header='s,gap,coarse,fine', delimiter=',')
    
    # 诊断图：正向 vs 逆向
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
    
    ax1.plot(s_forward, fine_fwd, 'o-', label='Forward (0→3)', color='#1f77b4')
    ax1.plot(s_backward, fine_bwd, 's--', label='Backward (3→0)', color='#d62728')
    ax1.set_xlabel('Contradiction strength s')
    ax1.set_ylabel('Enhanced diagnosis (fine)')
    ax1.set_title('Time Arrow Test: Enhanced Diagnosis')
    ax1.legend()
    ax1.grid(True, alpha=0.3)
    
    ax2.plot(s_forward, coarse_fwd, 'o-', label='Forward (0→3)', color='#1f77b4')
    ax2.plot(s_backward, coarse_bwd, 's--', label='Backward (3→0)', color='#d62728')
    ax2.set_xlabel('Contradiction strength s')
    ax2.set_ylabel('Default diagnosis (coarse)')
    ax2.set_title('Time Arrow Test: Default Diagnosis')
    ax2.legend()
    ax2.grid(True, alpha=0.3)
    
    plt.suptitle(f'Time Arrow Test: Forward vs Backward (L={L}, Heisenberg)')
    plt.tight_layout()
    plt.savefig('time_arrow_test.png', dpi=150)
    print("\nDone. Data saved to time_arrow_forward.csv / time_arrow_backward.csv")