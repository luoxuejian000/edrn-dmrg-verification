"""
终极时间箭头检验 —— 精确对角化版本
彻底消除DMRG收敛误差，严格检验关系场路径无关性
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh

# =============================================
# 哈密顿量构建（泡利矩阵版，标准Heisenberg）
# =============================================
def build_hamiltonian(N, contradiction_edge, contradiction_strength):
    """使用泡利矩阵构建标准各向同性Heisenberg模型"""
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    
    def to_full(op, site):
        ops = [I2] * N
        ops[site] = op
        result = ops[0]
        for k in range(1, N):
            result = np.kron(result, ops[k])
        return result
    
    for i in range(N-1):
        J = contradiction_strength if (i, i+1) == contradiction_edge or (i+1, i) == contradiction_edge else 1.0
        H += J * (to_full(sx, i) @ to_full(sx, i+1)).real
        H += J * (to_full(sy, i) @ to_full(sy, i+1)).real
        H += J * (to_full(sz, i) @ to_full(sz, i+1)).real
    
    return H.tocsc()


def compute_diagnostics(N, contradiction_edge, s, num_eig=5):
    """用ED精确计算基态，返回能隙、默认诊断和精细诊断"""
    H = build_hamiltonian(N, contradiction_edge, s)
    
    # ED精确求解：不需要初始猜测，不存在收敛问题
    energies, states = eigsh(H, k=min(num_eig, 2**N-1), which='SA')
    
    gap = energies[1] - energies[0] if len(energies) > 1 else np.nan
    gs = states[:, 0]  # 基态：ED按能量排序，第0个是最低能量态
    
    # 默认诊断：平均磁化
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    mag = 0.0
    for i in range(N):
        ops = [I2] * N
        ops[i] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        mag += np.real(gs.conj().T @ op_full @ gs)
    coarse = abs(mag / N)
    
    # 精细诊断：边关联涨落标准差
    corrs = []
    for i in range(N-1):
        ops = [I2] * N
        ops[i] = sz
        ops[i+1] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        corr = np.real(gs.conj().T @ op_full @ gs)
        corrs.append(corr)
    fine = np.std(corrs) if corrs else 0.0
    
    return gap, coarse, fine


def run_scan(N, contradiction_edge, s_values, label, seed_offset=0):
    """沿指定s序列扫描，返回诊断数据"""
    gaps, coarse_vals, fine_vals = [], [], []
    print(f"\n=== {label} ===")
    for s in s_values:
        gap, coarse, fine = compute_diagnostics(N, contradiction_edge, s)
        gaps.append(gap)
        coarse_vals.append(coarse)
        fine_vals.append(fine)
        print(f"s={s:.2f}: gap={gap:.6f}, coarse={coarse:.4f}, fine={fine:.4f}")
    return np.array(gaps), np.array(coarse_vals), np.array(fine_vals)


if __name__ == "__main__":
    N = 6
    contradiction_edge = (N//2 - 1, N//2)  # (2,3)
    s_values = np.linspace(0.0, 3.0, 13)
    
    # === 正向扫描 ===
    s_fwd = s_values.copy()
    gaps_fwd, coarse_fwd, fine_fwd = run_scan(N, contradiction_edge, s_fwd, "正向扫描 (s: 0→3)")
    
    # === 逆向扫描 ===
    s_bwd = s_values[::-1].copy()
    gaps_bwd, coarse_bwd, fine_bwd = run_scan(N, contradiction_edge, s_bwd, "逆向扫描 (s: 3→0)")
    
    # === 随机扫描（5组独立随机顺序）===
    all_random_fine = []
    for run_id in range(1, 6):
        np.random.seed(run_id * 42)
        s_random = s_values.copy()
        np.random.shuffle(s_random)
        gaps_rnd, coarse_rnd, fine_rnd = run_scan(N, contradiction_edge, s_random,
                                                    f"随机扫描 #{run_id}")
        # 将结果按s值排序
        sort_idx = np.argsort(s_random)
        all_random_fine.append((s_random[sort_idx], fine_rnd[sort_idx], coarse_rnd[sort_idx]))
    
    # === 保存数据 ===
    np.savetxt('ed_forward.csv',
               np.column_stack((s_fwd, gaps_fwd, coarse_fwd, fine_fwd)),
               header='s,gap,coarse,fine', delimiter=',')
    np.savetxt('ed_backward.csv',
               np.column_stack((s_bwd, gaps_bwd, coarse_bwd, fine_bwd)),
               header='s,gap,coarse,fine', delimiter=',')
    for run_id, (s_rnd, fine_rnd, coarse_rnd) in enumerate(all_random_fine, start=1):
        np.savetxt(f'ed_random_run{run_id}.csv',
                   np.column_stack((s_rnd, fine_rnd, coarse_rnd)),
                   header='s,fine,coarse', delimiter=',')
    
    # === 对比图 ===
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
    
    # 精细诊断对比
    ax1.plot(s_fwd, fine_fwd, 'o-', label='Forward', color='#1f77b4', lw=2)
    ax1.plot(s_bwd, fine_bwd, 's--', label='Backward', color='#d62728', lw=2)
    colors = ['#2ca02c', '#9467bd', '#8c564b', '#e377c2', '#7f7f7f']
    for run_id, (s_rnd, fine_rnd, _) in enumerate(all_random_fine):
        ax1.plot(s_rnd, fine_rnd, '^:', label=f'Random #{run_id+1}', color=colors[run_id], ms=5)
    ax1.set_xlabel('s')
    ax1.set_ylabel('Fine diagnosis')
    ax1.set_title('ED Time Arrow Test: Enhanced Diagnosis')
    ax1.legend(fontsize=7)
    ax1.grid(True, alpha=0.3)
    
    # 默认诊断对比
    ax2.plot(s_fwd, coarse_fwd, 'o-', label='Forward', color='#1f77b4', lw=2)
    ax2.plot(s_bwd, coarse_bwd, 's--', label='Backward', color='#d62728', lw=2)
    for run_id, (s_rnd, _, coarse_rnd) in enumerate(all_random_fine):
        ax2.plot(s_rnd, coarse_rnd, '^:', label=f'Random #{run_id+1}', color=colors[run_id], ms=5)
    ax2.set_xlabel('s')
    ax2.set_ylabel('Coarse diagnosis')
    ax2.set_title('ED Time Arrow Test: Default Diagnosis')
    ax2.legend(fontsize=7)
    ax2.grid(True, alpha=0.3)
    
    plt.suptitle('ED Time Arrow Test (N=6, Heisenberg, Exact Diagonalization)')
    plt.tight_layout()
    plt.savefig('ed_time_arrow_test.png', dpi=150)
    
    # === 定量统计 ===
    print("\n=== 定量对比 ===")
    for run_id, (s_rnd, fine_rnd, _) in enumerate(all_random_fine, start=1):
        max_dev = np.max(np.abs(fine_rnd - fine_fwd))
        mean_dev = np.mean(np.abs(fine_rnd - fine_fwd))
        print(f"随机扫描#{run_id} vs 正向扫描: 最大偏差={max_dev:.6f}, 平均偏差={mean_dev:.6f}")
    
    print("\nDone. 所有数据已保存。")