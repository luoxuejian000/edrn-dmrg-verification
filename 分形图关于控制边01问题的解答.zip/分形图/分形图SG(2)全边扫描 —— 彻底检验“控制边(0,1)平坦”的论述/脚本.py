import numpy as np
import networkx as nx
from scipy.sparse import lil_matrix, csr_matrix
from scipy.sparse.linalg import eigsh
import itertools, os, pandas as pd

# ============ 分形图生成（明确边列表）============
def sierpinski_gasket_level2():
    edges = [
        (0,6),(0,8),(1,9),(1,11),(2,12),(2,14),
        (3,6),(3,7),(3,9),(3,10),(4,10),(4,11),(4,12),(4,13),
        (5,7),(5,8),(5,13),(5,14),
        (6,7),(7,8),(9,10),(10,11),(12,13),(13,14),
        (6,8),(9,11),(12,14)
    ]
    G = nx.Graph()
    G.add_nodes_from(range(15))
    G.add_edges_from(edges)
    return G

# ============ 哈密顿量构建（全局诊断用）============
def build_hamiltonian(N, edges, J_vals, N_up):
    basis_states = list(itertools.combinations(range(N), N_up))
    state_to_idx = {st: i for i, st in enumerate(basis_states)}
    dim = len(basis_states)
    H = lil_matrix((dim, dim), dtype=float)

    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis_states):
            si = 1 if i in state else -1
            sj = 1 if j in state else -1
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis_states):
            i_up = i in state; j_up = j in state
            if i_up and not j_up:
                ns = list(state); ns.remove(i); ns.append(j)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2 * J
            elif j_up and not i_up:
                ns = list(state); ns.remove(j); ns.append(i)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2 * J
    return csr_matrix(H), basis_states

def compute_diagnostics(N, edges, J_vals, N_up, seed=0):
    H, basis = build_hamiltonian(N, edges, J_vals, N_up)
    rng = np.random.default_rng(seed)
    v0 = rng.standard_normal(H.shape[0])
    evals, evecs = eigsh(H, k=1, which='SA', v0=v0)
    psi = evecs[:, 0]

    corrs = []
    for (i, j) in edges:
        sp = np.array([(1 if i in state else -1)*(1 if j in state else -1) for state in basis])
        corrs.append(np.sum(np.abs(psi)**2 * sp))
    E_global = np.std(np.array(corrs))
    D_default = np.mean(np.abs(np.array(corrs)))
    return E_global, D_default

# ============ 全边扫描 ===========
G = sierpinski_gasket_level2()
N = 15
N_up = 7
edges = list(G.edges())
s_values = np.linspace(0.0, 3.0, 25)

print(f"分形图SG(2)全边扫描: N={N}, {len(edges)}条边")
print("="*70)

results = []
for edge_idx, edge in enumerate(edges):
    def vertex_type(v):
        if v in [0,1,2]: return "tip"
        elif v in [3,4,5]: return "corner"
        else: return "interior"
    
    v1_type = vertex_type(edge[0])
    v2_type = vertex_type(edge[1])
    
    J_vals = np.ones(len(edges))
    E_curve, D_curve = [], []
    for s in s_values:
        J_vals[edge_idx] = s
        E, D = compute_diagnostics(N, edges, J_vals, N_up, seed=0)
        E_curve.append(E)
        D_curve.append(D)
        J_vals[edge_idx] = 1.0
    
    E_curve = np.array(E_curve)
    D_curve = np.array(D_curve)
    
    valleys = [(s_values[i], E_curve[i]) for i in range(1, len(E_curve)-1)
               if E_curve[i] < E_curve[i-1] and E_curve[i] < E_curve[i+1]]
    
    if valleys:
        best_s, best_E = min(valleys, key=lambda x: x[1])
        valley_depth = E_curve[0] - best_E
    else:
        best_s, best_E, valley_depth = np.nan, np.nan, np.nan
    
    E_range = np.max(E_curve) - np.min(E_curve)
    D_range = np.max(D_curve) - np.min(D_curve)
    is_flat = "YES" if E_range < 0.001 else "NO"
    
    results.append({
        'edge': edge,
        'type_1': v1_type, 'type_2': v2_type,
        'E_range': E_range,
        'valley_s': best_s,
        'valley_depth': valley_depth,
        'D_range': D_range,
        'flat': is_flat
    })
    
    print(f"边{edge} ({v1_type}-{v2_type}): E_range={E_range:.6f}, "
          f"谷底s={best_s}, 谷深={valley_depth:.6f}, flat={is_flat}")

df = pd.DataFrame(results)
df.to_csv("sierpinski_full_edge_scan.csv", index=False)
print(f"\n{'='*70}")
print(f"结果已保存至 sierpinski_full_edge_scan.csv")

flat_edges = df[df['flat'] == 'YES']
print(f"\n平坦边（E_range < 0.001）: {len(flat_edges)}条")
for _, row in flat_edges.iterrows():
    print(f"  {row['edge']} ({row['type_1']}-{row['type_2']})")