import numpy as np
import networkx as nx
from scipy.sparse import coo_matrix, csr_matrix
from scipy.sparse.linalg import eigsh
import itertools, os, pandas as pd

# SG(2) graph
G = nx.Graph()
G.add_nodes_from(range(15))
edges = [
    (0,6),(0,8),(1,9),(1,11),(2,12),(2,14),
    (3,6),(3,7),(3,9),(3,10),(4,10),(4,11),(4,12),(4,13),
    (5,7),(5,8),(5,13),(5,14),
    (6,7),(7,8),(9,10),(10,11),(12,13),(13,14),
    (6,8),(9,11),(12,14)
]
G.add_edges_from(edges)
N = 15
N_up = 7
s_values = np.linspace(0.0, 3.0, 13)

# Precompute basis and each edge operator. This is algebraically equivalent to
# rebuilding the Hamiltonian for every scan point, but avoids repeated work.
basis = list(itertools.combinations(range(N), N_up))
state_to_idx = {st: i for i, st in enumerate(basis)}
dim = len(basis)
edge_ops = []
corr_signs = []
for i, j in edges:
    rows = []
    cols = []
    vals = []
    signs = np.empty(dim, dtype=float)
    for idx, state in enumerate(basis):
        i_up = i in state
        j_up = j in state
        si = 1 if i_up else -1
        sj = 1 if j_up else -1
        signs[idx] = si * sj
        rows.append(idx); cols.append(idx); vals.append(float(si * sj))
        if i_up and not j_up:
            ns = list(state); ns.remove(i); ns.append(j)
            jdx = state_to_idx[tuple(sorted(ns))]
            rows.append(idx); cols.append(jdx); vals.append(2.0)
        elif j_up and not i_up:
            ns = list(state); ns.remove(j); ns.append(i)
            jdx = state_to_idx[tuple(sorted(ns))]
            rows.append(idx); cols.append(jdx); vals.append(2.0)
    edge_ops.append(coo_matrix((vals, (rows, cols)), shape=(dim, dim)).tocsr())
    corr_signs.append(signs)
corr_signs = np.asarray(corr_signs)
H_base = sum(edge_ops, csr_matrix((dim, dim), dtype=float))

# Local radius-2 edge sets
local_edge_indices = []
for u, v in edges:
    nodes_u = set(nx.single_source_shortest_path_length(G, u, cutoff=2).keys())
    nodes_v = set(nx.single_source_shortest_path_length(G, v, cutoff=2).keys())
    local_nodes = nodes_u | nodes_v
    local_edge_indices.append(np.array([k for k, (a, b) in enumerate(edges)
                                        if a in local_nodes and b in local_nodes], dtype=int))

print(f"分形图SG(2)全边对照扫描: {len(edges)}条边")
print(f"每条边：全局诊断 vs 局部半径-2诊断")
print("="*80)

rng = np.random.default_rng(0)
# Preserve the original convention: same random initial vector for every solve.
v0 = rng.standard_normal(dim)
results = []
for edge_idx, contradiction_edge in enumerate(edges):
    E_global_curve, E_local_curve = [], []
    local_idx = local_edge_indices[edge_idx]
    for s in s_values:
        H = H_base + (s - 1.0) * edge_ops[edge_idx]
        evals, evecs = eigsh(H, k=1, which='SA', v0=v0)
        psi = evecs[:, 0]
        probs = np.abs(psi) ** 2
        corrs = corr_signs @ probs
        E_global_curve.append(np.std(corrs))
        E_local_curve.append(np.std(corrs[local_idx]))
    E_global_curve = np.asarray(E_global_curve)
    E_local_curve = np.asarray(E_local_curve)
    global_range = np.ptp(E_global_curve)
    local_range = np.ptp(E_local_curve)
    global_flat = "YES" if global_range < 0.001 else "NO"
    local_flat = "YES" if local_range < 0.001 else "NO"
    results.append({
        'edge': contradiction_edge,
        'global_range': global_range,
        'local_range': local_range,
        'global_flat': global_flat,
        'local_flat': local_flat
    })
    print(f"边{contradiction_edge}: 全局极差={global_range:.6f} ({global_flat}), 局部极差={local_range:.6f} ({local_flat})")

df = pd.DataFrame(results)
df.to_csv("global_vs_local_flat.csv", index=False)
print(f"\n{'='*80}")
print(f"全局诊断下平坦的边: {sum(df['global_flat']=='YES')}条")
for _, row in df[df['global_flat']=='YES'].iterrows():
    print(f"  {row['edge']}")
print(f"局部诊断下平坦的边: {sum(df['local_flat']=='YES')}条")
for _, row in df[df['local_flat']=='YES'].iterrows():
    print(f"  {row['edge']}")