"""
分形图 SG(2) 矛盾边全面扫描 —— 全局 vs 局部诊断对照
目标：判断"控制边(0,1)完全平坦"是否来自局部诊断
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import networkx as nx
from scipy.sparse import lil_matrix, csr_matrix
from scipy.sparse.linalg import eigsh
import itertools, os, pandas as pd

# ============ 分形图生成（与论文一致）============
def sierpinski_gasket_level2():
    edges = [
        (0,6),(0,8),(1,9),(1,11),(2,12),(2,14),
        (3,6),(3,7),(3,9),(3,10),(4,10),(4,11),(4,12),(4,13),
        (5,7),(5,8),(5,13),(5,14),
        (6,7),(7,8),(9,10),(10,11),(12,13),(13,14),
        (6,8),(9,11),(12,14)
    ]
    G = nx.Graph()
    G.add_nodes_from(range(15))
    G.add_edges_from(edges)
    return G

# ============ 哈密顿量构建与诊断 ============
def build_hamiltonian(N, edges, J_vals, N_up):
    basis_states = list(itertools.combinations(range(N), N_up))
    state_to_idx = {st: i for i, st in enumerate(basis_states)}
    dim = len(basis_states)
    H = lil_matrix((dim, dim), dtype=float)

    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis_states):
            si = 1 if i in state else -1
            sj = 1 if j in state else -1
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis_states):
            i_up = i in state; j_up = j in state
            if i_up and not j_up:
                ns = list(state); ns.remove(i); ns.append(j)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2 * J
            elif j_up and not i_up:
                ns = list(state); ns.remove(j); ns.append(i)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2 * J
    return csr_matrix(H), basis_states

def compute_diagnostics(N, edges, J_vals, N_up, seed=0):
    """同时计算全局诊断和局部诊断"""
    H, basis = build_hamiltonian(N, edges, J_vals, N_up)
    rng = np.random.default_rng(seed)
    v0 = rng.standard_normal(H.shape[0])
    evals, evecs = eigsh(H, k=1, which='SA', v0=v0)
    psi = evecs[:, 0]

    corrs = []
    for (i, j) in edges:
        sp = np.array([(1 if i in state else -1)*(1 if j in state else -1) for state in basis])
        corrs.append(np.sum(np.abs(psi)**2 * sp))
    
    # 全局诊断：所有27条边的标准差
    E_global = np.std(np.array(corrs))
    D_global = np.mean(np.abs(np.array(corrs)))
    return E_global, D_global

# ============ 局部半径-2诊断 ============
def get_local_edges(G, edge, radius=2):
    """获取矛盾边的半径-2邻域内的所有边"""
    u, v = edge
    # 取以u和v为中心的半径r子图
    nodes_u = set(nx.single_source_shortest_path_length(G, u, cutoff=radius).keys())
    nodes_v = set(nx.single_source_shortest_path_length(G, v, cutoff=radius).keys())
    local_nodes = nodes_u | nodes_v
    local_edges = [e for e in G.edges() if e[0] in local_nodes and e[1] in local_nodes]
    return local_edges

def compute_local_diagnostic(N, edges, J_vals, N_up, local_edges, seed=0):
    """只对局部邻域的边计算增强诊断"""
    H, basis = build_hamiltonian(N, edges, J_vals, N_up)
    rng = np.random.default_rng(seed)
    v0 = rng.standard_normal(H.shape[0])
    evals, evecs = eigsh(H, k=1, which='SA', v0=v0)
    psi = evecs[:, 0]

    corrs = []
    for (i, j) in local_edges:
        sp = np.array([(1 if i in state else -1)*(1 if j in state else -1) for state in basis])
        corrs.append(np.sum(np.abs(psi)**2 * sp))
    return np.std(np.array(corrs))

# ============ 全边对照扫描 ============
G = sierpinski_gasket_level2()
N = 15
N_up = 7
edges = list(G.edges())
s_values = np.linspace(0.0, 3.0, 13)  # 13个点，足够判断平坦与否
edge_idx = None  # 在循环中动态确定

print(f"分形图SG(2)全边对照扫描: {len(edges)}条边")
print(f"每条边：全局诊断 vs 局部半径-2诊断")
print("="*80)

results = []
for contradiction_edge in edges:
    # 确定该边在edges列表中的索引
    for idx, (u, v) in enumerate(edges):
        if (u, v) == contradiction_edge or (v, u) == contradiction_edge:
            edge_idx = idx
            break
    
    # 获取局部邻域
    local_edges = get_local_edges(G, contradiction_edge, radius=2)
    
    # 扫描
    E_global_curve, E_local_curve = [], []
    for s in s_values:
        J_vals = np.ones(len(edges))
        J_vals[edge_idx] = s
        E_glob, _ = compute_diagnostics(N, edges, J_vals, N_up, seed=0)
        E_loc = compute_local_diagnostic(N, edges, J_vals, N_up, local_edges, seed=0)
        E_global_curve.append(E_glob)
        E_local_curve.append(E_loc)
    
    E_global_curve = np.array(E_global_curve)
    E_local_curve = np.array(E_local_curve)
    
    # 极差
    global_range = np.max(E_global_curve) - np.min(E_global_curve)
    local_range = np.max(E_local_curve) - np.min(E_local_curve)
    
    # 平坦判断（阈值0.001）
    global_flat = "YES" if global_range < 0.001 else "NO"
    local_flat = "YES" if local_range < 0.001 else "NO"
    
    results.append({
        'edge': contradiction_edge,
        'global_range': global_range,
        'local_range': local_range,
        'global_flat': global_flat,
        'local_flat': local_flat
    })
    
    print(f"边{contradiction_edge}: 全局极差={global_range:.6f} ({global_flat}), "
          f"局部极差={local_range:.6f} ({local_flat})")

# 保存
df = pd.DataFrame(results)
df.to_csv("global_vs_local_flat.csv", index=False)

# 统计
print(f"\n{'='*80}")
print(f"全局诊断下平坦的边: {sum(df['global_flat']=='YES')}条")
for _, row in df[df['global_flat']=='YES'].iterrows():
    print(f"  {row['edge']}")
print(f"局部诊断下平坦的边: {sum(df['local_flat']=='YES')}条")
for _, row in df[df['local_flat']=='YES'].iterrows():
    print(f"  {row['edge']}")