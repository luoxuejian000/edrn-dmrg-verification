"""
关系场中的"胶球"涌现探测 —— 金箍棒精确对角化版
核心追问：无实体、纯关系、自相互作用的关系场，是否能涌现出类似胶球的束缚态？
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import networkx as nx
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh

# =============================================
# 公理一：关系本体论 —— 构建"类胶球"关系图
# =============================================
def build_glueball_graph(N):
    """
    全连接随机图：每个节点与其他所有节点都有潜在的连接。
    这是"无结构真空"的关系场表示——没有预设的几何，只有潜在的关系。
    """
    G = nx.complete_graph(N)
    # 为每条边赋予一个初始随机权重，代表胶子场的量子涨落
    np.random.seed(42)
    for u, v in G.edges():
        G[u][v]['weight'] = np.random.uniform(0.8, 1.2)
    return G


# =============================================
# 公理一（续）：纯关系哈密顿量 —— 无在位项，只有边上的自相互作用
# =============================================
def build_glueball_hamiltonian(G, self_coupling_strength=0.5, fluctuation_scale=0.1):
    """
    纯关系哈密顿量：
    H = Σ_{(i,j)∈E} J_{ij} * (S_i·S_j)
    其中 J_{ij} 不是固定的，而是与边上的关联涨落成正比：
    J_{ij} = J0 + λ * ⟨(S_i·S_j - ⟨S_i·S_j⟩)^2⟩^{1/2}
    
    这里用简化版本：J_{ij} = J0 + λ * |随机涨落|
    模拟胶子的自相互作用——关联越强的边，耦合越强。
    """
    N = G.number_of_nodes()
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)

    def to_full(op, site):
        ops = [I2] * N
        ops[site] = op
        result = ops[0]
        for k in range(1, N):
            result = np.kron(result, ops[k])
        return result

    for i, j, w in G.edges(data='weight'):
        # 自相互作用：耦合强度包含随机涨落，模拟胶子场的量子涨落
        J = w + self_coupling_strength * np.random.normal(0, fluctuation_scale)
        H += J * (to_full(sx, i) @ to_full(sx, j)).real
        H += J * (to_full(sy, i) @ to_full(sy, j)).real
        H += J * (to_full(sz, i) @ to_full(sz, j)).real

    return H.tocsc()


# =============================================
# 公理二：矛盾动力论 —— 扫描自耦合强度，驱动关系场演化
# =============================================
def compute_diagnostics(G, self_coupling_strength, fluctuation_scale=0.1, num_eig=5):
    """计算基态诊断指标"""
    H = build_glueball_hamiltonian(G, self_coupling_strength, fluctuation_scale)
    N = G.number_of_nodes()
    energies, states = eigsh(H, k=min(num_eig, 2**N-1), which='SA')
    gap = energies[1] - energies[0] if len(energies) > 1 else np.nan
    gs = states[:, 0]

    # 默认诊断：平均磁化（胶球不应有磁化——它是纯胶子态）
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    mag = 0.0
    for i in range(N):
        ops = [I2] * N
        ops[i] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        mag += np.real(gs.conj().T @ op_full @ gs)
    coarse = abs(mag / N)

    # 增强诊断：边关联涨落的标准差（对胶球的涌现敏感）
    corrs = []
    for i, j in G.edges():
        ops = [I2] * N
        ops[i] = sz
        ops[j] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        corr = np.real(gs.conj().T @ op_full @ gs)
        corrs.append(corr)
    fine = np.std(corrs) if corrs else 0.0

    # "胶球"探针：最近邻关联的局域化程度
    # 胶球应该是局域的——即少数几条边承载了大部分关联
    abs_corrs = np.abs(corrs)
    localization = np.max(abs_corrs) / (np.mean(abs_corrs) + 1e-12)

    return gap, coarse, fine, localization, corrs


# =============================================
# 公理三：实践介入论 —— 双诊断并排展示
# =============================================
def run_glueball_scan(N=6, self_coupling_vals=None, fluctuation_scale=0.1):
    """扫描自耦合强度，寻找胶球涌现的信号"""
    if self_coupling_vals is None:
        self_coupling_vals = np.linspace(0.0, 2.0, 41)  # 41个采样点

    G = build_glueball_graph(N)
    
    gaps, coarse_vals, fine_vals, localizations = [], [], [], []
    
    print(f"=== 关系场胶球涌现探测 (N={N}) ===")
    print(f"自耦合强度扫描: λ∈[0,2.0], 步数={len(self_coupling_vals)}")
    print(f"无在位项，纯边相互作用，含随机涨落(σ={fluctuation_scale})\n")
    
    for lam in self_coupling_vals:
        gap, coarse, fine, localization, corrs = compute_diagnostics(G, lam, fluctuation_scale)
        gaps.append(gap)
        coarse_vals.append(coarse)
        fine_vals.append(fine)
        localizations.append(localization)
        
        if lam == 0.0 or lam == 1.0 or lam == 2.0:
            print(f"λ={lam:.2f}: gap={gap:.6f}, coarse={coarse:.4f}, fine={fine:.6f}, localization={localization:.4f}")
    
    return (np.array(self_coupling_vals), np.array(gaps), np.array(coarse_vals),
            np.array(fine_vals), np.array(localizations))


if __name__ == "__main__":
    N = 6
    self_coupling_vals = np.linspace(0.0, 2.0, 41)
    
    lambda_vals, gaps, coarse_vals, fine_vals, localizations = run_glueball_scan(N, self_coupling_vals)
    
    # 保存数据
    np.savetxt('glueball_scan_results.csv',
               np.column_stack((lambda_vals, gaps, coarse_vals, fine_vals, localizations)),
               header='lambda,gap,coarse,fine,localization', delimiter=',')
    print("\n数据已保存: glueball_scan_results.csv")
    
    # =============================================
    # 公理三（续）：双诊断对比图
    # =============================================
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    
    # 图1：默认诊断（平均磁化）
    ax = axes[0, 0]
    ax.plot(lambda_vals, coarse_vals, 'o-', color='#1f77b4', markersize=4)
    ax.set_xlabel('Self-coupling strength λ')
    ax.set_ylabel('Default diagnosis (magnetization)')
    ax.set_title('Default Diagnosis: Blind to Glueball?')
    ax.grid(True, alpha=0.3)
    
    # 图2：增强诊断（边关联涨落标准差）
    ax = axes[0, 1]
    ax.plot(lambda_vals, fine_vals, 's-', color='#d62728', markersize=4)
    ax.set_xlabel('Self-coupling strength λ')
    ax.set_ylabel('Enhanced diagnosis (correlation fluctuation)')
    ax.set_title('Enhanced Diagnosis: Glueball Emergence Signal?')
    ax.grid(True, alpha=0.3)
    
    # 图3：局域化程度（胶球探针）
    ax = axes[1, 0]
    ax.plot(lambda_vals, localizations, '^-', color='#2ca02c', markersize=4)
    ax.set_xlabel('Self-coupling strength λ')
    ax.set_ylabel('Localization (max/mean correlation)')
    ax.set_title('Glueball Probe: Localization of Correlations')
    ax.grid(True, alpha=0.3)
    
    # 图4：能隙
    ax = axes[1, 1]
    ax.plot(lambda_vals, gaps, 'D-', color='#9467bd', markersize=4)
    ax.set_xlabel('Self-coupling strength λ')
    ax.set_ylabel('Energy gap')
    ax.set_title('Energy Gap')
    ax.grid(True, alpha=0.3)
    
    plt.suptitle(f'Glueball Emergence in Pure-Relation Field (N={N})',
                 fontsize=14, fontweight='bold')
    plt.tight_layout()
    plt.savefig('glueball_scan_diagnosis.png', dpi=150)
    print("诊断图已保存: glueball_scan_diagnosis.png")
    
    # =============================================
    # 公理五：元反思律 —— 自动检测胶球涌现信号
    # =============================================
    print("\n=== 胶球涌现自动检测 ===")
    
    # 检测增强诊断的非单调行为
    peaks = []
    valleys = []
    for i in range(1, len(fine_vals)-1):
        if fine_vals[i] > fine_vals[i-1] and fine_vals[i] > fine_vals[i+1]:
            peaks.append(i)
        if fine_vals[i] < fine_vals[i-1] and fine_vals[i] < fine_vals[i+1]:
            valleys.append(i)
    
    if len(peaks) > 0:
        print(f"增强诊断峰值位置: λ={lambda_vals[peaks]}")
    if len(valleys) > 0:
        print(f"增强诊断谷底位置: λ={lambda_vals[valleys]}")
    
    # 检测默认诊断是否盲视
    coarse_range = np.max(coarse_vals) - np.min(coarse_vals)
    fine_range = np.max(fine_vals) - np.min(fine_vals)
    print(f"默认诊断变化幅度: {coarse_range:.6f}")
    print(f"增强诊断变化幅度: {fine_range:.6f}")
    if coarse_range < 0.01 and fine_range > 0.01:
        print("✓ 默认诊断盲视，增强诊断敏感——这是沉默失谐的特征信号")
    else:
        print("✗ 未检测到显著的沉默失谐信号")
    
    # 检测局域化程度是否在某个λ值突增
    loc_jumps = np.diff(localizations)
    max_jump_idx = np.argmax(loc_jumps)
    print(f"最大局域化跃升位置: λ={lambda_vals[max_jump_idx]:.2f}, 跃升幅度={loc_jumps[max_jump_idx]:.4f}")
    
    print("\nDone. 所有数据已保存。")