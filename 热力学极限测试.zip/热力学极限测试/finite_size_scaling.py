"""
沉默失谐有限尺寸标度实验
结合金箍棒（关系图编译+诊断）与 TeNPy DMRG（大系统求解）
"""
import numpy as np
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')

# 金箍棒核心函数（关系图编译与诊断）
from golden_staff_v2 import (
    build_graph, introduce_contradiction,
    coarse_diagnosis, fine_diagnosis
)

# 尝试导入 TeNPy
try:
    from tenpy.models.xxz_chain import XXZChain
    from tenpy.networks.mps import MPS
    from tenpy.algorithms import dmrg
    HAS_TENPY = True
    print("TeNPy 已加载，将使用 DMRG 求解。")
except ImportError:
    HAS_TENPY = False
    print("TeNPy 未安装，将回退到金箍棒 ED 求解（仅支持 N ≤ 8）。")

# =============================================
# DMRG 求解器（基于金箍棒关系图编译的哈密顿量）
# =============================================
def solve_gs_dmrg(G, rule='heisenberg', chi_max=100):
    """
    用 TeNPy DMRG 求解关系图 G 对应哈密顿量的基态。
    返回基态能量和关联函数 C_{ij} = <σ_i^z σ_j^z>。
    """
    if not HAS_TENPY:
        raise RuntimeError("TeNPy 未安装，无法使用 DMRG。")
    
    N = G.number_of_nodes()
    # 从关系图提取耦合参数
    couplings = {}
    for i, j, w in G.edges(data='weight'):
        w = w if w else 1.0
        couplings[(i, j)] = w

    # 构建 XXZ 链模型（当 couplings 为最近邻时适用）
    # 对于非最近邻耦合，需要使用更通用的模型定义
    model_params = dict(
        L=N,
        Jxx=1.0, Jyy=1.0, Jz=1.0,  # Heisenberg
        bc_MPS='finite',
        conserve='best',
    )
    
    M = XXZChain(model_params)
    psi = MPS.from_product_state(M.lat, [['up']] * N)
    
    dmrg_params = {
        'mixer': True,
        'chi_max': chi_max,
        'max_sweeps': 50,
        'verbose': 0,
    }
    eng = dmrg.run(psi, M, dmrg_params)
    
    # 提取关联函数
    # 此处简化：直接返回能量，关联函数通过标准方法计算
    E0 = eng.eigenvalues[0]
    
    # 用 TeNPy 的关联函数工具计算 C_{ij}
    C = np.zeros((N, N))
    for i in range(N):
        for j in range(N):
            if i == j:
                C[i, j] = 1.0  # <σ_i^z σ_i^z> = 1
            else:
                # 使用 term_correlation_function 或直接计算
                corr = M.correlation_function(psi, [i], [j], ['Sz'], ['Sz'])
                C[i, j] = corr[0, 0]
    
    # 计算粗粒化和精细化诊断
    coarse = coarse_diagnosis(N, psi)  # 需要适配
    fine = fine_diagnosis(G, psi)      # 需要适配
    
    return E0, C, coarse, fine


def solve_gs_ed(G, rule='heisenberg'):
    """用金箍棒 ED 求解（回退方案）"""
    from golden_staff_v2 import graph_to_hamiltonian_sparse, diagnose
    N = G.number_of_nodes()
    energies, gap, gs = diagnose(G, rule=rule, num_eig=5)
    E0 = energies[0]
    coarse = coarse_diagnosis(N, gs)
    fine = fine_diagnosis(G, gs)
    
    # 计算关联矩阵
    dim = len(gs)
    C = np.zeros((N, N))
    sz_exp = np.zeros(N)
    for state in range(dim):
        prob = np.abs(gs[state])**2
        for i in range(N):
            bit = (state >> i) & 1
            sz_exp[i] += prob * (1 - 2*bit)
    for i in range(N):
        for j in range(N):
            corr = 0.0
            for state in range(dim):
                prob = np.abs(gs[state])**2
                bit_i = (state >> i) & 1
                bit_j = (state >> j) & 1
                corr += prob * (1 - 2*bit_i) * (1 - 2*bit_j)
            C[i, j] = corr - sz_exp[i] * sz_exp[j]
    
    return E0, C, coarse, fine


# =============================================
# 主实验：有限尺寸标度
# =============================================
graph_type = 'chain'
rule = 'heisenberg'
s_vals = np.linspace(0.0, 3.0, 9)

# 根据是否有 TeNPy 决定扫描的尺寸范围
if HAS_TENPY:
    N_list = [6, 8, 10, 12, 14, 16]
else:
    N_list = [6, 8]  # ED 只能跑小系统
    print("注意：仅扫描 N=6,8。安装 TeNPy 后可扫描更大尺寸。")

print(f"=== 有限尺寸标度实验: {graph_type} {rule} ===")
print(f"扫描尺寸: {N_list}")

all_fine = {}  # {N: [fine_vals]}
all_coarse = {}

for N in N_list:
    print(f"\n--- N={N} ---")
    fine_vals = []
    coarse_vals = []
    
    for s in s_vals:
        G = build_graph(graph_type, N)
        contradiction_edge = (N//2 - 1, N//2) if N > 2 else (0, 1)
        G = introduce_contradiction(G, contradiction_edge, s)
        
        if HAS_TENPY:
            try:
                E0, C, coarse, fine = solve_gs_dmrg(G, rule=rule)
            except Exception as e:
                print(f"  DMRG 失败: {e}，回退到 ED。")
                E0, C, coarse, fine = solve_gs_ed(G, rule=rule)
        else:
            E0, C, coarse, fine = solve_gs_ed(G, rule=rule)
        
        fine_vals.append(fine)
        coarse_vals.append(coarse)
        
        print(f"  s={s:.2f}: coarse={coarse:.4f}, fine={fine:.4f}")
    
    all_fine[N] = np.array(fine_vals)
    all_coarse[N] = np.array(coarse_vals)

# =============================================
# 可视化：多尺寸对比
# =============================================
fig, axes = plt.subplots(1, 2, figsize=(14, 5.5))

# 左图：默认诊断（应全部平滑）
for N in N_list:
    axes[0].plot(s_vals, all_coarse[N], 'o-', label=f'N={N}', markersize=3)
axes[0].set_xlabel('Contradiction strength s')
axes[0].set_ylabel('Default Diagnosis (coarse)')
axes[0].set_title('Default: Blind across all sizes')
axes[0].legend()
axes[0].grid(True, alpha=0.3)

# 右图：增强诊断（关注谷底位置和深度随N的变化）
for N in N_list:
    axes[1].plot(s_vals, all_fine[N], 'o-', label=f'N={N}', markersize=3)
axes[1].set_xlabel('Contradiction strength s')
axes[1].set_ylabel('Enhanced Diagnosis (fine)')
axes[1].set_title('Enhanced: Finite-size scaling of V-shape')
axes[1].legend()
axes[1].grid(True, alpha=0.3)

plt.suptitle(f'Finite-Size Scaling: {graph_type} {rule}')
plt.tight_layout()
plt.savefig('finite_size_scaling.png', dpi=150)
print("\n图表已保存至 finite_size_scaling.png")

# 保存数据
for N in N_list:
    np.savetxt(f'finite_size_N{N}.csv',
               np.column_stack((s_vals, all_coarse[N], all_fine[N])),
               header='s,coarse,fine', delimiter=',')
print("数据已保存至 finite_size_N*.csv")