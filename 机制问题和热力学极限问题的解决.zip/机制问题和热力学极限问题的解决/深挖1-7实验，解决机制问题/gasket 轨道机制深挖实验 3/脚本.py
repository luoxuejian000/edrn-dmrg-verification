import numpy as np
import networkx as nx
import itertools
import os

# ========== gasket 图 ==========
GASKET_EDGES = [
    (0,6),(0,8),(1,9),(1,11),(2,12),(2,14),
    (3,6),(3,7),(3,9),(3,10),(4,10),(4,11),(4,12),(4,13),
    (5,7),(5,8),(5,13),(5,14),
    (6,7),(7,8),(9,10),(10,11),(12,13),(13,14),
    (6,8),(9,11),(12,14)
]
G = nx.Graph()
G.add_nodes_from(range(15))
G.add_edges_from(GASKET_EDGES)

# 边轨道已知
ORBITS = [
    [(6,8),(9,11),(12,14)],
    [(0,6),(0,8),(1,9),(1,11),(2,12),(2,14)],
    [(3,6),(3,9),(4,11),(4,12),(5,8),(5,14)],
    [(3,7),(3,10),(4,10),(4,13),(5,7),(5,13)],
    [(6,7),(7,8),(9,10),(10,11),(12,13),(13,14)]
]
EDGE_TO_ORBIT = {}
for oi, orb in enumerate(ORBITS):
    for e in orb:
        EDGE_TO_ORBIT[tuple(sorted(e))] = oi

def compute_vertex_orbits(G):
    """返回顶点轨道列表，每个轨道是顶点集合列表。"""
    GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
    automorphisms = list(GM.isomorphisms_iter())
    if not automorphisms:
        return [[v] for v in G.nodes()]
    vertices = set(G.nodes())
    orbits = []
    remaining = set(vertices)
    while remaining:
        v0 = remaining.pop()
        orbit = set()
        for perm in automorphisms:
            orbit.add(perm[v0])
        orbits.append(list(orbit))
        remaining -= orbit
    return orbits

def main():
    print("="*80)
    print("深挖3：顶点轨道与边轨道组合")
    print("="*80)

    vertex_orbits = compute_vertex_orbits(G)
    print(f"\n顶点轨道数: {len(vertex_orbits)}")
    vertex_to_orbit = {}
    for vi, orb in enumerate(vertex_orbits):
        for v in orb:
            vertex_to_orbit[v] = vi
        print(f"  Vertex orbit {vi}: {orb}")

    combo_to_edges = {}
    for edge in GASKET_EDGES:
        u, v = edge
        ou = vertex_to_orbit[u]
        ov = vertex_to_orbit[v]
        combo = tuple(sorted((ou, ov)))
        combo_to_edges.setdefault(combo, []).append(tuple(sorted(edge)))

    print("\n边端点轨道组合统计:")
    for combo, edges in combo_to_edges.items():
        edge_orbits = sorted(set(EDGE_TO_ORBIT[e] for e in edges))
        print(f"  顶点轨道组合 {combo}: {len(edges)} 条边, 所属边轨道 {edge_orbits}, 边列表 {edges}")

    orbit4_combos = set()
    for e in ORBITS[4]:
        u, v = e
        orbit4_combos.add(tuple(sorted((vertex_to_orbit[u], vertex_to_orbit[v]))))
    other_combos = set()
    for oi in range(4):
        for e in ORBITS[oi]:
            u, v = e
            other_combos.add(tuple(sorted((vertex_to_orbit[u], vertex_to_orbit[v]))))
    print(f"\n[判据 A] Orbit 4 端点组合: {orbit4_combos}")
    print(f"[判据 A] 其他轨道端点组合: {other_combos}")
    if orbit4_combos.isdisjoint(other_combos):
        print("[判据 A] PASS: Orbit 4 的端点组合与其他轨道不同")
    else:
        print("[判据 A] FAIL: Orbit 4 与其他轨道共享端点组合")

    print("\n[判据 B] 端点组合到边轨道的映射")
    combo_to_orbit = {}
    for combo, edges in combo_to_edges.items():
        orbit_set = set(EDGE_TO_ORBIT[e] for e in edges)
        combo_to_orbit[combo] = orbit_set
        print(f"  {combo}: 边轨道 {orbit_set}")
    if all(len(v) == 1 for v in combo_to_orbit.values()):
        print("[判据 B] PASS: 每个端点组合唯一对应一个边轨道")
    else:
        print("[判据 B] FAIL: 存在端点组合对应多个边轨道")

    print("\n[判据 C] 顶点轨道解释边轨道")
    if len(combo_to_edges) == len(ORBITS):
        print("[判据 C] PASS: 组合数等于边轨道数，可能构成双射")
    else:
        print("[判据 C] FAIL: 组合数不等于边轨道数")

    print("\n实验结束。")

if __name__ == "__main__":
    main()