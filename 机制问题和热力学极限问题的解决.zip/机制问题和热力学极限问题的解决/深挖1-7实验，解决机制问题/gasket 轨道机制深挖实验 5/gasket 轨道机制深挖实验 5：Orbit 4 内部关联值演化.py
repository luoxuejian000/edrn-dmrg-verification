"""
gasket 轨道机制深挖实验 5：Orbit 4 内部关联值演化
严格遵循：关系本体论、矛盾动力论、实践介入论、谐振调谐论、元反思律
严防工具理性悖论，旗帜鲜明反对对齐

预设判据：
  在 Orbit 4 的 within_var 峰值处，计算六条边两两关联差，找出贡献最大的边对。
  若最大贡献边对占总方差比例 > 0.5，则轨道内破缺由局部边对主导；
  否则轨道内破缺是整体性的。
"""
import itertools
import numpy as np
import networkx as nx
from scipy.sparse import lil_matrix, csr_matrix
from scipy.sparse.linalg import eigsh
import pandas as pd
import matplotlib.pyplot as plt
import os

# ========== 参数 ==========
N = 15
N_up = 7
S_VALUES = np.linspace(0.0, 1.5, 151)
OUTDIR = "deepdig5_orbit4_internal"
os.makedirs(OUTDIR, exist_ok=True)

# gasket 图和边
GASKET_EDGES = [
    (0,6),(0,8),(1,9),(1,11),(2,12),(2,14),
    (3,6),(3,7),(3,9),(3,10),(4,10),(4,11),(4,12),(4,13),
    (5,7),(5,8),(5,13),(5,14),
    (6,7),(7,8),(9,10),(10,11),(12,13),(13,14),
    (6,8),(9,11),(12,14)
]
GASKET_EDGES_SORTED = [tuple(sorted(e)) for e in GASKET_EDGES]
ORBIT4 = [(6,7),(7,8),(9,10),(10,11),(12,13),(13,14)]
ORBIT4_IDX = [GASKET_EDGES_SORTED.index(tuple(sorted(e))) for e in ORBIT4]

# 哈密顿量与密度
def build_sector_hamiltonian(N, edges, J_vals, N_up):
    basis = list(itertools.combinations(range(N), N_up))
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = lil_matrix((dim, dim), dtype=float)
    for (i,j), J in zip(edges, J_vals):
        for idx, st in enumerate(basis):
            si = 1 if i in st else -1
            sj = 1 if j in st else -1
            H[idx, idx] += J * si * sj
        for idx, st in enumerate(basis):
            i_up = i in st
            j_up = j in st
            if i_up and not j_up:
                ns = list(st); ns.remove(i); ns.append(j)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2*J
            elif j_up and not i_up:
                ns = list(st); ns.remove(j); ns.append(i)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2*J
    return csr_matrix(H), basis

def solve_uniform_density(N, edges, J_vals, N_up, seed=42):
    H, basis = build_sector_hamiltonian(N, edges, J_vals, N_up)
    rng = np.random.default_rng(seed)
    v0 = rng.standard_normal(H.shape[0])
    evals, evecs = eigsh(H, k=2, which='SA', v0=v0, maxiter=10000, tol=1e-12)
    gap = abs(evals[1] - evals[0])
    psi0 = evecs[:, 0]
    psi1 = evecs[:, 1] if gap < 1e-8 else None
    if psi1 is not None:
        density = (np.abs(psi0)**2 + np.abs(psi1)**2) / 2.0
    else:
        density = np.abs(psi0)**2
    return density, basis

def edge_correlation(density, basis, edge):
    i, j = edge
    sp = np.array([(1 if i in st else -1)*(1 if j in st else -1) for st in basis])
    return np.sum(density * sp)

def main():
    print("="*80)
    print("深挖5：Orbit 4 内部六条边关联值随 s 演化")
    print("="*80)

    # 选择一条 Orbit 4 边作为矛盾边
    # 这里取 Orbit 4 的第一条边 (6,7)，确保矛盾边也在该轨道内
    contradiction_edge = (6,7)
    cont_idx = GASKET_EDGES_SORTED.index(tuple(sorted(contradiction_edge)))

    records = []
    J_vals = np.ones(len(GASKET_EDGES_SORTED))
    for s in S_VALUES:
        J_vals[cont_idx] = s
        density, basis = solve_uniform_density(N, GASKET_EDGES_SORTED, J_vals, N_up)
        corr_vals = [edge_correlation(density, basis, e) for e in ORBIT4]
        records.append((s, *corr_vals))
        J_vals[cont_idx] = 1.0

    df = pd.DataFrame(records, columns=['s'] + [str(e) for e in ORBIT4])
    df.to_csv(os.path.join(OUTDIR, "orbit4_internal_correlations.csv"), index=False)

    # 找到 within_var 峰值位置
    vals = df.iloc[:, 1:].values
    within_var = np.var(vals, axis=1)
    peak_idx = np.argmax(within_var)
    peak_s = df['s'].iloc[peak_idx]
    print(f"within_var 峰值位于 s={peak_s:.3f}, max var={within_var[peak_idx]:.6e}")

    # 在峰值处计算两两边关联差的贡献
    peak_vals = vals[peak_idx]
    pair_contributions = []
    for a,b in itertools.combinations(range(len(peak_vals)), 2):
        diff = peak_vals[a] - peak_vals[b]
        pair_contributions.append((ORBIT4[a], ORBIT4[b], diff*diff))
    pair_contributions.sort(key=lambda x: x[2], reverse=True)
    total_pair_sum = sum(contrib for _,_,contrib in pair_contributions)
    top_pair = pair_contributions[0]
    print(f"\n峰值处最大关联差边对: {top_pair[0]} vs {top_pair[1]}, squared diff={top_pair[2]:.6e}")
    print(f"该边对占全部两两平方差总和比例: {top_pair[2]/total_pair_sum:.4f}")

    # 判据
    if top_pair[2]/total_pair_sum > 0.5:
        print("判据: 轨道内破缺由局部边对主导")
    else:
        print("判据: 轨道内破缺是整体性的")

    # 绘制六条边关联曲线
    plt.figure(figsize=(10,6))
    for col in df.columns[1:]:
        plt.plot(df['s'], df[col], label=col)
    plt.xlabel('s')
    plt.ylabel('edge correlation')
    plt.title('Orbit 4 internal edge correlations vs s')
    plt.grid(True, alpha=0.3)
    plt.legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(os.path.join(OUTDIR, "orbit4_internal_curves.png"), dpi=150)
    print(f"图已保存: {OUTDIR}/orbit4_internal_curves.png")

    # 绘制 within_var
    plt.figure(figsize=(8,5))
    plt.plot(df['s'], within_var, 'r-')
    plt.xlabel('s')
    plt.ylabel('within_var')
    plt.title('Orbit 4 internal variance')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(OUTDIR, "orbit4_within_var.png"), dpi=150)
    print(f"图已保存: {OUTDIR}/orbit4_within_var.png")

    print("\n实验结束。")

if __name__ == "__main__":
    main()