import itertools
import os
import numpy as np
import networkx as nx
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats
from scipy.sparse import csr_matrix, diags
from scipy.sparse.linalg import eigsh

# Corrected and accelerated execution of the supplied experiment.
# S_FINE includes s=3 because criterion A explicitly compares against s=3.
N = 15
N_up = 7
S_FINE = np.linspace(0.0, 3.0, 301)
OUTDIR = "deepdig2_orbit4"
os.makedirs(OUTDIR, exist_ok=True)

GASKET_EDGES = [
    (0,6),(0,8),(1,9),(1,11),(2,12),(2,14),
    (3,6),(3,7),(3,9),(3,10),(4,10),(4,11),(4,12),(4,13),
    (5,7),(5,8),(5,13),(5,14),
    (6,7),(7,8),(9,10),(10,11),(12,13),(13,14),
    (6,8),(9,11),(12,14)
]
GASKET_EDGES_SORTED = [tuple(sorted(e)) for e in GASKET_EDGES]
GASKET = nx.Graph()
GASKET.add_nodes_from(range(N))
GASKET.add_edges_from(GASKET_EDGES_SORTED)

ORBITS = [
    [(6,8),(9,11),(12,14)],
    [(0,6),(0,8),(1,9),(1,11),(2,12),(2,14)],
    [(3,6),(3,9),(4,11),(4,12),(5,8),(5,14)],
    [(3,7),(3,10),(4,10),(4,13),(5,7),(5,13)],
    [(6,7),(7,8),(9,10),(10,11),(12,13),(13,14)]
]
ORBIT_DICT = {i: ORBITS[i] for i in range(len(ORBITS))}

# Build the fixed-N_up basis and one sparse operator per edge once.
basis = list(itertools.combinations(range(N), N_up))
state_to_idx = {st: i for i, st in enumerate(basis)}
dim = len(basis)
spin_products = np.empty((len(GASKET_EDGES_SORTED), dim), dtype=np.int8)
edge_ops = []

for eidx, (i, j) in enumerate(GASKET_EDGES_SORTED):
    diag = np.empty(dim, dtype=np.float64)
    rows = []
    cols = []
    data = []
    for idx, st in enumerate(basis):
        i_up = i in st
        j_up = j in st
        si = 1 if i_up else -1
        sj = 1 if j_up else -1
        diag[idx] = si * sj
        spin_products[eidx, idx] = si * sj
        if i_up and not j_up:
            ns = list(st)
            ns.remove(i)
            ns.append(j)
            rows.append(idx)
            cols.append(state_to_idx[tuple(sorted(ns))])
            data.append(2.0)
        elif j_up and not i_up:
            ns = list(st)
            ns.remove(j)
            ns.append(i)
            rows.append(idx)
            cols.append(state_to_idx[tuple(sorted(ns))])
            data.append(2.0)
    op = diags(diag, format="csr") + csr_matrix((data, (rows, cols)), shape=(dim, dim))
    edge_ops.append(op)

H_uniform = sum(edge_ops[1:], edge_ops[0])
rng = np.random.default_rng(42)
base_v0 = rng.standard_normal(dim)

# The original function passed basis=None into the correlation routine; this
# version retains the basis and computes correlations from the precomputed table.
def solve_uniform_density(edge_idx, s, v0=None):
    H = H_uniform + (s - 1.0) * edge_ops[edge_idx]
    if v0 is None:
        v0 = base_v0
    evals, evecs = eigsh(H, k=2, which="SA", v0=v0, maxiter=10000, tol=1e-10)
    order = np.argsort(evals)
    evals = evals[order]
    evecs = evecs[:, order]
    gap = abs(evals[1] - evals[0])
    if gap < 1e-8:
        density = (np.abs(evecs[:, 0])**2 + np.abs(evecs[:, 1])**2) / 2.0
    else:
        density = np.abs(evecs[:, 0])**2
    return density, gap, evecs[:, 0]

def compute_within_var(corr_values):
    orbit_vars = []
    orbit_sizes = []
    edge_to_value = dict(zip(GASKET_EDGES_SORTED, corr_values))
    for orb in ORBITS:
        vals = np.array([edge_to_value[tuple(sorted(e))] for e in orb])
        orbit_vars.append(np.var(vals))
        orbit_sizes.append(len(vals))
    return float(np.average(orbit_vars, weights=orbit_sizes))

def scan_edge(edge):
    edge_idx = GASKET_EDGES_SORTED.index(tuple(sorted(edge)))
    curve = np.empty(len(S_FINE), dtype=float)
    gaps = np.empty(len(S_FINE), dtype=float)
    v0 = base_v0
    for k, s in enumerate(S_FINE):
        density, gap, v0 = solve_uniform_density(edge_idx, float(s), v0=v0)
        curve[k] = compute_within_var(density @ spin_products.T)
        gaps[k] = gap
    return curve, gaps

def compute_geometric_features(G, orbits):
    features = {}
    for oi, orb in enumerate(orbits):
        degrees = []
        shared_neighbors = []
        for u, v in orb:
            degrees.extend([G.degree(u), G.degree(v)])
            shared_neighbors.append(len(set(G.neighbors(u)).intersection(G.neighbors(v))))
        features[oi] = {
            "orbit_size": len(orb),
            "avg_degree": float(np.mean(degrees)),
            "avg_shared_neighbors": float(np.mean(shared_neighbors)),
        }
    return features

# Scan all edges needed for A/B, plus one representative edge per remaining orbit
# for a non-circular, data-derived version of criterion C.
scan_edges = []
for oi in [0, 4]:
    scan_edges.extend(ORBIT_DICT[oi])
for oi in [1, 2, 3]:
    scan_edges.append(ORBIT_DICT[oi][0])

results = []
for n, edge in enumerate(scan_edges, start=1):
    curve, gaps = scan_edge(edge)
    oi = next(oi for oi, orb in ORBIT_DICT.items() if tuple(sorted(edge)) in {tuple(sorted(x)) for x in orb})
    results.append({"orbit": oi, "edge": str(edge), "curve": curve, "gaps": gaps})
    peak_idx = int(np.argmax(curve))
    print(f"[{n}/{len(scan_edges)}] Orbit {oi}, edge {edge}: peak s={S_FINE[peak_idx]:.3f}, max within={curve[peak_idx]:.8e}")

# Criterion A
print("\n[判据 A] Orbit 4 峰位置")
criterion_a = []
for r in [x for x in results if x["orbit"] == 4]:
    curve = r["curve"]
    idx = int(np.argmax(curve))
    peak_s, peak_val = float(S_FINE[idx]), float(curve[idx])
    s0_val = float(curve[0])
    s3_val = float(curve[-1])
    passed = abs(peak_s - 0.8) < 0.1 and peak_val > s0_val and peak_val > s3_val
    criterion_a.append(passed)
    print(f"  边 {r['edge']}: peak s={peak_s:.3f}, peak={peak_val:.8e}, s=0={s0_val:.8e}, s=3={s3_val:.8e} -> {'PASS' if passed else 'FAIL'}")
print(f"  判据 A 总体: {'PASS' if all(criterion_a) else 'FAIL'}")

# Criterion B: report both maximum and average pairwise curve differences.
print("\n[判据 B] 轨道内曲线重合性")
criterion_b = {}
for oi in [0, 4]:
    curves = [r["curve"] for r in results if r["orbit"] == oi]
    pairwise = [float(np.max(np.abs(curves[i] - curves[j]))) for i in range(len(curves)) for j in range(i + 1, len(curves))]
    max_diff = max(pairwise)
    avg_diff = float(np.mean(pairwise))
    criterion_b[oi] = max_diff < 1e-5
    print(f"  Orbit {oi}: maximum pairwise max diff={max_diff:.8e}, average pairwise max diff={avg_diff:.8e} -> {'PASS' if criterion_b[oi] else 'FAIL'}")

# Criterion C: use actual scanned maxima for one representative per orbit.
print("\n[判据 C] 几何特征与最大 within 相关性")
features = compute_geometric_features(GASKET, ORBITS)
orbit_max_within = {}
for oi in range(5):
    orbit_results = [r for r in results if r["orbit"] == oi]
    orbit_max_within[oi] = float(max(np.max(r["curve"]) for r in orbit_results))
print("  data-derived orbit maxima:", {oi: f"{v:.8e}" for oi, v in orbit_max_within.items()})
criterion_c = {}
for feat in ["orbit_size", "avg_degree", "avg_shared_neighbors"]:
    x = np.array([features[oi][feat] for oi in range(5)], dtype=float)
    y = np.array([orbit_max_within[oi] for oi in range(5)], dtype=float)
    r, p = stats.pearsonr(x, y) if np.std(x) > 1e-12 and np.std(y) > 1e-12 else (np.nan, np.nan)
    passed = bool(np.isfinite(r) and abs(r) > 0.8 and p < 0.05)
    criterion_c[feat] = passed
    print(f"  {feat}: r={r:.6f}, p={p:.6f} -> {'显著相关' if passed else '无显著相关'}")

# Save complete scanned curves and a compact summary.
curve_table = []
for r in results:
    for s, val, gap in zip(S_FINE, r["curve"], r["gaps"]):
        curve_table.append({"orbit": r["orbit"], "edge": r["edge"], "s": s, "within": val, "gap": gap})
curve_df = pd.DataFrame(curve_table)
curve_df.to_csv(os.path.join(OUTDIR, "within_curves.csv"), index=False)
summary_rows = []
for oi, max_val in orbit_max_within.items():
    rep = [r for r in results if r["orbit"] == oi][0]
    idx = int(np.argmax(rep["curve"]))
    summary_rows.append({"orbit": oi, "representative_edge": rep["edge"], "peak_s": S_FINE[idx], "max_within": max_val, **features[oi]})
pd.DataFrame(summary_rows).to_csv(os.path.join(OUTDIR, "orbit_summary.csv"), index=False)

# One plot only, as a visual check for the requested Orbit 4 anomaly.
plt.figure(figsize=(8, 5))
for r in [x for x in results if x["orbit"] == 4]:
    plt.plot(S_FINE, r["curve"], label=r["edge"])
plt.axvline(0.8, color="k", linestyle="--", linewidth=1, label="s=0.8")
plt.xlabel("s")
plt.ylabel("weighted within-orbit variance")
plt.title("Orbit 4 within(s)")
plt.legend(fontsize=8)
plt.tight_layout()
plt.savefig(os.path.join(OUTDIR, "orbit4_within.png"), dpi=150)
plt.close()

print("\n实验结束。结果已保存到", OUTDIR)
print("判据汇总:", {"A": all(criterion_a), "B": criterion_b, "C": criterion_c})