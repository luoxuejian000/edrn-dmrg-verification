"""
gasket 轨道机制深挖实验 6：逐轨道内部方差与峰值错位
严格遵循：关系本体论、矛盾动力论、实践介入论、谐振调谐论、元反思律
严防工具理性悖论，旗帜鲜明反对对齐

预设判据：
  若五个边轨道的内部方差达到峰值的 s 位置至少有两个显著不同（差 > 0.1），
  则说明轨道破缺在矛盾强度轴上存在错峰，轨道响应不可同步描述。
  否则，所有轨道同步破缺。

这里每个轨道内部方差只使用该轨道内部的边计算，
矛盾边选择该轨道的第一条边作为代表。
"""
import itertools
import numpy as np
import networkx as nx
from scipy.sparse import lil_matrix, csr_matrix
from scipy.sparse.linalg import eigsh
import pandas as pd
import matplotlib.pyplot as plt
import os

# ========== 参数 ==========
N = 15
N_up = 7
S_VALUES = np.linspace(0.0, 3.0, 121)
OUTDIR = "deepdig6_per_orbit_peak_shift"
os.makedirs(OUTDIR, exist_ok=True)

# gasket 图
GASKET_EDGES = [
    (0,6),(0,8),(1,9),(1,11),(2,12),(2,14),
    (3,6),(3,7),(3,9),(3,10),(4,10),(4,11),(4,12),(4,13),
    (5,7),(5,8),(5,13),(5,14),
    (6,7),(7,8),(9,10),(10,11),(12,13),(13,14),
    (6,8),(9,11),(12,14)
]
GASKET_EDGES_SORTED = [tuple(sorted(e)) for e in GASKET_EDGES]

# 边轨道硬编码
ORBITS = [
    [(6,8),(9,11),(12,14)],                 # Orbit 0
    [(0,6),(0,8),(1,9),(1,11),(2,12),(2,14)], # Orbit 1
    [(3,6),(3,9),(4,11),(4,12),(5,8),(5,14)], # Orbit 2
    [(3,7),(3,10),(4,10),(4,13),(5,7),(5,13)], # Orbit 3
    [(6,7),(7,8),(9,10),(10,11),(12,13),(13,14)] # Orbit 4
]

def build_sector_hamiltonian(N, edges, J_vals, N_up):
    basis = list(itertools.combinations(range(N), N_up))
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = lil_matrix((dim, dim), dtype=float)
    for (i,j), J in zip(edges, J_vals):
        for idx, st in enumerate(basis):
            si = 1 if i in st else -1
            sj = 1 if j in st else -1
            H[idx, idx] += J * si * sj
        for idx, st in enumerate(basis):
            i_up = i in st
            j_up = j in st
            if i_up and not j_up:
                ns = list(st); ns.remove(i); ns.append(j)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2*J
            elif j_up and not i_up:
                ns = list(st); ns.remove(j); ns.append(i)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2*J
    return csr_matrix(H), basis

def solve_uniform_density(N, edges, J_vals, N_up, seed=42):
    H, basis = build_sector_hamiltonian(N, edges, J_vals, N_up)
    rng = np.random.default_rng(seed)
    v0 = rng.standard_normal(H.shape[0])
    evals, evecs = eigsh(H, k=2, which='SA', v0=v0, maxiter=10000, tol=1e-12)
    gap = abs(evals[1] - evals[0])
    psi0 = evecs[:, 0]
    psi1 = evecs[:, 1] if gap < 1e-8 else None
    if psi1 is not None:
        density = (np.abs(psi0)**2 + np.abs(psi1)**2) / 2.0
    else:
        density = np.abs(psi0)**2
    return density, basis

def edge_correlation(density, basis, edge):
    i, j = edge
    sp = np.array([(1 if i in st else -1)*(1 if j in st else -1) for st in basis])
    return np.sum(density * sp)

def main():
    print("="*80)
    print("深挖6：逐轨道内部方差与峰值错位")
    print("="*80)

    peak_positions = {}
    curves = {}

    for oi, orbit_edges in enumerate(ORBITS):
        # 选择该轨道的第一条边作为矛盾边
        contradiction_edge = orbit_edges[0]
        cont_idx = GASKET_EDGES_SORTED.index(tuple(sorted(contradiction_edge)))
        print(f"\nOrbit {oi}, 矛盾边 {contradiction_edge}")

        within_curve = []
        J_vals = np.ones(len(GASKET_EDGES_SORTED))
        for s in S_VALUES:
            J_vals[cont_idx] = s
            density, basis = solve_uniform_density(N, GASKET_EDGES_SORTED, J_vals, N_up)
            # 计算该轨道内所有边的关联值
            corr_vals = [edge_correlation(density, basis, e) for e in orbit_edges]
            # 该轨道内部方差
            var_o = np.var(corr_vals)
            within_curve.append(var_o)
            J_vals[cont_idx] = 1.0
        within_curve = np.array(within_curve)
        curves[oi] = within_curve

        peak_idx = np.argmax(within_curve)
        peak_s = S_VALUES[peak_idx]
        peak_val = within_curve[peak_idx]
        peak_positions[oi] = peak_s
        print(f"  峰值位置 s={peak_s:.2f}, 峰值方差={peak_val:.6e}")

    # 判据：峰值位置是否明显不同
    unique_peaks = sorted(set(round(p, 1) for p in peak_positions.values()))
    print(f"\n各轨道峰值位置: {peak_positions}")
    print(f"四舍五入到0.1的唯一峰值: {unique_peaks}")

    # 至少两个显著不同的峰值（差>0.1）
    distinct_peaks = []
    for p in peak_positions.values():
        if not any(abs(p - q) <= 0.1 for q in distinct_peaks):
            distinct_peaks.append(p)
    print(f"显著不同的峰值数: {len(distinct_peaks)}")

    if len(distinct_peaks) >= 2:
        print("判据 PASS: 轨道破缺存在错峰，响应不同步")
    else:
        print("判据 FAIL: 轨道破缺同步，响应可同步描述")

    # 绘图
    plt.figure(figsize=(10,6))
    for oi in range(5):
        plt.plot(S_VALUES, curves[oi], label=f'Orbit {oi}', marker='.')
    plt.xlabel('s')
    plt.ylabel('orbit-internal variance')
    plt.title('Per-orbit internal variance vs s')
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(OUTDIR, "per_orbit_internal_variance.png"), dpi=150)
    print(f"图已保存: {OUTDIR}/per_orbit_internal_variance.png")

    # 保存 CSV
    df = pd.DataFrame({'s': S_VALUES})
    for oi in range(5):
        df[f'orbit{oi}'] = curves[oi]
    df.to_csv(os.path.join(OUTDIR, "per_orbit_internal_variance.csv"), index=False)
    print(f"数据已保存: {OUTDIR}/per_orbit_internal_variance.csv")

    print("\n实验结束。")

if __name__ == "__main__":
    main()