"""
gasket 轨道机制深挖实验 1：全边扫描与轨道分类
严格遵循：关系本体论、矛盾动力论、实践介入论、谐振调谐论、元反思律
严防工具理性悖论，旗帜鲜明反对对齐

实验目的：
  对 gasket 的全部 27 条边，逐条作为矛盾边扫描 s∈[0,3]，
  计算关联涨落的空间分解：
    total_var = within_var + between_var
  并观察每条边所在轨道是否决定 within(s) 的曲线形状。

预设判据（运行前写死）：
  A. 在 s=1 均匀点，所有 27 条边的 within_var 应小于 1e-10。
  B. 在 s=1 均匀点，随机重排边关联后 within_var 占比应显著上升。
  C. 同一轨道内的所有边，其 within(s) 曲线应当重合或高度相似。
  D. 不同轨道的 within(s) 曲线可以不同，但应表现出可分类的结构。

负对照：
  随机图（N=15, 27边, seed=42）在 s=1 时进行同样分解，
  预期轨道内方差占比不接近零。
"""
import itertools
import numpy as np
import pandas as pd
import networkx as nx
from scipy.sparse import lil_matrix, csr_matrix
from scipy.sparse.linalg import eigsh
import matplotlib.pyplot as plt
import json
import os

# ==================== 预设参数 ====================
N = 15
N_up = 7                     # Sz=+1/2 扇区
S_VALUES = np.linspace(0.0, 3.0, 31)
RANDOM_SEED = 42
WITHIN_THRESHOLD_S1 = 1e-10
OUTDIR = "deepdig1_all_edges"
os.makedirs(OUTDIR, exist_ok=True)

# ==================== 图定义 ====================
GASKET_EDGES = [
    (0,6),(0,8),(1,9),(1,11),(2,12),(2,14),
    (3,6),(3,7),(3,9),(3,10),(4,10),(4,11),(4,12),(4,13),
    (5,7),(5,8),(5,13),(5,14),
    (6,7),(7,8),(9,10),(10,11),(12,13),(13,14),
    (6,8),(9,11),(12,14)
]
GASKET = nx.Graph()
GASKET.add_nodes_from(range(N))
GASKET.add_edges_from(GASKET_EDGES)
GASKET_EDGES_SORTED = [tuple(sorted(e)) for e in GASKET_EDGES]

RANDOM = nx.gnm_random_graph(15, 27, seed=42)
RANDOM = nx.relabel_nodes(RANDOM, {old: new for new, old in enumerate(RANDOM.nodes())})
RANDOM_EDGES_SORTED = [tuple(sorted(e)) for e in RANDOM.edges()]

# ==================== 自守轨道计算 ====================
def compute_edge_orbits(G):
    """返回边轨道列表，每个轨道是排序边元组的列表。"""
    try:
        GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
        automorphisms = list(GM.isomorphisms_iter())
        if not automorphisms:
            return [[tuple(sorted(e))] for e in G.edges()]
        edge_set = set(tuple(sorted(e)) for e in G.edges())
        orbits = []
        remaining = set(edge_set)
        while remaining:
            e0 = remaining.pop()
            orbit = set()
            for perm in automorphisms:
                new_e = tuple(sorted((perm[e0[0]], perm[e0[1]])))
                if new_e in edge_set:
                    orbit.add(new_e)
            orbits.append(list(orbit))
            remaining -= orbit
        return orbits
    except Exception as e:
        print(f"[Warning] 自守计算失败: {e}")
        return [[tuple(sorted(e))] for e in G.edges()]

# ==================== 哈密顿量与基态 ====================
def build_sector_hamiltonian(N, edges, J_vals, N_up):
    basis = list(itertools.combinations(range(N), N_up))
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = lil_matrix((dim, dim), dtype=float)
    for (i,j), J in zip(edges, J_vals):
        for idx, st in enumerate(basis):
            si = 1 if i in st else -1
            sj = 1 if j in st else -1
            H[idx, idx] += J * si * sj
        for idx, st in enumerate(basis):
            i_up = i in st
            j_up = j in st
            if i_up and not j_up:
                ns = list(st); ns.remove(i); ns.append(j)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2*J
            elif j_up and not i_up:
                ns = list(st); ns.remove(j); ns.append(i)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2*J
    return csr_matrix(H), basis

def compute_correlations_from_density(N, edges_sorted, basis, density):
    corr_list = []
    for (i,j) in edges_sorted:
        sp = np.array([(1 if i in st else -1)*(1 if j in st else -1) for st in basis])
        corr = np.sum(density * sp)
        corr_list.append(corr)
    return np.array(corr_list)

def solve_uniform_density(N, edges_sorted, J_vals, N_up, seed=RANDOM_SEED):
    H, basis = build_sector_hamiltonian(N, edges_sorted, J_vals, N_up)
    rng = np.random.default_rng(seed)
    v0 = rng.standard_normal(H.shape[0])
    evals, evecs = eigsh(H, k=2, which='SA', v0=v0, maxiter=10000, tol=1e-12)
    gap = abs(evals[1] - evals[0])
    psi0 = evecs[:, 0]
    psi1 = evecs[:, 1] if gap < 1e-8 else None
    if psi1 is not None:
        density = (np.abs(psi0)**2 + np.abs(psi1)**2) / 2.0
    else:
        density = np.abs(psi0)**2
    return density, gap

# ==================== 方差分解 ====================
def decompose_variance(edges_sorted, edge_values, edge_orbits):
    """edges_sorted 是边列表（排序元组），与 edge_values 顺序一致。"""
    edge_to_value = {}
    for e, val in zip(edges_sorted, edge_values):
        edge_to_value[tuple(sorted(e))] = val
    total_var = np.var(edge_values)
    orbit_vars = []
    orbit_means = []
    orbit_sizes = []
    for orbit in edge_orbits:
        vals = [edge_to_value[tuple(sorted(e))] for e in orbit]
        if not vals:
            continue
        orbit_means.append(np.mean(vals))
        orbit_vars.append(np.var(vals))
        orbit_sizes.append(len(vals))
    if not orbit_vars:
        return total_var, 0.0, 0.0, 0.0
    sizes = np.array(orbit_sizes, dtype=float)
    within_var = np.average(orbit_vars, weights=sizes)
    if len(orbit_means) > 1:
        overall_mean = np.average(orbit_means, weights=sizes)
        between_var = np.average((np.array(orbit_means) - overall_mean)**2, weights=sizes)
    else:
        between_var = 0.0
    return total_var, within_var, between_var

# ==================== 主程序 ====================
def main():
    print("="*80)
    print("gasket 全边扫描与轨道分类")
    print("预设阈值：within(s=1) <", WITHIN_THRESHOLD_S1)
    print("="*80)

    # 计算 gasket 轨道
    gasket_orbits = compute_edge_orbits(GASKET)
    print(f"\n[gasket] 边轨道数: {len(gasket_orbits)}")
    orbit_dict = {}
    for i, orb in enumerate(gasket_orbits):
        orb_sorted = [tuple(sorted(e)) for e in orb]
        orbit_dict[i] = orb_sorted
        print(f"  Orbit {i}: size {len(orb_sorted)}, edges {orb_sorted}")

    # 构建边到轨道索引映射
    edge_to_orbit = {}
    for orbit_idx, orb in orbit_dict.items():
        for e in orb:
            edge_to_orbit[tuple(sorted(e))] = orbit_idx

    # 扫描所有 27 条边
    all_results = []
    for edge_idx, edge in enumerate(GASKET_EDGES_SORTED):
        edge_orb = edge_to_orbit[edge]
        print(f"\n扫描边 {edge} (orbit {edge_orb})")
        J_vals = np.ones(len(GASKET_EDGES_SORTED))
        for s in S_VALUES:
            # 设置矛盾边权重
            J_vals_scan = J_vals.copy()
            J_vals_scan[edge_idx] = s
            density, gap = solve_uniform_density(N, GASKET_EDGES_SORTED, J_vals_scan, N_up)
            corr = compute_correlations_from_density(N, GASKET_EDGES_SORTED, None, density)
            total, within, between = decompose_variance(GASKET_EDGES_SORTED, corr, gasket_orbits)
            all_results.append({
                'edge': str(edge),
                'edge_idx': edge_idx,
                'orbit': edge_orb,
                's': s,
                'total_var': total,
                'within_var': within,
                'between_var': between,
                'gap': gap
            })

    df = pd.DataFrame(all_results)
    df.to_csv(os.path.join(OUTDIR, "gasket_all_edges_deepdig1.csv"), index=False)
    print(f"\n完整数据已保存: {OUTDIR}/gasket_all_edges_deepdig1.csv")

    # 检查判据 A：所有边在 s=1 的 within_var
    s1_idx = np.argmin(np.abs(S_VALUES - 1.0))
    s1_df = df[df['s'] == S_VALUES[s1_idx]]
    within_s1 = s1_df['within_var'].values
    print("\n[判据 A] s=1 时各边 within_var 最大值:", within_s1.max())
    if within_s1.max() < WITHIN_THRESHOLD_S1:
        print("[判据 A] PASS: 所有边在均匀点轨道内方差接近零")
    else:
        print("[判据 A] FAIL: 存在边在均匀点轨道内方差不为零")

    # 检查判据 B：随机重排对照
    # 随机选择一条边 (0,6) 的 s=1 结果进行重排
    edge_example = (0,6)
    edge_example_idx = GASKET_EDGES_SORTED.index(edge_example)
    density_s1, _ = solve_uniform_density(N, GASKET_EDGES_SORTED, np.ones(len(GASKET_EDGES_SORTED)), N_up)
    corr_s1 = compute_correlations_from_density(N, GASKET_EDGES_SORTED, None, density_s1)
    rng_perm = np.random.default_rng(999)
    permuted_corr = corr_s1[rng_perm.permutation(len(corr_s1))]
    total_orig, within_orig, between_orig = decompose_variance(GASKET_EDGES_SORTED, corr_s1, gasket_orbits)
    total_perm, within_perm, between_perm = decompose_variance(GASKET_EDGES_SORTED, permuted_corr, gasket_orbits)
    print(f"\n[判据 B] 随机重排对照 (边 {edge_example}, s=1):")
    print(f"  原始 within_var = {within_orig:.6e}, 随机重排后 within_var = {within_perm:.6e}")
    if within_perm > within_orig * 1e6:
        print("[判据 B] PASS: 随机重排后轨道内方差占比显著上升")
    else:
        print("[判据 B] FAIL: 随机重排后轨道内方差占比未显著上升")

    # 检查判据 C：同一轨道内边的 within(s) 曲线重合程度
    print("\n[判据 C] 同一轨道内边的 within(s) 曲线相似性")
    orbit_curves = {}
    for orbit_idx in range(len(gasket_orbits)):
        orbit_edges = orbit_dict[orbit_idx]
        curves = []
        for edge in orbit_edges:
            edge_idx = GASKET_EDGES_SORTED.index(edge)
            sub = df[(df['edge_idx'] == edge_idx)].sort_values('s')
            curves.append(sub['within_var'].values)
        orbit_curves[orbit_idx] = {
            'orbit': orbit_idx,
            'edges': [str(e) for e in orbit_edges],
            'curves': np.array(curves)
        }
    for orbit_idx in range(len(gasket_orbits)):
        curves = orbit_curves[orbit_idx]['curves']
        if len(curves) > 1:
            # 计算各曲线之间的平均最大差异
            max_diffs = []
            for i in range(len(curves)):
                for j in range(i+1, len(curves)):
                    max_diffs.append(np.max(np.abs(curves[i] - curves[j])))
            avg_max_diff = np.mean(max_diffs)
            print(f"  Orbit {orbit_idx} ({len(curves)} edges): avg max diff = {avg_max_diff:.6f}")
            if avg_max_diff < 1e-5:
                print("    -> 高度重合，判据 C PASS")
            else:
                print("    -> 曲线差异较大，判据 C FAIL（或需要更细检查）")
        else:
            print(f"  Orbit {orbit_idx} (1 edge): 无法比较, 跳过")

    # 负对照：随机图在 s=1 的分解
    print("\n[负对照] 随机图 s=1 轨道分解")
    random_orbits = compute_edge_orbits(RANDOM)
    random_edges_sorted = [tuple(sorted(e)) for e in RANDOM.edges()]
    density_rand, _ = solve_uniform_density(N, random_edges_sorted, np.ones(len(random_edges_sorted)), N_up)
    corr_rand = compute_correlations_from_density(N, random_edges_sorted, None, density_rand)
    total_rand, within_rand, between_rand = decompose_variance(random_edges_sorted, corr_rand, random_orbits)
    print(f"  随机图 total_var = {total_rand:.6e}, within_var = {within_rand:.6e}")
    print(f"  随机图 within/total = {within_rand/total_rand if total_rand>1e-30 else 0:.6e}")
    if within_rand/total_rand > 0.1:
        print("  负对照符合预期：随机图轨道内涨落不可忽略")
    else:
        print("  负对照异常：需要检查")

    # 绘图：每个轨道的 within(s) 曲线
    plt.figure(figsize=(12, 8))
    for orbit_idx in range(len(gasket_orbits)):
        curves = orbit_curves[orbit_idx]['curves']
        edges = orbit_curves[orbit_idx]['edges']
        for ci, curve in enumerate(curves):
            plt.plot(S_VALUES, curve, marker='.', label=f"orbit {orbit_idx} edge {edges[ci]}")
    plt.xlabel('s')
    plt.ylabel('within_var')
    plt.title('gasket within-orbit variance for all edges')
    plt.yscale('log')
    plt.grid(True, alpha=0.3)
    plt.legend(fontsize=6, ncol=2)
    plt.tight_layout()
    plt.savefig(os.path.join(OUTDIR, "gasket_all_edges_within_curves.png"), dpi=150)
    print(f"\n图已保存: {OUTDIR}/gasket_all_edges_within_curves.png")

    print("\n实验结束。数据可复现。")

if __name__ == "__main__":
    main()