import itertools
import numpy as np
import networkx as nx
from scipy.sparse import lil_matrix, csr_matrix
from scipy.sparse.linalg import eigsh
import pandas as pd
import matplotlib.pyplot as plt
import os

# ========== 参数 ==========
N = 15
N_up = 7
S_VALUES = np.linspace(0.0, 3.0, 121)
OUTDIR = "deepdig7_cross_scan"
os.makedirs(OUTDIR, exist_ok=True)

# gasket 图
GASKET_EDGES = [
    (0,6),(0,8),(1,9),(1,11),(2,12),(2,14),
    (3,6),(3,7),(3,9),(3,10),(4,10),(4,11),(4,12),(4,13),
    (5,7),(5,8),(5,13),(5,14),
    (6,7),(7,8),(9,10),(10,11),(12,13),(13,14),
    (6,8),(9,11),(12,14)
]
GASKET_EDGES_SORTED = [tuple(sorted(e)) for e in GASKET_EDGES]

# 边轨道硬编码
ORBITS = [
    [(6,8),(9,11),(12,14)],
    [(0,6),(0,8),(1,9),(1,11),(2,12),(2,14)],
    [(3,6),(3,9),(4,11),(4,12),(5,8),(5,14)],
    [(3,7),(3,10),(4,10),(4,13),(5,7),(5,13)],
    [(6,7),(7,8),(9,10),(10,11),(12,13),(13,14)]
]
REPRESENTATIVES = [orb[0] for orb in ORBITS]

# ========== 哈密顿量与基态 ==========
def build_sector_hamiltonian(N, edges, J_vals, N_up):
    basis = list(itertools.combinations(range(N), N_up))
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = lil_matrix((dim, dim), dtype=float)
    for (i,j), J in zip(edges, J_vals):
        for idx, st in enumerate(basis):
            si = 1 if i in st else -1
            sj = 1 if j in st else -1
            H[idx, idx] += J * si * sj
        for idx, st in enumerate(basis):
            i_up = i in st
            j_up = j in st
            if i_up and not j_up:
                ns = list(st); ns.remove(i); ns.append(j)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2*J
            elif j_up and not i_up:
                ns = list(st); ns.remove(j); ns.append(i)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2*J
    return csr_matrix(H), basis

def solve_uniform_density(N, edges, J_vals, N_up, seed=42):
    H, basis = build_sector_hamiltonian(N, edges, J_vals, N_up)
    rng = np.random.default_rng(seed)
    v0 = rng.standard_normal(H.shape[0])
    evals, evecs = eigsh(H, k=2, which='SA', v0=v0, maxiter=10000, tol=1e-12)
    gap = abs(evals[1] - evals[0])
    psi0 = evecs[:, 0]
    psi1 = evecs[:, 1] if gap < 1e-8 else None
    if psi1 is not None:
        density = (np.abs(psi0)**2 + np.abs(psi1)**2) / 2.0
    else:
        density = np.abs(psi0)**2
    return density, basis

def edge_correlation(density, basis, edge):
    i, j = edge
    sp = np.array([(1 if i in st else -1)*(1 if j in st else -1) for st in basis])
    return np.sum(density * sp)

def main():
    print("="*80)
    print("深挖7：矛盾注入轨道 vs 响应轨道的交叉扫描")
    print("="*80)

    peak_positions = {inj: {} for inj in range(5)}
    all_curves = {}

    for inj_orb, cont_edge in enumerate(REPRESENTATIVES):
        print(f"\n注入轨道 {inj_orb}, 矛盾边 {cont_edge}")
        cont_idx = GASKET_EDGES_SORTED.index(tuple(sorted(cont_edge)))

        for resp_orb, resp_edges in enumerate(ORBITS):
            curve = []
            J_vals = np.ones(len(GASKET_EDGES_SORTED))
            for s in S_VALUES:
                J_vals[cont_idx] = s
                density, basis = solve_uniform_density(N, GASKET_EDGES_SORTED, J_vals, N_up)
                corr_vals = [edge_correlation(density, basis, e) for e in resp_edges]
                var_o = np.var(corr_vals)
                curve.append(var_o)
                J_vals[cont_idx] = 1.0
            curve = np.array(curve)
            all_curves[(inj_orb, resp_orb)] = curve
            peak_idx = np.argmax(curve)
            peak_s = S_VALUES[peak_idx]
            peak_positions[inj_orb][resp_orb] = peak_s
            print(f"  响应轨道 {resp_orb}: 峰值位置 s={peak_s:.2f}")

    df_peaks = pd.DataFrame(peak_positions).T
    df_peaks.columns = [f'resp_{i}' for i in range(5)]
    df_peaks.index = [f'inj_{i}' for i in range(5)]
    df_peaks.to_csv(os.path.join(OUTDIR, "peak_positions_matrix.csv"))

    print("\n峰值位置矩阵（行=注入轨道，列=响应轨道）：")
    print(df_peaks)

    resp_std = df_peaks.std(axis=0)
    inj_std = df_peaks.std(axis=1)

    print("\n各响应轨道跨注入的标准差：", resp_std.values)
    print("各注入轨道跨响应的标准差：", inj_std.values)

    if np.all(resp_std < 0.2):
        print("判据 A PASS: 响应轨道主导峰值位置")
    else:
        print("判据 A FAIL: 响应轨道不单独主导")

    if np.all(inj_std < 0.2):
        print("判据 B PASS: 注入轨道主导峰值位置")
    else:
        print("判据 B FAIL: 注入轨道不单独主导")

    if not (np.all(resp_std < 0.2) or np.all(inj_std < 0.2)):
        print("判据 C PASS: 存在交互作用，两个因素都重要")
    else:
        print("判据 C FAIL: 不存在交互作用")

    fig, axes = plt.subplots(5, 1, figsize=(12, 20), sharex=True)
    for inj in range(5):
        ax = axes[inj]
        for resp in range(5):
            ax.plot(S_VALUES, all_curves[(inj, resp)], label=f'resp {resp}')
        ax.set_title(f'Injection orbit {inj}, edge {REPRESENTATIVES[inj]}')
        ax.set_ylabel('within_var')
        ax.legend(fontsize=7)
        ax.grid(True, alpha=0.3)
    axes[-1].set_xlabel('s')
    plt.tight_layout()
    plt.savefig(os.path.join(OUTDIR, "cross_scan_curves.png"), dpi=150)
    print(f"图已保存: {OUTDIR}/cross_scan_curves.png")

    curve_dict = {'s': S_VALUES}
    for inj in range(5):
        for resp in range(5):
            curve_dict[f'inj{inj}_resp{resp}'] = all_curves[(inj, resp)]
    df_curves = pd.DataFrame(curve_dict)
    df_curves.to_csv(os.path.join(OUTDIR, "all_cross_curves.csv"), index=False)
    print(f"数据已保存: {OUTDIR}/all_cross_curves.csv")

    print("\n实验结束。")
    return df_peaks, all_curves, resp_std, inj_std

if __name__ == "__main__":
    df_peaks, all_curves, resp_std, inj_std = main()