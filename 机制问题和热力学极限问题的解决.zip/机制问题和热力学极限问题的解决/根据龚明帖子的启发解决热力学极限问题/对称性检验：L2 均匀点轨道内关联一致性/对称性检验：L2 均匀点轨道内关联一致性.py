"""
对称性检验：L2 均匀点轨道内关联一致性
严格遵循：关系本体论、矛盾动力论、实践介入论、谐振调谐论、元反思律
严防工具理性悖论，旗帜鲜明反对对齐

目标：
  不追求更大系统，而是在 L2 上验证：
  均匀点 s=1 处，同一自守轨道内所有边的关联期望值是否相等。
  如果相等，则轨道内方差为零是由图的对称性保证的，
  不依赖于数值方法，也不需要在热力学极限下重新检验。

预设判据：
  每个轨道内边关联值的最大差异 < 1e-10  -> 判据通过
  随机重排边关联值后，轨道内方差应显著上升 -> 说明轨道结构关键
  若判据失败，如实报告，不调整任何参数。
"""
import itertools
import numpy as np
import networkx as nx
from scipy.sparse import lil_matrix, csr_matrix
from scipy.sparse.linalg import eigsh
import json, os

# ==================== 预设参数 ====================
OUTDIR = "l2_orbit_symmetry"
os.makedirs(OUTDIR, exist_ok=True)
THRESHOLD = 1e-10
N = 15
N_up = 7  # Sz=+1/2

# ==================== Sierpiński gasket L2 边列表 ====================
def sierpinski_edges_l2():
    edges = [
        (0,6),(0,8),(1,9),(1,11),(2,12),(2,14),
        (3,6),(3,7),(3,9),(3,10),(4,10),(4,11),(4,12),(4,13),
        (5,7),(5,8),(5,13),(5,14),
        (6,7),(7,8),(9,10),(10,11),(12,13),(13,14),
        (6,8),(9,11),(12,14)
    ]
    return [tuple(sorted(e)) for e in edges]

EDGES = sierpinski_edges_l2()

# ==================== 边自守轨道 ====================
def compute_edge_orbits(edges):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
    automorphisms = list(GM.isomorphisms_iter())
    if not automorphisms:
        return [[e] for e in edges]
    edge_set = set(edges)
    orbits = []
    remaining = set(edge_set)
    while remaining:
        e0 = remaining.pop()
        orbit = set()
        for perm in automorphisms:
            new_e = tuple(sorted((perm[e0[0]], perm[e0[1]])))
            if new_e in edge_set:
                orbit.add(new_e)
        orbits.append(list(orbit))
        remaining -= orbit
    return orbits

ORBITS = compute_edge_orbits(EDGES)

# ==================== 哈密顿量与基态 ====================
def build_hamiltonian(N, edges, N_up):
    basis = list(itertools.combinations(range(N), N_up))
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = lil_matrix((dim, dim), dtype=float)
    for (i,j) in edges:
        for idx, st in enumerate(basis):
            si = 1 if i in st else -1
            sj = 1 if j in st else -1
            H[idx, idx] += si * sj
        for idx, st in enumerate(basis):
            i_up = i in st
            j_up = j in st
            if i_up and not j_up:
                ns = list(st)
                ns.remove(i)
                ns.append(j)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2.0
            elif j_up and not i_up:
                ns = list(st)
                ns.remove(j)
                ns.append(i)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2.0
    return csr_matrix(H), basis

def solve_uniform_density(N, edges, N_up):
    H, basis = build_hamiltonian(N, edges, N_up)
    rng = np.random.default_rng(42)
    v0 = rng.standard_normal(H.shape[0])
    evals, evecs = eigsh(H, k=2, which='SA', v0=v0, maxiter=10000, tol=1e-12)
    gap = abs(evals[1] - evals[0])
    psi0 = evecs[:, 0]
    psi1 = evecs[:, 1] if gap < 1e-8 else None
    if psi1 is not None:
        density = (np.abs(psi0)**2 + np.abs(psi1)**2) / 2.0
    else:
        density = np.abs(psi0)**2
    return density, basis

def edge_correlations(edges, basis, density):
    corr = []
    for (i,j) in edges:
        sp = np.array([(1 if i in st else -1)*(1 if j in st else -1) for st in basis])
        corr.append(np.sum(density * sp))
    return np.array(corr)

# ==================== 主程序 ====================
def main():
    print("="*70)
    print("L2 均匀点轨道内关联一致性检验")
    print("="*70)

    density, basis = solve_uniform_density(N, EDGES, N_up)
    corr = edge_correlations(EDGES, basis, density)

    edge_to_val = {e: v for e, v in zip(EDGES, corr)}

    print("\n各轨道内边关联值：")
    orbit_max_diffs = []
    for i, orbit in enumerate(ORBITS):
        vals = [edge_to_val[e] for e in orbit]
        max_diff = max(vals) - min(vals)
        orbit_max_diffs.append(max_diff)
        print(f"  Orbit {i}: size={len(orbit)}, max_diff={max_diff:.6e}")
        for e, v in zip(orbit, vals):
            print(f"    {e}: {v:.10f}")

    # 判据：每个轨道最大差异都小于阈值
    max_all = max(orbit_max_diffs)
    print(f"\n所有轨道中的最大关联差异: {max_all:.6e}")
    if max_all < THRESHOLD:
        print(f"[PASS] 轨道内关联差异 < {THRESHOLD:.0e}，对称性成立")
    else:
        print(f"[FAIL] 轨道内关联差异 >= {THRESHOLD:.0e}，对称性破缺")

    # 随机重排对照
    rng = np.random.default_rng(999)
    permuted_corr = corr[rng.permutation(len(corr))]
    # 重新计算轨道内方差（使用原始轨道划分）
    orbit_vars_orig = []
    orbit_vars_perm = []
    for orbit in ORBITS:
        vals_orig = [edge_to_val[e] for e in orbit]
        vals_perm = [permuted_corr[EDGES.index(e)] for e in orbit]
        orbit_vars_orig.append(np.var(vals_orig))
        orbit_vars_perm.append(np.var(vals_perm))
    within_orig = np.mean(orbit_vars_orig)
    within_perm = np.mean(orbit_vars_perm)
    print(f"\n原始轨道内方差: {within_orig:.6e}")
    print(f"随机重排后轨道内方差: {within_perm:.6e}")
    if within_perm > within_orig * 1e6:
        print("[PASS] 随机重排破坏轨道一致性")
    else:
        print("[FAIL] 随机重排未显著破坏轨道一致性")

    # 保存结果
    result = {
        'orbit_count': len(ORBITS),
        'orbit_sizes': [len(o) for o in ORBITS],
        'orbit_max_diffs': [float(d) for d in orbit_max_diffs],
        'max_all_diff': float(max_all),
        'within_orig': float(within_orig),
        'within_perm': float(within_perm)
    }
    with open(os.path.join(OUTDIR, 'orbit_symmetry_result.json'), 'w') as f:
        json.dump(result, f, indent=2)
    print(f"\n结果已保存至 {OUTDIR}/orbit_symmetry_result.json")

if __name__ == "__main__":
    main()