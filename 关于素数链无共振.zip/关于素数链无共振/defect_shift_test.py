"""
缺陷位移验证 —— 金箍棒 3.0 DMRG
检验马拉特"镜像对称破缺"假说
实验一：N=6，矛盾边从(2,3)移至(1,2)
实验二：N=7，矛盾边从(2,3)移至(3,4)
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tenpy.models.model import CouplingMPOModel
from tenpy.models.lattice import Chain
from tenpy.networks.site import SpinHalfSite
from tenpy.networks.mps import MPS
from tenpy.algorithms import dmrg

class DefectShiftModel(CouplingMPOModel):
    """链式 Heisenberg 模型，矛盾边位置和强度可独立设置"""
    def __init__(self, model_params):
        L = model_params.get('L', 6)
        self.contradiction_strength = model_params.get('contradiction_strength', 1.0)
        self.contradiction_edge = model_params.get('contradiction_edge', (L//2 - 1, L//2))
        lat = Chain(L, SpinHalfSite(conserve='Sz'), bc='open')
        model_params['lattice'] = lat
        CouplingMPOModel.__init__(self, model_params)

    def init_terms(self, model_params):
        L = self.lat.N_sites
        for i in range(L-1):
            if (i, i+1) == self.contradiction_edge or (i+1, i) == self.contradiction_edge:
                J = self.contradiction_strength
            else:
                J = 1.0
            self.add_coupling_term(J * 0.5, i, i+1, 'Sp', 'Sm', plus_hc=True)
            self.add_coupling_term(J, i, i+1, 'Sz', 'Sz')


def run_shift_test(L, contradiction_edge, label, strengths=None, chi_max=100):
    """扫描矛盾强度，返回诊断数据"""
    if strengths is None:
        strengths = np.linspace(0.0, 3.0, 9)
    
    gaps, coarse_vals, fine_vals = [], [], []
    print(f"\n=== {label} (L={L}, edge={contradiction_edge}) ===")
    
    for s in strengths:
        M = DefectShiftModel(dict(
            L=L,
            contradiction_edge=contradiction_edge,
            contradiction_strength=s,
            bc_MPS='finite', conserve='Sz'
        ))
        init = ['up', 'down'] * (L // 2)
        if L % 2 == 1:
            init.append('up')
        psi = MPS.from_product_state(M.lat.mps_sites(), init, bc='finite')
        dmrg_params = {'mixer': True, 'chi_max': chi_max, 'max_sweeps': 50, 'verbose': 0}
        
        eng = dmrg.run(psi, M, dmrg_params)
        E0 = eng['E']
        
        init_ex = init.copy()
        center = L // 2
        init_ex[center] = 'down' if init[center] == 'up' else 'up'
        psi_ex = MPS.from_product_state(M.lat.mps_sites(), init_ex, bc='finite')
        eng_ex = dmrg.run(psi_ex, M, dmrg_params)
        E1 = eng_ex['E']
        gap = E1 - E0

        Sz = psi.expectation_value('Sz')
        coarse = np.mean(np.abs(Sz))
        corrs = []
        for i in range(L - 1):
            corr = psi.correlation_function('Sz', 'Sz', [i], [i+1])
            corrs.append(corr[0])
        fine = np.std(corrs) if corrs else 0.0
        
        gaps.append(gap)
        coarse_vals.append(coarse)
        fine_vals.append(fine)
        print(f"s={s:.2f}: gap={gap:.6f}, coarse={coarse:.4f}, fine={fine:.4f}")
    
    return np.array(strengths), np.array(gaps), np.array(coarse_vals), np.array(fine_vals)


if __name__ == "__main__":
    strengths = np.linspace(0.0, 3.0, 9)
    
    # 实验一：N=6，矛盾边从 (2,3) 移至 (1,2)
    s1, g1, c1, f1 = run_shift_test(6, (1, 2), "N=6 asymmetric", strengths, chi_max=100)
    
    # 实验二：N=7，矛盾边从 (2,3) 移至 (3,4)
    s2, g2, c2, f2 = run_shift_test(7, (3, 4), "N=7 asymmetric", strengths, chi_max=100)
    
    # 保存数据
    np.savetxt('defect_shift_N6_asymmetric.csv',
               np.column_stack((s1, g1, c1, f1)),
               header='strength,gap,coarse,fine', delimiter=',')
    np.savetxt('defect_shift_N7_asymmetric.csv',
               np.column_stack((s2, g2, c2, f2)),
               header='strength,gap,coarse,fine', delimiter=',')
    
    # 并排诊断图
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    for ax, s_vals, coarse, fine, title in [
        (axes[0], s1, c1, f1, 'N=6 asymmetric (1,2)'),
        (axes[1], s2, c2, f2, 'N=7 asymmetric (3,4)')
    ]:
        ax_ = ax.twinx()
        ax.plot(s_vals, coarse, 'o-', label='Coarse')
        ax_.plot(s_vals, fine, 's-', color='red', label='Fine')
        ax.set_xlabel('s')
        ax.set_ylabel('Coarse')
        ax_.set_ylabel('Fine')
        ax.legend(loc='upper left')
        ax_.legend(loc='upper right')
        ax.set_title(title)
    plt.suptitle('Defect Shift Test: Marat Oscillation Hypothesis')
    plt.tight_layout()
    plt.savefig('defect_shift_test.png', dpi=150)
    print("\nDone. Data saved to defect_shift_N6_asymmetric.csv / N7_asymmetric.csv")