"""
流代数沉默失谐探测 —— 基于 TeNPy 内置 SpinChain 模型
完全避开自定义模型，绝对可靠
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tenpy.models.spins import SpinChain
from tenpy.networks.mps import MPS
from tenpy.algorithms import dmrg

def run_scan(L=6, hz_values=None, chi_max=100):
    if hz_values is None:
        hz_values = np.linspace(0.0, 3.0, 13)
    
    gaps, coarse_vals, fine_vals = [], [], []
    print(f"\n=== 流代数沉默失谐探测 (SpinChain, L={L}) ===")
    
    for hz in hz_values:
        M = SpinChain(dict(L=L, Jx=1.0, Jy=1.0, Jz=1.0, hz=hz, 
                           bc_MPS='finite', conserve='Sz'))
        init = ['up', 'down'] * (L // 2)
        if L % 2 == 1: init.append('up')
        psi = MPS.from_product_state(M.lat.mps_sites(), init, bc='finite')
        dmrg_params = {'mixer': True, 'chi_max': chi_max, 'max_sweeps': 50, 'verbose': 0}
        
        eng = dmrg.run(psi, M, dmrg_params)
        E0 = eng['E']
        
        init_ex = init.copy()
        center = L // 2
        init_ex[center] = 'down' if init[center] == 'up' else 'up'
        psi_ex = MPS.from_product_state(M.lat.mps_sites(), init_ex, bc='finite')
        eng_ex = dmrg.run(psi_ex, M, dmrg_params)
        E1 = eng_ex['E']
        gap = E1 - E0

        Sz = psi.expectation_value('Sz')
        coarse = np.mean(np.abs(Sz))
        corrs = []
        for i in range(L - 1):
            corr = psi.correlation_function('Sz', 'Sz', [i], [i+1])
            corrs.append(corr[0])
        fine = np.std(corrs) if corrs else 0.0
        
        gaps.append(gap); coarse_vals.append(coarse); fine_vals.append(fine)
        print(f"hz={hz:.2f}: gap={gap:.6f}, coarse={coarse:.4f}, fine={fine:.4f}")
    
    return np.array(hz_values), np.array(gaps), np.array(coarse_vals), np.array(fine_vals)

if __name__ == "__main__":
    L = 6
    hz_values = np.linspace(0.0, 3.0, 13)
    hz_vals, gaps, coarse, fine = run_scan(L, hz_values, chi_max=100)
    
    np.savetxt('current_algebra_scan.csv', 
                np.column_stack((hz_vals, gaps, coarse, fine)), 
                header='hz,gap,coarse,fine', delimiter=',')
    
    fig, ax1 = plt.subplots(figsize=(10,6))
    ax1.plot(hz_vals, coarse, 'o-', label='Default diagnosis (coarse)')
    ax2 = ax1.twinx()
    ax2.plot(hz_vals, fine, 's-', color='red', label='Enhanced diagnosis (fine)')
    ax1.set_xlabel('hz (Zeeman field)')
    ax1.set_ylabel('Default metric'); ax2.set_ylabel('Enhanced metric')
    ax1.legend(loc='upper left'); ax2.legend(loc='upper right')
    plt.title(f'Silent Discordance in SpinChain (L={L})')
    plt.tight_layout()
    plt.savefig('current_algebra_scan.png')
    print("数据已保存至 current_algebra_scan.csv")