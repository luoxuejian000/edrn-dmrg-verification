"""
通用命运节点定位 —— 任意关系图
输入：边列表（任意图）
输出：命运节点、命运节点簇、远距离缘分关联
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh

# =============================================
# 用户输入：关系图边列表（在此修改）
# =============================================
# 示例：链式图 N=12
# EDGES = [(i, i+1) for i in range(11)]

# 示例：Sierpinski 分形图 N=15
EDGES = [
    (0,1),(0,2),(1,2),
    (1,3),(1,4),(3,4),
    (2,5),(2,6),(5,6),
    (0,7),(0,8),(7,8),
    (3,9),(3,10),(9,10),
    (4,11),(4,12),(11,12),
    (5,13),(5,14),(13,14)
]

# 也可以换成小世界图、随机图、星形图、环形图……
# 你只需要把边列表替换成你自己的图

# =============================================
# 遍历基矢法构建稀疏哈密顿量（内存安全）
# =============================================
def build_hamiltonian_sparse(edges, s=1.0):
    # 自动识别节点数
    all_nodes = set()
    for i, j in edges:
        all_nodes.add(i)
        all_nodes.add(j)
    N = max(all_nodes) + 1
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    
    for i, j in edges:
        J = s
        for state in range(dim):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            flipped = state ^ (1 << i) ^ (1 << j)
            H[state, flipped] += J
            if bit_i == bit_j:
                H[state, state] += J
            else:
                H[state, state] -= J
    
    return H.tocsc(), N


def get_ground_state(edges, s=1.0):
    H, N = build_hamiltonian_sparse(edges, s)
    energies, states = eigsh(H, k=2, which='SA')
    return states[:, 0], N


def compute_all_pair_correlations(edges, gs, N):
    """计算所有节点对的自旋关联 <σz_i σz_j>，使用位操作避免kron"""
    correlations = []
    dim = 2**N
    for i in range(N):
        for j in range(i+1, N):
            corr = 0.0
            for state in range(dim):
                bit_i = (state >> i) & 1
                bit_j = (state >> j) & 1
                sign = 1.0 if (bit_i == bit_j) else -1.0
                corr += np.abs(gs[state])**2 * sign
            correlations.append((i, j, corr))
    return correlations


def compute_spin_expectations(edges, gs, N):
    """计算每个节点的自旋期望值 <σz_i>，使用位操作避免kron"""
    spins = []
    dim = 2**N
    for i in range(N):
        spin = 0.0
        for state in range(dim):
            bit_i = (state >> i) & 1
            spin_val = 1.0 if bit_i == 0 else -1.0
            spin += np.abs(gs[state])**2 * spin_val
        spins.append(spin)
    return np.array(spins)


if __name__ == "__main__":
    edges = EDGES
    s = 1.0
    gs, N = get_ground_state(edges, s)
    
    print(f"=== 通用命运节点定位 ===")
    print(f"节点数: {N}, 边数: {len(edges)}, s={s:.2f}\n")
    
    correlations = compute_all_pair_correlations(edges, gs, N)
    correlations.sort(key=lambda x: abs(x[2]), reverse=True)
    
    # 构建边的集合，用于判断是否为直接边
    edge_set = set()
    for i, j in edges:
        edge_set.add((min(i,j), max(i,j)))
    
    print("--- 关联最强的前15对节点 ---")
    count = 0
    for i, j, corr in correlations:
        if count >= 15:
            break
        is_direct = (min(i,j), max(i,j)) in edge_set
        label = "直接边" if is_direct else "远距离"
        print(f"  {count+1}: ({i}, {j}) -> {corr:.6f}  [{label}]")
        count += 1
    
    # 专门列出远距离关联（非直接边）中最强的5对
    far_corrs = [(i, j, c) for i, j, c in correlations if (min(i,j), max(i,j)) not in edge_set]
    print("\n--- 远距离关联（非直接边）最强的5对 ---")
    for idx, (i, j, c) in enumerate(far_corrs[:5]):
        print(f"  {idx+1}: ({i}, {j}) -> {c:.6f}")
    
    spins = compute_spin_expectations(edges, gs, N)
    print("\n--- 节点自旋期望值 <σz> ---")
    for i, spin in enumerate(spins):
        print(f"  节点{i}: {spin:.6f}")
    
    # 命运节点簇：自旋期望值绝对值最大的3个节点
    sorted_spins = sorted([(i, abs(spins[i])) for i in range(N)], key=lambda x: x[1], reverse=True)
    top3 = [i for i, _ in sorted_spins[:3]]
    print(f"\n--- 命运节点簇（最特殊的3个节点） ---")
    print(f"  {top3}")
    
    # 保存数据
    with open('universal_destiny_nodes_results.csv', 'w') as f:
        f.write("node_i,node_j,correlation,is_direct\n")
        for i, j, c in correlations:
            is_direct = 1 if (min(i,j), max(i,j)) in edge_set else 0
            f.write(f"{i},{j},{c:.6f},{is_direct}\n")
    print("\n完整数据已保存至 universal_destiny_nodes_results.csv")
    
    # 热图
    corr_matrix = np.zeros((N, N))
    for i, j, c in correlations:
        corr_matrix[i, j] = c
        corr_matrix[j, i] = c
    
    fig, ax = plt.subplots(figsize=(10, 8))
    im = ax.imshow(corr_matrix, cmap='RdBu_r', vmin=-0.6, vmax=0.6)
    ax.set_xticks(range(N))
    ax.set_yticks(range(N))
    ax.set_xlabel('Node j')
    ax.set_ylabel('Node i')
    ax.set_title(f'Spin Correlation Matrix (N={N})')
    plt.colorbar(im, ax=ax, label='<σz_i σz_j>')
    plt.tight_layout()
    plt.savefig('universal_destiny_nodes.png', dpi=150)
    print("\n热图已保存至 universal_destiny_nodes.png")
    print("Done.")