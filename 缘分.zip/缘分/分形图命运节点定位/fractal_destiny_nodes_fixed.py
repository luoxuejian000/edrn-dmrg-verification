"""
分形图命运节点定位 —— 遍历基矢法（内存安全）
在Sierpinski分形图（N=15）中，找出关系场中预存的"命运节点"
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh

# =============================================
# Sierpinski 分形图生成（N=15）
# =============================================
def sierpinski_graph():
    edges = [
        (0,1),(0,2),(1,2),
        (1,3),(1,4),(3,4),
        (2,5),(2,6),(5,6),
        (0,7),(0,8),(7,8),
        (3,9),(3,10),(9,10),
        (4,11),(4,12),(11,12),
        (5,13),(5,14),(13,14)
    ]
    return edges

# =============================================
# 遍历基矢法构建稀疏哈密顿量（内存安全）
# =============================================
def build_hamiltonian_sparse(edges, s=1.0):
    N = 15
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    
    # 预计算每个节点在计算基矢中的位操作
    for i, j in edges:
        J = s
        # 遍历所有计算基矢
        for state in range(dim):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            
            # XX + YY 项：翻转两个自旋（相当于自旋交换）
            flipped = state ^ (1 << i) ^ (1 << j)
            H[state, flipped] += J
            
            # ZZ 项：对角贡献
            # 对于Heisenberg，ZZ项是 σ^z_i σ^z_j
            # 如果两个自旋相同，贡献 +1；不同，贡献 -1
            if bit_i == bit_j:
                H[state, state] += J
            else:
                H[state, state] -= J
    
    return H.tocsc()


def get_ground_state(edges, s=1.0):
    H = build_hamiltonian_sparse(edges, s)
    energies, states = eigsh(H, k=2, which='SA')
    return states[:, 0]


def compute_all_pair_correlations(edges, gs):
    N = 15
    correlations = []
    for i in range(N):
        for j in range(i+1, N):
            corr = 0.0
            for state in range(2**N):
                bit_i = (state >> i) & 1
                bit_j = (state >> j) & 1
                sign = 1.0 if (bit_i == bit_j) else -1.0
                corr += np.abs(gs[state])**2 * sign
            correlations.append((i, j, corr))
    return correlations


def compute_spin_expectations(edges, gs):
    N = 15
    spins = []
    for i in range(N):
        spin = 0.0
        for state in range(2**N):
            bit_i = (state >> i) & 1
            spin_val = 1.0 if bit_i == 0 else -1.0
            spin += np.abs(gs[state])**2 * spin_val
        spins.append(spin)
    return np.array(spins)


if __name__ == "__main__":
    edges = sierpinski_graph()
    s = 1.0
    N = 15
    
    print(f"=== 分形图命运节点定位 (N={N}, s={s:.2f}) ===")
    print(f"边数: {len(edges)}，希尔伯特空间维度: {2**N}")
    print("正在计算基态...\n")
    
    gs = get_ground_state(edges, s)
    
    correlations = compute_all_pair_correlations(edges, gs)
    correlations.sort(key=lambda x: abs(x[2]), reverse=True)
    
    print("--- 关联最强的前15对节点 ---")
    for idx, (i, j, corr) in enumerate(correlations[:15]):
        print(f"  {idx+1}: ({i}, {j}) -> corr = {corr:.6f}")
    
    spins = compute_spin_expectations(edges, gs)
    print("\n--- 节点自旋期望值 <σz> ---")
    for i, spin in enumerate(spins):
        print(f"  节点{i}: {spin:.6f}")
    
    max_spin_idx = np.argmax(np.abs(spins))
    print(f"\n--- 最特殊节点 ---")
    print(f"  节点{max_spin_idx}: 自旋期望值 {spins[max_spin_idx]:.6f}")
    
    # 找节点簇：自旋期望值绝对值最大的3个节点
    sorted_spins = sorted([(i, abs(spins[i])) for i in range(N)], key=lambda x: x[1], reverse=True)
    top3 = [i for i, _ in sorted_spins[:3]]
    print(f"\n--- 最特殊的3个节点（命运节点簇候选） ---")
    print(f"  {top3}")
    
    # 找关联最强的10个节点对，看它们覆盖哪些节点
    top_nodes = set()
    for _, (i, j, _) in zip(range(10), correlations[:10]):
        top_nodes.add(i)
        top_nodes.add(j)
    print(f"\n--- 关联最强前10对覆盖的节点 ---")
    print(f"  {sorted(top_nodes)}")
    
    # 保存数据
    with open('fractal_destiny_nodes_results.csv', 'w') as f:
        f.write("node_i,node_j,correlation\n")
        for i, j, corr in correlations:
            f.write(f"{i},{j},{corr:.6f}\n")
    print("\n完整数据已保存至 fractal_destiny_nodes_results.csv")
    
    # 可视化
    corr_matrix = np.zeros((N, N))
    for i, j, corr in correlations:
        corr_matrix[i, j] = corr
        corr_matrix[j, i] = corr
    
    fig, ax = plt.subplots(figsize=(10, 8))
    im = ax.imshow(corr_matrix, cmap='RdBu_r', vmin=-0.6, vmax=0.6)
    ax.set_xticks(range(N))
    ax.set_yticks(range(N))
    ax.set_xlabel('Node j')
    ax.set_ylabel('Node i')
    ax.set_title(f'Sierpinski Fractal (N={N}) - Spin Correlation Matrix')
    plt.colorbar(im, ax=ax, label='<σz_i σz_j>')
    plt.tight_layout()
    plt.savefig('fractal_destiny_nodes.png', dpi=150)
    print("\n热图已保存至 fractal_destiny_nodes.png")
    print("Done.")