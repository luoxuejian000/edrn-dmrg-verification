"""
分形图命运节点定位 —— 金箍棒 ED 版
在Sierpinski分形图（N=15）中，找出关系场中预存的"命运节点"
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh

# =============================================
# Sierpinski 分形图生成（N=15）
# =============================================
def sierpinski_graph():
    """生成15节点的Sierpinski分形图（level=2）"""
    edges = [
        (0,1),(0,2),(1,2),  # 大三角形
        (1,3),(1,4),(3,4),  # 左上子三角形
        (2,5),(2,6),(5,6),  # 右上子三角形
        (0,7),(0,8),(7,8),  # 左下子三角形
        (3,9),(3,10),(9,10),(4,11),(4,12),(11,12),(5,13),(5,14),(13,14)  # 下一层
    ]
    return edges

# =============================================
# 哈密顿量构建（Heisenberg）
# =============================================
def build_hamiltonian(edges, s=1.0):
    N = 15
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    
    def to_full(op, site):
        ops = [I2] * N
        ops[site] = op
        result = ops[0]
        for k in range(1, N):
            result = np.kron(result, ops[k])
        return result
    
    for i, j in edges:
        J = s
        H += J * (to_full(sx, i) @ to_full(sx, j)).real
        H += J * (to_full(sy, i) @ to_full(sy, j)).real
        H += J * (to_full(sz, i) @ to_full(sz, j)).real
    
    return H.tocsc()


def get_ground_state(edges, s=1.0):
    H = build_hamiltonian(edges, s)
    energies, states = eigsh(H, k=2, which='SA')
    return states[:, 0]


def compute_all_pair_correlations(edges, gs):
    """计算所有节点对的自旋关联 <σz_i σz_j>"""
    N = 15
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    correlations = []
    for i in range(N):
        for j in range(i+1, N):
            ops = [I2] * N
            ops[i] = sz
            ops[j] = sz
            op_full = ops[0]
            for k in range(1, N):
                op_full = np.kron(op_full, ops[k])
            corr = np.real(gs.conj().T @ op_full @ gs)
            correlations.append((i, j, corr))
    return correlations


def compute_spin_expectations(edges, gs):
    """计算每个节点的自旋期望值 <σz_i>"""
    N = 15
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    spins = []
    for i in range(N):
        ops = [I2] * N
        ops[i] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        spin = np.real(gs.conj().T @ op_full @ gs)
        spins.append(spin)
    return np.array(spins)

if __name__ == "__main__":
    edges = sierpinski_graph()
    s = 1.0
    N = 15
    
    print(f"=== 分形图命运节点定位 (N={N}, s={s:.2f}) ===")
    print("测量所有节点对的自旋关联，找出关系场中预存的特殊节点对\n")
    
    gs = get_ground_state(edges, s)
    
    correlations = compute_all_pair_correlations(edges, gs)
    correlations.sort(key=lambda x: abs(x[2]), reverse=True)
    
    print("--- 关联最强的前10对节点 ---")
    for idx, (i, j, corr) in enumerate(correlations[:10]):
        print(f"  {idx+1}: ({i}, {j}) -> corr = {corr:.6f}")
    
    spins = compute_spin_expectations(edges, gs)
    print("\n--- 节点自旋期望值 <σz> ---")
    for i, spin in enumerate(spins):
        print(f"  节点{i}: {spin:.6f}")
    
    max_spin_idx = np.argmax(np.abs(spins))
    print(f"\n--- 最特殊节点 ---")
    print(f"  节点{max_spin_idx}: 自旋期望值 {spins[max_spin_idx]:.6f}")
    print(f"  与它关联最强的节点对: {correlations[0][0]} 和 {correlations[0][1]}")
    
    with open('fractal_destiny_nodes_results.csv', 'w') as f:
        f.write("node_i,node_j,correlation\n")
        for i, j, corr in correlations:
            f.write(f"{i},{j},{corr:.6f}\n")
    print("\n完整数据已保存至 fractal_destiny_nodes_results.csv")
    
    # 可视化
    corr_matrix = np.zeros((N, N))
    for i, j, corr in correlations:
        corr_matrix[i, j] = corr
        corr_matrix[j, i] = corr
    
    fig, ax = plt.subplots(figsize=(10, 8))
    im = ax.imshow(corr_matrix, cmap='RdBu_r', vmin=-0.6, vmax=0.6)
    ax.set_xticks(range(N))
    ax.set_yticks(range(N))
    ax.set_xlabel('Node j')
    ax.set_ylabel('Node i')
    ax.set_title(f'Sierpinski Fractal (N={N}) - Spin Correlation Matrix')
    plt.colorbar(im, ax=ax, label='<σz_i σz_j>')
    plt.tight_layout()
    plt.savefig('fractal_destiny_nodes.png', dpi=150)
    print("\n热图已保存至 fractal_destiny_nodes.png")
    print("Done.")