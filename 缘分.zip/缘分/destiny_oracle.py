"""
命运预言实验 —— 金箍棒 ED 版
基于"时间静止、关系场预存"原理的算命模拟
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh

# =============================================
# 哈密顿量构建（泡利矩阵版，标准Heisenberg）
# =============================================
def build_hamiltonian(N, contradiction_edge, contradiction_strength):
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    
    def to_full(op, site):
        ops = [I2] * N
        ops[site] = op
        result = ops[0]
        for k in range(1, N):
            result = np.kron(result, ops[k])
        return result
    
    for i in range(N-1):
        if (i, i+1) == contradiction_edge or (i+1, i) == contradiction_edge:
            J = contradiction_strength
        else:
            J = 1.0
        j = i + 1
        H += J * (to_full(sx, i) @ to_full(sx, j)).real
        H += J * (to_full(sy, i) @ to_full(sy, j)).real
        H += J * (to_full(sz, i) @ to_full(sz, j)).real
    
    return H.tocsc()


def compute_fine(N, contradiction_edge, s):
    """用ED计算给定s下的精细诊断值"""
    H = build_hamiltonian(N, contradiction_edge, s)
    energies, states = eigsh(H, k=2, which='SA')
    gs = states[:, 0]
    
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    corrs = []
    for i in range(N-1):
        ops = [I2] * N
        ops[i] = sz
        ops[i+1] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        corr = np.real(gs.conj().T @ op_full @ gs)
        corrs.append(corr)
    fine = np.std(corrs) if corrs else 0.0
    return fine


def generate_life_path(start_s=1.5, steps=20, step_range=0.2, s_min=0.0, s_max=3.0):
    """随机生成一条人生路径：s值随机游走，限制在[s_min, s_max]内"""
    path = [start_s]
    for _ in range(steps - 1):
        delta = np.random.uniform(-step_range, step_range)
        next_s = np.clip(path[-1] + delta, s_min, s_max)
        path.append(next_s)
    return np.array(path)