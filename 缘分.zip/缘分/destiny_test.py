"""
缘分诊断 —— 金箍棒 3.0 DMRG
扫描缘分强度 λ，测量两个命运节点之间的关联
检验：缘分是否是关系场中预存的连接？
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tenpy.models.model import CouplingMPOModel
from tenpy.models.lattice import Chain
from tenpy.networks.site import SpinHalfSite
from tenpy.networks.mps import MPS
from tenpy.algorithms import dmrg

class DestinyModel(CouplingMPOModel):
    """链式Heisenberg模型，带缘分强度 λ 作用于中心键"""
    def __init__(self, model_params):
        L = model_params.get('L', 12)
        self.destiny_strength = model_params.get('destiny_strength', 1.0)
        lat = Chain(L, SpinHalfSite(conserve='Sz'), bc='open')
        model_params['lattice'] = lat
        CouplingMPOModel.__init__(self, model_params)

    def init_terms(self, model_params=None):
        if model_params is None:
            model_params = {}
        L = self.lat.N_sites
        center = L // 2 - 1
        J_arr = np.ones(L - 1)
        J_arr[center] = self.destiny_strength
        # XX+YY 项 (非对角)
        self.add_coupling(J_arr * 0.5, 0, 'Sp', 0, 'Sm', dx=[1], plus_hc=True)
        # ZZ 项 (对角)
        self.add_coupling(J_arr, 0, 'Sz', 0, 'Sz', dx=[1])


def compute_diagnostics(L, destiny_strength, chi_max=100):
    """用DMRG计算基态，返回能隙、默认诊断、精细诊断和命运关联"""
    M = DestinyModel(dict(
        L=L, destiny_strength=destiny_strength,
        bc_MPS='finite', conserve='Sz'
    ))
    init = ['up', 'down'] * (L // 2)
    if L % 2 == 1: init.append('up')
    psi = MPS.from_product_state(M.lat.mps_sites(), init, bc='finite')
    dmrg_params = {'mixer': True, 'chi_max': chi_max, 'max_sweeps': 50, 'verbose': 0}
    eng = dmrg.run(psi, M, dmrg_params)
    E0 = float(eng['E'])
    
    init_ex = init.copy()
    center = L // 2
    init_ex[center] = 'down' if init_ex[center] == 'up' else 'up'
    psi_ex = MPS.from_product_state(M.lat.mps_sites(), init_ex, bc='finite')
    eng_ex = dmrg.run(psi_ex, M, dmrg_params)
    E1 = float(eng_ex['E'])
    gap = float(E1 - E0)

    Sz = psi.expectation_value('Sz')
    coarse = float(np.mean(np.abs(Sz)))
    
    corrs = []
    for i in range(L - 1):
        corr = psi.correlation_function('Sz', 'Sz', [i], [i+1])
        corrs.append(corr[0, 0])
    fine = float(np.std(corrs)) if corrs else 0.0
    
    # 命运关联：节点0与节点L-1的自旋关联
    destiny_corr = float(psi.correlation_function('Sz', 'Sz', [0], [L-1])[0, 0])
    
    return gap, coarse, fine, destiny_corr

if __name__ == "__main__":
    L = 12
    lambda_vals = np.linspace(0.0, 5.0, 21)
    
    gaps, coarse_vals, fine_vals, destiny_corrs = [], [], [], []
    
    print(f"=== 缘分诊断 (L={L}) ===")
    print("扫描缘分强度 λ，测量命运节点(0,{})之间的关联\n".format(L-1))
    
    for lam in lambda_vals:
        gap, coarse, fine, destiny = compute_diagnostics(L, lam, chi_max=100)
        gaps.append(gap)
        coarse_vals.append(coarse)
        fine_vals.append(fine)
        destiny_corrs.append(destiny)
        print(f"λ={lam:.2f}: gap={gap:.6f}, coarse={coarse:.4f}, fine={fine:.6f}, destiny={destiny:.6f}")
    
    # 保存数据
    np.savetxt('destiny_results.csv', 
               np.column_stack((lambda_vals, gaps, coarse_vals, fine_vals, destiny_corrs)), 
               header='lambda,gap,coarse,fine,destiny_corr', delimiter=',')
    
    # 诊断图
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    
    axes[0].plot(lambda_vals, coarse_vals, 'o-', color='#1f77b4')
    axes[0].set_xlabel('Destiny strength λ'); axes[0].set_ylabel('Coarse diagnosis')
    axes[0].set_title('Default Diagnosis (Blind?)')
    axes[0].grid(True, alpha=0.3)
    
    axes[1].plot(lambda_vals, fine_vals, 's-', color='#d62728')
    axes[1].set_xlabel('Destiny strength λ'); axes[1].set_ylabel('Fine diagnosis')
    axes[1].set_title('Enhanced Diagnosis')
    axes[1].grid(True, alpha=0.3)
    
    axes[2].plot(lambda_vals, destiny_corrs, '^-', color='#2ca02c', markersize=8)
    axes[2].set_xlabel('Destiny strength λ'); axes[2].set_ylabel('Correlation <σ^z_0 σ^z_{L-1}>')
    axes[2].set_title(f'Destiny Correlation (nodes 0 and {L-1})')
    axes[2].grid(True, alpha=0.3)
    
    # 标注命运关联的峰值
    if len(destiny_corrs) > 2:
        peak_idx = np.argmax(np.abs(destiny_corrs))
        axes[2].annotate(f'Peak λ={lambda_vals[peak_idx]:.2f}',
                        (lambda_vals[peak_idx], destiny_corrs[peak_idx]),
                        textcoords="offset points", xytext=(0,10), ha='center',
                        fontweight='bold', color='red')
    
    plt.suptitle(f'Destiny Test: Are connections pre-wired in the relational field?')
    plt.tight_layout()
    plt.savefig('destiny_test.png', dpi=150)
    
    # 缘分报告
    print("\n=== 缘分诊断报告 ===")
    print(f"命运节点: 0 和 {L-1} (无直接连接)")
    
    # 检查是否有非单调行为
    abs_destiny = np.abs(destiny_corrs)
    if len(abs_destiny) > 2:
        peaks = []
        for i in range(1, len(abs_destiny)-1):
            if abs_destiny[i] > abs_destiny[i-1] and abs_destiny[i] > abs_destiny[i+1]:
                peaks.append(i)
        if peaks:
            print(f"缘分关联峰值位置: λ = {lambda_vals[peaks]}")
            print(f"峰值强度: {abs_destiny[peaks]}")
        else:
            print("未发现缘分关联的非单调峰值。")
    
    # 检查默认诊断是否盲视
    coarse_range = np.max(coarse_vals) - np.min(coarse_vals)
    if coarse_range < 0.01:
        print(f"默认诊断基本盲视（波动范围 {coarse_range:.6f}）")
    else:
        print(f"默认诊断对缘分强度有响应（波动范围 {coarse_range:.4f}）")
    
    print("\nDone. 数据已保存。")