"""
命运节点定位 —— 金箍棒 ED 版
在固定关系结构中，找出关系场中预存的"命运节点"
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh

# =============================================
# 哈密顿量构建（链式 Heisenberg，固定s=1.0）
# =============================================
def build_hamiltonian(N, s=1.0):
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    
    def to_full(op, site):
        ops = [I2] * N
        ops[site] = op
        result = ops[0]
        for k in range(1, N):
            result = np.kron(result, ops[k])
        return result
    
    for i in range(N-1):
        J = s
        j = i + 1
        H += J * (to_full(sx, i) @ to_full(sx, j)).real
        H += J * (to_full(sy, i) @ to_full(sy, j)).real
        H += J * (to_full(sz, i) @ to_full(sz, j)).real
    
    return H.tocsc()


def get_ground_state(N, s=1.0):
    """计算基态波函数"""
    H = build_hamiltonian(N, s)
    energies, states = eigsh(H, k=2, which='SA')
    gs = states[:, 0]
    return gs


def compute_all_pair_correlations(N, gs):
    """计算所有节点对的自旋关联 <σz_i σz_j>"""
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    
    correlations = []
    for i in range(N):
        for j in range(i+1, N):
            ops = [I2] * N
            ops[i] = sz
            ops[j] = sz
            op_full = ops[0]
            for k in range(1, N):
                op_full = np.kron(op_full, ops[k])
            corr = np.real(gs.conj().T @ op_full @ gs)
            correlations.append((i, j, corr))
    return correlations


def compute_spin_expectations(N, gs):
    """计算每个节点的自旋期望值 <σz_i>"""
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    
    spins = []
    for i in range(N):
        ops = [I2] * N
        ops[i] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        spin = np.real(gs.conj().T @ op_full @ gs)
        spins.append(spin)
    return np.array(spins)


if __name__ == "__main__":
    N = 12
    s = 1.0
    
    print(f"=== 命运节点定位 (N={N}, s={s:.2f}) ===")
    print("测量所有节点对的自旋关联，找出关系场中预存的特殊节点对\n")
    
    gs = get_ground_state(N, s)
    
    # 1. 所有节点对关联
    correlations = compute_all_pair_correlations(N, gs)
    correlations.sort(key=lambda x: abs(x[2]), reverse=True)
    
    print("--- 关联最强的前10对节点 ---")
    for idx, (i, j, corr) in enumerate(correlations[:10]):
        print(f"  {idx+1}: ({i}, {j}) -> corr = {corr:.6f}")
    
    # 2. 节点自身的自旋期望值
    spins = compute_spin_expectations(N, gs)
    print("\n--- 节点自旋期望值 <σz> ---")
    for i, spin in enumerate(spins):
        print(f"  节点{i}: {spin:.6f}")
    
    # 3. 识别"特殊节点"：自旋期望值绝对值最大的节点
    max_spin_idx = np.argmax(np.abs(spins))
    print(f"\n--- 最特殊节点 ---")
    print(f"  节点{max_spin_idx}: 自旋期望值 {spins[max_spin_idx]:.6f}")
    print(f"  与它关联最强的节点对: {correlations[0][0]} 和 {correlations[0][1]}")
    
    # 4. 保存完整数据
    with open('destiny_nodes_results.csv', 'w') as f:
        f.write("node_i,node_j,correlation\n")
        for i, j, corr in correlations:
            f.write(f"{i},{j},{corr:.6f}\n")
    print("\n完整数据已保存至 destiny_nodes_results.csv")
    
    # 5. 可视化：关联矩阵热图
    corr_matrix = np.zeros((N, N))
    for i, j, corr in correlations:
        corr_matrix[i, j] = corr
        corr_matrix[j, i] = corr
    
    fig, ax = plt.subplots(figsize=(8, 6))
    im = ax.imshow(corr_matrix, cmap='RdBu_r', vmin=-0.3, vmax=0.3)
    ax.set_xticks(range(N))
    ax.set_yticks(range(N))
    ax.set_xlabel('Node j')
    ax.set_ylabel('Node i')
    ax.set_title(f'Spin Correlation Matrix (N={N}, s={s:.2f})')
    plt.colorbar(im, ax=ax, label='<σz_i σz_j>')
    plt.tight_layout()
    plt.savefig('destiny_nodes.png', dpi=150)
    
    print("\n热图已保存至 destiny_nodes.png")
    print("Done.")