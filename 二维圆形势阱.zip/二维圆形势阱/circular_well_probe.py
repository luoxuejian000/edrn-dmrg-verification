"""
二维圆形势阱沉默失谐诊断
龚明教授：指数函数就是虚宗量的三角函数——同一个关系结构的不同显现。
检验：势阱几何约束的改变，是否触发关系场的沉默失谐响应？
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh

def build_circular_well(Nx, Ny, V0, r0, center_x, center_y, perturbation_strength):
    """
    构建二维有限深圆形势阱的哈密顿量。
    势阱形状：V(r) = -V0 (r < r0), 0 (r >= r0)
    在势阱边界附近施加扰动：边界上某些格点的势能乘以perturbation_strength。
    """
    N = Nx * Ny
    dim = N  # 单粒子问题，维度 = Nx*Ny
    H = lil_matrix((dim, dim), dtype=float)
    
    for ix in range(Nx):
        for iy in range(Ny):
            idx = ix * Ny + iy
            r = np.sqrt((ix - center_x)**2 + (iy - center_y)**2)
            
            # 势能项
            if r < r0:
                V = -V0
            else:
                V = 0.0
            
            # 在势阱边界附近施加扰动
            if abs(r - r0) < 0.5:
                V *= perturbation_strength
            
            H[idx, idx] = V
            
            # 动能项（最近邻hopping）
            if ix > 0:
                H[idx, (ix-1)*Ny + iy] = -1.0  # 向左
            if ix < Nx - 1:
                H[idx, (ix+1)*Ny + iy] = -1.0  # 向右
            if iy > 0:
                H[idx, ix*Ny + (iy-1)] = -1.0  # 向下
            if iy < Ny - 1:
                H[idx, ix*Ny + (iy+1)] = -1.0  # 向上
    
    return H.tocsc()


def compute_diagnostics(Nx, Ny, V0, r0, center_x, center_y, perturbation_strength, num_eig=5):
    """用ED精确计算基态和第一激发态，返回能隙、默认诊断和精细诊断"""
    H = build_circular_well(Nx, Ny, V0, r0, center_x, center_y, perturbation_strength)
    N = Nx * Ny
    energies, states = eigsh(H, k=min(num_eig, N-1), which='SA')
    gap = energies[1] - energies[0] if len(energies) > 1 else np.nan
    gs = states[:, 0]
    
    # 默认诊断：平均粒子密度
    density = np.abs(gs)**2
    coarse = np.mean(density)
    
    # 精细诊断：密度分布的涨落（标准差）
    fine = np.std(density) if len(density) > 1 else 0.0
    
    return gap, coarse, fine


def scan_perturbation(Nx, Ny, V0, r0, center_x, center_y, perturbation_values, label):
    """扫描扰动强度，返回诊断数据"""
    gaps, coarse_vals, fine_vals = [], [], []
    print(f"\n=== {label} ===")
    for p in perturbation_values:
        gap, coarse, fine = compute_diagnostics(Nx, Ny, V0, r0, center_x, center_y, p)
        gaps.append(gap); coarse_vals.append(coarse); fine_vals.append(fine)
        print(f"pert={p:.3f}: gap={gap:.6f}, coarse={coarse:.4f}, fine={fine:.6f}")
    return np.array(perturbation_values), np.array(gaps), np.array(coarse_vals), np.array(fine_vals)


if __name__ == "__main__":
    Nx, Ny = 5, 5
    center_x, center_y = 2.0, 2.0
    
    # 实验一：固定势阱半径r0=1.5，扫描边界扰动强度（检验沉默失谐）
    V0 = 2.0
    r0 = 1.5
    perturbation_values = np.linspace(0.5, 1.5, 13)
    p1, g1, c1, f1 = scan_perturbation(Nx, Ny, V0, r0, center_x, center_y, perturbation_values, "基准扫描 (r0=1.5)")
    
    # 实验二：不同势阱半径的对比
    r0_values = [1.0, 1.5, 2.0]
    all_fine = []
    for r0_val in r0_values:
        _, _, _, f = scan_perturbation(Nx, Ny, V0, r0_val, center_x, center_y, perturbation_values, f"对比扫描 (r0={r0_val})")
        all_fine.append(f)
    
    # 保存数据
    np.savetxt('circular_well_benchmark.csv',
               np.column_stack((p1, g1, c1, f1)),
               header='perturbation,gap,coarse,fine', delimiter=',')
    
    # 对比图
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
    
    ax1.plot(p1, c1, 'o-', label='Coarse', color='#1f77b4', lw=2)
    ax1.set_xlabel('Boundary perturbation'); ax1.set_ylabel('Coarse diagnosis')
    ax1.set_title('Default Diagnosis: Boundary Response')
    ax1.grid(True, alpha=0.3)
    
    ax2.plot(p1, f1, 'o-', label=f'r0={r0}', color='#d62728', lw=2)
    for idx, r0_val in enumerate(r0_values):
        ax2.plot(perturbation_values, all_fine[idx], 's--', label=f'r0={r0_val}', alpha=0.7)
    ax2.set_xlabel('Boundary perturbation'); ax2.set_ylabel('Fine diagnosis')
    ax2.set_title('Enhanced Diagnosis: Boundary Response vs Radius')
    ax2.legend(); ax2.grid(True, alpha=0.3)
    
    plt.suptitle('Circular Well Probe (Nx=Ny=5, V0=2.0)')
    plt.tight_layout()
    plt.savefig('circular_well_probe.png', dpi=150)
    
    print("\nDone. 数据已保存。")
