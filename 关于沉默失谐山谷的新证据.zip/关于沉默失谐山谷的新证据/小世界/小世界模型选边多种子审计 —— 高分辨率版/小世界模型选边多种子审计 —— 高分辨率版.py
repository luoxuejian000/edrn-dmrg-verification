"""
小世界模型选边多种子审计 —— 高分辨率版
针对特定矛盾边，在谷附近进行0.001步长、5种子的精细扫描
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh
import networkx as nx

def generate_small_world(N=10, k=4, p=0.1, seed=42):
    G = nx.watts_strogatz_graph(N, k, p, seed=seed)
    edges = list(G.edges())
    return edges, G

def graph_to_hamiltonian(N, edges, contradiction_edge, s):
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)

    def to_full(op, site):
        ops = [I2] * N
        ops[site] = op
        result = ops[0]
        for k in range(1, N):
            result = np.kron(result, ops[k])
        return result

    for (i, j) in edges:
        w = s if (i,j)==contradiction_edge or (j,i)==contradiction_edge else 1.0
        H += w * (to_full(sx, i) @ to_full(sx, j)).real
        H += w * (to_full(sy, i) @ to_full(sy, j)).real
        H += w * (to_full(sz, i) @ to_full(sz, j)).real
    return H.tocsc()

def diagnose(N, edges, contradiction_edge, s, num_eig=3, seed=None):
    H = graph_to_hamiltonian(N, edges, contradiction_edge, s)
    v0 = None
    if seed is not None:
        rng = np.random.default_rng(seed)
        v0 = rng.random(2**N)
    energies, states = eigsh(H, k=min(num_eig, 2**N-1), which='SA', v0=v0)
    E0 = energies[0]
    gap = energies[1] - energies[0] if len(energies) > 1 else np.nan
    gs = states[:, 0]

    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    mag = 0.0
    for i in range(N):
        ops = [I2] * N
        ops[i] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        mag += np.real(gs.conj().T @ op_full @ gs)
    coarse = abs(mag / N)

    corrs = []
    for (i, j) in edges:
        ops = [I2] * N
        ops[i] = sz
        ops[j] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        corr = np.real(gs.conj().T @ op_full @ gs)
        corrs.append(corr)
    fine = np.std(corrs) if corrs else 0.0

    return coarse, fine, gap

def multi_seed_audit(N, edges, contradiction_edge, s_values, seeds):
    results = {seed: {'coarse': [], 'fine': [], 'gap': []} for seed in seeds}
    for seed in seeds:
        for s in s_values:
            coarse, fine, gap = diagnose(N, edges, contradiction_edge, s,
                                         num_eig=3, seed=seed)
            results[seed]['coarse'].append(coarse)
            results[seed]['fine'].append(fine)
            results[seed]['gap'].append(gap)
    return results

if __name__ == "__main__":
    N = 10
    edges, G = generate_small_world(N, k=4, p=0.1, seed=42)

    # 从粗扫结果中选择3条代表边
    # 这里用户自行替换为粗扫筛选出的边
    selected_edges = [(0,1), (1,9), (1,4)]
    # 谷附近的扫描窗口（根据粗扫 valley_s 设定）
    scan_windows = {
        (0,1): (1.30, 1.70),
        (1,9): (0.10, 0.50),
        (1,4): (1.05, 1.45),
    }

    seeds = [0, 1, 2, 3, 4]  # 5种子

    for edge in selected_edges:
        window = scan_windows[edge]
        s_values = np.arange(window[0], window[1] + 0.0005, 0.001)
        print(f"\n=== 多种子审计: 矛盾边 {edge}, s ∈ [{window[0]}, {window[1]}], 步长0.001, 5种子 ===")
        results = multi_seed_audit(N, edges, edge, s_values, seeds)

        # 保存每个种子
        for seed in seeds:
            np.savetxt(f'sw_edge{edge[0]}_{edge[1]}_seed{seed}.csv',
                       np.column_stack((s_values,
                                        results[seed]['coarse'],
                                        results[seed]['fine'],
                                        results[seed]['gap'])),
                       header='s,coarse,fine,gap', delimiter=',')

        # 多种子统计
        all_fine = np.array([results[seed]['fine'] for seed in seeds])
        mean_fine = np.mean(all_fine, axis=0)
        std_fine = np.std(all_fine, axis=0)

        # 找谷：最小值的均值和标准差
        min_idx = np.argmin(mean_fine)
        min_s = s_values[min_idx]
        min_val = mean_fine[min_idx]
        min_std = std_fine[min_idx]

        # 谷位置跨种子标准差
        seed_min_positions = []
        for seed in seeds:
            seed_idx = np.argmin(results[seed]['fine'])
            seed_min_positions.append(s_values[seed_idx])
        seed_min_positions = np.array(seed_min_positions)
        pos_std = np.std(seed_min_positions)

        print(f"谷位置: s={min_s:.3f}")
        print(f"谷位置跨种子标准差: {pos_std:.6f}")
        print(f"谷深: {min_val:.6f} ± {min_std:.6f}")

        # 保存均值
        np.savetxt(f'sw_edge{edge[0]}_{edge[1]}_mean.csv',
                   np.column_stack((s_values, mean_fine, std_fine)),
                   header='s,fine_mean,fine_std', delimiter=',')

        # 绘图
        fig, ax = plt.subplots(figsize=(10, 6))
        for seed in seeds:
            ax.plot(s_values, results[seed]['fine'], lw=0.5, alpha=0.5)
        ax.plot(s_values, mean_fine, color='red', lw=2, label='Mean')
        ax.fill_between(s_values, mean_fine - std_fine, mean_fine + std_fine,
                        alpha=0.3, color='red')
        ax.axvline(min_s, color='black', ls='--', label=f'Valley s={min_s:.3f}')
        ax.set_xlabel('Contradiction strength s')
        ax.set_ylabel('Enhanced diagnosis (fine)')
        ax.set_title(f'Multi-seed audit: edge {edge}, 5 seeds, 0.001 step')
        ax.legend()
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(f'sw_edge{edge[0]}_{edge[1]}_audit.png', dpi=150)
        plt.close()

    print("\n多种子审计完成。")