import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.sparse import lil_matrix, csc_matrix
from scipy.sparse.linalg import eigsh
import networkx as nx
import os, time


def generate_small_world(N=10, k=4, p=0.1, seed=42):
    G = nx.watts_strogatz_graph(N, k, p, seed=seed)
    edges = list(G.edges())
    return edges, G


def heisenberg_edge_operator(N, i, j):
    """Sparse operator for sigma_i·sigma_j = XX + YY + ZZ in computational basis."""
    dim = 1 << N
    rows = []
    cols = []
    data = []
    mask_i = 1 << (N - 1 - i)
    mask_j = 1 << (N - 1 - j)
    flip_mask = mask_i | mask_j
    for state in range(dim):
        bi = 1 if (state & mask_i) else 0
        bj = 1 if (state & mask_j) else 0
        # ZZ: +1 for equal bits, -1 for different bits
        rows.append(state)
        cols.append(state)
        data.append(1.0 if bi == bj else -1.0)
        # XX + YY: only flips anti-aligned spins, amplitude 2
        if bi != bj:
            rows.append(state ^ flip_mask)
            cols.append(state)
            data.append(2.0)
    return csc_matrix((data, (rows, cols)), shape=(dim, dim), dtype=float)


def precompute_edge_ops(N, edges):
    return {tuple(edge): heisenberg_edge_operator(N, edge[0], edge[1]) for edge in edges}


def canonical_edge(edge_ops, edge):
    e = tuple(edge)
    if e in edge_ops:
        return e
    er = (edge[1], edge[0])
    if er in edge_ops:
        return er
    raise KeyError(f"edge {edge} not found")


def diagnose_fast(N, edge_ops, H_base, contradiction_edge, s, num_eig=3, seed=None, tol=1e-8):
    e = canonical_edge(edge_ops, contradiction_edge)
    H = H_base + (s - 1.0) * edge_ops[e]
    v0 = None
    if seed is not None:
        rng = np.random.default_rng(seed)
        v0 = rng.random(1 << N)
    energies, states = eigsh(H, k=min(num_eig, (1 << N) - 1), which='SA', v0=v0, tol=tol)
    order = np.argsort(energies)
    energies = energies[order]
    states = states[:, order]
    gap = energies[1] - energies[0] if len(energies) > 1 else np.nan
    gs = states[:, 0]
    probs = np.abs(gs) ** 2

    dim = 1 << N
    states_idx = np.arange(dim)
    z = np.empty((N, dim), dtype=np.int8)
    for i in range(N):
        mask = 1 << (N - 1 - i)
        z[i] = np.where((states_idx & mask) == 0, 1, -1)

    mag_sites = z @ probs
    coarse = abs(np.sum(mag_sites) / N)

    corrs = []
    for i, j in edge_ops.keys():
        corrs.append(np.sum(z[i] * z[j] * probs))
    fine = float(np.std(corrs)) if corrs else 0.0
    return float(coarse), fine, float(gap)


def multi_seed_audit_fast(N, edge_ops, H_base, contradiction_edge, s_values, seeds, tol=1e-8):
    results = {seed: {'coarse': [], 'fine': [], 'gap': []} for seed in seeds}
    for seed in seeds:
        for s in s_values:
            coarse, fine, gap = diagnose_fast(N, edge_ops, H_base, contradiction_edge, s, num_eig=3, seed=seed, tol=tol)
            results[seed]['coarse'].append(coarse)
            results[seed]['fine'].append(fine)
            results[seed]['gap'].append(gap)
    return results

# Run the high-resolution multi-seed audit with an optimized sparse implementation.
N = 10
edges, G = generate_small_world(N, k=4, p=0.1, seed=42)
selected_edges = [(0, 1), (1, 9), (1, 4)]
scan_windows = {
    (0, 1): (1.30, 1.70),
    (1, 9): (0.10, 0.50),
    (1, 4): (1.05, 1.45),
}
seeds = [0, 1, 2, 3, 4]

edge_ops = precompute_edge_ops(N, edges)
H_base = sum(edge_ops.values())
summary_rows = []

start_all = time.time()
for edge in selected_edges:
    window = scan_windows[edge]
    s_values = np.round(np.arange(window[0], window[1] + 0.0005, 0.001), 3)
    print(f"\n=== 多种子审计: 矛盾边 {edge}, s ∈ [{window[0]}, {window[1]}], 步长0.001, 5种子 ===", flush=True)
    start_edge = time.time()
    results = multi_seed_audit_fast(N, edge_ops, H_base, edge, s_values, seeds)

    for seed in seeds:
        np.savetxt(
            f'sw_edge{edge[0]}_{edge[1]}_seed{seed}.csv',
            np.column_stack((s_values, results[seed]['coarse'], results[seed]['fine'], results[seed]['gap'])),
            header='s,coarse,fine,gap', delimiter=','
        )

    all_fine = np.array([results[seed]['fine'] for seed in seeds])
    mean_fine = np.mean(all_fine, axis=0)
    std_fine = np.std(all_fine, axis=0)

    min_idx = int(np.argmin(mean_fine))
    min_s = float(s_values[min_idx])
    min_val = float(mean_fine[min_idx])
    min_std = float(std_fine[min_idx])

    seed_min_positions = np.array([s_values[int(np.argmin(results[seed]['fine']))] for seed in seeds])
    pos_std = float(np.std(seed_min_positions))

    print(f"谷位置: s={min_s:.3f}", flush=True)
    print(f"谷位置跨种子标准差: {pos_std:.6f}", flush=True)
    print(f"谷深: {min_val:.6f} ± {min_std:.6f}", flush=True)
    print(f"耗时: {time.time() - start_edge:.1f} 秒", flush=True)

    np.savetxt(
        f'sw_edge{edge[0]}_{edge[1]}_mean.csv',
        np.column_stack((s_values, mean_fine, std_fine)),
        header='s,fine_mean,fine_std', delimiter=','
    )

    fig, ax = plt.subplots(figsize=(10, 6))
    for seed in seeds:
        ax.plot(s_values, results[seed]['fine'], lw=0.5, alpha=0.5)
    ax.plot(s_values, mean_fine, color='red', lw=2, label='Mean')
    ax.fill_between(s_values, mean_fine - std_fine, mean_fine + std_fine, alpha=0.3, color='red')
    ax.axvline(min_s, color='black', ls='--', label=f'Valley s={min_s:.3f}')
    ax.set_xlabel('Contradiction strength s')
    ax.set_ylabel('Enhanced diagnosis (fine)')
    ax.set_title(f'Multi-seed audit: edge {edge}, 5 seeds, 0.001 step')
    ax.legend()
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(f'sw_edge{edge[0]}_{edge[1]}_audit.png', dpi=150)
    plt.close()

    summary_rows.append({
        'edge': str(edge),
        'min_s': min_s,
        'valley_position_seed_std': pos_std,
        'valley_depth_mean': min_val,
        'valley_depth_seed_std': min_std,
        'n_s_values': len(s_values),
        'elapsed_sec': time.time() - start_edge,
    })

import pandas as pd
summary_df = pd.DataFrame(summary_rows)
summary_df.to_csv('sw_multi_seed_audit_summary.csv', index=False)
print("\n多种子审计完成。", flush=True)
print(f"总耗时: {time.time() - start_all:.1f} 秒", flush=True)
summary_df