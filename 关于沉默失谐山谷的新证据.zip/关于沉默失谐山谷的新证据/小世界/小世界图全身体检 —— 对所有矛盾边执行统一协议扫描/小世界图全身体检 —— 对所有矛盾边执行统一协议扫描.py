"""
小世界图全身体检 —— 对所有矛盾边执行统一协议扫描
N=10, k=4, p=0.1, seed=42
每条边: s从0到3, 步长0.01, 3种子
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh
import networkx as nx

# =============================================
# 公理一：小世界图生成
# =============================================
def generate_small_world(N=10, k=4, p=0.1, seed=42):
    G = nx.watts_strogatz_graph(N, k, p, seed=seed)
    edges = list(G.edges())
    return edges, G

# =============================================
# 哈密顿量编译（泡利矩阵版，标准海森堡）
# =============================================
def graph_to_hamiltonian(N, edges, contradiction_edge, s):
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)

    def to_full(op, site):
        ops = [I2] * N
        ops[site] = op
        result = ops[0]
        for k in range(1, N):
            result = np.kron(result, ops[k])
        return result

    for (i, j) in edges:
        w = s if (i,j)==contradiction_edge or (j,i)==contradiction_edge else 1.0
        H += w * (to_full(sx, i) @ to_full(sx, j)).real
        H += w * (to_full(sy, i) @ to_full(sy, j)).real
        H += w * (to_full(sz, i) @ to_full(sz, j)).real
    return H.tocsc()

# =============================================
# 诊断函数
# =============================================
def diagnose(N, edges, contradiction_edge, s, num_eig=3, seed=None):
    H = graph_to_hamiltonian(N, edges, contradiction_edge, s)
    v0 = None
    if seed is not None:
        rng = np.random.default_rng(seed)
        v0 = rng.random(2**N)
    energies, states = eigsh(H, k=min(num_eig, 2**N-1), which='SA', v0=v0)
    gap = energies[1] - energies[0] if len(energies) > 1 else np.nan
    gs = states[:, 0]

    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    mag = 0.0
    for i in range(N):
        ops = [I2] * N
        ops[i] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        mag += np.real(gs.conj().T @ op_full @ gs)
    coarse = abs(mag / N)

    corrs = []
    for (i, j) in edges:
        ops = [I2] * N
        ops[i] = sz
        ops[j] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        corr = np.real(gs.conj().T @ op_full @ gs)
        corrs.append(corr)
    fine = np.std(corrs) if corrs else 0.0

    return coarse, fine, gap

# =============================================
# 单条边的多种子扫描
# =============================================
def scan_single_edge(N, edges, contradiction_edge, s_values, seeds):
    results = {seed: {'coarse': [], 'fine': [], 'gap': []} for seed in seeds}
    for seed in seeds:
        for s in s_values:
            coarse, fine, gap = diagnose(N, edges, contradiction_edge, s,
                                         num_eig=3, seed=seed)
            results[seed]['coarse'].append(coarse)
            results[seed]['fine'].append(fine)
            results[seed]['gap'].append(gap)
    return results

# =============================================
# 主程序：对所有边执行统一体检
# =============================================
if __name__ == "__main__":
    N = 10
    k = 4
    p = 0.1
    seed = 42
    seeds_list = [0, 1, 2]

    edges, G = generate_small_world(N, k, p, seed)
    n_edges = len(edges)

    print(f"=== 小世界图全身体检 ===")
    print(f"N={N}, k={k}, p={p}, seed={seed}")
    print(f"总边数: {n_edges}")
    print(f"扫描协议: s从0到3, 步长0.01, 3种子\n")

    # 步长0.01，301个点
    s_values = np.arange(0.0, 3.01, 0.01)

    # 汇总表
    summary = []

    for edge_idx, (i, j) in enumerate(edges):
        contradiction_edge = (i, j)
        print(f"[边 {edge_idx+1}/{n_edges}] 矛盾边=({i},{j}) ... ", end='', flush=True)

        results = scan_single_edge(N, edges, contradiction_edge, s_values, seeds_list)

        # 计算多种子平均
        all_fine = np.array([results[s]['fine'] for s in seeds_list])
        all_coarse = np.array([results[s]['coarse'] for s in seeds_list])
        all_gap = np.array([results[s]['gap'] for s in seeds_list])

        mean_fine = np.mean(all_fine, axis=0)
        mean_coarse = np.mean(all_coarse, axis=0)
        mean_gap = np.mean(all_gap, axis=0)

        # 保存该边的数据
        np.savetxt(f'sw_edge_{i}_{j}.csv',
                   np.column_stack((s_values, mean_coarse, mean_fine, mean_gap)),
                   header='s,coarse_mean,fine_mean,gap_mean', delimiter=',')

        # 计算关键指标
        fine_range = np.max(mean_fine) - np.min(mean_fine)
        coarse_range = np.max(mean_coarse) - np.min(mean_coarse)
        valley_idx = np.argmin(mean_fine)
        valley_s = s_values[valley_idx]
        valley_depth = fine_range  # 极差即深度
        gap_at_valley = mean_gap[valley_idx]
        gap_min = np.min(mean_gap)
        gap_min_s = s_values[np.argmin(mean_gap)]

        summary.append({
            'edge': contradiction_edge,
            'fine_range': fine_range,
            'coarse_range': coarse_range,
            'valley_s': valley_s,
            'valley_depth': valley_depth,
            'gap_at_valley': gap_at_valley,
            'gap_min': gap_min,
            'gap_min_s': gap_min_s,
        })

        print(f"fine_range={fine_range:.6f}, coarse_range={coarse_range:.6f}, "
              f"valley_s={valley_s:.3f}, gap_at_valley={gap_at_valley:.4f}")

    # 保存汇总表
    summary_file = 'small_world_full_check_summary.csv'
    with open(summary_file, 'w') as f:
        f.write('edge_i,edge_j,fine_range,coarse_range,valley_s,valley_depth,gap_at_valley,gap_min,gap_min_s\n')
        for row in summary:
            f.write(f"{row['edge'][0]},{row['edge'][1]},{row['fine_range']:.6f},"
                    f"{row['coarse_range']:.6f},{row['valley_s']:.3f},"
                    f"{row['valley_depth']:.6f},{row['gap_at_valley']:.4f},"
                    f"{row['gap_min']:.4f},{row['gap_min_s']:.3f}\n")

    print(f"\n=== 全身体检汇总 ===")
    print(f"总边数: {n_edges}")
    print(f"边列表及关键指标:")

    # 统计
    n_with_valley = sum(1 for r in summary if r['fine_range'] > 0.05)
    n_blind_default = sum(1 for r in summary if r['coarse_range'] < 0.001)
    n_valley_with_gap = sum(1 for r in summary if r['fine_range'] > 0.05 and r['gap_at_valley'] > 0.01)

    for r in summary:
        print(f"  边({r['edge'][0]},{r['edge'][1]}): fine_range={r['fine_range']:.6f}, "
              f"coarse_range={r['coarse_range']:.6f}, valley_s={r['valley_s']:.3f}, "
              f"gap_at_valley={r['gap_at_valley']:.4f}")

    print(f"\n=== 统计 ===")
    print(f"有显著谷的边 (fine_range > 0.05): {n_with_valley}/{n_edges}")
    print(f"默认诊断盲视的边 (coarse_range < 0.001): {n_blind_default}/{n_edges}")
    print(f"谷在能隙非零处的边: {n_valley_with_gap}/{n_edges}")

    # 汇总图
    fig, ax = plt.subplots(figsize=(12, 6))
    edge_labels = [f"({r['edge'][0]},{r['edge'][1]})" for r in summary]
    fine_ranges = [r['fine_range'] for r in summary]
    coarse_ranges = [r['coarse_range'] for r in summary]

    x = np.arange(len(edge_labels))
    width = 0.35
    ax.bar(x - width/2, fine_ranges, width, label='Fine range', color='red', alpha=0.8)
    ax.bar(x + width/2, coarse_ranges, width, label='Coarse range', color='blue', alpha=0.8)
    ax.set_xticks(x)
    ax.set_xticklabels(edge_labels, rotation=45, ha='right')
    ax.set_xlabel('Contradiction edge')
    ax.set_ylabel('Diagnostic range')
    ax.set_title(f'Full Check: Diagnostic Ranges for Each Edge (N={N})')
    ax.legend()
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('small_world_full_check.png', dpi=150)
    print("\n汇总图已保存: small_world_full_check.png")