import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.sparse import coo_matrix, csc_matrix
from scipy.sparse.linalg import eigsh
import networkx as nx
import time

# =============================================
# 公理一：小世界图生成
# =============================================
def generate_small_world(N=10, k=4, p=0.1, seed=42):
    G = nx.watts_strogatz_graph(N, k, p, seed=seed)
    edges = list(G.edges())
    return edges, G

# =============================================
# 快速哈密顿量编译：标准海森堡，与泡利矩阵定义等价
# σxσx+σyσy: 反平行自旋态互换，矩阵元 2
# σzσz: 平行 +1，反平行 -1
# =============================================
def heisenberg_edge_operator(N, edge):
    i, j = edge
    dim = 2**N
    rows = []
    cols = []
    data = []
    # 与 np.kron 顺序一致：site 0 是最高位
    bit_i = N - 1 - i
    bit_j = N - 1 - j
    mask = (1 << bit_i) | (1 << bit_j)
    for state in range(dim):
        si = (state >> bit_i) & 1
        sj = (state >> bit_j) & 1
        # σz_i σz_j diagonal
        rows.append(state)
        cols.append(state)
        data.append(1.0 if si == sj else -1.0)
        # σxσx + σyσy off-diagonal only for opposite spins, amplitude 2
        if si != sj:
            flipped = state ^ mask
            rows.append(flipped)
            cols.append(state)
            data.append(2.0)
    return coo_matrix((data, (rows, cols)), shape=(dim, dim), dtype=float).tocsc()

def precompute_system(N, edges):
    dim = 2**N
    edge_terms = {tuple(edge): heisenberg_edge_operator(N, tuple(edge)) for edge in edges}
    H_all = csc_matrix((dim, dim), dtype=float)
    for term in edge_terms.values():
        H_all = H_all + term

    states = np.arange(dim)
    z_vals = np.empty((N, dim), dtype=float)
    for site in range(N):
        bit = N - 1 - site
        z_vals[site] = 1.0 - 2.0 * ((states >> bit) & 1)
    zz_vals = {tuple(edge): z_vals[edge[0]] * z_vals[edge[1]] for edge in edges}
    return H_all, edge_terms, z_vals, zz_vals

# =============================================
# 诊断函数
# =============================================
def diagnose_fast(N, edges, contradiction_edge, s, H_all, edge_terms, z_vals, zz_vals, num_eig=3, seed=None):
    edge_key = tuple(contradiction_edge)
    H = H_all + (s - 1.0) * edge_terms[edge_key]
    v0 = None
    if seed is not None:
        rng = np.random.default_rng(seed)
        v0 = rng.random(2**N)
    energies, states = eigsh(H, k=min(num_eig, 2**N-1), which='SA', v0=v0)
    order = np.argsort(energies)
    energies = energies[order]
    states = states[:, order]
    gap = energies[1] - energies[0] if len(energies) > 1 else np.nan
    gs = states[:, 0]
    probs = np.abs(gs)**2

    mag = np.sum(z_vals @ probs)
    coarse = abs(mag / N)
    corrs = [float(zz_vals[tuple(edge)] @ probs) for edge in edges]
    fine = np.std(corrs) if corrs else 0.0
    return coarse, fine, gap

# =============================================
# 单条边的多种子扫描
# =============================================
def scan_single_edge_fast(N, edges, contradiction_edge, s_values, seeds, H_all, edge_terms, z_vals, zz_vals):
    results = {seed: {'coarse': [], 'fine': [], 'gap': []} for seed in seeds}
    for seed in seeds:
        for s in s_values:
            coarse, fine, gap = diagnose_fast(
                N, edges, contradiction_edge, s, H_all, edge_terms, z_vals, zz_vals,
                num_eig=3, seed=seed
            )
            results[seed]['coarse'].append(coarse)
            results[seed]['fine'].append(fine)
            results[seed]['gap'].append(gap)
    return results

# =============================================
# 主程序：对所有边执行统一体检
# =============================================
N = 10
k = 4
p = 0.1
seed = 42
seeds_list = [0, 1, 2]

edges, G = generate_small_world(N, k, p, seed)
n_edges = len(edges)
s_values = np.arange(0.0, 3.01, 0.01)

print(f"=== 小世界图全身体检 ===")
print(f"N={N}, k={k}, p={p}, seed={seed}")
print(f"总边数: {n_edges}")
print(f"扫描协议: s从0到3, 步长0.01, 3种子\n")

start_time = time.time()
H_all, edge_terms, z_vals, zz_vals = precompute_system(N, edges)
print(f"预编译完成: {time.time() - start_time:.2f}s\n")

summary = []
all_edge_results = {}

for edge_idx, (i, j) in enumerate(edges):
    contradiction_edge = (i, j)
    print(f"[边 {edge_idx+1}/{n_edges}] 矛盾边=({i},{j}) ... ", end='', flush=True)

    results = scan_single_edge_fast(N, edges, contradiction_edge, s_values, seeds_list, H_all, edge_terms, z_vals, zz_vals)
    all_edge_results[contradiction_edge] = results

    all_fine = np.array([results[s]['fine'] for s in seeds_list])
    all_coarse = np.array([results[s]['coarse'] for s in seeds_list])
    all_gap = np.array([results[s]['gap'] for s in seeds_list])

    mean_fine = np.mean(all_fine, axis=0)
    mean_coarse = np.mean(all_coarse, axis=0)
    mean_gap = np.mean(all_gap, axis=0)

    np.savetxt(f'sw_edge_{i}_{j}.csv',
               np.column_stack((s_values, mean_coarse, mean_fine, mean_gap)),
               header='s,coarse_mean,fine_mean,gap_mean', delimiter=',')

    fine_range = np.max(mean_fine) - np.min(mean_fine)
    coarse_range = np.max(mean_coarse) - np.min(mean_coarse)
    valley_idx = np.argmin(mean_fine)
    valley_s = s_values[valley_idx]
    valley_depth = fine_range
    gap_at_valley = mean_gap[valley_idx]
    gap_min = np.min(mean_gap)
    gap_min_s = s_values[np.argmin(mean_gap)]

    summary.append({
        'edge': contradiction_edge,
        'fine_range': fine_range,
        'coarse_range': coarse_range,
        'valley_s': valley_s,
        'valley_depth': valley_depth,
        'gap_at_valley': gap_at_valley,
        'gap_min': gap_min,
        'gap_min_s': gap_min_s,
    })

    print(f"fine_range={fine_range:.6f}, coarse_range={coarse_range:.6f}, "
          f"valley_s={valley_s:.3f}, gap_at_valley={gap_at_valley:.4f}")

summary_file = 'small_world_full_check_summary.csv'
with open(summary_file, 'w') as f:
    f.write('edge_i,edge_j,fine_range,coarse_range,valley_s,valley_depth,gap_at_valley,gap_min,gap_min_s\n')
    for row in summary:
        f.write(f"{row['edge'][0]},{row['edge'][1]},{row['fine_range']:.6f},"
                f"{row['coarse_range']:.6f},{row['valley_s']:.3f},"
                f"{row['valley_depth']:.6f},{row['gap_at_valley']:.4f},"
                f"{row['gap_min']:.4f},{row['gap_min_s']:.3f}\n")

print(f"\n=== 全身体检汇总 ===")
print(f"总边数: {n_edges}")
print(f"边列表及关键指标:")

n_with_valley = sum(1 for r in summary if r['fine_range'] > 0.05)
n_blind_default = sum(1 for r in summary if r['coarse_range'] < 0.001)
n_valley_with_gap = sum(1 for r in summary if r['fine_range'] > 0.05 and r['gap_at_valley'] > 0.01)

for r in summary:
    print(f"  边({r['edge'][0]},{r['edge'][1]}): fine_range={r['fine_range']:.6f}, "
          f"coarse_range={r['coarse_range']:.6f}, valley_s={r['valley_s']:.3f}, "
          f"gap_at_valley={r['gap_at_valley']:.4f}")

print(f"\n=== 统计 ===")
print(f"有显著谷的边 (fine_range > 0.05): {n_with_valley}/{n_edges}")
print(f"默认诊断盲视的边 (coarse_range < 0.001): {n_blind_default}/{n_edges}")
print(f"谷在能隙非零处的边: {n_valley_with_gap}/{n_edges}")

fig, ax = plt.subplots(figsize=(12, 6))
edge_labels = [f"({r['edge'][0]},{r['edge'][1]})" for r in summary]
fine_ranges = [r['fine_range'] for r in summary]
coarse_ranges = [r['coarse_range'] for r in summary]

x = np.arange(len(edge_labels))
width = 0.35
ax.bar(x - width/2, fine_ranges, width, label='Fine range', color='red', alpha=0.8)
ax.bar(x + width/2, coarse_ranges, width, label='Coarse range', color='blue', alpha=0.8)
ax.set_xticks(x)
ax.set_xticklabels(edge_labels, rotation=45, ha='right')
ax.set_xlabel('Contradiction edge')
ax.set_ylabel('Diagnostic range')
ax.set_title(f'Full Check: Diagnostic Ranges for Each Edge (N={N})')
ax.legend()
ax.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig('small_world_full_check.png', dpi=150)
plt.close(fig)

print("\n汇总表已保存: small_world_full_check_summary.csv")
print("汇总图已保存: small_world_full_check.png")
print(f"总耗时: {(time.time() - start_time)/60:.2f} 分钟")