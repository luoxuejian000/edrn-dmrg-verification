import numpy as np
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import networkx as nx

def watts_strogatz_edges(N=8, k=4, p=0.1, seed=42):
    """生成小世界图边列表（Watts-Strogatz模型）"""
    G = nx.watts_strogatz_graph(N, k, p, seed=seed)
    return [(i, j, 1.0) for (i, j) in sorted(G.edges())]

def build_hamiltonian_correct(N, edges, contradiction_edge, s):
    """标准各向同性Heisenberg哈密顿量（泡利矩阵构建）。
    矛盾边可以是二元组或三元组，函数内部统一提取前两个元素。"""
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    ce_i, ce_j = contradiction_edge[0], contradiction_edge[1]
    for (i, j, w) in edges:
        if (i == ce_i and j == ce_j) or (i == ce_j and j == ce_i):
            J = s
        else:
            J = w
        for state in range(dim):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                H[state, flipped] += 2.0 * J
                H[state, state] -= J
            else:
                H[state, state] += J
    return H.tocsc()

def compute_enhanced(N, edges, psi):
    corrs = []
    for (i, j, _) in edges:
        corr = 0.0
        for state, amp in enumerate(psi):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            corr += np.abs(amp)**2 * (1 - 2 * bit_i) * (1 - 2 * bit_j)
        corrs.append(corr)
    return np.std(corrs)

def run_edge_scan(N=8, s_vals=np.linspace(0, 3, 13), v0_seed=0):
    edges = watts_strogatz_edges(N, k=4, p=0.1, seed=42)
    N = max(max(i, j) for (i, j, _) in edges) + 1
    print(f"小世界图: N={N}, 边数={len(edges)}")
    print(f"扫描：每条边逐一作为矛盾边，s ∈ [0,3]\n")
    
    results = []
    for edge in edges:
        edge_pair = (edge[0], edge[1])
        enhanceds = []
        for s in s_vals:
            H = build_hamiltonian_correct(N, edges, edge_pair, s)
            np.random.seed(v0_seed)
            v0 = np.random.randn(2**N)
            v0 /= np.linalg.norm(v0)
            evals, evecs = eigsh(H, k=1, which='SA', v0=v0)
            psi = evecs[:, 0]
            enhanceds.append(compute_enhanced(N, edges, psi))
        enhanceds = np.array(enhanceds)
        range_val = np.max(enhanceds) - np.min(enhanceds)
        valley_idx = np.argmin(enhanceds)
        valley_depth = enhanceds[0] - enhanceds[valley_idx]
        results.append({
            'edge': edge_pair,
            'range': range_val,
            'depth': valley_depth,
            'valley_s': s_vals[valley_idx],
        })
        print(f"边 {edge_pair}: 极差={range_val:.6f}, 谷深度={valley_depth:.6f}, 谷位置s={s_vals[valley_idx]:.2f}")
    
    results.sort(key=lambda x: x['depth'], reverse=True)
    print("\n按谷深度排序的所有边：")
    for i, r in enumerate(results):
        print(f"  {i+1}. 边{r['edge']}: 深度={r['depth']:.6f}, 极差={r['range']:.6f}, 谷位置={r['valley_s']:.2f}")
    
    np.savetxt('small_world_edge_scan_corrected.csv',
               np.array([(r['edge'][0], r['edge'][1], r['depth'], r['range'], r['valley_s'])
                         for r in results]),
               header='edge_i,edge_j,depth,range,valley_s', delimiter=',')
    print("\n数据已保存: small_world_edge_scan_corrected.csv")
    return results

results = run_edge_scan()