import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import sparse
from scipy.sparse.linalg import eigsh
import networkx as nx

# =============================================
# 公理一：小世界图生成
# =============================================
def build_small_world(N, k, p, seed=42):
    """使用 networkx 生成 Watts-Strogatz 小世界图"""
    G = nx.watts_strogatz_graph(N, k, p, seed=seed)
    edges = list(G.edges())
    return N, edges

# =============================================
# 优化版哈密顿量/诊断预编译：等价于原代码，但避免重复 Kronecker 构造
# =============================================
def _one_site_ops(N):
    sx = sparse.csr_matrix(np.array([[0, 1], [1, 0]], dtype=float))
    sy = sparse.csr_matrix(np.array([[0, -1j], [1j, 0]], dtype=complex))
    sz = sparse.csr_matrix(np.array([[1, 0], [0, -1]], dtype=float))
    I2 = sparse.identity(2, format='csr', dtype=float)

    sx_ops, sy_ops, sz_ops = [], [], []
    for site in range(N):
        ops = [I2] * N
        ops[site] = sx
        op = ops[0]
        for q in range(1, N):
            op = sparse.kron(op, ops[q], format='csr')
        sx_ops.append(op)

        ops = [I2] * N
        ops[site] = sy
        op = ops[0]
        for q in range(1, N):
            op = sparse.kron(op, ops[q], format='csr')
        sy_ops.append(op)

        ops = [I2] * N
        ops[site] = sz
        op = ops[0]
        for q in range(1, N):
            op = sparse.kron(op, ops[q], format='csr')
        sz_ops.append(op)

    return sx_ops, sy_ops, sz_ops

def precompile_audit(N, edges, contradiction_edge):
    sx_ops, sy_ops, sz_ops = _one_site_ops(N)
    dim = 2**N
    H_base = sparse.csr_matrix((dim, dim), dtype=float)
    H_contrad = sparse.csr_matrix((dim, dim), dtype=float)
    zz_edge_ops = []

    ce = tuple(contradiction_edge)
    ce_rev = (ce[1], ce[0])
    for (i, j) in edges:
        Hij = (sx_ops[i] @ sx_ops[j]).real + (sy_ops[i] @ sy_ops[j]).real + (sz_ops[i] @ sz_ops[j]).real
        Hij = Hij.tocsr()
        if (i, j) == ce or (i, j) == ce_rev:
            H_contrad = H_contrad + Hij
        else:
            H_base = H_base + Hij
        zz_edge_ops.append((sz_ops[i] @ sz_ops[j]).tocsr())
    return H_base.tocsc(), H_contrad.tocsc(), sz_ops, zz_edge_ops

def compute_diagnostics_precompiled(H_base, H_contrad, sz_ops, zz_edge_ops, s, num_eig=3, seed=None):
    H = H_base + s * H_contrad
    v0 = None
    if seed is not None:
        rng = np.random.default_rng(seed)
        v0 = rng.random(H.shape[0])
    energies, states = eigsh(H, k=min(num_eig, H.shape[0]-1), which='SA', v0=v0)
    order = np.argsort(energies)
    energies = energies[order]
    states = states[:, order]

    gap = energies[1] - energies[0] if len(energies) > 1 else np.nan
    gs = states[:, 0]

    mag = 0.0
    for op in sz_ops:
        mag += np.real(np.vdot(gs, op @ gs))
    coarse = abs(mag / len(sz_ops))

    corrs = [np.real(np.vdot(gs, op @ gs)) for op in zz_edge_ops]
    fine = np.std(corrs) if corrs else 0.0
    return fine, coarse, gap

# =============================================
# 高分辨率多种子审计
# =============================================
N = 10
k = 4
p = 0.1
seed_graph = 42
contradiction_edge = (0, 1)

_, edges = build_small_world(N, k, p, seed=seed_graph)
print(f"=== (0,1)边高分辨率多种子审计 ===")
print(f"N={N}, 边数={len(edges)}, 矛盾边={contradiction_edge}")

s_values = np.arange(1.20, 1.80 + 0.005, 0.005)
seeds = [101, 202, 303, 404, 505, 606, 707]
print(f"扫描窗口: s ∈ [1.20, 1.80]")
print(f"点数: {len(s_values)}, 种子数: {len(seeds)}")

H_base, H_contrad, sz_ops, zz_edge_ops = precompile_audit(N, edges, contradiction_edge)

all_fine = np.zeros((len(seeds), len(s_values)))
all_coarse = np.zeros((len(seeds), len(s_values)))
all_gap = np.zeros((len(seeds), len(s_values)))

for seed_idx, seed in enumerate(seeds):
    for s_idx, s in enumerate(s_values):
        fine, coarse, gap = compute_diagnostics_precompiled(
            H_base, H_contrad, sz_ops, zz_edge_ops, s, num_eig=3, seed=seed
        )
        all_fine[seed_idx, s_idx] = fine
        all_coarse[seed_idx, s_idx] = coarse
        all_gap[seed_idx, s_idx] = gap
    print(f"种子 {seed}: 完成")

print("\n=== 各种子谷特征 ===")
seed_valley_positions = []
for seed_idx, seed in enumerate(seeds):
    fine_curve = all_fine[seed_idx]
    min_idx = np.argmin(fine_curve)
    valley_s = s_values[min_idx]
    seed_valley_positions.append(valley_s)
    valley_fine = fine_curve[min_idx]
    valley_depth = np.max(fine_curve) - valley_fine
    gap_at_valley = all_gap[seed_idx, min_idx]
    print(f"种子 {seed}: valley_s={valley_s:.3f}, valley_fine={valley_fine:.6f}, "
          f"depth={valley_depth:.6f}, gap={gap_at_valley:.4f}")

fine_mean = np.mean(all_fine, axis=0)
fine_std = np.std(all_fine, axis=0)
gap_mean = np.mean(all_gap, axis=0)
gap_min = np.min(all_gap, axis=0)

overall_min_idx = np.argmin(fine_mean)
overall_valley_s = s_values[overall_min_idx]
overall_valley_fine = fine_mean[overall_min_idx]
overall_valley_depth = np.max(fine_mean) - overall_valley_fine

seed_valley_positions = np.array(seed_valley_positions)
valley_pos_std = np.std(seed_valley_positions)

print("\n=== 跨种子汇总 ===")
print(f"平均谷位置: s={overall_valley_s:.3f}")
print(f"各种子谷位置标准差: {valley_pos_std:.6f}")
print(f"平均谷深度: {overall_valley_depth:.6f}")
print(f"谷值跨种子标准差: {fine_std[overall_min_idx]:.6f}")
print(f"谷底平均能隙: {gap_mean[overall_min_idx]:.4f}")
print(f"谷底最小能隙: {gap_min[overall_min_idx]:.4f}")

np.savetxt('edge01_dense_fine.csv',
           np.column_stack((s_values, fine_mean, fine_std)),
           header='s,fine_mean,fine_std', delimiter=',')
np.savetxt('edge01_dense_gap.csv',
           np.column_stack((s_values, gap_mean, gap_min)),
           header='s,gap_mean,gap_min', delimiter=',')

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
for seed_idx in range(len(seeds)):
    ax1.plot(s_values, all_fine[seed_idx], lw=0.8, alpha=0.5,
             label=f'Seed {seeds[seed_idx]}' if seed_idx < 3 else None)
ax1.plot(s_values, fine_mean, 'k-', lw=2, label='Mean')
ax1.axvline(overall_valley_s, color='red', ls='--', lw=1,
            label=f'Valley s={overall_valley_s:.3f}')
ax1.set_xlabel('s')
ax1.set_ylabel('Enhanced diagnosis')
ax1.set_title('Edge (0,1) Dense Multi-Seed Audit')
ax1.legend(fontsize=8)
ax1.grid(True, alpha=0.3)

ax2.plot(s_values, gap_mean, 'b-', lw=2, label='Mean gap')
ax2.fill_between(s_values, gap_min, gap_mean, alpha=0.2, color='blue',
                 label='Range across seeds')
ax2.axvline(overall_valley_s, color='red', ls='--', lw=1,
            label=f'Valley s={overall_valley_s:.3f}')
ax2.set_xlabel('s')
ax2.set_ylabel('Energy gap')
ax2.set_title('Gap at Edge (0,1)')
ax2.legend(fontsize=8)
ax2.grid(True, alpha=0.3)

plt.suptitle('Edge (0,1) High-Resolution Audit (7 Seeds)')
plt.tight_layout()
plt.savefig('edge01_dense_audit.png', dpi=150)
plt.close(fig)
print("\n图表已保存: edge01_dense_audit.png")

print("\n=== 诚实声明 ===")
if valley_pos_std < 0.01:
    print("谷位置跨种子稳定（标准差 < 0.01）。")
else:
    print(f"谷位置跨种子变异显著（标准差 = {valley_pos_std:.4f}）。")
if fine_std[overall_min_idx] < 0.01:
    print("谷值跨种子稳定。")
else:
    print(f"谷值跨种子变异显著（标准差 = {fine_std[overall_min_idx]:.4f}）。")