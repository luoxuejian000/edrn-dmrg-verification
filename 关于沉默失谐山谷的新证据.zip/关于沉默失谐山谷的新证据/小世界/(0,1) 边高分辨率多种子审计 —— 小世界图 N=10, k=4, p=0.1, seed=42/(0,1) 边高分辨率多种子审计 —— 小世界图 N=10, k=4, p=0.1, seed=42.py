"""
(0,1) 边高分辨率多种子审计 —— 小世界图 N=10, k=4, p=0.1, seed=42
目的：精确解剖谷底在s=1.5附近的行为，量化种子间变异，检查能隙是否闭合。
严格遵循：关系本体论、防工具理性悖论、反对对齐。
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh
import networkx as nx

# =============================================
# 公理一：小世界图生成
# =============================================
def build_small_world(N, k, p, seed=42):
    """使用 networkx 生成 Watts-Strogatz 小世界图"""
    G = nx.watts_strogatz_graph(N, k, p, seed=seed)
    edges = list(G.edges())
    return N, edges

# =============================================
# 哈密顿量编译（标准泡利矩阵 Heisenberg）
# =============================================
def graph_to_hamiltonian(N, edges, contradiction_edge, s):
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)

    def to_full(op, site):
        ops = [I2] * N
        ops[site] = op
        result = ops[0]
        for k in range(1, N):
            result = np.kron(result, ops[k])
        return result

    for (i, j) in edges:
        w = s if (i,j)==contradiction_edge or (j,i)==contradiction_edge else 1.0
        H += w * (to_full(sx, i) @ to_full(sx, j)).real
        H += w * (to_full(sy, i) @ to_full(sy, j)).real
        H += w * (to_full(sz, i) @ to_full(sz, j)).real
    return H.tocsc()

# =============================================
# 诊断函数
# =============================================
def compute_diagnostics(N, edges, contradiction_edge, s, num_eig=3, seed=None):
    H = graph_to_hamiltonian(N, edges, contradiction_edge, s)
    v0 = None
    if seed is not None:
        rng = np.random.default_rng(seed)
        v0 = rng.random(2**N)
    energies, states = eigsh(H, k=min(num_eig, 2**N-1), which='SA', v0=v0)

    # 能隙
    gap = energies[1] - energies[0] if len(energies) > 1 else np.nan
    gs = states[:, 0]

    # 默认诊断：平均磁化
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    mag = 0.0
    for i in range(N):
        ops = [I2] * N
        ops[i] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        mag += np.real(gs.conj().T @ op_full @ gs)
    coarse = abs(mag / N)

    # 增强诊断：边关联涨落标准差
    corrs = []
    for (i, j) in edges:
        ops = [I2] * N
        ops[i] = sz
        ops[j] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        corr = np.real(gs.conj().T @ op_full @ gs)
        corrs.append(corr)
    fine = np.std(corrs) if corrs else 0.0

    return fine, coarse, gap

# =============================================
# 高分辨率多种子审计
# =============================================
if __name__ == "__main__":
    N = 10
    k = 4
    p = 0.1
    seed_graph = 42
    contradiction_edge = (0, 1)

    _, edges = build_small_world(N, k, p, seed=seed_graph)
    print(f"=== (0,1)边高分辨率多种子审计 ===")
    print(f"N={N}, 边数={len(edges)}, 矛盾边={contradiction_edge}")

    # 聚焦窗口：s ∈ [1.2, 1.8]，步长0.005，共121点
    s_values = np.arange(1.20, 1.80 + 0.005, 0.005)
    seeds = [101, 202, 303, 404, 505, 606, 707]  # 7个独立Lanczos种子

    print(f"扫描窗口: s ∈ [1.20, 1.80]")
    print(f"点数: {len(s_values)}, 种子数: {len(seeds)}")

    # 全量存储：每个种子在每个s点的 fine、coarse、gap
    all_fine = np.zeros((len(seeds), len(s_values)))
    all_coarse = np.zeros((len(seeds), len(s_values)))
    all_gap = np.zeros((len(seeds), len(s_values)))

    for seed_idx, seed in enumerate(seeds):
        for s_idx, s in enumerate(s_values):
            fine, coarse, gap = compute_diagnostics(
                N, edges, contradiction_edge, s, num_eig=3, seed=seed
            )
            all_fine[seed_idx, s_idx] = fine
            all_coarse[seed_idx, s_idx] = coarse
            all_gap[seed_idx, s_idx] = gap
        print(f"种子 {seed}: 完成")

    # 每个种子的谷位置和谷深度
    print("\n=== 各种子谷特征 ===")
    for seed_idx, seed in enumerate(seeds):
        fine_curve = all_fine[seed_idx]
        min_idx = np.argmin(fine_curve)
        valley_s = s_values[min_idx]
        valley_fine = fine_curve[min_idx]
        # 谷深度 = 窗口内的最大值 - 谷值
        valley_depth = np.max(fine_curve) - valley_fine
        gap_at_valley = all_gap[seed_idx, min_idx]
        print(f"种子 {seed}: valley_s={valley_s:.3f}, valley_fine={valley_fine:.6f}, "
              f"depth={valley_depth:.6f}, gap={gap_at_valley:.4f}")

    # 跨种子统计
    fine_mean = np.mean(all_fine, axis=0)
    fine_std = np.std(all_fine, axis=0)
    gap_mean = np.mean(all_gap, axis=0)
    gap_min = np.min(all_gap, axis=0)

    # 总体谷位置（基于平均曲线）
    overall_min_idx = np.argmin(fine_mean)
    overall_valley_s = s_values[overall_min_idx]
    overall_valley_fine = fine_mean[overall_min_idx]
    overall_valley_depth = np.max(fine_mean) - overall_valley_fine

    # 跨种子谷位置变异
    seed_valley_positions = []
    for seed_idx in range(len(seeds)):
        min_idx = np.argmin(all_fine[seed_idx])
        seed_valley_positions.append(s_values[min_idx])
    seed_valley_positions = np.array(seed_valley_positions)
    valley_pos_std = np.std(seed_valley_positions)

    print("\n=== 跨种子汇总 ===")
    print(f"平均谷位置: s={overall_valley_s:.3f}")
    print(f"各种子谷位置标准差: {valley_pos_std:.6f}")
    print(f"平均谷深度: {overall_valley_depth:.6f}")
    print(f"谷值跨种子标准差: {fine_std[overall_min_idx]:.6f}")
    print(f"谷底平均能隙: {gap_mean[overall_min_idx]:.4f}")
    print(f"谷底最小能隙: {gap_min[overall_min_idx]:.4f}")

    # 保存数据
    np.savetxt('edge01_dense_fine.csv',
               np.column_stack((s_values, fine_mean, fine_std)),
               header='s,fine_mean,fine_std', delimiter=',')
    np.savetxt('edge01_dense_gap.csv',
               np.column_stack((s_values, gap_mean, gap_min)),
               header='s,gap_mean,gap_min', delimiter=',')

    # 诊断图
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

    # 左图：增强诊断 vs s，展示所有种子
    for seed_idx in range(len(seeds)):
        ax1.plot(s_values, all_fine[seed_idx], lw=0.8, alpha=0.5,
                 label=f'Seed {seeds[seed_idx]}' if seed_idx < 3 else None)
    ax1.plot(s_values, fine_mean, 'k-', lw=2, label='Mean')
    ax1.axvline(overall_valley_s, color='red', ls='--', lw=1,
                label=f'Valley s={overall_valley_s:.3f}')
    ax1.set_xlabel('s')
    ax1.set_ylabel('Enhanced diagnosis')
    ax1.set_title('Edge (0,1) Dense Multi-Seed Audit')
    ax1.legend(fontsize=8)
    ax1.grid(True, alpha=0.3)

    # 右图：能隙 vs s
    ax2.plot(s_values, gap_mean, 'b-', lw=2, label='Mean gap')
    ax2.fill_between(s_values, gap_min, gap_mean, alpha=0.2, color='blue',
                     label='Range across seeds')
    ax2.axvline(overall_valley_s, color='red', ls='--', lw=1,
                label=f'Valley s={overall_valley_s:.3f}')
    ax2.set_xlabel('s')
    ax2.set_ylabel('Energy gap')
    ax2.set_title('Gap at Edge (0,1)')
    ax2.legend(fontsize=8)
    ax2.grid(True, alpha=0.3)

    plt.suptitle('Edge (0,1) High-Resolution Audit (7 Seeds)')
    plt.tight_layout()
    plt.savefig('edge01_dense_audit.png', dpi=150)
    print("\n图表已保存: edge01_dense_audit.png")

    # 诚实声明
    print("\n=== 诚实声明 ===")
    if valley_pos_std < 0.01:
        print("谷位置跨种子稳定（标准差 < 0.01）。")
    else:
        print(f"谷位置跨种子变异显著（标准差 = {valley_pos_std:.4f}）。")
    if fine_std[overall_min_idx] < 0.01:
        print("谷值跨种子稳定。")
    else:
        print(f"谷值跨种子变异显著（标准差 = {fine_std[overall_min_idx]:.4f}）。")