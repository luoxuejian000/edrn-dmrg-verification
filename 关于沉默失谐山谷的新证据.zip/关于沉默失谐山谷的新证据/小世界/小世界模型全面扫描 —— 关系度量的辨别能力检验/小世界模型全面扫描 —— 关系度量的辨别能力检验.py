"""
小世界模型全面扫描 —— 关系度量的辨别能力检验
N=10, k=4, p=0.1, seed=42
矛盾边强度s从0到3，步长0.001
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh
import networkx as nx

# =============================================
# 公理一：小世界图生成（固定种子，可复现）
# =============================================
def generate_small_world(N=10, k=4, p=0.1, seed=42):
    """生成 Watts-Strogatz 小世界图，返回边列表"""
    G = nx.watts_strogatz_graph(N, k, p, seed=seed)
    edges = list(G.edges())
    return edges, G

# =============================================
# 公理一：哈密顿量编译（泡利矩阵版，标准海森堡）
# =============================================
def graph_to_hamiltonian(N, edges, contradiction_edge, s):
    """标准各向同性 Heisenberg 哈密顿量"""
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)

    def to_full(op, site):
        ops = [I2] * N
        ops[site] = op
        result = ops[0]
        for k in range(1, N):
            result = np.kron(result, ops[k])
        return result

    for (i, j) in edges:
        w = s if (i,j)==contradiction_edge or (j,i)==contradiction_edge else 1.0
        H += w * (to_full(sx, i) @ to_full(sx, j)).real
        H += w * (to_full(sy, i) @ to_full(sy, j)).real
        H += w * (to_full(sz, i) @ to_full(sz, j)).real
    return H.tocsc()

# =============================================
# 公理三：诊断函数
# =============================================
def diagnose(N, edges, contradiction_edge, s, num_eig=3, seed=None):
    """求解基态，返回默认诊断、增强诊断和能隙"""
    H = graph_to_hamiltonian(N, edges, contradiction_edge, s)
    v0 = None
    if seed is not None:
        rng = np.random.default_rng(seed)
        v0 = rng.random(2**N)
    energies, states = eigsh(H, k=min(num_eig, 2**N-1), which='SA', v0=v0)
    E0 = energies[0]
    gap = energies[1] - energies[0] if len(energies) > 1 else np.nan
    gs = states[:, 0]

    # 默认诊断：平均磁化
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    mag = 0.0
    for i in range(N):
        ops = [I2] * N
        ops[i] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        mag += np.real(gs.conj().T @ op_full @ gs)
    coarse = abs(mag / N)

    # 增强诊断：边关联涨落标准差
    corrs = []
    for (i, j) in edges:
        ops = [I2] * N
        ops[i] = sz
        ops[j] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        corr = np.real(gs.conj().T @ op_full @ gs)
        corrs.append(corr)
    fine = np.std(corrs) if corrs else 0.0

    return coarse, fine, gap

# =============================================
# 多种子扫描
# =============================================
def multi_seed_scan(N, edges, contradiction_edge, s_values, seeds):
    """对每个s值，用多个Lanczos种子独立计算"""
    results = {seed: {'coarse': [], 'fine': [], 'gap': []} for seed in seeds}

    for seed in seeds:
        for s in s_values:
            coarse, fine, gap = diagnose(N, edges, contradiction_edge, s,
                                         num_eig=3, seed=seed)
            results[seed]['coarse'].append(coarse)
            results[seed]['fine'].append(fine)
            results[seed]['gap'].append(gap)

    return results

# =============================================
# 主程序
# =============================================
if __name__ == "__main__":
    N = 10
    k = 4
    p = 0.1
    seed = 42

    edges, G = generate_small_world(N, k, p, seed)
    print(f"=== 小世界图 (N={N}, k={k}, p={p}, seed={seed}) ===")
    print(f"边数: {len(edges)}")

    # 矛盾边选择：选择第一个边（不预设"应该出谷"的边）
    contradiction_edge = edges[0]
    print(f"矛盾边: {contradiction_edge}")

    # 高分辨率扫描：步长0.001
    s_values = np.arange(0.0, 3.001, 0.001)
    seeds_list = [0, 1, 2]

    print(f"扫描: {len(s_values)} 点, {len(seeds_list)} 种子")
    print("开始扫描...")

    results = multi_seed_scan(N, edges, contradiction_edge, s_values, seeds_list)

    # 保存数据
    for seed in seeds_list:
        np.savetxt(f'small_world_seed{seed}.csv',
                   np.column_stack((s_values,
                                    results[seed]['coarse'],
                                    results[seed]['fine'],
                                    results[seed]['gap'])),
                   header='s,coarse,fine,gap', delimiter=',')

    # 多种子平均
    all_fine = np.array([results[seed]['fine'] for seed in seeds_list])
    all_coarse = np.array([results[seed]['coarse'] for seed in seeds_list])
    all_gap = np.array([results[seed]['gap'] for seed in seeds_list])

    mean_fine = np.mean(all_fine, axis=0)
    mean_coarse = np.mean(all_coarse, axis=0)
    mean_gap = np.mean(all_gap, axis=0)
    std_fine = np.std(all_fine, axis=0)

    # 保存平均值
    np.savetxt('small_world_mean.csv',
               np.column_stack((s_values, mean_coarse, mean_fine, mean_gap, std_fine)),
               header='s,coarse_mean,fine_mean,gap_mean,fine_std', delimiter=',')

    # 计算极差
    fine_range = np.max(mean_fine) - np.min(mean_fine)
    coarse_range = np.max(mean_coarse) - np.min(mean_coarse)
    fine_min_idx = np.argmin(mean_fine)
    fine_max_idx = np.argmax(mean_fine)

    print(f"\n=== 多种子审计结果 ===")
    print(f"增强诊断极差 (fine range): {fine_range:.6f}")
    print(f"默认诊断极差 (coarse range): {coarse_range:.6f}")
    if coarse_range > 0:
        ratio = fine_range / coarse_range
        print(f"极差比 (fine/coarse): {ratio:.2f}")
    else:
        print("极差比: 默认诊断极差为零，无法计算比值")
        ratio = np.inf
    print(f"增强诊断最小值位置: s={s_values[fine_min_idx]:.3f}, 值={mean_fine[fine_min_idx]:.6f}")
    print(f"增强诊断最大值位置: s={s_values[fine_max_idx]:.3f}, 值={mean_fine[fine_max_idx]:.6f}")
    print(f"能隙最小值位置: s={s_values[np.argmin(mean_gap)]:.3f}, 值={mean_gap[np.argmin(mean_gap)]:.6f}")

    # 预设成功标准（防工具理性悖论）：极差比>3才有辨别能力
    print(f"\n预设成功标准: fine/coarse 极差比 > 3.0")
    print(f"实际比值: {ratio:.2f}")
    if ratio > 3.0:
        print("结果: 关系度量有辨别能力。")
    else:
        print("结果: 关系度量无显著辨别能力，或默认诊断同样敏感。")

    # 绘图
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

    ax1.plot(s_values, mean_coarse, color='blue', label='Default (coarse)')
    ax1.set_xlabel('Contradiction strength s')
    ax1.set_ylabel('Default diagnosis')
    ax1.set_title('Default Diagnosis (mean magnetization)')
    ax1.legend()
    ax1.grid(True, alpha=0.3)

    ax2.plot(s_values, mean_fine, color='red', label='Enhanced (fine)')
    ax2.fill_between(s_values, mean_fine - std_fine, mean_fine + std_fine,
                     alpha=0.3, color='red')
    ax2.set_xlabel('Contradiction strength s')
    ax2.set_ylabel('Enhanced diagnosis')
    ax2.set_title('Enhanced Diagnosis (corr. std)')
    ax2.legend()
    ax2.grid(True, alpha=0.3)

    plt.suptitle(f'Small-World Scan (N={N}, k={k}, p={p}, edge={contradiction_edge})')
    plt.tight_layout()
    plt.savefig('small_world_scan.png', dpi=150)
    print("\n图表已保存: small_world_scan.png")

    # 能隙图
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(s_values, mean_gap, color='green', label='Energy gap')
    ax.set_xlabel('Contradiction strength s')
    ax.set_ylabel('Energy gap')
    ax.set_title(f'Energy Gap Across Scan (min={np.min(mean_gap):.6f})')
    ax.legend()
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('small_world_gap.png', dpi=150)
    print("能隙图已保存: small_world_gap.png")