import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.sparse import coo_matrix, csc_matrix
from scipy.sparse.linalg import eigsh
import networkx as nx
import time

# Optimized implementation of the user's scan: same model and diagnostics,
# but avoids repeated Kronecker products by using computational-basis sparse operators.

def generate_small_world(N=10, k=4, p=0.1, seed=42):
    G = nx.watts_strogatz_graph(N, k, p, seed=seed)
    edges = list(G.edges())
    return edges, G


def heisenberg_edge_operator(N, i, j):
    dim = 2**N
    rows, cols, data = [], [], []
    # bit convention: site i corresponds to bit (N-1-i), matching np.kron order in the original code
    bi = N - 1 - i
    bj = N - 1 - j
    for state in range(dim):
        si = 1 if ((state >> bi) & 1) == 0 else -1
        sj = 1 if ((state >> bj) & 1) == 0 else -1
        # sigma_z sigma_z diagonal term
        rows.append(state); cols.append(state); data.append(si * sj)
        # sigma_x sigma_x + sigma_y sigma_y: off-diagonal flip only for anti-aligned spins, amplitude 2
        if si != sj:
            flipped = state ^ (1 << bi) ^ (1 << bj)
            rows.append(flipped); cols.append(state); data.append(2.0)
    return coo_matrix((data, (rows, cols)), shape=(dim, dim), dtype=float).tocsc()


def precompute_model(N, edges, contradiction_edge):
    terms = {tuple(e): heisenberg_edge_operator(N, e[0], e[1]) for e in edges}
    contradiction_key = tuple(contradiction_edge)
    H_contra = terms[contradiction_key]
    H_base = sum((mat for e, mat in terms.items() if e != contradiction_key), csc_matrix((2**N, 2**N), dtype=float))

    dim = 2**N
    site_z = np.empty((N, dim), dtype=float)
    for i in range(N):
        b = N - 1 - i
        site_z[i] = np.where(((np.arange(dim) >> b) & 1) == 0, 1.0, -1.0)
    mag_diag = site_z.sum(axis=0) / N
    corr_diags = np.vstack([site_z[i] * site_z[j] for i, j in edges])
    return H_base, H_contra, mag_diag, corr_diags


def diagnose_precomputed(H_base, H_contra, mag_diag, corr_diags, s, num_eig=3, seed=None):
    H = H_base + s * H_contra
    v0 = None
    if seed is not None:
        rng = np.random.default_rng(seed)
        v0 = rng.random(H.shape[0])
    energies, states = eigsh(H, k=min(num_eig, H.shape[0]-1), which='SA', v0=v0)
    order = np.argsort(energies)
    energies = energies[order]
    states = states[:, order]
    gap = energies[1] - energies[0] if len(energies) > 1 else np.nan
    gs = states[:, 0]
    prob = np.abs(gs) ** 2
    coarse = abs(np.dot(prob, mag_diag))
    corrs = corr_diags @ prob
    fine = np.std(corrs) if corr_diags.size else 0.0
    return coarse, fine, gap


def multi_seed_scan_fast(N, edges, contradiction_edge, s_values, seeds):
    H_base, H_contra, mag_diag, corr_diags = precompute_model(N, edges, contradiction_edge)
    results = {seed: {'coarse': [], 'fine': [], 'gap': []} for seed in seeds}
    t0 = time.time()
    total = len(seeds) * len(s_values)
    n_done = 0
    for seed in seeds:
        for s in s_values:
            coarse, fine, gap = diagnose_precomputed(H_base, H_contra, mag_diag, corr_diags, s, num_eig=3, seed=seed)
            results[seed]['coarse'].append(coarse)
            results[seed]['fine'].append(fine)
            results[seed]['gap'].append(gap)
            n_done += 1
            if n_done % 500 == 0:
                print(f"已完成 {n_done}/{total} 点，用时 {time.time()-t0:.1f}s")
    return results

N = 10
k = 4
p = 0.1
seed = 42
edges, G = generate_small_world(N, k, p, seed)
contradiction_edge = edges[0]
s_values = np.arange(0.0, 3.001, 0.001)
seeds_list = [0, 1, 2]

print(f"=== 小世界图 (N={N}, k={k}, p={p}, seed={seed}) ===")
print(f"边数: {len(edges)}")
print(f"矛盾边: {contradiction_edge}")
print(f"扫描: {len(s_values)} 点, {len(seeds_list)} 种子")
print("开始扫描（优化版，保持同一哈密顿量和同一诊断定义）...")

results = multi_seed_scan_fast(N, edges, contradiction_edge, s_values, seeds_list)

for lanczos_seed in seeds_list:
    np.savetxt(f'small_world_seed{lanczos_seed}.csv',
               np.column_stack((s_values,
                                results[lanczos_seed]['coarse'],
                                results[lanczos_seed]['fine'],
                                results[lanczos_seed]['gap'])),
               header='s,coarse,fine,gap', delimiter=',')

all_fine = np.array([results[lanczos_seed]['fine'] for lanczos_seed in seeds_list])
all_coarse = np.array([results[lanczos_seed]['coarse'] for lanczos_seed in seeds_list])
all_gap = np.array([results[lanczos_seed]['gap'] for lanczos_seed in seeds_list])

mean_fine = np.mean(all_fine, axis=0)
mean_coarse = np.mean(all_coarse, axis=0)
mean_gap = np.mean(all_gap, axis=0)
std_fine = np.std(all_fine, axis=0)

np.savetxt('small_world_mean.csv',
           np.column_stack((s_values, mean_coarse, mean_fine, mean_gap, std_fine)),
           header='s,coarse_mean,fine_mean,gap_mean,fine_std', delimiter=',')

fine_range = np.max(mean_fine) - np.min(mean_fine)
coarse_range = np.max(mean_coarse) - np.min(mean_coarse)
fine_min_idx = np.argmin(mean_fine)
fine_max_idx = np.argmax(mean_fine)
gap_min_idx = np.argmin(mean_gap)
ratio = fine_range / coarse_range if coarse_range > 0 else np.inf

print(f"\n=== 多种子审计结果 ===")
print(f"增强诊断极差 (fine range): {fine_range:.6f}")
print(f"默认诊断极差 (coarse range): {coarse_range:.6f}")
if np.isfinite(ratio):
    print(f"极差比 (fine/coarse): {ratio:.2f}")
else:
    print("极差比: 默认诊断极差为零，无法计算比值")
print(f"增强诊断最小值位置: s={s_values[fine_min_idx]:.3f}, 值={mean_fine[fine_min_idx]:.6f}")
print(f"增强诊断最大值位置: s={s_values[fine_max_idx]:.3f}, 值={mean_fine[fine_max_idx]:.6f}")
print(f"能隙最小值位置: s={s_values[gap_min_idx]:.3f}, 值={mean_gap[gap_min_idx]:.6f}")
print(f"\n预设成功标准: fine/coarse 极差比 > 3.0")
print(f"实际比值: {ratio:.2f}" if np.isfinite(ratio) else "实际比值: inf")
print("结果: 关系度量有辨别能力。" if ratio > 3.0 else "结果: 关系度量无显著辨别能力，或默认诊断同样敏感。")

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
ax1.plot(s_values, mean_coarse, color='blue', label='Default (coarse)')
ax1.set_xlabel('Contradiction strength s')
ax1.set_ylabel('Default diagnosis')
ax1.set_title('Default Diagnosis (mean magnetization)')
ax1.legend()
ax1.grid(True, alpha=0.3)

ax2.plot(s_values, mean_fine, color='red', label='Enhanced (fine)')
ax2.fill_between(s_values, mean_fine - std_fine, mean_fine + std_fine, alpha=0.3, color='red')
ax2.set_xlabel('Contradiction strength s')
ax2.set_ylabel('Enhanced diagnosis')
ax2.set_title('Enhanced Diagnosis (corr. std)')
ax2.legend()
ax2.grid(True, alpha=0.3)
plt.suptitle(f'Small-World Scan (N={N}, k={k}, p={p}, edge={contradiction_edge})')
plt.tight_layout()
plt.savefig('small_world_scan.png', dpi=150)
print("\n图表已保存: small_world_scan.png")

fig, ax = plt.subplots(figsize=(10, 5))
ax.plot(s_values, mean_gap, color='green', label='Energy gap')
ax.set_xlabel('Contradiction strength s')
ax.set_ylabel('Energy gap')
ax.set_title(f'Energy Gap Across Scan (min={np.min(mean_gap):.6f})')
ax.legend()
ax.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig('small_world_gap.png', dpi=150)
print("能隙图已保存: small_world_gap.png")