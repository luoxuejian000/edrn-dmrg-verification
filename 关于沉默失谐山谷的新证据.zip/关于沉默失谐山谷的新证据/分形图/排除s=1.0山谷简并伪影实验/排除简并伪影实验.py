"""
简并度控制实验 —— 分形图 (0,6) 边
目标：检验增强诊断谷底是否依赖于基态简并。
方法：在 s∈[0,1] 范围内密集扫描，同步计算能隙和增强诊断。
预设判据（防工具理性悖论）：
  - 若增强诊断的局部极小值全部落在能隙≈0的位置，则简并伪影成立，分形图证据有缺陷。
  - 若存在增强诊断的局部极小值位于能隙>0.01的位置，则简并伪影被排除，分形图证据成立。
严格遵循：关系本体论、防工具理性、反对对齐。
"""

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh

# =============================================
# 公理一：Sierpinski 分形图生成（已验证正确）
# =============================================
def sierpinski_graph(level):
    """生成 Sierpinski gasket 图，返回节点数和无向边列表"""
    nodes = set([0, 1, 2])
    edges = set()

    def add_edge(a, b):
        edges.add((min(a, b), max(a, b)))

    def add_triangle(a, b, c):
        add_edge(a, b)
        add_edge(b, c)
        add_edge(c, a)

    def rec(v1, v2, v3, depth):
        if depth == 0:
            add_triangle(v1, v2, v3)
        else:
            max_id = max(nodes)
            m12 = max_id + 1; nodes.add(m12)
            m23 = max_id + 2; nodes.add(m23)
            m31 = max_id + 3; nodes.add(m31)
            rec(v1, m12, m31, depth-1)
            rec(v2, m23, m12, depth-1)
            rec(v3, m31, m23, depth-1)

    rec(0, 1, 2, level)
    return len(nodes), list(edges)

# =============================================
# 哈密顿量构建（泡利矩阵，标准 Heisenberg）
# =============================================
def graph_to_hamiltonian(N, edges, contradiction_edge, s):
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)

    def to_full(op, site):
        ops = [I2] * N
        ops[site] = op
        result = ops[0]
        for k in range(1, N):
            result = np.kron(result, ops[k])
        return result

    for (i, j) in edges:
        w = s if (i, j) == contradiction_edge or (j, i) == contradiction_edge else 1.0
        H += w * (to_full(sx, i) @ to_full(sx, j)).real
        H += w * (to_full(sy, i) @ to_full(sy, j)).real
        H += w * (to_full(sz, i) @ to_full(sz, j)).real
    return H.tocsc()

# =============================================
# 诊断函数：同时返回能隙和增强诊断
# =============================================
def diagnose_with_gap(N, edges, contradiction_edge, s, seed=0):
    H = graph_to_hamiltonian(N, edges, contradiction_edge, s)
    dim = 2**N
    rng = np.random.default_rng(seed)
    v0 = rng.random(dim)

    # 求最小的两个本征值，得到能隙
    eigenvalues, eigenvectors = eigsh(H, k=2, which='SA', v0=v0)
    gap = eigenvalues[1] - eigenvalues[0]
    gs = eigenvectors[:, 0]

    # 增强诊断：边关联涨落标准差
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    corrs = []
    for (i, j) in edges:
        ops = [I2] * N
        ops[i] = sz
        ops[j] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        corr = np.real(gs.conj().T @ op_full @ gs)
        corrs.append(corr)
    enhanced = np.std(corrs) if corrs else 0.0

    return gap, enhanced

# =============================================
# 主扫描：单种子，密集扫描 s∈[0,1]
# =============================================
def main_scan(N, edges, contradiction_edge, s_values, seed=0):
    gaps = []
    enhanceds = []
    for s in s_values:
        gap, enhanced = diagnose_with_gap(N, edges, contradiction_edge, s, seed=seed)
        gaps.append(gap)
        enhanceds.append(enhanced)
        print(f"s={s:.3f}: gap={gap:.6f}, enhanced={enhanced:.6f}")
    return np.array(gaps), np.array(enhanceds)

# =============================================
# 多种子验证：对谷底附近关键点
# =============================================
def multi_seed_check(N, edges, contradiction_edge, s_points, seeds):
    results = {}
    for s in s_points:
        gaps_seeds = []
        enhanced_seeds = []
        for seed in seeds:
            gap, enhanced = diagnose_with_gap(N, edges, contradiction_edge, s, seed=seed)
            gaps_seeds.append(gap)
            enhanced_seeds.append(enhanced)
        results[s] = {
            'gap_mean': np.mean(gaps_seeds),
            'gap_std': np.std(gaps_seeds),
            'enhanced_mean': np.mean(enhanced_seeds),
            'enhanced_std': np.std(enhanced_seeds),
        }
        print(f"s={s:.3f}: gap={np.mean(gaps_seeds):.6f}±{np.std(gaps_seeds):.6f}, "
              f"enhanced={np.mean(enhanced_seeds):.6f}±{np.std(enhanced_seeds):.6f}")
    return results

if __name__ == "__main__":
    N = 15
    edges = sierpinski_graph(2)[1]
    contradiction_edge = (0, 6)

    print(f"=== 简并度控制实验：分形图 N={N}, 边 (0,6) ===")
    print(f"图规模: {len(edges)} 条边")
    print(f"预设判据: 增强诊断局部极小值是否全部落在能隙≈0处")
    print()

    # 主扫描
    s_values = np.linspace(0.0, 1.0, 101)
    gaps, enhanceds = main_scan(N, edges, contradiction_edge, s_values, seed=0)

    # 保存主扫描数据
    np.savetxt('degeneracy_control_scan.csv',
               np.column_stack((s_values, gaps, enhanceds)),
               header='s,gap,enhanced', delimiter=',')

    # 多种子验证谷底附近
    print("\n=== 谷底附近多种子验证 (s∈[0.9,1.1]) ===")
    key_s = [0.9, 0.95, 1.0, 1.05, 1.1]
    seeds = [0, 1, 2, 3, 4]
    multi_results = multi_seed_check(N, edges, contradiction_edge, key_s, seeds)

    # 保存多种子验证结果
    with open('degeneracy_control_multiseed.csv', 'w') as f:
        f.write('s,gap_mean,gap_std,enhanced_mean,enhanced_std\n')
        for s, res in multi_results.items():
            f.write(f"{s:.3f},{res['gap_mean']:.6f},{res['gap_std']:.6f},"
                    f"{res['enhanced_mean']:.6f},{res['enhanced_std']:.6f}\n")

    # 简单绘图
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
    ax1.plot(s_values, gaps, 'o-', ms=3, label='Gap')
    ax1.set_xlabel('s'); ax1.set_ylabel('Energy gap'); ax1.set_title('Gap vs s')
    ax1.axhline(0, color='gray', ls='--'); ax1.grid(True, alpha=0.3)
    ax2.plot(s_values, enhanceds, 'o-', ms=3, color='red', label='Enhanced')
    ax2.set_xlabel('s'); ax2.set_ylabel('Enhanced diagnosis'); ax2.set_title('Enhanced vs s')
    ax2.grid(True, alpha=0.3)
    plt.suptitle('Degeneracy Control Experiment: Edge (0,6)')
    plt.tight_layout()
    plt.savefig('degeneracy_control.png', dpi=150)
    print("\n图表已保存至 degeneracy_control.png")
    print("原始数据已保存至 degeneracy_control_scan.csv / degeneracy_control_multiseed.csv")