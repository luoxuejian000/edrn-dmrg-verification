# 运行能隙与简并度审计代码
import numpy as np
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import time

def sierpinski_edges(level=2):
    triangles = [(0, 1, 2)]
    next_node = 3
    for _ in range(level):
        new_triangles = []
        for a, b, c in triangles:
            d = next_node; e = next_node + 1; f = next_node + 2
            next_node += 3
            new_triangles.append((a, d, f))
            new_triangles.append((b, d, e))
            new_triangles.append((c, e, f))
        triangles = new_triangles
    edges_set = set()
    for a, b, c in triangles:
        edges_set.add(tuple(sorted((a, b))))
        edges_set.add(tuple(sorted((b, c))))
        edges_set.add(tuple(sorted((c, a))))
    return [(i, j, 1.0) for (i, j) in sorted(edges_set)]

def build_hamiltonian_correct(N, edges, contradiction_edge, s):
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    ce_i, ce_j = contradiction_edge[0], contradiction_edge[1]
    for (i, j, w) in edges:
        if (i == ce_i and j == ce_j) or (i == ce_j and j == ce_i):
            J = s
        else:
            J = w
        for state in range(dim):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                H[state, flipped] += 2.0 * J
                H[state, state] -= J
            else:
                H[state, state] += J
    return H.tocsc()

def compute_enhanced(N, edges, psi):
    corrs = []
    for (i, j, _) in edges:
        corr = 0.0
        for state, amp in enumerate(psi):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            corr += np.abs(amp)**2 * (1 - 2 * bit_i) * (1 - 2 * bit_j)
        corrs.append(corr)
    return np.std(corrs)

def run_gap_audit(N=15, edge=(0,6), s_range=(0.8,1.2), n_points=11, n_seeds=2):
    edges = sierpinski_edges(level=2)
    N = max(max(i, j) for (i, j, _) in edges) + 1
    
    print("=" * 70)
    print("能隙与简并度审计")
    print(f"Sierpiński L2: N={N}, 矛盾边={edge}")
    print(f"扫描: s ∈ [{s_range[0]}, {s_range[1]}], {n_points}点, {n_seeds}种子")
    print("=" * 70)
    
    s_vals = np.linspace(s_range[0], s_range[1], n_points)
    
    gaps = []
    overlaps = []
    energies = []
    
    for idx, s in enumerate(s_vals):
        H = build_hamiltonian_correct(N, edges, edge, s)
        
        evals, evecs = eigsh(H, k=2, which='SA')
        order = np.argsort(evals)
        evals = evals[order]
        E0, E1 = evals[0], evals[1]
        gap = E1 - E0
        gaps.append(gap)
        energies.append((E0, E1))
        
        np.random.seed(0)
        v0 = np.random.randn(2**N); v0 /= np.linalg.norm(v0)
        _, psi0_vec = eigsh(H, k=1, which='SA', v0=v0)
        psi0 = psi0_vec[:, 0]
        
        np.random.seed(1)
        v0 = np.random.randn(2**N); v0 /= np.linalg.norm(v0)
        _, psi0_vec2 = eigsh(H, k=1, which='SA', v0=v0)
        psi0_2 = psi0_vec2[:, 0]
        
        overlap = np.abs(np.dot(psi0.conj(), psi0_2))**2
        overlaps.append(overlap)
        
        print(f"s={s:.3f}: E0={E0:.6f}, E1={E1:.6f}, gap={gap:.6f}, overlap(seed0,seed1)={overlap:.6f}")
    
    gaps = np.array(gaps)
    overlaps = np.array(overlaps)
    energies = np.array(energies)
    
    print("\n" + "=" * 70)
    print("审计结果")
    print("=" * 70)
    
    min_gap_idx = np.argmin(gaps)
    print(f"最小能隙: {gaps[min_gap_idx]:.6f} 在 s={s_vals[min_gap_idx]:.3f}")
    print(f"谷底位置 s=1.000 处的能隙: {gaps[np.argmin(np.abs(s_vals-1.0))]:.6f}")
    
    if gaps.min() < 1e-4:
        print("\n⚠️ 能隙接近零：基态可能存在简并。谷可能受简并选择影响。")
    else:
        print("\n✅ 能隙非零：基态非简并。谷不是简并伪影。")
    
    print(f"\n种子间基态重叠: 均值={overlaps.mean():.6f}, 最小值={overlaps.min():.6f} (在s={s_vals[np.argmin(overlaps)]:.3f})")
    if overlaps.min() < 0.9:
        print("⚠️ 某个s值处，不同种子选择了不同的基态向量。这可能导致深度波动。")
    else:
        print("✅ 所有s值处，不同种子选择了相同的基态。深度波动不是简并选择造成的。")
    
    np.savetxt('gap_audit_edge_0_6.csv',
               np.column_stack((s_vals, gaps, overlaps)),
               header='s,gap,overlap', delimiter=',')
    
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    axes[0].plot(s_vals, gaps, 'o-', color='#1f77b4')
    axes[0].axvline(1.0, color='gray', ls='--', alpha=0.5)
    axes[0].set_xlabel('s')
    axes[0].set_ylabel('Energy gap')
    axes[0].set_title('Gap vs s')
    axes[0].grid(True, alpha=0.3)
    
    axes[1].plot(s_vals, overlaps, 's-', color='#d62728')
    axes[1].axvline(1.0, color='gray', ls='--', alpha=0.5)
    axes[1].set_xlabel('s')
    axes[1].set_ylabel('Seed overlap')
    axes[1].set_title('Ground-state seed overlap')
    axes[1].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('gap_audit_edge_0_6.png', dpi=150)
    print("\n数据已保存: gap_audit_edge_0_6.csv")
    print("绘图已保存: gap_audit_edge_0_6.png")
    return s_vals, gaps, overlaps, energies

gap_audit_results = run_gap_audit(N=15, edge=(0,6), s_range=(0.8,1.2), n_points=11, n_seeds=2)