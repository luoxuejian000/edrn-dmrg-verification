"""
多种子审计 —— 边 (0,6) 谷深可复现性检验
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def sierpinski_edges(level=2):
    triangles = [(0, 1, 2)]
    next_node = 3
    for _ in range(level):
        new_triangles = []
        for a, b, c in triangles:
            d = next_node
            e = next_node + 1
            f = next_node + 2
            next_node += 3
            new_triangles.append((a, d, f))
            new_triangles.append((b, d, e))
            new_triangles.append((c, e, f))
        triangles = new_triangles
    edges_set = set()
    for a, b, c in triangles:
        edges_set.add(tuple(sorted((a, b))))
        edges_set.add(tuple(sorted((b, c))))
        edges_set.add(tuple(sorted((c, a))))
    return [(i, j, 1.0) for (i, j) in sorted(edges_set)]

def build_hamiltonian_correct(N, edges, contradiction_edge, s):
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    for (i, j, w) in edges:
        if (i, j) == contradiction_edge or (j, i) == contradiction_edge:
            J = s
        else:
            J = w
        for state in range(dim):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                H[state, flipped] += 2.0 * J
                H[state, state] -= J
            else:
                H[state, state] += J
    return H.tocsc()

def compute_enhanced(N, edges, psi):
    corrs = []
    for (i, j, _) in edges:
        corr = 0.0
        for state, amp in enumerate(psi):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            corr += np.abs(amp)**2 * (1 - 2 * bit_i) * (1 - 2 * bit_j)
        corrs.append(corr)
    return np.std(corrs)

def run_multi_seed_audit(N=15, contradiction_edge=(0,6), n_seeds=5, s_vals=None):
    if s_vals is None:
        s_vals = np.linspace(0.0, 3.0, 13)
    
    edges = sierpinski_edges(level=2)
    N = max(max(i,j) for (i,j,_) in edges) + 1
    
    # 验证边存在
    edge_set = {(i,j) for (i,j,_) in edges}
    if contradiction_edge not in edge_set and (contradiction_edge[1], contradiction_edge[0]) not in edge_set:
        print(f"❌ 边 {contradiction_edge} 不存在")
        return
    
    print(f"多种子审计：边 {contradiction_edge}")
    print(f"Sierpiński L2: N={N}, 边数={len(edges)}")
    print(f"扫描 s ∈ [{s_vals[0]}, {s_vals[-1]}], {len(s_vals)}点, {n_seeds}个Lanczos种子\n")
    
    all_enhanced = []
    all_valley_positions = []
    all_valley_depths = []
    
    for seed in range(n_seeds):
        enhanceds = []
        for s in s_vals:
            H = build_hamiltonian_correct(N, edges, contradiction_edge, s)
            np.random.seed(seed)
            v0 = np.random.randn(2**N)
            v0 /= np.linalg.norm(v0)
            evals, evecs = eigsh(H, k=1, which='SA', v0=v0)
            psi = evecs[:, 0]
            enhanceds.append(compute_enhanced(N, edges, psi))
        enhanceds = np.array(enhanceds)
        all_enhanced.append(enhanceds)
        
        valley_idx = np.argmin(enhanceds)
        valley_s = s_vals[valley_idx]
        left_shoulder = enhanceds[0]
        valley_depth = left_shoulder - enhanceds[valley_idx]
        
        all_valley_positions.append(valley_s)
        all_valley_depths.append(valley_depth)
        
        print(f"种子 {seed}: 谷位置 s={valley_s:.3f}, 谷深={valley_depth:.6f}, 极小值={enhanceds[valley_idx]:.6f}")
    
    # 统计
    positions = np.array(all_valley_positions)
    depths = np.array(all_valley_depths)
    
    print("\n" + "="*60)
    print("多种子统计")
    print("="*60)
    print(f"谷位置: 均值={positions.mean():.4f}, 标准差={positions.std():.4f}")
    print(f"谷深度: 均值={depths.mean():.6f}, 标准差={depths.std():.6f}")
    print(f"位置范围: [{positions.min():.4f}, {positions.max():.4f}]")
    print(f"深度范围: [{depths.min():.6f}, {depths.max():.6f}]")
    print("="*60)
    
    # 判断
    if positions.std() < 0.01 and depths.std() < 0.002:
        print("✅ 谷在多种子下可复现，位置和深度均稳定")
    elif positions.std() < 0.01:
        print("⚠️ 谷位置可复现，但深度存在一定波动")
    else:
        print("❌ 谷位置在不同种子间漂移，需要进一步分析")
    
    # 保存数据
    header = 's,' + ','.join([f'seed{i}' for i in range(n_seeds)])
    data = np.column_stack([s_vals] + all_enhanced)
    np.savetxt('multi_seed_audit_edge_0_6.csv', data, header=header, delimiter=',')
    print("\n数据已保存: multi_seed_audit_edge_0_6.csv")
    
    # 绘图
    plt.figure(figsize=(10, 6))
    for i in range(n_seeds):
        plt.plot(s_vals, all_enhanced[i], '-', lw=1, alpha=0.7, label=f'Seed {i}')
    plt.xlabel('Contradiction strength s', fontsize=13)
    plt.ylabel('Enhanced diagnosis (edge corr std)', fontsize=13)
    plt.title(f'Multi-Seed Audit: Edge (0,6), L2 Sierpinski', fontsize=14)
    plt.legend(fontsize=9)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('multi_seed_audit_edge_0_6.png', dpi=150)
    print("绘图已保存: multi_seed_audit_edge_0_6.png")
    return {
        's_vals': s_vals,
        'all_enhanced': np.array(all_enhanced),
        'positions': positions,
        'depths': depths,
        'edges': edges,
    }

multi_seed_result = run_multi_seed_audit(N=15, contradiction_edge=(0,6), n_seeds=5)