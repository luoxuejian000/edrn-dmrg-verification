"""
矛盾边全面扫描 —— 关系本体论下的边身份检验
目标：在 L2 Sierpiński 垫片（N=15，27条边）中，识别哪些边作为矛盾边时，
      会使精细诊断产生显著的非单调响应。
方法：对每条边分别执行扫描 s ∈ [0,3]，计算精细诊断的极差（max-min）
      和谷深度（最左肩 - 谷底），并报告。
严格遵循：关系本体论、防工具理性、反对对齐。
"""
import numpy as np
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import time

def sierpinski_edges(level=2):
    triangles = [(0, 1, 2)]
    next_node = 3
    for _ in range(level):
        new_triangles = []
        for a, b, c in triangles:
            d = next_node
            e = next_node + 1
            f = next_node + 2
            next_node += 3
            new_triangles.append((a, d, f))
            new_triangles.append((b, d, e))
            new_triangles.append((c, e, f))
        triangles = new_triangles
    edges_set = set()
    for a, b, c in triangles:
        edges_set.add(tuple(sorted((a, b))))
        edges_set.add(tuple(sorted((b, c))))
        edges_set.add(tuple(sorted((c, a))))
    return [(i, j, 1.0) for (i, j) in sorted(edges_set)]

def build_hamiltonian_correct(N, edges, contradiction_edge, s):
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    for (i, j, w) in edges:
        if (i, j) == contradiction_edge or (j, i) == contradiction_edge:
            J = s
        else:
            J = w
        for state in range(dim):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                H[state, flipped] += 2.0 * J
                H[state, state] -= J
            else:
                H[state, state] += J
    return H.tocsc()

def compute_enhanced(N, edges, psi):
    corrs = []
    for (i, j, _) in edges:
        corr = 0.0
        for state, amp in enumerate(psi):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            corr += np.abs(amp)**2 * (1 - 2 * bit_i) * (1 - 2 * bit_j)
        corrs.append(corr)
    return np.std(corrs)

def run_edge_scan(N=15, s_vals=np.linspace(0, 3, 13), v0_seed=0):
    edges = sierpinski_edges(level=2)
    N = max(max(i, j) for (i, j, _) in edges) + 1
    print(f"扫描总边数: {len(edges)}")
    print(f"矛盾边扫描: 每条边逐一作为矛盾边，s ∈ [0,3]")
    
    results = []
    for edge in edges:
        enhanceds = []
        for s in s_vals:
            H = build_hamiltonian_correct(N, edges, edge, s)
            np.random.seed(v0_seed)
            v0 = np.random.randn(2**N)
            v0 /= np.linalg.norm(v0)
            evals, evecs = eigsh(H, k=1, which='SA', v0=v0)
            psi = evecs[:, 0]
            enhanceds.append(compute_enhanced(N, edges, psi))
        enhanceds = np.array(enhanceds)
        # 计算极差和谷深度
        range_val = np.max(enhanceds) - np.min(enhanceds)
        # 找到谷底和左肩
        valley_idx = np.argmin(enhanceds)
        left_shoulder = enhanceds[0]
        valley_depth = left_shoulder - enhanceds[valley_idx]
        # 记录
        results.append({
            'edge': edge,
            'range': range_val,
            'depth': valley_depth,
            'valley_idx': valley_idx,
            'valley_s': s_vals[valley_idx],
            'min_val': enhanceds[valley_idx],
        })
        print(f"边 {edge}: 极差={range_val:.6f}, 谷深度={valley_depth:.6f}, 谷位置s={s_vals[valley_idx]:.2f}")
    
    # 按谷深度排序
    results.sort(key=lambda x: x['depth'], reverse=True)
    print("\n按谷深度排序的前10条边：")
    for i, r in enumerate(results[:10]):
        print(f"  {i+1}. 边{r['edge']}: 深度={r['depth']:.6f}, 极差={r['range']:.6f}, 谷位置={r['valley_s']:.2f}")
    
    return results

if __name__ == "__main__":
    results = run_edge_scan()
    # 保存前10条结果供参考
    np.savetxt('edge_scan_results.csv',
               np.array([(r['edge'][0], r['edge'][1], r['depth'], r['range'], r['valley_s'])
                         for r in results]),
               header='edge_i,edge_j,depth,range,valley_s', delimiter=',')