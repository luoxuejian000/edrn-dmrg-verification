import numpy as np
from scipy.sparse import lil_matrix, csc_matrix
from scipy.sparse.linalg import eigsh
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import time


def sierpinski_edges(level=2):
    triangles = [(0, 1, 2)]
    next_node = 3
    for _ in range(level):
        new_triangles = []
        for a, b, c in triangles:
            d = next_node
            e = next_node + 1
            f = next_node + 2
            next_node += 3
            new_triangles.append((a, d, f))
            new_triangles.append((b, d, e))
            new_triangles.append((c, e, f))
        triangles = new_triangles
    edges_set = set()
    for a, b, c in triangles:
        edges_set.add(tuple(sorted((a, b))))
        edges_set.add(tuple(sorted((b, c))))
        edges_set.add(tuple(sorted((c, a))))
    return [(i, j, 1.0) for (i, j) in sorted(edges_set)]


def edge_operator(N, edge):
    i, j = edge
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    for state in range(dim):
        bit_i = (state >> i) & 1
        bit_j = (state >> j) & 1
        if bit_i != bit_j:
            flipped = state ^ (1 << i) ^ (1 << j)
            H[state, flipped] += 2.0
            H[state, state] -= 1.0
        else:
            H[state, state] += 1.0
    return H.tocsc()


def compute_corr_signs(N, edges):
    states = np.arange(2**N, dtype=np.uint32)
    signs = np.empty((len(edges), 2**N), dtype=np.int8)
    for k, (i, j, _) in enumerate(edges):
        bit_i = (states >> i) & 1
        bit_j = (states >> j) & 1
        signs[k] = 1 - 2 * (bit_i ^ bit_j)
    return signs


def run_edge_scan_fast(N=15, s_vals=np.linspace(0, 3, 13), v0_seed=0):
    edges = sierpinski_edges(level=2)
    N = max(max(i, j) for (i, j, _) in edges) + 1
    dim = 2**N
    print(f"扫描总边数: {len(edges)}")
    print("预构造边算符与基础哈密顿量...")
    t0 = time.time()
    edge_pairs = [(i, j) for i, j, _ in edges]
    edge_ops = [edge_operator(N, e) for e in edge_pairs]
    H_base = sum(edge_ops[1:], edge_ops[0].copy()).tocsc()
    corr_signs = compute_corr_signs(N, edges)
    rng = np.random.default_rng(v0_seed)
    v0 = rng.standard_normal(dim)
    v0 /= np.linalg.norm(v0)
    print(f"预构造完成，用时 {time.time() - t0:.2f}s")
    print("矛盾边扫描: 每条边逐一作为矛盾边，s ∈ [0,3]")

    results = []
    curves = {}
    for edge_idx, edge in enumerate(edge_pairs):
        enhanceds = []
        evals_curve = []
        for s in s_vals:
            H = (H_base + (float(s) - 1.0) * edge_ops[edge_idx]).tocsc()
            evals, evecs = eigsh(H, k=1, which='SA', v0=v0, tol=1e-8, maxiter=10000)
            psi = evecs[:, 0]
            probs = np.abs(psi)**2
            corrs = corr_signs @ probs
            enhanceds.append(float(np.std(corrs)))
            evals_curve.append(float(evals[0]))
        enhanceds = np.array(enhanceds)
        range_val = float(np.max(enhanceds) - np.min(enhanceds))
        valley_idx = int(np.argmin(enhanceds))
        left_shoulder = float(enhanceds[0])
        valley_depth = float(left_shoulder - enhanceds[valley_idx])
        result = {
            'edge': edge,
            'range': range_val,
            'depth': valley_depth,
            'valley_idx': valley_idx,
            'valley_s': float(s_vals[valley_idx]),
            'min_val': float(enhanceds[valley_idx]),
            'max_val': float(np.max(enhanceds)),
        }
        results.append(result)
        curves[edge] = {'s_vals': np.array(s_vals), 'enhanced': enhanceds, 'evals': np.array(evals_curve)}
        print(f"边 {edge}: 极差={range_val:.6f}, 谷深度={valley_depth:.6f}, 谷位置s={s_vals[valley_idx]:.2f}")

    results.sort(key=lambda x: x['depth'], reverse=True)
    print("\n按谷深度排序的前10条边：")
    for i, r in enumerate(results[:10]):
        print(f"  {i+1}. 边{r['edge']}: 深度={r['depth']:.6f}, 极差={r['range']:.6f}, 谷位置={r['valley_s']:.2f}")

    np.savetxt(
        'edge_scan_results.csv',
        np.array([(r['edge'][0], r['edge'][1], r['depth'], r['range'], r['valley_s'], r['min_val'], r['max_val']) for r in results]),
        header='edge_i,edge_j,depth,range,valley_s,min_val,max_val',
        delimiter=','
    )
    return results, curves

results, curves = run_edge_scan_fast()