"""
分形图多种子审计 —— 边(0,6) 可复现性检验
与小世界图(0,6)审计使用完全相同的协议，以便直接对比。
"""
import numpy as np
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def sierpinski_edges(level=2):
    triangles = [(0, 1, 2)]
    next_node = 3
    for _ in range(level):
        new_triangles = []
        for a, b, c in triangles:
            d, e, f = next_node, next_node+1, next_node+2
            next_node += 3
            new_triangles.extend([(a,d,f), (b,d,e), (c,e,f)])
        triangles = new_triangles
    edges_set = set()
    for a, b, c in triangles:
        for u, v in [(a,b),(b,c),(c,a)]:
            edges_set.add(tuple(sorted((u,v))))
    return [(i,j,1.0) for (i,j) in sorted(edges_set)]

def build_hamiltonian_correct(N, edges, contradiction_edge, s):
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    ce_i, ce_j = contradiction_edge[0], contradiction_edge[1]
    for (i, j, w) in edges:
        J = s if (i==ce_i and j==ce_j) or (i==ce_j and j==ce_i) else w
        for state in range(dim):
            bit_i, bit_j = (state>>i)&1, (state>>j)&1
            if bit_i != bit_j:
                flipped = state ^ (1<<i) ^ (1<<j)
                H[state, flipped] += 2.0 * J
                H[state, state] -= J
            else:
                H[state, state] += J
    return H.tocsc()

def compute_enhanced(N, edges, psi):
    corrs = []
    for (i,j,_) in edges:
        corr = sum(np.abs(amp)**2*(1-2*((state>>i)&1))*(1-2*((state>>j)&1))
                   for state, amp in enumerate(psi))
        corrs.append(corr)
    return np.std(corrs)

def run_fractal_multi_seed(contradiction_edge=(0,6), n_seeds=5, s_range=(0,1), n_points=101):
    edges = sierpinski_edges(level=2)
    N = max(max(i,j) for (i,j,_) in edges) + 1
    s_vals = np.linspace(s_range[0], s_range[1], n_points)
    
    print("="*70)
    print(f"分形图多种子审计 —— 边{contradiction_edge}")
    print(f"N={N}, 边数={len(edges)}, s∈[{s_range[0]},{s_range[1]}], {n_points}点, {n_seeds}种子")
    print("="*70)
    
    all_enhanceds = []
    valley_positions = []
    valley_depths = []
    
    for seed in range(n_seeds):
        enhanceds = []
        for s in s_vals:
            H = build_hamiltonian_correct(N, edges, contradiction_edge, s)
            np.random.seed(seed)
            v0 = np.random.randn(2**N)
            v0 /= np.linalg.norm(v0)
            _, evecs = eigsh(H, k=1, which='SA', v0=v0)
            psi = evecs[:, 0]
            enhanceds.append(compute_enhanced(N, edges, psi))
        enhanceds = np.array(enhanceds)
        all_enhanceds.append(enhanceds)
        
        valley_idx = np.argmin(enhanceds)
        v_pos = s_vals[valley_idx]
        v_depth = enhanceds[0] - enhanceds[valley_idx]
        valley_positions.append(v_pos)
        valley_depths.append(v_depth)
        print(f"种子 {seed}: 谷位置s={v_pos:.4f}, 谷值={enhanceds[valley_idx]:.6f}, 深度={v_depth:.6f}")
    
    valley_positions = np.array(valley_positions)
    valley_depths = np.array(valley_depths)
    print("\n" + "="*70)
    print("可复现性统计")
    print("="*70)
    print(f"谷位置: 均值={valley_positions.mean():.4f}, 标准差={valley_positions.std():.4f}")
    print(f"谷深度: 均值={valley_depths.mean():.6f}, 标准差={valley_depths.std():.6f}")
    
    if valley_positions.std() < 0.05 and valley_depths.std() < 0.01:
        print("\n✅ 判定：谷可复现。这是强证据。")
    elif valley_positions.std() < 0.1 and valley_depths.std() < 0.02:
        print("\n⚠️ 判定：谷部分可复现。")
    else:
        print("\n❌ 判定：谷不可复现。")
    
    all_enhanceds = np.array(all_enhanceds)
    np.savetxt('fractal_multi_seed_audit.csv',
               np.column_stack([s_vals] + [all_enhanceds[i] for i in range(n_seeds)]),
               header='s,' + ','.join([f'seed{i}' for i in range(n_seeds)]), delimiter=',')
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
    for i in range(n_seeds):
        ax1.plot(s_vals, all_enhanceds[i], '-', lw=1, alpha=0.7, label=f'Seed {i}')
    ax1.set_xlabel('s'); ax1.set_ylabel('Enhanced'); ax1.set_title('Fractal Multi-Seed: Edge (0,6)')
    ax1.legend(fontsize=8); ax1.grid(True, alpha=0.3)
    
    std_across = all_enhanceds.std(axis=0)
    ax2.plot(s_vals, std_across, '-', color='black', lw=2)
    ax2.set_xlabel('s'); ax2.set_ylabel('Cross-seed std'); ax2.set_title('Numerical Uncertainty')
    ax2.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('fractal_multi_seed_audit.png', dpi=150)
    print("\n数据已保存: fractal_multi_seed_audit.csv")
    print("绘图已保存: fractal_multi_seed_audit.png")

if __name__ == "__main__":
    run_fractal_multi_seed(contradiction_edge=(0,6), n_seeds=5, s_range=(0,1), n_points=101)