"""
L1 分形图多种子审计 —— 修正版
使用正确的 Sierpinski gasket 生成函数 (N=6, E=9)
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh


def sierpinski_graph(level):
    """
    生成 Sierpinski gasket 图。
    level=0: 3节点 3边
    level=1: 6节点 9边
    level=2: 15节点 27边
    返回: 节点数 N, 无向边列表 (去重)
    """
    nodes = set([0, 1, 2])
    edges = set()
    
    def add_edge(a, b):
        edges.add((min(a, b), max(a, b)))
    
    def add_triangle(a, b, c):
        add_edge(a, b)
        add_edge(b, c)
        add_edge(c, a)
    
    def rec(v1, v2, v3, depth):
        if depth == 0:
            add_triangle(v1, v2, v3)
        else:
            max_id = max(nodes)
            m12 = max_id + 1; nodes.add(m12)
            m23 = max_id + 2; nodes.add(m23)
            m31 = max_id + 3; nodes.add(m31)
            rec(v1, m12, m31, depth-1)
            rec(v2, m23, m12, depth-1)
            rec(v3, m31, m23, depth-1)
    
    rec(0, 1, 2, level)
    N = len(nodes)
    edges_list = list(edges)
    return N, edges_list


def graph_to_hamiltonian(N, edges, contradiction_edge, s):
    """标准各向同性 Heisenberg 哈密顿量（泡利矩阵版）"""
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    
    def to_full(op, site):
        ops = [I2] * N
        ops[site] = op
        result = ops[0]
        for k in range(1, N):
            result = np.kron(result, ops[k])
        return result
    
    for (i, j) in edges:
        w = s if (i, j) == contradiction_edge or (j, i) == contradiction_edge else 1.0
        H += w * (to_full(sx, i) @ to_full(sx, j)).real
        H += w * (to_full(sy, i) @ to_full(sy, j)).real
        H += w * (to_full(sz, i) @ to_full(sz, j)).real
    return H.tocsc()


def diagnose(N, edges, contradiction_edge, s, num_eig=3, seed=None):
    H = graph_to_hamiltonian(N, edges, contradiction_edge, s)
    v0 = None
    if seed is not None:
        rng = np.random.default_rng(seed)
        v0 = rng.random(2**N)
    energies, states = eigsh(H, k=min(num_eig, 2**N-1), which='SA', v0=v0)
    gs = states[:, 0]
    
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    mag = 0.0
    for i in range(N):
        ops = [I2] * N
        ops[i] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        mag += np.real(gs.conj().T @ op_full @ gs)
    coarse = abs(mag / N)
    
    corrs = []
    for (i, j) in edges:
        ops = [I2] * N
        ops[i] = sz
        ops[j] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        corr = np.real(gs.conj().T @ op_full @ gs)
        corrs.append(corr)
    fine = np.std(corrs) if corrs else 0.0
    return coarse, fine


def multi_seed_audit(N, edges, contradiction_edge, s_values, seeds):
    results = {}
    for seed in seeds:
        fine_curve = []
        for s in s_values:
            _, fine = diagnose(N, edges, contradiction_edge, s, num_eig=3, seed=seed)
            fine_curve.append(fine)
        results[seed] = np.array(fine_curve)
    return results


level = 1
N, edges = sierpinski_graph(level)
print(f"=== L1 分形图 (N={N}, {len(edges)} 条边) ===")
assert N == 6 and len(edges) == 9, f"图生成错误: 应 N=6, E=9，实际 N={N}, E={len(edges)}"

contradiction_edge = (0, 3)
s_values = np.linspace(0.0, 1.0, 101)
seeds = [0, 1, 2, 3, 4]

print(f"矛盾边: {contradiction_edge}")
print(f"扫描: {len(s_values)} 点, {len(seeds)} 种子")

results = multi_seed_audit(N, edges, contradiction_edge, s_values, seeds)

for seed in seeds:
    np.savetxt(f'L1_edge03_seed{seed}.csv',
               np.column_stack((s_values, results[seed])),
               header='s,fine', delimiter=',')

all_curves = np.array([results[s] for s in seeds])
mean_curve = np.mean(all_curves, axis=0)
std_curve = np.std(all_curves, axis=0)
min_idx = np.argmin(mean_curve)
min_s = s_values[min_idx]
min_val = mean_curve[min_idx]
min_std = std_curve[min_idx]
range_val = np.max(mean_curve) - np.min(mean_curve)

print(f"\n=== L1 多种子审计结果 ===")
print(f"谷位置: s={min_s:.3f}")
print(f"谷深度: {min_val:.6f}±{min_std:.6f}")
print(f"增强诊断极差: {range_val:.6f}")
print(f"\n对照: L2 (N=15) LDS Valley 深度 0.0998±0.0064")
print(f"L1 谷深: {min_val:.6f}±{min_std:.6f}")
if min_val < 0.05:
    print("结论: L1 谷深显著小于 L2，与有限尺寸趋势一致。")
else:
    print("结论: L1 谷深与 L2 相当，有限尺寸趋势不明显。")