import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.sparse import coo_matrix, diags
from scipy.sparse.linalg import eigsh
import pandas as pd

# =============================================
# 公理一：Sierpinski 分形图生成（保持原定义）
# =============================================
def sierpinski_graph(level):
    """生成 Sierpinski gasket 图，返回节点数和无向边列表"""
    nodes = set([0, 1, 2])
    edges = set()

    def add_edge(a, b):
        edges.add((min(a, b), max(a, b)))

    def add_triangle(a, b, c):
        add_edge(a, b)
        add_edge(b, c)
        add_edge(c, a)

    def rec(v1, v2, v3, depth):
        if depth == 0:
            add_triangle(v1, v2, v3)
        else:
            max_id = max(nodes)
            m12 = max_id + 1; nodes.add(m12)
            m23 = max_id + 2; nodes.add(m23)
            m31 = max_id + 3; nodes.add(m31)
            rec(v1, m12, m31, depth-1)
            rec(v2, m23, m12, depth-1)
            rec(v3, m31, m23, depth-1)

    rec(0, 1, 2, level)
    return len(nodes), sorted(edges)

# =============================================
# 稀疏位运算版 Heisenberg 哈密顿量
# 与原始 Pauli 定义等价：σxσx + σyσy + σzσz
# 但避免构造 32768 x 32768 的稠密 Kronecker 矩阵
# =============================================
def edge_hamiltonian_sparse(N, edge):
    dim = 2**N
    i, j = edge
    bi = 1 << (N - 1 - i)
    bj = 1 << (N - 1 - j)
    states = np.arange(dim, dtype=np.int64)
    si = (states & bi) != 0
    sj = (states & bj) != 0
    same = si == sj

    diag_vals = np.where(same, 1.0, -1.0)
    H_diag = diags(diag_vals, offsets=0, shape=(dim, dim), format='coo')

    anti_states = states[~same]
    flipped = anti_states ^ bi ^ bj
    off_vals = np.full(len(anti_states), 2.0, dtype=float)
    H_off = coo_matrix((off_vals, (flipped, anti_states)), shape=(dim, dim))

    return (H_diag + H_off).tocsc()

def prepare_sparse_problem(N, edges, contradiction_edge):
    contradiction_edge = tuple(sorted(contradiction_edge))
    dim = 2**N
    H_static = coo_matrix((dim, dim), dtype=float).tocsc()
    H_contra = coo_matrix((dim, dim), dtype=float).tocsc()
    edge_ops = {}

    for edge in edges:
        edge = tuple(sorted(edge))
        H_edge = edge_hamiltonian_sparse(N, edge)
        edge_ops[edge] = H_edge
        if edge == contradiction_edge:
            H_contra = H_contra + H_edge
        else:
            H_static = H_static + H_edge

    states = np.arange(dim, dtype=np.int64)
    corr_signs = []
    for i, j in edges:
        bi = 1 << (N - 1 - i)
        bj = 1 << (N - 1 - j)
        si = (states & bi) != 0
        sj = (states & bj) != 0
        corr_signs.append(np.where(si == sj, 1.0, -1.0))
    corr_signs = np.asarray(corr_signs)

    return H_static.tocsc(), H_contra.tocsc(), corr_signs

def diagnose_with_gap_sparse(H_static, H_contra, corr_signs, s, seed=0):
    dim = H_static.shape[0]
    H = H_static + s * H_contra
    rng = np.random.default_rng(seed)
    v0 = rng.random(dim)

    eigenvalues, eigenvectors = eigsh(H, k=2, which='SA', v0=v0, tol=1e-9, maxiter=5000)
    order = np.argsort(eigenvalues)
    eigenvalues = eigenvalues[order]
    eigenvectors = eigenvectors[:, order]

    gap = float(eigenvalues[1] - eigenvalues[0])
    gs = eigenvectors[:, 0]
    probs = np.abs(gs)**2
    corrs = corr_signs @ probs
    enhanced = float(np.std(corrs)) if len(corrs) else 0.0
    return gap, enhanced

def main_scan_sparse(H_static, H_contra, corr_signs, s_values, seed=0):
    gaps = []
    enhanceds = []
    for s in s_values:
        gap, enhanced = diagnose_with_gap_sparse(H_static, H_contra, corr_signs, float(s), seed=seed)
        gaps.append(gap)
        enhanceds.append(enhanced)
        print(f"s={s:.3f}: gap={gap:.6f}, enhanced={enhanced:.6f}")
    return np.array(gaps), np.array(enhanceds)

def multi_seed_check_sparse(H_static, H_contra, corr_signs, s_points, seeds):
    results = {}
    for s in s_points:
        gaps_seeds = []
        enhanced_seeds = []
        for seed in seeds:
            gap, enhanced = diagnose_with_gap_sparse(H_static, H_contra, corr_signs, float(s), seed=seed)
            gaps_seeds.append(gap)
            enhanced_seeds.append(enhanced)
        results[float(s)] = {
            'gap_mean': float(np.mean(gaps_seeds)),
            'gap_std': float(np.std(gaps_seeds)),
            'enhanced_mean': float(np.mean(enhanced_seeds)),
            'enhanced_std': float(np.std(enhanced_seeds)),
        }
        print(f"s={s:.3f}: gap={np.mean(gaps_seeds):.6f}±{np.std(gaps_seeds):.6f}, "
              f"enhanced={np.mean(enhanced_seeds):.6f}±{np.std(enhanced_seeds):.6f}")
    return results

def local_minima_indices(y):
    y = np.asarray(y)
    return np.where((y[1:-1] < y[:-2]) & (y[1:-1] < y[2:]))[0] + 1

N = 15
edges = sierpinski_graph(2)[1]
contradiction_edge = (0, 6)
contradiction_edge_sorted = tuple(sorted(contradiction_edge))

print(f"=== 简并度控制实验：分形图 N={N}, 边 (0,6) ===")
print(f"图规模: {len(edges)} 条边")
print(f"边 (0,6) 是否存在: {contradiction_edge_sorted in set(edges)}")
print(f"预设判据: 增强诊断局部极小值是否全部落在能隙≈0处")
print()

H_static, H_contra, corr_signs = prepare_sparse_problem(N, edges, contradiction_edge)

s_values = np.linspace(0.0, 1.0, 101)
gaps, enhanceds = main_scan_sparse(H_static, H_contra, corr_signs, s_values, seed=0)

scan_df = pd.DataFrame({'s': s_values, 'gap': gaps, 'enhanced': enhanceds})
scan_df.to_csv('degeneracy_control_scan.csv', index=False)

min_idx = local_minima_indices(enhanceds)
local_minima_df = scan_df.iloc[min_idx].copy().reset_index(drop=True)
local_minima_df['criterion_gap_gt_0_01'] = local_minima_df['gap'] > 0.01
local_minima_df.to_csv('degeneracy_control_local_minima.csv', index=False)

print("\n=== 增强诊断局部极小值 ===")
if len(local_minima_df) == 0:
    print("未检测到严格局部极小值。")
else:
    print(local_minima_df.to_string(index=False))

print("\n=== 谷底附近多种子验证 (s∈[0.9,1.1]) ===")
key_s = [0.9, 0.95, 1.0, 1.05, 1.1]
seeds = [0, 1, 2, 3, 4]
multi_results = multi_seed_check_sparse(H_static, H_contra, corr_signs, key_s, seeds)

multiseed_df = pd.DataFrame([
    {'s': s, **res} for s, res in multi_results.items()
])
multiseed_df.to_csv('degeneracy_control_multiseed.csv', index=False)

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
ax1.plot(s_values, gaps, 'o-', ms=3, label='Gap')
ax1.set_xlabel('s'); ax1.set_ylabel('Energy gap'); ax1.set_title('Gap vs s')
ax1.axhline(0, color='gray', ls='--'); ax1.axhline(0.01, color='orange', ls=':', label='gap=0.01')
ax1.grid(True, alpha=0.3); ax1.legend()
ax2.plot(s_values, enhanceds, 'o-', ms=3, color='red', label='Enhanced')
if len(local_minima_df) > 0:
    ax2.scatter(local_minima_df['s'], local_minima_df['enhanced'], color='black', s=40, zorder=5, label='local minima')
ax2.set_xlabel('s'); ax2.set_ylabel('Enhanced diagnosis'); ax2.set_title('Enhanced vs s')
ax2.grid(True, alpha=0.3); ax2.legend()
plt.suptitle('Degeneracy Control Experiment: Edge (0,6)')
plt.tight_layout()
plt.savefig('degeneracy_control.png', dpi=150)
plt.close(fig)

if len(local_minima_df) > 0 and bool(local_minima_df['criterion_gap_gt_0_01'].any()):
    verdict = '简并伪影被排除：存在增强诊断局部极小值位于 gap > 0.01。'
elif len(local_minima_df) > 0:
    verdict = '简并伪影成立：检测到的增强诊断局部极小值全部落在 gap <= 0.01。'
else:
    verdict = '未检测到严格局部极小值，无法按预设判据给出二分结论。'

print("\n=== 预设判据结论 ===")
print(verdict)
print("\n图表已保存至 degeneracy_control.png")
print("原始数据已保存至 degeneracy_control_scan.csv / degeneracy_control_multiseed.csv / degeneracy_control_local_minima.csv")

scan_df