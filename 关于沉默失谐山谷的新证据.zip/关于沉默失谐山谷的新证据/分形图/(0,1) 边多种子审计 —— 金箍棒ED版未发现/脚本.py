import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import eigsh
from math import comb
import time

# 复用/覆盖为可执行的高效 ED：在固定 Sz 扇区构建 Pauli-Heisenberg 稀疏哈密顿量

def sierpinski_graph(level):
    """生成 Sierpinski 三角形分形图：保持原脚本的有向双边语义。"""
    G = {}
    def add_triangle(a, b, c):
        G[(a,b)] = 1.0; G[(b,a)] = 1.0
        G[(b,c)] = 1.0; G[(c,b)] = 1.0
        G[(c,a)] = 1.0; G[(a,c)] = 1.0
    def rec(v1, v2, v3, depth):
        if depth == 0:
            add_triangle(v1, v2, v3)
        else:
            n = max(max(v1, v2, v3), max([max(k) for k in G.keys()], default=0))
            m12 = n + 1
            m23 = n + 2
            m31 = n + 3
            rec(v1, m12, m31, depth - 1)
            rec(v2, m23, m12, depth - 1)
            rec(v3, m31, m23, depth - 1)
    rec(0, 1, 2, level)
    return list(G.keys())


def make_fixed_sz_basis(N, n_up):
    basis = np.array([state for state in range(1 << N) if state.bit_count() == n_up], dtype=np.uint32)
    index = {int(state): idx for idx, state in enumerate(basis)}
    return basis, index


def graph_to_hamiltonian_sector(N, edges, contradiction_edge, s, basis, index):
    dim = len(basis)
    diag = np.zeros(dim, dtype=np.float64)
    rows = []
    cols = []
    data = []
    ci, cj = contradiction_edge
    
    for col, state0 in enumerate(basis):
        state = int(state0)
        d = 0.0
        for i, j in edges:
            w = float(s) if ((i == ci and j == cj) or (i == cj and j == ci)) else 1.0
            bi = (state >> i) & 1
            bj = (state >> j) & 1
            if bi == bj:
                d += w
            else:
                d -= w
                flipped = state ^ (1 << i) ^ (1 << j)
                rows.append(index[flipped])
                cols.append(col)
                data.append(2.0 * w)  # sigma_x sigma_x + sigma_y sigma_y
        diag[col] = d
    rows.extend(range(dim))
    cols.extend(range(dim))
    data.extend(diag.tolist())
    return coo_matrix((data, (rows, cols)), shape=(dim, dim)).tocsr()


def edge_zz_correlations_sector(gs, basis, edges):
    prob = np.abs(gs) ** 2
    corrs = []
    for i, j in edges:
        vals = np.empty(len(basis), dtype=np.float64)
        for k, state0 in enumerate(basis):
            state = int(state0)
            bi = (state >> i) & 1
            bj = (state >> j) & 1
            vals[k] = 1.0 if bi == bj else -1.0
        corrs.append(float(prob @ vals))
    return np.array(corrs)


def diagnose_fast(N, edges, contradiction_edge, s, basis, index, seed=None):
    H = graph_to_hamiltonian_sector(N, edges, contradiction_edge, s, basis, index)
    v0 = None
    if seed is not None:
        rng = np.random.default_rng(seed)
        v0 = rng.random(len(basis))
    energies, states = eigsh(H, k=1, which='SA', v0=v0, tol=1e-9, maxiter=200000)
    gs = states[:, 0]
    # 固定 n_up 扇区下 coarse 为常数；审计只需要 fine。
    n_up = int(np.array([int(x).bit_count() for x in basis[:1]])[0]) if len(basis) else 0
    coarse = abs((2 * (basis[0].bit_count()) - N) / N)
    fine = float(np.std(edge_zz_correlations_sector(gs, basis, edges)))
    return coarse, fine, float(energies[0])


def multi_seed_audit_fast(N, edges, contradiction_edge, s_values, seeds, n_up=None):
    if n_up is None:
        n_up = N // 2  # N=15: Sz=-1 sector; SU(2) 退相同于 n_up=8
    basis, index = make_fixed_sz_basis(N, n_up)
    results = {}
    energies = {}
    for seed in seeds:
        fine_curve = []
        energy_curve = []
        for s in s_values:
            _, fine, energy = diagnose_fast(N, edges, contradiction_edge, float(s), basis, index, seed=seed)
            fine_curve.append(fine)
            energy_curve.append(energy)
        results[seed] = np.array(fine_curve)
        energies[seed] = np.array(energy_curve)
    return results, energies, basis

N = 15
edges = sierpinski_graph(2)
contradiction_edge = (0, 1)
s_values = np.linspace(0.0, 1.0, 101)
seeds = [0, 1, 2, 3, 4]

print(f"=== (0,1) 边多种子审计，高效固定 Sz ED (N={N}, 5种子, 101点) ===")
print(f"有向边数: {len(edges)}；无向边数: {len({tuple(sorted(e)) for e in edges})}；最大节点: {max(max(e) for e in edges)}")
print(f"固定 Sz 扇区维度 C({N},{N//2}) = {comb(N, N//2)}，替代全空间 2^{N} = {2**N}")

start = time.time()
results, energies_by_seed, basis = multi_seed_audit_fast(N, edges, contradiction_edge, s_values, seeds, n_up=N//2)
elapsed = time.time() - start

for seed in seeds:
    np.savetxt(
        f'edge01_seed{seed}.csv',
        np.column_stack((s_values, results[seed])),
        header='s,fine', delimiter=','
    )

all_curves = np.array([results[seed] for seed in seeds])
mean_curve = np.mean(all_curves, axis=0)
std_curve = np.std(all_curves, axis=0)
min_idx = int(np.argmin(mean_curve))
min_s = float(s_values[min_idx])
min_val = float(mean_curve[min_idx])
range_val = float(np.max(mean_curve) - np.min(mean_curve))
max_seed_spread = float(np.max(np.ptp(all_curves, axis=0)))

print(f"\n=== 多种子审计结果 ===")
print(f"耗时: {elapsed:.2f} s")
print(f"最小增强诊断位置: s={min_s:.3f}")
print(f"最小增强诊断值: {min_val:.6f}")
print(f"增强诊断极差: {range_val:.6f}")
print(f"最大种子间离散: {max_seed_spread:.6e}")
print(f"\n对照: (0,6) 边 LDS Valley 深度 0.0998±0.0064")
print(f"(0,1) 边极差: {range_val:.6f}")
if range_val < 0.05:
    print("结论: (0,1) 边无显著沉默失谐谷，不对称注入是必要条件。")
else:
    print("注意: (0,1) 边存在非平凡结构，需进一步分析。")