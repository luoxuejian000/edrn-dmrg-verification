"""
(0,1) 边多种子审计 —— 金箍棒ED版
在 Sierpinski 分形图 N=15 上，对矛盾边 (0,1) 进行 101 点、5 种子审计
验证：不对称注入是沉默失谐的必要条件
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh

# =============================================
# 公理一：Sierpinski 分形图生成
# =============================================
def sierpinski_graph(level):
    """生成 Sierpinski 三角形分形图"""
    G = {}
    def add_triangle(a, b, c):
        G[(a,b)] = 1.0; G[(b,a)] = 1.0
        G[(b,c)] = 1.0; G[(c,b)] = 1.0
        G[(c,a)] = 1.0; G[(a,c)] = 1.0
    def rec(v1, v2, v3, depth):
        if depth == 0:
            add_triangle(v1, v2, v3)
        else:
            m12 = max(max(G.keys(), key=lambda x: max(x[0],x[1])), default=-1)
            # 简化：用递归构建
            n = max(max(v1,v2,v3), max([max(k) for k in G.keys()], default=0))
            m12 = n+1; m23 = n+2; m31 = n+3
            rec(v1, m12, m31, depth-1)
            rec(v2, m23, m12, depth-1)
            rec(v3, m31, m23, depth-1)
    rec(0, 1, 2, level)
    # 转换为边列表
    edges = list(G.keys())
    return edges

# =============================================
# 公理一：哈密顿量编译（泡利矩阵版，标准海森堡）
# =============================================
def graph_to_hamiltonian(N, edges, contradiction_edge, s):
    """使用泡利矩阵构建标准各向同性 Heisenberg 哈密顿量"""
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)

    def to_full(op, site):
        ops = [I2] * N
        ops[site] = op
        result = ops[0]
        for k in range(1, N):
            result = np.kron(result, ops[k])
        return result

    for (i, j) in edges:
        w = s if (i,j)==contradiction_edge or (j,i)==contradiction_edge else 1.0
        H += w * (to_full(sx, i) @ to_full(sx, j)).real
        H += w * (to_full(sy, i) @ to_full(sy, j)).real
        H += w * (to_full(sz, i) @ to_full(sz, j)).real
    return H.tocsc()

# =============================================
# 公理三：诊断函数
# =============================================
def diagnose(N, edges, contradiction_edge, s, num_eig=3, seed=None):
    """求解基态，返回默认诊断和增强诊断"""
    H = graph_to_hamiltonian(N, edges, contradiction_edge, s)
    # v0 控制 Lanczos 种子
    v0 = None
    if seed is not None:
        rng = np.random.default_rng(seed)
        v0 = rng.random(2**N)
    energies, states = eigsh(H, k=min(num_eig, 2**N-1), which='SA', v0=v0)
    gs = states[:, 0]

    # 默认诊断：平均磁化
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    mag = 0.0
    for i in range(N):
        ops = [I2] * N
        ops[i] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        mag += np.real(gs.conj().T @ op_full @ gs)
    coarse = abs(mag / N)

    # 增强诊断：边关联涨落标准差
    corrs = []
    for (i, j) in edges:
        ops = [I2] * N
        ops[i] = sz
        ops[j] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        corr = np.real(gs.conj().T @ op_full @ gs)
        corrs.append(corr)
    fine = np.std(corrs) if corrs else 0.0

    return coarse, fine

# =============================================
# 多种子审计
# =============================================
def multi_seed_audit(N, edges, contradiction_edge, s_values, seeds):
    """对每个s值，用多个Lanczos种子独立计算"""
    results = {}
    for seed in seeds:
        fine_curve = []
        for s in s_values:
            coarse, fine = diagnose(N, edges, contradiction_edge, s, num_eig=3, seed=seed)
            fine_curve.append(fine)
        results[seed] = np.array(fine_curve)
    return results

if __name__ == "__main__":
    N = 15
    edges = sierpinski_graph(2)
    contradiction_edge = (0, 1)  # 与(0,6)的对照
    s_values = np.linspace(0.0, 1.0, 101)
    seeds = [0, 1, 2, 3, 4]

    print(f"=== (0,1) 边多种子审计 (N={N}, 5种子, 101点) ===")
    results = multi_seed_audit(N, edges, contradiction_edge, s_values, seeds)

    # 保存数据
    for seed in seeds:
        np.savetxt(f'edge01_seed{seed}.csv',
                   np.column_stack((s_values, results[seed])),
                   header='s,fine', delimiter=',')

    # 判断是否无谷
    all_curves = np.array([results[s] for s in seeds])
    mean_curve = np.mean(all_curves, axis=0)
    min_idx = np.argmin(mean_curve)
    min_s = s_values[min_idx]
    min_val = mean_curve[min_idx]
    # 计算极差
    range_val = np.max(mean_curve) - np.min(mean_curve)

    print(f"\n=== 多种子审计结果 ===")
    print(f"最小增强诊断位置: s={min_s:.3f}")
    print(f"最小增强诊断值: {min_val:.6f}")
    print(f"增强诊断极差: {range_val:.6f}")

    # 对比 (0,6) 边的 LDS Valley 深度 0.0998
    print(f"\n对照: (0,6) 边 LDS Valley 深度 0.0998±0.0064")
    print(f"(0,1) 边极差: {range_val:.6f}")
    if range_val < 0.05:
        print("结论: (0,1) 边无显著沉默失谐谷，不对称注入是必要条件。")
    else:
        print("注意: (0,1) 边存在非平凡结构，需进一步分析。")