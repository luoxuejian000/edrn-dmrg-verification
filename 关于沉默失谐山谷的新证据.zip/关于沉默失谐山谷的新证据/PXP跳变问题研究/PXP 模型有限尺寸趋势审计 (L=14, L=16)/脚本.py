import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.sparse import lil_matrix, csc_matrix
from scipy.sparse.linalg import eigsh

# Optimized execution of the submitted audit while preserving its Hamiltonian semantics:
# the original double loop + symmetric assignment produces off-diagonal flip amplitude 2.

def generate_valid_states(L):
    valid = []
    for n in range(2**L):
        s, ok, prev = n, True, 0
        for _ in range(L):
            bit = s & 1
            if bit == 1 and prev == 1:
                ok = False
                break
            prev = bit
            s >>= 1
        if ok:
            valid.append(n)
    return np.array(valid, dtype=int)

_pxp_cache = {}

def prepare_pxp(L, defect_site):
    key = (L, defect_site)
    if key in _pxp_cache:
        return _pxp_cache[key]
    valid = generate_valid_states(L)
    N = len(valid)
    state_to_idx = {int(s): i for i, s in enumerate(valid)}
    H0 = lil_matrix((N, N), dtype=float)
    defect_bits = np.zeros(N, dtype=float)
    for idx, s0 in enumerate(valid):
        s = int(s0)
        defect_bits[idx] = (s >> defect_site) & 1
        for j in range(L):
            left = (s >> (j - 1)) & 1 if j > 0 else 0
            right = (s >> (j + 1)) & 1 if j < L - 1 else 0
            if left or right:
                continue
            new_s = s ^ (1 << j)
            jdx = state_to_idx.get(new_s)
            if jdx is not None:
                H0[idx, jdx] += 1.0
                H0[jdx, idx] += 1.0
    H0 = H0.tocsc()
    sz_vals = np.empty((N, L), dtype=float)
    for i, s0 in enumerate(valid):
        s = int(s0)
        for j in range(L):
            sz_vals[i, j] = 1.0 - 2.0 * ((s >> j) & 1)
    _pxp_cache[key] = (valid, H0, defect_bits, sz_vals)
    return _pxp_cache[key]

def compute_default_diagnosis_fast(L, psi_vec, valid, sz_vals):
    prob = np.abs(psi_vec)**2
    sz_exp = prob @ sz_vals
    weighted = sz_vals * prob[:, None]
    corr = weighted.T @ sz_vals
    C = corr - np.outer(sz_exp, sz_exp)
    return float(np.mean(np.abs(C)))

def compute_enhanced_diagnosis_fast(L, psi_vec, valid):
    L_sub = L // 2
    left_size = 1 << L_sub
    right_size = 1 << (L - L_sub)
    v_full = np.zeros(2**L, dtype=complex)
    v_full[valid] = psi_vec
    # Original indexing uses v_full[left * right_size + right]
    M = v_full.reshape(left_size, right_size)
    rho_A = M @ M.conj().T
    eigvals = np.linalg.eigvalsh(rho_A)
    eigvals = np.sort(np.abs(eigvals))[::-1]
    eigvals = eigvals[eigvals > 1e-12]
    return float(np.std(eigvals)) if len(eigvals) > 1 else 0.0

def scan_L_fast(L, defect_site, mu_values, seeds):
    valid, H0, defect_bits, sz_vals = prepare_pxp(L, defect_site)
    N = len(valid)
    results = {seed: {'default': [], 'enhanced': []} for seed in seeds}
    D = csc_matrix((defect_bits, (np.arange(N), np.arange(N))), shape=(N, N))
    for seed in seeds:
        rng = np.random.default_rng(seed)
        for mu in mu_values:
            H = H0 - mu * D
            v0 = rng.random(N)
            energies, states = eigsh(H, k=1, which='SA', v0=v0, tol=1e-10, maxiter=N*20)
            psi_vec = states[:, 0]
            results[seed]['default'].append(compute_default_diagnosis_fast(L, psi_vec, valid, sz_vals))
            results[seed]['enhanced'].append(compute_enhanced_diagnosis_fast(L, psi_vec, valid))
    return results

mu_values = np.linspace(0.0, 2.0, 41)
seeds = [0, 1, 2, 3, 4]
summary_rows = []
all_results = {}

for L in [14, 16]:
    defect_site = L // 2
    print(f"\n=== PXP L={L} 有限尺寸趋势审计 ===")
    print(f"缺陷位置: {defect_site}, μ点数: {len(mu_values)}, 种子数: {len(seeds)}")
    results = scan_L_fast(L, defect_site, mu_values, seeds)
    all_results[L] = results

    for seed in seeds:
        np.savetxt(
            f'pxp_L{L}_seed{seed}.csv',
            np.column_stack((mu_values, results[seed]['default'], results[seed]['enhanced'])),
            header='mu,default,enhanced', delimiter=','
        )

    all_enhanced = np.array([results[seed]['enhanced'] for seed in seeds])
    mean_enhanced = np.mean(all_enhanced, axis=0)
    std_enhanced = np.std(all_enhanced, axis=0)
    enhanced_range = float(np.max(mean_enhanced) - np.min(mean_enhanced))
    min_idx = int(np.argmin(mean_enhanced))
    max_idx = int(np.argmax(mean_enhanced))

    print(f"\n=== L={L} 多种子审计结果 ===")
    print(f"增强诊断极差 (Enhanced range): {enhanced_range:.6f}")
    print(f"增强诊断最小值位置: μ={mu_values[min_idx]:.3f}, 值={mean_enhanced[min_idx]:.6f}")
    print(f"增强诊断最大值位置: μ={mu_values[max_idx]:.3f}, 值={mean_enhanced[max_idx]:.6f}")
    print(f"增强诊断跨种子平均标准差: {np.mean(std_enhanced):.6f}")
    print(f"\n对照: L=18 增强诊断极差 > 0.02 (jump 0.0217)")
    print(f"L={L} 增强诊断极差: {enhanced_range:.6f}")

    np.savetxt(
        f'pxp_L{L}_mean.csv',
        np.column_stack((mu_values, mean_enhanced, std_enhanced)),
        header='mu,enhanced_mean,enhanced_std', delimiter=','
    )
    summary_rows.append((L, enhanced_range, mu_values[min_idx], mean_enhanced[min_idx], mu_values[max_idx], mean_enhanced[max_idx], float(np.mean(std_enhanced))))

pxp_audit_summary = np.array(summary_rows, dtype=[('L', int), ('enhanced_range', float), ('min_mu', float), ('min_value', float), ('max_mu', float), ('max_value', float), ('mean_seed_std', float)])
pxp_audit_summary