"""
PXP 模型沉默失谐全面扫描
目的：检验沉默失谐是否真实存在，是否依赖于缺陷位置。
方法：遍历所有可能缺陷位置 (0 到 L-1)，对每个位置扫描化学势 μ，计算默认诊断与增强诊断。
严格遵循：关系本体论、防工具理性、反对对齐
"""

import numpy as np
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import warnings
import time

warnings.filterwarnings('ignore')

# =============================================
# PXP 模型核心函数（与原始脚本一致）
# =============================================
def generate_valid_states(L):
    """生成 PXP 约束下的所有有效态 (无相邻 1)"""
    valid = []
    for n in range(2**L):
        s, ok, prev = n, True, 0
        for _ in range(L):
            bit = s & 1
            if bit == 1 and prev == 1:
                ok = False
                break
            prev = bit
            s >>= 1
        if ok:
            valid.append(n)
    return np.array(valid, dtype=int)

def build_hamiltonian(L, mu_defect, defect_site):
    """构建带化学势缺陷的 PXP 模型哈密顿量 (约束子空间)"""
    valid = generate_valid_states(L)
    N = len(valid)
    state_to_idx = {s: i for i, s in enumerate(valid)}
    H = lil_matrix((N, N))
    for idx, s in enumerate(valid):
        # 化学势项
        bit_at_defect = (s >> defect_site) & 1
        H[idx, idx] -= mu_defect * bit_at_defect
        # 动力学项
        for j in range(L):
            left  = (s >> (j-1)) & 1 if j > 0 else 0
            right = (s >> (j+1)) & 1 if j < L-1 else 0
            if left or right:
                continue
            new_s = s ^ (1 << j)
            if new_s in state_to_idx:
                jdx = state_to_idx[new_s]
                H[idx, jdx] += 1.0
    return H.tocsc(), valid, state_to_idx

def compute_entanglement_spectrum(psi, L_sub, valid, state_to_idx):
    """计算半链纠缠谱 (约化密度矩阵的本征值)"""
    N = len(valid)
    rho_A = np.zeros((N, N), dtype=complex)
    for i in range(N):
        for j in range(N):
            si, sj = valid[i], valid[j]
            left_i = si & ((1 << L_sub) - 1)
            left_j = sj & ((1 << L_sub) - 1)
            right_i = si >> L_sub
            right_j = sj >> L_sub
            if right_i == right_j:
                rho_A[left_i, left_j] += psi[i] * np.conj(psi[j])
    eigvals = np.linalg.eigvalsh(rho_A)
    eigvals = np.sort(np.abs(eigvals))[::-1]
    return eigvals[eigvals > 1e-12]

def compute_correlation_matrix(L, psi, valid, state_to_idx):
    """计算自旋关联矩阵 C[i,j] = <σ^z_i σ^z_j> - <σ^z_i><σ^z_j>"""
    C = np.zeros((L, L))
    sz_exp = np.zeros(L)
    for i, s in enumerate(valid):
        prob = np.abs(psi[i])**2
        for j in range(L):
            bit = (s >> j) & 1
            sz_exp[j] += prob * (1 - 2*bit)
    for i in range(L):
        for j in range(L):
            corr = 0.0
            for k, s in enumerate(valid):
                bit_i = (s >> i) & 1
                bit_j = (s >> j) & 1
                val_i = 1.0 - 2.0*bit_i
                val_j = 1.0 - 2.0*bit_j
                corr += np.abs(psi[k])**2 * val_i * val_j
            C[i, j] = corr - sz_exp[i]*sz_exp[j]
    return C

# =============================================
# 单位置扫描函数
# =============================================
def scan_defect_position(L, defect_site, mu_vals, seed=0):
    """对指定缺陷位置扫描化学势，返回默认和增强诊断数组"""
    defaults = []
    enhanceds = []
    
    for mu in mu_vals:
        H, valid, stoi = build_hamiltonian(L, mu, defect_site)
        np.random.seed(seed)
        v0 = np.random.randn(len(valid))
        v0 /= np.linalg.norm(v0)
        evals, evecs = eigsh(H, k=1, which='SA', v0=v0)
        psi = evecs[:, 0]
        
        C = compute_correlation_matrix(L, psi, valid, stoi)
        default_metric = np.mean(np.abs(C))
        
        eigs = compute_entanglement_spectrum(psi, L//2, valid, stoi)
        enhanced_metric = np.std(eigs)
        
        defaults.append(default_metric)
        enhanceds.append(enhanced_metric)
    
    return np.array(defaults), np.array(enhanceds)

# =============================================
# 非单调性检测函数
# =============================================
def detect_non_monotonic(enhanceds, mu_vals, threshold_ratio=1.5):
    """
    检测增强诊断是否存在显著非单调特征。
    返回：最大相邻跳变比例，以及是否存在谷/峰。
    """
    max_jump_ratio = 0.0
    has_valley = False
    has_peak = False
    
    # 计算相邻差分
    diffs = np.diff(enhanceds)
    for i in range(1, len(diffs)-1):
        if abs(diffs[i]) > threshold_ratio * np.mean(np.abs(diffs[:i])):
            max_jump_ratio = max(max_jump_ratio, abs(diffs[i]) / max(np.mean(np.abs(diffs[:i])), 1e-12))
    
    # 检测局部最小值（谷）和局部最大值（峰）
    for i in range(1, len(enhanceds)-1):
        if enhanceds[i] < enhanceds[i-1] and enhanceds[i] < enhanceds[i+1]:
            has_valley = True
        if enhanceds[i] > enhanceds[i-1] and enhanceds[i] > enhanceds[i+1]:
            has_peak = True
    
    return max_jump_ratio, has_valley, has_peak

# =============================================
# 主扫描：所有缺陷位置
# =============================================
def run_full_position_scan(L=18, n_positions=None, n_mu=15, seed=0):
    """遍历所有缺陷位置，执行全面扫描"""
    if n_positions is None:
        n_positions = L  # 扫描所有位置
    
    mu_vals = np.linspace(0.0, 2.0, n_mu)
    positions = range(n_positions)
    
    print("=" * 70)
    print(f"PXP 模型沉默失谐全面扫描")
    print(f"系统尺寸 L={L}, 扫描 {n_positions} 个缺陷位置")
    print(f"化学势 μ ∈ [0, 2.0], {n_mu} 个点")
    print("=" * 70)
    
    results = []
    start_time = time.time()
    
    for defect_site in positions:
        defaults, enhanceds = scan_defect_position(L, defect_site, mu_vals, seed=seed)
        max_jump_ratio, has_valley, has_peak = detect_non_monotonic(enhanceds, mu_vals)
        
        # 记录关键统计量
        enhanced_min = np.min(enhanceds)
        enhanced_max = np.max(enhanceds)
        enhanced_range = enhanced_max - enhanced_min
        default_range = np.max(defaults) - np.min(defaults)
        default_smooth = default_range < 0.02  # 默认诊断变化很小，认为是平滑的
        
        # 谷深度：最左侧肩膀到全局最小值的深度
        valley_depth = defaults[0] - enhanced_min if enhanced_min < defaults[0] else 0
        peak_height = enhanced_max - defaults[-1] if enhanced_max > defaults[-1] else 0
        
        results.append({
            'position': defect_site,
            'max_jump_ratio': max_jump_ratio,
            'has_valley': has_valley,
            'has_peak': has_peak,
            'enhanced_min': enhanced_min,
            'enhanced_max': enhanced_max,
            'enhanced_range': enhanced_range,
            'default_range': default_range,
            'default_smooth': default_smooth,
            'valley_depth': valley_depth,
            'peak_height': peak_height,
        })
        
        print(f"\n位置 {defect_site}:")
        print(f"  增强诊断极差: {enhanced_range:.6f}")
        print(f"  最大相邻跳变比例: {max_jump_ratio:.4f}")
        print(f"  检测到谷: {has_valley}, 检测到峰: {has_peak}")
        print(f"  默认诊断变化幅度: {default_range:.6f}")
        print(f"  默认诊断平滑: {default_smooth}")
        
    elapsed = time.time() - start_time
    print(f"\n总耗时: {elapsed:.1f} 秒")
    
    # 保存完整数据
    np.savetxt('pxp_full_position_scan_summary.csv',
               np.array([(r['position'], r['enhanced_range'], r['max_jump_ratio'],
                          int(r['has_valley']), int(r['has_peak']),
                          r['default_range'], int(r['default_smooth']),
                          r['valley_depth'], r['peak_height'])
                         for r in results]),
               header='position,enhanced_range,max_jump_ratio,has_valley,has_peak,default_range,default_smooth,valley_depth,peak_height',
               delimiter=',')
    
    return results

if __name__ == "__main__":
    # 运行全面扫描，扫描所有18个位置
    results = run_full_position_scan(L=18, n_positions=18, n_mu=15, seed=0)
    
    # 输出总结
    print("\n" + "=" * 70)
    print("全面扫描总结")
    print("=" * 70)
    
    # 找出具有显著非单调特征的位置
    significant_positions = [r for r in results if r['has_valley'] or r['max_jump_ratio'] > 2.0]
    print(f"\n具有显著非单调特征的位置: {len(significant_positions)} 个")
    for r in significant_positions:
        print(f"  位置 {r['position']}: 最大跳变比例={r['max_jump_ratio']:.2f}, 谷={r['has_valley']}, 峰={r['has_peak']}")
    
    # 沉默失谐条件：默认平滑 + 增强非单调
    silent_discordance_candidates = [r for r in results if r['default_smooth'] and (r['has_valley'] or r['max_jump_ratio'] > 2.0)]
    print(f"\n满足沉默失谐条件的位置: {len(silent_discordance_candidates)} 个")
    for r in silent_discordance_candidates:
        print(f"  位置 {r['position']}: 默认平滑={r['default_smooth']}, 谷={r['has_valley']}, 最大跳变={r['max_jump_ratio']:.2f}")