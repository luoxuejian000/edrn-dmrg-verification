import numpy as np
from scipy.sparse import lil_matrix, csr_matrix
from scipy.sparse.linalg import eigsh
import matplotlib.pyplot as plt

def generate_valid_states(L):
    valid = []
    for n in range(2**L):
        s, ok, prev = n, True, 0
        for _ in range(L):
            bit = s & 1
            if bit == 1 and prev == 1:
                ok = False
                break
            prev = bit
            s >>= 1
        if ok:
            valid.append(n)
    return np.array(valid, dtype=int)

def build_hamiltonian_with_defect(L, mu_defect, defect_site):
    valid = generate_valid_states(L)
    N = len(valid)
    state_to_idx = {s: i for i, s in enumerate(valid)}
    H = lil_matrix((N, N))
    for idx, s in enumerate(valid):
        bit_at_defect = (s >> defect_site) & 1
        H[idx, idx] -= mu_defect * bit_at_defect
        for j in range(L):
            left  = (s >> (j-1)) & 1 if j > 0 else 0
            right = (s >> (j+1)) & 1 if j < L-1 else 0
            if left or right: continue
            new_s = s ^ (1 << j)
            if new_s in state_to_idx:
                jdx = state_to_idx[new_s]
                H[idx, jdx] += 1.0
                H[jdx, idx] += 1.0
    return H.tocsc(), valid, state_to_idx

def compute_correlation_matrix(L, psi, valid, state_to_idx):
    C = np.zeros((L, L))
    sz_exp = np.zeros(L)
    for i, s in enumerate(valid):
        prob = np.abs(psi[i])**2
        for j in range(L):
            bit = (s >> j) & 1
            sz_exp[j] += prob * (1 - 2*bit)
    
    for i in range(L):
        for j in range(L):
            corr = 0.0
            for k, s in enumerate(valid):
                bit_i = (s >> i) & 1
                bit_j = (s >> j) & 1
                val_i = 1.0 - 2.0*bit_i
                val_j = 1.0 - 2.0*bit_j
                corr += np.abs(psi[k])**2 * val_i * val_j
            C[i, j] = corr - sz_exp[i]*sz_exp[j]
    return C

def run_diagnosis():
    L = 14
    defect_site = L // 2
    mu_defect_vals = np.linspace(0, 2.0, 21)
    
    H0, valid, stoi = build_hamiltonian_with_defect(L, 0.0, defect_site)
    energies0, states0 = eigsh(H0, k=1, which='SA')
    psi0 = states0[:, 0]
    C0 = compute_correlation_matrix(L, psi0, valid, stoi)
    
    default_metrics = []
    enhanced_metrics = []
    
    print(f"Scanning mu_defect from {mu_defect_vals[0]} to {mu_defect_vals[-1]}...")
    for mu in mu_defect_vals:
        H, valid, stoi = build_hamiltonian_with_defect(L, mu, defect_site)
        energies, states = eigsh(H, k=1, which='SA')
        psi = states[:, 0]
        C = compute_correlation_matrix(L, psi, valid, stoi)
        
        default_metric = np.mean(np.abs(C))
        default_metrics.append(default_metric)
        
        D = C - C0
        enhanced_metric = np.var(D)
        enhanced_metrics.append(enhanced_metric)
        
        print(f"  mu={mu:.2f}: default={default_metric:.4f}, enhanced={enhanced_metric:.6f}")
    
    fig, ax1 = plt.subplots(figsize=(10, 6))
    
    color1 = '#1f77b4'
    ax1.plot(mu_defect_vals, default_metrics, 'o-', color=color1, lw=2, ms=6, label='Default Diagnosis (mean |C|)')
    ax1.set_xlabel('Defect strength mu', fontsize=13)
    ax1.set_ylabel('Default Metric (mean |C|)', color=color1, fontsize=13)
    ax1.tick_params(axis='y', labelcolor=color1)
    
    ax2 = ax1.twinx()
    color2 = '#d62728'
    ax2.plot(mu_defect_vals, enhanced_metrics, 's--', color=color2, lw=2, ms=6, label='Enhanced Diagnosis (var of C - C0)')
    ax2.set_ylabel('Enhanced Metric (var of Delta C)', color=color2, fontsize=13)
    ax2.tick_params(axis='y', labelcolor=color2)
    
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1+lines2, labels1+labels2, fontsize=10, loc='upper left')
    
    plt.title(f'Silent Discordance Detector (PXP, L={L})', fontsize=14, fontweight='bold')
    plt.tight_layout()
    plt.savefig('silent_discordance.png', dpi=150)
    print("\nDiagnosis complete. Chart saved to silent_discordance.png")
    plt.show()

if __name__ == "__main__":
    run_diagnosis()