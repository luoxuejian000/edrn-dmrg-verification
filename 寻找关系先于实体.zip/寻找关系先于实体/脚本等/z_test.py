import sys
sys.path.insert(0, r"D:\luoxuejian000\wulihuaxue\tenpy-main (1)\tenpy-main")
import numpy as np
from tenpy.models.hubbard import FermiHubbardModel
from tenpy.networks.mps import MPS
from tenpy.algorithms import dmrg

L = 30
seg = L // 3
U_arr = [4.0]*seg + [0.1]*seg + [4.0]*seg

M = FermiHubbardModel(dict(
    L=L, U=U_arr, t=1.0,
    cons_N='N', cons_Sz='Sz',
    bc_MPS='finite'
))

psi_s = MPS.from_product_state(M.lat.mps_sites(), ['up' if i % 2 == 0 else 'down' for i in range(L)])
result0 = dmrg.run(psi_s, M, {'mixer':True, 'max_sweeps':50, 'min_sweeps':2, 'trunc_params':{'chi_max':100}})
E0 = result0['E']

init_t = ['up' if i % 2 == 0 else 'down' for i in range(L)]
c = L//2
if c%2==0:
    init_t[c]='up'; init_t[c+1]='up'
else:
    init_t[c]='up'; init_t[c-1]='up'
psi_t = MPS.from_product_state(M.lat.mps_sites(), init_t)
result1 = dmrg.run(psi_t, M, {'mixer':True, 'max_sweeps':50, 'min_sweeps':2, 'trunc_params':{'chi_max':100}})
E1 = result1['E']

print(f"Spin gap (uniform t=1.0): {E1-E0:.6f}")