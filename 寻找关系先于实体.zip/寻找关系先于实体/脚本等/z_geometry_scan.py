import sys
sys.path.insert(0, r"D:\luoxuejian000\wulihuaxue\tenpy-main (1)\tenpy-main")
import numpy as np
from tenpy.models.hubbard import FermiHubbardModel
from tenpy.networks.mps import MPS
from tenpy.algorithms import dmrg

def compute_gap(L, U_mid, t_left, t_right):
    seg = L // 3
    U_arr = [4.0]*seg + [U_mid]*seg + [4.0]*seg
    M = FermiHubbardModel(dict(
        L=L, U=U_arr, t=1.0,
        cons_N='N', cons_Sz='Sz',
        bc_MPS='finite'
    ))
    couplings = M.all_coupling_terms()
    for i, d1 in couplings.coupling_terms.items():
        for (op_i, op_string), d2 in d1.items():
            for j, d3 in d2.items():
                if i == seg-1 and j == seg:
                    for op_j in d3:
                        d3[op_j] = t_left
                if i == 2*seg-1 and j == 2*seg:
                    for op_j in d3:
                        d3[op_j] = t_right

    psi_s = MPS.from_product_state(M.lat.mps_sites(), ['up' if i % 2 == 0 else 'down' for i in range(L)])
    dmrg_params = {'mixer': True, 'trunc_params': {'chi_max': 100}, 'max_sweeps': 50, 'min_sweeps': 2, 'verbose': 0}
    E0 = dmrg.run(psi_s, M, dmrg_params)['E']

    init_t = ['up' if i % 2 == 0 else 'down' for i in range(L)]
    c = L//2
    if c%2==0:
        init_t[c]='up'; init_t[c+1]='up'
    else:
        init_t[c]='up'; init_t[c-1]='up'
    psi_t = MPS.from_product_state(M.lat.mps_sites(), init_t)
    E1 = dmrg.run(psi_t, M, dmrg_params)['E']

    return E1 - E0

def run_scan():
    L = 30
    U_mid = 0.1
    configs = {
        "A: weak-weak (0.1,0.1)": (0.1, 0.1),
        "B: strong-weak (1.0,0.1)": (1.0, 0.1),
        "C: strong-strong (1.0,1.0)": (1.0, 1.0)
    }
    print("Z-Geometry Experiment: Relation Determines Entity?")
    print(f"L={L}, U_mid={U_mid}\n")
    for name, (t_left, t_right) in configs.items():
        gap = compute_gap(L, U_mid, t_left, t_right)
        print(f"  {name}: gap = {gap:.6f}")
    print("\nDone.")

if __name__ == "__main__":
    run_scan()