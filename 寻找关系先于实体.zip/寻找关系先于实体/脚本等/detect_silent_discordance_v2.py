import numpy as np
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')

def generate_valid_states(L):
    valid = []
    for n in range(2**L):
        s, ok, prev = n, True, 0
        for _ in range(L):
            bit = s & 1
            if bit == 1 and prev == 1:
                ok = False
                break
            prev = bit
            s >>= 1
        if ok:
            valid.append(n)
    return np.array(valid, dtype=int)

def build_hamiltonian(L, mu_defect, defect_site):
    valid = generate_valid_states(L)
    N = len(valid)
    state_to_idx = {s: i for i, s in enumerate(valid)}
    H = lil_matrix((N, N))
    for idx, s in enumerate(valid):
        bit_at_defect = (s >> defect_site) & 1
        H[idx, idx] -= mu_defect * bit_at_defect
        for j in range(L):
            left  = (s >> (j-1)) & 1 if j > 0 else 0
            right = (s >> (j+1)) & 1 if j < L-1 else 0
            if left or right: continue
            new_s = s ^ (1 << j)
            if new_s in state_to_idx:
                jdx = state_to_idx[new_s]
                H[idx, jdx] += 1.0
    return H.tocsc(), valid, state_to_idx

def compute_entanglement_spectrum(psi, L_sub, valid, state_to_idx):
    L_total = len(bin(valid[0])) - 2 if valid[0] > 0 else 0
    if L_total == 0:
        L_total = 1
    L = L_total
    N = len(valid)
    rho_A = np.zeros((N, N), dtype=complex)
    for i in range(N):
        for j in range(N):
            si, sj = valid[i], valid[j]
            left_i = si & ((1 << L_sub) - 1)
            left_j = sj & ((1 << L_sub) - 1)
            right_i = si >> L_sub
            right_j = sj >> L_sub
            if right_i == right_j:
                rho_A[left_i, left_j] += psi[i] * np.conj(psi[j])
    eigvals = np.linalg.eigvalsh(rho_A)
    eigvals = np.sort(np.abs(eigvals))[::-1]
    return eigvals[eigvals > 1e-12]

def compute_correlation_matrix(L, psi, valid, state_to_idx):
    C = np.zeros((L, L))
    sz_exp = np.zeros(L)
    for i, s in enumerate(valid):
        prob = np.abs(psi[i])**2
        for j in range(L):
            bit = (s >> j) & 1
            sz_exp[j] += prob * (1 - 2*bit)
    for i in range(L):
        for j in range(L):
            corr = 0.0
            for k, s in enumerate(valid):
                bit_i = (s >> i) & 1
                bit_j = (s >> j) & 1
                val_i = 1.0 - 2.0*bit_i
                val_j = 1.0 - 2.0*bit_j
                corr += np.abs(psi[k])**2 * val_i * val_j
            C[i, j] = corr - sz_exp[i]*sz_exp[j]
    return C

def run_diagnosis():
    L = 18
    L_sub = L // 2
    defect_site = L // 2
    mu_defect_vals = np.linspace(0, 2.0, 15)

    print("Computing reference state (mu=0)...")
    H0, valid, stoi = build_hamiltonian(L, 0.0, defect_site)
    ev0, st0 = eigsh(H0, k=1, which='SA')
    psi0 = st0[:, 0]
    C0 = compute_correlation_matrix(L, psi0, valid, stoi)

    default_metrics = []
    enhanced_metrics = []

    print(f"Scanning mu_defect on PXP L={L} (Entanglement Spectrum Probe)...")
    for mu in mu_defect_vals:
        H, valid, stoi = build_hamiltonian(L, mu, defect_site)
        ev, st = eigsh(H, k=1, which='SA')
        psi = st[:, 0]
        C = compute_correlation_matrix(L, psi, valid, stoi)
        default_metric = np.mean(np.abs(C))
        default_metrics.append(default_metric)
        eigs = compute_entanglement_spectrum(psi, L_sub, valid, stoi)
        enhanced_metric = np.std(eigs)
        enhanced_metrics.append(enhanced_metric)
        print(f"  mu={mu:.2f}: default={default_metric:.4f}, ent-spec std={enhanced_metric:.6f}")

    fig, ax1 = plt.subplots(figsize=(10, 6))
    ax1.plot(mu_defect_vals, default_metrics, 'o-', color='#1f77b4', lw=2, ms=6, label='Default Diagnosis (mean |C|)')
    ax1.set_xlabel('Defect strength mu', fontsize=13)
    ax1.set_ylabel('Default Metric (mean |C|)', color='#1f77b4', fontsize=13)
    ax1.tick_params(axis='y', labelcolor='#1f77b4')

    ax2 = ax1.twinx()
    ax2.plot(mu_defect_vals, enhanced_metrics, 's--', color='#d62728', lw=2, ms=6, label='Enhanced Diagnosis (entanglement spectrum std)')
    ax2.set_ylabel('Enhanced Metric (ent. spec. std)', color='#d62728', fontsize=13)
    ax2.tick_params(axis='y', labelcolor='#d62728')

    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1+lines2, labels1+labels2, fontsize=10)
    plt.title(f'Silent Discordance 2.0: Entanglement Spectrum Probe (PXP, L={L})', fontsize=14, fontweight='bold')
    plt.tight_layout()
    plt.savefig('silent_discordance_v2.png', dpi=150)
    print("\nDiagnosis complete. Chart saved to silent_discordance_v2.png")
    plt.show()

if __name__ == "__main__":
    run_diagnosis()