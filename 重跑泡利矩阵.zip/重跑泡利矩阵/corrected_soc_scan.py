"""
修正版 Rashba SOC 扫描 —— 标准各向同性 Heisenberg 模型
替代 constant_validation.py，使用泡利矩阵构建哈密顿量
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh

# =============================================
# 公理一：关系图与哈密顿量编译（标准泡利矩阵版）
# =============================================
def chain_graph(N):
    """生成链式图边列表"""
    edges = [(i, i+1, 1.0) for i in range(N-1)]
    return edges

def graph_to_hamiltonian_pauli(N, edges, contradiction_edge, contradiction_strength,
                                rule='heisenberg', delta=1.0, D=0.0):
    """
    使用泡利矩阵构建哈密顿量（与 final_ed_scan.py 完全一致）
    """
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)

    def to_full(op, site):
        ops = [I2] * N
        ops[site] = op
        result = ops[0]
        for k in range(1, N):
            result = np.kron(result, ops[k])
        return result

    for (i, j, w) in edges:
        # 矛盾边替换权重
        if (i, j) == contradiction_edge or (j, i) == contradiction_edge:
            w = contradiction_strength

        # Heisenberg 部分 (XX+YY+ZZ)
        if rule in ['heisenberg', 'xy', 'xxz']:
            H += w * (to_full(sx, i) @ to_full(sx, j)).real
            H += w * (to_full(sy, i) @ to_full(sy, j)).real
        if rule in ['heisenberg', 'ising', 'xxz']:
            zz = delta if rule == 'xxz' else 1.0
            H += w * zz * (to_full(sz, i) @ to_full(sz, j)).real

        # Rashba SOC (DM 向量沿 y 轴)
        if D != 0.0:
            H += D * (to_full(sz, i) @ to_full(sx, j)).real
            H -= D * (to_full(sx, i) @ to_full(sz, j)).real

    return H.tocsc()


# =============================================
# 公理三：诊断函数
# =============================================
def diagnose(N, edges, contradiction_edge, s, rule='heisenberg', delta=1.0, D=0.0, num_eig=5):
    """求解基态，返回能隙、默认诊断和精细诊断"""
    H = graph_to_hamiltonian_pauli(N, edges, contradiction_edge, s,
                                   rule=rule, delta=delta, D=D)
    energies, states = eigsh(H, k=min(num_eig, 2**N-1), which='SA')
    gap = energies[1] - energies[0] if len(energies) > 1 else np.nan
    gs = states[:, 0]

    # 默认诊断：平均磁化
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    mag = 0.0
    for i in range(N):
        ops = [I2] * N
        ops[i] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        mag += np.real(gs.conj().T @ op_full @ gs)
    coarse = abs(mag / N)

    # 精细诊断：边关联涨落标准差
    corrs = []
    for (i, j, w) in edges:
        ops = [I2] * N
        ops[i] = sz
        ops[j] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        corr = np.real(gs.conj().T @ op_full @ gs)
        corrs.append(corr)
    fine = np.std(corrs) if corrs else 0.0

    return gap, coarse, fine


# =============================================
# 主扫描：Rashba SOC 对比扫描
# =============================================
def run_soc_scan(N_values=None, D=0.3, strengths=None):
    """
    对每个 N，分别用纯 Heisenberg (D=0) 和 Rashba SOC (D>0) 扫描矛盾强度，
    计算精细诊断比值 fine_SOC / fine_Heisenberg，逐点输出
    """
    if N_values is None:
        N_values = [6, 8, 10]
    if strengths is None:
        strengths = np.linspace(0.0, 3.0, 9)

    for N in N_values:
        edges = chain_graph(N)
        contradiction_edge = (N//2 - 1, N//2)  # 中心键

        print(f"\n=== N={N} ===")
        ratios = []
        for s in strengths:
            # 纯 Heisenberg
            _, _, fine_heis = diagnose(N, edges, contradiction_edge, s,
                                       rule='heisenberg', D=0.0, num_eig=5)
            # Rashba SOC
            _, _, fine_soc = diagnose(N, edges, contradiction_edge, s,
                                      rule='heisenberg', D=D, num_eig=5)
            ratio = fine_soc / fine_heis if fine_heis != 0 else np.nan
            ratios.append(ratio)
            print(f"s={s:.2f}: fine_Heis={fine_heis:.6f}, fine_SOC={fine_soc:.6f}, ratio={ratio:.6f}")

        # 保存数据
        data = np.column_stack((strengths, ratios))
        csv_name = f"soc_corrected_N{N}.csv"
        np.savetxt(csv_name, data,
                   header='strength,ratio_SOC_over_Heis', delimiter=',')
        print(f"数据已保存: {csv_name}")


if __name__ == "__main__":
    run_soc_scan(N_values=[6, 8, 10], D=0.3)