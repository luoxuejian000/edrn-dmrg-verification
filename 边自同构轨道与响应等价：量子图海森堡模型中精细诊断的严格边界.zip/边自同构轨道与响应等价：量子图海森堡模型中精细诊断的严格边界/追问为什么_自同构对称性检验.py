"""
追问为什么_自同构对称性检验.py

目标：
    追问同轨道异曲线反例的根源。
    对每对同轨道边，检验自同构映射是否保持扫描哈密顿量：
        1. 构建扫描边ei的哈密顿量H(s, ei)
        2. 用自同构映射φ变换H(s, ei)，得到φ(H(s, ei))
        3. 构建扫描边ej的哈密顿量H(s, ej)
        4. 比较φ(H(s, ei))与H(s, ej)的逐元素差异
    如果差异为零，则自同构保持哈密顿量，反例来自数值问题；
    如果差异非零，则自同构不保持哈密顿量，找到了物理根源。

方法：
    只查同与不同，不拟合。
    标准物理（自同构变换后哈密顿量）与晶脉视角（反例）并排。

输出：
    jingmai_why_automorphism_symmetry.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6

def build_hamiltonian(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def get_edge_orbits_with_mapping(edges, N):
    """
    获取边轨道，并返回每条边对应的自同构映射（将边ei映射到同轨道另一条边ej的节点置换）。
    返回：orbits, edge_to_orbit, orbit_mappings
    orbit_mappings[oi] = {ei: {ej: mapping_dict, ...}, ...}
    """
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    automorphisms = list(GM.isomorphisms_iter())
    
    # 为每条边找到映射到同轨道其他边的自同构
    orbit_mappings = {}
    # 先计算轨道
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        mappings_for_orbit = {}
        for auto in automorphisms:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    
    # 重新构建映射：对每个轨道，找到轨道内每条边之间的映射
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
        # 对于该轨道，建立映射字典
        mappings = {}
        orbit_edges = [edges[i] for i in orbit]
        for i_idx, ei in enumerate(orbit):
            mappings[ei] = {}
            for j_idx, ej in enumerate(orbit):
                if ei == ej:
                    continue
                # 寻找将 edges[ei] 映射到 edges[ej] 的自同构
                found_mapping = None
                for auto in automorphisms:
                    mapped_edge = tuple(sorted((auto[edges[ei][0]], auto[edges[ei][1]])))
                    if mapped_edge == edges[ej]:
                        found_mapping = auto
                        break
                if found_mapping is not None:
                    mappings[ei][ej] = found_mapping
                else:
                    mappings[ei][ej] = None
        orbit_mappings[oi] = mappings
    
    return orbits, edge_to_orbit, orbit_mappings

def apply_mapping_to_hamiltonian(H, basis, mapping, N):
    """
    将节点映射 mapping 应用到哈密顿量矩阵 H 上。
    需要重新构建基向量索引，因为节点置换会改变基向量。
    这里简化：直接根据节点映射重新构建边集合，然后用新边集合和原 J 值重建哈密顿量。
    但 J 值需要按原边对应。由于我们扫描时 J 只在一特殊边上为 s，其余为 1。
    映射后，特殊边变为 mapping(特殊边)。所以我们需要知道映射前后的 J 配置。
    为简单，我们直接比较扫描边 ei 和 ej 的哈密顿量，而不用显式映射。
    实际上，如果映射保持边集，则扫描 ei 的 H 经过节点置换应等于扫描 ej 的 H。
    我们在这里直接实现节点置换矩阵 P，计算 P^T H P。
    """
    # 构建节点置换矩阵
    dim = len(basis)
    # 根据基向量在新节点标记下的索引构建置换矩阵
    new_basis_states = []
    for state in basis:
        # 应用 mapping 到 state
        new_state = 0
        for i in range(N):
            if (state >> i) & 1:
                new_state |= (1 << mapping[i])
        new_basis_states.append(new_state)
    # 新基向量到索引的映射
    new_state_to_idx = {st: i for i, st in enumerate(new_basis_states)}
    P = np.zeros((dim, dim), dtype=float)
    for old_idx, new_state in enumerate(new_basis_states):
        new_idx = new_state_to_idx[new_state]
        P[new_idx, old_idx] = 1.0
    H_transformed = P @ H @ P.T
    return H_transformed

def main():
    print("=== 追问为什么_自同构对称性检验 ===\n")
    
    # 选取几个已知反例图
    # 图38, 图80, 图82, 图89, 图93, 图110, 图111
    all_graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            all_graphs.append(edges)
    
    # 选择几个反例图
    ce_graph_indices = [38, 80, 82, 89, 93, 110, 111]
    results = []
    
    for g_idx in ce_graph_indices:
        edges = all_graphs[g_idx]
        n_edges = len(edges)
        orbits, edge_to_orbit, orbit_mappings = get_edge_orbits_with_mapping(edges, N)
        
        print(f"\n===== 图 {g_idx}（{n_edges}边，{len(orbits)}轨道） =====")
        print(f"边列表：{edges}")
        
        # 扫描参数
        s_val = -0.5
        J_template = np.ones(n_edges)
        
        # 对每个轨道，取一对边检查
        for oi, orbit in enumerate(orbits):
            if len(orbit) >= 2:
                ei = orbit[0]
                ej = orbit[1]
                
                # 构建扫描 ei 的哈密顿量
                J_i = J_template.copy()
                J_i[ei] = s_val
                H_i, basis_i = build_hamiltonian(N, edges, J_i)
                
                # 找到映射 ei -> ej
                mapping = orbit_mappings[oi].get(ei, {}).get(ej)
                if mapping is None:
                    print(f"  轨道{oi}: 边{ei}->边{ej} 未找到映射，跳过")
                    continue
                
                # 应用映射变换 H_i
                H_transformed = apply_mapping_to_hamiltonian(H_i, basis_i, mapping, N)
                
                # 构建扫描 ej 的哈密顿量
                J_j = J_template.copy()
                J_j[ej] = s_val
                H_j, basis_j = build_hamiltonian(N, edges, J_j)
                
                # 比较 H_transformed 和 H_j
                max_diff = float(np.max(np.abs(H_transformed - H_j)))
                is_equal = max_diff < 1e-10
                
                print(f"  轨道{oi}: 边{ei}->边{ej}, 映射后哈密顿量与扫描{ej}的最大差异 = {max_diff:.6e}")
                print(f"    是否相等：{is_equal}")
                
                results.append({
                    'graph': g_idx,
                    'orbit': oi,
                    'edge_i': ei,
                    'edge_j': ej,
                    'max_diff': max_diff,
                    'is_equal': is_equal
                })
    
    # 保存
    output = {
        'results': results,
        'note': '追问为什么：自同构映射是否保持扫描哈密顿量。若差异非零，则反例的物理根源找到。'
    }
    with open('jingmai_why_automorphism_symmetry.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_automorphism_symmetry.json")

if __name__ == "__main__":
    main()