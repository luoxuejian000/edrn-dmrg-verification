"""
追问为什么_激发态关联相似度轨道分类.py

目标：
    继续追问：引入基态-第一激发态关联分布相似度 sim01 后，
    能否恢复完美的轨道分类？
    对每个N=6连通图，对每条边扫描得到 sim01(Δ) 曲线，
    比较同轨道边对和异轨道边对的 sim01 曲线是否相同。
    统计四类：
        同轨道同sim01、同轨道异sim01、异轨道同sim01、异轨道异sim01
    与排序关联分布的轨道分类结果并排对比。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。
    基态简并使用对称性约化密度矩阵。

理论精髓：
    - 数据自己说话。
    - 追问：激发态信息能否填补排序分布的缺陷？

输出：
    jingmai_why_sim01_orbits.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
S_POINTS = 21
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10

def build_hamiltonian_and_basis(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def compute_probs_with_degen(N, edges, J_vals):
    H, basis = build_hamiltonian_and_basis(N, edges, J_vals)
    evals, evecs = np.linalg.eigh(H)
    E0 = evals[0]
    degen_indices = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
    degen_dim = len(degen_indices)
    probs = np.zeros(len(basis))
    for idx in degen_indices:
        probs += np.abs(evecs[:, idx])**2
    probs /= degen_dim
    return probs, basis, evals, evecs, degen_indices

def compute_corrs_from_probs(N, edges, basis, probs):
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return np.array(corrs)

def distribution_similarity(dist1, dist2):
    return float(np.linalg.norm(np.sort(dist1) - np.sort(dist2)))

def compute_sim01(N, edges, J_vals):
    """计算基态与第一激发态关联分布的相似度"""
    probs, basis, evals, evecs, degen_indices = compute_probs_with_degen(N, edges, J_vals)
    corrs_gs = compute_corrs_from_probs(N, edges, basis, probs)
    E0 = evals[0]
    excited_indices = [k for k in range(len(evals)) if evals[k] > E0 + TOL_DEGEN]
    if excited_indices:
        idx_ex = excited_indices[0]
        psi_ex = evecs[:, idx_ex]
    else:
        psi_ex = evecs[:, 0]
    probs_ex = np.abs(psi_ex)**2
    corrs_ex = compute_corrs_from_probs(N, edges, basis, probs_ex)
    return distribution_similarity(corrs_gs, corrs_ex)

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def get_edge_orbits_from_edges(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    automorphisms = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in automorphisms:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return orbits, edge_to_orbit

def same_curve(c1, c2, tol=TOL_CURVE):
    return np.allclose(c1, c2, atol=tol)

def main():
    print("=== 追问为什么_激发态关联相似度轨道分类 ===\n")
    
    all_graphs = get_all_N6_graphs()
    s_values = np.linspace(-1.5, 0.0, S_POINTS)
    print(f"总图数：{len(all_graphs)}")
    
    # 全局统计
    stats = {'same_orbit_same': 0, 'same_orbit_diff': 0,
             'diff_orbit_same': 0, 'diff_orbit_diff': 0}
    ce_list = []
    
    for g_idx, edges in enumerate(all_graphs):
        n_edges = len(edges)
        orbits, edge_to_orbit = get_edge_orbits_from_edges(edges, N)
        
        # 扫描所有边，计算 sim01 曲线
        sim01_curves = []
        for i in range(n_edges):
            curve = np.zeros(S_POINTS)
            for si, s in enumerate(s_values):
                J = np.ones(n_edges); J[i] = s
                curve[si] = compute_sim01(N, edges, J)
            sim01_curves.append(curve)
        
        for i in range(n_edges):
            for j in range(i+1, n_edges):
                curve_same = same_curve(sim01_curves[i], sim01_curves[j])
                orbit_same = edge_to_orbit[i] == edge_to_orbit[j]
                if orbit_same:
                    if curve_same:
                        stats['same_orbit_same'] += 1
                    else:
                        stats['same_orbit_diff'] += 1
                        ce_list.append((g_idx, 'same_orbit_diff', i, j))
                else:
                    if curve_same:
                        stats['diff_orbit_same'] += 1
                        ce_list.append((g_idx, 'diff_orbit_same', i, j))
                    else:
                        stats['diff_orbit_diff'] += 1
        
        if (g_idx+1) % 30 == 0:
            print(f"  进度：{g_idx+1}/{len(all_graphs)}")
    
    print(f"\n===== sim01 轨道分类统计 =====")
    print(f"同轨道同sim01：{stats['same_orbit_same']}")
    print(f"同轨道异sim01：{stats['same_orbit_diff']}")
    print(f"异轨道同sim01：{stats['diff_orbit_same']}")
    print(f"异轨道异sim01：{stats['diff_orbit_diff']}")
    print(f"反例数：{len(ce_list)}")
    
    if ce_list:
        print("\n反例详情（前20个）：")
        for ce in ce_list[:20]:
            print(f"  图{ce[0]} 类型={ce[1]} 边{ce[2]} vs 边{ce[3]}")
    
    output = {
        'stats': stats,
        'ce_list': ce_list,
        'note': '追问：引入基态-第一激发态关联分布相似度后，轨道分类是否完美？'
    }
    with open('jingmai_why_sim01_orbits.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_sim01_orbits.json")

if __name__ == "__main__":
    main()