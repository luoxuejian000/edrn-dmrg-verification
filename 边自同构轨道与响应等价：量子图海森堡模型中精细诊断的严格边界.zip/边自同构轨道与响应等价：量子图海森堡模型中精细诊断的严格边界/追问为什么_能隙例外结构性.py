"""
追问为什么_能隙例外结构性.py

目标：
    追问29对能隙例外是否具有结构性。
    对每对例外，检查：
        1. 能隙差异是否在整个扫描区间内保持常数
        2. 能隙差异的符号是否一致（恒正/恒负/变号）
        3. 两边的基态能量是否相同
        4. 两边的第一激发态能量是否相同
        5. 能隙差异是否等于某个整数或简单有理数（图108中差异恒为2.0）
        6. 是否都是"割点边 vs 分支边"模式
    并排展示标准物理（基态能量、第一激发能量、能隙）与晶脉视角（响应等价）。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。
    基态简并使用对称性约化密度矩阵。

输出：
    jingmai_why_gap_exception_structure.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
S_POINTS = 11
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10
TOL_STRUCT = 1e-8

def build_basis(N):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    return basis, state_to_idx

def add_heisenberg_term(H, basis, state_to_idx, edges, J_vals):
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J

def build_heisenberg(N, edges, J_vals):
    basis, state_to_idx = build_basis(N)
    H = np.zeros((len(basis), len(basis)), dtype=float)
    add_heisenberg_term(H, basis, state_to_idx, edges, J_vals)
    return H, basis

def compute_full(N, edges, J_vals):
    """返回基态能量、第一激发态能量、能隙、排序关联分布"""
    H, basis = build_heisenberg(N, edges, J_vals)
    evals, evecs = np.linalg.eigh(H)
    E0 = float(evals[0])
    # 找出第一个与E0不同的能级
    E1 = None
    for k in range(1, len(evals)):
        if abs(evals[k] - E0) > TOL_DEGEN:
            E1 = float(evals[k])
            break
    gap = E1 - E0 if E1 is not None else 0.0
    # 简并度
    degen = sum(1 for e in evals if abs(e - E0) < TOL_DEGEN)
    # 关联分布（用简并子空间均匀混合）
    probs = np.zeros(len(basis))
    degen_indices = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
    for idx in degen_indices:
        probs += np.abs(evecs[:, idx])**2
    probs /= len(degen_indices)
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return {
        'E0': E0,
        'E1': E1,
        'gap': gap,
        'degen': degen,
        'sorted_corrs': np.sort(np.array(corrs))
    }

def get_edge_data(N, edges, edge_idx, s_values):
    n_edges = len(edges)
    E0_curve = []
    E1_curve = []
    gap_curve = []
    sorted_curves = []
    degen_curve = []
    for s in s_values:
        J = np.ones(n_edges); J[edge_idx] = s
        r = compute_full(N, edges, J)
        E0_curve.append(r['E0'])
        E1_curve.append(r['E1'])
        gap_curve.append(r['gap'])
        sorted_curves.append(r['sorted_corrs'])
        degen_curve.append(r['degen'])
    return {
        'E0': E0_curve,
        'E1': E1_curve,
        'gap': gap_curve,
        'degen': degen_curve,
        'sorted_corrs': sorted_curves
    }

def curves_equal(c1, c2, tol=TOL_CURVE):
    if len(c1) != len(c2):
        return False
    for a, b in zip(c1, c2):
        if isinstance(a, np.ndarray) or isinstance(b, np.ndarray):
            if not np.allclose(a, b, atol=tol):
                return False
        else:
            if abs(a - b) > tol:
                return False
    return True

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def get_edge_orbits(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    autos = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in autos:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return edge_to_orbit

def main():
    print("=== 追问为什么_能隙例外结构性 ===\n")
    
    all_graphs = get_all_N6_graphs()
    s_values = np.linspace(-1.5, 0.0, S_POINTS)
    
    exceptions = []
    
    for g_idx, edges in enumerate(all_graphs):
        n_edges = len(edges)
        edge_to_orbit = get_edge_orbits(edges, N)
        G = nx.Graph()
        G.add_nodes_from(range(N))
        G.add_edges_from(edges)
        cut_vertices = list(nx.articulation_points(G))
        
        # 计算所有边的数据
        all_data = []
        for i in range(n_edges):
            all_data.append(get_edge_data(N, edges, i, s_values))
        
        for i in range(n_edges):
            for j in range(i+1, n_edges):
                resp_same = curves_equal(all_data[i]['sorted_corrs'], all_data[j]['sorted_corrs'])
                if not resp_same:
                    continue
                gap_same = curves_equal(all_data[i]['gap'], all_data[j]['gap'])
                if gap_same:
                    continue
                # 例外
                gaps_i = all_data[i]['gap']
                gaps_j = all_data[j]['gap']
                E0s_i = all_data[i]['E0']
                E0s_j = all_data[j]['E0']
                E1s_i = all_data[i]['E1']
                E1s_j = all_data[j]['E1']
                degens_i = all_data[i]['degen']
                degens_j = all_data[j]['degen']
                
                # 能隙差异分析
                gap_diffs = [a - b for a, b in zip(gaps_i, gaps_j)]
                # 差异是否常数
                diff_constant = all(abs(d - gap_diffs[0]) < TOL_STRUCT for d in gap_diffs)
                # 差异符号一致性
                signs = set()
                for d in gap_diffs:
                    if abs(d) > TOL_STRUCT:
                        signs.add(1 if d > 0 else -1)
                sign_consistent = len(signs) <= 1
                # 基态能量是否相同
                E0_same = all(abs(a - b) < TOL_STRUCT for a, b in zip(E0s_i, E0s_j))
                # 第一激发态能量是否相同
                E1_same = all(abs(a - b) < TOL_STRUCT for a, b in zip(E1s_i, E1s_j))
                # 简并度是否相同
                degen_same = degens_i == degens_j
                
                # 是否割点边 vs 分支边
                u_i, v_i = edges[i]
                u_j, v_j = edges[j]
                touches_cut_i = any(cv in (u_i, v_i) for cv in cut_vertices)
                touches_cut_j = any(cv in (u_j, v_j) for cv in cut_vertices)
                one_touches = touches_cut_i != touches_cut_j
                
                exceptions.append({
                    'graph': g_idx,
                    'edge_i': i,
                    'edge_j': j,
                    'edges_i': edges[i],
                    'edges_j': edges[j],
                    'orbit_i': edge_to_orbit[i],
                    'orbit_j': edge_to_orbit[j],
                    'cut_vertices': cut_vertices,
                    'touches_cut_i': touches_cut_i,
                    'touches_cut_j': touches_cut_j,
                    'one_touches_cut': one_touches,
                    'gap_diffs': gap_diffs,
                    'diff_constant': diff_constant,
                    'sign_consistent': sign_consistent,
                    'E0_same': E0_same,
                    'E1_same': E1_same,
                    'degen_same': degen_same,
                    'E0s_i': E0s_i,
                    'E0s_j': E0s_j,
                    'E1s_i': E1s_i,
                    'E1s_j': E1s_j,
                    'degens_i': degens_i,
                    'degens_j': degens_j,
                    'gaps_i': gaps_i,
                    'gaps_j': gaps_j
                })
    
    print(f"能隙例外总数：{len(exceptions)}\n")
    
    # 统计
    n_diff_constant = sum(1 for e in exceptions if e['diff_constant'])
    n_sign_consistent = sum(1 for e in exceptions if e['sign_consistent'])
    n_E0_same = sum(1 for e in exceptions if e['E0_same'])
    n_E1_same = sum(1 for e in exceptions if e['E1_same'])
    n_degen_same = sum(1 for e in exceptions if e['degen_same'])
    n_one_touches = sum(1 for e in exceptions if e['one_touches_cut'])
    
    print("===== 结构性统计 =====")
    print(f"能隙差异为常数：{n_diff_constant}/{len(exceptions)}")
    print(f"能隙差异符号一致：{n_sign_consistent}/{len(exceptions)}")
    print(f"基态能量相同：{n_E0_same}/{len(exceptions)}")
    print(f"第一激发态能量相同：{n_E1_same}/{len(exceptions)}")
    print(f"简并度相同：{n_degen_same}/{len(exceptions)}")
    print(f"一边触碰割点另一边不碰：{n_one_touches}/{len(exceptions)}")
    
    # 输出详细信息
    print(f"\n===== 例外详细结构 =====")
    for e in exceptions:
        print(f"\n图{e['graph']} 边{e['edge_i']}({e['edges_i']}) vs 边{e['edge_j']}({e['edges_j']})")
        print(f"  轨道: {e['orbit_i']} vs {e['orbit_j']}, 割点: {e['cut_vertices']}")
        print(f"  触碰割点: i={e['touches_cut_i']}, j={e['touches_cut_j']}")
        print(f"  能隙差异: {[round(d,4) for d in e['gap_diffs']]}")
        print(f"  差异常数: {e['diff_constant']}, 符号一致: {e['sign_consistent']}")
        print(f"  基态能量相同: {e['E0_same']}, 第一激发态能量相同: {e['E1_same']}")
        print(f"  简并度: i={e['degens_i']}, j={e['degens_j']}")
        print(f"  能隙_i: {[round(g,4) for g in e['gaps_i']]}")
        print(f"  能隙_j: {[round(g,4) for g in e['gaps_j']]}")
    
    # 最典型的模式分析
    print(f"\n===== 能隙差异常数且符号一致 =====")
    constant_consistent = [e for e in exceptions if e['diff_constant'] and e['sign_consistent']]
    print(f"数量：{len(constant_consistent)}")
    for e in constant_consistent:
        print(f"  图{e['graph']} 边{e['edge_i']} vs 边{e['edge_j']}: 能隙差恒为 {e['gap_diffs'][0]:.6f}")
        print(f"    能隙_i={e['gaps_i'][0]:.6f}, 能隙_j={e['gaps_j'][0]:.6f}")
    
    output = {
        'n_exceptions': len(exceptions),
        'n_diff_constant': n_diff_constant,
        'n_sign_consistent': n_sign_consistent,
        'n_E0_same': n_E0_same,
        'n_E1_same': n_E1_same,
        'n_degen_same': n_degen_same,
        'n_one_touches': n_one_touches,
        'exceptions': exceptions,
        'note': '能隙例外的结构性分析。'
    }
    with open('jingmai_why_gap_exception_structure.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_gap_exception_structure.json")

if __name__ == "__main__":
    main()