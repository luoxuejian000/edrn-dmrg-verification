"""
追问为什么_等价类是图论量还是量子量.py

目标：
    检验排序分布等价类的本质：
        如果它由图结构决定，那么改变相互作用但保持图不变，
        等价类应保持不变。
        如果它依赖量子哈密顿量，改变相互作用后等价类应变化。
    对N=6小世界图（seed=42），在四个模型下计算排序分布等价类：
        1. 海森堡
        2. XXZ (Δ=1.5)
        3. 海森堡 + 次近邻(0.2)
        4. 海森堡 + 次近邻(0.5)
    比较四个模型的等价矩阵是否完全相同。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。
    基态简并使用对称性约化密度矩阵。

输出：
    jingmai_why_equivalence_class_quantum.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
S_POINTS = 11
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10

def get_small_world_edges(N=6, seed=42):
    G = nx.watts_strogatz_graph(N, 4, 0.1, seed=seed)
    edges = [tuple(sorted(e)) for e in G.edges()]
    edges.sort()
    return edges

def build_basis(N):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    return basis, state_to_idx

def add_heisenberg_term(H, basis, state_to_idx, edges, J_vals):
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J

def build_heisenberg(N, edges, J_vals):
    basis, state_to_idx = build_basis(N)
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    add_heisenberg_term(H, basis, state_to_idx, edges, J_vals)
    return H, basis

def build_xxz(N, edges, J_vals, delta_zz=1.5):
    basis, state_to_idx = build_basis(N)
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * delta_zz * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def build_nnn(N, edges, J_vals, nnn_strength=0.2):
    """海森堡 + 次近邻相互作用（次近邻由图结构定义）"""
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    nnn_edges = []
    for i in range(N):
        for j in range(i+1, N):
            if not G.has_edge(i, j):
                if nx.has_path(G, i, j):
                    if nx.shortest_path_length(G, i, j) == 2:
                        nnn_edges.append((i, j))
    nnn_edges.sort()
    
    basis, state_to_idx = build_basis(N)
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    # 原边相互作用
    add_heisenberg_term(H, basis, state_to_idx, edges, J_vals)
    # 次近邻相互作用
    nnn_J = [nnn_strength] * len(nnn_edges)
    add_heisenberg_term(H, basis, state_to_idx, nnn_edges, nnn_J)
    return H, basis

def compute_probs_with_degen(N, edges, J_vals, model):
    if model == 'heisenberg':
        H, basis = build_heisenberg(N, edges, J_vals)
    elif model == 'xxz':
        H, basis = build_xxz(N, edges, J_vals)
    elif model == 'nnn_0.2':
        H, basis = build_nnn(N, edges, J_vals, 0.2)
    elif model == 'nnn_0.5':
        H, basis = build_nnn(N, edges, J_vals, 0.5)
    else:
        raise ValueError(model)
    
    evals, evecs = np.linalg.eigh(H)
    E0 = evals[0]
    degen_indices = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
    degen_dim = len(degen_indices)
    probs = np.zeros(len(basis))
    for idx in degen_indices:
        probs += np.abs(evecs[:, idx])**2
    probs /= degen_dim
    return probs, basis

def compute_corrs(N, edges, basis, probs):
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return np.array(corrs)

def get_sorted_curves(N, edges, model, s_values):
    n_edges = len(edges)
    curves = []
    for i in range(n_edges):
        curve = []
        for s in s_values:
            J = np.ones(n_edges)
            J[i] = s
            probs, basis = compute_probs_with_degen(N, edges, J, model)
            corrs = compute_corrs(N, edges, basis, probs)
            curve.append(np.sort(corrs))
        curves.append(curve)
    return curves

def build_equiv_matrix(sorted_curves, n_edges):
    equiv = np.zeros((n_edges, n_edges), dtype=bool)
    for i in range(n_edges):
        for j in range(i+1, n_edges):
            same = True
            for c1, c2 in zip(sorted_curves[i], sorted_curves[j]):
                if not np.allclose(c1, c2, atol=TOL_CURVE):
                    same = False
                    break
            equiv[i, j] = equiv[j, i] = same
    for i in range(n_edges):
        equiv[i, i] = True
    return equiv

def main():
    print("=== 追问为什么_等价类是图论量还是量子量 ===\n")
    
    edges = get_small_world_edges(N, 42)
    n_edges = len(edges)
    s_values = np.linspace(-1.5, 0.0, S_POINTS)
    print(f"小世界图：{n_edges}边，扫描点数{S_POINTS}\n")
    
    models = ['heisenberg', 'xxz', 'nnn_0.2', 'nnn_0.5']
    equiv_matrices = {}
    
    for model in models:
        print(f"计算模型 {model} ...")
        sorted_curves = get_sorted_curves(N, edges, model, s_values)
        equiv = build_equiv_matrix(sorted_curves, n_edges)
        equiv_matrices[model] = equiv
        n_same = (equiv.sum() - n_edges) // 2
        print(f"  等价边对数：{n_same}")
    
    # 比较四个模型的等价矩阵
    print("\n===== 等价矩阵比较 =====")
    base = 'heisenberg'
    for model in models[1:]:
        same = np.array_equal(equiv_matrices[base], equiv_matrices[model])
        n_diff = int(np.sum(equiv_matrices[base] != equiv_matrices[model]))
        print(f"{base} vs {model}: 相同={same}, 差异矩阵元={n_diff}")
    
    # 判断
    all_same = all(np.array_equal(equiv_matrices[base], equiv_matrices[m]) for m in models[1:])
    if all_same:
        print("\n所有模型给出相同的排序分布等价类。")
        print("结论：排序分布等价类由图结构决定，不依赖具体相互作用。")
    else:
        print("\n不同模型给出不同的排序分布等价类。")
        print("结论：排序分布等价类依赖量子哈密顿量，不是纯图论量。")
    
    output = {
        'edges': edges,
        'models': models,
        'equiv_matrices': {m: equiv_matrices[m].tolist() for m in models},
        'all_same': all_same,
        'note': '检验排序分布等价类是否由图结构决定。'
    }
    with open('jingmai_why_equivalence_class_quantum.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_equivalence_class_quantum.json")

if __name__ == "__main__":
    main()