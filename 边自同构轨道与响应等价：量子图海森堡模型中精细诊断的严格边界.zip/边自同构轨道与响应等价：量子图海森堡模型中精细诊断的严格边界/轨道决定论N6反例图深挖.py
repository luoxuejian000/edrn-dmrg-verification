"""
轨道决定论N6反例图深挖.py

目标：
    对N=6穷举中出现的26个反例图进行深挖，找出轨道决定论失效的条件。
    对每个反例图，检查：
        1. 基态是否简并（扫描中任意点能隙<1e-8）
        2. 反例类型：同轨道异曲线/异轨道同曲线
        3. 边轨道划分
        4. 端点度对、环长等标准物理量
        5. 与正例图的区别
    并排呈现标准物理与晶脉视角。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。
    使用精确对角化。

理论精髓：
    - 主动分析反例，不回避。
    - 数据自己说话。

输出：
    jingmai_n6_counterexample_graphs.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
TOL = 1e-8

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def build_hamiltonian(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def compute_E_fine(N, edges, J_vals):
    H, basis = build_hamiltonian(N, edges, J_vals)
    evals, evecs = np.linalg.eigh(H)
    return float(np.std([np.sum(np.abs(evecs[:,0])**2 * 
        np.array([1.0 if ((st>>i)&1) else -1.0 for st in basis]) *
        np.array([1.0 if ((st>>j)&1) else -1.0 for st in basis]))
        for (i,j) in edges]))

def compute_gap(N, edges, J_vals):
    H, basis = build_hamiltonian(N, edges, J_vals)
    evals = np.linalg.eigvalsh(H)
    return float(evals[1] - evals[0])

def get_edge_orbits_from_edges(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    automorphisms = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in automorphisms:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return orbits, edge_to_orbit

def same_curve(c1, c2, tol=TOL):
    return np.allclose(c1, c2, atol=tol)

def main():
    print("=== 轨道决定论N6反例图深挖 ===\n")
    
    all_graphs = get_all_N6_graphs()
    print(f"总图数：{len(all_graphs)}")
    
    # 找出所有反例图
    ce_graphs = []
    for g_idx, edges in enumerate(all_graphs):
        n_edges = len(edges)
        orbits, edge_to_orbit = get_edge_orbits_from_edges(edges, N)
        s_values = np.linspace(-1.5, 0.0, 31)
        E_curves = []
        for i in range(n_edges):
            curve = np.zeros(31)
            for si, s in enumerate(s_values):
                J = np.ones(n_edges); J[i] = s
                curve[si] = compute_E_fine(N, edges, J)
            E_curves.append(curve)
        
        has_ce = False
        ce_details = []
        for i in range(n_edges):
            for j in range(i+1, n_edges):
                cs = same_curve(E_curves[i], E_curves[j])
                os_ = edge_to_orbit[i] == edge_to_orbit[j]
                if (os_ and not cs) or (not os_ and cs):
                    has_ce = True
                    ce_details.append({
                        'type': 'same_orbit_diff' if os_ else 'diff_orbit_same',
                        'edge_i': i,
                        'edge_j': j,
                        'orbit_i': edge_to_orbit[i],
                        'orbit_j': edge_to_orbit[j]
                    })
        
        if has_ce:
            # 检查基态简并
            degen_points = []
            for si, s in enumerate(s_values):
                J = np.ones(n_edges); J[0] = s
                gap = compute_gap(N, edges, J)
                if gap < TOL:
                    degen_points.append(float(s))
            
            ce_graphs.append({
                'graph_index': g_idx,
                'edges': edges,
                'n_edges': n_edges,
                'n_orbits': len(orbits),
                'orbits': orbits,
                'ce_details': ce_details,
                'n_ce': len(ce_details),
                'degen_points': degen_points,
                'has_degeneracy': len(degen_points) > 0
            })
    
    print(f"反例图数量：{len(ce_graphs)}")
    
    # 输出每个反例图
    for g in ce_graphs:
        print(f"\n===== 图 {g['graph_index']}（{g['n_edges']}边，{g['n_orbits']}轨道） =====")
        print(f"边列表：{g['edges']}")
        print(f"轨道：{g['orbits']}")
        print(f"反例数：{g['n_ce']}")
        for ce in g['ce_details'][:5]:
            print(f"  {ce}")
        print(f"简并点：{g['degen_points'][:5]}{'...' if len(g['degen_points'])>5 else ''}")
        print(f"是否简并：{g['has_degeneracy']}")
    
    # 统计
    total = len(ce_graphs)
    degen_count = sum(1 for g in ce_graphs if g['has_degeneracy'])
    no_degen_count = total - degen_count
    print(f"\n===== 统计 =====")
    print(f"总反例图：{total}")
    print(f"有简并的：{degen_count}")
    print(f"无简并的：{no_degen_count}")
    
    # 无简并的反例图
    no_degen_graphs = [g for g in ce_graphs if not g['has_degeneracy']]
    if no_degen_graphs:
        print(f"\n无简并但仍反例的图：")
        for g in no_degen_graphs:
            print(f"  图{g['graph_index']}：{g['edges']}, 轨道数{g['n_orbits']}")
    
    # 保存
    output = {
        'total_graphs': len(all_graphs),
        'ce_graphs': ce_graphs,
        'n_ce_graphs': total,
        'degen_count': degen_count,
        'no_degen_count': no_degen_count,
        'note': 'N=6穷举反例图深挖结果。'
    }
    with open('jingmai_n6_counterexample_graphs.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_n6_counterexample_graphs.json")

if __name__ == "__main__":
    main()