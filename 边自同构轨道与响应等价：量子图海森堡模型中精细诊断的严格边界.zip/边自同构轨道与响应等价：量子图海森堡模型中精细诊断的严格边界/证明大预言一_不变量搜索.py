"""
证明大预言一_不变量搜索.py

目标：
    搜索能够精确刻画排序分布等价类的图论不变量。
    对N=6全部112个连通图，计算每条边的排序分布等价类，
    并与以下候选图论不变量逐一比较：
        1. 边自同构轨道
        2. 边删除同构
        3. 端点度对（排序）
        4. 端点度之和
        5. 边介数
        6. 边参与环长集合
        7. 是否桥边
        8. 删除边后图的度序列
        9. 删除边后图的连通分量数
        10. 删除边后图的直径（若连通）
    对每个不变量，构建等价矩阵，与排序分布等价矩阵比较，
    统计不一致图数和不一致边对数。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。
    基态简并使用对称性约化密度矩阵。
    排序分布比较容差 1e-10。
    扫描Δ点数：11（-1.5 到 0.0 等间距）。

理论精髓：
    - 数据自己说话。
    - 标准物理（各候选不变量）与晶脉视角（排序分布等价类）并排。
    - 追问：是否存在一个图论不变量完全一致？

输出：
    jingmai_invariant_search.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
S_POINTS = 11
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10

# 候选不变量名称
INVARIANT_NAMES = [
    'orbit',              # 边自同构轨道
    'deletion_iso',       # 边删除同构
    'deg_pair',           # 端点度对（排序）
    'deg_sum',            # 端点度之和
    'betweenness',        # 边介数
    'cycles',             # 边参与环长集合
    'bridge',             # 是否桥边
    'del_deg_seq',        # 删除边后图的度序列
    'del_n_components',   # 删除边后图的连通分量数
    'del_diameter'        # 删除边后图的直径（若连通）
]

def build_hamiltonian_and_basis(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def compute_probs_with_degen(N, edges, J_vals):
    H, basis = build_hamiltonian_and_basis(N, edges, J_vals)
    evals, evecs = np.linalg.eigh(H)
    E0 = evals[0]
    degen_indices = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
    degen_dim = len(degen_indices)
    probs = np.zeros(len(basis))
    for idx in degen_indices:
        probs += np.abs(evecs[:, idx])**2
    probs /= degen_dim
    return probs, basis

def compute_corrs_from_probs(N, edges, basis, probs):
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return np.array(corrs)

def get_sorted_correlation_curve(N, edges, defect_idx, s_values):
    n_edges = len(edges)
    curve = []
    for s in s_values:
        J = np.ones(n_edges)
        J[defect_idx] = s
        probs, basis = compute_probs_with_degen(N, edges, J)
        corrs = compute_corrs_from_probs(N, edges, basis, probs)
        curve.append(np.sort(corrs))
    return curve

def curves_equal(curve1, curve2, tol=TOL_CURVE):
    if len(curve1) != len(curve2):
        return False
    for c1, c2 in zip(curve1, curve2):
        if not np.allclose(c1, c2, atol=tol):
            return False
    return True

def build_equiv_matrix_from_curves(sorted_curves, n_edges):
    equiv = np.zeros((n_edges, n_edges), dtype=bool)
    for i in range(n_edges):
        for j in range(i+1, n_edges):
            same = curves_equal(sorted_curves[i], sorted_curves[j])
            equiv[i, j] = equiv[j, i] = same
    for i in range(n_edges):
        equiv[i, i] = True
    return equiv

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def get_edge_orbits(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    automorphisms = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in automorphisms:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return edge_to_orbit

def get_invariant_value(edges, N, edge_idx, invariant_name):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    u, v = edges[edge_idx]

    if invariant_name == 'orbit':
        # 轨道编号
        edge_to_orbit = get_edge_orbits(edges, N)
        return edge_to_orbit[edge_idx]
    elif invariant_name == 'deletion_iso':
        # 删除同构类：用删除后图的图同构特征，这里返回一个标记，需要统一计算
        G_del = G.copy()
        G_del.remove_edge(u, v)
        # 返回度序列和连通分量数、直径作为图同构的指纹
        deg_seq = sorted([d for _, d in G_del.degree()])
        n_comp = nx.number_connected_components(G_del)
        diam = nx.diameter(G_del) if nx.is_connected(G_del) else -1
        return ('del_iso', deg_seq, n_comp, diam)
    elif invariant_name == 'deg_pair':
        return tuple(sorted([G.degree(u), G.degree(v)]))
    elif invariant_name == 'deg_sum':
        return G.degree(u) + G.degree(v)
    elif invariant_name == 'betweenness':
        edge_bc = nx.edge_betweenness_centrality(G)
        return edge_bc.get((u, v), edge_bc.get((v, u), 0.0))
    elif invariant_name == 'cycles':
        cycles = []
        for cycle in nx.cycle_basis(G):
            edge_in_cycle = False
            for i in range(len(cycle)):
                a, b = cycle[i], cycle[(i+1)%len(cycle)]
                if (a == u and b == v) or (a == v and b == u):
                    edge_in_cycle = True
                    break
            if edge_in_cycle:
                cycles.append(len(cycle))
        return tuple(sorted(cycles))
    elif invariant_name == 'bridge':
        G_del = G.copy()
        G_del.remove_edge(u, v)
        return nx.is_connected(G_del)  # False表示桥
    elif invariant_name == 'del_deg_seq':
        G_del = G.copy()
        G_del.remove_edge(u, v)
        return tuple(sorted([d for _, d in G_del.degree()]))
    elif invariant_name == 'del_n_components':
        G_del = G.copy()
        G_del.remove_edge(u, v)
        return nx.number_connected_components(G_del)
    elif invariant_name == 'del_diameter':
        G_del = G.copy()
        G_del.remove_edge(u, v)
        if nx.is_connected(G_del):
            return nx.diameter(G_del)
        else:
            return -1
    else:
        raise ValueError(f"Unknown invariant: {invariant_name}")

def build_invariant_equiv_matrix(edges, N, invariant_name, tolerance=1e-10):
    n_edges = len(edges)
    # 对每条边计算不变量值
    values = []
    for i in range(n_edges):
        values.append(get_invariant_value(edges, N, i, invariant_name))
    equiv = np.zeros((n_edges, n_edges), dtype=bool)
    for i in range(n_edges):
        for j in range(i+1, n_edges):
            # 判断值是否相同（对于浮点数使用容差）
            if isinstance(values[i], float) and isinstance(values[j], float):
                same = abs(values[i] - values[j]) < tolerance
            else:
                same = values[i] == values[j]
            equiv[i, j] = equiv[j, i] = same
    for i in range(n_edges):
        equiv[i, i] = True
    return equiv

def main():
    print("=== 证明大预言一：不变量搜索 ===\n")
    
    all_graphs = get_all_N6_graphs()
    s_values = np.linspace(-1.5, 0.0, S_POINTS)
    print(f"总图数：{len(all_graphs)}")
    print(f"扫描点数：{S_POINTS}")
    print(f"候选不变量：{INVARIANT_NAMES}\n")
    
    # 对每个图，计算排序分布等价矩阵和各候选不变量等价矩阵
    inconsistency_counts = {name: {'n_graphs': 0, 'n_edges': 0} for name in INVARIANT_NAMES}
    inconsistent_details = {name: [] for name in INVARIANT_NAMES}
    
    for g_idx, edges in enumerate(all_graphs):
        n_edges = len(edges)
        # 计算排序分布等价矩阵
        sorted_curves = []
        for i in range(n_edges):
            curve = get_sorted_correlation_curve(N, edges, i, s_values)
            sorted_curves.append(curve)
        sorted_equiv = build_equiv_matrix_from_curves(sorted_curves, n_edges)
        
        # 对每个不变量，计算等价矩阵并与排序等价矩阵比较
        for inv_name in INVARIANT_NAMES:
            inv_equiv = build_invariant_equiv_matrix(edges, N, inv_name)
            if np.array_equal(sorted_equiv, inv_equiv):
                continue  # 该图完全一致
            inconsistency_counts[inv_name]['n_graphs'] += 1
            # 找出差异边对
            diff_pairs = []
            for i in range(n_edges):
                for j in range(i+1, n_edges):
                    if sorted_equiv[i, j] != inv_equiv[i, j]:
                        if sorted_equiv[i, j]:
                            typ = 'sorted_same_inv_diff'
                        else:
                            typ = 'sorted_diff_inv_same'
                        diff_pairs.append((i, j, typ))
                        inconsistency_counts[inv_name]['n_edges'] += 1
            inconsistent_details[inv_name].append({
                'graph': g_idx,
                'diff_pairs': diff_pairs
            })
        
        if (g_idx+1) % 30 == 0:
            print(f"  进度：{g_idx+1}/{len(all_graphs)}")
    
    # 输出结果
    print("\n===== 各候选不变量与排序分布等价类的一致性 =====")
    print(f"{'不变量':<20} {'不一致图数':<10} {'不一致边对数':<12}")
    print("-" * 45)
    for inv_name in INVARIANT_NAMES:
        print(f"{inv_name:<20} {inconsistency_counts[inv_name]['n_graphs']:<10} "
              f"{inconsistency_counts[inv_name]['n_edges']:<12}")
    
    # 找出完美匹配的不变量
    perfect_invariants = [name for name in INVARIANT_NAMES 
                          if inconsistency_counts[name]['n_graphs'] == 0]
    if perfect_invariants:
        print(f"\n完全一致的图论不变量：{perfect_invariants}")
    else:
        print("\n不存在单一候选不变量与排序分布等价类完全一致。")
    
    # 输出最接近的不变量
    best_inv = min(INVARIANT_NAMES, key=lambda x: inconsistency_counts[x]['n_graphs'])
    print(f"\n最接近的候选不变量：{best_inv}")
    print(f"  不一致图数：{inconsistency_counts[best_inv]['n_graphs']}")
    
    # 输出该不变量的差异详情（前3个图）
    if inconsistency_counts[best_inv]['n_graphs'] > 0:
        print(f"\n{best_inv} 差异图详情（前3个）：")
        for detail in inconsistent_details[best_inv][:3]:
            print(f"  图{detail['graph']}: {len(detail['diff_pairs'])} 对差异")
            for p in detail['diff_pairs'][:5]:
                print(f"    边{p[0]} vs 边{p[1]} ({p[2]})")
    
    output = {
        'inconsistency_counts': inconsistency_counts,
        'inconsistent_details': inconsistent_details,
        'perfect_invariants': perfect_invariants,
        'best_invariant': best_inv,
        'note': '搜索能刻画排序分布等价类的图论不变量。'
    }
    with open('jingmai_invariant_search.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_invariant_search.json")

if __name__ == "__main__":
    main()