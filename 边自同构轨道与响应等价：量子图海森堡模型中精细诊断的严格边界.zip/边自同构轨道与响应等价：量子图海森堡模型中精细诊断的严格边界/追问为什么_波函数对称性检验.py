"""
追问为什么_波函数对称性检验.py

目标：
    检验同轨道边对扫描时基态波函数是否满足自同构对称性。
    若自同构映射保持哈密顿量，则基态波函数应当满足：
        |ψ_j> = U_φ |ψ_i>
    其中 U_φ 是节点映射 φ 诱导的基向量置换矩阵。
    若不满足，则说明数值对角化没有返回对称性保持的基态，
    这是同轨道异曲线反例的可能根源。

方法：
    对每个反例图，取同轨道边对，扫描两边得到基态波函数，
    应用映射后比较，输出最大差异。
    并排输出标准物理（波函数对称性）与晶脉视角（反例边对）。

输出：
    jingmai_why_wavefunction_symmetry.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6

def build_hamiltonian_and_basis(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def get_automorphisms(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    GM = iso.GraphMatcher(G, G)
    return list(GM.isomorphisms_iter())

def get_edge_orbits_from_edges(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    automorphisms = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in automorphisms:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return orbits, edge_to_orbit

def build_permutation_matrix(basis, mapping, N):
    """根据节点映射构建基向量置换矩阵"""
    new_basis_states = []
    for state in basis:
        new_state = 0
        for i in range(N):
            if (state >> i) & 1:
                new_state |= (1 << mapping[i])
        new_basis_states.append(new_state)
    # 找到新基向量在原基向量中的索引
    new_state_to_idx = {st: i for i, st in enumerate(new_basis_states)}
    # 实际上我们需要的是 U_φ |ψ_i> = |ψ_j>，其中 U_φ 作用于振幅，使得在旧基下的振幅变换后对应新基
    # 这里简单起见：直接将原波函数的振幅按新基重排
    P = np.zeros((len(basis), len(basis)), dtype=float)
    for old_idx, new_state in enumerate(new_basis_states):
        # new_state 在 basis 中的索引
        new_idx = basis.index(new_state) if new_state in basis else None
        # 实际上应该总在 basis 中，因为 basis 包含所有组合
        if new_idx is not None:
            P[new_idx, old_idx] = 1.0
    return P

def main():
    print("=== 追问为什么_波函数对称性检验 ===\n")
    
    all_graphs = get_all_N6_graphs()
    
    # 已知反例图索引
    ce_graph_indices = [38, 80, 82, 89, 93, 110, 111]
    results = []
    
    for g_idx in ce_graph_indices:
        edges = all_graphs[g_idx]
        n_edges = len(edges)
        orbits, edge_to_orbit = get_edge_orbits_from_edges(edges, N)
        automorphisms = get_automorphisms(edges, N)
        
        print(f"\n===== 图 {g_idx}（{n_edges}边，{len(orbits)}轨道） =====")
        
        s_val = -0.5
        J_template = np.ones(n_edges)
        
        for oi, orbit in enumerate(orbits):
            if len(orbit) < 2:
                continue
            ei = orbit[0]
            ej = orbit[1]
            
            # 找映射
            mapping = None
            for auto in automorphisms:
                mapped_edge = tuple(sorted((auto[edges[ei][0]], auto[edges[ei][1]])))
                if mapped_edge == edges[ej]:
                    mapping = auto
                    break
            if mapping is None:
                continue
            
            # 扫描 ei
            J_i = J_template.copy(); J_i[ei] = s_val
            H_i, basis_i = build_hamiltonian_and_basis(N, edges, J_i)
            evals_i, evecs_i = np.linalg.eigh(H_i)
            psi_i = evecs_i[:, 0]
            
            # 扫描 ej
            J_j = J_template.copy(); J_j[ej] = s_val
            H_j, basis_j = build_hamiltonian_and_basis(N, edges, J_j)
            evals_j, evecs_j = np.linalg.eigh(H_j)
            psi_j = evecs_j[:, 0]
            
            # 应用映射到 psi_i
            P = build_permutation_matrix(basis_i, mapping, N)
            psi_i_mapped = P @ psi_i
            
            # 比较 psi_i_mapped 与 psi_j
            # 由于可能相差一个符号，计算绝对内积
            overlap = np.abs(np.dot(psi_i_mapped, psi_j))
            diff_norm = np.linalg.norm(psi_i_mapped - psi_j)
            sign_flip = np.sign(np.dot(psi_i_mapped, psi_j))
            
            print(f"  轨道{oi}: 边{ei}->边{ej}")
            print(f"    基态波函数映射后与扫描{ej}的绝对内积 = {overlap:.10f}")
            print(f"    波函数差的范数 = {diff_norm:.10e}")
            print(f"    符号 = {sign_flip}")
            
            results.append({
                'graph': g_idx,
                'orbit': oi,
                'edge_i': ei,
                'edge_j': ej,
                'overlap': float(overlap),
                'diff_norm': float(diff_norm),
                'sign_flip': float(sign_flip)
            })
    
    output = {
        'results': results,
        'note': '检验基态波函数是否满足自同构对称性。若重叠<1或差范数>1e-10，则波函数对称性破坏。'
    }
    with open('jingmai_why_wavefunction_symmetry.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_wavefunction_symmetry.json")

if __name__ == "__main__":
    main()