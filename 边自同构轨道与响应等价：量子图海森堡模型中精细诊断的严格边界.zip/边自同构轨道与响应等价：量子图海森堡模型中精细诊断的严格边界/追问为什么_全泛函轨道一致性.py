"""
追问为什么_全泛函轨道一致性.py

目标：
    继续追问：排序关联分布的哪些泛函能忠实保持轨道分类？
    对每个N=6连通图，正确处理基态简并后，对每条边扫描得到排序关联分布，
    计算多个泛函：std, range, entropy, skewness, kurtosis, max_abs, mean。
    对同轨道边对和异轨道边对，逐Δ点比较各泛函是否相同。
    输出统计：同轨道同泛函、同轨道异泛函、异轨道同泛函、异轨道异泛函。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。
    基态简并使用对称性约化密度矩阵。

理论精髓：
    - 数据自己说话。
    - 追问：是否存在泛函使轨道分类完美保持？

输出：
    jingmai_why_all_functionals_consistency.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
S_POINTS = 21
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10

FUNCTIONAL_NAMES = ['std', 'range', 'entropy', 'skewness', 'kurtosis', 'max_abs', 'mean']

def build_hamiltonian_and_basis(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def compute_probs_with_degen(N, edges, J_vals):
    H, basis = build_hamiltonian_and_basis(N, edges, J_vals)
    evals, evecs = np.linalg.eigh(H)
    E0 = evals[0]
    degen_indices = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
    degen_dim = len(degen_indices)
    probs = np.zeros(len(basis))
    for idx in degen_indices:
        probs += np.abs(evecs[:, idx])**2
    probs /= degen_dim
    return probs, basis

def compute_corrs_from_probs(N, edges, basis, probs):
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return np.array(corrs)

def compute_functionals(corrs):
    corrs = np.array(corrs)
    mean = float(np.mean(corrs))
    std = float(np.std(corrs))
    rng = float(np.max(corrs) - np.min(corrs))
    if std < 1e-12:
        skew = 0.0
        kurt = 0.0
    else:
        skew = float(np.mean(((corrs - mean)/std)**3))
        kurt = float(np.mean(((corrs - mean)/std)**4))
    abs_corrs = np.abs(corrs)
    total = np.sum(abs_corrs)
    if total < 1e-14:
        ent = 0.0
    else:
        probs = abs_corrs / total
        probs = probs[probs > 1e-14]
        ent = float(-np.sum(probs * np.log(probs)))
    max_abs = float(np.max(np.abs(corrs)))
    return {
        'std': std,
        'range': rng,
        'entropy': ent,
        'skewness': skew,
        'kurtosis': kurt,
        'max_abs': max_abs,
        'mean': mean
    }

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def get_edge_orbits_from_edges(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    automorphisms = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in automorphisms:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return orbits, edge_to_orbit

def same_curve(c1, c2, tol=TOL_CURVE):
    return np.allclose(c1, c2, atol=tol)

def main():
    print("=== 追问为什么_全泛函轨道一致性 ===\n")
    
    all_graphs = get_all_N6_graphs()
    s_values = np.linspace(-1.5, 0.0, S_POINTS)
    print(f"总图数：{len(all_graphs)}")
    print(f"扫描点数：{S_POINTS}")
    print(f"泛函：{FUNCTIONAL_NAMES}\n")
    
    # 全局统计：对每个泛函
    global_stats = {name: {'same_orbit_same': 0, 'same_orbit_diff': 0,
                            'diff_orbit_same': 0, 'diff_orbit_diff': 0}
                    for name in FUNCTIONAL_NAMES}
    
    # 逐图处理
    for g_idx, edges in enumerate(all_graphs):
        n_edges = len(edges)
        orbits, edge_to_orbit = get_edge_orbits_from_edges(edges, N)
        
        # 对每条边，计算每个泛函的曲线
        functional_curves = {name: [] for name in FUNCTIONAL_NAMES}
        for i in range(n_edges):
            curves = {name: [] for name in FUNCTIONAL_NAMES}
            for s in s_values:
                J = np.ones(n_edges); J[i] = s
                probs, basis = compute_probs_with_degen(N, edges, J)
                corrs = compute_corrs_from_probs(N, edges, basis, probs)
                funcs = compute_functionals(corrs)
                for name in FUNCTIONAL_NAMES:
                    curves[name].append(funcs[name])
            for name in FUNCTIONAL_NAMES:
                functional_curves[name].append(np.array(curves[name]))
        
        # 比较边对
        for i in range(n_edges):
            for j in range(i+1, n_edges):
                orbit_same = edge_to_orbit[i] == edge_to_orbit[j]
                for name in FUNCTIONAL_NAMES:
                    curve_same = same_curve(functional_curves[name][i], functional_curves[name][j])
                    if orbit_same:
                        if curve_same:
                            global_stats[name]['same_orbit_same'] += 1
                        else:
                            global_stats[name]['same_orbit_diff'] += 1
                    else:
                        if curve_same:
                            global_stats[name]['diff_orbit_same'] += 1
                        else:
                            global_stats[name]['diff_orbit_diff'] += 1
        
        if (g_idx+1) % 30 == 0:
            print(f"  进度：{g_idx+1}/{len(all_graphs)}")
    
    # 打印统计
    print("\n===== 各泛函轨道一致性统计 =====")
    print(f"{'泛函':<12} {'同轨道同':<10} {'同轨道异':<10} {'异轨道同':<10} {'异轨道异':<10}")
    print("-" * 55)
    for name in FUNCTIONAL_NAMES:
        s = global_stats[name]
        print(f"{name:<12} {s['same_orbit_same']:<10} {s['same_orbit_diff']:<10} "
              f"{s['diff_orbit_same']:<10} {s['diff_orbit_diff']:<10}")
    
    # 判断哪些泛函是完美的（同轨道异=0且异轨道同=0）
    print("\n===== 完美泛函（同轨道异=0且异轨道同=0） =====")
    for name in FUNCTIONAL_NAMES:
        s = global_stats[name]
        if s['same_orbit_diff'] == 0 and s['diff_orbit_same'] == 0:
            print(f"  {name}: 完美")
        else:
            print(f"  {name}: 不完美（同轨道异={s['same_orbit_diff']}, 异轨道同={s['diff_orbit_same']}）")
    
    output = {
        'FUNCTIONAL_NAMES': FUNCTIONAL_NAMES,
        'global_stats': global_stats,
        'note': '追问：哪些泛函能完美保持轨道分类？'
    }
    with open('jingmai_why_all_functionals_consistency.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_all_functionals_consistency.json")

if __name__ == "__main__":
    main()