"""
追问为什么_能隙例外深挖.py

目标：
    深挖响应等价中"能隙不等价"的29对例外。
    对每对例外，检查：
        1. 两边的能隙曲线具体差异
        2. 两边的响应（排序分布）是否真正相同
        3. 两边的基态简并情况
        4. 两边是否在扫描区间内有能级交叉
        5. 图结构特征（割点、自同构、轨道）
    并排展示标准物理（能隙、简并）与晶脉视角（响应等价）。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。
    基态简并使用对称性约化密度矩阵。

输出：
    jingmai_why_gap_exceptions.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
S_POINTS = 11
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10

def build_heisenberg(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    H = np.zeros((len(basis), len(basis)), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def compute_full(N, edges, J_vals):
    """返回能隙、简并度、排序关联分布"""
    H, basis = build_heisenberg(N, edges, J_vals)
    evals, evecs = np.linalg.eigh(H)
    E0 = evals[0]
    degen = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
    degen_dim = len(degen)
    gap = float(evals[len(degen)] - E0) if len(degen) < len(evals) else 0.0
    probs = np.zeros(len(basis))
    for idx in degen:
        probs += np.abs(evecs[:, idx])**2
    probs /= len(degen)
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return {
        'gap': gap,
        'degen': degen_dim,
        'sorted_corrs': np.sort(np.array(corrs))
    }

def get_all_data(N, edges, s_values):
    n_edges = len(edges)
    gaps = []
    degens = []
    sorted_curves = []
    for i in range(n_edges):
        gap_curve = []
        degen_curve = []
        sorted_curve = []
        for s in s_values:
            J = np.ones(n_edges); J[i] = s
            result = compute_full(N, edges, J)
            gap_curve.append(result['gap'])
            degen_curve.append(result['degen'])
            sorted_curve.append(result['sorted_corrs'])
        gaps.append(gap_curve)
        degens.append(degen_curve)
        sorted_curves.append(sorted_curve)
    return gaps, degens, sorted_curves

def curves_equal(c1, c2, tol=TOL_CURVE):
    if len(c1) != len(c2):
        return False
    for a, b in zip(c1, c2):
        if isinstance(a, np.ndarray) or isinstance(b, np.ndarray):
            if not np.allclose(a, b, atol=tol):
                return False
        else:
            if abs(a - b) > tol:
                return False
    return True

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def get_edge_orbits(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    autos = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in autos:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return edge_to_orbit

def main():
    print("=== 追问为什么_能隙例外深挖 ===\n")
    
    all_graphs = get_all_N6_graphs()
    s_values = np.linspace(-1.5, 0.0, S_POINTS)
    
    exceptions = []
    total_resp_equiv = 0
    total_gap_equiv = 0
    
    for g_idx, edges in enumerate(all_graphs):
        n_edges = len(edges)
        gaps, degens, sorted_curves = get_all_data(N, edges, s_values)
        edge_to_orbit = get_edge_orbits(edges, N)
        G = nx.Graph()
        G.add_nodes_from(range(N))
        G.add_edges_from(edges)
        cut_vertices = list(nx.articulation_points(G))
        
        for i in range(n_edges):
            for j in range(i+1, n_edges):
                resp_same = curves_equal(sorted_curves[i], sorted_curves[j])
                if not resp_same:
                    continue
                total_resp_equiv += 1
                gap_same = curves_equal(gaps[i], gaps[j])
                if gap_same:
                    total_gap_equiv += 1
                else:
                    # 例外
                    # 计算能隙差异
                    gap_diffs = [abs(a-b) for a, b in zip(gaps[i], gaps[j])]
                    max_gap_diff = max(gap_diffs)
                    # 检查简并
                    degen_i = max(degens[i])
                    degen_j = max(degens[j])
                    # 检查是否在扫描中触及能级交叉
                    has_crossing_i = any(d > 1 for d in degens[i])
                    has_crossing_j = any(d > 1 for d in degens[j])
                    
                    exceptions.append({
                        'graph': g_idx,
                        'edge_i': i,
                        'edge_j': j,
                        'edges_i': edges[i],
                        'edges_j': edges[j],
                        'orbit_i': edge_to_orbit[i],
                        'orbit_j': edge_to_orbit[j],
                        'cut_vertices': cut_vertices,
                        'max_gap_diff': float(max_gap_diff),
                        'degen_i': degen_i,
                        'degen_j': degen_j,
                        'has_crossing_i': has_crossing_i,
                        'has_crossing_j': has_crossing_j,
                        'gaps_i': gaps[i],
                        'gaps_j': gaps[j],
                        'degens_i': degens[i],
                        'degens_j': degens[j]
                    })
    
    print(f"响应等价对总数：{total_resp_equiv}")
    print(f"能隙也等价：{total_gap_equiv} ({total_gap_equiv/total_resp_equiv:.4f})")
    print(f"能隙不等价例外：{len(exceptions)} ({len(exceptions)/total_resp_equiv:.4f})\n")
    
    print("===== 例外详情 =====")
    for e in exceptions:
        print(f"\n图{e['graph']}: 边{e['edge_i']}({e['edges_i']}) vs 边{e['edge_j']}({e['edges_j']})")
        print(f"  轨道: {e['orbit_i']} vs {e['orbit_j']}, 割点: {e['cut_vertices']}")
        print(f"  最大能隙差异: {e['max_gap_diff']:.6f}")
        print(f"  扫描中最大简并度: i={e['degen_i']}, j={e['degen_j']}")
        print(f"  扫描中触及能级交叉: i={e['has_crossing_i']}, j={e['has_crossing_j']}")
        print(f"  能隙_i: {[round(g,4) for g in e['gaps_i']]}")
        print(f"  能隙_j: {[round(g,4) for g in e['gaps_j']]}")
    
    # 统计例外特征
    print(f"\n===== 例外特征统计 =====")
    n_with_crossing = sum(1 for e in exceptions if e['has_crossing_i'] or e['has_crossing_j'])
    n_both_no_crossing = sum(1 for e in exceptions if not e['has_crossing_i'] and not e['has_crossing_j'])
    n_with_cut = sum(1 for e in exceptions if e['cut_vertices'])
    n_diff_orbit = sum(1 for e in exceptions if e['orbit_i'] != e['orbit_j'])
    
    print(f"涉及能级交叉的：{n_with_crossing}/{len(exceptions)}")
    print(f"完全不涉及能级交叉的：{n_both_no_crossing}/{len(exceptions)}")
    print(f"涉及割点的：{n_with_cut}/{len(exceptions)}")
    print(f"异轨道对：{n_diff_orbit}/{len(exceptions)}")
    
    # 按最大能隙差异排序
    exceptions_sorted = sorted(exceptions, key=lambda x: -x['max_gap_diff'])
    print(f"\n===== 能隙差异最大的前5对 =====")
    for e in exceptions_sorted[:5]:
        print(f"  图{e['graph']} 边{e['edge_i']} vs 边{e['edge_j']}: 最大能隙差异={e['max_gap_diff']:.6f}")
        print(f"    能隙_i: {[round(g,4) for g in e['gaps_i']]}")
        print(f"    能隙_j: {[round(g,4) for g in e['gaps_j']]}")
        print(f"    简并_i: {e['degens_i']}")
        print(f"    简并_j: {e['degens_j']}")
    
    output = {
        'total_resp_equiv': total_resp_equiv,
        'total_gap_equiv': total_gap_equiv,
        'n_exceptions': len(exceptions),
        'exceptions': exceptions,
        'n_with_crossing': n_with_crossing,
        'n_both_no_crossing': n_both_no_crossing,
        'n_with_cut': n_with_cut,
        'n_diff_orbit': n_diff_orbit,
        'note': '深挖响应等价中能隙例外的结构。'
    }
    with open('jingmai_why_gap_exceptions.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_gap_exceptions.json")

if __name__ == "__main__":
    main()