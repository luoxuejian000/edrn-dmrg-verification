"""
追问为什么_能隙例外统一结构.py

目标：
    对29对能隙例外，追问是否存在统一的结构模式。
    具体检查：
        1. 基态能量E0曲线是否完全相同？（已知全部相同）
        2. 第一激发态能量E1曲线是否有特定关系？
        3. 能隙差异是否总是对应E1的某个固定偏移？
        4. 图108中恒定-2.0差异是否对应E1的整数偏移？
        5. 其余26对例外的E1差异是否也具有结构？
        6. 检查例外的E1曲线是否在某个Δ点发生交换或交叉
    并排展示标准物理（E0、E1、gap）与晶脉视角（响应等价）。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。
    基态简并使用对称性约化密度矩阵。

输出：
    jingmai_why_gap_exception_unified.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
S_POINTS = 11
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10
TOL_STRUCT = 1e-6

def build_basis(N):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    return basis, state_to_idx

def add_heisenberg_term(H, basis, state_to_idx, edges, J_vals):
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J

def build_heisenberg(N, edges, J_vals):
    basis, state_to_idx = build_basis(N)
    H = np.zeros((len(basis), len(basis)), dtype=float)
    add_heisenberg_term(H, basis, state_to_idx, edges, J_vals)
    return H, basis

def compute_full(N, edges, J_vals, k_eigen=8):
    """返回基态能量、前k个能级、排序关联分布"""
    H, basis = build_heisenberg(N, edges, J_vals)
    evals, evecs = np.linalg.eigh(H)
    E0 = float(evals[0])
    # 找出第一个与E0不同的能级
    E1 = None
    for k in range(1, len(evals)):
        if abs(evals[k] - E0) > TOL_DEGEN:
            E1 = float(evals[k])
            break
    gap = E1 - E0 if E1 is not None else 0.0
    degen = sum(1 for e in evals if abs(e - E0) < TOL_DEGEN)
    # 前k个能级
    low_evals = [float(e) for e in evals[:k_eigen]]
    # 关联分布
    probs = np.zeros(len(basis))
    degen_indices = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
    for idx in degen_indices:
        probs += np.abs(evecs[:, idx])**2
    probs /= len(degen_indices)
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return {
        'E0': E0,
        'E1': E1,
        'gap': gap,
        'degen': degen,
        'low_evals': low_evals,
        'sorted_corrs': np.sort(np.array(corrs))
    }

def get_edge_data(N, edges, edge_idx, s_values):
    n_edges = len(edges)
    E0_curve = []
    E1_curve = []
    gap_curve = []
    sorted_curves = []
    degen_curve = []
    low_evals_curve = []
    for s in s_values:
        J = np.ones(n_edges); J[edge_idx] = s
        r = compute_full(N, edges, J)
        E0_curve.append(r['E0'])
        E1_curve.append(r['E1'])
        gap_curve.append(r['gap'])
        sorted_curves.append(r['sorted_corrs'])
        degen_curve.append(r['degen'])
        low_evals_curve.append(r['low_evals'])
    return {
        'E0': E0_curve,
        'E1': E1_curve,
        'gap': gap_curve,
        'degen': degen_curve,
        'sorted_corrs': sorted_curves,
        'low_evals': low_evals_curve
    }

def curves_equal(c1, c2, tol=TOL_CURVE):
    if len(c1) != len(c2):
        return False
    for a, b in zip(c1, c2):
        if isinstance(a, np.ndarray) or isinstance(b, np.ndarray):
            if not np.allclose(a, b, atol=tol):
                return False
        else:
            if abs(a - b) > tol:
                return False
    return True

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def get_edge_orbits(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    autos = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in autos:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return edge_to_orbit

def main():
    print("=== 追问为什么_能隙例外统一结构 ===\n")
    
    all_graphs = get_all_N6_graphs()
    s_values = np.linspace(-1.5, 0.0, S_POINTS)
    
    exceptions = []
    
    for g_idx, edges in enumerate(all_graphs):
        n_edges = len(edges)
        edge_to_orbit = get_edge_orbits(edges, N)
        G = nx.Graph()
        G.add_nodes_from(range(N))
        G.add_edges_from(edges)
        cut_vertices = list(nx.articulation_points(G))
        
        all_data = []
        for i in range(n_edges):
            all_data.append(get_edge_data(N, edges, i, s_values))
        
        for i in range(n_edges):
            for j in range(i+1, n_edges):
                resp_same = curves_equal(all_data[i]['sorted_corrs'], all_data[j]['sorted_corrs'])
                if not resp_same:
                    continue
                gap_same = curves_equal(all_data[i]['gap'], all_data[j]['gap'])
                if gap_same:
                    continue
                # 例外
                gaps_i = all_data[i]['gap']
                gaps_j = all_data[j]['gap']
                E0s_i = all_data[i]['E0']
                E0s_j = all_data[j]['E0']
                E1s_i = all_data[i]['E1']
                E1s_j = all_data[j]['E1']
                
                # 能隙差异
                gap_diffs = [a - b for a, b in zip(gaps_i, gaps_j)]
                E1_diffs = [a - b for a, b in zip(E1s_i, E1s_j)]
                
                # 差异是否常数
                diff_constant = all(abs(d - gap_diffs[0]) < TOL_STRUCT for d in gap_diffs)
                # E1差异是否常数
                E1_diff_constant = all(abs(d - E1_diffs[0]) < TOL_STRUCT for d in E1_diffs)
                
                # 检查E1是否对应某个固定偏移
                # 是否E1_i = E1_j + constant
                E1_fixed_offset = None
                if E1_diff_constant:
                    E1_fixed_offset = E1_diffs[0]
                
                # 在扫描过程中，E1是否发生交换（i的E1超过j的E1）
                E1_swap = False
                for k in range(len(E1s_i)-1):
                    if (E1s_i[k] - E1s_j[k]) * (E1s_i[k+1] - E1s_j[k+1]) < 0:
                        E1_swap = True
                        break
                
                # 检查low_evals是否有一个简单的整数关系
                # 图108中E1差2.0，检查是否E1_j - E1_i = 2.0
                low_evals_relation = None
                if diff_constant:
                    # 检查low_evals的差异模式
                    diffs_list = []
                    for k in range(len(all_data[i]['low_evals'][0])):
                        d = all_data[i]['low_evals'][0][k] - all_data[j]['low_evals'][0][k]
                        diffs_list.append(round(d, 6))
                    low_evals_relation = diffs_list
                
                exceptions.append({
                    'graph': g_idx,
                    'edge_i': i,
                    'edge_j': j,
                    'edges_i': edges[i],
                    'edges_j': edges[j],
                    'orbit_i': edge_to_orbit[i],
                    'orbit_j': edge_to_orbit[j],
                    'cut_vertices': cut_vertices,
                    'gap_diffs': gap_diffs,
                    'E1_diffs': E1_diffs,
                    'diff_constant': diff_constant,
                    'E1_diff_constant': E1_diff_constant,
                    'E1_fixed_offset': E1_fixed_offset,
                    'E1_swap': E1_swap,
                    'gaps_i': gaps_i,
                    'gaps_j': gaps_j,
                    'E1s_i': E1s_i,
                    'E1s_j': E1s_j,
                    'low_evals_i': all_data[i]['low_evals'][0],
                    'low_evals_j': all_data[j]['low_evals'][0],
                    'low_evals_relation': low_evals_relation
                })
    
    print(f"能隙例外总数：{len(exceptions)}\n")
    
    # 统计E1差异是否常数
    n_E1_diff_constant = sum(1 for e in exceptions if e['E1_diff_constant'])
    n_E1_swap = sum(1 for e in exceptions if e['E1_swap'])
    
    print("===== E1结构统计 =====")
    print(f"E1差异为常数：{n_E1_diff_constant}/{len(exceptions)}")
    print(f"E1在扫描中发生交换：{n_E1_swap}/{len(exceptions)}")
    
    # 输出所有E1差异常数的例子
    print(f"\n===== E1差异常数的例外 =====")
    for e in exceptions:
        if e['E1_diff_constant']:
            print(f"\n图{e['graph']} 边{e['edge_i']}({e['edges_i']}) vs 边{e['edge_j']}({e['edges_j']})")
            print(f"  轨道: {e['orbit_i']} vs {e['orbit_j']}, 割点: {e['cut_vertices']}")
            print(f"  E1差异恒为: {e['E1_fixed_offset']:.6f}")
            print(f"  E1_i: {[round(v,4) for v in e['E1s_i']]}")
            print(f"  E1_j: {[round(v,4) for v in e['E1s_j']]}")
            print(f"  前8能级差异: {e['low_evals_relation']}")
    
    # 对E1差异非常数的例子，检查E1差异的分布
    print(f"\n===== E1差异非常数的例外（前5个） =====")
    count = 0
    for e in exceptions:
        if not e['E1_diff_constant']:
            print(f"\n图{e['graph']} 边{e['edge_i']}({e['edges_i']}) vs 边{e['edge_j']}({e['edges_j']})")
            print(f"  E1差异: {[round(d,4) for d in e['E1_diffs']]}")
            print(f"  E1_swap: {e['E1_swap']}")
            count += 1
            if count >= 5:
                break
    
    # 特别关注图108
    print(f"\n===== 图108详细 =====")
    for e in exceptions:
        if e['graph'] == 108:
            print(f"\n边{e['edge_i']}({e['edges_i']}) vs 边{e['edge_j']}({e['edges_j']})")
            print(f"  E0_i: {[round(v,4) for v in [e['gaps_i'][k] for k in range(len(e['gaps_i']))]]}")
            print(f"  前8能级_i: {[round(v,6) for v in e['low_evals_i']]}")
            print(f"  前8能级_j: {[round(v,6) for v in e['low_evals_j']]}")
    
    output = {
        'n_exceptions': len(exceptions),
        'n_E1_diff_constant': n_E1_diff_constant,
        'n_E1_swap': n_E1_swap,
        'exceptions': exceptions,
        'note': '能隙例外的统一结构分析。'
    }
    with open('jingmai_why_gap_exception_unified.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_gap_exception_unified.json")

if __name__ == "__main__":
    main()