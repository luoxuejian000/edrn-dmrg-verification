"""
追问为什么_37对异轨道同分布深挖.py

目标：
    继续追问：37对异轨道但排序分布完全相同的边对，为什么？
    对每对边，检查：
        1. 标准物理量：端点度对、环长、边介数
        2. 拓扑特征：删除边后图是否同构、删除后节点度序列
        3. 轨道编号
    并排呈现标准物理视角与晶脉视角。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。

理论精髓：
    - 数据自己说话。
    - 追问：不同轨道却同分布，背后是什么结构原因？

输出：
    jingmai_why_37_diff_orbit_same_dist.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10

def build_hamiltonian_and_basis(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def compute_probs_with_degen(N, edges, J_vals):
    H, basis = build_hamiltonian_and_basis(N, edges, J_vals)
    evals, evecs = np.linalg.eigh(H)
    E0 = evals[0]
    degen_indices = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
    degen_dim = len(degen_indices)
    probs = np.zeros(len(basis))
    for idx in degen_indices:
        probs += np.abs(evecs[:, idx])**2
    probs /= degen_dim
    return probs, basis

def compute_corrs_from_probs(N, edges, basis, probs):
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return np.array(corrs)

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def get_edge_orbits_from_edges(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    automorphisms = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in automorphisms:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return orbits, edge_to_orbit

def get_edge_features(edges, N):
    """返回每条边的标准物理特征"""
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    edge_bc = nx.edge_betweenness_centrality(G)
    features = []
    for e in edges:
        u, v = e
        deg_pair = sorted([G.degree(u), G.degree(v)])
        cycles = []
        for cycle in nx.cycle_basis(G):
            edge_in_cycle = False
            for i in range(len(cycle)):
                a, b = cycle[i], cycle[(i+1)%len(cycle)]
                if (a == u and b == v) or (a == v and b == u):
                    edge_in_cycle = True
                    break
            if edge_in_cycle:
                cycles.append(len(cycle))
        cycles = sorted(cycles)
        bc = edge_bc.get(e, edge_bc.get((v,u), 0.0))
        features.append({
            'deg_pair': deg_pair,
            'cycles': cycles,
            'betweenness': float(bc)
        })
    return features

def main():
    print("=== 追问为什么_37对异轨道同分布深挖 ===\n")
    
    all_graphs = get_all_N6_graphs()
    s_values = np.linspace(-1.5, 0.0, 21)
    
    # 找出所有异轨道同排序分布的边对
    targets = []
    for g_idx, edges in enumerate(all_graphs):
        n_edges = len(edges)
        orbits, edge_to_orbit = get_edge_orbits_from_edges(edges, N)
        features = get_edge_features(edges, N)
        
        # 扫描所有边，计算排序分布
        sorted_curves = []
        for i in range(n_edges):
            sorted_curve = []
            for s in s_values:
                J = np.ones(n_edges); J[i] = s
                probs, basis = compute_probs_with_degen(N, edges, J)
                corrs = compute_corrs_from_probs(N, edges, basis, probs)
                sorted_curve.append(np.sort(corrs))
            sorted_curves.append(sorted_curve)
        
        # 比较异轨道边对
        for i in range(n_edges):
            for j in range(i+1, n_edges):
                if edge_to_orbit[i] == edge_to_orbit[j]:
                    continue
                # 检查所有Δ点排序分布是否相同
                all_same = True
                for si in range(len(s_values)):
                    if not np.allclose(sorted_curves[i][si], sorted_curves[j][si], atol=TOL_CURVE):
                        all_same = False
                        break
                if all_same:
                    # 检查删除边后图是否同构
                    G_i = nx.Graph()
                    G_i.add_nodes_from(range(N))
                    G_i.add_edges_from([e for idx,e in enumerate(edges) if idx != i])
                    G_j = nx.Graph()
                    G_j.add_nodes_from(range(N))
                    G_j.add_edges_from([e for idx,e in enumerate(edges) if idx != j])
                    del_iso = nx.is_isomorphic(G_i, G_j)
                    
                    targets.append({
                        'graph': g_idx,
                        'edge_i': i,
                        'edge_j': j,
                        'orbit_i': edge_to_orbit[i],
                        'orbit_j': edge_to_orbit[j],
                        'feat_i': features[i],
                        'feat_j': features[j],
                        'del_iso': del_iso,
                        'edges': edges
                    })
    
    print(f"异轨道同排序分布边对数：{len(targets)}")
    
    # 统计特征
    n_deg_pair_same = sum(1 for t in targets if t['feat_i']['deg_pair'] == t['feat_j']['deg_pair'])
    n_cycles_same = sum(1 for t in targets if t['feat_i']['cycles'] == t['feat_j']['cycles'])
    n_del_iso = sum(1 for t in targets if t['del_iso'])
    
    print(f"\n===== 特征统计 =====")
    print(f"端点度对相同：{n_deg_pair_same}/{len(targets)}")
    print(f"环长集合相同：{n_cycles_same}/{len(targets)}")
    print(f"删除边后图同构：{n_del_iso}/{len(targets)}")
    
    # 输出前10个
    print("\n===== 前10个边对详情 =====")
    for t in targets[:10]:
        print(f"\n图{t['graph']} 边{t['edge_i']}(轨道{t['orbit_i']}) vs 边{t['edge_j']}(轨道{t['orbit_j']})")
        print(f"  度对: {t['feat_i']['deg_pair']} vs {t['feat_j']['deg_pair']}")
        print(f"  环长: {t['feat_i']['cycles']} vs {t['feat_j']['cycles']}")
        print(f"  介数: {t['feat_i']['betweenness']:.4f} vs {t['feat_j']['betweenness']:.4f}")
        print(f"  删除边后图同构: {t['del_iso']}")
        print(f"  边列表: {t['edges']}")
    
    # 输出所有删除边后同构的边对
    del_iso_targets = [t for t in targets if t['del_iso']]
    print(f"\n===== 删除边后同构的边对数：{len(del_iso_targets)} =====")
    for t in del_iso_targets[:10]:
        print(f"  图{t['graph']} 边{t['edge_i']} vs 边{t['edge_j']}")
    
    output = {
        'targets': targets,
        'n_targets': len(targets),
        'n_deg_pair_same': n_deg_pair_same,
        'n_cycles_same': n_cycles_same,
        'n_del_iso': n_del_iso,
        'note': '追问：37对异轨道同排序分布边对的结构特征。'
    }
    with open('jingmai_why_37_diff_orbit_same_dist.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_37_diff_orbit_same_dist.json")

if __name__ == "__main__":
    main()