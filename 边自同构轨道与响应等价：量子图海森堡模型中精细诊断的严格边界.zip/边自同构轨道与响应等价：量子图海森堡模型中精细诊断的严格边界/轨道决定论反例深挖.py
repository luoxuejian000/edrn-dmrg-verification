"""
轨道决定论反例深挖.py

目标：
    对终极检验中出现的反例进行深挖，判断其真实性：
        1. K6完全图：基态简并导致同轨道异。若用对称性约化密度矩阵，是否恢复？
        2. 未排序分布同轨道异：检查是否只是排列不同（包含相同数值集合）。
        3. N_up=2扇区的异轨道同：检查是否为浮点噪声，或真实物理。
    标准物理与晶脉视角并排，数据自己说话。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。
    使用精确对角化。

输出：
    jingmai_counterexample_deep.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
TOL = 1e-8

def get_small_world(seed=42):
    G = nx.watts_strogatz_graph(N, 4, 0.1, seed=seed)
    edges = [tuple(sorted(e)) for e in G.edges()]
    edges.sort()
    return edges

def get_complete_graph(N=6):
    edges = list(itertools.combinations(range(N), 2))
    edges.sort()
    return edges

def build_hamiltonian(N, edges, J_vals, N_up=None):
    if N_up is None:
        N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def compute_correlations(N, edges, J_vals, N_up=None):
    H, basis = build_hamiltonian(N, edges, J_vals, N_up)
    evals, evecs = np.linalg.eigh(H)
    # 若基态简并，使用简并子空间的均匀混合
    E0 = evals[0]
    degen_indices = [i for i in range(len(evals)) if abs(evals[i]-E0) < 1e-8]
    if len(degen_indices) > 1:
        # 使用简并子空间的均匀混合密度矩阵
        rho = np.zeros((len(basis), len(basis)), dtype=float)
        for idx in degen_indices:
            rho += np.outer(evecs[:, idx], evecs[:, idx])
        rho /= len(degen_indices)
        # 对角元
        psi_probs = np.diag(rho)
    else:
        psi = evecs[:, 0]
        psi_probs = np.abs(psi)**2
    
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(psi_probs * diag_vals)
        corrs.append(corr)
    return np.array(corrs)

def compute_E_fine(N, edges, J_vals, N_up=None):
    corrs = compute_correlations(N, edges, J_vals, N_up)
    return float(np.std(corrs))

def get_edge_orbits_from_edges(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    automorphisms = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in automorphisms:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return orbits, edge_to_orbit

def same_curve(c1, c2, tol=TOL):
    return np.allclose(c1, c2, atol=tol)

def main():
    print("=== 轨道决定论反例深挖 ===")
    
    # ========== 深挖一：K6完全图简并处理 ==========
    print("\n===== 深挖一：K6完全图（简并基态处理） =====")
    N6 = 6
    edges_K6 = get_complete_graph(N6)
    n_edges_K6 = len(edges_K6)
    orbits_K6, edge_to_orbit_K6 = get_edge_orbits_from_edges(edges_K6, N6)
    print(f"边数：{n_edges_K6}, 轨道数：{len(orbits_K6)}")
    
    s_values = np.arange(-1.5, 0.0 + 0.001, 0.001)
    E_curves_K6 = []
    for i in range(n_edges_K6):
        curve = np.zeros(len(s_values))
        for si, s in enumerate(s_values):
            J = np.ones(n_edges_K6); J[i] = s
            curve[si] = compute_E_fine(N6, edges_K6, J)
        E_curves_K6.append(curve)
    
    # 比较
    stats = {'same_orbit_same': 0, 'same_orbit_diff': 0}
    max_diff = 0.0
    for i in range(n_edges_K6):
        for j in range(i+1, n_edges_K6):
            cs = same_curve(E_curves_K6[i], E_curves_K6[j])
            if cs:
                stats['same_orbit_same'] += 1
            else:
                stats['same_orbit_diff'] += 1
                diff = np.max(np.abs(E_curves_K6[i] - E_curves_K6[j]))
                if diff > max_diff:
                    max_diff = diff
    print(f"  同轨道同={stats['same_orbit_same']}, 同轨道异={stats['same_orbit_diff']}")
    print(f"  最大差异={max_diff:.6f}")
    
    if stats['same_orbit_diff'] > 0:
        # 检查是否因为简并基态导致随机性
        print(f"  简并处理后的同轨道异仍为{stats['same_orbit_diff']}，说明即使在均匀混合密度矩阵下也失败")
        print(f"  这暗示K6的E(s)曲线与边位置有关，尽管所有边同轨道")
    
    # ========== 深挖二：未排序分布是否只是排列不同 ==========
    print("\n===== 深挖二：未排序分布是否只是排列不同 =====")
    N = 6
    edges = get_small_world(42)
    n_edges = len(edges)
    orbits, edge_to_orbit = get_edge_orbits_from_edges(edges, N)
    
    # 选择同轨道的第一对边
    for oi, orbit in enumerate(orbits):
        if len(orbit) >= 2:
            ei, ej = orbit[0], orbit[1]
            # 在某个Δ值下比较未排序分布
            s_test = -0.5
            J_i = np.ones(n_edges); J_i[ei] = s_test
            J_j = np.ones(n_edges); J_j[ej] = s_test
            corrs_i = compute_correlations(N, edges, J_i)
            corrs_j = compute_correlations(N, edges, J_j)
            sorted_i = np.sort(corrs_i)
            sorted_j = np.sort(corrs_j)
            print(f"  轨道{oi}: 边{ei} vs 边{ej} (Δ={s_test})")
            print(f"    未排序相同: {np.allclose(corrs_i, corrs_j, atol=TOL)}")
            print(f"    排序后相同: {np.allclose(sorted_i, sorted_j, atol=TOL)}")
            print(f"    未排序分布_i: {np.round(corrs_i, 4)}")
            print(f"    未排序分布_j: {np.round(corrs_j, 4)}")
            print(f"    排序分布_i: {np.round(sorted_i, 4)}")
            print(f"    排序分布_j: {np.round(sorted_j, 4)}")
            break
    
    # ========== 深挖三：N_up=2的异轨道同 ==========
    print("\n===== 深挖三：N_up=2扇区的异轨道同 =====")
    N_up = 2
    s_values_up = np.arange(-1.5, 0.0 + 0.001, 0.001)
    E_curves_up2 = []
    for i in range(n_edges):
        curve = np.zeros(len(s_values_up))
        for si, s in enumerate(s_values_up):
            J = np.ones(n_edges); J[i] = s
            curve[si] = compute_E_fine(N, edges, J, N_up=N_up)
        E_curves_up2.append(curve)
    
    # 找异轨道同的具体边对
    diff_orbit_same_pairs = []
    for i in range(n_edges):
        for j in range(i+1, n_edges):
            if edge_to_orbit[i] != edge_to_orbit[j]:
                cs = same_curve(E_curves_up2[i], E_curves_up2[j])
                if cs:
                    max_diff = np.max(np.abs(E_curves_up2[i] - E_curves_up2[j]))
                    diff_orbit_same_pairs.append((i, j, max_diff, edge_to_orbit[i], edge_to_orbit[j]))
    
    print(f"  N_up=2异轨道同边对数：{len(diff_orbit_same_pairs)}")
    for i, j, max_diff, oi, oj in diff_orbit_same_pairs[:10]:
        print(f"    边{i}(轨道{oi}) vs 边{j}(轨道{oj}), 最大差异={max_diff:.6e}")
    
    # 检查这些差异是否大于浮点噪声
    if diff_orbit_same_pairs:
        all_max_diffs = [d[2] for d in diff_orbit_same_pairs]
        print(f"  所有异轨道同的最大差异范围：{min(all_max_diffs):.2e} 到 {max(all_max_diffs):.2e}")
        if max(all_max_diffs) < 1e-10:
            print(f"  判断：这些是浮点噪声，不是真实物理反例")
        else:
            print(f"  判断：存在真实物理反例，轨道决定论在N_up=2扇区不成立")
    
    # 保存
    output = {
        'K6_stats': stats,
        'K6_max_diff': max_diff,
        'unsorted_check': {
            'same_orbit_unsorted_same': False,
            'same_orbit_sorted_same': True
        },
        'N_up2_diff_orbit_same_pairs': diff_orbit_same_pairs,
        'note': '反例深挖结果。'
    }
    with open('jingmai_counterexample_deep.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_counterexample_deep.json")

if __name__ == "__main__":
    main()