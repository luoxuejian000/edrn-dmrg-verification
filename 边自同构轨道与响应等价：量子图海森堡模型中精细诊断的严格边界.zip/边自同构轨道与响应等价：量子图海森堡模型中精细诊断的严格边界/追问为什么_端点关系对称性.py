"""
追问为什么_端点关系对称性.py

目标：
    对“分支内边 vs 割点连接边”的每一对组合，
    计算两个端点在图中的关系位置是否对称。
    具体：内边(u,v)和连接边(c,u)，u是公共端点。
    检查c和v相对于u的关系特征是否相同：
        1. c和v在u的邻居列表中的位置
        2. c和v与其他节点共享邻居的数量
        3. 把u去掉后，c和v是否在同一个连通分量
        4. c和v到u的距离以外的路径数
        5. 是否存在一个局部置换把c映射到v同时保持u不变
    统计等价对和非等价对在这个特征上的差异。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。

输出：
    jingmai_why_endpoint_symmetry.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
S_POINTS = 11
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10

def build_heisenberg(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def compute_corrs(N, edges, basis, probs):
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return np.array(corrs)

def get_sorted_curves(N, edges, s_values):
    n_edges = len(edges)
    curves = []
    for i in range(n_edges):
        curve = []
        for s in s_values:
            J = np.ones(n_edges); J[i] = s
            H, basis = build_heisenberg(N, edges, J)
            evals, evecs = np.linalg.eigh(H)
            E0 = evals[0]
            degen = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
            probs = np.zeros(len(basis))
            for idx in degen:
                probs += np.abs(evecs[:, idx])**2
            probs /= len(degen)
            corrs = compute_corrs(N, edges, basis, probs)
            curve.append(np.sort(corrs))
        curves.append(curve)
    return curves

def curves_equal(c1, c2):
    return all(np.allclose(a, b, atol=TOL_CURVE) for a, b in zip(c1, c2))

def endpoint_symmetry_features(G, u, c, v):
    """计算c和v相对于u的对称性特征"""
    nbrs_u = set(G.neighbors(u))
    
    # 特征1：c和v是否都在u的邻居中
    c_in_nbr = c in nbrs_u
    v_in_nbr = v in nbrs_u
    
    # 特征2：c和v的度
    deg_c = G.degree(c)
    deg_v = G.degree(v)
    
    # 特征3：c和v与其他u邻居共享邻居的数量
    nbrs_c = set(G.neighbors(c)) - {u}
    nbrs_v = set(G.neighbors(v)) - {u}
    
    # 去掉u后，c和v的邻居中与u的其他邻居重叠
    other_nbrs_u = nbrs_u - {c, v}
    
    # c和v与other_nbrs_u的连接数
    c_conn_other = len(nbrs_c & other_nbrs_u)
    v_conn_other = len(nbrs_v & other_nbrs_u)
    
    # 特征4：删除u后，c和v是否连通
    G_removed = G.copy()
    G_removed.remove_node(u)
    if c in G_removed and v in G_removed:
        try:
            same_comp = nx.has_path(G_removed, c, v)
        except:
            same_comp = False
    else:
        same_comp = False
    
    # 特征5：c和v在删除u后的连通分量大小
    comp_size_c = 0
    comp_size_v = 0
    if c in G_removed:
        comp_size_c = len(nx.node_connected_component(G_removed, c))
    if v in G_removed:
        comp_size_v = len(nx.node_connected_component(G_removed, v))
    
    # 特征6：是否存在局部置换把c映射到v同时保持u不变
    # 简化检查：c和v是否具有相同的“邻居度分布”（不含u）
    c_nbr_deg = tuple(sorted([G.degree(x) for x in nbrs_c]))
    v_nbr_deg = tuple(sorted([G.degree(x) for x in nbrs_v]))
    same_nbr_deg = c_nbr_deg == v_nbr_deg
    
    # 特征7：c和v到u以外的共同邻居数
    common_nbr = len(nbrs_c & nbrs_v)
    
    return {
        'c_in_nbr': c_in_nbr,
        'v_in_nbr': v_in_nbr,
        'deg_c': deg_c,
        'deg_v': deg_v,
        'deg_same': deg_c == deg_v,
        'c_conn_other': c_conn_other,
        'v_conn_other': v_conn_other,
        'conn_other_same': c_conn_other == v_conn_other,
        'same_comp_after_removing_u': same_comp,
        'comp_size_c': comp_size_c,
        'comp_size_v': comp_size_v,
        'comp_size_same': comp_size_c == comp_size_v,
        'c_nbr_deg': c_nbr_deg,
        'v_nbr_deg': v_nbr_deg,
        'same_nbr_deg': same_nbr_deg,
        'common_nbr': common_nbr,
    }

def main():
    print("=== 追问为什么_端点关系对称性 ===\n")
    
    all_graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            all_graphs.append(edges)
    
    problem_with_cut = [9, 26, 31, 33, 49, 55, 60, 64, 69]
    s_values = np.linspace(-1.5, 0.0, S_POINTS)
    
    equivalent_results = []
    non_equivalent_results = []
    
    for g_idx in problem_with_cut:
        edges = all_graphs[g_idx]
        G = nx.Graph()
        G.add_nodes_from(range(N))
        G.add_edges_from(edges)
        cut_vertices = list(nx.articulation_points(G))
        curves = get_sorted_curves(N, edges, s_values)
        
        print(f"\n===== 图{g_idx}: 割点={cut_vertices} =====")
        
        for cv in cut_vertices:
            G_removed = G.copy()
            G_removed.remove_node(cv)
            components = list(nx.connected_components(G_removed))
            
            for ci, comp in enumerate(components):
                inner_edges = []
                for ei, (u, v) in enumerate(edges):
                    if u in comp and v in comp:
                        inner_edges.append(ei)
                connect_edges = []
                for ei, (u, v) in enumerate(edges):
                    if (u == cv and v in comp) or (v == cv and u in comp):
                        connect_edges.append(ei)
                
                if not inner_edges or not connect_edges:
                    continue
                
                for ie in inner_edges:
                    for ce in connect_edges:
                        # 找公共端点u
                        u_ie, v_ie = edges[ie]
                        u_ce, v_ce = edges[ce]
                        # 公共端点是连接边的分支侧端点
                        if u_ce == cv:
                            u_common = v_ce
                            c_end = cv
                            other_ie = v_ie if u_ie == u_common else u_ie
                        else:
                            u_common = u_ce
                            c_end = cv
                            other_ie = v_ie if u_ie == u_common else u_ie
                        
                        same = curves_equal(curves[ie], curves[ce])
                        feats = endpoint_symmetry_features(G, u_common, c_end, other_ie)
                        
                        record = {
                            'graph': g_idx,
                            'cut_vertex': cv,
                            'branch': ci,
                            'inner_edge': ie,
                            'connect_edge': ce,
                            'inner_edge_nodes': edges[ie],
                            'connect_edge_nodes': edges[ce],
                            'common_endpoint': u_common,
                            'cut_endpoint': c_end,
                            'other_inner_endpoint': other_ie,
                            'same': same,
                            'features': feats
                        }
                        
                        if same:
                            equivalent_results.append(record)
                        else:
                            non_equivalent_results.append(record)
    
    # 统计特征匹配率
    print(f"\n===== 统计 =====")
    print(f"等价对：{len(equivalent_results)}")
    print(f"非等价对：{len(non_equivalent_results)}")
    
    feature_keys = ['deg_same', 'conn_other_same', 'same_comp_after_removing_u',
                    'comp_size_same', 'same_nbr_deg']
    
    print(f"\n各特征匹配率（等价 vs 非等价）：")
    print(f"{'特征':<35} {'等价':<10} {'非等价':<10}")
    print("-" * 55)
    for key in feature_keys:
        eq_true = sum(1 for r in equivalent_results if r['features'][key])
        neq_true = sum(1 for r in non_equivalent_results if r['features'][key])
        eq_ratio = eq_true / len(equivalent_results) if equivalent_results else 0
        neq_ratio = neq_true / len(non_equivalent_results) if non_equivalent_results else 0
        print(f"{key:<35} {eq_ratio:<10.4f} {neq_ratio:<10.4f}")
    
    # 寻找能完美区分等价和非等价的组合
    print(f"\n===== 特征组合区分能力 =====")
    perfect_combos = []
    for r in range(1, len(feature_keys) + 1):
        for combo in itertools.combinations(feature_keys, r):
            # 在等价对中：所有特征都满足
            eq_all = all(all(r['features'][k] for k in combo) for r in equivalent_results)
            # 在非等价对中：所有特征都不满足
            neq_none = all(not all(r['features'][k] for k in combo) for r in non_equivalent_results)
            if eq_all and neq_none:
                perfect_combos.append(combo)
    
    if perfect_combos:
        print(f"完美区分组合：{perfect_combos}")
    else:
        print("不存在完美区分组合。")
        # 找出最佳组合
        best_score = -1
        best_combo = None
        for r in range(1, len(feature_keys) + 1):
            for combo in itertools.combinations(feature_keys, r):
                eq_true = sum(1 for r in equivalent_results if all(r['features'][k] for k in combo))
                neq_false = sum(1 for r in non_equivalent_results if not all(r['features'][k] for k in combo))
                score = eq_true + neq_false
                if score > best_score:
                    best_score = score
                    best_combo = combo
        print(f"最佳组合：{best_combo}，得分：{best_score}/{len(equivalent_results)+len(non_equivalent_results)}")
    
    # 输出等价对的详细特征
    print(f"\n===== 等价对详细特征 =====")
    for r in equivalent_results[:10]:
        print(f"\n图{r['graph']} 割点{r['cut_vertex']}: 内边{r['inner_edge']}({r['inner_edge_nodes']}) "
              f"vs 连接边{r['connect_edge']}({r['connect_edge_nodes']})")
        print(f"  公共端点={r['common_endpoint']}, 割点端={r['cut_endpoint']}, 内边另一端={r['other_inner_endpoint']}")
        print(f"  度: c={r['features']['deg_c']}, v={r['features']['deg_v']}, 同={r['features']['deg_same']}")
        print(f"  连接其他邻居: c={r['features']['c_conn_other']}, v={r['features']['v_conn_other']}, "
              f"同={r['features']['conn_other_same']}")
        print(f"  删除u后同分量: {r['features']['same_comp_after_removing_u']}")
        print(f"  分量大小: c={r['features']['comp_size_c']}, v={r['features']['comp_size_v']}, "
              f"同={r['features']['comp_size_same']}")
    
    output = {
        'equivalent_results': equivalent_results,
        'non_equivalent_results': non_equivalent_results,
        'perfect_combos': [list(c) for c in perfect_combos],
        'note': '追问端点关系对称性。'
    }
    with open('jingmai_why_endpoint_symmetry.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_endpoint_symmetry.json")

if __name__ == "__main__":
    main()