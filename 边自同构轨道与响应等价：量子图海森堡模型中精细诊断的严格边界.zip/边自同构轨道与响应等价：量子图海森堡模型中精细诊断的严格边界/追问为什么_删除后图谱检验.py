"""
追问为什么_删除后图谱检验.py

目标：
    局部对称性失败。追问等价性的全局谱根源。
    对每个内边-连接边组合，计算删除该边后图的拉普拉斯谱。
    检验：
        1. 等价对中，删除后图拉普拉斯谱是否相同？
        2. 非等价对中，删除后图拉普拉斯谱是否相同？
        3. 是否存在一个谱特征能完美区分等价与非等价？
    如果等价性与删除后图谱相同高度一致，则响应等价性
    由删除后图的谱结构决定，与边的局部环境无关。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。
    基态简并使用对称性约化密度矩阵。

输出：
    jingmai_why_deletion_spectrum.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
S_POINTS = 11
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10
TOL_SPECTRAL = 1e-8

def build_heisenberg(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def compute_corrs(N, edges, basis, probs):
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return np.array(corrs)

def get_sorted_curves(N, edges, s_values):
    n_edges = len(edges)
    curves = []
    for i in range(n_edges):
        curve = []
        for s in s_values:
            J = np.ones(n_edges); J[i] = s
            H, basis = build_heisenberg(N, edges, J)
            evals, evecs = np.linalg.eigh(H)
            E0 = evals[0]
            degen = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
            probs = np.zeros(len(basis))
            for idx in degen:
                probs += np.abs(evecs[:, idx])**2
            probs /= len(degen)
            corrs = compute_corrs(N, edges, basis, probs)
            curve.append(np.sort(corrs))
        curves.append(curve)
    return curves

def curves_equal(c1, c2):
    return all(np.allclose(a, b, atol=TOL_CURVE) for a, b in zip(c1, c2))

def deletion_spectrum(edges, N, edge_idx):
    """计算删除边后图的拉普拉斯谱和邻接谱"""
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    G_del = G.copy()
    G_del.remove_edge(*edges[edge_idx])
    L = nx.laplacian_matrix(G_del).toarray()
    lap_evals = np.sort(np.linalg.eigvalsh(L))
    A = nx.adjacency_matrix(G_del).toarray()
    adj_evals = np.sort(np.linalg.eigvalsh(A))
    return lap_evals, adj_evals

def main():
    print("=== 追问为什么_删除后图谱检验 ===\n")
    
    all_graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            all_graphs.append(edges)
    
    problem_with_cut = [9, 26, 31, 33, 49, 55, 60, 64, 69]
    s_values = np.linspace(-1.5, 0.0, S_POINTS)
    
    all_results = []
    
    for g_idx in problem_with_cut:
        edges = all_graphs[g_idx]
        G = nx.Graph()
        G.add_nodes_from(range(N))
        G.add_edges_from(edges)
        cut_vertices = list(nx.articulation_points(G))
        curves = get_sorted_curves(N, edges, s_values)
        
        for cv in cut_vertices:
            G_removed = G.copy()
            G_removed.remove_node(cv)
            components = list(nx.connected_components(G_removed))
            
            for ci, comp in enumerate(components):
                inner_edges = []
                for ei, (u, v) in enumerate(edges):
                    if u in comp and v in comp:
                        inner_edges.append(ei)
                connect_edges = []
                for ei, (u, v) in enumerate(edges):
                    if (u == cv and v in comp) or (v == cv and u in comp):
                        connect_edges.append(ei)
                
                if not inner_edges or not connect_edges:
                    continue
                
                for ie in inner_edges:
                    for ce in connect_edges:
                        same = curves_equal(curves[ie], curves[ce])
                        lap_ie, adj_ie = deletion_spectrum(edges, N, ie)
                        lap_ce, adj_ce = deletion_spectrum(edges, N, ce)
                        
                        lap_same = np.allclose(lap_ie, lap_ce, atol=TOL_SPECTRAL)
                        adj_same = np.allclose(adj_ie, adj_ce, atol=TOL_SPECTRAL)
                        
                        all_results.append({
                            'graph': g_idx,
                            'cut_vertex': cv,
                            'branch': ci,
                            'inner_edge': ie,
                            'connect_edge': ce,
                            'inner_edge_nodes': edges[ie],
                            'connect_edge_nodes': edges[ce],
                            'same': same,
                            'lap_same': lap_same,
                            'adj_same': adj_same,
                            'lap_ie': lap_ie.tolist(),
                            'lap_ce': lap_ce.tolist(),
                            'adj_ie': adj_ie.tolist(),
                            'adj_ce': adj_ce.tolist()
                        })
    
    # 统计
    n_total = len(all_results)
    n_equiv = sum(1 for r in all_results if r['same'])
    n_non = n_total - n_equiv
    
    print(f"总检查数：{n_total}")
    print(f"等价：{n_equiv}")
    print(f"非等价：{n_non}\n")
    
    # 等价对中，谱是否相同
    equiv_lap_same = sum(1 for r in all_results if r['same'] and r['lap_same'])
    equiv_adj_same = sum(1 for r in all_results if r['same'] and r['adj_same'])
    non_lap_same = sum(1 for r in all_results if not r['same'] and r['lap_same'])
    non_adj_same = sum(1 for r in all_results if not r['same'] and r['adj_same'])
    
    print(f"===== 删除后图谱相同比例 =====")
    print(f"等价对中拉普拉斯谱相同：{equiv_lap_same}/{n_equiv} ({equiv_lap_same/n_equiv:.4f})")
    print(f"等价对中邻接谱相同：{equiv_adj_same}/{n_equiv} ({equiv_adj_same/n_equiv:.4f})")
    print(f"非等价对中拉普拉斯谱相同：{non_lap_same}/{n_non} ({non_lap_same/n_non:.4f})")
    print(f"非等价对中邻接谱相同：{non_adj_same}/{n_non} ({non_adj_same/n_non:.4f})")
    
    # 区分度
    lap_discrimination = (equiv_lap_same/n_equiv) - (non_lap_same/n_non) if n_equiv and n_non else 0
    adj_discrimination = (equiv_adj_same/n_equiv) - (non_adj_same/n_non) if n_equiv and n_non else 0
    print(f"\n拉普拉斯谱区分度：{lap_discrimination:.4f}")
    print(f"邻接谱区分度：{adj_discrimination:.4f}")
    
    # 检查是否完美
    if equiv_lap_same == n_equiv and non_lap_same == 0:
        print("\n拉普拉斯谱完美区分等价与非等价！")
    if equiv_adj_same == n_equiv and non_adj_same == 0:
        print("\n邻接谱完美区分等价与非等价！")
    
    # 找反例
    print(f"\n===== 反例 =====")
    print("等价但拉普拉斯谱不同：")
    for r in all_results:
        if r['same'] and not r['lap_same']:
            print(f"  图{r['graph']} 内边{r['inner_edge']}({r['inner_edge_nodes']}) vs "
                  f"连接边{r['connect_edge']}({r['connect_edge_nodes']})")
    print("\n非等价但拉普拉斯谱相同：")
    count = 0
    for r in all_results:
        if not r['same'] and r['lap_same']:
            print(f"  图{r['graph']} 内边{r['inner_edge']}({r['inner_edge_nodes']}) vs "
                  f"连接边{r['connect_edge']}({r['connect_edge_nodes']})")
            count += 1
            if count >= 10:
                break
    
    output = {
        'all_results': all_results,
        'n_total': n_total,
        'n_equiv': n_equiv,
        'n_non': n_non,
        'equiv_lap_same': equiv_lap_same,
        'equiv_adj_same': equiv_adj_same,
        'non_lap_same': non_lap_same,
        'non_adj_same': non_adj_same,
        'lap_discrimination': lap_discrimination,
        'adj_discrimination': adj_discrimination,
        'note': '删除后图谱检验。'
    }
    with open('jingmai_why_deletion_spectrum.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_deletion_spectrum.json")

if __name__ == "__main__":
    main()