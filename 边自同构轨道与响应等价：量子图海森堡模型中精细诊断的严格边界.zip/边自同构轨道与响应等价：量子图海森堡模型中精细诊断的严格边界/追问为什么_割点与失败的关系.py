"""
追问为什么_割点与失败的关系.py

目标：
    追问：有割点的图是否都与轨道失败或模型依赖相关？
    对N=6全部112个连通图：
        1. 计算每个图的割点数
        2. 标记每个图是否属于问题图（orbit_fail/model_dependent/double_fail）
        3. 对有割点的图，检查失败边对是否恰好连接割点两侧的不同分支
    统计：
        - 有割点的图中，问题图的比例
        - 无割点的图中，问题图的比例
        - 如果问题图全部有割点，则割点是必要条件
        - 失败边对与割点位置的关系

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。

输出：
    jingmai_why_cut_vertex.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def get_cut_vertices(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    return list(nx.articulation_points(G))

def main():
    print("=== 追问为什么_割点与失败的关系 ===\n")
    
    with open('jingmai_why_problem_graphs_common.json', 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    classifications = data['classifications']
    all_graphs = get_all_N6_graphs()
    
    print(f"总图数：{len(all_graphs)}")
    
    # 统计
    stats = {
        'has_cut': {'normal': 0, 'problem': 0},
        'no_cut': {'normal': 0, 'problem': 0},
    }
    
    cut_details = []
    
    for x in classifications:
        g_idx = x['graph']
        category = x['category']
        edges = all_graphs[g_idx]
        cut_vertices = get_cut_vertices(edges, N)
        n_cut = len(cut_vertices)
        
        is_problem = (category != 'normal')
        
        if n_cut > 0:
            stats['has_cut']['problem' if is_problem else 'normal'] += 1
        else:
            stats['no_cut']['problem' if is_problem else 'normal'] += 1
        
        cut_details.append({
            'graph': g_idx,
            'category': category,
            'n_cut_vertices': n_cut,
            'cut_vertices': cut_vertices,
            'n_edges': len(edges)
        })
    
    print("\n===== 割点与问题图的关系 =====")
    print(f"有割点的图：正常 {stats['has_cut']['normal']}, 问题 {stats['has_cut']['problem']}")
    print(f"无割点的图：正常 {stats['no_cut']['normal']}, 问题 {stats['no_cut']['problem']}")
    
    total_with_cut = stats['has_cut']['normal'] + stats['has_cut']['problem']
    total_no_cut = stats['no_cut']['normal'] + stats['no_cut']['problem']
    total_problem = stats['has_cut']['problem'] + stats['no_cut']['problem']
    
    if total_problem > 0:
        ratio_problem_with_cut = stats['has_cut']['problem'] / total_problem
        print(f"\n问题图中有割点的比例：{ratio_problem_with_cut:.4f}")
    if total_with_cut > 0:
        ratio_with_cut_problem = stats['has_cut']['problem'] / total_with_cut
        print(f"有割点的图中问题图的比例：{ratio_with_cut_problem:.4f}")
    if total_no_cut > 0:
        ratio_no_cut_problem = stats['no_cut']['problem'] / total_no_cut
        print(f"无割点的图中问题图的比例：{ratio_no_cut_problem:.4f}")
    
    # 检查是否所有问题图都有割点
    problem_with_cut = stats['has_cut']['problem']
    if problem_with_cut == total_problem:
        print("\n结论：所有问题图都有割点。割点是问题图的必要条件。")
    else:
        print(f"\n结论：{total_problem - problem_with_cut} 个问题图没有割点。割点不是必要条件。")
    
    # 输出所有有割点的图的详情
    print("\n===== 有割点的图详情 =====")
    for d in cut_details:
        if d['n_cut_vertices'] > 0:
            print(f"  图{d['graph']}: 分类={d['category']}, 割点数={d['n_cut_vertices']}, "
                  f"割点={d['cut_vertices']}, 边数={d['n_edges']}")
    
    # 输出所有问题图的详情
    print("\n===== 问题图详情 =====")
    for d in cut_details:
        if d['category'] != 'normal':
            print(f"  图{d['graph']}: 分类={d['category']}, 割点数={d['n_cut_vertices']}, "
                  f"割点={d['cut_vertices']}")
    
    output = {
        'stats': stats,
        'cut_details': cut_details,
        'note': '追问割点与问题图的关系。'
    }
    with open('jingmai_why_cut_vertex.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_cut_vertex.json")

if __name__ == "__main__":
    main()