"""
大预言_关系位置不变量存在性.py

目标：
    验证大预言的第一步：关系位置不变量存在。
    对N=6全部112个连通图，在多个模型下计算排序分布等价类，
    检验等价类是否在所有模型下完全相同。
    同时收集每条边的高维图论特征向量，
    对等价类内部和等价类之间的特征差异做初步统计，
    看是否存在一个可分离的特征子空间。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。
    基态简并使用对称性约化密度矩阵。

理论精髓：
    - 数据自己说话。
    - 追问：不变量的存在性是否由图结构保证？

输出：
    jingmai_big_prediction_invariant_existence.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
S_POINTS = 11
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10

def build_basis(N):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    return basis, state_to_idx

def add_heisenberg_term(H, basis, state_to_idx, edges, J_vals):
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J

def build_heisenberg(N, edges, J_vals):
    basis, state_to_idx = build_basis(N)
    H = np.zeros((len(basis), len(basis)), dtype=float)
    add_heisenberg_term(H, basis, state_to_idx, edges, J_vals)
    return H, basis

def build_xxz(N, edges, J_vals, delta_zz=1.5):
    basis, state_to_idx = build_basis(N)
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * delta_zz * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def build_nnn(N, edges, J_vals, strength=0.2):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    nnn_edges = []
    for i in range(N):
        for j in range(i+1, N):
            if not G.has_edge(i, j) and nx.has_path(G, i, j):
                if nx.shortest_path_length(G, i, j) == 2:
                    nnn_edges.append((i, j))
    nnn_edges.sort()
    basis, state_to_idx = build_basis(N)
    H = np.zeros((len(basis), len(basis)), dtype=float)
    add_heisenberg_term(H, basis, state_to_idx, edges, J_vals)
    nnn_J = [strength] * len(nnn_edges)
    add_heisenberg_term(H, basis, state_to_idx, nnn_edges, nnn_J)
    return H, basis

def compute_probs(N, edges, J_vals, model):
    if model == 'heisenberg':
        H, basis = build_heisenberg(N, edges, J_vals)
    elif model == 'xxz':
        H, basis = build_xxz(N, edges, J_vals)
    elif model == 'nnn_0.2':
        H, basis = build_nnn(N, edges, J_vals, 0.2)
    else:
        raise ValueError(model)
    evals, evecs = np.linalg.eigh(H)
    E0 = evals[0]
    degen = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
    probs = np.zeros(len(basis))
    for idx in degen:
        probs += np.abs(evecs[:, idx])**2
    probs /= len(degen)
    return probs, basis

def compute_corrs(N, edges, basis, probs):
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return np.array(corrs)

def get_sorted_curves(N, edges, model, s_values):
    n_edges = len(edges)
    curves = []
    for i in range(n_edges):
        curve = []
        for s in s_values:
            J = np.ones(n_edges)
            J[i] = s
            probs, basis = compute_probs(N, edges, J, model)
            corrs = compute_corrs(N, edges, basis, probs)
            curve.append(np.sort(corrs))
        curves.append(curve)
    return curves

def build_equiv(sorted_curves, n_edges):
    equiv = np.zeros((n_edges, n_edges), dtype=bool)
    for i in range(n_edges):
        for j in range(i+1, n_edges):
            same = all(np.allclose(c1, c2, atol=TOL_CURVE) 
                       for c1, c2 in zip(sorted_curves[i], sorted_curves[j]))
            equiv[i, j] = equiv[j, i] = same
    for i in range(n_edges):
        equiv[i, i] = True
    return equiv

def edge_feature_vector(edges, N, idx):
    """收集边的所有可用图论特征，构成高维向量"""
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    u, v = edges[idx]
    feats = []
    # 端点度
    feats.extend(sorted([G.degree(u), G.degree(v)]))
    # 度之和
    feats.append(G.degree(u) + G.degree(v))
    # 邻居度分布
    nbr_u = sorted([G.degree(x) for x in G.neighbors(u)])
    nbr_v = sorted([G.degree(x) for x in G.neighbors(v)])
    feats.extend(nbr_u[:4] + [0]*(4-len(nbr_u)))
    feats.extend(nbr_v[:4] + [0]*(4-len(nbr_v)))
    # 是否桥
    G_del = G.copy()
    G_del.remove_edge(u, v)
    feats.append(1.0 if nx.is_connected(G_del) else 0.0)
    # 删除后图的连通分量数
    feats.append(nx.number_connected_components(G_del))
    # 删除后图的度序列前4
    deg_seq = sorted([d for _, d in G_del.degree()])
    feats.extend(deg_seq[:4] + [0]*(4-len(deg_seq)))
    # 边介数
    bc = nx.edge_betweenness_centrality(G)
    feats.append(bc.get((u, v), bc.get((v, u), 0.0)))
    # 边参与环长
    cycles = []
    for cycle in nx.cycle_basis(G):
        for i in range(len(cycle)):
            a, b = cycle[i], cycle[(i+1)%len(cycle)]
            if (a == u and b == v) or (a == v and b == u):
                cycles.append(len(cycle))
    feats.append(len(cycles))
    feats.append(sum(cycles) if cycles else 0)
    return np.array(feats, dtype=float)

def main():
    print("=== 大预言_关系位置不变量存在性 ===\n")
    
    all_graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            all_graphs.append(edges)
    
    s_values = np.linspace(-1.5, 0.0, S_POINTS)
    models = ['heisenberg', 'xxz', 'nnn_0.2']
    
    print(f"总图数：{len(all_graphs)}")
    print(f"模型：{models}")
    print(f"扫描点数：{S_POINTS}\n")
    
    # 对所有图检验模型无关性
    total_model_independent = 0
    total_graphs = 0
    all_equiv_data = []
    
    for g_idx, edges in enumerate(all_graphs):
        n_edges = len(edges)
        equiv_matrices = {}
        for model in models:
            sorted_curves = get_sorted_curves(N, edges, model, s_values)
            equiv_matrices[model] = build_equiv(sorted_curves, n_edges)
        
        # 检查所有模型是否给出相同的等价矩阵
        base = models[0]
        all_same = all(np.array_equal(equiv_matrices[base], equiv_matrices[m]) 
                       for m in models[1:])
        
        total_graphs += 1
        if all_same:
            total_model_independent += 1
        else:
            print(f"图{g_idx} 模型无关性失败:")
            for m in models[1:]:
                n_diff = int(np.sum(equiv_matrices[base] != equiv_matrices[m]))
                print(f"  {base} vs {m}: 差异矩阵元={n_diff}")
        
        # 收集特征向量
        feature_vectors = [edge_feature_vector(edges, N, i) for i in range(n_edges)]
        all_equiv_data.append({
            'graph': g_idx,
            'equiv_matrix': equiv_matrices[base].tolist(),
            'feature_vectors': [fv.tolist() for fv in feature_vectors]
        })
        
        if (g_idx+1) % 30 == 0:
            print(f"  进度：{g_idx+1}/{len(all_graphs)}")
    
    print(f"\n===== 模型无关性统计 =====")
    print(f"模型无关的图数：{total_model_independent}/{total_graphs}")
    if total_model_independent == total_graphs:
        print("所有图在所有模型下给出相同的排序分布等价类。")
        print("结论：关系位置不变量存在，且由图结构决定。")
    else:
        print(f"存在 {total_graphs - total_model_independent} 个图在不同模型下给出不同等价类。")
        print("结论：关系位置不变量不是纯图论量，需要进一步追问。")
    
    output = {
        'total_graphs': total_graphs,
        'total_model_independent': total_model_independent,
        'models': models,
        'all_equiv_data': all_equiv_data,
        'note': '大预言第一步：关系位置不变量的存在性检验。'
    }
    with open('jingmai_big_prediction_invariant_existence.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_big_prediction_invariant_existence.json")

if __name__ == "__main__":
    main()