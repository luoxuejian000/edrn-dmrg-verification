"""
反例真实性判别.py

目标：
    对N=6穷举中26个反例图，重新精确计算同轨道异曲线或异轨道同曲线
    的最大差异，判断是真实物理反例还是浮点噪声。
    如果最大差异在10^-12以下，判定为数值噪声；
    否则为真实反例。

方法：
    只查同与不同，不拟合，不预设。
    使用float64精确对角化。
    输出每个反例图的反例边对、最大差异、差异量级。

理论精髓：
    - 数据自己说话，反例必须如实报告。
    - 如果反例都是噪声，轨道决定论仍然成立；
      如果存在真实差异，则轨道决定论存在真实边界。

输出：
    jingmai_counterexample_authenticity.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
TOL_STRICT = 1e-12  # 严格容差，大于此值视为真实差异

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def build_hamiltonian(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def compute_E_fine(N, edges, J_vals):
    H, basis = build_hamiltonian(N, edges, J_vals)
    evals, evecs = np.linalg.eigh(H)
    psi = evecs[:, 0]
    probs = np.abs(psi)**2
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return float(np.std(corrs))

def get_edge_orbits_from_edges(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    automorphisms = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in automorphisms:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return orbits, edge_to_orbit

def main():
    print("=== 反例真实性判别 ===\n")
    
    all_graphs = get_all_N6_graphs()
    print(f"总图数：{len(all_graphs)}")
    
    ce_info = []
    total_ce = 0
    noise_ce = 0
    real_ce = 0
    
    for g_idx, edges in enumerate(all_graphs):
        n_edges = len(edges)
        orbits, edge_to_orbit = get_edge_orbits_from_edges(edges, N)
        s_values = np.linspace(-1.5, 0.0, 51)  # 更密的扫描
        E_curves = []
        for i in range(n_edges):
            curve = np.zeros(len(s_values))
            for si, s in enumerate(s_values):
                J = np.ones(n_edges); J[i] = s
                curve[si] = compute_E_fine(N, edges, J)
            E_curves.append(curve)
        
        # 检查所有边对
        for i in range(n_edges):
            for j in range(i+1, n_edges):
                cs = np.allclose(E_curves[i], E_curves[j], atol=1e-8)
                os_ = edge_to_orbit[i] == edge_to_orbit[j]
                if (os_ and not cs) or (not os_ and cs):
                    # 计算最大差异
                    max_diff = float(np.max(np.abs(E_curves[i] - E_curves[j])))
                    ce_info.append({
                        'graph': g_idx,
                        'type': 'same_orbit_diff' if os_ else 'diff_orbit_same',
                        'edge_i': i,
                        'edge_j': j,
                        'orbit_i': edge_to_orbit[i],
                        'orbit_j': edge_to_orbit[j],
                        'max_diff': max_diff,
                        'is_noise': max_diff < TOL_STRICT
                    })
                    total_ce += 1
                    if max_diff < TOL_STRICT:
                        noise_ce += 1
                    else:
                        real_ce += 1
    
    print(f"总反例边对数：{total_ce}")
    print(f"噪声级反例（<{TOL_STRICT}）：{noise_ce}")
    print(f"真实反例（>{TOL_STRICT}）：{real_ce}")
    
    if real_ce > 0:
        print("\n真实反例详情：")
        real_items = [ce for ce in ce_info if not ce['is_noise']]
        for ce in real_items[:20]:
            print(f"  图{ce['graph']} 边{ce['edge_i']}(轨道{ce['orbit_i']}) vs 边{ce['edge_j']}(轨道{ce['orbit_j']}), "
                  f"类型={ce['type']}, 最大差异={ce['max_diff']:.6e}")
    else:
        print("\n所有反例均为数值噪声，轨道决定论在N=6穷举中零真实反例。")
    
    # 保存
    output = {
        'total_ce': total_ce,
        'noise_ce': noise_ce,
        'real_ce': real_ce,
        'real_counterexamples': [ce for ce in ce_info if not ce['is_noise']],
        'noise_counterexamples': [ce for ce in ce_info if ce['is_noise']],
        'TOL_STRICT': TOL_STRICT,
        'note': '反例真实性判别。若real_ce=0，则轨道决定论在所有N=6连通图中成立。'
    }
    with open('jingmai_counterexample_authenticity.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_counterexample_authenticity.json")

if __name__ == "__main__":
    main()