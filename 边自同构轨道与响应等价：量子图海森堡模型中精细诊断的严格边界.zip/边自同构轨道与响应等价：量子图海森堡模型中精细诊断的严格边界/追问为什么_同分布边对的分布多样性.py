"""
追问为什么_同分布边对的分布多样性.py

目标：
    继续追问：32对异轨道但排序分布相同的边对，其排序分布是否具有低多样性？
    对每对边，在Δ=-0.5处，计算排序关联分布，并统计其中不同值的个数。
    如果不同值个数很少（如只有2或3个值），则排序分布高度退化，
    这可能解释了为什么异轨道边对会偶然给出相同排序分布。
    并排呈现标准物理特征与晶脉视角。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。
    基态简并使用对称性约化密度矩阵。

理论精髓：
    - 数据自己说话。
    - 追问：排序分布相同是否源于分布退化？

输出：
    jingmai_why_distribution_diversity.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10
DELTA = -0.5

def build_hamiltonian_and_basis(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def compute_probs_with_degen(N, edges, J_vals):
    H, basis = build_hamiltonian_and_basis(N, edges, J_vals)
    evals, evecs = np.linalg.eigh(H)
    E0 = evals[0]
    degen_indices = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
    degen_dim = len(degen_indices)
    probs = np.zeros(len(basis))
    for idx in degen_indices:
        probs += np.abs(evecs[:, idx])**2
    probs /= degen_dim
    return probs, basis

def compute_corrs_from_probs(N, edges, basis, probs):
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return np.array(corrs)

def count_distinct(values, tol=1e-6):
    """统计不同值的个数"""
    sorted_vals = np.sort(values)
    distinct = []
    current = None
    for v in sorted_vals:
        if current is None or abs(v - current) > tol:
            distinct.append(v)
            current = v
    return len(distinct), distinct

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def get_edge_orbits_from_edges(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    automorphisms = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in automorphisms:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return orbits, edge_to_orbit

def get_edge_features(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    edge_bc = nx.edge_betweenness_centrality(G)
    features = []
    for e in edges:
        u, v = e
        deg_pair = sorted([G.degree(u), G.degree(v)])
        cycles = []
        for cycle in nx.cycle_basis(G):
            edge_in_cycle = False
            for i in range(len(cycle)):
                a, b = cycle[i], cycle[(i+1)%len(cycle)]
                if (a == u and b == v) or (a == v and b == u):
                    edge_in_cycle = True
                    break
            if edge_in_cycle:
                cycles.append(len(cycle))
        cycles = sorted(cycles)
        bc = edge_bc.get(e, edge_bc.get((v,u), 0.0))
        features.append({
            'deg_pair': deg_pair,
            'cycles': cycles,
            'betweenness': float(bc)
        })
    return features

def main():
    print("=== 追问为什么_同分布边对的分布多样性 ===\n")
    
    all_graphs = get_all_N6_graphs()
    s_values = np.linspace(-1.5, 0.0, 21)
    
    # 找出所有异轨道同排序分布边对
    targets = []
    for g_idx, edges in enumerate(all_graphs):
        n_edges = len(edges)
        orbits, edge_to_orbit = get_edge_orbits_from_edges(edges, N)
        features = get_edge_features(edges, N)
        
        sorted_curves = []
        for i in range(n_edges):
            sorted_curve = []
            for s in s_values:
                J = np.ones(n_edges); J[i] = s
                probs, basis = compute_probs_with_degen(N, edges, J)
                corrs = compute_corrs_from_probs(N, edges, basis, probs)
                sorted_curve.append(np.sort(corrs))
            sorted_curves.append(sorted_curve)
        
        for i in range(n_edges):
            for j in range(i+1, n_edges):
                if edge_to_orbit[i] == edge_to_orbit[j]:
                    continue
                all_same = True
                for si in range(len(s_values)):
                    if not np.allclose(sorted_curves[i][si], sorted_curves[j][si], atol=TOL_CURVE):
                        all_same = False
                        break
                if all_same:
                    targets.append({
                        'graph': g_idx,
                        'edge_i': i,
                        'edge_j': j,
                        'orbit_i': edge_to_orbit[i],
                        'orbit_j': edge_to_orbit[j],
                        'feat_i': features[i],
                        'feat_j': features[j],
                        'edges': edges
                    })
    
    print(f"异轨道同排序分布边对数：{len(targets)}")
    
    # 对每个目标，在Δ=-0.5处计算分布并统计多样性
    results = []
    for t in targets:
        g_idx = t['graph']
        edges = all_graphs[g_idx]
        n_edges = len(edges)
        ei = t['edge_i']
        ej = t['edge_j']
        
        J_i = np.ones(n_edges); J_i[ei] = DELTA
        probs_i, basis_i = compute_probs_with_degen(N, edges, J_i)
        corrs_i = compute_corrs_from_probs(N, edges, basis_i, probs_i)
        sorted_i = np.sort(corrs_i)
        n_distinct_i, distinct_i = count_distinct(sorted_i)
        
        J_j = np.ones(n_edges); J_j[ej] = DELTA
        probs_j, basis_j = compute_probs_with_degen(N, edges, J_j)
        corrs_j = compute_corrs_from_probs(N, edges, basis_j, probs_j)
        sorted_j = np.sort(corrs_j)
        n_distinct_j, distinct_j = count_distinct(sorted_j)
        
        results.append({
            'graph': g_idx,
            'edge_i': ei,
            'edge_j': ej,
            'orbit_i': t['orbit_i'],
            'orbit_j': t['orbit_j'],
            'deg_pair_i': t['feat_i']['deg_pair'],
            'deg_pair_j': t['feat_j']['deg_pair'],
            'cycles_i': t['feat_i']['cycles'],
            'cycles_j': t['feat_j']['cycles'],
            'n_distinct_i': n_distinct_i,
            'n_distinct_j': n_distinct_j,
            'distinct_i': distinct_i,
            'distinct_j': distinct_j,
            'unsorted_same': np.allclose(corrs_i, corrs_j, atol=1e-8),
            'sorted_i': sorted_i.tolist(),
            'sorted_j': sorted_j.tolist()
        })
    
    # 打印统计
    print(f"\n===== 多样性统计（Δ={DELTA}） =====")
    print(f"边1不同值个数范围：{min(r['n_distinct_i'] for r in results)} - {max(r['n_distinct_i'] for r in results)}")
    print(f"边2不同值个数范围：{min(r['n_distinct_j'] for r in results)} - {max(r['n_distinct_j'] for r in results)}")
    
    low_diversity = sum(1 for r in results if r['n_distinct_i'] <= 3 and r['n_distinct_j'] <= 3)
    print(f"低多样性（≤3个不同值）边对数：{low_diversity}/{len(results)}")
    
    # 输出前10个
    print("\n===== 前10个边对详情 =====")
    for r in results[:10]:
        print(f"\n图{r['graph']} 边{r['edge_i']}(轨道{r['orbit_i']}) vs 边{r['edge_j']}(轨道{r['orbit_j']})")
        print(f"  度对: {r['deg_pair_i']} vs {r['deg_pair_j']}")
        print(f"  环长: {r['cycles_i']} vs {r['cycles_j']}")
        print(f"  不同值个数: {r['n_distinct_i']} vs {r['n_distinct_j']}")
        print(f"  未排序相同: {r['unsorted_same']}")
        print(f"  排序分布: {np.round(r['sorted_i'], 4)}")
        print(f"           {np.round(r['sorted_j'], 4)}")
    
    output = {
        'targets': targets,
        'results': results,
        'n_targets': len(results),
        'low_diversity_count': low_diversity,
        'note': '追问：排序分布相同是否源于分布退化？'
    }
    with open('jingmai_why_distribution_diversity.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_distribution_diversity.json")

if __name__ == "__main__":
    main()