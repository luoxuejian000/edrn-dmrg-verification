"""
轨道决定论终极检验.py

目标：
    对轨道决定论进行终极检验，从多个可能推翻结论的方向攻击：
        1. 严格容差：1e-10, 1e-12, 1e-14
        2. 不同磁化子空间：N_up=2 vs N_up=3（不同Sz扇区）
        3. 完全图K6：所有边同轨道，检验E(s)曲线是否逐点相同
        4. 改变扫描区间：[-1.5,0] vs [-2,1] vs [-1,1]
        5. 未排序关联分布直接对比：同轨道边应逐点相同
    对每个检验，输出标准物理（能隙、端点度）与晶脉视角
    （同轨道同曲线/异曲线、未排序分布差异）。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据，反例全部输出。
    使用精确对角化。

理论精髓：
    - 主动找反例，不维护结论。
    - 数据自己说话。

输出：
    jingmai_ultimate_refutation.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

# ========== 参数 ==========
TOL_VALUES = [1e-8, 1e-10, 1e-12, 1e-14]  # 多级容差

def get_small_world(N=6, seed=42):
    G = nx.watts_strogatz_graph(N, 4, 0.1, seed=seed)
    edges = [tuple(sorted(e)) for e in G.edges()]
    edges.sort()
    return edges

def get_complete_graph(N=6):
    edges = list(itertools.combinations(range(N), 2))
    edges.sort()
    return edges

def build_hamiltonian(N, edges, J_vals, N_up=None):
    if N_up is None:
        N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def compute_correlations(N, edges, J_vals, N_up=None):
    """返回未排序关联分布"""
    H, basis = build_hamiltonian(N, edges, J_vals, N_up)
    evals, evecs = np.linalg.eigh(H)
    psi = evecs[:, 0]
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(np.abs(psi)**2 * diag_vals)
        corrs.append(corr)
    return np.array(corrs)

def compute_E_fine(N, edges, J_vals, N_up=None):
    corrs = compute_correlations(N, edges, J_vals, N_up)
    return float(np.std(corrs))

def get_edge_orbits_from_edges(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    automorphisms = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in automorphisms:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return orbits, edge_to_orbit

def same_curve(c1, c2, tol):
    return np.allclose(c1, c2, atol=tol)

def same_vector_direct(v1, v2, tol):
    return np.allclose(v1, v2, atol=tol)

def main():
    print("=== 轨道决定论终极检验 ===")
    print(f"容差级别：{TOL_VALUES}\n")
    
    all_results = {}
    
    # ========== 检验一：严格容差（小世界图 N=6, seed=42） ==========
    print("===== 检验一：严格容差（小世界图 N=6, seed=42） =====")
    N = 6
    edges = get_small_world(N, seed=42)
    n_edges = len(edges)
    orbits, edge_to_orbit = get_edge_orbits_from_edges(edges, N)
    
    s_values = np.arange(-1.5, 0.0 + 0.001, 0.001)
    E_curves = []
    for i in range(n_edges):
        curve = np.zeros(len(s_values))
        for si, s in enumerate(s_values):
            J = np.ones(n_edges); J[i] = s
            curve[si] = compute_E_fine(N, edges, J)
        E_curves.append(curve)
    
    for tol in TOL_VALUES:
        stats = {'same_orbit_same': 0, 'same_orbit_diff': 0,
                 'diff_orbit_same': 0, 'diff_orbit_diff': 0}
        for i in range(n_edges):
            for j in range(i+1, n_edges):
                cs = same_curve(E_curves[i], E_curves[j], tol)
                os_ = edge_to_orbit[i] == edge_to_orbit[j]
                if os_:
                    if cs: stats['same_orbit_same'] += 1
                    else: stats['same_orbit_diff'] += 1
                else:
                    if cs: stats['diff_orbit_same'] += 1
                    else: stats['diff_orbit_diff'] += 1
        print(f"  容差 {tol:.0e}: 同轨道同={stats['same_orbit_same']}, "
              f"同轨道异={stats['same_orbit_diff']}, "
              f"异轨道同={stats['diff_orbit_same']}, "
              f"异轨道异={stats['diff_orbit_diff']}")
        all_results[f'test1_tol_{tol}'] = stats
    
    # ========== 检验二：不同磁化子空间（N_up=2 vs N_up=3） ==========
    print("\n===== 检验二：不同磁化子空间（小世界图 N=6, seed=42） =====")
    for N_up in [2, 3]:
        E_curves_up = []
        for i in range(n_edges):
            curve = np.zeros(len(s_values))
            for si, s in enumerate(s_values):
                J = np.ones(n_edges); J[i] = s
                curve[si] = compute_E_fine(N, edges, J, N_up=N_up)
            E_curves_up.append(curve)
        stats = {'same_orbit_same': 0, 'same_orbit_diff': 0,
                 'diff_orbit_same': 0, 'diff_orbit_diff': 0}
        for i in range(n_edges):
            for j in range(i+1, n_edges):
                cs = same_curve(E_curves_up[i], E_curves_up[j], 1e-8)
                os_ = edge_to_orbit[i] == edge_to_orbit[j]
                if os_:
                    if cs: stats['same_orbit_same'] += 1
                    else: stats['same_orbit_diff'] += 1
                else:
                    if cs: stats['diff_orbit_same'] += 1
                    else: stats['diff_orbit_diff'] += 1
        print(f"  N_up={N_up}: 同轨道同={stats['same_orbit_same']}, "
              f"同轨道异={stats['same_orbit_diff']}, "
              f"异轨道同={stats['diff_orbit_same']}, "
              f"异轨道异={stats['diff_orbit_diff']}")
        all_results[f'test2_Nup_{N_up}'] = stats
    
    # ========== 检验三：完全图K6（所有边同轨道） ==========
    print("\n===== 检验三：完全图K6（所有边同轨道） =====")
    N6 = 6
    edges_K6 = get_complete_graph(N6)
    n_edges_K6 = len(edges_K6)
    orbits_K6, edge_to_orbit_K6 = get_edge_orbits_from_edges(edges_K6, N6)
    print(f"  边数：{n_edges_K6}, 轨道数：{len(orbits_K6)}")
    
    s_values_K6 = np.arange(-1.5, 0.0 + 0.001, 0.001)
    E_curves_K6 = []
    for i in range(n_edges_K6):
        curve = np.zeros(len(s_values_K6))
        for si, s in enumerate(s_values_K6):
            J = np.ones(n_edges_K6); J[i] = s
            curve[si] = compute_E_fine(N6, edges_K6, J)
        E_curves_K6.append(curve)
    
    stats_K6 = {'same_orbit_same': 0, 'same_orbit_diff': 0,
                'diff_orbit_same': 0, 'diff_orbit_diff': 0}
    for i in range(n_edges_K6):
        for j in range(i+1, n_edges_K6):
            cs = same_curve(E_curves_K6[i], E_curves_K6[j], 1e-8)
            os_ = edge_to_orbit_K6[i] == edge_to_orbit_K6[j]
            if os_:
                if cs: stats_K6['same_orbit_same'] += 1
                else: stats_K6['same_orbit_diff'] += 1
            else:
                if cs: stats_K6['diff_orbit_same'] += 1
                else: stats_K6['diff_orbit_diff'] += 1
    print(f"  同轨道同={stats_K6['same_orbit_same']}, "
          f"同轨道异={stats_K6['same_orbit_diff']}, "
          f"异轨道同={stats_K6['diff_orbit_same']}, "
          f"异轨道异={stats_K6['diff_orbit_diff']}")
    all_results['test3_K6'] = stats_K6
    
    # ========== 检验四：改变扫描区间（小世界图 N=6, seed=42） ==========
    print("\n===== 检验四：改变扫描区间 =====")
    for scan_range in [(-1.5, 0.0), (-2.0, 1.0), (-1.0, 1.0)]:
        s_start, s_end = scan_range
        s_vals = np.arange(s_start, s_end + 0.001, 0.001)
        E_curves_scan = []
        for i in range(n_edges):
            curve = np.zeros(len(s_vals))
            for si, s in enumerate(s_vals):
                J = np.ones(n_edges); J[i] = s
                curve[si] = compute_E_fine(N, edges, J)
            E_curves_scan.append(curve)
        stats = {'same_orbit_same': 0, 'same_orbit_diff': 0,
                 'diff_orbit_same': 0, 'diff_orbit_diff': 0}
        for i in range(n_edges):
            for j in range(i+1, n_edges):
                cs = same_curve(E_curves_scan[i], E_curves_scan[j], 1e-8)
                os_ = edge_to_orbit[i] == edge_to_orbit[j]
                if os_:
                    if cs: stats['same_orbit_same'] += 1
                    else: stats['same_orbit_diff'] += 1
                else:
                    if cs: stats['diff_orbit_same'] += 1
                    else: stats['diff_orbit_diff'] += 1
        print(f"  区间 [{s_start},{s_end}]: 同轨道同={stats['same_orbit_same']}, "
              f"同轨道异={stats['same_orbit_diff']}, "
              f"异轨道同={stats['diff_orbit_same']}, "
              f"异轨道异={stats['diff_orbit_diff']}")
        all_results[f'test4_scan_{s_start}_{s_end}'] = stats
    
    # ========== 检验五：未排序关联分布直接对比（小世界图 N=6, seed=42） ==========
    print("\n===== 检验五：未排序关联分布直接对比 =====")
    s_values_direct = np.arange(-1.5, 0.0 + 0.001, 0.001)
    corr_curves = []
    for i in range(n_edges):
        curve = np.zeros((len(s_values_direct), n_edges))
        for si, s in enumerate(s_values_direct):
            J = np.ones(n_edges); J[i] = s
            curve[si, :] = compute_correlations(N, edges, J)
        corr_curves.append(curve)
    
    stats_direct = {'same_orbit_same': 0, 'same_orbit_diff': 0,
                    'diff_orbit_same': 0, 'diff_orbit_diff': 0}
    for i in range(n_edges):
        for j in range(i+1, n_edges):
            # 未排序分布逐点对比
            all_same = True
            for si in range(len(s_values_direct)):
                if not same_vector_direct(corr_curves[i][si], corr_curves[j][si], 1e-8):
                    all_same = False
                    break
            os_ = edge_to_orbit[i] == edge_to_orbit[j]
            if os_:
                if all_same: stats_direct['same_orbit_same'] += 1
                else: stats_direct['same_orbit_diff'] += 1
            else:
                if all_same: stats_direct['diff_orbit_same'] += 1
                else: stats_direct['diff_orbit_diff'] += 1
    print(f"  同轨道同={stats_direct['same_orbit_same']}, "
          f"同轨道异={stats_direct['same_orbit_diff']}, "
          f"异轨道同={stats_direct['diff_orbit_same']}, "
          f"异轨道异={stats_direct['diff_orbit_diff']}")
    all_results['test5_direct_corrs'] = stats_direct
    
    # 保存
    output = {
        'TOL_VALUES': TOL_VALUES,
        'all_results': all_results,
        'note': '轨道决定论终极检验：严格容差、不同磁化子空间、完全图K6、改变扫描区间、未排序关联分布直接对比。'
    }
    with open('jingmai_ultimate_refutation.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_ultimate_refutation.json")

if __name__ == "__main__":
    main()