"""
追问为什么_割点边与分支边等价.py

目标：
    追问主要失败模式：割点边与分支边为什么响应等价。
    对每个有割点的问题图：
        1. 删除割点，得到分支
        2. 把边分成割点边和分支边
        3. 对每对“割点边 vs 分支边”，检查响应是否相同
        4. 检查等价对的边在局部拓扑上是否有共同特征：
            - 边的两个端点在删除割点后图中到割点的距离
            - 两个端点各自的分支内度
            - 边的两端点在图中的等价角色
    统计：
        - 等价边对中，割点边与分支边的局部特征是否匹配
        - 正常图中是否有类似等价

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。
    基态简并使用对称性约化密度矩阵。

输出：
    jingmai_why_cut_edge_branch_edge.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
S_POINTS = 11
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10

def build_heisenberg(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def compute_corrs(N, edges, basis, probs):
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return np.array(corrs)

def get_sorted_curves(N, edges, s_values):
    n_edges = len(edges)
    curves = []
    for i in range(n_edges):
        curve = []
        for s in s_values:
            J = np.ones(n_edges); J[i] = s
            H, basis = build_heisenberg(N, edges, J)
            evals, evecs = np.linalg.eigh(H)
            E0 = evals[0]
            degen = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
            probs = np.zeros(len(basis))
            for idx in degen:
                probs += np.abs(evecs[:, idx])**2
            probs /= len(degen)
            corrs = compute_corrs(N, edges, basis, probs)
            curve.append(np.sort(corrs))
        curves.append(curve)
    return curves

def get_edge_orbits(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    autos = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in autos:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return edge_to_orbit

def main():
    print("=== 追问为什么_割点边与分支边等价 ===\n")
    
    all_graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            all_graphs.append(edges)
    
    problem_with_cut = [9, 26, 31, 33, 49, 55, 60, 64, 69]
    s_values = np.linspace(-1.5, 0.0, S_POINTS)
    
    all_equivalences = []
    
    for g_idx in problem_with_cut:
        edges = all_graphs[g_idx]
        G = nx.Graph()
        G.add_nodes_from(range(N))
        G.add_edges_from(edges)
        cut_vertices = list(nx.articulation_points(G))
        edge_to_orbit = get_edge_orbits(edges, N)
        n_edges = len(edges)
        
        curves = get_sorted_curves(N, edges, s_values)
        
        print(f"\n===== 图{g_idx}: 割点={cut_vertices} =====")
        for cv in cut_vertices:
            G_removed = G.copy()
            G_removed.remove_node(cv)
            components = list(nx.connected_components(G_removed))
            print(f"  割点{cv}, 分支：{components}")
            
            # 分类边
            cut_edges = []
            branch_edges = []
            for ei, (u, v) in enumerate(edges):
                if u == cv or v == cv:
                    cut_edges.append(ei)
                else:
                    branch_edges.append(ei)
            
            print(f"  割点边：{cut_edges}")
            print(f"  分支边：{branch_edges}")
            
            # 检查割点边与分支边的等价
            for ci in cut_edges:
                for bi in branch_edges:
                    same = all(np.allclose(c1, c2, atol=TOL_CURVE) 
                              for c1, c2 in zip(curves[ci], curves[bi]))
                    if same and edge_to_orbit[ci] != edge_to_orbit[bi]:
                        # 计算局部特征
                        u_c, v_c = edges[ci]
                        u_b, v_b = edges[bi]
                        # 割点边：另一个端点到割点的距离
                        other_c = u_c if v_c == cv else v_c
                        # 分支边的端点到割点的距离
                        dist_u_b = nx.shortest_path_length(G, u_b, cv)
                        dist_v_b = nx.shortest_path_length(G, v_b, cv)
                        # 边两端在分支内的度
                        deg_u_b = G.degree(u_b)
                        deg_v_b = G.degree(v_b)
                        # 割点边的另一个端点的度
                        deg_other_c = G.degree(other_c)
                        
                        print(f"    等价对：割点边{ci}({edges[ci]}) vs 分支边{bi}({edges[bi]})")
                        print(f"      割点边另一端点{other_c}: 度={deg_other_c}, 轨道={edge_to_orbit[ci]}")
                        print(f"      分支边两端点: {u_b}(度={deg_u_b}), {v_b}(度={deg_v_b}), "
                              f"到割点距离=({dist_u_b},{dist_v_b}), 轨道={edge_to_orbit[bi]}")
                        
                        all_equivalences.append({
                            'graph': g_idx,
                            'cut_vertex': cv,
                            'cut_edge': ci,
                            'branch_edge': bi,
                            'cut_edge_nodes': edges[ci],
                            'branch_edge_nodes': edges[bi],
                            'other_c': other_c,
                            'deg_other_c': deg_other_c,
                            'u_b': u_b, 'v_b': v_b,
                            'deg_u_b': deg_u_b, 'deg_v_b': deg_v_b,
                            'dist_u_b': dist_u_b, 'dist_v_b': dist_v_b,
                            'orbit_cut': edge_to_orbit[ci],
                            'orbit_branch': edge_to_orbit[bi]
                        })
    
    # 统计
    print(f"\n===== 统计 =====")
    print(f"割点边-分支边等价对总数：{len(all_equivalences)}")
    
    # 分析共同特征
    if all_equivalences:
        # 割点边另一端点的度
        deg_others = [e['deg_other_c'] for e in all_equivalences]
        print(f"割点边另一端点度分布：{sorted(set(deg_others))}")
        # 分支边端点到割点的距离
        dist_pairs = [(e['dist_u_b'], e['dist_v_b']) for e in all_equivalences]
        print(f"分支边到割点距离分布：{sorted(set(dist_pairs))}")
        # 分支边端点度
        deg_branch_pairs = [(e['deg_u_b'], e['deg_v_b']) for e in all_equivalences]
        print(f"分支边端点度分布：{sorted(set(deg_branch_pairs))}")
    
    output = {
        'all_equivalences': all_equivalences,
        'n_total': len(all_equivalences),
        'note': '追问割点边与分支边的等价机制。'
    }
    with open('jingmai_why_cut_edge_branch_edge.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_cut_edge_branch_edge.json")

if __name__ == "__main__":
    main()