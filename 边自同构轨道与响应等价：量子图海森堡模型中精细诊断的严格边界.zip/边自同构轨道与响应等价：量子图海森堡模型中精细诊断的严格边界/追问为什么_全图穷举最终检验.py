"""
追问为什么_全图穷举最终检验.py

目标：
    对N=6穷举中的所有112个连通图，在正确处理简并基态后，
    重新检验轨道决定论是否零反例。
    
    对每个图：
        1. 计算边自同构轨道
        2. 对每条边，在扫描区间内多个Δ点检查基态简并
        3. 若存在简并点，使用对称性约化密度矩阵计算E(s)
        4. 对同轨道边对，比较E(s)曲线是否逐点相同
        5. 统计反例数量
    最终判断：正确处理简并后，轨道决定论是否在所有N=6图中零反例。
    
    并排展示标准物理（能隙、简并度）与晶脉视角（反例统计）。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。
    扫描点数：21（控制计算量）。

输出：
    jingmai_full_exhaustive_final.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
N_S = 21  # 扫描点数
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10

def build_hamiltonian_and_basis(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def compute_E_with_degen_handling(N, edges, J_vals):
    """计算精细诊断，正确处理基态简并"""
    H, basis = build_hamiltonian_and_basis(N, edges, J_vals)
    evals, evecs = np.linalg.eigh(H)
    E0 = evals[0]
    degen_indices = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
    degen_dim = len(degen_indices)
    
    # 对称性约化密度矩阵：简并子空间均匀混合
    probs = np.zeros(len(basis))
    for idx in degen_indices:
        probs += np.abs(evecs[:, idx])**2
    probs /= degen_dim
    
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    
    return float(np.std(np.array(corrs))), degen_dim

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def get_edge_orbits_from_edges(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    automorphisms = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in automorphisms:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return orbits, edge_to_orbit

def same_curve(c1, c2, tol=TOL_CURVE):
    return np.allclose(c1, c2, atol=tol)

def main():
    print("=== 追问为什么_全图穷举最终检验 ===\n")
    
    all_graphs = get_all_N6_graphs()
    print(f"总图数：{len(all_graphs)}")
    
    s_values = np.linspace(-1.5, 0.0, N_S)
    
    total_same_orbit_same = 0
    total_same_orbit_diff = 0
    total_diff_orbit_same = 0
    total_diff_orbit_diff = 0
    total_ce = 0
    ce_graphs = []
    
    for g_idx, edges in enumerate(all_graphs):
        n_edges = len(edges)
        orbits, edge_to_orbit = get_edge_orbits_from_edges(edges, N)
        
        # 扫描所有边，正确处理简并
        E_curves = []
        degen_flags = []
        for i in range(n_edges):
            curve = np.zeros(N_S)
            degen_any = False
            for si, s in enumerate(s_values):
                J = np.ones(n_edges); J[i] = s
                E_val, degen_dim = compute_E_with_degen_handling(N, edges, J)
                curve[si] = E_val
                if degen_dim > 1:
                    degen_any = True
            E_curves.append(curve)
            degen_flags.append(degen_any)
        
        # 比较同轨道边对
        for i in range(n_edges):
            for j in range(i+1, n_edges):
                cs = same_curve(E_curves[i], E_curves[j])
                os_ = edge_to_orbit[i] == edge_to_orbit[j]
                if os_:
                    if cs:
                        total_same_orbit_same += 1
                    else:
                        total_same_orbit_diff += 1
                        total_ce += 1
                        ce_graphs.append((g_idx, 'same_orbit_diff', i, j))
                else:
                    if cs:
                        total_diff_orbit_same += 1
                        total_ce += 1
                        ce_graphs.append((g_idx, 'diff_orbit_same', i, j))
                    else:
                        total_diff_orbit_diff += 1
        
        if (g_idx+1) % 20 == 0:
            print(f"  进度：{g_idx+1}/{len(all_graphs)}")
    
    print(f"\n===== 最终统计（正确处理简并后） =====")
    print(f"同轨道同曲线：{total_same_orbit_same}")
    print(f"同轨道异曲线：{total_same_orbit_diff}")
    print(f"异轨道同曲线：{total_diff_orbit_same}")
    print(f"异轨道异曲线：{total_diff_orbit_diff}")
    print(f"总反例数：{total_ce}")
    
    if total_ce > 0:
        print(f"\n有反例的图数：{len(set(ce[0] for ce in ce_graphs))}")
        print("反例详情（前20个）：")
        for ce in ce_graphs[:20]:
            print(f"  图{ce[0]} 类型={ce[1]} 边{ce[2]} vs 边{ce[3]}")
    else:
        print("\n轨道决定论在所有N=6连通图中零反例（正确处理简并后）。")
    
    output = {
        'total_graphs': len(all_graphs),
        'N_S': N_S,
        'TOL_DEGEN': TOL_DEGEN,
        'TOL_CURVE': TOL_CURVE,
        'total_same_orbit_same': total_same_orbit_same,
        'total_same_orbit_diff': total_same_orbit_diff,
        'total_diff_orbit_same': total_diff_orbit_same,
        'total_diff_orbit_diff': total_diff_orbit_diff,
        'total_ce': total_ce,
        'ce_graphs': ce_graphs,
        'note': '正确处理基态简并（对称性约化密度矩阵）后的最终检验。'
    }
    with open('jingmai_full_exhaustive_final.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_full_exhaustive_final.json")

if __name__ == "__main__":
    main()