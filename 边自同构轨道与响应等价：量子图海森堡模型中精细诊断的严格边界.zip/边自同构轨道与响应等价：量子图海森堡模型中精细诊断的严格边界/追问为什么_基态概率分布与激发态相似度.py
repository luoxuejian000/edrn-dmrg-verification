"""
追问为什么_基态概率分布与激发态相似度.py

目标：
    继续追问：排序分布相同但完整本征值谱不同，那么基态波函数结构是否不同？
    对每对同分布边对，在多个Δ点：
        1. 计算基态概率分布的熵 S_ent
        2. 计算基态与第一激发态关联分布的相似度 sim_01
        3. 比较两边这些量的差异
    并排呈现标准物理视角（谱差异、能隙）与晶脉视角（排序分布相同）。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。
    基态简并使用对称性约化密度矩阵。

理论精髓：
    - 数据自己说话。
    - 追问：分布相同是否意味着波函数结构也相同？

输出：
    jingmai_why_wavefunction_structure.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10
DELTA_VALUES = [-1.5, -1.0, -0.5, -0.25, 0.0]

def build_hamiltonian_and_basis(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def compute_probs_with_degen(N, edges, J_vals):
    H, basis = build_hamiltonian_and_basis(N, edges, J_vals)
    evals, evecs = np.linalg.eigh(H)
    E0 = evals[0]
    degen_indices = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
    degen_dim = len(degen_indices)
    probs = np.zeros(len(basis))
    for idx in degen_indices:
        probs += np.abs(evecs[:, idx])**2
    probs /= degen_dim
    return probs, basis, evals, evecs, degen_indices

def compute_corrs_from_probs(N, edges, basis, probs):
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return np.array(corrs)

def compute_prob_entropy(probs):
    p = probs[probs > 1e-12]
    return float(-np.sum(p * np.log(p)))

def distribution_similarity(dist1, dist2):
    return float(np.linalg.norm(np.sort(dist1) - np.sort(dist2)))

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def get_edge_orbits_from_edges(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    automorphisms = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in automorphisms:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return orbits, edge_to_orbit

def main():
    print("=== 追问为什么_基态概率分布与激发态相似度 ===\n")
    
    all_graphs = get_all_N6_graphs()
    
    # 读取同分布边对
    with open('jingmai_why_distribution_diversity.json', 'r', encoding='utf-8') as f:
        diversity_data = json.load(f)
    targets = diversity_data['results']
    print(f"同分布边对数：{len(targets)}")
    
    results = []
    
    for t in targets:
        g_idx = t['graph']
        edges = all_graphs[g_idx]
        n_edges = len(edges)
        ei = t['edge_i']
        ej = t['edge_j']
        
        print(f"\n图{g_idx} 边{ei}(轨道{t['orbit_i']}) vs 边{ej}(轨道{t['orbit_j']})")
        print(f"  {'Δ':<8} {'能隙':<12} {'熵i':<12} {'熵j':<12} {'熵同':<6} {'sim01_i':<12} {'sim01_j':<12} {'sim01同':<6}")
        
        for s_val in DELTA_VALUES:
            # 边 ei
            J_i = np.ones(n_edges); J_i[ei] = s_val
            probs_i, basis_i, evals_i, evecs_i, degen_i = compute_probs_with_degen(N, edges, J_i)
            corrs_i = compute_corrs_from_probs(N, edges, basis_i, probs_i)
            ent_i = compute_prob_entropy(probs_i)
            # 第一激发态关联分布
            if len(degen_i) > 1:
                # 简并基态，激发态取简并外第一个
                E0 = evals_i[0]
                excited_indices = [k for k in range(len(evals_i)) if evals_i[k] > E0 + TOL_DEGEN]
                if excited_indices:
                    idx_ex = excited_indices[0]
                    psi_ex = evecs_i[:, idx_ex]
                else:
                    psi_ex = evecs_i[:, 0]
            else:
                psi_ex = evecs_i[:, 1]
            probs_ex_i = np.abs(psi_ex)**2
            corrs_ex_i = compute_corrs_from_probs(N, edges, basis_i, probs_ex_i)
            sim01_i = distribution_similarity(corrs_i, corrs_ex_i)
            gap_i = float(evals_i[1] - evals_i[0])
            
            # 边 ej
            J_j = np.ones(n_edges); J_j[ej] = s_val
            probs_j, basis_j, evals_j, evecs_j, degen_j = compute_probs_with_degen(N, edges, J_j)
            corrs_j = compute_corrs_from_probs(N, edges, basis_j, probs_j)
            ent_j = compute_prob_entropy(probs_j)
            if len(degen_j) > 1:
                E0j = evals_j[0]
                excited_indices_j = [k for k in range(len(evals_j)) if evals_j[k] > E0j + TOL_DEGEN]
                if excited_indices_j:
                    idx_exj = excited_indices_j[0]
                    psi_exj = evecs_j[:, idx_exj]
                else:
                    psi_exj = evecs_j[:, 0]
            else:
                psi_exj = evecs_j[:, 1]
            probs_ex_j = np.abs(psi_exj)**2
            corrs_ex_j = compute_corrs_from_probs(N, edges, basis_j, probs_ex_j)
            sim01_j = distribution_similarity(corrs_j, corrs_ex_j)
            gap_j = float(evals_j[1] - evals_j[0])
            
            ent_same = abs(ent_i - ent_j) < TOL_CURVE
            sim01_same = abs(sim01_i - sim01_j) < TOL_CURVE
            
            print(f"  {s_val:<8.2f} {gap_i:<12.8f} {ent_i:<12.8f} {ent_j:<12.8f} {str(ent_same):<6} "
                  f"{sim01_i:<12.8f} {sim01_j:<12.8f} {str(sim01_same):<6}")
            
            results.append({
                'graph': g_idx,
                'edge_i': ei,
                'edge_j': ej,
                's_val': s_val,
                'gap_i': gap_i,
                'gap_j': gap_j,
                'entropy_i': ent_i,
                'entropy_j': ent_j,
                'entropy_same': bool(ent_same),
                'sim01_i': sim01_i,
                'sim01_j': sim01_j,
                'sim01_same': bool(sim01_same)
            })
    
    # 统计
    n_ent_same = sum(1 for r in results if r['entropy_same'])
    n_sim01_same = sum(1 for r in results if r['sim01_same'])
    n_total = len(results)
    
    print(f"\n===== 统计 =====")
    print(f"总检查点：{n_total}")
    print(f"基态概率分布熵相同：{n_ent_same}")
    print(f"基态-第一激发态关联分布相似度相同：{n_sim01_same}")
    
    output = {
        'results': results,
        'n_total': n_total,
        'n_entropy_same': n_ent_same,
        'n_sim01_same': n_sim01_same,
        'note': '追问：排序分布相同但谱不同时，基态波函数结构是否相同？'
    }
    with open('jingmai_why_wavefunction_structure.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_wavefunction_structure.json")

if __name__ == "__main__":
    main()