"""
追问为什么_异轨道同曲线深挖.py

目标：
    对正确处理简并后仍存在的37个异轨道同曲线反例进行深挖。
    对每个反例边对，检查：
        1. E(s)曲线最大差异
        2. 在多个Δ点，未排序关联分布是否相同
        3. 排序关联分布是否相同
        4. 若排序分布相同，则轨道分类在排序分布层面也失败；
           若排序分布不同但标准差相同，则E(s)标准差丢失了分布信息。
    并排呈现标准物理（轨道编号）与晶脉视角（分布对比）。

方法：
    只查同与不同，不拟合。
    不筛除任何数据。

输出：
    jingmai_why_diff_orbit_same.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
TOL_CURVE = 1e-10
DELTA_CHECK = [-1.5, -1.0, -0.5, -0.25, 0.0]

def build_hamiltonian_and_basis(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def compute_corr_with_degen(N, edges, J_vals):
    H, basis = build_hamiltonian_and_basis(N, edges, J_vals)
    evals, evecs = np.linalg.eigh(H)
    E0 = evals[0]
    degen_indices = [k for k in range(len(evals)) if abs(evals[k]-E0) < 1e-8]
    degen_dim = len(degen_indices)
    probs = np.zeros(len(basis))
    for idx in degen_indices:
        probs += np.abs(evecs[:, idx])**2
    probs /= degen_dim
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return np.array(corrs)

def compute_E_with_degen(N, edges, J_vals):
    corrs = compute_corr_with_degen(N, edges, J_vals)
    return float(np.std(corrs))

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def get_edge_orbits_from_edges(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    automorphisms = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in automorphisms:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return orbits, edge_to_orbit

def main():
    print("=== 追问为什么_异轨道同曲线深挖 ===\n")
    
    all_graphs = get_all_N6_graphs()
    s_values = np.linspace(-1.5, 0.0, 21)
    
    # 找出所有异轨道同曲线反例
    ce_list = []
    for g_idx, edges in enumerate(all_graphs):
        n_edges = len(edges)
        orbits, edge_to_orbit = get_edge_orbits_from_edges(edges, N)
        E_curves = []
        for i in range(n_edges):
            curve = np.zeros(21)
            for si, s in enumerate(s_values):
                J = np.ones(n_edges); J[i] = s
                curve[si] = compute_E_with_degen(N, edges, J)
            E_curves.append(curve)
        for i in range(n_edges):
            for j in range(i+1, n_edges):
                if edge_to_orbit[i] != edge_to_orbit[j]:
                    if np.allclose(E_curves[i], E_curves[j], atol=TOL_CURVE):
                        ce_list.append((g_idx, i, j, edge_to_orbit[i], edge_to_orbit[j]))
    
    print(f"异轨道同曲线反例数：{len(ce_list)}")
    
    # 深挖每个反例
    results = []
    for g_idx, ei, ej, oi, oj in ce_list:
        edges = all_graphs[g_idx]
        n_edges = len(edges)
        print(f"\n===== 图{g_idx} 边{ei}(轨道{oi}) vs 边{ej}(轨道{oj}) =====")
        
        for s_val in DELTA_CHECK:
            J_i = np.ones(n_edges); J_i[ei] = s_val
            J_j = np.ones(n_edges); J_j[ej] = s_val
            corrs_i = compute_corr_with_degen(N, edges, J_i)
            corrs_j = compute_corr_with_degen(N, edges, J_j)
            E_i = float(np.std(corrs_i))
            E_j = float(np.std(corrs_j))
            sorted_i = np.sort(corrs_i)
            sorted_j = np.sort(corrs_j)
            unsorted_same = np.allclose(corrs_i, corrs_j, atol=1e-8)
            sorted_same = np.allclose(sorted_i, sorted_j, atol=1e-8)
            E_same = abs(E_i - E_j) < 1e-10
            
            print(f"  Δ={s_val:.2f}: E_i={E_i:.8f}, E_j={E_j:.8f}, E相同={E_same}")
            print(f"    未排序相同={unsorted_same}, 排序后相同={sorted_same}")
            if not sorted_same:
                print(f"    排序分布_i: {np.round(sorted_i, 6)}")
                print(f"    排序分布_j: {np.round(sorted_j, 6)}")
            
            results.append({
                'graph': g_idx,
                'edge_i': ei,
                'edge_j': ej,
                'orbit_i': oi,
                'orbit_j': oj,
                's_val': s_val,
                'E_i': E_i,
                'E_j': E_j,
                'E_same': E_same,
                'unsorted_same': unsorted_same,
                'sorted_same': sorted_same
            })
    
    # 统计
    n_E_same = sum(1 for r in results if r['E_same'])
    n_unsorted_same = sum(1 for r in results if r['unsorted_same'])
    n_sorted_same = sum(1 for r in results if r['sorted_same'])
    n_total = len(results)
    
    print(f"\n===== 统计 =====")
    print(f"总检查点：{n_total}")
    print(f"E相同：{n_E_same}")
    print(f"未排序分布相同：{n_unsorted_same}")
    print(f"排序分布相同：{n_sorted_same}")
    print(f"排序分布不同但E相同：{n_E_same - n_sorted_same}")
    
    output = {
        'ce_list': ce_list,
        'results': results,
        'n_total': n_total,
        'n_E_same': n_E_same,
        'n_unsorted_same': n_unsorted_same,
        'n_sorted_same': n_sorted_same,
        'n_E_same_sorted_diff': n_E_same - n_sorted_same,
        'note': '异轨道同曲线反例深挖。'
    }
    with open('jingmai_why_diff_orbit_same.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_diff_orbit_same.json")

if __name__ == "__main__":
    main()