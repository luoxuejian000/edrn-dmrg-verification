"""
追问为什么_能隙偏移与激发态结构.py

目标：
    深挖29对能隙例外的能级结构。
    具体检查：
        1. 图33和图49的能隙偏移为0但能隙不同——检查简并度是否不同
        2. 所有例外的第一激发态偏移是否对应能级的“整体平移”
        3. 偏移量是否与两个基态简并度有关
        4. 偏移量是否与边在图中的位置（割点距离、度）相关
        5. 是否存在“偏移谱”——偏移量按图分组
    并排展示标准物理（能级结构、简并度）与晶脉视角（响应等价）。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。

输出：
    jingmai_why_offset_deep.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
S_POINTS = 11
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10
TOL_STRUCT = 1e-6

def build_basis(N):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    return basis, state_to_idx

def add_heisenberg_term(H, basis, state_to_idx, edges, J_vals):
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J

def build_heisenberg(N, edges, J_vals):
    basis, state_to_idx = build_basis(N)
    H = np.zeros((len(basis), len(basis)), dtype=float)
    add_heisenberg_term(H, basis, state_to_idx, edges, J_vals)
    return H, basis

def compute_full(N, edges, J_vals, k=10):
    H, basis = build_heisenberg(N, edges, J_vals)
    evals, evecs = np.linalg.eigh(H)
    E0 = float(evals[0])
    degen_indices = [idx for idx in range(len(evals)) if abs(evals[idx]-E0) < TOL_DEGEN]
    degen_dim = len(degen_indices)
    low_levels = [float(e) for e in evals[:k]]
    probs = np.zeros(len(basis))
    for idx in degen_indices:
        probs += np.abs(evecs[:, idx])**2
    probs /= degen_dim
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return {
        'E0': E0,
        'low_levels': low_levels,
        'degen_dim': degen_dim,
        'sorted_corrs': np.sort(np.array(corrs))
    }

def get_edge_data(N, edges, edge_idx, s_values, k=10):
    n_edges = len(edges)
    E0_curve = []
    low_curves = [[] for _ in range(k)]
    sorted_curves = []
    degen_curve = []
    for s in s_values:
        J = np.ones(n_edges); J[edge_idx] = s
        r = compute_full(N, edges, J, k)
        E0_curve.append(r['E0'])
        for ki in range(k):
            low_curves[ki].append(r['low_levels'][ki])
        sorted_curves.append(r['sorted_corrs'])
        degen_curve.append(r['degen_dim'])
    return {
        'E0': E0_curve,
        'low_curves': low_curves,
        'sorted_corrs': sorted_curves,
        'degen_curve': degen_curve
    }

def curves_equal(c1, c2, tol=TOL_CURVE):
    if len(c1) != len(c2):
        return False
    for a, b in zip(c1, c2):
        if isinstance(a, np.ndarray) or isinstance(b, np.ndarray):
            if not np.allclose(a, b, atol=tol):
                return False
        else:
            if abs(a - b) > tol:
                return False
    return True

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def get_edge_orbits(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    autos = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in autos:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return edge_to_orbit

def main():
    print("=== 追问为什么_能隙偏移与激发态结构 ===\n")
    
    all_graphs = get_all_N6_graphs()
    s_values = np.linspace(-1.5, 0.0, S_POINTS)
    K = 10
    
    # 读取之前的例外列表
    with open('jingmai_why_gap_offset_source.json', 'r', encoding='utf-8') as f:
        prev = json.load(f)
    exception_pairs = [(r['graph'], r['edge_i'], r['edge_j']) for r in prev['results']]
    
    print(f"待分析例外对数：{len(exception_pairs)}\n")
    
    all_analyses = []
    
    for g_idx, edge_i, edge_j in exception_pairs:
        edges = all_graphs[g_idx]
        n_edges = len(edges)
        G = nx.Graph()
        G.add_nodes_from(range(N))
        G.add_edges_from(edges)
        cut_vertices = list(nx.articulation_points(G))
        edge_to_orbit = get_edge_orbits(edges, N)
        
        data_i = get_edge_data(N, edges, edge_i, s_values, K)
        data_j = get_edge_data(N, edges, edge_j, s_values, K)
        
        # 简并度曲线
        degen_i = data_i['degen_curve']
        degen_j = data_j['degen_curve']
        degen_same = degen_i == degen_j
        
        # 能级偏移分析（用第一个Δ点）
        level_offsets = []
        for ki in range(K):
            offset = data_i['low_curves'][ki][0] - data_j['low_curves'][ki][0]
            level_offsets.append(round(offset, 6))
        
        # 检查每个能级偏移是否常数
        level_offsets_constant = []
        for ki in range(K):
            diffs = [data_i['low_curves'][ki][k] - data_j['low_curves'][ki][k] 
                     for k in range(len(s_values))]
            is_const = all(abs(d - diffs[0]) < TOL_STRUCT for d in diffs)
            level_offsets_constant.append(is_const)
        
        # 基态能量曲线是否相同
        E0_same = curves_equal(data_i['E0'], data_j['E0'])
        
        # 能隙偏移
        gap_shift = None
        for k in range(len(s_values)):
            d_i = degen_i[k]
            d_j = degen_j[k]
            if d_i == d_j:
                gap_i = data_i['low_curves'][d_i][k] - data_i['low_curves'][0][k]
                gap_j = data_j['low_curves'][d_j][k] - data_j['low_curves'][0][k]
                gap_shift = gap_i - gap_j
                break
        
        # 简并度对比
        max_degen_i = max(degen_i)
        max_degen_j = max(degen_j)
        
        # 边的特征
        u_i, v_i = edges[edge_i]
        u_j, v_j = edges[edge_j]
        deg_i = sorted([G.degree(u_i), G.degree(v_i)])
        deg_j = sorted([G.degree(u_j), G.degree(v_j)])
        
        # 到割点距离
        def dist_to_cut(edge, cv):
            u, v = edge
            if u == cv or v == cv:
                return 0
            try:
                du = nx.shortest_path_length(G, u, cv)
                dv = nx.shortest_path_length(G, v, cv)
                return min(du, dv)
            except:
                return -1
        
        if cut_vertices:
            dist_i = min(dist_to_cut(edges[edge_i], cv) for cv in cut_vertices)
            dist_j = min(dist_to_cut(edges[edge_j], cv) for cv in cut_vertices)
        else:
            dist_i = -1
            dist_j = -1
        
        analysis = {
            'graph': g_idx,
            'edge_i': edge_i,
            'edge_j': edge_j,
            'edges_i': edges[edge_i],
            'edges_j': edges[edge_j],
            'orbit_i': edge_to_orbit[edge_i],
            'orbit_j': edge_to_orbit[edge_j],
            'cut_vertices': cut_vertices,
            'E0_same': E0_same,
            'gap_shift': gap_shift,
            'degen_i_max': max_degen_i,
            'degen_j_max': max_degen_j,
            'degen_same': degen_same,
            'level_offsets': level_offsets,
            'level_offsets_constant': level_offsets_constant,
            'n_const_levels': sum(level_offsets_constant),
            'deg_i': deg_i,
            'deg_j': deg_j,
            'dist_to_cut_i': dist_i,
            'dist_to_cut_j': dist_j,
            'degen_i': degen_i,
            'degen_j': degen_j
        }
        all_analyses.append(analysis)
    
    # 统计
    print("===== 统计 =====")
    n_E0_same = sum(1 for a in all_analyses if a['E0_same'])
    n_degen_same = sum(1 for a in all_analyses if a['degen_same'])
    n_degen_diff = sum(1 for a in all_analyses if not a['degen_same'])
    
    print(f"基态能量曲线相同：{n_E0_same}/{len(all_analyses)}")
    print(f"简并度曲线相同：{n_degen_same}/{len(all_analyses)}")
    print(f"简并度曲线不同：{n_degen_diff}/{len(all_analyses)}")
    
    # 简并度与偏移的关系
    print(f"\n===== 简并度与偏移关系 =====")
    for a in all_analyses:
        print(f"\n图{a['graph']} 边{a['edge_i']} vs {a['edge_j']}:")
        print(f"  能隙偏移: {a['gap_shift']:.6f}")
        print(f"  最大简并度: i={a['degen_i_max']}, j={a['degen_j_max']}, 同={a['degen_same']}")
        print(f"  简并度曲线_i: {a['degen_i']}")
        print(f"  简并度曲线_j: {a['degen_j']}")
        print(f"  前10能级偏移: {a['level_offsets']}")
        print(f"  偏移常数的能级数: {a['n_const_levels']}/10")
    
    # 图33和图49的详细分析
    print(f"\n===== 图33和图49详细分析 =====")
    for a in all_analyses:
        if a['graph'] in [33, 49]:
            print(f"\n图{a['graph']} 边{a['edge_i']} vs {a['edge_j']}:")
            print(f"  能隙偏移: {a['gap_shift']:.6f}")
            print(f"  简并度曲线_i: {a['degen_i']}")
            print(f"  简并度曲线_j: {a['degen_j']}")
            print(f"  前10能级偏移: {a['level_offsets']}")
    
    output = {
        'all_analyses': all_analyses,
        'n_E0_same': n_E0_same,
        'n_degen_same': n_degen_same,
        'n_degen_diff': n_degen_diff,
        'note': '能隙偏移与激发态结构分析。'
    }
    with open('jingmai_why_offset_deep.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_offset_deep.json")

if __name__ == "__main__":
    main()