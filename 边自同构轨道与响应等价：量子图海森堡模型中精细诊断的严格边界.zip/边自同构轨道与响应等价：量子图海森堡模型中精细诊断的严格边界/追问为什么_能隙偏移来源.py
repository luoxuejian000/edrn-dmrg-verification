"""
追问为什么_能隙偏移来源.py

目标：
    追问能隙例外的固定偏移量来源。
    对每对例外：
        1. 计算能隙偏移量 ΔE = gap_i - gap_j（常数）
        2. 检查 ΔE 是否对应整数、半整数、或与图的某个量有关
        3. 检查偏移是否只在第一激发态，还是所有激发态都发生偏移
        4. 检查两条边的基态能量是否完全相同（已知是）
        5. 检查两条边的第一激发态能量曲线的偏移是否常数
        6. 检查偏移量与边在图中的局部特征（度、环、割点距离）的关系
    并排展示标准物理（能级偏移）与晶脉视角（响应等价）。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。
    基态简并使用对称性约化密度矩阵。

输出：
    jingmai_why_gap_offset_source.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
S_POINTS = 11
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10
TOL_STRUCT = 1e-6

def build_basis(N):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    return basis, state_to_idx

def add_heisenberg_term(H, basis, state_to_idx, edges, J_vals):
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J

def build_heisenberg(N, edges, J_vals):
    basis, state_to_idx = build_basis(N)
    H = np.zeros((len(basis), len(basis)), dtype=float)
    add_heisenberg_term(H, basis, state_to_idx, edges, J_vals)
    return H, basis

def compute_full(N, edges, J_vals, k=8):
    H, basis = build_heisenberg(N, edges, J_vals)
    evals, evecs = np.linalg.eigh(H)
    E0 = float(evals[0])
    degen_indices = [idx for idx in range(len(evals)) if abs(evals[idx]-E0) < TOL_DEGEN]
    degen_dim = len(degen_indices)
    low_levels = [float(e) for e in evals[:k]]
    probs = np.zeros(len(basis))
    for idx in degen_indices:
        probs += np.abs(evecs[:, idx])**2
    probs /= degen_dim
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return {
        'E0': E0,
        'low_levels': low_levels,
        'degen_dim': degen_dim,
        'sorted_corrs': np.sort(np.array(corrs))
    }

def get_edge_data(N, edges, edge_idx, s_values, k=8):
    n_edges = len(edges)
    E0_curve = []
    low_curves = [[] for _ in range(k)]
    sorted_curves = []
    degen_curve = []
    for s in s_values:
        J = np.ones(n_edges); J[edge_idx] = s
        r = compute_full(N, edges, J, k)
        E0_curve.append(r['E0'])
        for ki in range(k):
            low_curves[ki].append(r['low_levels'][ki])
        sorted_curves.append(r['sorted_corrs'])
        degen_curve.append(r['degen_dim'])
    return {
        'E0': E0_curve,
        'low_curves': low_curves,
        'sorted_corrs': sorted_curves,
        'degen_curve': degen_curve
    }

def curves_equal(c1, c2, tol=TOL_CURVE):
    if len(c1) != len(c2):
        return False
    for a, b in zip(c1, c2):
        if isinstance(a, np.ndarray) or isinstance(b, np.ndarray):
            if not np.allclose(a, b, atol=tol):
                return False
        else:
            if abs(a - b) > tol:
                return False
    return True

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def get_edge_orbits(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    autos = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in autos:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return edge_to_orbit

def main():
    print("=== 追问为什么_能隙偏移来源 ===\n")
    
    all_graphs = get_all_N6_graphs()
    s_values = np.linspace(-1.5, 0.0, S_POINTS)
    K = 8
    
    results = []
    
    for g_idx, edges in enumerate(all_graphs):
        n_edges = len(edges)
        edge_to_orbit = get_edge_orbits(edges, N)
        G = nx.Graph()
        G.add_nodes_from(range(N))
        G.add_edges_from(edges)
        cut_vertices = list(nx.articulation_points(G))
        
        all_data = []
        for i in range(n_edges):
            all_data.append(get_edge_data(N, edges, i, s_values, K))
        
        for i in range(n_edges):
            for j in range(i+1, n_edges):
                resp_same = curves_equal(all_data[i]['sorted_corrs'], all_data[j]['sorted_corrs'])
                if not resp_same:
                    continue
                # 检查能隙
                gap_i = []
                gap_j = []
                for k in range(len(s_values)):
                    d_i = all_data[i]['degen_curve'][k]
                    d_j = all_data[j]['degen_curve'][k]
                    gap_i.append(all_data[i]['low_curves'][d_i][k] - all_data[i]['low_curves'][0][k])
                    gap_j.append(all_data[j]['low_curves'][d_j][k] - all_data[j]['low_curves'][0][k])
                gap_same = all(abs(a-b) < TOL_CURVE for a, b in zip(gap_i, gap_j))
                if gap_same:
                    continue
                
                # 分析能级结构
                # 对每个能级，检查偏移是否常数
                level_shifts = []
                level_shift_constant = []
                for ki in range(K):
                    diffs = [all_data[i]['low_curves'][ki][k] - all_data[j]['low_curves'][ki][k]
                             for k in range(len(s_values))]
                    is_const = all(abs(d - diffs[0]) < TOL_STRUCT for d in diffs)
                    level_shifts.append(float(np.mean(diffs)))
                    level_shift_constant.append(is_const)
                
                # 基态能量是否相同
                E0_same = curves_equal(all_data[i]['E0'], all_data[j]['E0'])
                
                # 找第一个能级偏移
                first_shifted = None
                for ki in range(K):
                    if abs(level_shifts[ki]) > TOL_STRUCT:
                        first_shifted = ki
                        break
                
                # 能隙偏移量
                gap_shift = None
                for k in range(len(s_values)):
                    d_i = all_data[i]['degen_curve'][k]
                    d_j = all_data[j]['degen_curve'][k]
                    if d_i == d_j:
                        gap_shift = gap_i[k] - gap_j[k]
                        break
                
                # 边的局部特征
                u_i, v_i = edges[i]
                u_j, v_j = edges[j]
                deg_i = sorted([G.degree(u_i), G.degree(v_i)])
                deg_j = sorted([G.degree(u_j), G.degree(v_j)])
                
                # 边到割点的距离
                def dist_to_cut(edge, cv):
                    u, v = edge
                    if u == cv or v == cv:
                        return 0
                    try:
                        du = nx.shortest_path_length(G, u, cv)
                        dv = nx.shortest_path_length(G, v, cv)
                        return min(du, dv)
                    except:
                        return None
                
                # 与最近割点的距离
                if cut_vertices:
                    dist_i = min(dist_to_cut(edges[i], cv) for cv in cut_vertices)
                    dist_j = min(dist_to_cut(edges[j], cv) for cv in cut_vertices)
                else:
                    dist_i = None
                    dist_j = None
                
                results.append({
                    'graph': g_idx,
                    'edge_i': i,
                    'edge_j': j,
                    'edges_i': edges[i],
                    'edges_j': edges[j],
                    'orbit_i': edge_to_orbit[i],
                    'orbit_j': edge_to_orbit[j],
                    'cut_vertices': cut_vertices,
                    'E0_same': E0_same,
                    'gap_shift': gap_shift,
                    'level_shifts': level_shifts,
                    'level_shift_constant': level_shift_constant,
                    'first_shifted': first_shifted,
                    'deg_i': deg_i,
                    'deg_j': deg_j,
                    'dist_to_cut_i': dist_i,
                    'dist_to_cut_j': dist_j,
                    'gap_i': gap_i,
                    'gap_j': gap_j,
                    'level_shifts_mean': level_shifts
                })
    
    print(f"能隙例外总数：{len(results)}\n")
    
    # 统计
    n_E0_same = sum(1 for r in results if r['E0_same'])
    n_gap_shift_constant = sum(1 for r in results if r['gap_shift'] is not None)
    
    print("===== 统计 =====")
    print(f"基态能量曲线相同：{n_E0_same}/{len(results)}")
    print(f"能隙偏移为常数：{n_gap_shift_constant}/{len(results)}")
    
    # 能隙偏移量分布
    gap_shifts = [r['gap_shift'] for r in results if r['gap_shift'] is not None]
    print(f"\n能隙偏移量列表（去重）：")
    from collections import Counter
    shift_counter = Counter(round(s, 4) for s in gap_shifts)
    for shift, count in sorted(shift_counter.items(), key=lambda x: -x[1]):
        print(f"  {shift}: {count} 对")
    
    # 分析能级偏移的结构
    print(f"\n===== 能级偏移结构 =====")
    for r in results[:10]:
        print(f"\n图{r['graph']} 边{r['edge_i']}({r['edges_i']}) vs 边{r['edge_j']}({r['edges_j']})")
        print(f"  能隙偏移: {r['gap_shift']:.6f}")
        print(f"  前8能级偏移: {[round(s, 4) for s in r['level_shifts']]}")
        print(f"  偏移常数的能级: {r['level_shift_constant']}")
        print(f"  第一个偏移的能级索引: {r['first_shifted']}")
        print(f"  边的度: i={r['deg_i']}, j={r['deg_j']}")
        print(f"  到割点距离: i={r['dist_to_cut_i']}, j={r['dist_to_cut_j']}")
    
    # 检查偏移量是否与图的某个特征有关
    print(f"\n===== 偏移量与图特征的关系 =====")
    for r in results:
        if r['gap_shift'] is not None:
            g = r['graph']
            # 用能隙偏移量除以某个整数，看是否有规律
            # 检查是否为1/2, 1/4, 或整数
            shift = r['gap_shift']
            # 检查是否为0.5的整数倍
            ratio_to_half = abs(shift) / 0.5
            is_half_multiple = abs(ratio_to_half - round(ratio_to_half)) < 1e-6
            print(f"图{g} 边{r['edge_i']} vs {r['edge_j']}: 偏移={shift:.4f}, "
                  f"是否为0.5倍数={is_half_multiple}, 比值={ratio_to_half:.4f}")
    
    output = {
        'n_exceptions': len(results),
        'n_E0_same': n_E0_same,
        'n_gap_shift_constant': n_gap_shift_constant,
        'gap_shifts': gap_shifts,
        'results': results,
        'note': '能隙偏移来源分析。'
    }
    with open('jingmai_why_gap_offset_source.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_gap_offset_source.json")

if __name__ == "__main__":
    main()