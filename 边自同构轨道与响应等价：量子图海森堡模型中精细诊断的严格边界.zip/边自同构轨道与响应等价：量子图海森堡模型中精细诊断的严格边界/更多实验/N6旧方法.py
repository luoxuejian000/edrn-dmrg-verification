#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
N=6 用 N=7 旧脚本的同样方法
- 完整 2^N 维希尔伯特空间
- 排序关联向量作诊断量
- 同 s 网格 [-1.5, 0.0] × 11
"""

import sys
import io
import json
import itertools
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from collections import Counter

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

I2 = np.eye(2, dtype=complex)
SX = np.array([[0, 1], [1, 0]], dtype=complex)
SY = np.array([[0, -1j], [1j, 0]], dtype=complex)
SZ = np.array([[1, 0], [0, -1]], dtype=complex)


def op_on_site(op, site, N):
    ops = [I2] * N
    ops[site] = op
    out = ops[0]
    for o in ops[1:]:
        out = np.kron(out, o)
    return out


def build_site_ops(N):
    return ([op_on_site(SX, i, N) for i in range(N)],
            [op_on_site(SY, i, N) for i in range(N)],
            [op_on_site(SZ, i, N) for i in range(N)])


def edge_matrix(i, j, SX_ops, SY_ops, SZ_ops):
    return SX_ops[i] @ SX_ops[j] + SY_ops[i] @ SY_ops[j] + SZ_ops[i] @ SZ_ops[j]


def ground_state_density(H, tol=1e-8):
    evals, evecs = eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < tol))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    return E0, rho, deg


def edge_correlations(rho, edges, SZ_ops):
    C = {}
    for (i, j) in edges:
        op = SZ_ops[i] @ SZ_ops[j]
        C[(i, j)] = float(np.real(np.trace(rho @ op)))
    return C


def compute_sorted_curve(G, defect_edge, s_vals, SX_ops, SY_ops, SZ_ops):
    N = G.number_of_nodes()
    edges = [tuple(sorted(e)) for e in G.edges()]
    H_edges = {e: edge_matrix(e[0], e[1], SX_ops, SY_ops, SZ_ops) for e in edges}
    H0 = sum(H_edges.values())
    M_defect = H_edges[defect_edge]
    curve = []
    for s in s_vals:
        H = H0 + (s - 1.0) * M_defect
        E0, rho, deg = ground_state_density(H)
        C = edge_correlations(rho, edges, SZ_ops)
        curve.append(tuple(np.round(sorted(C.values()), 12)))
    return curve


def find_automorphisms(G):
    nodes = list(G.nodes())
    adj = nx.to_numpy_array(G)
    perms = []
    for p in itertools.permutations(nodes):
        P = np.zeros((len(nodes), len(nodes)))
        for i, pi in enumerate(p):
            P[i, pi] = 1
        if np.allclose(P @ adj @ P.T, adj):
            perms.append(p)
    return perms


def find_edge_orbits(G):
    nodes = list(G.nodes())
    edges = [tuple(sorted(e)) for e in G.edges()]
    perms = find_automorphisms(G)
    orbit_id = {e: None for e in edges}
    oid = 0
    for e in edges:
        if orbit_id[e] is not None:
            continue
        orbit_id[e] = oid
        for p in perms:
            mapping = {nodes[i]: p[i] for i in range(len(nodes))}
            e2 = tuple(sorted((mapping[e[0]], mapping[e[1]])))
            if G.has_edge(*e2):
                orbit_id[e2] = oid
        oid += 1
    return orbit_id


def main():
    N = 6
    s_vals = np.linspace(-1.5, 0.0, 11)
    print("=" * 78)
    print(f"  N={N} 用 N=7 旧脚本的同样方法")
    print("=" * 78)
    print(f"  s: [{s_vals[0]:.2f}, {s_vals[-1]:.2f}], {len(s_vals)} 点")
    print(f"  希尔伯特空间: 完整 2^{N} = {2**N} 维")
    print(f"  诊断量: 排序关联向量")
    print()

    atlas = nx.graph_atlas_g()
    candidates = [G for G in atlas
                  if G.number_of_nodes() == N and nx.is_connected(G)]
    # 用 is_isomorphic 去重
    unique = []
    for G in candidates:
        if not any(nx.is_isomorphic(G, H) for H in unique):
            unique.append(G)
    graphs = unique
    print(f"  N={N} 非同构连通图总数: {len(graphs)}")
    print()

    SX_ops, SY_ops, SZ_ops = build_site_ops(N)

    diff_orbit_same_list = []

    for gid, G in enumerate(graphs):
        edges = [tuple(sorted(e)) for e in G.edges()]
        orbits = find_edge_orbits(G)
        curves = {}
        for e in edges:
            curves[e] = compute_sorted_curve(G, e, s_vals,
                                             SX_ops, SY_ops, SZ_ops)
        for i, e1 in enumerate(edges):
            for j in range(i + 1, len(edges)):
                e2 = edges[j]
                if orbits[e1] == orbits[e2]:
                    continue
                same = all(
                    len(a) == len(b) and np.allclose(a, b, atol=1e-10)
                    for a, b in zip(curves[e1], curves[e2])
                )
                if same:
                    diff_orbit_same_list.append({
                        "gid": gid,
                        "e1": list(e1),
                        "e2": list(e2),
                    })
        if (gid + 1) % 20 == 0:
            print(f"    已处理 {gid + 1}/{len(graphs)} 图")

    print()
    print(f"  异轨道同响应总数: {len(diff_orbit_same_list)}")
    print()
    gid_counter = Counter(p["gid"] for p in diff_orbit_same_list)
    print(f"  涉及图数: {len(gid_counter)}")
    print()
    print(f"  {'图号':<8}{'对数':<8}")
    print(f"  {'-'*8}{'-'*8}")
    for gid, count in gid_counter.most_common(20):
        print(f"  {gid:<8}{count:<8}")
    print()

    output = {
        "N": N,
        "s_grid": list(s_vals),
        "total_diff_orbit_same": len(diff_orbit_same_list),
        "gid_distribution": dict(gid_counter),
        "pairs": diff_orbit_same_list,
    }
    with open(f"N{N}_旧方法结果.json", "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2, default=str)
    print(f"已保存: N{N}_旧方法结果.json")


if __name__ == "__main__":
    main()