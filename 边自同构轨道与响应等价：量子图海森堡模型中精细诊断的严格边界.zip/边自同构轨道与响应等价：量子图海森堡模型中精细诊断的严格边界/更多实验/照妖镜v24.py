#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 v24.0：对称不变子集条件在全部异轨道对上的分布
================================================================

v23 的 bug：
  只加载了 47 对同响应，没有加载 2684 对异响应。
  所以无法回答"对称不变子集是否充分"。

v24 修复：
  对全部 2731 对异轨道对（47 同响应 + 2684 异响应），
  计算对称不变子集大小，并排比较。
"""

import sys, io, itertools, json, os
import numpy as np
import networkx as nx
from collections import Counter, defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"


def build_atlas_graphs(N):
    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    return graphs


def edge_orbits(G):
    edges = [tuple(sorted(e)) for e in G.edges()]
    GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
    autos = list(GM.isomorphisms_iter())
    orbits = {}
    for e in edges:
        orbit = frozenset(frozenset({a[e[0]], a[e[1]]}) for a in autos)
        orbits[e] = orbit
    return orbits


def load_v51_patterns():
    with open(os.path.join(WORK_DIR, "照妖镜_v5_1_模式.json"), "r",
              encoding="utf-8") as f:
        v51 = json.load(f)
    patterns = {}
    for key, s in v51["patterns"].items():
        gid, e1_str, e2_str = key.split("_", 2)
        gid = int(gid)
        e1 = tuple(map(int, e1_str.strip("()").split(",")))
        e2 = tuple(map(int, e2_str.strip("()").split(",")))
        patterns[(gid, tuple(sorted(e1)), tuple(sorted(e2)))] = s
    return patterns


def find_symmetric_subset(G, e1, e2, autos):
    """包含 e1, e2 的最小对称不变子集"""
    current = set(e1) | set(e2)
    changed = True
    while changed:
        changed = False
        for a in autos:
            for n in list(current):
                if a[n] not in current:
                    current.add(a[n])
                    changed = True
    is_inv = any(all(a[n] in current for n in current) for a in autos)
    return sorted(current), is_inv


def main():
    print("=" * 100)
    print("照妖镜 v24.0：对称不变子集条件在全部异轨道对上的分布")
    print("=" * 100)

    N = 6
    graphs = build_atlas_graphs(N)
    patterns = load_v51_patterns()
    print(f"\n  N={N} 图集: {len(graphs)} 图")
    print(f"  已知同响应对: {len(patterns)}")

    # 对全部 2731 对异轨道对计算
    print(f"\n  扫描全部异轨道对...")
    all_pairs = []
    for gid, G in enumerate(graphs):
        if gid % 30 == 0:
            print(f"    {gid}/{len(graphs)}")
        edges = [tuple(sorted(e)) for e in G.edges()]
        orbits = edge_orbits(G)
        # 缓存自同构
        GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
        autos = list(GM.isomorphisms_iter())

        for i in range(len(edges)):
            for j in range(i + 1, len(edges)):
                e1, e2 = edges[i], edges[j]
                if orbits[e1] == orbits[e2]:
                    continue
                # 已知 pattern
                key = (gid, e1, e2)
                if key in patterns:
                    n_true = patterns[key].count("1")
                else:
                    n_true = 0
                # 对称不变子集
                subset, is_inv = find_symmetric_subset(G, e1, e2, autos)
                all_pairs.append({
                    "gid": gid, "e1": e1, "e2": e2,
                    "n_true": n_true,
                    "subset_size": len(subset),
                    "is_invariant": is_inv,
                })

    print(f"\n  总异轨道对数: {len(all_pairs)}")
    n_same = sum(1 for p in all_pairs if p["n_true"] > 0)
    n_diff = len(all_pairs) - n_same
    print(f"  同响应: {n_same}")
    print(f"  异响应: {n_diff}")

    # ============================================================
    # Q1: 全部对的对称子集大小分布
    # ============================================================
    print("\n" + "=" * 100)
    print("Q1. 全部异轨道对的对称子集大小分布")
    print("=" * 100)

    print(f"\n  {'subset 大小':>12} | {'总数':>6} | {'同响应':>6} | {'异响应':>6} | {'同响应比例':>10}")
    print(f"  {'-'*12}-+-{'-'*6}-+-{'-'*6}-+-{'-'*6}-+-{'-'*10}")
    by_size = defaultdict(lambda: {"same": 0, "diff": 0})
    for p in all_pairs:
        by_size[p["subset_size"]]["same" if p["n_true"] > 0 else "diff"] += 1

    for sz in sorted(by_size.keys()):
        d = by_size[sz]
        total = d["same"] + d["diff"]
        rate = d["same"] / total if total > 0 else 0
        print(f"  {sz:>12} | {total:>6} | {d['same']:>6} | {d['diff']:>6} | {rate:>10.1%}")

    # ============================================================
    # Q2: 对称不变 vs 非对称不变
    # ============================================================
    print("\n" + "=" * 100)
    print("Q2. 对称不变 vs 非对称不变")
    print("=" * 100)

    inv_pairs = [p for p in all_pairs if p["is_invariant"]]
    non_inv_pairs = [p for p in all_pairs if not p["is_invariant"]]
    print(f"\n  对称不变的对: {len(inv_pairs)}/{len(all_pairs)} = {len(inv_pairs)/len(all_pairs):.1%}")
    print(f"  非对称不变的对: {len(non_inv_pairs)}/{len(all_pairs)} = {len(non_inv_pairs)/len(all_pairs):.1%}")

    n_inv_same = sum(1 for p in inv_pairs if p["n_true"] > 0)
    n_non_inv_same = sum(1 for p in non_inv_pairs if p["n_true"] > 0)
    print(f"\n  对称不变的对中:")
    print(f"    同响应: {n_inv_same}/{len(inv_pairs)} = {n_inv_same/len(inv_pairs):.1%}")
    print(f"    异响应: {len(inv_pairs) - n_inv_same}/{len(inv_pairs)}")
    print(f"\n  非对称不变的对中:")
    print(f"    同响应: {n_non_inv_same}/{len(non_inv_pairs)} = {n_non_inv_same/len(non_inv_pairs):.1%}")
    print(f"    异响应: {len(non_inv_pairs) - n_non_inv_same}/{len(non_inv_pairs)}")

    # ============================================================
    # Q3: 子集大小作为筛选器
    # ============================================================
    print("\n" + "=" * 100)
    print("Q3. 子集大小作为筛选器")
    print("=" * 100)

    print(f"\n  {'条件':>30} | {'候选数':>6} | {'命中同响应':>10} | {'精确率':>8} | {'召回率':>8}")
    print(f"  {'-'*30}-+-{'-'*6}-+-{'-'*10}-+-{'-'*8}-+-{'-'*8}")

    conditions = [
        ("全部异轨道对", lambda p: True),
        ("对称不变", lambda p: p["is_invariant"]),
        ("对称不变 & size=3", lambda p: p["is_invariant"] and p["subset_size"] == 3),
        ("对称不变 & size=3,4", lambda p: p["is_invariant"] and p["subset_size"] in (3, 4)),
        ("对称不变 & size=3,4,5", lambda p: p["is_invariant"] and p["subset_size"] in (3, 4, 5)),
        ("对称不变 & size=3,4,5,6", lambda p: p["is_invariant"] and p["subset_size"] in (3, 4, 5, 6)),
    ]

    for name, cond in conditions:
        subset = [p for p in all_pairs if cond(p)]
        n_hit = sum(1 for p in subset if p["n_true"] > 0)
        precision = n_hit / len(subset) if len(subset) > 0 else 0
        recall = n_hit / n_same if n_same > 0 else 0
        print(f"  {name:>30} | {len(subset):>6} | {n_hit:>10} | "
              f"{precision:>7.1%} | {recall:>7.1%}")

    # ============================================================
    # Q4: 核心 24 对在全部对中的位置
    # ============================================================
    print("\n" + "=" * 100)
    print("Q4. 核心 24 对在全部对中的位置")
    print("=" * 100)

    core_pairs = [p for p in all_pairs if p["n_true"] == 24]
    print(f"\n  核心对: {len(core_pairs)}")
    print(f"  核心对 subset 大小: {Counter(p['subset_size'] for p in core_pairs)}")

    # 核心对占 size=3,4 的比例
    sz34 = [p for p in all_pairs if p["is_invariant"] and p["subset_size"] in (3, 4)]
    n_core_in_sz34 = sum(1 for p in sz34 if p["n_true"] == 24)
    print(f"  对称不变且 size ∈ {{3,4}} 的对: {len(sz34)}")
    print(f"  其中核心对: {n_core_in_sz34}")
    print(f"  核心对在该子集的占比: {n_core_in_sz34/len(sz34):.1%}")

    # ============================================================
    # Q5: 不同 size 的异构分布
    # ============================================================
    print("\n" + "=" * 100)
    print("Q5. 同响应 vs 异响应的子集大小分布对比")
    print("=" * 100)

    print(f"\n  {'size':>6} | {'同响应数':>8} | {'异响应数':>8} | {'同响应占比':>10}")
    print(f"  {'-'*6}-+-{'-'*8}-+-{'-'*8}-+-{'-'*10}")
    for sz in sorted(by_size.keys()):
        d = by_size[sz]
        total = d["same"] + d["diff"]
        print(f"  {sz:>6} | {d['same']:>8} | {d['diff']:>8} | "
              f"{d['same']/total:>10.1%}" if total > 0 else f"  {sz:>6} | 0 | 0 | -")

    # ============================================================
    # 导出
    # ============================================================
    out = {
        "n_total": len(all_pairs),
        "n_same": n_same,
        "n_diff": n_diff,
        "n_inv": len(inv_pairs),
        "n_inv_same": n_inv_same,
        "n_non_inv": len(non_inv_pairs),
        "n_non_inv_same": n_non_inv_same,
        "by_size": {str(k): dict(v) for k, v in by_size.items()},
    }
    out_path = os.path.join(WORK_DIR, "照妖镜_v24_全部对.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("v24.0 完成。")
    print("=" * 100)


if __name__ == "__main__":
    main()