#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 v25.0：核心层的穷举条件攻击
================================================================

目标：
  对全部 2731 对异轨道对，穷举计算所有可能的判别条件，
  找出能把 24 核心对从 2684 异响应对中分出来的任何条件。

四个层次并行：
  层次 1：图论条件穷举（20+ 特征）
  层次 2：量子条件穷举（p_S 曲线 + 简并结构）
  层次 3：图论 + 量子联合条件
  层次 4：核心层 24 对的特殊结构（不只看判别，看结构本身）

原则：
  · 不预设条件
  · 每个条件都并排输出（候选数、命中数、精确率、召回率）
  · 接受"没有条件成立"作为结果
"""

import sys, io, itertools, json, os
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from collections import Counter, defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"


# ============================================================
# 图集
# ============================================================

def build_atlas_graphs(N):
    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    return graphs


def edge_orbits(G):
    edges = [tuple(sorted(e)) for e in G.edges()]
    GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
    autos = list(GM.isomorphisms_iter())
    orbits = {}
    for e in edges:
        orbit = frozenset(frozenset({a[e[0]], a[e[1]]}) for a in autos)
        orbits[e] = orbit
    return orbits


def load_v51_patterns():
    with open(os.path.join(WORK_DIR, "照妖镜_v5_1_模式.json"), "r",
              encoding="utf-8") as f:
        v51 = json.load(f)
    patterns = {}
    for key, s in v51["patterns"].items():
        gid, e1_str, e2_str = key.split("_", 2)
        gid = int(gid)
        e1 = tuple(map(int, e1_str.strip("()").split(",")))
        e2 = tuple(map(int, e2_str.strip("()").split(",")))
        patterns[(gid, tuple(sorted(e1)), tuple(sorted(e2)))] = s
    return patterns


# ============================================================
# 层次 1：图论特征穷举
# ============================================================

def graph_features(G, e1, e2, orbits):
    """计算一对边的全部图论特征"""
    n1a, n1b = e1
    n2a, n2b = e2
    s1, s2 = {n1a, n1b}, {n2a, n2b}

    # 端点特征
    deg1 = tuple(sorted([G.degree(n1a), G.degree(n1b)]))
    deg2 = tuple(sorted([G.degree(n2a), G.degree(n2b)]))

    # 邻域
    neigh1 = set(G.neighbors(n1a)) | set(G.neighbors(n1b))
    neigh2 = set(G.neighbors(n2a)) | set(G.neighbors(n2b))
    common_neigh = neigh1 & neigh2
    union_neigh = neigh1 | neigh2

    # 桥
    try:
        bridges = set(map(frozenset, nx.bridges(G)))
        is_bridge_1 = frozenset(e1) in bridges
        is_bridge_2 = frozenset(e2) in bridges
    except Exception:
        is_bridge_1 = is_bridge_2 = False

    # 三角形
    tri_1 = sum(1 for _ in nx.common_neighbors(G, n1a, n1b))
    tri_2 = sum(1 for _ in nx.common_neighbors(G, n2a, n2b))

    # k-core
    core = nx.core_number(G)
    kcore_1 = min(core[n1a], core[n1b])
    kcore_2 = min(core[n2a], core[n2b])

    # 边距
    try:
        d_aa = nx.shortest_path_length(G, n1a, n2a)
    except Exception:
        d_aa = -1

    # 收缩度序列
    try:
        G1 = nx.contracted_edge(G, e1, self_loops=False)
        ds1 = tuple(sorted(d for _, d in G1.degree()))
    except Exception:
        ds1 = ()
    try:
        G2 = nx.contracted_edge(G, e2, self_loops=False)
        ds2 = tuple(sorted(d for _, d in G2.degree()))
    except Exception:
        ds2 = ()

    # 缺陷边子图：两条边合起来覆盖的节点集
    combined_nodes = s1 | s2
    sub = G.subgraph(combined_nodes)
    sub_edges = set(tuple(sorted(e)) for e in sub.edges())
    e1_in_sub = tuple(sorted(e1)) in sub_edges
    e2_in_sub = tuple(sorted(e2)) in sub_edges
    # 两条边的合取子图边数
    combined_edges = len(sub_edges)

    return {
        "share_endpoint": len(s1 & s2) > 0,
        "deg_pair_equal": deg1 == deg2,
        "deg_sum_equal": sum(deg1) == sum(deg2),
        "common_neighbors": len(common_neigh),
        "neighbor_union": len(union_neigh),
        "jaccard": len(common_neigh) / len(union_neigh) if union_neigh else 0,
        "both_not_bridge": not is_bridge_1 and not is_bridge_2,
        "tri_equal": tri_1 == tri_2,
        "tri_sum": tri_1 + tri_2,
        "kcore_equal": kcore_1 == kcore_2,
        "edge_distance": d_aa,
        "contract_deg_equal": ds1 == ds2 and len(ds1) > 0,
        "orbit_sizes_equal": len(orbits[e1]) == len(orbits[e2]),
        "combined_nodes": len(combined_nodes),
        "combined_edges": combined_edges,
        "combined_density": combined_edges / (len(combined_nodes) * (len(combined_nodes) - 1) / 2) if len(combined_nodes) > 1 else 0,
        "combined_is_K4": combined_edges == 6 and len(combined_nodes) == 4,
        "combined_is_K4_minus": len(combined_nodes) == 4 and combined_edges in (4, 5),
        "combined_is_C4": len(combined_nodes) == 4 and combined_edges == 4,
    }


# ============================================================
# 层次 2：量子特征
# ============================================================

def build_sz0_sector(N):
    n_up = N // 2
    basis = []
    for comb in itertools.combinations(range(N), n_up):
        state = [0]*N
        for i in comb: state[i] = 1
        basis.append(tuple(state))
    dim = len(basis)
    idx = {s: i for i, s in enumerate(basis)}
    SZ_ops = []
    for site in range(N):
        SZ = np.zeros((dim, dim), dtype=complex)
        for i, state in enumerate(basis):
            SZ[i, i] = 1 if state[site] == 1 else -1
        SZ_ops.append(SZ)
    return basis, idx, SZ_ops


def build_edge_op(i, j, basis, idx):
    dim = len(basis)
    op = np.zeros((dim, dim), dtype=complex)
    for a_idx, state_a in enumerate(basis):
        sa, sb = state_a[i], state_a[j]
        if sa == sb:
            op[a_idx, a_idx] += 1
        else:
            op[a_idx, a_idx] += -1
            new_state = list(state_a)
            new_state[i], new_state[j] = new_state[j], new_state[i]
            b_idx = idx.get(tuple(new_state))
            if b_idx is not None:
                op[b_idx, a_idx] += 2
    return op


def pS_curve(edge_ops, defect, s_grid, SZ_ops, ref_dim):
    """在 s_grid 上计算 p_S"""
    curve = []
    for s in s_grid:
        H = np.zeros((ref_dim, ref_dim), dtype=complex)
        for e, M in edge_ops.items():
            c = s if e == defect else 1.0
            H += c * M
        try:
            evals, evecs = eigh(H)
        except Exception:
            curve.append(np.nan)
            continue
        E0 = evals[0]
        deg = int(np.sum(np.abs(evals - E0) < 1e-8))
        V = evecs[:, :deg]
        rho = V @ V.conj().T / deg
        i, j = defect
        szsz_diag = np.diag(SZ_ops[i] @ SZ_ops[j])
        szsz = float(np.real(np.sum(np.diag(rho) * szsz_diag)))
        p_S = (1 - 3 * szsz) / 4
        curve.append(p_S)
    return np.array(curve)


def quantum_features(c1, c2, s_grid):
    """比较两条 p_S 曲线"""
    if len(c1) != len(c2):
        return {}
    diff = np.abs(c1 - c2)
    return {
        "pS_max_diff": float(np.nanmax(diff)),
        "pS_mean_diff": float(np.nanmean(diff)),
        "pS_diff_at_0": float(abs(c1[np.argmin(np.abs(s_grid - 0.0))] - c2[np.argmin(np.abs(s_grid - 0.0))])),
        "pS_diff_at_05": float(abs(c1[np.argmin(np.abs(s_grid - 0.5))] - c2[np.argmin(np.abs(s_grid - 0.5))])),
        "pS_curves_equal": bool(np.nanmax(diff) < 1e-10),
        "pS_both_flat_neg": bool(np.nanstd(c1[s_grid <= 0.5]) < 1e-4 and np.nanstd(c2[s_grid <= 0.5]) < 1e-4),
    }


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 100)
    print("照妖镜 v25.0：核心层的穷举条件攻击")
    print("=" * 100)

    N = 6
    graphs = build_atlas_graphs(N)
    patterns = load_v51_patterns()
    print(f"\n  N={N} 图集: {len(graphs)} 图")
    print(f"  已知同响应对: {len(patterns)}")

    basis, idx, SZ_ops = build_sz0_sector(N)
    ref_dim = len(basis)
    print(f"  S_z=0 维度: {ref_dim}")

    # 精细 s 网格
    s_grid = np.linspace(-1.0, 1.0, 41)

    # 收集所有异轨道对
    print(f"\n  扫描全部异轨道对...")
    all_pairs = []
    for gid, G in enumerate(graphs):
        if gid % 30 == 0:
            print(f"    {gid}/{len(graphs)}")
        edges = [tuple(sorted(e)) for e in G.edges()]
        orbits = edge_orbits(G)
        edge_ops = {e: build_edge_op(e[0], e[1], basis, idx) for e in edges}

        # 缓存每条边的 p_S 曲线
        pS_cache = {e: pS_curve(edge_ops, e, s_grid, SZ_ops, ref_dim) for e in edges}

        for i in range(len(edges)):
            for j in range(i + 1, len(edges)):
                e1, e2 = edges[i], edges[j]
                if orbits[e1] == orbits[e2]:
                    continue
                key = (gid, e1, e2)
                if key in patterns:
                    n_true = patterns[key].count("1")
                else:
                    n_true = 0
                # 图论特征
                gf = graph_features(G, e1, e2, orbits)
                # 量子特征
                qf = quantum_features(pS_cache[e1], pS_cache[e2], s_grid)
                all_pairs.append({
                    "gid": gid, "e1": e1, "e2": e2,
                    "n_true": n_true,
                    **gf, **qf,
                })

    print(f"\n  总对数: {len(all_pairs)}")
    n_same = sum(1 for p in all_pairs if p["n_true"] > 0)
    n_core = sum(1 for p in all_pairs if p["n_true"] == 24)
    n_middle = sum(1 for p in all_pairs if 1 < p["n_true"] < 24)
    n_outer = sum(1 for p in all_pairs if p["n_true"] == 1)
    n_diff = sum(1 for p in all_pairs if p["n_true"] == 0)
    print(f"  同响应: {n_same} (核心 {n_core}, 中环 {n_middle}, 外壳 {n_outer})")
    print(f"  异响应: {n_diff}")

    # ============================================================
    # Q1: 穷举图论条件
    # ============================================================
    print("\n" + "=" * 100)
    print("Q1. 穷举图论条件：能否区分 24 核心对？")
    print("=" * 100)

    # 所有可以数值化的图论条件
    gnn_conditions = []

    # 布尔条件
    for name in ["share_endpoint", "deg_pair_equal", "deg_sum_equal",
                 "both_not_bridge", "tri_equal", "kcore_equal",
                 "contract_deg_equal", "orbit_sizes_equal",
                 "combined_is_K4", "combined_is_K4_minus", "combined_is_C4"]:
        gnn_conditions.append((name, lambda p, n=name: p.get(n, False)))

    # 数值条件（阈值化）
    gnn_conditions += [
        ("common_neighbors >= 4", lambda p: p["common_neighbors"] >= 4),
        ("common_neighbors >= 5", lambda p: p["common_neighbors"] >= 5),
        ("jaccard >= 0.6", lambda p: p["jaccard"] >= 0.6),
        ("jaccard >= 0.8", lambda p: p["jaccard"] >= 0.8),
        ("edge_distance == 1", lambda p: p["edge_distance"] == 1),
        ("edge_distance <= 2", lambda p: p["edge_distance"] <= 2),
        ("combined_nodes == 4", lambda p: p["combined_nodes"] == 4),
        ("combined_nodes == 4 & edges >= 4", lambda p: p["combined_nodes"] == 4 and p["combined_edges"] >= 4),
        ("combined_density >= 0.5", lambda p: p["combined_density"] >= 0.5),
    ]

    # 并排输出
    print(f"\n  {'条件':<35} | {'候选数':>6} | {'命中核心':>8} | {'核心精度':>8} | {'核心召回':>8}")
    print(f"  {'-'*35}-+-{'-'*6}-+-{'-'*8}-+-{'-'*8}-+-{'-'*8}")

    for name, cond in gnn_conditions:
        subset = [p for p in all_pairs if cond(p)]
        n_hit_core = sum(1 for p in subset if p["n_true"] == 24)
        precision = n_hit_core / len(subset) if len(subset) > 0 else 0
        recall = n_hit_core / n_core if n_core > 0 else 0
        print(f"  {name:<35} | {len(subset):>6} | {n_hit_core:>8} | "
              f"{precision:>7.1%} | {recall:>7.1%}")

    # ============================================================
    # Q2: 穷举量子条件
    # ============================================================
    print("\n" + "=" * 100)
    print("Q2. 穷举量子条件：能否区分 24 核心对？")
    print("=" * 100)

    quantum_conditions = [
        ("pS_curves_equal", lambda p: p.get("pS_curves_equal", False)),
        ("pS_max_diff < 1e-6", lambda p: p.get("pS_max_diff", 1) < 1e-6),
        ("pS_max_diff < 1e-4", lambda p: p.get("pS_max_diff", 1) < 1e-4),
        ("pS_diff_at_0 < 1e-6", lambda p: p.get("pS_diff_at_0", 1) < 1e-6),
        ("pS_diff_at_05 < 1e-6", lambda p: p.get("pS_diff_at_05", 1) < 1e-6),
        ("pS_both_flat_neg", lambda p: p.get("pS_both_flat_neg", False)),
    ]

    print(f"\n  {'条件':<35} | {'候选数':>6} | {'命中核心':>8} | {'核心精度':>8} | {'核心召回':>8}")
    print(f"  {'-'*35}-+-{'-'*6}-+-{'-'*8}-+-{'-'*8}-+-{'-'*8}")
    for name, cond in quantum_conditions:
        subset = [p for p in all_pairs if cond(p)]
        n_hit_core = sum(1 for p in subset if p["n_true"] == 24)
        precision = n_hit_core / len(subset) if len(subset) > 0 else 0
        recall = n_hit_core / n_core if n_core > 0 else 0
        print(f"  {name:<35} | {len(subset):>6} | {n_hit_core:>8} | "
              f"{precision:>7.1%} | {recall:>7.1%}")

    # ============================================================
    # Q3: 图论 + 量子联合条件
    # ============================================================
    print("\n" + "=" * 100)
    print("Q3. 图论 + 量子联合条件")
    print("=" * 100)

    combined_conditions = [
        ("share_endpoint & pS_curves_equal", lambda p: p["share_endpoint"] and p.get("pS_curves_equal", False)),
        ("common_neigh >= 4 & pS_curves_equal", lambda p: p["common_neighbors"] >= 4 and p.get("pS_curves_equal", False)),
        ("combined_K4 & pS_curves_equal", lambda p: p.get("combined_is_K4", False) and p.get("pS_curves_equal", False)),
        ("combined_nodes=4 & pS_curves_equal", lambda p: p["combined_nodes"] == 4 and p.get("pS_curves_equal", False)),
        ("combined_nodes=4 & edges>=4 & pS_curves_equal", lambda p: p["combined_nodes"] == 4 and p["combined_edges"] >= 4 and p.get("pS_curves_equal", False)),
        ("edge_dist <= 2 & pS_curves_equal", lambda p: p["edge_distance"] <= 2 and p.get("pS_curves_equal", False)),
        ("both_not_bridge & pS_curves_equal", lambda p: p["both_not_bridge"] and p.get("pS_curves_equal", False)),
    ]

    print(f"\n  {'条件':<45} | {'候选数':>6} | {'命中核心':>8} | {'核心精度':>8} | {'核心召回':>8}")
    print(f"  {'-'*45}-+-{'-'*6}-+-{'-'*8}-+-{'-'*8}-+-{'-'*8}")
    for name, cond in combined_conditions:
        subset = [p for p in all_pairs if cond(p)]
        n_hit_core = sum(1 for p in subset if p["n_true"] == 24)
        precision = n_hit_core / len(subset) if len(subset) > 0 else 0
        recall = n_hit_core / n_core if n_core > 0 else 0
        print(f"  {name:<45} | {len(subset):>6} | {n_hit_core:>8} | "
              f"{precision:>7.1%} | {recall:>7.1%}")

    # ============================================================
    # Q4: 核心 24 对的特殊结构
    # ============================================================
    print("\n" + "=" * 100)
    print("Q4. 核心 24 对的特殊结构")
    print("=" * 100)

    core_pairs = [p for p in all_pairs if p["n_true"] == 24]
    print(f"\n  核心对: {len(core_pairs)}")

    # 核心对的图论特征分布
    print(f"\n  核心对的图论特征分布:")
    for name in ["share_endpoint", "deg_pair_equal", "both_not_bridge",
                 "tri_equal", "kcore_equal", "contract_deg_equal",
                 "combined_is_K4", "combined_is_K4_minus", "combined_is_C4"]:
        cnt = Counter(p.get(name, False) for p in core_pairs)
        print(f"    {name:<25}: {dict(cnt)}")

    # 核心对的数值特征
    print(f"\n  核心对的数值特征:")
    for name in ["common_neighbors", "jaccard", "edge_distance",
                 "combined_nodes", "combined_edges", "combined_density"]:
        vals = [p.get(name, 0) for p in core_pairs]
        print(f"    {name:<25}: min={min(vals):.2f}, max={max(vals):.2f}, "
              f"mean={np.mean(vals):.2f}")

    # ============================================================
    # Q5: 最接近的判别器
    # ============================================================
    print("\n" + "=" * 100)
    print("Q5. 最接近的判别器（按核心精度排序）")
    print("=" * 100)

    all_conditions = gnn_conditions + quantum_conditions + combined_conditions
    results = []
    for name, cond in all_conditions:
        subset = [p for p in all_pairs if cond(p)]
        if not subset:
            continue
        n_hit_core = sum(1 for p in subset if p["n_true"] == 24)
        precision = n_hit_core / len(subset)
        recall = n_hit_core / n_core if n_core > 0 else 0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
        results.append((name, len(subset), n_hit_core, precision, recall, f1))

    results.sort(key=lambda x: -x[5])  # 按 F1 排序

    print(f"\n  {'条件':<45} | {'候选数':>6} | {'命中':>5} | {'精度':>6} | {'召回':>6} | {'F1':>6}")
    print(f"  {'-'*45}-+-{'-'*6}-+-{'-'*5}-+-{'-'*6}-+-{'-'*6}-+-{'-'*6}")
    for name, n_cand, n_hit, prec, rec, f1 in results[:20]:
        print(f"  {name:<45} | {n_cand:>6} | {n_hit:>5} | {prec:>5.1%} | "
              f"{rec:>5.1%} | {f1:>5.1%}")

    # ============================================================
    # 导出
    # ============================================================
    out = {
        "n_total": len(all_pairs),
        "n_core": n_core, "n_middle": n_middle, "n_outer": n_outer, "n_diff": n_diff,
        "top_conditions": [
            {"name": n, "n_candidates": nc, "n_core_hit": nh,
             "precision": p, "recall": r, "f1": f}
            for n, nc, nh, p, r, f in results[:30]
        ],
    }
    out_path = os.path.join(WORK_DIR, "照妖镜_v25_穷举条件.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("v25.0 完成。核心层的穷举条件攻击完成。")
    print("=" * 100)


if __name__ == "__main__":
    main()