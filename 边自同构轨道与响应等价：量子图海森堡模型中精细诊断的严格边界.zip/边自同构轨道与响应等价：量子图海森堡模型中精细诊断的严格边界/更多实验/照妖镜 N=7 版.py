# -*- coding: utf-8 -*-
"""
================================================================================
照妖镜 N=7 版
用同样的方法查 N=7 的 382 对异轨道同响应

与 N=6 v3.0 保持同构：
  1. 同一套关系特征提取
  2. 同一套 S_GRID 扫描
  3. 同一套 DNA 提取
  4. 最后与 N=6 的 28 对并排比较

晶脉哲学：
  · 关系本体论：只看关系位置
  · 对象化=截断=产生方向：每个窗口显式标注
  · 只查同与不同：不拟合，不回归
  · 反对对齐：不预设"382 是对的"
================================================================================
"""

import os
import json
import warnings
from collections import Counter, defaultdict
from itertools import combinations

import numpy as np
import networkx as nx

warnings.filterwarnings('ignore')

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"
N_NODES = 7
TOL = 1e-10
TARGET_N7 = 382

# ============================================================
# 基础
# ============================================================

def fmt(x, nd=10):
    if isinstance(x, (bool, np.bool_)):
        return "True" if x else "False"
    if isinstance(x, (int, np.integer)):
        return str(int(x))
    if isinstance(x, (float, np.floating)):
        if np.isnan(x):
            return "nan"
        if abs(x) < 1e-14:
            return "0"
        return f"{x:.{nd}f}"
    return str(x)


def build_all_N7_graphs():
    """networkx 的 atlas 已按同构类去重，直接过滤即可"""
    graphs = []
    for G in nx.graph_atlas_g():
        if G.number_of_nodes() == N_NODES and nx.is_connected(G):
            graphs.append(nx.convert_node_labels_to_integers(G))
    return graphs


def build_adj_list(G):
    nodes = sorted(G.nodes())
    node_idx = {n: i for i, n in enumerate(nodes)}
    edges = sorted([tuple(sorted((node_idx[a], node_idx[b])))
                    for a, b in G.edges()])
    return edges


def sz0_basis(N):
    """对奇数 N，用 S_z = -1/2 子空间（与 +1/2 等价）"""
    n_up = N // 2
    basis = []
    for comb in combinations(range(N), n_up):
        state = [0] * N
        for i in comb:
            state[i] = 1
        basis.append(tuple(state))
    return basis


def build_edge_matrices(N, edges):
    """预计算每条边的贡献矩阵 M_e"""
    basis = sz0_basis(N)
    dim = len(basis)
    idx = {s: i for i, s in enumerate(basis)}
    Ms = []
    for (a, b) in edges:
        M = np.zeros((dim, dim))
        for i, state in enumerate(basis):
            if state[a] == state[b]:
                M[i, i] += 1.0
            else:
                M[i, i] -= 1.0
                new_state = list(state)
                new_state[a], new_state[b] = new_state[b], new_state[a]
                M[i, idx[tuple(new_state)]] += 2.0
        Ms.append(M)
    H0 = sum(Ms)
    return H0, Ms, basis


def edge_orbits(G, edges):
    GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
    autos = list(GM.isomorphisms_iter())
    orbits = {}
    for e in edges:
        orbit = set()
        for auto in autos:
            mapped = frozenset({auto[e[0]], auto[e[1]]})
            orbit.add(mapped)
        orbits[e] = frozenset(orbit)
    uniq = {}
    out = {}
    for e in edges:
        o = orbits[e]
        if o not in uniq:
            uniq[o] = len(uniq)
        out[e] = uniq[o]
    return out


def compute_E_curve_fast(N, edges, defect_idx, s_grid, H0, Ms, basis):
    """用预计算矩阵快速算 E(s)"""
    dim = len(basis)
    sz_config = np.array([[1.0 if state[i] == 1 else -1.0
                           for i in range(N)] for state in basis])
    curves = []
    M_defect = Ms[defect_idx]
    for s in s_grid:
        H = H0 + (s - 1.0) * M_defect
        try:
            vals, vecs = np.linalg.eigh(H)
        except Exception:
            curves.append(np.nan)
            continue
        E0 = vals[0]
        degen = np.where(np.abs(vals - E0) < 1e-8)[0]
        rho = np.zeros((dim, dim))
        for k in degen:
            v = vecs[:, k].reshape(-1, 1)
            rho += v @ v.conj().T
        rho /= len(degen)
        rho_diag = np.diag(rho).real
        corr = []
        for (a, b) in edges:
            val = float(np.sum(rho_diag * sz_config[:, a] * sz_config[:, b]))
            corr.append(val)
        curves.append(float(np.std(corr)))
    return np.array(curves)


# ============================================================
# DNA 提取（与 N=6 v3 一致）
# ============================================================

def extract_pair_features(G, e1, e2, orbits):
    n1a, n1b = e1
    n2a, n2b = e2
    s1 = {n1a, n1b}
    s2 = {n2a, n2b}
    inter = (set(G.neighbors(n1a)) | set(G.neighbors(n1b))) & \
            (set(G.neighbors(n2a)) | set(G.neighbors(n2b)))
    union = (set(G.neighbors(n1a)) | set(G.neighbors(n1b))) | \
            (set(G.neighbors(n2a)) | set(G.neighbors(n2b)))
    try:
        dist = nx.shortest_path_length(G, n1a, n2a)
    except Exception:
        dist = -1
    orbit_size = Counter(orbits.values())
    bridges = set(map(frozenset, nx.bridges(G)))
    try:
        L = nx.laplacian_matrix(G).astype(float).toarray()
        Lpinv = np.linalg.pinv(L)
        def eff_res(u, v):
            return float(Lpinv[u, u] + Lpinv[v, v] - 2 * Lpinv[u, v])
        er1, er2 = eff_res(*e1), eff_res(*e2)
    except Exception:
        er1 = er2 = np.nan
    return {
        "share_endpoint": len(s1 & s2) > 0,
        "edge_distance": dist,
        "common_neighbors": len(inter),
        "neighbor_union": len(union),
        "neighbor_jaccard": len(inter) / len(union) if union else 0.0,
        "degree_pair_1": tuple(sorted([G.degree(n1a), G.degree(n1b)])),
        "degree_pair_2": tuple(sorted([G.degree(n2a), G.degree(n2b)])),
        "degree_sum_1": G.degree(n1a) + G.degree(n1b),
        "degree_sum_2": G.degree(n2a) + G.degree(n2b),
        "orbit_size_1": orbit_size[orbits[e1]],
        "orbit_size_2": orbit_size[orbits[e2]],
        "orbit_size_sym": orbit_size[orbits[e1]] == orbit_size[orbits[e2]],
        "triangle_1": sum(1 for _ in nx.common_neighbors(G, n1a, n1b)),
        "triangle_2": sum(1 for _ in nx.common_neighbors(G, n2a, n2b)),
        "kcore_1": min(nx.core_number(G)[n1a], nx.core_number(G)[n1b]),
        "kcore_2": min(nx.core_number(G)[n2a], nx.core_number(G)[n2b]),
        "is_bridge_1": frozenset(e1) in bridges,
        "is_bridge_2": frozenset(e2) in bridges,
        "eff_res_sym": (not np.isnan(er1)) and (not np.isnan(er2)) and abs(er1 - er2) < 1e-8,
    }


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 100)
    print("照妖镜 N=7 版：查 382 对异轨道同响应")
    print("=" * 100)

    print("\n[准备] 构建 N=7 全部连通图…")
    graphs = build_all_N7_graphs()
    print(f"  图集: {len(graphs)} 个 N=7 连通图")

    print("\n[准备] 预计算所有 E 曲线（宽网格 [-4,4] × 181 点）…")
    wide_grid = np.linspace(-4, 4, 181)
    all_curves = {}
    all_orbits = {}
    all_edges = {}
    for gid, G in enumerate(graphs):
        if gid % 50 == 0:
            print(f"    {gid}/{len(graphs)}")
        edges = build_adj_list(G)
        try:
            H0, Ms, basis = build_edge_matrices(N_NODES, edges)
        except Exception as e:
            print(f"    图 {gid} 构建失败: {e}")
            continue
        all_edges[gid] = edges
        all_orbits[gid] = edge_orbits(G, edges)
        all_curves[gid] = {}
        for k, e in enumerate(edges):
            all_curves[gid][e] = compute_E_curve_fast(
                N_NODES, edges, k, wide_grid, H0, Ms, basis)
    print("  完成")

    # ============================================================
    # 阶段 1：窗口扫描
    # ============================================================
    print("\n" + "=" * 100)
    print("阶段 1：窗口扫描，找 382")
    print("=" * 100)

    # 收集所有异轨道对
    pair_list = []
    for gid in all_edges:
        edges = all_edges[gid]
        orbits = all_orbits[gid]
        for i in range(len(edges)):
            for j in range(i + 1, len(edges)):
                e1, e2 = edges[i], edges[j]
                if orbits[e1] == orbits[e2]:
                    continue
                pair_list.append((gid, e1, e2))
    print(f"  总异轨道对数: {len(pair_list)}")

    # 预计算 |diff| 曲线
    print(f"  预计算 |diff| 曲线…")
    diff_curves = {}
    for idx, (gid, e1, e2) in enumerate(pair_list):
        if idx % 5000 == 0:
            print(f"    {idx}/{len(pair_list)}")
        d = np.abs(all_curves[gid][e1] - all_curves[gid][e2])
        d[np.isnan(d)] = np.inf
        diff_curves[(gid, e1, e2)] = d
    print(f"  完成")

    # 生成窗口
    windows = set()
    for center in np.arange(-2.0, 2.01, 0.25):
        for hw in np.arange(0.25, 4.01, 0.25):
            lo, hi = round(center - hw, 2), round(center + hw, 2)
            if lo >= -4 and hi <= 4 and hi > lo:
                windows.add((lo, hi))
    for lo in np.arange(-3.0, 1.01, 0.5):
        for hi in np.arange(lo + 0.5, 3.01, 0.5):
            windows.add((round(lo, 2), round(hi, 2)))
    windows = sorted(windows)
    print(f"  候选窗口数: {len(windows)}")

    print(f"  扫描窗口…")
    results = []
    for wi, (lo, hi) in enumerate(windows):
        if wi % 100 == 0:
            print(f"    窗口 {wi}/{len(windows)}")
        mask = (wide_grid >= lo) & (wide_grid <= hi)
        if mask.sum() < 5:
            continue
        count = 0
        pairs_in = []
        for key, d in diff_curves.items():
            if np.max(d[mask]) < TOL:
                count += 1
                pairs_in.append(key)
        results.append({"window": (lo, hi), "n_points": int(mask.sum()),
                        "n_pairs": count, "pairs": pairs_in})

    exact_target = [r for r in results if r["n_pairs"] == TARGET_N7]
    closest = sorted(results, key=lambda r: abs(r["n_pairs"] - TARGET_N7))[:10]

    print(f"\n  给出恰好 {TARGET_N7} 对的窗口数: {len(exact_target)}")
    if exact_target:
        print("\n  --- 所有 382 窗口 ---")
        for r in exact_target:
            print(f"    {r['window']}: {r['n_pairs']} 对 ({r['n_points']} 点)")
    else:
        print(f"\n  --- 没有窗口给出恰好 {TARGET_N7} 对 ---")
        print(f"\n  --- 最接近 {TARGET_N7} 的 10 个窗口 ---")
        print(f"  {'窗口':>20} | {'点数':>5} | {'对数':>6}")
        print(f"  {'-'*20}-+-{'-'*5}-+-{'-'*6}")
        for r in closest:
            print(f"  {str(r['window']):>20} | {r['n_points']:>5} | {r['n_pairs']:>6}")

    # 选择分析对象
    if exact_target:
        analyze = exact_target[0]
    else:
        analyze = closest[0]
    pairs = analyze["pairs"]
    print(f"\n  [选择] 分析窗口: {analyze['window']}")
    print(f"  [选择] 分析对数: {len(pairs)}")

    # ============================================================
    # 阶段 2：DNA 提取
    # ============================================================
    print("\n" + "=" * 100)
    print(f"阶段 2：DNA 提取（{len(pairs)} 对）")
    print("=" * 100)

    rows = []
    for gid, e1, e2 in pairs:
        G = graphs[gid]
        feats = extract_pair_features(G, e1, e2, all_orbits[gid])
        feats["graph_id"] = gid
        feats["e1"] = e1
        feats["e2"] = e2
        rows.append(feats)

    # DNA 分析
    feature_names = [k for k in rows[0].keys()
                     if k not in ("graph_id", "e1", "e2")]
    dna = []
    variable = []
    for fname in feature_names:
        values = [r[fname] for r in rows]
        cnt = Counter([str(v) for v in values])
        if len(cnt) == 1:
            dna.append((fname, values[0]))
        else:
            variable.append((fname, dict(cnt)))

    print(f"\n  --- DNA（在 {len(pairs)} 对中恒定）---")
    if dna:
        for fname, value in dna:
            print(f"    {fname:>25} = {fmt(value)}")
    else:
        print(f"    （没有任何特征在所有对中恒定）")

    print(f"\n  --- 变化特征 ---")
    for fname, cnt in variable:
        items = sorted(cnt.items(), key=lambda x: -x[1])
        top = items[:6]
        rest = len(items) - len(top)
        line = ", ".join(f"{v}:{c}" for v, c in top)
        if rest > 0:
            line += f", ... (+{rest} 种)"
        print(f"    {fname:>25}: {line}")

    # 按 graph_id 分组
    print(f"\n  --- 按 graph_id 分组 ---")
    gid_groups = defaultdict(list)
    for r in rows:
        gid_groups[r["graph_id"]].append(r)
    print(f"  参与的图数: {len(gid_groups)}")
    print(f"  {'gid':>4} | {'对数':>5}")
    print(f"  {'-'*4}-+-{'-'*5}")
    for gid in sorted(gid_groups.keys(), key=lambda g: -len(gid_groups[g]))[:30]:
        print(f"  {gid:>4} | {len(gid_groups[gid]):>5}")

    # ============================================================
    # 与 N=6 并排比较
    # ============================================================
    print("\n" + "=" * 100)
    print("与 N=6 的 28 对并排比较（N=6 数据来自 v3.0）")
    print("=" * 100)

    # N=6 的特征分布（来自 v3.0 输出）
    n6_data = {
        "share_endpoint": {"False": 15, "True": 13},
        "edge_distance": {"1": 18, "2": 6, "0": 4},
        "common_neighbors": {"4": 23, "5": 4, "2": 1},
        "neighbor_jaccard": {"2/3": 22, "5/6": 4, "1/3": 1, "4/5": 1},
        "orbit_size_1": {"2": 16, "3": 9, "1": 3},
        "orbit_size_2": {"2": 16, "3": 9, "1": 3},
    }

    print(f"\n  --- 关键特征分布：N=6（28对） vs N=7（{len(pairs)}对）---")
    for fname in ["share_endpoint", "edge_distance", "common_neighbors",
                  "neighbor_jaccard", "orbit_size_sym"]:
        print(f"\n  {fname}:")
        print(f"    N=6: {n6_data.get(fname, '(见 v3 输出)')}")
        values = [str(r[fname]) for r in rows]
        cnt = Counter(values)
        top = sorted(cnt.items(), key=lambda x: -x[1])[:6]
        print(f"    N=7: {dict(top)}")

    # ============================================================
    # 导出
    # ============================================================
    out = {
        "N": 7,
        "n_graphs": len(graphs),
        "n_diff_orbit_pairs": len(pair_list),
        "n_exact_382_windows": len(exact_target),
        "exact_382_windows": [
            {"window": list(r["window"]), "n_pairs": r["n_pairs"]}
            for r in exact_target
        ],
        "closest_10": [
            {"window": list(r["window"]), "n_pairs": r["n_pairs"]}
            for r in closest
        ],
        "analyzed_window": list(analyze["window"]),
        "analyzed_n_pairs": len(pairs),
        "analyzed_pairs": [
            {"gid": g, "e1": list(e1), "e2": list(e2)}
            for g, e1, e2 in pairs
        ],
        "DNA": [(f, str(v)) for f, v in dna],
        "variable_summary": [(f, dict(c)) for f, c in variable],
        "graph_distribution": {
            str(g): len(gid_groups[g]) for g in gid_groups
        },
    }
    out_path = os.path.join(WORK_DIR, "照妖镜_N7_382_v1.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("N=7 查 382 完成。结果并排。不筛选。不下结论。")
    print("脚本是对象化，追问是行动。")
    print("=" * 100)


if __name__ == "__main__":
    main()