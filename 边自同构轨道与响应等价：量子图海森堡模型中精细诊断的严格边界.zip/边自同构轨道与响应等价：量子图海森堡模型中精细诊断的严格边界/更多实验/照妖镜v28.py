#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 v28.0：47 对的自然分类 + 全类覆盖检验
================================================================

上一轮的批评：
  机制必须"都有"。不是找越来越小的子集。

v28 的方法论转向：
  1. 不再切 24/12/7。按"基态简并度"这个自然分类量把 47 对切成两类。
  2. 对每一类，穷举所有可能条件，找"全类覆盖"的条件。
  3. 不报告"精度/召回"，报告"类内覆盖率"。
  4. 验证"三层结构"是类内现象还是类间现象。
"""

import sys, io, itertools, json, os
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from collections import Counter, defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"


# ============================================================
# 基础
# ============================================================

def build_atlas_graphs(N):
    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    return graphs


def build_sz0_sector(N):
    n_up = N // 2
    basis = []
    for comb in itertools.combinations(range(N), n_up):
        state = [0]*N
        for i in comb: state[i] = 1
        basis.append(tuple(state))
    dim = len(basis)
    idx = {s: i for i, s in enumerate(basis)}
    SZ_ops = []
    for site in range(N):
        SZ = np.zeros((dim, dim), dtype=complex)
        for i, state in enumerate(basis):
            SZ[i, i] = 1 if state[site] == 1 else -1
        SZ_ops.append(SZ)
    return basis, idx, SZ_ops


def build_edge_op(i, j, basis, idx):
    dim = len(basis)
    op = np.zeros((dim, dim), dtype=complex)
    for a_idx, state_a in enumerate(basis):
        sa, sb = state_a[i], state_a[j]
        if sa == sb:
            op[a_idx, a_idx] += 1
        else:
            op[a_idx, a_idx] += -1
            new_state = list(state_a)
            new_state[i], new_state[j] = new_state[j], new_state[i]
            b_idx = idx.get(tuple(new_state))
            if b_idx is not None:
                op[b_idx, a_idx] += 2
    return op


def build_S2_op(basis, idx, N):
    dim = len(basis)
    S2 = np.zeros((dim, dim), dtype=complex)
    for i in range(N):
        S2 += 3/4 * np.eye(dim, dtype=complex)
        for j in range(N):
            if i == j: continue
            S2 += 1/4 * build_edge_op(i, j, basis, idx)
    return S2


def analyze_at_s(edge_ops, defect, s, SZ_ops, S2_op, ref_dim):
    """在 s 处返回：pS, szsz, sigdot, deg, S_total"""
    H = np.zeros((ref_dim, ref_dim), dtype=complex)
    for e, M in edge_ops.items():
        c = s if e == defect else 1.0
        H += c * M
    try:
        evals, evecs = eigh(H)
    except Exception:
        return None
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < 1e-8))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    i, j = defect
    szsz_diag = np.diag(SZ_ops[i] @ SZ_ops[j])
    szsz = float(np.real(np.sum(np.diag(rho) * szsz_diag)))
    p_S = (1 - 3 * szsz) / 4
    sd = float(np.real(np.trace(rho @ edge_ops[defect])))
    # S_total
    S2_val = float(np.real(np.trace(rho @ S2_op)))
    S_total = (-1 + np.sqrt(1 + 4*max(S2_val, 0))) / 2
    return {
        "pS": p_S, "szsz": szsz, "sd": sd, "deg": deg, "S": S_total,
        "E0": float(E0),
    }


def load_patterns():
    with open(os.path.join(WORK_DIR, "照妖镜_v5_1_模式.json"), "r",
              encoding="utf-8") as f:
        v51 = json.load(f)
    patterns = {}
    for key, s in v51["patterns"].items():
        gid, e1_str, e2_str = key.split("_", 2)
        gid = int(gid)
        e1 = tuple(map(int, e1_str.strip("()").split(",")))
        e2 = tuple(map(int, e2_str.strip("()").split(",")))
        patterns[(gid, tuple(sorted(e1)), tuple(sorted(e2)))] = s
    return patterns


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 100)
    print("照妖镜 v28.0：47 对的自然分类 + 全类覆盖检验")
    print("=" * 100)

    N = 6
    graphs = build_atlas_graphs(N)
    patterns = load_patterns()
    print(f"\n  N={N} 图集: {len(graphs)} 图")
    print(f"  同响应对: {len(patterns)}")

    basis, idx, SZ_ops = build_sz0_sector(N)
    ref_dim = len(basis)
    S2_op = build_S2_op(basis, idx, N)

    # s 网格
    s_grid = np.linspace(-2.0, 2.0, 41)
    s_idx_0 = np.argmin(np.abs(s_grid - 0.0))
    s_idx_05 = np.argmin(np.abs(s_grid - 0.5))
    s_idx_1 = np.argmin(np.abs(s_grid - 1.0))

    # 分析每一对
    print(f"\n  分析每一对（计算 pS 曲线 + 简并结构）...")
    pair_data = []
    for i, ((gid, e1, e2), pattern) in enumerate(sorted(patterns.items())):
        if i % 10 == 0:
            print(f"    {i}/{len(patterns)}")
        G = graphs[gid]
        edges = [tuple(sorted(e)) for e in G.edges()]
        edge_ops = {e: build_edge_op(e[0], e[1], basis, idx) for e in edges}

        # 计算两条边作为缺陷边时的结构
        per_defect = {}
        for d_edge in [e1, e2]:
            curve = []
            for s in s_grid:
                r = analyze_at_s(edge_ops, d_edge, s, SZ_ops, S2_op, ref_dim)
                curve.append(r["pS"] if r else np.nan)
            curve = np.array(curve)
            r0 = analyze_at_s(edge_ops, d_edge, 0.0, SZ_ops, S2_op, ref_dim)
            r05 = analyze_at_s(edge_ops, d_edge, 0.5, SZ_ops, S2_op, ref_dim)
            r1 = analyze_at_s(edge_ops, d_edge, 1.0, SZ_ops, S2_op, ref_dim)
            per_defect[d_edge] = {
                "curve": curve,
                "pS@0": curve[s_idx_0],
                "pS@0.5": curve[s_idx_05],
                "pS@1": curve[s_idx_1],
                "pS_mean": float(np.nanmean(curve)),
                "pS_std": float(np.nanstd(curve)),
                "deg@0.5": r05["deg"] if r05 else None,
                "S@0.5": r05["S"] if r05 else None,
                "sd@0.5": r05["sd"] if r05 else None,
                "sd@0": r0["sd"] if r0 else None,
                "sd@1": r1["sd"] if r1 else None,
            }

        # 交叉检测（pS=0.5）
        curve1 = per_defect[e1]["curve"]
        crossings = []
        for k in range(len(s_grid) - 1):
            if (curve1[k] - 0.5) * (curve1[k+1] - 0.5) < 0:
                crossings.append((s_grid[k] + s_grid[k+1]) / 2)

        n_true = pattern.count("1")
        pair_data.append({
            "gid": gid, "e1": e1, "e2": e2,
            "n_true": n_true,
            "d1": per_defect[e1]["deg@0.5"],
            "d2": per_defect[e2]["deg@0.5"],
            "S1": per_defect[e1]["S@0.5"],
            "S2": per_defect[e2]["S@0.5"],
            "pS1_at_05": per_defect[e1]["pS@0.5"],
            "pS2_at_05": per_defect[e2]["pS@0.5"],
            "pS1_mean": per_defect[e1]["pS_mean"],
            "pS2_mean": per_defect[e2]["pS_mean"],
            "sd1_at_05": per_defect[e1]["sd@0.5"],
            "sd2_at_05": per_defect[e2]["sd@0.5"],
            "sd1_at_0": per_defect[e1]["sd@0"],
            "sd2_at_0": per_defect[e2]["sd@0"],
            "sd1_at_1": per_defect[e1]["sd@1"],
            "sd2_at_1": per_defect[e2]["sd@1"],
            "curve1": curve1.tolist(),
            "curve2": per_defect[e2]["curve"].tolist(),
            "n_crossings": len(crossings),
            "min_deg": min(per_defect[e1]["deg@0.5"], per_defect[e2]["deg@0.5"]),
            "max_deg": max(per_defect[e1]["deg@0.5"], per_defect[e2]["deg@0.5"]),
        })

    print(f"\n  完成 {len(pair_data)} 对")

    # ============================================================
    # Q1: 按基态简并度的自然分类
    # ============================================================
    print("\n" + "=" * 100)
    print("Q1. 按基态简并度的自然分类")
    print("=" * 100)

    # 按 max(d1, d2) 分类
    by_deg = defaultdict(list)
    for p in pair_data:
        key = p["max_deg"]
        by_deg[key].append(p)

    print(f"\n  {'max_d':>6} | {'对数':>6} | {'类别':>12}")
    print(f"  {'-'*6}-+-{'-'*6}-+-{'-'*12}")
    for d in sorted(by_deg.keys()):
        cnt = len(by_deg[d])
        cat = "非简并" if d == 1 else "简并"
        print(f"  {d:>6} | {cnt:>6} | {cat:>12}")

    # 两大类
    class_1 = [p for p in pair_data if p["max_deg"] == 1]  # 非简并
    class_2 = [p for p in pair_data if p["max_deg"] > 1]   # 简并
    print(f"\n  类 1（非简并，max_d=1）: {len(class_1)} 对")
    print(f"  类 2（简并，max_d>1）: {len(class_2)} 对")

    # ============================================================
    # Q2: 对每一类，穷举"全类覆盖"条件
    # ============================================================
    print("\n" + "=" * 100)
    print("Q2. 每类的全类覆盖条件穷举")
    print("=" * 100)

    def coverage(condition, subset):
        """返回条件在 subset 中的覆盖率"""
        if not subset:
            return 0, 0
        n_hit = sum(1 for p in subset if condition(p))
        return n_hit, len(subset)

    # 候选条件（都返回 True/False）
    conditions = [
        ("pS@0.5 两条边都等于 0.5", lambda p: abs(p["pS1_at_05"] - 0.5) < 1e-6 and abs(p["pS2_at_05"] - 0.5) < 1e-6),
        ("pS@0.5 至少一条边等于 0.5", lambda p: abs(p["pS1_at_05"] - 0.5) < 1e-6 or abs(p["pS2_at_05"] - 0.5) < 1e-6),
        ("<sigma.sigma>@0.5 两条边都等于 -1", lambda p: abs(p["sd1_at_05"] + 1) < 1e-6 and abs(p["sd2_at_05"] + 1) < 1e-6),
        ("<sigma.sigma>@0.5 至少一条边等于 -1", lambda p: abs(p["sd1_at_05"] + 1) < 1e-6 or abs(p["sd2_at_05"] + 1) < 1e-6),
        ("pS 曲线在 s=0.5 处交叉 0.5", lambda p: p["n_crossings"] > 0),
        ("pS 曲线完全相等", lambda p: np.nanmax(np.abs(np.array(p["curve1"]) - np.array(p["curve2"]))) < 1e-10),
        ("pS 曲线差 < 1e-6", lambda p: np.nanmax(np.abs(np.array(p["curve1"]) - np.array(p["curve2"]))) < 1e-6),
        ("pS@0 两条边都 < 0.3", lambda p: p["pS1_at_05"] < 0.3 and p["pS2_at_05"] < 0.3),
        ("pS@0.5 两条边都 < 0.3", lambda p: p["pS1_at_05"] < 0.3 and p["pS2_at_05"] < 0.3),
        ("pS_mean 两条边都 < 0.3", lambda p: p["pS1_mean"] < 0.3 and p["pS2_mean"] < 0.3),
        ("pS 曲线单调递增（两条边）", lambda p: _is_monotone(p["curve1"]) and _is_monotone(p["curve2"])),
        ("S 值相同（|S1 - S2| < 1e-3）", lambda p: abs(p["S1"] - p["S2"]) < 1e-3),
    ]

    print(f"\n  {'条件':<40} | {'类1覆盖':>10} | {'类2覆盖':>10}")
    print(f"  {'-'*40}-+-{'-'*10}-+-{'-'*10}")
    for name, cond in conditions:
        n1, t1 = coverage(cond, class_1)
        n2, t2 = coverage(cond, class_2)
        r1 = f"{n1}/{t1}" if t1 > 0 else "-"
        r2 = f"{n2}/{t2}" if t2 > 0 else "-"
        print(f"  {name:<40} | {r1:>10} | {r2:>10}")

    # ============================================================
    # Q3: 类 2 内部结构（简并对是否可以再分）
    # ============================================================
    print("\n" + "=" * 100)
    print("Q3. 类 2（简并对）内部结构")
    print("=" * 100)

    # 按 S 类型分
    print(f"\n  {'gid':>4} | {'e1':>8} | {'e2':>8} | {'d1':>3} | {'d2':>3} | "
          f"{'S1':>6} | {'S2':>6} | {'sd1':>8} | {'sd2':>8} | {'n_true':>6}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*8}-+-{'-'*3}-+-{'-'*3}-+-"
          f"{'-'*6}-+-{'-'*6}-+-{'-'*8}-+-{'-'*8}-+-{'-'*6}")
    for p in sorted(class_2, key=lambda x: (x["gid"], x["e1"])):
        print(f"  {p['gid']:>4} | {str(p['e1']):>8} | {str(p['e2']):>8} | "
              f"{p['d1']:>3} | {p['d2']:>3} | "
              f"{p['S1']:>6.2f} | {p['S2']:>6.2f} | "
              f"{p['sd1_at_05']:>8.4f} | {p['sd2_at_05']:>8.4f} | {p['n_true']:>6}")

    # ============================================================
    # Q4: 三层结构与自然类的关系
    # ============================================================
    print("\n" + "=" * 100)
    print("Q4. 三层结构与自然类的关系")
    print("=" * 100)

    # 三层：核心 24, 中环 17, 外壳 6
    layers = {
        "核心": [p for p in pair_data if p["n_true"] == 24],
        "中环": [p for p in pair_data if 1 < p["n_true"] < 24],
        "外壳": [p for p in pair_data if p["n_true"] == 1],
    }

    print(f"\n  {'层':>6} | {'总数':>6} | {'类1(非简并)':>12} | {'类2(简并)':>12}")
    print(f"  {'-'*6}-+-{'-'*6}-+-{'-'*12}-+-{'-'*12}")
    for name, group in layers.items():
        n1 = sum(1 for p in group if p["max_deg"] == 1)
        n2 = sum(1 for p in group if p["max_deg"] > 1)
        print(f"  {name:>6} | {len(group):>6} | {n1:>12} | {n2:>12}")

    # ============================================================
    # Q5: 类 1 的内部结构
    # ============================================================
    print("\n" + "=" * 100)
    print("Q5. 类 1（非简并对）内部结构")
    print("=" * 100)

    print(f"\n  {'gid':>4} | {'e1':>8} | {'e2':>8} | {'n_true':>6} | "
          f"{'pS1@0.5':>10} | {'pS2@0.5':>10} | {'sd1@0.5':>10} | {'sd2@0.5':>10}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*8}-+-{'-'*6}-+-"
          f"{'-'*10}-+-{'-'*10}-+-{'-'*10}-+-{'-'*10}")
    for p in sorted(class_1, key=lambda x: (x["gid"], x["e1"])):
        print(f"  {p['gid']:>4} | {str(p['e1']):>8} | {str(p['e2']):>8} | "
              f"{p['n_true']:>6} | "
              f"{p['pS1_at_05']:>10.6f} | {p['pS2_at_05']:>10.6f} | "
              f"{p['sd1_at_05']:>10.6f} | {p['sd2_at_05']:>10.6f}")

    # ============================================================
    # 汇总
    # ============================================================
    print("\n" + "=" * 100)
    print("汇总：自然分类 vs 三层结构")
    print("=" * 100)

    print(f"""
  自然分类（按基态简并度）：
    - 类 1（非简并，max_d = 1）: {len(class_1)} 对
    - 类 2（简并，max_d > 1）: {len(class_2)} 对

  三层结构（按 24 位模式）：
    - 核心（24 位全 1）: {len(layers['核心'])} 对
    - 中环（2-23 位）: {len(layers['中环'])} 对
    - 外壳（1 位）: {len(layers['外壳'])} 对

  类 vs 层的交叉：
""")

    for name, group in layers.items():
        n1 = sum(1 for p in group if p["max_deg"] == 1)
        n2 = sum(1 for p in group if p["max_deg"] > 1)
        print(f"    {name}: 类1={n1}, 类2={n2}")

    # ============================================================
    # 导出
    # ============================================================
    out = {
        "n_total": len(pair_data),
        "class_1_size": len(class_1),
        "class_2_size": len(class_2),
        "layers": {name: len(g) for name, g in layers.items()},
        "layer_class_cross": {
            name: {
                "class_1": sum(1 for p in g if p["max_deg"] == 1),
                "class_2": sum(1 for p in g if p["max_deg"] > 1),
            } for name, g in layers.items()
        },
        "pairs": [
            {k: v for k, v in p.items() if k not in ("curve1", "curve2")}
            for p in pair_data
        ],
    }
    out_path = os.path.join(WORK_DIR, "照妖镜_v28_自然分类.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[ok] 导出: {out_path}")


def _is_monotone(curve):
    curve = np.array(curve)
    diffs = np.diff(curve)
    return bool(np.all(diffs >= -1e-6) or np.all(diffs <= 1e-6))


if __name__ == "__main__":
    main()