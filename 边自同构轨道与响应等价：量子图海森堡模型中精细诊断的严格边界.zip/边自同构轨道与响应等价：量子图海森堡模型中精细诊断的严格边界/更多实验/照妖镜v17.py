#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 v17.0：为什么 S=3/2 的态在缺陷边给出非整数 ⟨σ·σ⟩？
================================================================

核心假设：
  非整数 ⟨σ·σ⟩ 来自简并子空间内 S_edge=0（单态）和 S_edge=1（三重态）
  的本征态混合。如果我们在简并子空间内同时对角化 S_total² 和 S_edge²，
  每个本征态应有纯 S_edge 值，从而给出整数 ⟨σ·σ⟩ ∈ {-3, +1}。

五个追问并行：
  Q1. 在原始 eigh 基下，简并态的 ⟨σ·σ⟩ 分布
  Q2. 在 S_edge² 对角化基下，⟨σ·σ⟩ 是否全为整数？
  Q3. N=6 vs N=7 的 S_edge² 谱结构对比
  Q4. 简并子空间中 S² 和 S_edge² 是否同时可对角化？
  Q5. S_total 值（1/2 vs 3/2）与非整数 ⟨σ·σ⟩ 的关联
"""

import sys, io, itertools, json, os
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from scipy.optimize import brentq
from collections import Counter, defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"


# ============================================================
# S_z=0 扇区
# ============================================================

def build_sz0_sector(N):
    n_up = N // 2
    basis = []
    for comb in itertools.combinations(range(N), n_up):
        state = [0]*N
        for i in comb: state[i] = 1
        basis.append(tuple(state))
    dim = len(basis)
    idx = {s: i for i, s in enumerate(basis)}
    SZ_ops = []
    for site in range(N):
        SZ = np.zeros((dim, dim), dtype=complex)
        for i, state in enumerate(basis):
            SZ[i, i] = 1 if state[site] == 1 else -1
        SZ_ops.append(SZ)
    return basis, idx, SZ_ops


def build_edge_op(i, j, basis, idx):
    dim = len(basis)
    op = np.zeros((dim, dim), dtype=complex)
    for a_idx, state_a in enumerate(basis):
        sa, sb = state_a[i], state_a[j]
        if sa == sb:
            op[a_idx, a_idx] += 1
        else:
            op[a_idx, a_idx] += -1
            new_state = list(state_a)
            new_state[i], new_state[j] = new_state[j], new_state[i]
            b_idx = idx.get(tuple(new_state))
            if b_idx is not None:
                op[b_idx, a_idx] += 2
    return op


def build_S2_op(basis, idx, N):
    dim = len(basis)
    S2 = np.zeros((dim, dim), dtype=complex)
    for i in range(N):
        S2 += 3/4 * np.eye(dim, dtype=complex)
        for j in range(N):
            if i == j: continue
            S2 += 1/4 * build_edge_op(i, j, basis, idx)
    return S2


# ============================================================
# 核心分析
# ============================================================

def analyze_degenerate_point(edge_ops, defect, s, SZ_ops,
                              S2_op, S_edge_sq_op, ref_dim):
    """
    在谐振点 s 处分析简并子空间的结构：
    1. 原始 eigh 基下的 ⟨σ·σ⟩
    2. S_edge² 对角化基下的 ⟨σ·σ⟩
    3. 同时对角化 S² 和 S_edge² 后的 ⟨σ·σ⟩
    """
    H = np.zeros((ref_dim, ref_dim), dtype=complex)
    for e, M in edge_ops.items():
        c = s if e == defect else 1.0
        H += c * M

    evals, evecs = eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < 1e-8))
    V = evecs[:, :deg]

    # (1) 原始基的 ⟨σ·σ⟩、S²、S_edge²
    raw_data = []
    for k in range(deg):
        v = V[:, k]
        sd = float(np.real(v.conj() @ edge_ops[defect] @ v))
        se2 = float(np.real(v.conj() @ S_edge_sq_op @ v))
        s2 = float(np.real(v.conj() @ S2_op @ v))
        S_total = (-1 + np.sqrt(1 + 4*max(s2, 0))) / 2
        raw_data.append({"sd": sd, "se2": se2, "s2": s2, "S": S_total})

    # (2) 简并子空间内对角化 S_edge²
    M_edge = V.conj().T @ S_edge_sq_op @ V
    se2_evals, W_edge = eigh(M_edge)
    V_edge = V @ W_edge
    edge_diag_data = []
    for k in range(deg):
        v = V_edge[:, k]
        sd = float(np.real(v.conj() @ edge_ops[defect] @ v))
        se2 = float(np.real(v.conj() @ S_edge_sq_op @ v))
        s2 = float(np.real(v.conj() @ S2_op @ v))
        S_total = (-1 + np.sqrt(1 + 4*max(s2, 0))) / 2
        edge_diag_data.append({"sd": sd, "se2": se2, "s2": s2, "S": S_total})

    # (3) 同时对角化 S² 和 S_edge²（用组合矩阵）
    M_S2 = V.conj().T @ S2_op @ V
    # 检查对易
    comm = M_S2 @ M_edge - M_edge @ M_S2
    comm_norm = float(np.linalg.norm(comm))

    # 组合：M_S2 + η * M_edge
    eta = 0.123456789012345
    M_comb = M_S2 + eta * M_edge
    _, W_comb = eigh(M_comb)
    V_comb = V @ W_comb
    comb_data = []
    for k in range(deg):
        v = V_comb[:, k]
        sd = float(np.real(v.conj() @ edge_ops[defect] @ v))
        se2 = float(np.real(v.conj() @ S_edge_sq_op @ v))
        s2 = float(np.real(v.conj() @ S2_op @ v))
        S_total = (-1 + np.sqrt(1 + 4*max(s2, 0))) / 2
        comb_data.append({"sd": sd, "se2": se2, "s2": s2, "S": S_total})

    # S_edge² 在简并子空间内的谱
    se2_spectrum = sorted(set(round(e, 4) for e in se2_evals))
    # S² 在简并子空间内的谱
    M_S2_proj = M_S2
    s2_evals_proj = sorted(set(round(e, 4)
                              for e in np.linalg.eigvalsh(M_S2_proj)))

    return {
        "s": s, "deg": deg,
        "raw": raw_data,
        "edge_diag": edge_diag_data,
        "comb": comb_data,
        "se2_spectrum": se2_spectrum,
        "s2_spectrum": s2_evals_proj,
        "comm_norm": comm_norm,
    }


# ============================================================
# 图集
# ============================================================

def build_atlas_graphs(N):
    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    return graphs


# ============================================================
# 主流程
# ============================================================

def run_analysis(N, max_graphs=None, sample_edges=3, label=""):
    """对 N 个节点的图运行分析"""
    print(f"\n{'='*80}")
    print(f"  N={N} 简并 S=3/2 分析 {label}")
    print(f"{'='*80}")

    graphs = build_atlas_graphs(N)
    if max_graphs:
        step = max(1, len(graphs) // max_graphs)
        graphs = graphs[::step][:max_graphs]
    print(f"  图集: {len(graphs)} 图")

    basis, idx, SZ_ops = build_sz0_sector(N)
    ref_dim = len(basis)
    print(f"  S_z=0 维度: {ref_dim}")

    S2_op = build_S2_op(basis, idx, N)

    # 收集简并谐振点
    print(f"  扫描谐振点...")
    degenerate_points = []

    for gid, G in enumerate(graphs):
        edges = [tuple(sorted(e)) for e in G.edges()]
        edge_ops = {e: build_edge_op(e[0], e[1], basis, idx) for e in edges}
        for defect in edges[:sample_edges]:
            # S_edge² = 6I + 2σ_i·σ_j（σ 约定）
            S_edge_sq_op = 6 * np.eye(ref_dim, dtype=complex) + \
                           2 * edge_ops[defect]

            # 粗扫 p_S
            s_grid = np.linspace(-2.0, 2.5, 61)
            pS_vals = []
            for s in s_grid:
                H = np.zeros((ref_dim, ref_dim), dtype=complex)
                for e, M in edge_ops.items():
                    c = s if e == defect else 1.0
                    H += c * M
                try:
                    evals, evecs = eigh(H)
                except Exception:
                    pS_vals.append(0.0)
                    continue
                E0 = evals[0]
                deg = int(np.sum(np.abs(evals - E0) < 1e-8))
                Vv = evecs[:, :deg]
                rho = Vv @ Vv.conj().T / deg
                i, j = defect
                szsz_diag = np.diag(SZ_ops[i] @ SZ_ops[j])
                szsz = float(np.real(np.sum(np.diag(rho) * szsz_diag)))
                pS_vals.append((1 - 3 * szsz) / 4)
            pS_vals = np.array(pS_vals)

            # 找交叉
            for k in range(len(s_grid) - 1):
                if (pS_vals[k] - 0.5) * (pS_vals[k+1] - 0.5) < 0:
                    try:
                        s_res = brentq(
                            lambda s: _pS_at_s(edge_ops, defect, s,
                                              SZ_ops, ref_dim) - 0.5,
                            s_grid[k], s_grid[k+1], xtol=1e-10)
                        # 检查简并
                        H = np.zeros((ref_dim, ref_dim), dtype=complex)
                        for e, M in edge_ops.items():
                            c = s_res if e == defect else 1.0
                            H += c * M
                        evals = np.linalg.eigvalsh(H)
                        deg = int(np.sum(np.abs(evals - evals[0]) < 1e-8))
                        if deg > 1:
                            info = analyze_degenerate_point(
                                edge_ops, defect, s_res, SZ_ops,
                                S2_op, S_edge_sq_op, ref_dim)
                            degenerate_points.append({
                                "gid": gid, "defect": list(defect), **info
                            })
                    except Exception:
                        pass

    print(f"  简并谐振点数: {len(degenerate_points)}")

    return degenerate_points


def _pS_at_s(edge_ops, defect, s, SZ_ops, ref_dim):
    H = np.zeros((ref_dim, ref_dim), dtype=complex)
    for e, M in edge_ops.items():
        c = s if e == defect else 1.0
        H += c * M
    evals, evecs = eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < 1e-8))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    i, j = defect
    szsz_diag = np.diag(SZ_ops[i] @ SZ_ops[j])
    szsz = float(np.real(np.sum(np.diag(rho) * szsz_diag)))
    return (1 - 3 * szsz) / 4


def main():
    print("=" * 100)
    print("照妖镜 v17.0：为什么 S=3/2 的态在缺陷边给出非整数 ⟨σ·σ⟩？")
    print("=" * 100)

    # N=7 简并点（主要目标）
    points_N7 = run_analysis(7, max_graphs=150, sample_edges=3, label="（抽样）")

    # N=6 简并点（对照）
    points_N6 = run_analysis(6, max_graphs=None, sample_edges=4, label="（全图）")

    # ============================================================
    # Q1: 原始 eigh 基下的 ⟨σ·σ⟩ 分布
    # ============================================================
    print("\n" + "=" * 100)
    print("Q1. 原始 eigh 基下，简并态 ⟨σ·σ⟩ 的整数性")
    print("=" * 100)

    for label, pts in [("N=6", points_N6), ("N=7", points_N7)]:
        if not pts:
            continue
        all_sd = [v["sd"] for p in pts for v in p["raw"]]
        n_total = len(all_sd)
        n_int = sum(1 for x in all_sd if abs(x - round(x)) < 1e-6)
        print(f"\n  {label}: 总简并态 {n_total}, "
              f"整数 ⟨σ·σ⟩ {n_int} ({n_int/n_total:.1%})")

    # ============================================================
    # Q2: S_edge² 对角化基下，⟨σ·σ⟩ 是否全为整数？
    # ============================================================
    print("\n" + "=" * 100)
    print("Q2. S_edge² 对角化基下，⟨σ·σ⟩ 是否全为整数？")
    print("=" * 100)

    for label, pts in [("N=6", points_N6), ("N=7", points_N7)]:
        if not pts:
            continue
        all_sd = [v["sd"] for p in pts for v in p["edge_diag"]]
        n_total = len(all_sd)
        n_int = sum(1 for x in all_sd if abs(x - round(x)) < 1e-6)
        print(f"\n  {label}: 总态 {n_total}, "
              f"整数 ⟨σ·σ⟩ {n_int} ({n_int/n_total:.1%})")
        # S_edge² 谱分布
        se2_specs = [tuple(p["se2_spectrum"]) for p in pts]
        spec_dist = Counter(se2_specs)
        print(f"    S_edge² 谱（简并子空间内）出现最多的:")
        for spec, cnt in spec_dist.most_common(5):
            print(f"      谱 = {spec}, 出现 {cnt} 次")

    # ============================================================
    # Q3: N=6 vs N=7 的 S_edge² 谱结构
    # ============================================================
    print("\n" + "=" * 100)
    print("Q3. N=6 vs N=7 的 S_edge² 谱结构对比")
    print("=" * 100)

    for label, pts in [("N=6", points_N6), ("N=7", points_N7)]:
        if not pts:
            continue
        # S_edge² 在 σ 约定下的期望值：
        # 纯三重态：6 + 2*1 = 8
        # 纯单态：6 + 2*(-3) = 0
        se2_single_value = []
        se2_multi_value = []
        for p in pts:
            spec = p["se2_spectrum"]
            if len(spec) == 1:
                se2_single_value.append(p)
            else:
                se2_multi_value.append(p)

        print(f"\n  {label}:")
        print(f"    简并子空间内 S_edge² 单值（纯 S_edge）: "
              f"{len(se2_single_value)}")
        print(f"    简并子空间内 S_edge² 多值（混合 S_edge）: "
              f"{len(se2_multi_value)}")

    # ============================================================
    # Q4: S² 和 S_edge² 的对易性
    # ============================================================
    print("\n" + "=" * 100)
    print("Q4. 简并子空间中 S² 和 S_edge² 的对易性")
    print("=" * 100)

    for label, pts in [("N=6", points_N6), ("N=7", points_N7)]:
        if not pts:
            continue
        comm_norms = [p["comm_norm"] for p in pts]
        print(f"\n  {label}: [S², S_edge²] 范数")
        print(f"    max = {max(comm_norms):.3e}")
        print(f"    mean = {np.mean(comm_norms):.3e}")
        n_commuting = sum(1 for x in comm_norms if x < 1e-6)
        print(f"    对易（<1e-6）: {n_commuting}/{len(comm_norms)}")

    # ============================================================
    # Q5: S_total 值与非整数 ⟨σ·σ⟩ 的关联
    # ============================================================
    print("\n" + "=" * 100)
    print("Q5. S_total 值与非整数 ⟨σ·σ⟩ 的关联")
    print("=" * 100)

    for label, pts in [("N=6", points_N6), ("N=7", points_N7)]:
        if not pts:
            continue
        print(f"\n  {label}: 按 S_total 分类")
        print(f"    {'S_total':>8} | {'总数':>6} | {'整数 sd':>8} | {'非整数 sd':>10} | {'整数占比':>8}")
        print(f"    {'-'*8}-+-{'-'*6}-+-{'-'*8}-+-{'-'*10}-+-{'-'*8}")

        by_S = defaultdict(list)
        for p in pts:
            for v in p["raw"]:
                by_S[round(v["S"] * 2) / 2].append(v["sd"])

        for S_val in sorted(by_S.keys()):
            vals = by_S[S_val]
            n_int = sum(1 for x in vals if abs(x - round(x)) < 1e-6)
            n_nonint = len(vals) - n_int
            print(f"    {S_val:>8.1f} | {len(vals):>6} | {n_int:>8} | "
                  f"{n_nonint:>10} | {n_int/len(vals):>8.1%}")

    # ============================================================
    # 深度追问：S_edge² 对角化是否把非整数变成整数？
    # ============================================================
    print("\n" + "=" * 100)
    print("深度追问：S_edge² 对角化是否把非整数变成整数？")
    print("=" * 100)

    for label, pts in [("N=6", points_N6), ("N=7", points_N7)]:
        if not pts:
            continue
        n_changed = 0
        n_unchanged_int = 0
        n_unchanged_nonint = 0
        n_total = 0
        for p in pts:
            raw = p["raw"]
            edge_diag = p["edge_diag"]
            for r, e in zip(raw, edge_diag):
                n_total += 1
                r_int = abs(r["sd"] - round(r["sd"])) < 1e-6
                e_int = abs(e["sd"] - round(e["sd"])) < 1e-6
                if r_int and e_int:
                    n_unchanged_int += 1
                elif not r_int and not e_int:
                    n_unchanged_nonint += 1
                elif not r_int and e_int:
                    n_changed += 1  # 非整数 -> 整数
                else:
                    n_unchanged_nonint += 1  # 整数 -> 非整数（异常）

        print(f"\n  {label}: 总态 {n_total}")
        print(f"    原本整数，保持整数: {n_unchanged_int} "
              f"({n_unchanged_int/n_total:.1%})")
        print(f"    原本非整数，变为整数: {n_changed} "
              f"({n_changed/n_total:.1%})")
        print(f"    原本非整数，仍非整数: {n_unchanged_nonint} "
              f"({n_unchanged_nonint/n_total:.1%})")

    # ============================================================
    # 导出
    # ============================================================
    out = {
        "N6": {
            "n_points": len(points_N6),
            "raw_sd_int_rate": sum(1 for p in points_N6 for v in p["raw"]
                                   if abs(v["sd"] - round(v["sd"])) < 1e-6) /
                               max(1, sum(len(p["raw"]) for p in points_N6)),
            "edge_diag_sd_int_rate": sum(1 for p in points_N6 for v in p["edge_diag"]
                                          if abs(v["sd"] - round(v["sd"])) < 1e-6) /
                                      max(1, sum(len(p["edge_diag"]) for p in points_N6)),
        },
        "N7": {
            "n_points": len(points_N7),
            "raw_sd_int_rate": sum(1 for p in points_N7 for v in p["raw"]
                                   if abs(v["sd"] - round(v["sd"])) < 1e-6) /
                               max(1, sum(len(p["raw"]) for p in points_N7)),
            "edge_diag_sd_int_rate": sum(1 for p in points_N7 for v in p["edge_diag"]
                                          if abs(v["sd"] - round(v["sd"])) < 1e-6) /
                                      max(1, sum(len(p["edge_diag"]) for p in points_N7)),
        },
    }
    out_path = os.path.join(WORK_DIR, "照妖镜_v17_S32非整数.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("v17.0 完成。")
    print("=" * 100)


if __name__ == "__main__":
    main()