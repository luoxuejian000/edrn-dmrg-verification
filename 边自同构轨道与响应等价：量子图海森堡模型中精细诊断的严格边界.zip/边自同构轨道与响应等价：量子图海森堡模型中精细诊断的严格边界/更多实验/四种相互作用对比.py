#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
四种相互作用对比：对合自同构充要条件是否依赖模型
====================================================

核心追问：
- 海森堡、XXZ、Ising、XY 下，32 对异轨道同响应是否仍然全部由对合像产生？
- 定理是否依赖 SU(2) 对称性？

理论精髓：
- 矛盾动力论：模型是矛盾的不同表达
- 只查同与不同：四种模型并行比较
- 反对对齐：不预设"海森堡是唯一正确的模型"
- 严防工具理性悖论：不做平均，直接并排

运行：
    python 四种相互作用对比.py
"""

import sys
import io
import json
import itertools
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from networkx.algorithms.isomorphism import GraphMatcher
from collections import defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)


I2 = np.eye(2, dtype=complex)
SX = np.array([[0, 1], [1, 0]], dtype=complex)
SY = np.array([[0, -1j], [1j, 0]], dtype=complex)
SZ = np.array([[1, 0], [0, -1]], dtype=complex)


def op_on_site(op, site, N):
    ops = [I2] * N
    ops[site] = op
    out = ops[0]
    for o in ops[1:]:
        out = np.kron(out, o)
    return out


def build_site_ops(N):
    return ([op_on_site(SX, i, N) for i in range(N)],
            [op_on_site(SY, i, N) for i in range(N)],
            [op_on_site(SZ, i, N) for i in range(N)])


def edge_matrix(i, j, SX_ops, SY_ops, SZ_ops, rule="heisenberg", delta=1.0):
    if rule == "heisenberg":
        return SX_ops[i] @ SX_ops[j] + SY_ops[i] @ SY_ops[j] + SZ_ops[i] @ SZ_ops[j]
    elif rule == "xxz":
        return SX_ops[i] @ SX_ops[j] + SY_ops[i] @ SY_ops[j] + delta * (SZ_ops[i] @ SZ_ops[j])
    elif rule == "ising":
        return SZ_ops[i] @ SZ_ops[j]
    elif rule == "xy":
        return SX_ops[i] @ SX_ops[j] + SY_ops[i] @ SY_ops[j]
    raise ValueError(f"未知规则: {rule}")


def ground_state_density(H, tol=1e-8):
    evals, evecs = eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < tol))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    return E0, rho, deg


def edge_correlations(rho, edges, SZ_ops):
    C = {}
    for (i, j) in edges:
        op = SZ_ops[i] @ SZ_ops[j]
        C[(i, j)] = float(np.real(np.trace(rho @ op)))
    return C


def compute_sorted_curve(G, defect_edge, s_vals, SX_ops, SY_ops, SZ_ops,
                         rule="heisenberg", delta=1.0):
    N = G.number_of_nodes()
    edges = [tuple(sorted(e)) for e in G.edges()]
    H_edges = {e: edge_matrix(e[0], e[1], SX_ops, SY_ops, SZ_ops, rule, delta)
               for e in edges}
    H0 = sum(H_edges.values())
    M_defect = H_edges[defect_edge]
    curve = []
    for s in s_vals:
        H = H0 + (s - 1.0) * M_defect
        E0, rho, deg = ground_state_density(H)
        C = edge_correlations(rho, edges, SZ_ops)
        curve.append(tuple(np.round(sorted(C.values()), 12)))
    return curve


def find_involution_pairs(G):
    nodes = list(G.nodes())
    matcher = GraphMatcher(G, G)
    pairs = set()
    for mapping in matcher.isomorphisms_iter():
        if not all(mapping[mapping[u]] == u for u in nodes):
            continue
        if all(mapping[u] == u for u in nodes):
            continue
        for u, v in G.edges():
            e1 = tuple(sorted((u, v)))
            u2, v2 = mapping[u], mapping[v]
            e2 = tuple(sorted((u2, v2)))
            if e1 != e2 and G.has_edge(u2, v2):
                pairs.add(tuple(sorted([e1, e2])))
    return pairs


def find_edge_orbits(G):
    nodes = list(G.nodes())
    edges = [tuple(sorted(e)) for e in G.edges()]
    matcher = GraphMatcher(G, G)
    orbit_id = {e: None for e in edges}
    oid = 0
    for e in edges:
        if orbit_id[e] is not None:
            continue
        orbit_id[e] = oid
        for mapping in matcher.isomorphisms_iter():
            u, v = e
            u2, v2 = mapping[u], mapping[v]
            e2 = tuple(sorted((u2, v2)))
            if G.has_edge(u2, v2):
                orbit_id[e2] = oid
        oid += 1
    return orbit_id


def generate_all_connected_graphs(N):
    all_edges = list(itertools.combinations(range(N), 2))
    graphs = []
    for m in range(N - 1, len(all_edges) + 1):
        for combo in itertools.combinations(all_edges, m):
            G = nx.Graph()
            G.add_nodes_from(range(N))
            G.add_edges_from(combo)
            if nx.is_connected(G):
                graphs.append(G)
    return graphs


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--rules", type=str, nargs="+",
                        default=["heisenberg", "xxz", "ising", "xy"])
    parser.add_argument("--delta", type=float, default=1.0)
    parser.add_argument("--out", type=str, default="四种相互作用结果.json")
    args = parser.parse_args()

    s_vals = np.linspace(-1.5, 0.0, 11)
    print("=" * 78)
    print("  四种相互作用对比")
    print("=" * 78)
    print(f"  规则: {args.rules}")
    print(f"  s: [{s_vals[0]}, {s_vals[-1]}], {len(s_vals)} 点")
    print()

    SX_ops, SY_ops, SZ_ops = build_site_ops(6)
    graphs = generate_all_connected_graphs(6)
    print(f"  N=6 连通图总数: {len(graphs)}")
    print()

    # 预计算自同构轨道和对合像（与模型无关）
    graph_data = []
    for gid, G in enumerate(graphs):
        orbits = find_edge_orbits(G)
        involution_pairs = find_involution_pairs(G)
        edges = [tuple(sorted(e)) for e in G.edges()]
        graph_data.append({
            "gid": gid, "G": G, "edges": edges,
            "orbits": orbits, "involution_pairs": involution_pairs,
        })

    all_results = {}

    for rule in args.rules:
        print("=" * 78)
        print(f"  规则: {rule}")
        print("=" * 78)

        same_orbit_same = 0
        same_orbit_diff = 0
        diff_orbit_same = 0
        diff_orbit_diff = 0
        involution_match = 0
        involution_mismatch = 0

        for gd in graph_data:
            G = gd["G"]
            edges = gd["edges"]
            orbits = gd["orbits"]
            involution_pairs = gd["involution_pairs"]

            curves = {}
            for e in edges:
                curves[e] = compute_sorted_curve(G, e, s_vals,
                                                 SX_ops, SY_ops, SZ_ops,
                                                 rule, args.delta)

            for i, e1 in enumerate(edges):
                for j in range(i + 1, len(edges)):
                    e2 = edges[j]
                    same = all(
                        len(a) == len(b) and np.allclose(a, b, atol=1e-10)
                        for a, b in zip(curves[e1], curves[e2])
                    )
                    same_orbit = (orbits[e1] == orbits[e2])
                    is_inv = tuple(sorted([e1, e2])) in involution_pairs

                    if same_orbit and same:
                        same_orbit_same += 1
                    elif same_orbit and not same:
                        same_orbit_diff += 1
                    elif not same_orbit and same:
                        diff_orbit_same += 1
                        if is_inv:
                            involution_match += 1
                        else:
                            involution_mismatch += 1
                    else:
                        diff_orbit_diff += 1

        print()
        print(f"  同轨道同曲线: {same_orbit_same}")
        print(f"  同轨道异曲线: {same_orbit_diff}")
        print(f"  异轨道同曲线: {diff_orbit_same}")
        print(f"  异轨道异曲线: {diff_orbit_diff}")
        print(f"  异轨道同曲线中，是对合像: {involution_match}")
        print(f"  异轨道同曲线中，不是对合像: {involution_mismatch}")
        print()

        all_results[rule] = {
            "same_orbit_same": same_orbit_same,
            "same_orbit_diff": same_orbit_diff,
            "diff_orbit_same": diff_orbit_same,
            "diff_orbit_diff": diff_orbit_diff,
            "involution_match": involution_match,
            "involution_mismatch": involution_mismatch,
        }

    # 并排输出
    print("=" * 78)
    print("  并排：四种相互作用下的核心数据")
    print("=" * 78)
    print()
    print(f"  {'规则':<14}{'同轨道同':<12}{'同轨道异':<12}{'异轨道同':<12}"
          f"{'异轨道异':<12}{'对合匹配':<12}{'对合不匹配':<12}")
    print(f"  {'-'*14}{'-'*12}{'-'*12}{'-'*12}{'-'*12}{'-'*12}{'-'*12}")
    for rule, r in all_results.items():
        print(f"  {rule:<14}{r['same_orbit_same']:<12}{r['same_orbit_diff']:<12}"
              f"{r['diff_orbit_same']:<12}{r['diff_orbit_diff']:<12}"
              f"{r['involution_match']:<12}{r['involution_mismatch']:<12}")
    print()

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(all_results, f, ensure_ascii=False, indent=2, default=str)
    print(f"已保存: {args.out}")


if __name__ == "__main__":
    main()