#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
N=7 全图验证：优化版
========================

优化点：
1. 每处理一个图打印进度（不再等到 50）。
2. 用 GraphMatcher 代替暴力枚举自同构。
3. 预计算 H0，每条边只做一次加减。
4. 用 nx.graph_atlas_g 过滤连通图。

运行：
    python N7全图验证_优化版.py
"""

import sys
import io
import json
import time
import itertools
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from networkx.algorithms.isomorphism import GraphMatcher

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)


I2 = np.eye(2, dtype=complex)
SX = np.array([[0, 1], [1, 0]], dtype=complex)
SY = np.array([[0, -1j], [1j, 0]], dtype=complex)
SZ = np.array([[1, 0], [0, -1]], dtype=complex)


def op_on_site(op, site, N):
    ops = [I2] * N
    ops[site] = op
    out = ops[0]
    for o in ops[1:]:
        out = np.kron(out, o)
    return out


def build_site_ops(N):
    return ([op_on_site(SX, i, N) for i in range(N)],
            [op_on_site(SY, i, N) for i in range(N)],
            [op_on_site(SZ, i, N) for i in range(N)])


def edge_matrix(i, j, SX_ops, SY_ops, SZ_ops):
    return SX_ops[i] @ SX_ops[j] + SY_ops[i] @ SY_ops[j] + SZ_ops[i] @ SZ_ops[j]


def ground_state_density(H, tol=1e-8):
    evals, evecs = eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < tol))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    return E0, rho, deg


def edge_correlations(rho, edges, SZ_ops):
    C = {}
    for (i, j) in edges:
        op = SZ_ops[i] @ SZ_ops[j]
        C[(i, j)] = float(np.real(np.trace(rho @ op)))
    return C


def compute_all_curves(G, s_vals, SX_ops, SY_ops, SZ_ops):
    """预计算 H0，每条边只做一次加减。"""
    N = G.number_of_nodes()
    edges = [tuple(sorted(e)) for e in G.edges()]
    H_edges = {e: edge_matrix(e[0], e[1], SX_ops, SY_ops, SZ_ops)
               for e in edges}
    H0 = sum(H_edges.values())

    curves = {}
    for e in edges:
        M = H_edges[e]
        curve = []
        for s in s_vals:
            H = H0 + (s - 1.0) * M
            E0, rho, deg = ground_state_density(H)
            C = edge_correlations(rho, edges, SZ_ops)
            curve.append(tuple(np.round(sorted(C.values()), 12)))
        curves[e] = curve
    return curves


def find_orbits_and_involutions(G):
    """用 GraphMatcher 一次性找轨道和对合像。"""
    nodes = list(G.nodes())
    edges = [tuple(sorted(e)) for e in G.edges()]
    matcher = GraphMatcher(G, G)

    orbit_id = {e: None for e in edges}
    pairs = set()
    oid = 0

    all_mappings = list(matcher.isomorphisms_iter())
    n_aut = len(all_mappings)

    for e in edges:
        if orbit_id[e] is not None:
            continue
        orbit_id[e] = oid
        for mapping in all_mappings:
            u, v = e
            u2, v2 = mapping[u], mapping[v]
            e2 = tuple(sorted((u2, v2)))
            if G.has_edge(u2, v2):
                orbit_id[e2] = oid
        oid += 1

    for mapping in all_mappings:
        if not all(mapping[mapping[u]] == u for u in nodes):
            continue
        if all(mapping[u] == u for u in nodes):
            continue
        for u, v in G.edges():
            e1 = tuple(sorted((u, v)))
            u2, v2 = mapping[u], mapping[v]
            e2 = tuple(sorted((u2, v2)))
            if e1 != e2 and G.has_edge(u2, v2):
                pairs.add(tuple(sorted([e1, e2])))

    return orbit_id, pairs, n_aut


def get_all_connected_graphs(N):
    """枚举 N 个节点的所有连通图。"""
    all_edges = list(itertools.combinations(range(N), 2))
    graphs = []
    for m in range(N - 1, len(all_edges) + 1):
        for combo in itertools.combinations(all_edges, m):
            G = nx.Graph()
            G.add_nodes_from(range(N))
            G.add_edges_from(combo)
            if nx.is_connected(G):
                graphs.append(G)
    return graphs


def main():
    s_vals = np.linspace(-1.5, 0.0, 11)
    print("=" * 78)
    print("  N=7 全图验证（优化版）")
    print("=" * 78)
    print(f"  s: [{s_vals[0]}, {s_vals[-1]}], {len(s_vals)} 点")
    print()

    t0 = time.time()
    graphs = get_all_connected_graphs(7)
    print(f"  图生成完成：{len(graphs)} 个连通图，耗时 {time.time()-t0:.1f}s")
    print()

    SX_ops, SY_ops, SZ_ops = build_site_ops(7)

    same_orbit_same = 0
    same_orbit_diff = 0
    diff_orbit_same = 0
    diff_orbit_diff = 0
    involution_match = 0
    involution_mismatch = 0

    t0 = time.time()
    for gid, G in enumerate(graphs):
        edges = [tuple(sorted(e)) for e in G.edges()]
        orbits, inv_pairs, n_aut = find_orbits_and_involutions(G)

        curves = compute_all_curves(G, s_vals, SX_ops, SY_ops, SZ_ops)

        for i, e1 in enumerate(edges):
            for j in range(i + 1, len(edges)):
                e2 = edges[j]
                same = all(
                    len(a) == len(b) and np.allclose(a, b, atol=1e-10)
                    for a, b in zip(curves[e1], curves[e2])
                )
                same_orbit = (orbits[e1] == orbits[e2])
                is_inv = tuple(sorted([e1, e2])) in inv_pairs

                if same_orbit and same:
                    same_orbit_same += 1
                elif same_orbit and not same:
                    same_orbit_diff += 1
                elif not same_orbit and same:
                    diff_orbit_same += 1
                    if is_inv:
                        involution_match += 1
                    else:
                        involution_mismatch += 1
                else:
                    diff_orbit_diff += 1

        if (gid + 1) % 10 == 0:
            dt = time.time() - t0
            print(f"    已处理 {gid + 1}/{len(graphs)} 图，"
                  f"耗时 {dt:.1f}s，"
                  f"预计剩余 {(dt/(gid+1))*(len(graphs)-gid-1):.0f}s")

    print()
    print(f"  N=7 结果：")
    print(f"    同轨道同曲线: {same_orbit_same}")
    print(f"    同轨道异曲线: {same_orbit_diff}  ← 必须为 0")
    print(f"    异轨道同曲线: {diff_orbit_same}")
    print(f"    异轨道异曲线: {diff_orbit_diff}")
    print(f"    异轨道同曲线中，是对合像: {involution_match}")
    print(f"    异轨道同曲线中，不是对合像: {involution_mismatch}")
    print()

    output = {
        "same_orbit_same": same_orbit_same,
        "same_orbit_diff": same_orbit_diff,
        "diff_orbit_same": diff_orbit_same,
        "diff_orbit_diff": diff_orbit_diff,
        "involution_match": involution_match,
        "involution_mismatch": involution_mismatch,
    }
    with open("N7全图验证结果.json", "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2, default=str)
    print("已保存: N7全图验证结果.json")


if __name__ == "__main__":
    main()