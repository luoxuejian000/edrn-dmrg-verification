#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 v6.0：谐振点五问并行攻击
====================================

五问并行：
  Q1. ±1/3 从哪来？s 依赖吗？它是 s=0.5 的偶然还是某个 s 的精确值？
  Q2. 图 38 是唯一外壳。它有什么特殊关系结构？
  Q3. 硬核 corr_std=0.44，外壳 0.24。为什么硬核整体离散度更高？
  Q4. 双谐振点（低差异 37 对 + 高差异 9 对）是不是两种关系结构？
  Q5. 谐振点在 s 空间是点、线、还是面？整条 s 曲线告诉你什么？

集中攻击：不是列 24 组合，是追每一个谐振点的代数指纹和关系位置。
"""

import sys, io, itertools, json, os
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from collections import Counter, defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"
N = 6
TOL = 1e-10

I2 = np.eye(2, dtype=complex)
SX = np.array([[0,1],[1,0]], dtype=complex)
SY = np.array([[0,-1j],[1j,0]], dtype=complex)
SZ = np.array([[1,0],[0,-1]], dtype=complex)


def op_on_site(op, site, N):
    ops = [I2]*N; ops[site] = op
    out = ops[0]
    for o in ops[1:]: out = np.kron(out, o)
    return out


def build_site_ops(N):
    return ([op_on_site(SX,i,N) for i in range(N)],
            [op_on_site(SY,i,N) for i in range(N)],
            [op_on_site(SZ,i,N) for i in range(N)])


def edge_matrix(i, j, SXo, SYo, SZo):
    return SXo[i]@SXo[j] + SYo[i]@SYo[j] + SZo[i]@SZo[j]


def gs_rho(H, tol=1e-8):
    evals, evecs = eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < tol))
    V = evecs[:, :deg]
    return V @ V.conj().T / deg


def find_automorphisms(G):
    nodes = list(G.nodes())
    adj = nx.to_numpy_array(G)
    perms = []
    for p in itertools.permutations(nodes):
        P = np.zeros((len(nodes), len(nodes)))
        for i, pi in enumerate(p): P[i, pi] = 1
        if np.allclose(P @ adj @ P.T, adj): perms.append(p)
    return perms


def find_edge_orbits(G):
    nodes = list(G.nodes())
    edges = [tuple(sorted(e)) for e in G.edges()]
    perms = find_automorphisms(G)
    orbit_id = {e: None for e in edges}
    oid = 0
    for e in edges:
        if orbit_id[e] is not None: continue
        orbit_id[e] = oid
        for p in perms:
            m = {nodes[i]: p[i] for i in range(len(nodes))}
            e2 = tuple(sorted((m[e[0]], m[e[1]])))
            if G.has_edge(*e2): orbit_id[e2] = oid
        oid += 1
    return orbit_id


def identify_algebraic(x, tol=1e-9):
    """识别有理数或二次代数数"""
    if abs(x) < tol: return "0"
    if abs(x - (-2.0)) < tol: return "-2"
    if abs(x - 2.0) < tol: return "+2"
    if abs(x - (-1/3)) < tol: return "-1/3"
    if abs(x - (1/3)) < tol: return "+1/3"
    if abs(x - (1 - np.sqrt(3))) < tol: return "1-sqrt(3)"
    if abs(x - (np.sqrt(3) - 1)) < tol: return "sqrt(3)-1"
    for q in [2,3,4,5,6,7,8,9,10,12,15,20]:
        p = round(x * q)
        if abs(x - p/q) < tol:
            return f"{p}/{q}"
    return f"{x:.6f}"


# ============================================================
# 全 s 曲线计算（关键：不只 s=0.5）
# ============================================================

def defect_corr_curve(G, defect_edge, s_vals, SXo, SYo, SZo):
    """
    返回 defect_corr 在 s_vals 上的完整曲线。
    defect_corr(s) = <σᶻσᶻ>_defect 在缺陷边上的值
    """
    edges = [tuple(sorted(e)) for e in G.edges()]
    H_edges = [edge_matrix(e[0], e[1], SXo, SYo, SZo) for e in edges]
    idx_def = edges.index(defect_edge)
    Za, Zb = SZo[defect_edge[0]], SZo[defect_edge[1]]
    op = Za @ Zb
    curve = []
    for s in s_vals:
        couplings = [s if e == defect_edge else 1.0 for e in edges]
        H = sum(c*M for c, M in zip(couplings, H_edges))
        rho = gs_rho(H)
        curve.append(float(np.real(np.trace(rho @ op))))
    return np.array(curve)


def overall_state_curve(G, defect_edge, s_vals, SXo, SYo, SZo):
    """返回每个 s 点下的整体状态特征"""
    edges = [tuple(sorted(e)) for e in G.edges()]
    H_edges = [edge_matrix(e[0], e[1], SXo, SYo, SZo) for e in edges]
    SZ_pairs = [(SZo[e[0]], SZo[e[1]]) for e in edges]
    idx_def = edges.index(defect_edge)
    results = {
        "corr_mean": [], "corr_std": [], "corr_range": [],
        "corr_skew": [], "corr_kurt": [], "corr_entropy": [],
        "defect_corr": [], "defect_rank": [],
    }
    for s in s_vals:
        couplings = [s if e == defect_edge else 1.0 for e in edges]
        H = sum(c*M for c, M in zip(couplings, H_edges))
        rho = gs_rho(H)
        corr = np.array([float(np.real(np.trace(rho @ (Za @ Zb))))
                         for Za, Zb in SZ_pairs])
        results["corr_mean"].append(float(np.mean(corr)))
        results["corr_std"].append(float(np.std(corr)))
        results["corr_range"].append(float(np.max(corr) - np.min(corr)))
        r = corr - corr.min()
        if r.max() > 1e-12:
            r = r / r.max()
            p = r / r.sum()
            p = p[p > 1e-12]
            results["corr_entropy"].append(float(-np.sum(p * np.log(p))))
        else:
            results["corr_entropy"].append(0.0)
        results["defect_corr"].append(float(corr[idx_def]))
        results["defect_rank"].append(float(np.sum(corr < corr[idx_def])) / len(corr))
    for k in results:
        results[k] = np.array(results[k])
    return results


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 100)
    print("照妖镜 v6.0：谐振点五问并行攻击")
    print("集中火力，从关系视角追每一个代数指纹")
    print("=" * 100)

    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    print(f"\n  图集: {len(graphs)} 个 N=6 连通图")

    all_orbits = {gid: find_edge_orbits(G) for gid, G in enumerate(graphs)}
    all_edges = {gid: [tuple(sorted(e)) for e in G.edges()]
                 for gid, G in enumerate(graphs)}
    SXo, SYo, SZo = build_site_ops(N)

    # 加载 v5.1 数据
    with open(os.path.join(WORK_DIR, "照妖镜_v5_1_模式.json"), "r",
              encoding="utf-8") as f:
        v51 = json.load(f)
    patterns = {}
    for key, s in v51["patterns"].items():
        gid, e1_str, e2_str = key.split("_", 2)
        gid = int(gid)
        e1 = tuple(map(int, e1_str.strip("()").split(",")))
        e2 = tuple(map(int, e2_str.strip("()").split(",")))
        patterns[(gid, e1, e2)] = s

    hard_core = set(k for k, v in patterns.items() if v.count("1") == 24)
    middle = set(k for k, v in patterns.items() if 1 < v.count("1") < 24)
    outer = set(k for k, v in patterns.items() if v.count("1") == 1)
    all_same = set(patterns.keys())

    # 精细 s 网格：覆盖 [-2, 2] 尽可能密
    s_vals = np.linspace(-2.0, 2.0, 81)
    print(f"\n  s 网格: [{s_vals[0]}, {s_vals[-1]}], {len(s_vals)} 点")

    # ============================================================
    # 预计算：对每个 (图, 缺陷边) 算完整 s 曲线
    # ============================================================
    print(f"\n  预计算所有 (图, 缺陷边) 的 defect_corr 曲线…")
    defect_corr_cache = {}  # (gid, edge) -> array
    overall_cache = {}      # (gid, edge) -> dict of arrays
    for gid, G in enumerate(graphs):
        if gid % 20 == 0:
            print(f"    {gid}/{len(graphs)}")
        for e in all_edges[gid]:
            defect_corr_cache[(gid, e)] = defect_corr_curve(
                G, e, s_vals, SXo, SYo, SZo)
            overall_cache[(gid, e)] = overall_state_curve(
                G, e, s_vals, SXo, SYo, SZo)
    print(f"  完成")

    # ============================================================
    # Q1：±1/3 从哪来？s 依赖吗？
    # ============================================================
    print("\n" + "=" * 100)
    print("Q1. ±1/3 从哪来？s 依赖吗？")
    print("=" * 100)

    # 对每个同响应对，追踪 defect_corr_1 和 defect_corr_2 在 s 上的轨迹
    print(f"\n  --- 同响应对的 defect_corr 差 (|dc1 - dc2|) 在 s 上的分布 ---")
    print(f"\n  {'gid':>4} | {'e1':>8} | {'e2':>8} | {'s 处 |Δdc|=0':>20} | {'s 处 dc=±1/3':>24}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*8}-+-{'-'*20}-+-{'-'*24}")

    q1_data = []
    for key in sorted(all_same):
        gid, e1, e2 = key
        c1 = defect_corr_cache[(gid, e1)]
        c2 = defect_corr_cache[(gid, e2)]
        # dc1 和 dc2 都是 array，长度 = len(s_vals)
        diff = np.abs(c1 - c2)
        # 找 |dc1 - dc2| ≈ 0 的 s 点
        zero_s = s_vals[np.abs(diff) < 1e-9]
        # 找 dc1 或 dc2 恰好等于 ±1/3 的 s 点
        hits_1_3 = []
        for si, s in enumerate(s_vals):
            if abs(abs(c1[si]) - 1/3) < 1e-9 or abs(abs(c2[si]) - 1/3) < 1e-9:
                hits_1_3.append(s)
        hits_1_3 = np.array(hits_1_3)

        zero_str = f"n={len(zero_s)}" if len(zero_s) > 0 else "never"
        hit_str = f"n={len(hits_1_3)}" if len(hits_1_3) > 0 else "never"
        if len(zero_s) > 0 and len(zero_s) <= 5:
            zero_str += f" @ {', '.join(f'{s:.2f}' for s in zero_s[:5])}"
        if len(hits_1_3) > 0 and len(hits_1_3) <= 5:
            hit_str += f" @ {', '.join(f'{s:.2f}' for s in hits_1_3[:5])}"

        q1_data.append({
            "key": key, "zero_s": zero_s.tolist(), "hit_1_3": hits_1_3.tolist()
        })
        if len(all_same) <= 50:
            print(f"  {gid:>4} | {str(e1):>8} | {str(e2):>8} | {zero_str:>20} | {hit_str:>24}")

    # 统计：多少个同响应对在 s 的哪个点差值为 0
    print(f"\n  --- 全 s 上 |dc1 - dc2| = 0 的 s 点分布 ---")
    zero_count = Counter()
    for d in q1_data:
        for s in d["zero_s"]:
            zero_count[round(s, 2)] += 1
    print(f"  {'s 值':>8} | {'对数':>6}")
    print(f"  {'-'*8}-+-{'-'*6}")
    for s_val, cnt in sorted(zero_count.items(), key=lambda x: -x[1])[:20]:
        print(f"  {s_val:>8.2f} | {cnt:>6}")

    # 关键发现：s=0.5 处哪些对 dc = ±1/3
    print(f"\n  --- s=0.5 处 dc = ±1/3 的对 ---")
    s_idx = np.argmin(np.abs(s_vals - 0.5))
    s_at = s_vals[s_idx]
    print(f"  最近 s 点: {s_at:.4f}")
    print(f"\n  {'gid':>4} | {'e1':>8} | {'e2':>8} | {'dc1':>12} | {'dc2':>12} | {'属于':>6}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*8}-+-{'-'*12}-+-{'-'*12}-+-{'-'*6}")
    for key in sorted(all_same):
        gid, e1, e2 = key
        c1 = defect_corr_cache[(gid, e1)][s_idx]
        c2 = defect_corr_cache[(gid, e2)][s_idx]
        id1 = identify_algebraic(c1)
        id2 = identify_algebraic(c2)
        if "1/3" in id1 or "1/3" in id2:
            if key in hard_core: grp = "硬核"
            elif key in middle: grp = "中环"
            else: grp = "外壳"
            print(f"  {gid:>4} | {str(e1):>8} | {str(e2):>8} | "
                  f"{c1:>12.6f} | {c2:>12.6f} | {grp:>6}")

    # ============================================================
    # Q2：图 38 有什么特殊关系结构？
    # ============================================================
    print("\n" + "=" * 100)
    print("Q2. 图 38 的关系结构（唯一的外壳来源）")
    print("=" * 100)

    g38 = graphs[38]
    edges_38 = all_edges[38]
    orbits_38 = all_orbits[38]
    degs_38 = sorted(d for _, d in g38.degree())
    orbit_sizes_38 = Counter(orbits_38.values())

    print(f"\n  图 38:")
    print(f"    边数: {len(edges_38)}")
    print(f"    边集: {edges_38}")
    print(f"    度序列: {degs_38}")
    print(f"    轨道大小分布: {dict(orbit_sizes_38)}")
    print(f"    桥数: {len(list(nx.bridges(g38)))}")
    print(f"    Laplacian 谱: {sorted(np.round(np.linalg.eigvalsh(nx.laplacian_matrix(g38).toarray()), 4))}")

    # 图 38 里同响应对的 defect_corr 曲线
    print(f"\n  --- 图 38 同响应对的 defect_corr(s) 曲线采样 ---")
    print(f"  {'e1':>8} | {'e2':>8} | {'dc1@-1':>8} | {'dc2@-1':>8} | {'dc1@0':>8} | {'dc2@0':>8} | {'dc1@0.5':>8} | {'dc2@0.5':>8} | {'dc1@1':>8} | {'dc2@1':>8}")
    print(f"  {'-'*8}-+-{'-'*8}-+-{'-'*8}-+-{'-'*8}-+-{'-'*8}-+-{'-'*8}-+-{'-'*8}-+-{'-'*8}-+-{'-'*8}-+-{'-'*8}")
    for key in sorted(outer):
        gid, e1, e2 = key
        if gid != 38: continue
        c1 = defect_corr_cache[(gid, e1)]
        c2 = defect_corr_cache[(gid, e2)]
        def val_at(arr, s_val):
            i = np.argmin(np.abs(s_vals - s_val))
            return arr[i]
        print(f"  {str(e1):>8} | {str(e2):>8} | "
              f"{val_at(c1,-1):>8.4f} | {val_at(c2,-1):>8.4f} | "
              f"{val_at(c1,0):>8.4f} | {val_at(c2,0):>8.4f} | "
              f"{val_at(c1,0.5):>8.4f} | {val_at(c2,0.5):>8.4f} | "
              f"{val_at(c1,1):>8.4f} | {val_at(c2,1):>8.4f}")

    # 图 38 与图 83/103/106/108 的对比
    print(f"\n  --- 图 38 与其他中环/外壳图的对比 ---")
    print(f"  {'gid':>4} | {'边数':>4} | {'轨道数':>6} | {'最大轨':>6} | {'桥数':>4} | {'Laplacian[1]':>12}")
    print(f"  {'-'*4}-+-{'-'*4}-+-{'-'*6}-+-{'-'*6}-+-{'-'*4}-+-{'-'*12}")
    for gid in [38, 31, 42, 60, 83, 103, 106, 108]:
        G = graphs[gid]
        L_eigs = np.linalg.eigvalsh(nx.laplacian_matrix(G).toarray())
        L1 = sorted(L_eigs)[1] if len(L_eigs) > 1 else 0
        n_orbits = len(set(all_orbits[gid].values()))
        max_orbit = max(Counter(all_orbits[gid].values()).values())
        n_bridges = len(list(nx.bridges(G)))
        print(f"  {gid:>4} | {len(all_edges[gid]):>4} | {n_orbits:>6} | {max_orbit:>6} | {n_bridges:>4} | {L1:>12.4f}")

    # ============================================================
    # Q3：硬核 corr_std 高，外壳低
    # ============================================================
    print("\n" + "=" * 100)
    print("Q3. 硬核 corr_std 高，外壳低。为什么？")
    print("=" * 100)

    # 在 s=0.5 处，比较三组的整体状态
    s_idx = np.argmin(np.abs(s_vals - 0.5))
    print(f"\n  s = {s_vals[s_idx]:.4f}")
    print(f"\n  {'组':>8} | {'对数':>4} | {'corr_std':>12} | {'corr_range':>12} | {'corr_entropy':>14} | {'n_edges':>8}")
    print(f"  {'-'*8}-+-{'-'*4}-+-{'-'*12}-+-{'-'*12}-+-{'-'*14}-+-{'-'*8}")

    for gname, group in [("硬核", hard_core), ("中环", middle), ("外壳", outer)]:
        if not group: continue
        stds, ranges, entropies, n_edges_list = [], [], [], []
        for gid, e1, e2 in group:
            for e in [e1, e2]:
                ov = overall_cache[(gid, e)]
                stds.append(ov["corr_std"][s_idx])
                ranges.append(ov["corr_range"][s_idx])
                entropies.append(ov["corr_entropy"][s_idx])
                n_edges_list.append(len(all_edges[gid]))
        print(f"  {gname:>8} | {len(group):>4} | {np.mean(stds):>12.6f} | "
              f"{np.mean(ranges):>12.6f} | {np.mean(entropies):>14.6f} | {np.mean(n_edges_list):>8.2f}")

    # 追问：corr_std 是否与图的边数相关？
    print(f"\n  --- 边数 vs corr_std 的关系 ---")
    print(f"  {'边数':>4} | {'对数':>4} | {'corr_std 均值':>14}")
    print(f"  {'-'*4}-+-{'-'*4}-+-{'-'*14}")
    n_edges_to_std = defaultdict(list)
    for key in all_same:
        gid, e1, e2 = key
        n_edges = len(all_edges[gid])
        for e in [e1, e2]:
            ov = overall_cache[(gid, e)]
            n_edges_to_std[n_edges].append(ov["corr_std"][s_idx])
    for n_edges in sorted(n_edges_to_std.keys()):
        stds = n_edges_to_std[n_edges]
        print(f"  {n_edges:>4} | {len(stds):>4} | {np.mean(stds):>14.6f}")

    # ============================================================
    # Q4：双谐振点是不是两种关系结构？
    # ============================================================
    print("\n" + "=" * 100)
    print("Q4. 双谐振点（低差异 vs 高差异）的关系结构")
    print("=" * 100)

    # 对每个同响应对，计算 s 上的平均整体状态差异
    print(f"\n  --- 同响应对按 Δdefect_corr 均值分组 ---")
    diff_data = []
    for key in sorted(all_same):
        gid, e1, e2 = key
        dc1 = defect_corr_cache[(gid, e1)]
        dc2 = defect_corr_cache[(gid, e2)]
        # 在 s ∈ [-1, 1] 上的平均差
        s_mask = (s_vals >= -1) & (s_vals <= 1)
        mean_diff = float(np.mean(np.abs(dc1[s_mask] - dc2[s_mask])))
        max_diff = float(np.max(np.abs(dc1[s_mask] - dc2[s_mask])))
        diff_data.append({
            "key": key, "mean_diff": mean_diff, "max_diff": max_diff
        })

    # 分两组：低差异（mean < 0.1）和高差异（mean > 0.1）
    low_diff = [d for d in diff_data if d["mean_diff"] < 0.1]
    high_diff = [d for d in diff_data if d["mean_diff"] >= 0.1]

    print(f"\n  低差异组（mean_diff < 0.1）: {len(low_diff)} 对")
    print(f"  高差异组（mean_diff ≥ 0.1）: {len(high_diff)} 对")

    for gname, group in [("低差异", low_diff), ("高差异", high_diff)]:
        print(f"\n  --- {gname} 组的关系特征分布 ---")
        gid_counter = Counter(d["key"][0] for d in group)
        print(f"    图分布: {dict(gid_counter)}")
        print(f"    按层: 硬核={sum(1 for d in group if d['key'] in hard_core)}"
              f", 中环={sum(1 for d in group if d['key'] in middle)}"
              f", 外壳={sum(1 for d in group if d['key'] in outer)}")
        # defect_corr 在 s=0.5 处的值
        s_idx_05 = np.argmin(np.abs(s_vals - 0.5))
        vals = []
        for d in group:
            gid, e1, e2 = d["key"]
            vals.append(defect_corr_cache[(gid, e1)][s_idx_05])
            vals.append(defect_corr_cache[(gid, e2)][s_idx_05])
        print(f"    dc@0.5 均值: {np.mean(vals):.4f}, 范围: [{np.min(vals):.4f}, {np.max(vals):.4f}]")
        # 代数识别
        ids = Counter(identify_algebraic(v) for v in vals)
        print(f"    dc@0.5 代数识别: {dict(ids)}")

    # ============================================================
    # Q5：谐振点在 s 空间是点、线、还是面？
    # ============================================================
    print("\n" + "=" * 100)
    print("Q5. 谐振点在 s 空间是点、线、还是面？")
    print("=" * 100)

    # 对每个同响应对，在 s ∈ [-2, 2] 上追踪 dc 曲线
    # 谐振点：dc1 和 dc2 同时等于同一个值（无论什么值）的 s
    print(f"\n  --- 谐振点：|dc1 - dc2| = 0 的 s 区间 ---")
    print(f"\n  {'组':>8} | {'对数':>4} | {'平均谐振点数':>14} | {'最长连续区间':>14}")
    print(f"  {'-'*8}-+-{'-'*4}-+-{'-'*14}-+-{'-'*14}")

    for gname, group in [("硬核", hard_core), ("中环", middle), ("外壳", outer)]:
        if not group: continue
        n_resonances = []
        longest_intervals = []
        for key in group:
            gid, e1, e2 = key
            dc1 = defect_corr_cache[(gid, e1)]
            dc2 = defect_corr_cache[(gid, e2)]
            diff = np.abs(dc1 - dc2)
            zero_mask = diff < 1e-9
            # 计数谐振点数
            n_resonances.append(int(zero_mask.sum()))
            # 最长连续区间
            max_run = 0
            cur_run = 0
            for v in zero_mask:
                if v:
                    cur_run += 1
                    max_run = max(max_run, cur_run)
                else:
                    cur_run = 0
            longest_intervals.append(max_run)
        print(f"  {gname:>8} | {len(group):>4} | "
              f"{np.mean(n_resonances):>14.2f} | {np.mean(longest_intervals):>14.2f}")

    # 整 s 范围的 dc 值识别
    print(f"\n  --- 所有同响应对的 dc 在 s 上的代数指纹统计 ---")
    all_dc_values = []
    for key in all_same:
        gid, e1, e2 = key
        for e in [e1, e2]:
            all_dc_values.extend(defect_corr_cache[(gid, e)].tolist())
    print(f"  dc 值总数: {len(all_dc_values)}")
    id_counter = Counter(identify_algebraic(v) for v in all_dc_values)
    print(f"\n  {'代数识别':>12} | {'出现次数':>8}")
    print(f"  {'-'*12}-+-{'-'*8}")
    for id_name, cnt in id_counter.most_common(20):
        print(f"  {id_name:>12} | {cnt:>8}")

    # ============================================================
    # 追问：±1/3 是精确值还是逼近？
    # ============================================================
    print("\n" + "=" * 100)
    print("追问：±1/3 的精确度（它是真 1/3，还是恰好接近）")
    print("=" * 100)

    print(f"\n  {'gid':>4} | {'e1':>8} | {'e2':>8} | {'s 点':>6} | {'dc':>14} | {'|dc - 1/3|':>14} | {'|dc + 1/3|':>14}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*8}-+-{'-'*6}-+-{'-'*14}-+-{'-'*14}-+-{'-'*14}")

    count_1_3 = 0
    for key in sorted(all_same):
        gid, e1, e2 = key
        for e in [e1, e2]:
            curve = defect_corr_cache[(gid, e)]
            for si, s in enumerate(s_vals):
                dc = curve[si]
                if abs(abs(dc) - 1/3) < 1e-6:
                    count_1_3 += 1
                    if count_1_3 <= 30:
                        print(f"  {gid:>4} | {str(e1):>8} | {str(e2):>8} | "
                              f"{s:>6.2f} | {dc:>14.10f} | {abs(dc - 1/3):>14.2e} | {abs(dc + 1/3):>14.2e}")
    print(f"\n  总命中（|dc ∓ 1/3| < 1e-6）: {count_1_3} 次")

    # 精确度检查：是否为 1/3 还是 0.333333
    print(f"\n  精确度检查（最接近 1/3 的 dc 值）:")
    closest = []
    for key in all_same:
        gid, e1, e2 = key
        for e in [e1, e2]:
            curve = defect_corr_cache[(gid, e)]
            for si, s in enumerate(s_vals):
                d = abs(abs(curve[si]) - 1/3)
                closest.append((d, gid, e, s, curve[si]))
    closest.sort()
    print(f"  {'gid':>4} | {'edge':>8} | {'s':>6} | {'dc':>16} | {'偏差':>12}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*6}-+-{'-'*16}-+-{'-'*12}")
    for d, gid, e, s, dc in closest[:20]:
        print(f"  {gid:>4} | {str(e):>8} | {s:>6.2f} | {dc:>16.12f} | {d:>12.2e}")

    # ============================================================
    # 导出
    # ============================================================
    out = {
        "Q1_zero_s": [{"key": list(d["key"]),
                       "zero_s": d["zero_s"],
                       "hit_1_3": d["hit_1_3"]}
                      for d in q1_data],
        "Q1_algebraic_stats": dict(id_counter),
        "Q4_low_diff": [{"key": list(d["key"]), "mean_diff": d["mean_diff"]}
                        for d in low_diff],
        "Q4_high_diff": [{"key": list(d["key"]), "mean_diff": d["mean_diff"]}
                         for d in high_diff],
    }
    out_path = os.path.join(WORK_DIR, "照妖镜_v6_谐振五问.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("v6.0 完成。五问并行。谐振点被攻击。")
    print("=" * 100)


if __name__ == "__main__":
    main()