#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 v21.0：核心层 24 对的图论解释
================================================================

核心层 24 对：
  - 全部来自 7 个图 (gid 9, 26, 33, 49, 55, 64, 69)
  - 缺陷边在 s ≤ 0.5 上 p_S ≡ 0
  - 无单一图论量统一

核心假设：
  核心对的缺陷边连接两个"等价子图"，使基态成为两个分量
  基态的直积，缺陷边形成纯三重态。

五个追问并行：
  Q1. 缺陷边断开后的两个连通分量是否同构？
  Q2. 两个分量的谱、度序列、大小对比
  Q3. 两个分量的基态总自旋 S_1 和 S_2
  Q4. 基态是否因子分解为两个分量基态的张量积？
  Q5. 7 个核心图的共同结构
"""

import sys, io, itertools, json, os
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from collections import Counter, defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"


# ============================================================
# 从 atlas 加载
# ============================================================

def build_atlas_graphs(N):
    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    return graphs


# ============================================================
# 子图的谱、度、基态分析
# ============================================================

def subgraph_features(sub):
    """分析一个子图的谱和结构特征"""
    n = sub.number_of_nodes()
    m = sub.number_of_edges()
    degs = sorted(d for _, d in sub.degree())
    L = nx.laplacian_matrix(sub).astype(float).toarray()
    L_eigs = sorted(np.linalg.eigvalsh(L))
    A = nx.to_numpy_array(sub)
    A_eigs = sorted(np.linalg.eigvalsh(A))
    return {
        "n_nodes": n, "n_edges": m,
        "deg_seq": tuple(degs),
        "L_eigs": tuple(round(e, 6) for e in L_eigs),
        "A_eigs": tuple(round(e, 6) for e in A_eigs),
    }


def build_edge_op(i, j, basis, idx):
    dim = len(basis)
    op = np.zeros((dim, dim), dtype=complex)
    for a_idx, state_a in enumerate(basis):
        sa, sb = state_a[i], state_a[j]
        if sa == sb:
            op[a_idx, a_idx] += 1
        else:
            op[a_idx, a_idx] += -1
            new_state = list(state_a)
            new_state[i], new_state[j] = new_state[j], new_state[i]
            b_idx = idx.get(tuple(new_state))
            if b_idx is not None:
                op[b_idx, a_idx] += 2
    return op


def build_sz0_sector(N):
    n_up = N // 2
    basis = []
    for comb in itertools.combinations(range(N), n_up):
        state = [0]*N
        for i in comb: state[i] = 1
        basis.append(tuple(state))
    dim = len(basis)
    idx = {s: i for i, s in enumerate(basis)}
    SZ_ops = []
    for site in range(N):
        SZ = np.zeros((dim, dim), dtype=complex)
        for i, state in enumerate(basis):
            SZ[i, i] = 1 if state[site] == 1 else -1
        SZ_ops.append(SZ)
    return basis, idx, SZ_ops


def build_S2_op(basis, idx, N):
    dim = len(basis)
    S2 = np.zeros((dim, dim), dtype=complex)
    for i in range(N):
        S2 += 3/4 * np.eye(dim, dtype=complex)
        for j in range(N):
            if i == j: continue
            S2 += 1/4 * build_edge_op(i, j, basis, idx)
    return S2


def component_gs_spin(sub, SXo_comp, SYo_comp, SZo_comp):
    """计算子图在自身 S_z=0 扇区的基态总自旋"""
    n = sub.number_of_nodes()
    if n == 1:
        return 0.5, 1
    n_up = n // 2
    basis = []
    for comb in itertools.combinations(range(n), n_up):
        state = [0]*n
        for i in comb: state[i] = 1
        basis.append(tuple(state))
    dim = len(basis)
    idx = {s: i for i, s in enumerate(basis)}
    H = np.zeros((dim, dim), dtype=complex)
    for (a, b) in sub.edges():
        op = build_edge_op(a, b, basis, idx)
        H += op
    if dim == 0:
        return 0.0, 0
    evals, evecs = eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < 1e-8))
    V = evecs[:, :deg]
    # S² 算符
    S2 = np.zeros((dim, dim), dtype=complex)
    for i in range(n):
        S2 += 3/4 * np.eye(dim, dtype=complex)
        for j in range(n):
            if i == j: continue
            S2 += 1/4 * build_edge_op(i, j, basis, idx)
    rho = V @ V.conj().T / deg
    S2_val = float(np.real(np.trace(rho @ S2)))
    S_val = (-1 + np.sqrt(1 + 4*max(S2_val, 0))) / 2
    return S_val, deg


# ============================================================
# 核心层对的完整分析
# ============================================================

def analyze_core_pair(G, defect, SXo, SYo, SZo, basis, idx, S2_op, ref_dim):
    """
    分析一个核心对：
    1. 断开缺陷边，找两个连通分量
    2. 比较两个分量的谱、度序列、大小
    3. 计算两个分量的基态总自旋
    4. 检查基态是否因子分解
    """
    G_broken = G.copy()
    G_broken.remove_edge(*defect)
    comps = list(nx.connected_components(G_broken))

    if len(comps) != 2:
        return {"n_comps": len(comps), "is_factorizable": False}

    # 重新标记节点
    comps = [sorted(c) for c in comps]
    # 哪个分量包含 defect[0]
    comp0 = comps[0] if defect[0] in comps[0] else comps[1]
    comp1 = comps[1] if comps[0] == comp0 else comps[0]

    sub0 = G_broken.subgraph(comp0).copy()
    sub1 = G_broken.subgraph(comp1).copy()
    sub0_relabeled = nx.convert_node_labels_to_integers(sub0)
    sub1_relabeled = nx.convert_node_labels_to_integers(sub1)

    # 结构特征
    f0 = subgraph_features(sub0_relabeled)
    f1 = subgraph_features(sub1_relabeled)

    # 是否同构
    is_iso = nx.is_isomorphic(sub0_relabeled, sub1_relabeled)

    # 谱比较
    spec_equal = (f0["L_eigs"] == f1["L_eigs"])
    deg_equal = (f0["deg_seq"] == f1["deg_seq"])

    # 分量基态自旋
    S_0, deg_0 = component_gs_spin(sub0_relabeled, SXo, SYo, SZo)
    S_1, deg_1 = component_gs_spin(sub1_relabeled, SXo, SYo, SZo)

    # 检查原始基态是否因子分解
    # 计算原始图在 s=0 处的基态
    edges = [tuple(sorted(e)) for e in G.edges()]
    edge_ops = {e: build_edge_op(e[0], e[1], basis, idx) for e in edges}
    H = np.zeros((ref_dim, ref_dim), dtype=complex)
    for e, M in edge_ops.items():
        c = 0.0 if e == defect else 1.0
        H += c * M
    evals, evecs = eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < 1e-8))

    # 检查基态是否是两个分量基态的张量积
    # 如果是，则基态应该对两个分量的量子数同时对角化
    # 简化检查：计算原始基态的 S²_total，看是否为 S_0 + S_1 的张量积

    # 计算 S²_total
    rho = evecs[:, :deg] @ evecs[:, :deg].conj().T / deg
    S2_val = float(np.real(np.trace(rho @ S2_op)))
    S_total = (-1 + np.sqrt(1 + 4*max(S2_val, 0))) / 2

    # 缺陷边的 ⟨σ·σ⟩
    sd = float(np.real(np.trace(rho @ edge_ops[defect])))

    # 因子分解检验：如果基态是 |S_0⟩ ⊗ |S_1⟩，则缺陷边的约化密度矩阵
    # 应该在两个 S=1/2 的耦合中形成 S_total 确定的态
    # 对于两个 S=1/2，p_S = 0 意味着 S_total 对应的态是三重态 |T_0⟩

    return {
        "n_comps": 2,
        "comp_sizes": (len(comp0), len(comp1)),
        "comp0_nodes": comp0, "comp1_nodes": comp1,
        "comp0_features": f0, "comp1_features": f1,
        "is_isomorphic": is_iso,
        "spec_equal": spec_equal,
        "deg_equal": deg_equal,
        "S_0": float(S_0), "S_1": float(S_1),
        "deg_comp_0": int(deg_0), "deg_comp_1": int(deg_1),
        "S_total": float(S_total),
        "deg_total": deg,
        "defect_sigdot": sd,
        "is_factorizable": (S_total == abs(S_0 - S_1) or
                            S_total == S_0 + S_1),
    }


def main():
    print("=" * 100)
    print("照妖镜 v21.0：核心层 24 对的图论解释")
    print("=" * 100)

    N = 6
    graphs = build_atlas_graphs(N)
    print(f"\n  N={N} 图集: {len(graphs)} 图")

    # 核心层的 7 个图
    core_gids = [9, 26, 33, 49, 55, 64, 69]
    print(f"  核心层 gid: {core_gids}")

    basis, idx, SZ_ops = build_sz0_sector(N)
    ref_dim = len(basis)
    S2_op = build_S2_op(basis, idx, N)
    print(f"  S_z=0 维度: {ref_dim}")

    # 从 v5.1 加载同响应对，筛选核心对
    with open(os.path.join(WORK_DIR, "照妖镜_v5_1_模式.json"), "r",
              encoding="utf-8") as f:
        v51 = json.load(f)

    # 核心层：24 对全 1 模式
    core_pairs = []
    for key, s in v51["patterns"].items():
        if s.count("1") == 24:
            gid, e1_str, e2_str = key.split("_", 2)
            gid = int(gid)
            e1 = tuple(map(int, e1_str.strip("()").split(",")))
            e2 = tuple(map(int, e2_str.strip("()").split(",")))
            core_pairs.append({"gid": gid, "e1": e1, "e2": e2})

    print(f"\n  核心对（24 全 1 模式）: {len(core_pairs)} 对")

    # 分析每个核心对
    results = []
    for i, cp in enumerate(core_pairs):
        gid = cp["gid"]
        e1 = cp["e1"]
        e2 = cp["e2"]
        G = graphs[gid]

        # 分析两条边（每条边都可以作为缺陷边）
        for defect in [e1, e2]:
            info = analyze_core_pair(G, defect, SZ_ops[0], SZ_ops[1], SZ_ops[2],
                                      basis, idx, S2_op, ref_dim)
            results.append({
                "pair_idx": i, "gid": gid,
                "defect": list(defect),
                "partner": list(e2 if defect == e1 else e1),
                **info,
            })

    # ============================================================
    # Q1: 两个分量是否同构？
    # ============================================================
    print("\n" + "=" * 100)
    print("Q1. 缺陷边断开后的两个分量是否同构？")
    print("=" * 100)

    n_iso = sum(1 for r in results if r.get("is_isomorphic", False))
    n_spec = sum(1 for r in results if r.get("spec_equal", False))
    n_deg = sum(1 for r in results if r.get("deg_equal", False))
    print(f"\n  总数: {len(results)}")
    print(f"  两个分量同构: {n_iso}/{len(results)} = {n_iso/len(results):.1%}")
    print(f"  Laplacian 谱相同: {n_spec}/{len(results)} = {n_spec/len(results):.1%}")
    print(f"  度序列相同: {n_deg}/{len(results)} = {n_deg/len(results):.1%}")

    # ============================================================
    # Q2: 两个分量的谱、度、大小对比
    # ============================================================
    print("\n" + "=" * 100)
    print("Q2. 两个分量的结构对比")
    print("=" * 100)

    print(f"\n  {'gid':>4} | {'defect':>8} | {'|C_0|':>5} | {'|C_1|':>5} | {'同构':>4} | {'谱同':>4} | {'度同':>4} | {'C_0 度序列':>20} | {'C_1 度序列':>20}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*5}-+-{'-'*5}-+-{'-'*4}-+-{'-'*4}-+-{'-'*4}-+-{'-'*20}-+-{'-'*20}")
    for r in results:
        if "comp0_features" not in r: continue
        f0 = r["comp0_features"]
        f1 = r["comp1_features"]
        print(f"  {r['gid']:>4} | {str(r['defect']):>8} | {f0['n_nodes']:>5} | "
              f"{f1['n_nodes']:>5} | {str(r['is_isomorphic']):>4} | "
              f"{str(r['spec_equal']):>4} | {str(r['deg_equal']):>4} | "
              f"{str(f0['deg_seq']):>20} | {str(f1['deg_seq']):>20}")

    # ============================================================
    # Q3: 两个分量的基态总自旋 S_0, S_1
    # ============================================================
    print("\n" + "=" * 100)
    print("Q3. 两个分量的基态总自旋")
    print("=" * 100)

    print(f"\n  {'gid':>4} | {'defect':>8} | {'S_0':>6} | {'S_1':>6} | {'S_total':>8} | {'S_0+S_1':>8} | {'缺陷边的 <σ·σ>':>16}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*6}-+-{'-'*6}-+-{'-'*8}-+-{'-'*8}-+-{'-'*16}")
    for r in results:
        if "S_0" not in r: continue
        sum_S = r['S_0'] + r['S_1']
        print(f"  {r['gid']:>4} | {str(r['defect']):>8} | {r['S_0']:>6.2f} | "
              f"{r['S_1']:>6.2f} | {r['S_total']:>8.4f} | {sum_S:>8.2f} | "
              f"{r['defect_sigdot']:>16.6f}")

    # ============================================================
    # Q4: 基态是否因子分解？
    # ============================================================
    print("\n" + "=" * 100)
    print("Q4. 基态是否因子分解为两个分量基态的张量积？")
    print("=" * 100)

    n_factor = sum(1 for r in results if r.get("is_factorizable", False))
    print(f"\n  因子分解（S_total = |S_0 - S_1| 或 S_0 + S_1）: "
          f"{n_factor}/{len(results)} = {n_factor/len(results):.1%}")

    # 对每条边，如果两个分量都是 S=1/2，则缺陷边耦合形成 S_total=1 的三重态
    # 这是 p_S = 0 的条件
    print(f"\n  --- 分量自旋类型统计 ---")
    spin_pairs = Counter()
    for r in results:
        if "S_0" in r:
            spin_pairs[(round(r['S_0'], 1), round(r['S_1'], 1))] += 1
    for pair, cnt in spin_pairs.most_common():
        print(f"    (S_0, S_1) = {pair}: {cnt} 个")

    # ============================================================
    # Q5: 7 个核心图的共同结构
    # ============================================================
    print("\n" + "=" * 100)
    print("Q5. 7 个核心图的共同结构")
    print("=" * 100)

    print(f"\n  {'gid':>4} | {'边数':>4} | {'|Aut|':>6} | {'度序列':>22} | {'桥数':>4} | {'核心对边集':>40}")
    print(f"  {'-'*4}-+-{'-'*4}-+-{'-'*6}-+-{'-'*22}-+-{'-'*4}-+-{'-'*40}")

    for gid in core_gids:
        G = graphs[gid]
        n_e = G.number_of_edges()
        # |Aut|
        GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
        n_autos = 0
        for _ in GM.isomorphisms_iter():
            n_autos += 1
            if n_autos > 500:
                break
        degs = tuple(sorted(d for _, d in G.degree()))
        n_bridges = len(list(nx.bridges(G)))
        # 该图的核心对
        pairs_in_g = [r for r in results if r['gid'] == gid]
        edges_in = set()
        for r in pairs_in_g:
            edges_in.add(tuple(r['defect']))
            edges_in.add(tuple(r['partner']))
        edge_str = ", ".join(str(tuple(sorted(e))) for e in sorted(edges_in))
        if len(edge_str) > 40:
            edge_str = edge_str[:37] + "..."
        print(f"  {gid:>4} | {n_e:>4} | {n_autos:>6} | {str(degs):>22} | "
              f"{n_bridges:>4} | {edge_str:>40}")

    # 关键分析：核心对边集覆盖的节点
    print(f"\n  --- 核心对边集覆盖的节点 ---")
    for gid in core_gids:
        G = graphs[gid]
        pairs_in_g = [r for r in results if r['gid'] == gid]
        nodes_in = set()
        for r in pairs_in_g:
            nodes_in.add(r['defect'][0])
            nodes_in.add(r['defect'][1])
            nodes_in.add(r['partner'][0])
            nodes_in.add(r['partner'][1])
        all_nodes = set(G.nodes())
        nodes_out = all_nodes - nodes_in
        print(f"  gid={gid}: 边集节点={sorted(nodes_in)}, 不参与节点={sorted(nodes_out)}")

    # ============================================================
    # 深度追问：两个分量的等价结构
    # ============================================================
    print("\n" + "=" * 100)
    print("深度追问：两个分量的等价结构")
    print("=" * 100)

    # 按 (|C_0|, |C_1|) 分组
    by_sizes = defaultdict(list)
    for r in results:
        if "comp0_features" in r:
            key = tuple(sorted([r["comp0_features"]["n_nodes"],
                                r["comp1_features"]["n_nodes"]]))
            by_sizes[key].append(r)

    print(f"\n  {'分量大小':>12} | {'数量':>6} | {'同构比例':>10} | {'共同 S 类型':>15}")
    print(f"  {'-'*12}-+-{'-'*6}-+-{'-'*10}-+-{'-'*15}")
    for key, group in sorted(by_sizes.items()):
        n_iso = sum(1 for r in group if r['is_isomorphic'])
        spins = Counter((round(r['S_0'], 1), round(r['S_1'], 1)) for r in group)
        most_common_spin = spins.most_common(1)[0] if spins else (None, 0)
        print(f"  {str(key):>12} | {len(group):>6} | "
              f"{n_iso/len(group):>9.1%} | {str(most_common_spin):>15}")

    # ============================================================
    # 导出
    # ============================================================
    out = {
        "n_core_pairs": len(core_pairs),
        "n_edge_analyses": len(results),
        "n_isomorphic": n_iso,
        "n_spec_equal": n_spec,
        "n_deg_equal": n_deg,
        "n_factorizable": n_factor,
        "results": [
            {k: (list(v) if isinstance(v, tuple) else v)
             for k, v in r.items()
             if k not in ("comp0_features", "comp1_features")}
            for r in results
        ],
    }
    out_path = os.path.join(WORK_DIR, "照妖镜_v21_核心层图论.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("v21.0 完成。核心层的图论结构被攻击。")
    print("=" * 100)


if __name__ == "__main__":
    main()