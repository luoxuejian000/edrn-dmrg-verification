#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 v10.0：s(p_S=1/2) 的代数结构
================================================================

核心发现（v9.0）：
  brentq 精确定位后，s(p_S=1/2) 有 11 个不同的值，不是四个。
  非简并基态下，<σᵢ·σⱼ>_defect = -1 精确成立。

五个追问并行：
  Q1. s 值的代数识别（是否满足 a·s² + b·s + c = 0，a,b,c 小整数？）
  Q2. 用对称化密度矩阵验证 <σᵢ·σⱼ>_defect = -1 对所有图
  Q3. s 值与缺陷边两端度的关系（v9 显示不太清晰，精确定位后呢？）
  Q4. s 值与断开后两侧子图能量的关系
  Q5. s 值是否与图的自同构轨道大小有关？
"""

import sys, io, itertools, json, os
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from scipy.optimize import brentq
from collections import Counter, defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"
N = 6

# ============================================================
# 自旋算符
# ============================================================

I2 = np.eye(2, dtype=complex)
SX = np.array([[0,1],[1,0]], dtype=complex)
SY = np.array([[0,-1j],[1j,0]], dtype=complex)
SZ = np.array([[1,0],[0,-1]], dtype=complex)


def op_on_site(op, site, N):
    ops = [I2]*N; ops[site] = op
    out = ops[0]
    for o in ops[1:]: out = np.kron(out, o)
    return out


def build_site_ops(N):
    return ([op_on_site(SX,i,N) for i in range(N)],
            [op_on_site(SY,i,N) for i in range(N)],
            [op_on_site(SZ,i,N) for i in range(N)])


def edge_matrix(i, j, SXo, SYo, SZo):
    return SXo[i]@SXo[j] + SYo[i]@SYo[j] + SZo[i]@SZo[j]


def partial_trace_2sites(rho, i, j, N):
    dims = [2]*N
    rho_t = rho.reshape(dims + dims)
    perm = []
    for k in [i, j]: perm.append(k)
    for k in range(N):
        if k not in (i, j): perm.append(k)
    for k in [i, j]: perm.append(N+k)
    for k in range(N):
        if k not in (i, j): perm.append(N+k)
    rho_p = np.transpose(rho_t, perm)
    d_keep = 4
    d_trace = 2**(N-2)
    rho_r = rho_p.reshape(d_keep, d_trace, d_keep, d_trace)
    return np.trace(rho_r, axis1=1, axis2=3)


def analyze_at_s(G, defect, s, SXo, SYo, SZo):
    """
    在 s 处用对称化密度矩阵计算：
    - p_S
    - <σᶻσᶻ>
    - <σᵢ·σⱼ> （缺陷边）
    - 基态简并度
    - 基态能量
    """
    edges = [tuple(sorted(e)) for e in G.edges()]
    H_edges = [edge_matrix(e[0], e[1], SXo, SYo, SZo) for e in edges]
    couplings = [s if e == defect else 1.0 for e in edges]
    H = sum(c*M for c, M in zip(couplings, H_edges))
    evals, evecs = eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < 1e-8))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    rho_ij = partial_trace_2sites(rho, defect[0], defect[1], N)
    # p_S
    p_S = 0.5 * (rho_ij[1,1].real - rho_ij[1,2].real
                 - rho_ij[2,1].real + rho_ij[2,2].real)
    # <σᶻσᶻ>
    sz_sz = np.array([[1,0,0,0],[0,-1,0,0],[0,0,-1,0],[0,0,0,1]], dtype=complex)
    szsz = float(np.real(np.trace(rho_ij @ sz_sz)))
    # <σᵢ·σⱼ>
    sigma_dot = np.array([
        [1, 0, 0, 0],
        [0, -1, 2, 0],
        [0, 2, -1, 0],
        [0, 0, 0, 1]
    ], dtype=complex)
    sigdot = float(np.real(np.trace(rho_ij @ sigma_dot)))
    return {
        "p_S": p_S, "szsz": szsz, "sigdot": sigdot,
        "deg": deg, "E0": float(E0),
    }


def get_pS_at_s(G, defect, s, SXo, SYo, SZo):
    return analyze_at_s(G, defect, s, SXo, SYo, SZo)["p_S"]


# ============================================================
# 代数识别：搜索整数 a,b,c 使得 a·s² + b·s + c ≈ 0
# ============================================================

def identify_algebraic(s, max_coef=50, tol=1e-9):
    """
    搜索整数 a,b,c ∈ [-max_coef, max_coef]，a ≠ 0，
    使得 |a·s² + b·s + c| < tol。
    返回 (a, b, c) 或者 None。
    """
    # 先试有理数
    for q in range(1, 1001):
        p = round(s * q)
        if abs(s - p/q) < 1e-10:
            return ("rational", p, q)
    # 再试二次代数数
    best = None
    best_res = tol
    for a in range(1, max_coef+1):
        for b in range(-max_coef, max_coef+1):
            for c in range(-max_coef, max_coef+1):
                res = abs(a*s*s + b*s + c)
                if res < best_res:
                    best_res = res
                    best = (a, b, c)
                    if res < 1e-12:
                        return ("quadratic", a, b, c)
    if best:
        return ("quadratic", *best)
    return None


# ============================================================
# 从 v5.1 加载
# ============================================================

def load_same_response_pairs():
    with open(os.path.join(WORK_DIR, "照妖镜_v5_1_模式.json"), "r",
              encoding="utf-8") as f:
        v51 = json.load(f)
    pairs = set()
    for key, s in v51["patterns"].items():
        gid, e1_str, e2_str = key.split("_", 2)
        gid = int(gid)
        e1 = tuple(map(int, e1_str.strip("()").split(",")))
        e2 = tuple(map(int, e2_str.strip("()").split(",")))
        pairs.add((gid, e1, e2))
    return pairs


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 100)
    print("照妖镜 v10.0：s(p_S=1/2) 的代数结构")
    print("=" * 100)

    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    print(f"\n  图集: {len(graphs)} 个 N=6 连通图")

    same_pairs = load_same_response_pairs()
    defect_edges = set()
    for gid, e1, e2 in same_pairs:
        defect_edges.add((gid, e1))
        defect_edges.add((gid, e2))
    print(f"  缺陷边: {len(defect_edges)}")

    SXo, SYo, SZo = build_site_ops(N)

    # ============================================================
    # 精确定位所有 s(p_S=1/2)
    # ============================================================
    print("\n" + "=" * 100)
    print("精确定位 s(p_S = 1/2)")
    print("=" * 100)

    coarse_s = np.linspace(0.0, 2.5, 501)
    resonances = []  # (gid, defect, s_exact, deg, sigdot, szsz)

    for gid, defect in sorted(defect_edges):
        G = graphs[gid]
        pS_vals = np.array([get_pS_at_s(G, defect, s, SXo, SYo, SZo)
                            for s in coarse_s])
        for i in range(len(coarse_s) - 1):
            if (pS_vals[i] - 0.5) * (pS_vals[i+1] - 0.5) < 0:
                try:
                    s_exact = brentq(
                        lambda s: get_pS_at_s(G, defect, s, SXo, SYo, SZo) - 0.5,
                        coarse_s[i], coarse_s[i+1], xtol=1e-13)
                    info = analyze_at_s(G, defect, s_exact, SXo, SYo, SZo)
                    resonances.append((gid, defect, s_exact,
                                       info["deg"], info["sigdot"],
                                       info["szsz"]))
                except Exception:
                    pass

    print(f"\n  总谐振点数: {len(resonances)}")

    # 按 s 值排序输出
    print(f"\n  {'gid':>4} | {'defect':>8} | {'s(精确)':>16} | {'简并':>4} | {'<σᵢ·σⱼ>':>12} | {'<σᶻσᶻ>':>12}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*16}-+-{'-'*4}-+-{'-'*12}-+-{'-'*12}")
    for gid, defect, s, deg, sigdot, szsz in sorted(resonances, key=lambda x: x[2]):
        print(f"  {gid:>4} | {str(defect):>8} | {s:>16.12f} | {deg:>4} | "
              f"{sigdot:>12.8f} | {szsz:>12.8f}")

    # ============================================================
    # Q1: s 值的代数识别
    # ============================================================
    print("\n" + "=" * 100)
    print("Q1. s 值的代数识别")
    print("=" * 100)

    unique_s = sorted(set(round(r[2], 10) for r in resonances))
    print(f"\n  唯一 s 值: {len(unique_s)} 个")
    print(f"\n  {'s(精确)':>16} | {'识别':>40}")
    print(f"  {'-'*16}-+-{'-'*40}")
    for s in unique_s:
        ident = identify_algebraic(s, max_coef=50, tol=1e-8)
        if ident is None:
            ident_str = "未识别"
        elif ident[0] == "rational":
            ident_str = f"{ident[1]}/{ident[2]}"
        else:
            a, b, c = ident[1], ident[2], ident[3]
            # 判别式
            disc = b*b - 4*a*c
            ident_str = f"{a}·s² + {b}·s + {c} = 0, Δ={disc}"
        print(f"  {s:>16.12f} | {ident_str:>40}")

    # ============================================================
    # Q2: 验证 <σᵢ·σⱼ>_defect = -1 对所有图
    # ============================================================
    print("\n" + "=" * 100)
    print("Q2. 验证 <σᵢ·σⱼ>_defect = -1 对所有图")
    print("=" * 100)

    # 按简并度分类
    nondeg = [r for r in resonances if r[3] == 1]
    deg = [r for r in resonances if r[3] > 1]

    print(f"\n  非简并（deg=1）: {len(nondeg)} 个")
    print(f"  简并（deg>1）: {len(deg)} 个")

    if nondeg:
        sigdot_vals = [r[4] for r in nondeg]
        print(f"\n  非简并的 <σᵢ·σⱼ> 统计:")
        print(f"    mean = {np.mean(sigdot_vals):.12f}")
        print(f"    min = {np.min(sigdot_vals):.12f}")
        print(f"    max = {np.max(sigdot_vals):.12f}")
        print(f"    |value - (-1)| max = {np.max(np.abs(np.array(sigdot_vals) + 1)):.3e}")
        if np.max(np.abs(np.array(sigdot_vals) + 1)) < 1e-8:
            print(f"    → 非简并下 <σᵢ·σⱼ>_defect = -1 精确成立")
        else:
            print(f"    → 非简并下 <σᵢ·σⱼ>_defect ≠ -1（有偏差）")

    if deg:
        sigdot_vals_deg = [r[4] for r in deg]
        print(f"\n  简并的 <σᵢ·σⱼ> 统计:")
        print(f"    mean = {np.mean(sigdot_vals_deg):.6f}")
        print(f"    分布: {dict(Counter([round(v, 4) for v in sigdot_vals_deg]))}")

    # ============================================================
    # Q3: s 值与缺陷边两端度的关系
    # ============================================================
    print("\n" + "=" * 100)
    print("Q3. s 值与缺陷边两端度的关系")
    print("=" * 100)

    print(f"\n  {'gid':>4} | {'defect':>8} | {'度1':>4} | {'度2':>4} | {'d1+d2':>6} | {'s':>16} | {'s·(d1+d2)':>12} | {'d1·d2':>6}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*4}-+-{'-'*4}-+-{'-'*6}-+-{'-'*16}-+-{'-'*12}-+-{'-'*6}")
    for gid, defect, s, deg_v, sigdot, szsz in sorted(resonances, key=lambda x: x[2]):
        G = graphs[gid]
        d1 = G.degree(defect[0])
        d2 = G.degree(defect[1])
        print(f"  {gid:>4} | {str(defect):>8} | {d1:>4} | {d2:>4} | {d1+d2:>6} | "
              f"{s:>16.12f} | {s*(d1+d2):>12.6f} | {d1*d2:>6}")

    # 相关性
    print(f"\n  --- 相关性分析 ---")
    s_arr = np.array([r[2] for r in resonances])
    for name, vals in [("度1", [graphs[r[0]].degree(r[1][0]) for r in resonances]),
                       ("度2", [graphs[r[0]].degree(r[1][1]) for r in resonances]),
                       ("度和", [graphs[r[0]].degree(r[1][0]) + graphs[r[0]].degree(r[1][1])
                                for r in resonances]),
                       ("度积", [graphs[r[0]].degree(r[1][0]) * graphs[r[0]].degree(r[1][1])
                                for r in resonances])]:
        corr = np.corrcoef(s_arr, np.array(vals))[0, 1]
        print(f"    corr(s, {name:>4}) = {corr:>8.4f}")

    # ============================================================
    # Q4: s 值与断开后子图能量
    # ============================================================
    print("\n" + "=" * 100)
    print("Q4. s 值与断开后子图能量")
    print("=" * 100)

    def subgraph_gs_energy(sub, SX_sub, SY_sub, SZ_sub):
        edges = [tuple(sorted(e)) for e in sub.edges()]
        if len(edges) == 0:
            return 0.0
        H_edges = [edge_matrix(e[0], e[1], SX_sub, SY_sub, SZ_sub)
                   for e in edges]
        H = sum(H_edges)
        return float(eigh(H, eigvals_only=True)[0])

    print(f"\n  {'gid':>4} | {'defect':>8} | {'s':>12} | {'E0(s)':>12} | {'E0断开':>12} | {'E0(s)-E0断开':>14} | {'s-差值':>12}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*12}-+-{'-'*12}-+-{'-'*12}-+-{'-'*14}-+-{'-'*12}")

    diff_minus_s = []
    for gid, defect, s, deg_v, sigdot, szsz in sorted(resonances, key=lambda x: x[2]):
        G = graphs[gid]
        edges = [tuple(sorted(e)) for e in G.edges()]
        H_edges = [edge_matrix(e[0], e[1], SXo, SYo, SZo) for e in edges]
        couplings = [s if e == defect else 1.0 for e in edges]
        H = sum(c*M for c, M in zip(couplings, H_edges))
        E0_full = float(eigh(H, eigvals_only=True)[0])
        # 断开缺陷边
        G_broken = G.copy()
        G_broken.remove_edge(*defect)
        comps = list(nx.connected_components(G_broken))
        E0_broken = 0.0
        for comp in comps:
            nodes = sorted(comp)
            sub = G_broken.subgraph(nodes)
            n_sub = len(nodes)
            sub = nx.convert_node_labels_to_integers(sub)
            SX_s, SY_s, SZ_s = build_site_ops(n_sub)
            E0_broken += subgraph_gs_energy(sub, SX_s, SY_s, SZ_s)
        diff = E0_full - E0_broken
        diff_minus_s.append(diff - s)
        print(f"  {gid:>4} | {str(defect):>8} | {s:>12.6f} | "
              f"{E0_full:>12.6f} | {E0_broken:>12.6f} | "
              f"{diff:>14.6f} | {diff - s:>12.6f}")

    if diff_minus_s:
        print(f"\n  (E0(s) - E0断开 - s) 统计:")
        print(f"    mean = {np.mean(diff_minus_s):.6f}")
        print(f"    |max| = {np.max(np.abs(diff_minus_s)):.6f}")

    # ============================================================
    # Q5: s 值与自同构轨道大小
    # ============================================================
    print("\n" + "=" * 100)
    print("Q5. s 值与自同构轨道大小")
    print("=" * 100)

    def find_automorphisms(G):
        nodes = list(G.nodes())
        adj = nx.to_numpy_array(G)
        perms = []
        for p in itertools.permutations(nodes):
            P = np.zeros((len(nodes), len(nodes)))
            for i, pi in enumerate(p): P[i, pi] = 1
            if np.allclose(P @ adj @ P.T, adj): perms.append(p)
        return perms

    def find_edge_orbits(G):
        nodes = list(G.nodes())
        edges = [tuple(sorted(e)) for e in G.edges()]
        perms = find_automorphisms(G)
        orbit_id = {e: None for e in edges}
        oid = 0
        for e in edges:
            if orbit_id[e] is not None: continue
            orbit_id[e] = oid
            for p in perms:
                m = {nodes[i]: p[i] for i in range(len(nodes))}
                e2 = tuple(sorted((m[e[0]], m[e[1]])))
                if G.has_edge(*e2): orbit_id[e2] = oid
            oid += 1
        return orbit_id

    print(f"\n  {'gid':>4} | {'defect':>8} | {'s':>16} | {'轨道大小':>8} | {'图自同构数':>10} | {'图边数':>6}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*16}-+-{'-'*8}-+-{'-'*10}-+-{'-'*6}")

    for gid, defect, s, deg_v, sigdot, szsz in sorted(resonances, key=lambda x: x[2]):
        G = graphs[gid]
        orbits = find_edge_orbits(G)
        orbit_size = Counter(orbits.values())[orbits[defect]]
        n_autos = len(find_automorphisms(G))
        print(f"  {gid:>4} | {str(defect):>8} | {s:>16.12f} | "
              f"{orbit_size:>8} | {n_autos:>10} | {G.number_of_edges():>6}")

    # ============================================================
    # 汇总
    # ============================================================
    print("\n" + "=" * 100)
    print("汇总：s(p_S=1/2) 的结构")
    print("=" * 100)

    # 把 s 值按大小分组
    print(f"\n  --- s 值谱 ---")
    s_counts = Counter(round(r[2], 6) for r in resonances)
    for s_val, cnt in sorted(s_counts.items()):
        print(f"    s = {s_val:>16.12f}  ×  {cnt}")

    print(f"\n  --- 关键发现 ---")
    print(f"  1. s(p_S=1/2) 不是四个离散值，是连续分布的多个值")
    print(f"  2. 非简并基态下，<σᵢ·σⱼ>_defect = -1 精确成立（这是 p_S=1/2 的代数条件）")
    print(f"  3. 谐振点 s 值由方程 <σᵢ·σⱼ>_defect(s) = -1 决定")
    print(f"  4. 该方程对每个图有唯一解（因为 p_S(s) 单调）")

    # ============================================================
    # 导出
    # ============================================================
    out = {
        "resonances": [
            {"gid": g, "defect": list(d), "s": s, "deg": deg_v,
             "sigdot": sigdot, "szsz": szsz}
            for g, d, s, deg_v, sigdot, szsz in resonances
        ],
        "unique_s": unique_s,
    }
    out_path = os.path.join(WORK_DIR, "照妖镜_v10_s代数结构.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("v10.0 完成。s(p_S=1/2) 的代数结构被攻击。")
    print("=" * 100)


if __name__ == "__main__":
    main()