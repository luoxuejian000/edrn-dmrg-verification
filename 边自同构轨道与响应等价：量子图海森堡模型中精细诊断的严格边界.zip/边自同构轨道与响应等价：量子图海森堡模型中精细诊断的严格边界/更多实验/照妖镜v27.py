#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 v27.0：12 图的共同结构
================================================================

v26 发现：
  - 35 对 pS_equal 来自 12 个图
  - 7 图只贡献核心对，5 图只贡献中环对
  - 核心图的 pS 曲线高度 0.2319，中环图 0.1067

新问题：
  Q1. 为什么是这 12 个图？它们的共同结构是什么？
  Q2. 剩余 100 个图为什么没有 pS_equal 对？
  Q3. 7 核心图 vs 5 中环图：图论差异是什么？
  Q4. pS 曲线高度与图的什么量相关？
  Q5. 是否存在一个关系不变量，同时预测 pS_equal 和高度？
"""

import sys, io, itertools, json, os
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from collections import Counter, defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"


# ============================================================
# 图集
# ============================================================

def build_atlas_graphs(N):
    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    return graphs


# ============================================================
# 图级特征
# ============================================================

def graph_level_features(G):
    """一个图的全部图级特征"""
    n = G.number_of_nodes()
    m = G.number_of_edges()

    # 度
    degs = [d for _, d in G.degree()]
    deg_min, deg_max = min(degs), max(degs)
    deg_mean = np.mean(degs)
    deg_std = np.std(degs)

    # 谱
    L = nx.laplacian_matrix(G).astype(float).toarray()
    L_eigs = sorted(np.linalg.eigvalsh(L))
    L_gap = L_eigs[1] if len(L_eigs) > 1 else 0
    L_max = L_eigs[-1]
    A = nx.to_numpy_array(G)
    A_eigs = sorted(np.linalg.eigvalsh(A))
    A_radius = A_eigs[-1]
    A_gap = A_eigs[-1] - A_eigs[-2] if len(A_eigs) > 1 else 0

    # 自同构
    GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
    n_autos = 0
    for _ in GM.isomorphisms_iter():
        n_autos += 1
        if n_autos > 2000:
            break

    # 拓扑
    n_bridges = len(list(nx.bridges(G)))
    n_triangles = sum(nx.triangles(G).values()) // 3
    try:
        cycle_rank = m - n + 1
    except Exception:
        cycle_rank = 0

    # 度分布熵
    deg_cnt = Counter(degs)
    deg_entropy = 0.0
    for d, c in deg_cnt.items():
        p = c / n
        if p > 0:
            deg_entropy -= p * np.log(p)

    # 最大团
    try:
        max_clique = max(len(c) for c in nx.find_cliques(G))
    except Exception:
        max_clique = 1

    # 边轨道数
    edges = [tuple(sorted(e)) for e in G.edges()]
    orbits = {}
    GM2 = nx.algorithms.isomorphism.GraphMatcher(G, G)
    autos = []
    for a in GM2.isomorphisms_iter():
        autos.append(a)
        if len(autos) > 500:
            break
    for e in edges:
        orbit = frozenset(frozenset({a[e[0]], a[e[1]]}) for a in autos)
        orbits[e] = orbit
    orbit_sizes = sorted(Counter(orbits.values()).values())

    # 是否是正则图
    is_regular = (deg_min == deg_max)

    return {
        "n_edges": m,
        "deg_min": deg_min, "deg_max": deg_max,
        "deg_mean": float(deg_mean), "deg_std": float(deg_std),
        "deg_entropy": float(deg_entropy),
        "L_gap": float(L_gap), "L_max": float(L_max),
        "A_radius": float(A_radius), "A_gap": float(A_gap),
        "n_autos": n_autos,
        "n_bridges": n_bridges,
        "n_triangles": n_triangles,
        "cycle_rank": cycle_rank,
        "max_clique": max_clique,
        "n_orbits": len(orbits),
        "orbit_sizes": orbit_sizes,
        "is_regular": is_regular,
    }


# ============================================================
# S_z=0 扇区（用于计算 pS 曲线）
# ============================================================

def build_sz0_sector(N):
    n_up = N // 2
    basis = []
    for comb in itertools.combinations(range(N), n_up):
        state = [0]*N
        for i in comb: state[i] = 1
        basis.append(tuple(state))
    dim = len(basis)
    idx = {s: i for i, s in enumerate(basis)}
    SZ_ops = []
    for site in range(N):
        SZ = np.zeros((dim, dim), dtype=complex)
        for i, state in enumerate(basis):
            SZ[i, i] = 1 if state[site] == 1 else -1
        SZ_ops.append(SZ)
    return basis, idx, SZ_ops


def build_edge_op(i, j, basis, idx):
    dim = len(basis)
    op = np.zeros((dim, dim), dtype=complex)
    for a_idx, state_a in enumerate(basis):
        sa, sb = state_a[i], state_a[j]
        if sa == sb:
            op[a_idx, a_idx] += 1
        else:
            op[a_idx, a_idx] += -1
            new_state = list(state_a)
            new_state[i], new_state[j] = new_state[j], new_state[i]
            b_idx = idx.get(tuple(new_state))
            if b_idx is not None:
                op[b_idx, a_idx] += 2
    return op


def pS_curve(edge_ops, defect, s_grid, SZ_ops, ref_dim):
    curve = []
    for s in s_grid:
        H = np.zeros((ref_dim, ref_dim), dtype=complex)
        for e, M in edge_ops.items():
            c = s if e == defect else 1.0
            H += c * M
        try:
            evals, evecs = eigh(H)
        except Exception:
            curve.append(np.nan)
            continue
        E0 = evals[0]
        deg = int(np.sum(np.abs(evals - E0) < 1e-8))
        V = evecs[:, :deg]
        rho = V @ V.conj().T / deg
        i, j = defect
        szsz_diag = np.diag(SZ_ops[i] @ SZ_ops[j])
        szsz = float(np.real(np.sum(np.diag(rho) * szsz_diag)))
        p_S = (1 - 3 * szsz) / 4
        curve.append(p_S)
    return np.array(curve)


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 100)
    print("照妖镜 v27.0：12 图的共同结构")
    print("=" * 100)

    N = 6
    graphs = build_atlas_graphs(N)
    print(f"\n  N={N} 图集: {len(graphs)} 图")

    # v26 报告的 12 个 pS_equal 图
    core_gids = [9, 26, 33, 49, 55, 64, 69]
    middle_gids = [31, 42, 83, 106, 108]
    pS_equal_gids = core_gids + middle_gids
    other_gids = [g for g in range(len(graphs)) if g not in pS_equal_gids]
    print(f"  核心图 (7): {core_gids}")
    print(f"  中环图 (5): {middle_gids}")
    print(f"  其他图: {len(other_gids)}")

    # ============================================================
    # Q1: 12 图的全部图级特征
    # ============================================================
    print("\n" + "=" * 100)
    print("Q1. 12 个 pS_equal 图的图级特征")
    print("=" * 100)

    print(f"\n  {'gid':>4} | {'组':>4} | {'边数':>4} | {'|Aut|':>6} | {'度范围':>10} | "
          f"{'度熵':>6} | {'L 间隙':>8} | {'L max':>6} | {'A 半径':>8} | "
          f"{'桥':>4} | {'三角形':>6} | {'最大团':>6} | {'正则':>4}")
    print(f"  {'-'*4}-+-{'-'*4}-+-{'-'*4}-+-{'-'*6}-+-{'-'*10}-+-"
          f"{'-'*6}-+-{'-'*8}-+-{'-'*6}-+-{'-'*8}-+-{'-'*4}-+-{'-'*6}-+-{'-'*6}-+-{'-'*4}")

    all_features = {}
    for gid in sorted(pS_equal_gids):
        G = graphs[gid]
        f = graph_level_features(G)
        all_features[gid] = f
        group = "C" if gid in core_gids else "M"
        deg_range = "({},{})".format(f["deg_min"], f["deg_max"])
        print(f"  {gid:>4} | {group:>4} | {f['n_edges']:>4} | {f['n_autos']:>6} | "
              f"{deg_range:>10} | {f['deg_entropy']:>6.3f} | "
              f"{f['L_gap']:>8.4f} | {f['L_max']:>6.2f} | {f['A_radius']:>8.4f} | "
              f"{f['n_bridges']:>4} | {f['n_triangles']:>6} | "
              f"{f['max_clique']:>6} | {str(f['is_regular']):>4}")

    # ============================================================
    # Q2: 12 图 vs 其他图的特征对比
    # ============================================================
    print("\n" + "=" * 100)
    print("Q2. 12 pS_equal 图 vs 100 非 pS_equal 图")
    print("=" * 100)

    # 其他图的特征（抽样，避免太慢）
    other_features = []
    for gid in other_gids[:40]:
        G = graphs[gid]
        f = graph_level_features(G)
        other_features.append(f)

    print(f"\n  {'特征':>18} | {'pS_equal(12)':>15} | {'其他(40)':>15} | {'差值':>10}")
    print(f"  {'-'*18}-+-{'-'*15}-+-{'-'*15}-+-{'-'*10}")

    for fname in ["n_edges", "n_autos", "deg_min", "deg_max", "deg_mean",
                  "deg_std", "deg_entropy", "L_gap", "L_max", "A_radius",
                  "A_gap", "n_bridges", "n_triangles", "cycle_rank",
                  "max_clique", "n_orbits"]:
        eq_vals = [all_features[gid][fname] for gid in pS_equal_gids]
        other_vals = [f[fname] for f in other_features]
        eq_mean = np.mean(eq_vals)
        other_mean = np.mean(other_vals)
        diff = eq_mean - other_mean
        print(f"  {fname:>18} | {eq_mean:>15.4f} | {other_mean:>15.4f} | {diff:>+10.4f}")

    # ============================================================
    # Q3: 7 核心图 vs 5 中环图
    # ============================================================
    print("\n" + "=" * 100)
    print("Q3. 7 核心图 vs 5 中环图：图论差异")
    print("=" * 100)

    print(f"\n  {'特征':>18} | {'核心(7)':>15} | {'中环(5)':>15} | {'差值':>10}")
    print(f"  {'-'*18}-+-{'-'*15}-+-{'-'*15}-+-{'-'*10}")

    for fname in ["n_edges", "n_autos", "deg_min", "deg_max", "deg_mean",
                  "deg_std", "deg_entropy", "L_gap", "L_max", "A_radius",
                  "A_gap", "n_bridges", "n_triangles", "cycle_rank",
                  "max_clique", "n_orbits"]:
        core_vals = [all_features[gid][fname] for gid in core_gids]
        mid_vals = [all_features[gid][fname] for gid in middle_gids]
        core_mean = np.mean(core_vals)
        mid_mean = np.mean(mid_vals)
        diff = core_mean - mid_mean
        print(f"  {fname:>18} | {core_mean:>15.4f} | {mid_mean:>15.4f} | {diff:>+10.4f}")

    # ============================================================
    # Q4: pS 高度与图级特征的相关性
    # ============================================================
    print("\n" + "=" * 100)
    print("Q4. pS 曲线高度 vs 图级特征的相关性")
    print("=" * 100)

    # 从 v26 数据中，核心/中环的 pS 高度
    core_heights = {
        9: 0.789, 26: 0.227, 33: 0.516, 49: 0.522,
        55: 0.522, 64: 0.167, 69: 0.049,
    }
    middle_heights = {
        31: 0.173, 42: 0.077, 83: 0.177,
        106: 0.069, 108: 0.060,
    }
    height_by_gid = {**core_heights, **middle_heights}

    # 计算每个图级特征与 pS 高度的相关性
    print(f"\n  {'特征':>18} | {'相关系数':>12}")
    print(f"  {'-'*18}-+-{'-'*12}")

    for fname in ["n_edges", "n_autos", "deg_min", "deg_max", "deg_mean",
                  "deg_std", "deg_entropy", "L_gap", "L_max", "A_radius",
                  "A_gap", "n_bridges", "n_triangles", "cycle_rank",
                  "max_clique", "n_orbits"]:
        feat_vals = []
        heights = []
        for gid in pS_equal_gids:
            feat_vals.append(all_features[gid][fname])
            heights.append(height_by_gid[gid])
        if len(set(feat_vals)) > 1:
            corr = np.corrcoef(feat_vals, heights)[0, 1]
            print(f"  {fname:>18} | {corr:>+12.4f}")

    # ============================================================
    # Q5: 边轨道结构对比
    # ============================================================
    print("\n" + "=" * 100)
    print("Q5. 12 pS_equal 图的轨道结构")
    print("=" * 100)

    print(f"\n  {'gid':>4} | {'组':>4} | {'边数':>4} | {'轨道数':>6} | {'轨道大小':>30}")
    print(f"  {'-'*4}-+-{'-'*4}-+-{'-'*4}-+-{'-'*6}-+-{'-'*30}")

    for gid in sorted(pS_equal_gids):
        G = graphs[gid]
        f = all_features[gid]
        group = "C" if gid in core_gids else "M"
        print(f"  {gid:>4} | {group:>4} | {f['n_edges']:>4} | {f['n_orbits']:>6} | "
              f"{str(f['orbit_sizes']):>30}")

    # ============================================================
    # 深度追问：12 图的边集覆盖与核心对涉及节点
    # ============================================================
    print("\n" + "=" * 100)
    print("深度追问：12 图的节点覆盖结构")
    print("=" * 100)

    print(f"\n  {'gid':>4} | {'组':>4} | {'节点集':>20} | {'图结构':>35}")
    print(f"  {'-'*4}-+-{'-'*4}-+-{'-'*20}-+-{'-'*35}")

    for gid in sorted(pS_equal_gids):
        G = graphs[gid]
        group = "C" if gid in core_gids else "M"
        nodes = sorted(G.nodes())
        edges_str = "[" + ", ".join(str(tuple(sorted(e))) for e in G.edges()) + "]"
        if len(edges_str) > 33:
            edges_str = edges_str[:30] + "..."
        print(f"  {gid:>4} | {group:>4} | {str(nodes):>20} | {edges_str:>35}")

    # ============================================================
    # 关键：pS_equal 是否与图的边轨道结构相关？
    # ============================================================
    print("\n" + "=" * 100)
    print("深度追问：pS_equal 与边轨道结构的关系")
    print("=" * 100)

    # 检查 12 图的边轨道大小之和
    print(f"\n  {'gid':>4} | {'组':>4} | {'轨道数':>6} | {'最大轨道':>8} | "
          f"{'最小轨道':>8} | {'轨道熵':>8} | {'pS 高度':>8}")
    print(f"  {'-'*4}-+-{'-'*4}-+-{'-'*6}-+-{'-'*8}-+-{'-'*8}-+-{'-'*8}-+-{'-'*8}")

    for gid in sorted(pS_equal_gids):
        G = graphs[gid]
        group = "C" if gid in core_gids else "M"
        orbits = {}
        GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
        autos = []
        for a in GM.isomorphisms_iter():
            autos.append(a)
            if len(autos) > 500:
                break
        edges = [tuple(sorted(e)) for e in G.edges()]
        for e in edges:
            orbit = frozenset(frozenset({a[e[0]], a[e[1]]}) for a in autos)
            orbits[e] = orbit
        orbit_sizes = list(Counter(orbits.values()).values())
        # 轨道熵
        total = sum(orbit_sizes)
        orbit_entropy = 0.0
        for s in orbit_sizes:
            p = s / total
            if p > 0:
                orbit_entropy -= p * np.log(p)
        height = height_by_gid[gid]
        print(f"  {gid:>4} | {group:>4} | {len(orbit_sizes):>6} | "
              f"{max(orbit_sizes):>8} | {min(orbit_sizes):>8} | "
              f"{orbit_entropy:>8.4f} | {height:>8.4f}")

    # 相关性
    print(f"\n  --- 轨道特征与 pS 高度的相关性 ---")
    for feat_name, feat_func in [
        ("轨道数", lambda o: len(o)),
        ("最大轨道", lambda o: max(o)),
        ("轨道熵", lambda o: sum(-(s/sum(o))*np.log(s/sum(o)) for s in o)),
    ]:
        feat_vals = []
        heights = []
        for gid in pS_equal_gids:
            G = graphs[gid]
            GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
            autos = []
            for a in GM.isomorphisms_iter():
                autos.append(a)
                if len(autos) > 500:
                    break
            edges = [tuple(sorted(e)) for e in G.edges()]
            orbits = {}
            for e in edges:
                orbit = frozenset(frozenset({a[e[0]], a[e[1]]}) for a in autos)
                orbits[e] = orbit
            orbit_sizes = list(Counter(orbits.values()).values())
            feat_vals.append(feat_func(orbit_sizes))
            heights.append(height_by_gid[gid])
        if len(set(feat_vals)) > 1:
            corr = np.corrcoef(feat_vals, heights)[0, 1]
            print(f"  {feat_name:>12} | 相关系数 = {corr:>+8.4f}")

    # ============================================================
    # 导出
    # ============================================================
    out = {
        "core_gids": core_gids,
        "middle_gids": middle_gids,
        "all_features": {str(gid): all_features[gid] for gid in all_features},
        "heights": height_by_gid,
    }
    out_path = os.path.join(WORK_DIR, "照妖镜_v27_12图结构.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("v27.0 完成。12 图的共同结构被攻击。")
    print("=" * 100)


if __name__ == "__main__":
    main()