#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 v18.0：简并子空间在 S_edge² 下是否闭合？
================================================================

v17 发现：
  - S_edge² 对角化后 N=6 提升 9.8%，N=7 提升 0%
  - S_edge² 谱本身有非整数值 (2.2321, 7.256) —— 不是 {0, 8}
  - S² 和 S_edge² 在简并子空间内对易，但和 H 不对易

核心问题：
  简并子空间在 S_edge² 作用下是否闭合？
  如果不闭合，那非整数 ⟨σ·σ⟩ 来自简并子空间外的态泄漏。

五个追问并行：
  Q1. 简并子空间 V_degen 在 S_edge² 作用后的泄漏量
  Q2. S_edge² 投影谱的非整数值与泄漏量的关系
  Q3. [S_edge², H] 的对易性
  Q4. 简并子空间在 S² 和 S_edge² 共同作用下是否闭合？
  Q5. 如果 V_degen 在 S_edge² 下不闭合，能否找到"闭合子空间"？
"""

import sys, io, itertools, json, os
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from scipy.optimize import brentq
from collections import Counter, defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"


def build_sz0_sector(N):
    n_up = N // 2
    basis = []
    for comb in itertools.combinations(range(N), n_up):
        state = [0]*N
        for i in comb: state[i] = 1
        basis.append(tuple(state))
    dim = len(basis)
    idx = {s: i for i, s in enumerate(basis)}
    SZ_ops = []
    for site in range(N):
        SZ = np.zeros((dim, dim), dtype=complex)
        for i, state in enumerate(basis):
            SZ[i, i] = 1 if state[site] == 1 else -1
        SZ_ops.append(SZ)
    return basis, idx, SZ_ops


def build_edge_op(i, j, basis, idx):
    dim = len(basis)
    op = np.zeros((dim, dim), dtype=complex)
    for a_idx, state_a in enumerate(basis):
        sa, sb = state_a[i], state_a[j]
        if sa == sb:
            op[a_idx, a_idx] += 1
        else:
            op[a_idx, a_idx] += -1
            new_state = list(state_a)
            new_state[i], new_state[j] = new_state[j], new_state[i]
            b_idx = idx.get(tuple(new_state))
            if b_idx is not None:
                op[b_idx, a_idx] += 2
    return op


def build_S2_op(basis, idx, N):
    dim = len(basis)
    S2 = np.zeros((dim, dim), dtype=complex)
    for i in range(N):
        S2 += 3/4 * np.eye(dim, dtype=complex)
        for j in range(N):
            if i == j: continue
            S2 += 1/4 * build_edge_op(i, j, basis, idx)
    return S2


def analyze_degenerate(edge_ops, defect, s, SZ_ops, S2_op, ref_dim):
    """
    分析简并子空间的闭合性：
    1. 在简并子空间内投影 S_edge² 和 S²
    2. 计算 S_edge² 对简并子空间的泄漏量
    3. 检查 [S_edge², H] 在简并子空间内的对易性
    4. 投影后 S_edge² 的特征值
    """
    H = np.zeros((ref_dim, ref_dim), dtype=complex)
    for e, M in edge_ops.items():
        c = s if e == defect else 1.0
        H += c * M

    evals, evecs = eigh(H)
    E0 = evals[0]
    degen_mask = np.abs(evals - E0) < 1e-8
    deg = int(np.sum(degen_mask))
    V = evecs[:, degen_mask]  # (dim, deg)
    V_out = evecs[:, ~degen_mask]  # (dim, dim-deg)

    # S_edge² = 6I + 2 σ_i·σ_j（σ 约定）
    S_edge_sq = 6 * np.eye(ref_dim, dtype=complex) + 2 * edge_ops[defect]

    # (1) 泄漏量：||(I - V V^T) S_edge² V||
    proj_in = V @ V.conj().T
    proj_out = np.eye(ref_dim) - proj_in
    leak_S_edge = proj_out @ S_edge_sq @ V
    leak_S_edge_norm = float(np.linalg.norm(leak_S_edge))

    # (2) S² 泄漏
    leak_S2 = proj_out @ S2_op @ V
    leak_S2_norm = float(np.linalg.norm(leak_S2))

    # (3) [S_edge², H] 泄漏（在简并子空间内）
    comm_S_edge_H = S_edge_sq @ H - H @ S_edge_sq
    comm_proj = V.conj().T @ comm_S_edge_H @ V
    comm_norm = float(np.linalg.norm(comm_proj))

    # (4) S_edge² 投影后的谱
    M_edge = V.conj().T @ S_edge_sq @ V
    edge_eigs = sorted(np.linalg.eigvalsh(M_edge))

    # (5) S² 投影后的谱
    M_S2 = V.conj().T @ S2_op @ V
    s2_eigs = sorted(np.linalg.eigvalsh(M_S2))

    # (6) 同时对角化 S² 和 S_edge²
    comm_in = M_S2 @ M_edge - M_edge @ M_S2
    comm_in_norm = float(np.linalg.norm(comm_in))

    # (7) 每个原始简并态的 ⟨σ·σ⟩
    raw_sds = []
    for k in range(deg):
        v = V[:, k]
        sd = float(np.real(v.conj() @ edge_ops[defect] @ v))
        raw_sds.append(sd)
    n_int = sum(1 for x in raw_sds if abs(x - round(x)) < 1e-6)

    return {
        "s": s, "deg": deg,
        "leak_S_edge": leak_S_edge_norm,
        "leak_S2": leak_S2_norm,
        "comm_S_edge_H": comm_norm,
        "comm_in_S2_S_edge": comm_in_norm,
        "edge_eigs": [float(x) for x in edge_eigs],
        "s2_eigs": [float(x) for x in s2_eigs],
        "raw_sds": raw_sds,
        "n_int": n_int,
        "deg_int_rate": n_int / deg if deg > 0 else 0,
    }


def build_atlas_graphs(N):
    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    return graphs


def run_analysis(N, max_graphs=None, sample_edges=3, label=""):
    print(f"\n{'='*80}")
    print(f"  N={N} 简并子空间闭合性分析 {label}")
    print(f"{'='*80}")

    graphs = build_atlas_graphs(N)
    if max_graphs:
        step = max(1, len(graphs) // max_graphs)
        graphs = graphs[::step][:max_graphs]
    print(f"  图集: {len(graphs)} 图")

    basis, idx, SZ_ops = build_sz0_sector(N)
    ref_dim = len(basis)
    print(f"  S_z=0 维度: {ref_dim}")

    S2_op = build_S2_op(basis, idx, N)

    degenerate_points = []

    for gid, G in enumerate(graphs):
        edges = [tuple(sorted(e)) for e in G.edges()]
        edge_ops = {e: build_edge_op(e[0], e[1], basis, idx) for e in edges}
        for defect in edges[:sample_edges]:
            # 粗扫
            s_grid = np.linspace(-2.0, 2.5, 61)
            pS_vals = []
            for s in s_grid:
                H = np.zeros((ref_dim, ref_dim), dtype=complex)
                for e, M in edge_ops.items():
                    c = s if e == defect else 1.0
                    H += c * M
                try:
                    evals, evecs = eigh(H)
                except Exception:
                    pS_vals.append(0.0)
                    continue
                E0 = evals[0]
                deg = int(np.sum(np.abs(evals - E0) < 1e-8))
                Vv = evecs[:, :deg]
                rho = Vv @ Vv.conj().T / deg
                i, j = defect
                szsz_diag = np.diag(SZ_ops[i] @ SZ_ops[j])
                szsz = float(np.real(np.sum(np.diag(rho) * szsz_diag)))
                pS_vals.append((1 - 3 * szsz) / 4)
            pS_vals = np.array(pS_vals)

            for k in range(len(s_grid) - 1):
                if (pS_vals[k] - 0.5) * (pS_vals[k+1] - 0.5) < 0:
                    try:
                        s_res = brentq(
                            lambda s: _pS(edge_ops, defect, s, SZ_ops, ref_dim) - 0.5,
                            s_grid[k], s_grid[k+1], xtol=1e-10)
                        H = np.zeros((ref_dim, ref_dim), dtype=complex)
                        for e, M in edge_ops.items():
                            c = s_res if e == defect else 1.0
                            H += c * M
                        evals = np.linalg.eigvalsh(H)
                        deg = int(np.sum(np.abs(evals - evals[0]) < 1e-8))
                        if deg > 1:
                            info = analyze_degenerate(
                                edge_ops, defect, s_res, SZ_ops,
                                S2_op, ref_dim)
                            degenerate_points.append({
                                "gid": gid, "defect": list(defect), **info
                            })
                    except Exception:
                        pass

    print(f"  简并谐振点: {len(degenerate_points)}")
    return degenerate_points


def _pS(edge_ops, defect, s, SZ_ops, ref_dim):
    H = np.zeros((ref_dim, ref_dim), dtype=complex)
    for e, M in edge_ops.items():
        c = s if e == defect else 1.0
        H += c * M
    evals, evecs = eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < 1e-8))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    i, j = defect
    szsz_diag = np.diag(SZ_ops[i] @ SZ_ops[j])
    szsz = float(np.real(np.sum(np.diag(rho) * szsz_diag)))
    return (1 - 3 * szsz) / 4


def main():
    print("=" * 100)
    print("照妖镜 v18.0：简并子空间在 S_edge² 下是否闭合？")
    print("=" * 100)

    points_N7 = run_analysis(7, max_graphs=150, sample_edges=3, label="（抽样）")
    points_N6 = run_analysis(6, max_graphs=None, sample_edges=4, label="（全图）")

    # ============================================================
    # Q1: S_edge² 对简并子空间的泄漏量
    # ============================================================
    print("\n" + "=" * 100)
    print("Q1. S_edge² 对简并子空间的泄漏量 ||P_out S_edge² V||")
    print("=" * 100)

    for label, pts in [("N=6", points_N6), ("N=7", points_N7)]:
        if not pts:
            continue
        leaks = [p["leak_S_edge"] for p in pts]
        print(f"\n  {label}: 总点数 {len(pts)}")
        print(f"    max leak = {max(leaks):.4f}")
        print(f"    mean leak = {np.mean(leaks):.4f}")
        n_closed = sum(1 for x in leaks if x < 1e-6)
        print(f"    完全闭合（leak < 1e-6）: {n_closed}/{len(pts)} = "
              f"{n_closed/len(pts):.1%}")

    # ============================================================
    # Q2: S_edge² 投影谱的非整数值
    # ============================================================
    print("\n" + "=" * 100)
    print("Q2. S_edge² 投影谱（简并子空间内）的整数值分析")
    print("=" * 100)

    # 纯 S_edge 值的期望：单态 0，三重态 8
    for label, pts in [("N=6", points_N6), ("N=7", points_N7)]:
        if not pts:
            continue
        all_eigs = [e for p in pts for e in p["edge_eigs"]]
        n_int_0 = sum(1 for x in all_eigs if abs(x) < 1e-4)
        n_int_8 = sum(1 for x in all_eigs if abs(x - 8) < 1e-4)
        n_other = len(all_eigs) - n_int_0 - n_int_8
        print(f"\n  {label}: 总本征值 {len(all_eigs)}")
        print(f"    ≈0（单态）: {n_int_0} ({n_int_0/len(all_eigs):.1%})")
        print(f"    ≈8（三重态）: {n_int_8} ({n_int_8/len(all_eigs):.1%})")
        print(f"    其他（非整数值）: {n_other} ({n_other/len(all_eigs):.1%})")
        # 其他值的分布
        others = [x for x in all_eigs if abs(x) > 1e-4 and abs(x - 8) > 1e-4]
        if others:
            print(f"    非整数值范围: [{min(others):.4f}, {max(others):.4f}]")

    # ============================================================
    # Q3: [S_edge², H] 在简并子空间内的对易性
    # ============================================================
    print("\n" + "=" * 100)
    print("Q3. [S_edge², H] 在简并子空间内的对易性")
    print("=" * 100)

    for label, pts in [("N=6", points_N6), ("N=7", points_N7)]:
        if not pts:
            continue
        comms = [p["comm_S_edge_H"] for p in pts]
        print(f"\n  {label}:")
        print(f"    [S_edge², H] 投影范数 max = {max(comms):.4e}")
        print(f"    mean = {np.mean(comms):.4e}")
        n_comm = sum(1 for x in comms if x < 1e-6)
        print(f"    对易（<1e-6）: {n_comm}/{len(pts)}")

    # ============================================================
    # Q4: S² 和 S_edge² 在简并子空间内的联合对易性
    # ============================================================
    print("\n" + "=" * 100)
    print("Q4. [S², S_edge²] 在简并子空间内的对易性")
    print("=" * 100)

    for label, pts in [("N=6", points_N6), ("N=7", points_N7)]:
        if not pts:
            continue
        comms = [p["comm_in_S2_S_edge"] for p in pts]
        print(f"\n  {label}:")
        print(f"    范数 max = {max(comms):.3e}")
        n_comm = sum(1 for x in comms if x < 1e-6)
        print(f"    对易（<1e-6）: {n_comm}/{len(pts)}")

    # ============================================================
    # Q5: 泄漏量与整数率的关系
    # ============================================================
    print("\n" + "=" * 100)
    print("Q5. 泄漏量与整数率的关系")
    print("=" * 100)

    for label, pts in [("N=6", points_N6), ("N=7", points_N7)]:
        if not pts:
            continue
        # 按泄漏量大小分组
        low_leak = [p for p in pts if p["leak_S_edge"] < 0.1]
        mid_leak = [p for p in pts if 0.1 <= p["leak_S_edge"] < 1.0]
        high_leak = [p for p in pts if p["leak_S_edge"] >= 1.0]

        print(f"\n  {label}:")
        for name, group in [("低泄漏(<0.1)", low_leak),
                            ("中泄漏(0.1-1)", mid_leak),
                            ("高泄漏(>1)", high_leak)]:
            if not group:
                continue
            avg_int_rate = np.mean([p["deg_int_rate"] for p in group])
            print(f"    {name}: {len(group)} 点, "
                  f"平均整数率 {avg_int_rate:.1%}")

    # ============================================================
    # 深度追问：是否存在"S_edge 闭合子空间"
    # ============================================================
    print("\n" + "=" * 100)
    print("深度追问：是否存在 S_edge² 的闭合子空间？")
    print("=" * 100)

    # 对每个简并点，计算 S_edge² 在简并子空间内的特征值分解
    # 然后对每个特征值，检查是否对应纯 S_edge
    for label, pts in [("N=6", points_N6), ("N=7", points_N7)]:
        if not pts:
            continue
        print(f"\n  {label}:")
        n_pure_0 = 0
        n_pure_8 = 0
        n_mixed = 0
        for p in pts:
            eigs = p["edge_eigs"]
            # 特征值是否全在 {0, 8}
            is_pure = all(abs(x) < 1e-4 or abs(x - 8) < 1e-4 for x in eigs)
            if is_pure:
                if all(abs(x) < 1e-4 for x in eigs):
                    n_pure_0 += 1
                elif all(abs(x - 8) < 1e-4 for x in eigs):
                    n_pure_8 += 1
                else:
                    n_mixed += 1
        n_total = len(pts)
        print(f"    所有特征值 ∈ {{0, 8}}: {n_pure_0 + n_pure_8 + n_mixed}/{n_total} "
              f"= {(n_pure_0+n_pure_8+n_mixed)/n_total:.1%}")
        print(f"    纯单态 (全 0): {n_pure_0}")
        print(f"    纯三重态 (全 8): {n_pure_8}")
        print(f"    0/8 混合: {n_mixed}")

    # ============================================================
    # 导出
    # ============================================================
    out = {
        "N6": {
            "n_points": len(points_N6),
            "leak_S_edge_max": max([p["leak_S_edge"] for p in points_N6]) if points_N6 else 0,
            "leak_S_edge_mean": float(np.mean([p["leak_S_edge"] for p in points_N6])) if points_N6 else 0,
            "comm_S_edge_H_max": max([p["comm_S_edge_H"] for p in points_N6]) if points_N6 else 0,
            "comm_in_S2_S_edge_max": max([p["comm_in_S2_S_edge"] for p in points_N6]) if points_N6 else 0,
        },
        "N7": {
            "n_points": len(points_N7),
            "leak_S_edge_max": max([p["leak_S_edge"] for p in points_N7]) if points_N7 else 0,
            "leak_S_edge_mean": float(np.mean([p["leak_S_edge"] for p in points_N7])) if points_N7 else 0,
            "comm_S_edge_H_max": max([p["comm_S_edge_H"] for p in points_N7]) if points_N7 else 0,
            "comm_in_S2_S_edge_max": max([p["comm_in_S2_S_edge"] for p in points_N7]) if points_N7 else 0,
        },
    }
    out_path = os.path.join(WORK_DIR, "照妖镜_v18_闭合性.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("v18.0 完成。")
    print("=" * 100)


if __name__ == "__main__":
    main()