#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 v23.0：核心层的必要条件 vs 充分条件
================================================================

v22 发现：
  核心层 24 对的特征：
  1. 两条边在图的对称不变子集内
  2. 全部是异轨道对
  3. 不参与节点通过 2-3 条边与核心连接

新问题：
  这些特征是充分条件吗？还是必要不充分？
  有多少非核心对也满足这些条件？

五个追问并行：
  Q1. 对全部 2731 对异轨道对，检查是否在"对称不变子集"内
  Q2. 满足"对称不变子集"的对，有多少同响应？
  Q3. 核心 24 对 vs 满足条件的非核心对的差异
  Q4. p_S 曲线相同 vs p_S 曲线不同的子集结构差异
  Q5. 如果去掉"对称不变子集"条件，核心对的其它共同点是什么？
"""

import sys, io, itertools, json, os
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from collections import Counter, defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"


def build_atlas_graphs(N):
    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    return graphs


def edge_orbits(G):
    edges = [tuple(sorted(e)) for e in G.edges()]
    GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
    autos = list(GM.isomorphisms_iter())
    orbits = {}
    for e in edges:
        orbit = frozenset(frozenset({a[e[0]], a[e[1]]}) for a in autos)
        orbits[e] = orbit
    return orbits


def load_v51_patterns():
    with open(os.path.join(WORK_DIR, "照妖镜_v5_1_模式.json"), "r",
              encoding="utf-8") as f:
        v51 = json.load(f)
    patterns = {}
    for key, s in v51["patterns"].items():
        gid, e1_str, e2_str = key.split("_", 2)
        gid = int(gid)
        e1 = tuple(map(int, e1_str.strip("()").split(",")))
        e2 = tuple(map(int, e2_str.strip("()").split(",")))
        patterns[(gid, tuple(sorted(e1)), tuple(sorted(e2)))] = s
    return patterns


def find_symmetric_subset(G, e1, e2):
    """
    寻找包含 e1 和 e2 的最小"对称不变子集"：
    即最小的节点子集 S，使得 S 在某个自同构下保持不变，且 e1, e2 ⊆ S。
    """
    GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
    autos = list(GM.isomorphisms_iter())

    e1_nodes = set(e1)
    e2_nodes = set(e2)

    # 从 e1 ∪ e2 开始，逐步闭包：加入所有在自同构下可达的节点
    current = e1_nodes | e2_nodes
    changed = True
    while changed:
        changed = False
        for a in autos:
            for n in list(current):
                if a[n] not in current:
                    current.add(a[n])
                    changed = True

    # 检查 current 是否在某个自同构下保持不变
    is_invariant = False
    for a in autos:
        if all(a[n] in current for n in current) and \
           all(n in set(a[m] for m in current) for n in current):
            is_invariant = True
            break

    return sorted(current), is_invariant


def main():
    print("=" * 100)
    print("照妖镜 v23.0：核心层的必要条件 vs 充分条件")
    print("=" * 100)

    N = 6
    graphs = build_atlas_graphs(N)
    patterns = load_v51_patterns()
    print(f"\n  N={N} 图集: {len(graphs)} 图")
    print(f"  同响应对: {len(patterns)}")

    # 计算每对的对称不变子集
    print(f"\n  计算每对的对称不变子集...")
    pair_data = []
    for (gid, e1, e2), pattern in patterns.items():
        G = graphs[gid]
        subset, is_inv = find_symmetric_subset(G, e1, e2)
        n_true = pattern.count("1")
        pair_data.append({
            "gid": gid, "e1": e1, "e2": e2,
            "n_true": n_true,
            "subset": subset,
            "subset_size": len(subset),
            "is_invariant": is_inv,
        })

    # ============================================================
    # Q1: 对称不变子集的大小分布
    # ============================================================
    print("\n" + "=" * 100)
    print("Q1. 对称不变子集的大小分布")
    print("=" * 100)

    print(f"\n  {'subset 大小':>12} | {'数量':>6} | {'其中同响应':>10} | {'同响应比例':>10}")
    print(f"  {'-'*12}-+-{'-'*6}-+-{'-'*10}-+-{'-'*10}")
    by_subset_size = defaultdict(list)
    for p in pair_data:
        by_subset_size[p["subset_size"]].append(p)
    for sz in sorted(by_subset_size.keys()):
        group = by_subset_size[sz]
        n_same = sum(1 for p in group if p["n_true"] > 0)
        print(f"  {sz:>12} | {len(group):>6} | {n_same:>10} | "
              f"{n_same/len(group):>10.1%}")

    # ============================================================
    # Q2: 核心 24 对的对称子集特征
    # ============================================================
    print("\n" + "=" * 100)
    print("Q2. 核心 24 对的对称子集特征")
    print("=" * 100)

    core_pairs = [p for p in pair_data if p["n_true"] == 24]
    print(f"\n  核心对（24 全 1 模式）: {len(core_pairs)}")
    print(f"  {'gid':>4} | {'e1':>8} | {'e2':>8} | {'subset 大小':>10} | {'对称不变':>8} | {'subset 节点':>25}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*8}-+-{'-'*10}-+-{'-'*8}-+-{'-'*25}")
    for p in core_pairs:
        print(f"  {p['gid']:>4} | {str(p['e1']):>8} | {str(p['e2']):>8} | "
              f"{p['subset_size']:>10} | {str(p['is_invariant']):>8} | "
              f"{str(p['subset']):>25}")

    # 核心对的对称子集大小
    core_subset_sizes = [p["subset_size"] for p in core_pairs]
    print(f"\n  核心对的对称子集大小: {sorted(set(core_subset_sizes))}")

    # ============================================================
    # Q3: 满足"对称不变子集"条件的非核心对
    # ============================================================
    print("\n" + "=" * 100)
    print("Q3. 满足对称不变子集条件的对")
    print("=" * 100)

    # 条件：subset_size = 6（覆盖全部节点）或 is_invariant = True
    n_inv = sum(1 for p in pair_data if p["is_invariant"])
    n_core_inv = sum(1 for p in core_pairs if p["is_invariant"])
    n_noncore_inv = n_inv - n_core_inv
    n_noncore = len(pair_data) - len(core_pairs)
    print(f"\n  总对数: {len(pair_data)}")
    print(f"  对称不变子集的对数: {n_inv}")
    print(f"  其中核心对: {n_core_inv}")
    print(f"  其中非核心对: {n_noncore_inv}")
    print(f"  非核心对总数: {n_noncore}")
    print(f"  非核心对中对称不变的占比: {n_noncore_inv/n_noncore:.1%}")

    # 满足"对称不变"的对中，同响应的比例
    inv_pairs = [p for p in pair_data if p["is_invariant"]]
    n_inv_same = sum(1 for p in inv_pairs if p["n_true"] > 0)
    print(f"\n  对称不变的对中:")
    print(f"    同响应: {n_inv_same}/{n_inv} = {n_inv_same/n_inv:.1%}")
    print(f"    异响应: {n_inv - n_inv_same}/{n_inv}")

    # ============================================================
    # Q4: 同响应的对称不变 vs 异响应的对称不变
    # ============================================================
    print("\n" + "=" * 100)
    print("Q4. 同响应的对称不变 vs 异响应的对称不变")
    print("=" * 100)

    same_inv = [p for p in pair_data if p["is_invariant"] and p["n_true"] > 0]
    diff_inv = [p for p in pair_data if p["is_invariant"] and p["n_true"] == 0]
    print(f"\n  同响应的对称不变对: {len(same_inv)}")
    print(f"  异响应的对称不变对: {len(diff_inv)}")

    # 对称子集大小分布对比
    print(f"\n  对称子集大小分布:")
    for name, group in [("同响应", same_inv), ("异响应", diff_inv)]:
        cnt = Counter(p["subset_size"] for p in group)
        print(f"    {name}: {dict(cnt)}")

    # ============================================================
    # Q5: 如果不看"对称不变子集"，核心对的其它共同点
    # ============================================================
    print("\n" + "=" * 100)
    print("Q5. 核心对的其它共同点")
    print("=" * 100)

    # 核心对的图论特征
    print(f"\n  核心对的图论特征汇总:")
    print(f"  {'gid':>4} | {'e1':>8} | {'e2':>8} | {'边数':>4} | {'\|Aut\|':>6} | "
          f"{'e1 度':>6} | {'e2 度':>6} | {'e1 轨道':>8} | {'e2 轨道':>8}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*8}-+-{'-'*4}-+-{'-'*6}-+-"
          f"{'-'*6}-+-{'-'*6}-+-{'-'*8}-+-{'-'*8}")
    for p in core_pairs:
        G = graphs[p["gid"]]
        n_e = G.number_of_edges()
        GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
        n_autos = 0
        for _ in GM.isomorphisms_iter():
            n_autos += 1
            if n_autos > 500:
                break
        e1_deg = tuple(sorted([G.degree(p["e1"][0]), G.degree(p["e1"][1])]))
        e2_deg = tuple(sorted([G.degree(p["e2"][0]), G.degree(p["e2"][1])]))
        # 轨道大小
        orbits = edge_orbits(G)
        e1_orbit = len(orbits[p["e1"]])
        e2_orbit = len(orbits[p["e2"]])
        print(f"  {p['gid']:>4} | {str(p['e1']):>8} | {str(p['e2']):>8} | "
              f"{n_e:>4} | {n_autos:>6} | {str(e1_deg):>6} | {str(e2_deg):>6} | "
              f"{e1_orbit:>8} | {e2_orbit:>8}")

    # ============================================================
    # 汇总
    # ============================================================
    print("\n" + "=" * 100)
    print("汇总：核心层的必要条件")
    print("=" * 100)

    print(f"""
  核心层 24 对的特征：
  1. 全部是异轨道对 (n_true = 24)
  2. 两条边在图的对称不变子集内 ({n_core_inv}/24)
  3. 对称子集大小分布: {sorted(set(core_subset_sizes))}
  4. 不参与节点通过 2-3 条边与核心连接

  这些特征的必要性 vs 充分性：
  - 特征 1 (异轨道): 核心 24 对全部满足，但异轨道对总数 2731
  - 特征 2 (对称不变): 核心 24 对全部满足，但非核心对中也有 {n_noncore_inv} 对满足
  - 特征 3 (子集大小): 核心对集中在 {sorted(set(core_subset_sizes))}，但非核心对也有

  → 这些特征是必要不充分
""")

    # ============================================================
    # 导出
    # ============================================================
    out = {
        "n_pairs": len(pair_data),
        "n_core": len(core_pairs),
        "n_invariant": n_inv,
        "n_core_invariant": n_core_inv,
        "n_noncore_invariant": n_noncore_inv,
        "n_inv_same": n_inv_same,
        "n_inv_diff": n_inv - n_inv_same,
        "core_subset_sizes": sorted(set(core_subset_sizes)),
    }
    out_path = os.path.join(WORK_DIR, "照妖镜_v23_必要条件.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("v23.0 完成。")
    print("=" * 100)


if __name__ == "__main__":
    main()