#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
对合像的物理量检验：能隙、纠缠熵、保真度、关联熵
====================================================

核心追问：
- 对合像保护的不仅是 E(s)，还有更广的物理量吗？
- 纠缠熵、保真度、关联分布熵是否也对合像相同？

理论精髓：
- 关系本体论：对合对称性保护的是关系位置的全部响应
- 只查同与不同：不拟合，不预设
- 反对对齐：不预设"对合像只保护 E(s)"
- 严防工具理性悖论：不用近似，用精确对角化

运行：
    python 对合像物理量检验.py
"""

import sys
import io
import json
import itertools
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from networkx.algorithms.isomorphism import GraphMatcher

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)


I2 = np.eye(2, dtype=complex)
SX = np.array([[0, 1], [1, 0]], dtype=complex)
SY = np.array([[0, -1j], [1j, 0]], dtype=complex)
SZ = np.array([[1, 0], [0, -1]], dtype=complex)


def op_on_site(op, site, N):
    ops = [I2] * N
    ops[site] = op
    out = ops[0]
    for o in ops[1:]:
        out = np.kron(out, o)
    return out


def build_site_ops(N):
    return ([op_on_site(SX, i, N) for i in range(N)],
            [op_on_site(SY, i, N) for i in range(N)],
            [op_on_site(SZ, i, N) for i in range(N)])


def edge_matrix(i, j, SX_ops, SY_ops, SZ_ops):
    return SX_ops[i] @ SX_ops[j] + SY_ops[i] @ SY_ops[j] + SZ_ops[i] @ SZ_ops[j]


def ground_state_full(H, tol=1e-8):
    evals, evecs = eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < tol))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    gap = evals[deg] - E0 if deg < len(evals) else 0.0
    return E0, gap, rho, deg


def von_neumann_entropy(rho):
    evals = np.linalg.eigvalsh(rho)
    evals = evals[evals > 1e-12]
    return float(-np.sum(evals * np.log(evals)))


def correlation_entropy(C):
    vals = np.array(list(C.values()))
    p = np.abs(vals) / np.sum(np.abs(vals))
    return float(-np.sum(p * np.log(p + 1e-30)))


def edge_correlations(rho, edges, SZ_ops):
    C = {}
    for (i, j) in edges:
        op = SZ_ops[i] @ SZ_ops[j]
        C[(i, j)] = float(np.real(np.trace(rho @ op)))
    return C


def compute_physical_quantities(G, defect_edge, s_vals, SX_ops, SY_ops, SZ_ops):
    N = G.number_of_nodes()
    edges = [tuple(sorted(e)) for e in G.edges()]
    H_edges = {e: edge_matrix(e[0], e[1], SX_ops, SY_ops, SZ_ops) for e in edges}
    H0 = sum(H_edges.values())
    M_defect = H_edges[defect_edge]

    gaps = []
    vn_entropies = []
    corr_entropies = []
    rhos = []
    for s in s_vals:
        H = H0 + (s - 1.0) * M_defect
        E0, gap, rho, deg = ground_state_full(H)
        C = edge_correlations(rho, edges, SZ_ops)
        gaps.append(float(gap))
        vn_entropies.append(von_neumann_entropy(rho))
        corr_entropies.append(correlation_entropy(C))
        rhos.append(rho)
    return gaps, vn_entropies, corr_entropies, rhos


def find_involution_pairs(G):
    nodes = list(G.nodes())
    matcher = GraphMatcher(G, G)
    pairs = set()
    for mapping in matcher.isomorphisms_iter():
        if not all(mapping[mapping[u]] == u for u in nodes):
            continue
        if all(mapping[u] == u for u in nodes):
            continue
        for u, v in G.edges():
            e1 = tuple(sorted((u, v)))
            u2, v2 = mapping[u], mapping[v]
            e2 = tuple(sorted((u2, v2)))
            if e1 != e2 and G.has_edge(u2, v2):
                pairs.add(tuple(sorted([e1, e2])))
    return pairs


def generate_all_connected_graphs(N):
    all_edges = list(itertools.combinations(range(N), 2))
    graphs = []
    for m in range(N - 1, len(all_edges) + 1):
        for combo in itertools.combinations(all_edges, m):
            G = nx.Graph()
            G.add_nodes_from(range(N))
            G.add_edges_from(combo)
            if nx.is_connected(G):
                graphs.append(G)
    return graphs


def main():
    s_vals = np.linspace(-1.5, 0.0, 11)
    print("=" * 78)
    print("  对合像的物理量检验")
    print("=" * 78)
    print(f"  s: [{s_vals[0]}, {s_vals[-1]}], {len(s_vals)} 点")
    print()

    SX_ops, SY_ops, SZ_ops = build_site_ops(6)
    graphs = generate_all_connected_graphs(6)
    print(f"  N=6 连通图总数: {len(graphs)}")
    print()

    gap_match = gap_mismatch = 0
    vn_match = vn_mismatch = 0
    corr_match = corr_mismatch = 0
    fidelity_match = fidelity_mismatch = 0

    for gid, G in enumerate(graphs):
        involution_pairs = find_involution_pairs(G)
        if not involution_pairs:
            continue

        edges = [tuple(sorted(e)) for e in G.edges()]
        quantities = {}
        for e in edges:
            gaps, vn, corr, rhos = compute_physical_quantities(
                G, e, s_vals, SX_ops, SY_ops, SZ_ops)
            quantities[e] = {"gaps": gaps, "vn": vn, "corr": corr, "rhos": rhos}

        for e1, e2 in involution_pairs:
            if e1 not in quantities or e2 not in quantities:
                continue
            q1 = quantities[e1]
            q2 = quantities[e2]

            if np.allclose(q1["gaps"], q2["gaps"], atol=1e-10):
                gap_match += 1
            else:
                gap_mismatch += 1

            if np.allclose(q1["vn"], q2["vn"], atol=1e-10):
                vn_match += 1
            else:
                vn_mismatch += 1

            if np.allclose(q1["corr"], q2["corr"], atol=1e-10):
                corr_match += 1
            else:
                corr_mismatch += 1

            fid_ok = True
            for rho1, rho2 in zip(q1["rhos"], q2["rhos"]):
                f = float(np.real(np.trace(rho1 @ rho2)))
                if abs(f - 1.0) > 1e-6:
                    fid_ok = False
                    break
            if fid_ok:
                fidelity_match += 1
            else:
                fidelity_mismatch += 1

        if (gid + 1) % 20 == 0:
            print(f"    已处理 {gid + 1}/{len(graphs)} 图")

    total = gap_match + gap_mismatch
    print()
    print(f"  对合像总数: {total}")
    print()
    print(f"  能隙相同: {gap_match} / {total}")
    print(f"  能隙不同: {gap_mismatch}")
    print(f"  纠缠熵相同: {vn_match} / {total}")
    print(f"  纠缠熵不同: {vn_mismatch}")
    print(f"  关联分布熵相同: {corr_match} / {total}")
    print(f"  关联分布熵不同: {corr_mismatch}")
    print(f"  保真度 = 1: {fidelity_match} / {total}")
    print(f"  保真度 < 1: {fidelity_mismatch}")
    print()

    output = {
        "total": total,
        "gap_match": gap_match, "gap_mismatch": gap_mismatch,
        "vn_match": vn_match, "vn_mismatch": vn_mismatch,
        "corr_match": corr_match, "corr_mismatch": corr_mismatch,
        "fidelity_match": fidelity_match, "fidelity_mismatch": fidelity_mismatch,
    }
    with open("对合像物理量检验结果.json", "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2, default=str)
    print("已保存: 对合像物理量检验结果.json")


if __name__ == "__main__":
    main()