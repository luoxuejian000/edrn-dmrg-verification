#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 v20.0：恢复的代数条件
================================================================

v19 关键发现：
  恢复点 S_edge² 谱: (2, 6), (2, 2, 8)    —— 简单有理数
  未恢复点 S_edge² 谱: (1.6, 5.333), (2.468, 5.296) —— 混乱代数数

核心假设：
  恢复的充分条件是 S_edge² 投影谱落在"低复杂度"代数数上。

五个追问并行：
  Q1. 恢复点 vs 未恢复点的 S_edge² 谱代数复杂度
  Q2. 恢复点是否集中在少数图？图结构有什么共同特征？
  Q3. 投影到 S_edge² 的 {0, 8} 特征空间后，能恢复多少？
  Q4. S_edge² 谱值能否写成 N 的简单函数？
  Q5. N=6 vs N=7 的 S_edge² 谱代数数分类
"""

import sys, io, itertools, json, os
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from scipy.optimize import brentq
from collections import Counter, defaultdict
from fractions import Fraction

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"


# ============================================================
# 基础
# ============================================================

def build_sz0_sector(N):
    n_up = N // 2
    basis = []
    for comb in itertools.combinations(range(N), n_up):
        state = [0]*N
        for i in comb: state[i] = 1
        basis.append(tuple(state))
    dim = len(basis)
    idx = {s: i for i, s in enumerate(basis)}
    SZ_ops = []
    for site in range(N):
        SZ = np.zeros((dim, dim), dtype=complex)
        for i, state in enumerate(basis):
            SZ[i, i] = 1 if state[site] == 1 else -1
        SZ_ops.append(SZ)
    return basis, idx, SZ_ops


def build_edge_op(i, j, basis, idx):
    dim = len(basis)
    op = np.zeros((dim, dim), dtype=complex)
    for a_idx, state_a in enumerate(basis):
        sa, sb = state_a[i], state_a[j]
        if sa == sb:
            op[a_idx, a_idx] += 1
        else:
            op[a_idx, a_idx] += -1
            new_state = list(state_a)
            new_state[i], new_state[j] = new_state[j], new_state[i]
            b_idx = idx.get(tuple(new_state))
            if b_idx is not None:
                op[b_idx, a_idx] += 2
    return op


def build_S2_op(basis, idx, N):
    dim = len(basis)
    S2 = np.zeros((dim, dim), dtype=complex)
    for i in range(N):
        S2 += 3/4 * np.eye(dim, dtype=complex)
        for j in range(N):
            if i == j: continue
            S2 += 1/4 * build_edge_op(i, j, basis, idx)
    return S2


# ============================================================
# 代数复杂度
# ============================================================

def algebraic_complexity(x, tol=1e-6):
    """
    对实数 x，返回其"代数复杂度"：
    - 若为 0：复杂度 0
    - 若为整数：复杂度 1
    - 若为简单有理数（分母 ≤ 4）：复杂度 2
    - 若为有理数（分母 ≤ 20）：复杂度 3
    - 若为简单二次代数数：复杂度 4
    - 否则：复杂度 5（混乱）
    """
    if abs(x) < tol:
        return 0, "0"
    if abs(x - round(x)) < tol:
        return 1, f"{int(round(x))}"
    for q in [2, 3, 4]:
        p = round(x * q)
        if abs(x - p/q) < tol:
            return 2, f"{p}/{q}"
    for q in range(5, 21):
        p = round(x * q)
        if abs(x - p/q) < tol:
            return 3, f"{p}/{q}"
    # 二次代数数：a·x² + b·x + c = 0，a, b, c 小整数
    for a in range(1, 6):
        for b in range(-10, 11):
            for c in range(-10, 11):
                if abs(a*x*x + b*x + c) < tol:
                    disc = b*b - 4*a*c
                    return 4, f"({-b}±√{disc})/{2*a}"
    return 5, f"~{x:.4f}"


# ============================================================
# 核心分析
# ============================================================

def analyze_recovery_deep(edge_ops, defect, s, SZ_ops, S2_op, ref_dim):
    """深度分析恢复条件"""
    H = np.zeros((ref_dim, ref_dim), dtype=complex)
    for e, M in edge_ops.items():
        c = s if e == defect else 1.0
        H += c * M

    evals, evecs = eigh(H)
    E0 = evals[0]
    degen_mask = np.abs(evals - E0) < 1e-8
    deg = int(np.sum(degen_mask))
    V = evecs[:, degen_mask]

    S_edge_sq = 6 * np.eye(ref_dim, dtype=complex) + 2 * edge_ops[defect]

    # 原始基
    raw_sds = []
    for k in range(deg):
        v = V[:, k]
        sd = float(np.real(v.conj() @ edge_ops[defect] @ v))
        raw_sds.append(sd)
    raw_n_int = sum(1 for x in raw_sds if abs(x - round(x)) < 1e-6)

    # S_edge² 对角化
    M_edge = V.conj().T @ S_edge_sq @ V
    se2_evals, W_edge = eigh(M_edge)
    V_edge = V @ W_edge
    edge_sds = []
    for k in range(deg):
        v = V_edge[:, k]
        sd = float(np.real(v.conj() @ edge_ops[defect] @ v))
        edge_sds.append(sd)
    edge_n_int = sum(1 for x in edge_sds if abs(x - round(x)) < 1e-6)

    # 投影到 {0, 8} 特征空间
    # 即：取 S_edge² 特征值最接近 0 或 8 的特征向量组合
    mask_0 = np.abs(se2_evals) < 1.0
    mask_8 = np.abs(se2_evals - 8) < 1.0
    mask_pure = mask_0 | mask_8
    n_pure = int(mask_pure.sum())

    if n_pure > 0:
        V_pure = V_edge[:, mask_pure]
        # 在纯 {0,8} 子空间内计算 σ·σ
        pure_sds = []
        for k in range(V_pure.shape[1]):
            v = V_pure[:, k]
            sd = float(np.real(v.conj() @ edge_ops[defect] @ v))
            pure_sds.append(sd)
        pure_n_int = sum(1 for x in pure_sds if abs(x - round(x)) < 1e-6)
    else:
        pure_sds = []
        pure_n_int = 0

    # S_edge² 谱的代数复杂度
    eigs_complexity = [algebraic_complexity(e) for e in se2_evals]
    max_complexity = max(c for c, _ in eigs_complexity)
    mean_complexity = np.mean([c for c, _ in eigs_complexity])
    # 是否有"混乱"值
    has_chaotic = any(c >= 5 for c, _ in eigs_complexity)

    return {
        "s": s, "deg": deg,
        "raw_sds": raw_sds, "raw_n_int": raw_n_int,
        "edge_sds": edge_sds, "edge_n_int": edge_n_int,
        "edge_eigs": [float(x) for x in se2_evals],
        "edge_eigs_complexity": eigs_complexity,
        "max_complexity": max_complexity,
        "mean_complexity": float(mean_complexity),
        "has_chaotic": has_chaotic,
        "n_pure": n_pure,
        "pure_sds": pure_sds, "pure_n_int": pure_n_int,
        "raw_int_rate": raw_n_int / deg,
        "edge_int_rate": edge_n_int / deg,
        "pure_int_rate": pure_n_int / n_pure if n_pure > 0 else 0,
    }


def build_atlas_graphs(N):
    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    return graphs


def run_analysis(N, max_graphs=None, sample_edges=4):
    print(f"\n  N={N} 分析...")
    graphs = build_atlas_graphs(N)
    if max_graphs:
        step = max(1, len(graphs) // max_graphs)
        graphs = graphs[::step][:max_graphs]
    print(f"    图集: {len(graphs)} 图")

    basis, idx, SZ_ops = build_sz0_sector(N)
    ref_dim = len(basis)
    S2_op = build_S2_op(basis, idx, N)

    results = []
    for gid, G in enumerate(graphs):
        if gid % 30 == 0:
            print(f"    {gid}/{len(graphs)}")
        edges = [tuple(sorted(e)) for e in G.edges()]
        edge_ops = {e: build_edge_op(e[0], e[1], basis, idx) for e in edges}
        for defect in edges[:sample_edges]:
            s_grid = np.linspace(-2.0, 2.5, 41)
            pS_vals = []
            for s in s_grid:
                H = np.zeros((ref_dim, ref_dim), dtype=complex)
                for e, M in edge_ops.items():
                    c = s if e == defect else 1.0
                    H += c * M
                try:
                    evals, evecs = eigh(H)
                except Exception:
                    pS_vals.append(0.0)
                    continue
                E0 = evals[0]
                deg = int(np.sum(np.abs(evals - E0) < 1e-8))
                Vv = evecs[:, :deg]
                rho = Vv @ Vv.conj().T / deg
                i, j = defect
                szsz_diag = np.diag(SZ_ops[i] @ SZ_ops[j])
                szsz = float(np.real(np.sum(np.diag(rho) * szsz_diag)))
                pS_vals.append((1 - 3 * szsz) / 4)
            pS_vals = np.array(pS_vals)

            for k in range(len(s_grid) - 1):
                if (pS_vals[k] - 0.5) * (pS_vals[k+1] - 0.5) < 0:
                    try:
                        s_res = brentq(
                            lambda s: _pS(edge_ops, defect, s, SZ_ops, ref_dim) - 0.5,
                            s_grid[k], s_grid[k+1], xtol=1e-10)
                        H = np.zeros((ref_dim, ref_dim), dtype=complex)
                        for e, M in edge_ops.items():
                            c = s_res if e == defect else 1.0
                            H += c * M
                        evals = np.linalg.eigvalsh(H)
                        deg = int(np.sum(np.abs(evals - evals[0]) < 1e-8))
                        if deg > 1:
                            info = analyze_recovery_deep(
                                edge_ops, defect, s_res, SZ_ops,
                                S2_op, ref_dim)
                            results.append({
                                "gid": gid, "defect": list(defect), **info
                            })
                    except Exception:
                        pass
    print(f"    简并谐振点: {len(results)}")
    return results, graphs


def _pS(edge_ops, defect, s, SZ_ops, ref_dim):
    H = np.zeros((ref_dim, ref_dim), dtype=complex)
    for e, M in edge_ops.items():
        c = s if e == defect else 1.0
        H += c * M
    evals, evecs = eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < 1e-8))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    i, j = defect
    szsz_diag = np.diag(SZ_ops[i] @ SZ_ops[j])
    szsz = float(np.real(np.sum(np.diag(rho) * szsz_diag)))
    return (1 - 3 * szsz) / 4


def main():
    print("=" * 100)
    print("照妖镜 v20.0：恢复的代数条件")
    print("=" * 100)

    points_N6, graphs_N6 = run_analysis(6, max_graphs=None, sample_edges=4)
    points_N7, graphs_N7 = run_analysis(7, max_graphs=150, sample_edges=4)

    # ============================================================
    # Q1: 恢复点 vs 未恢复点的 S_edge² 谱代数复杂度
    # ============================================================
    print("\n" + "=" * 100)
    print("Q1. S_edge² 谱的代数复杂度 vs 恢复")
    print("=" * 100)

    for label, pts in [("N=6", points_N6), ("N=7", points_N7)]:
        if not pts:
            continue
        # 分类
        nonint_pts = [p for p in pts if p["raw_int_rate"] < 0.99]
        recovered = [p for p in nonint_pts
                     if p["edge_int_rate"] > p["raw_int_rate"] + 0.05]
        not_rec = [p for p in nonint_pts
                   if p["edge_int_rate"] <= p["raw_int_rate"] + 0.05]

        print(f"\n  {label}:")
        print(f"    非整数点: {len(nonint_pts)}")
        if recovered:
            max_comp = [p["max_complexity"] for p in recovered]
            mean_comp = [p["mean_complexity"] for p in recovered]
            n_chaotic = sum(1 for p in recovered if p["has_chaotic"])
            print(f"    恢复点 ({len(recovered)} 个):")
            print(f"      max_complexity: {Counter(max_comp)}")
            print(f"      mean_complexity: {np.mean(mean_comp):.2f}")
            print(f"      含混乱值: {n_chaotic}/{len(recovered)}")
        if not_rec:
            max_comp = [p["max_complexity"] for p in not_rec]
            mean_comp = [p["mean_complexity"] for p in not_rec]
            n_chaotic = sum(1 for p in not_rec if p["has_chaotic"])
            print(f"    未恢复点 ({len(not_rec)} 个):")
            print(f"      max_complexity: {Counter(max_comp)}")
            print(f"      mean_complexity: {np.mean(mean_comp):.2f}")
            print(f"      含混乱值: {n_chaotic}/{len(not_rec)}")

    # ============================================================
    # Q2: 恢复点是否集中在少数图？
    # ============================================================
    print("\n" + "=" * 100)
    print("Q2. 恢复点的图分布")
    print("=" * 100)

    for label, pts in [("N=6", points_N6), ("N=7", points_N7)]:
        if not pts:
            continue
        nonint_pts = [p for p in pts if p["raw_int_rate"] < 0.99]
        recovered = [p for p in nonint_pts
                     if p["edge_int_rate"] > p["raw_int_rate"] + 0.05]
        if not recovered:
            print(f"\n  {label}: 无恢复点")
            continue
        gid_cnt = Counter(p["gid"] for p in recovered)
        print(f"\n  {label}: 恢复点 {len(recovered)} 个，来自 {len(gid_cnt)} 个图")
        print(f"    图分布: {dict(gid_cnt.most_common(10))}")

        # 这些图的共同结构
        print(f"    恢复点图的 d 分布: "
              f"{Counter(p['deg'] for p in recovered)}")

    # ============================================================
    # Q3: 投影到 {0, 8} 特征空间后的恢复
    # ============================================================
    print("\n" + "=" * 100)
    print("Q3. 投影到 S_edge² 的 {0, 8} 特征空间后的恢复")
    print("=" * 100)

    for label, pts in [("N=6", points_N6), ("N=7", points_N7)]:
        if not pts:
            continue
        nonint_pts = [p for p in pts if p["raw_int_rate"] < 0.99]
        print(f"\n  {label}: 非整数点 {len(nonint_pts)}")
        # 统计 n_pure
        n_pure_vals = [p["n_pure"] for p in nonint_pts]
        print(f"    纯 {{0,8}} 特征空间维度: min={min(n_pure_vals)}, "
              f"max={max(n_pure_vals)}, mean={np.mean(n_pure_vals):.2f}")
        # 纯子空间的整数率
        pure_rates = [p["pure_int_rate"] for p in nonint_pts if p["n_pure"] > 0]
        if pure_rates:
            print(f"    纯子空间整数率均值: {np.mean(pure_rates):.1%}")
        # 全 0 或全 8 的点
        n_full_pure = sum(1 for p in nonint_pts if p["n_pure"] == p["deg"])
        print(f"    完全 {0,8} 子空间（所有特征值在 {{0,8}}）: {n_full_pure}")

    # ============================================================
    # Q4: S_edge² 谱值的分布
    # ============================================================
    print("\n" + "=" * 100)
    print("Q4. S_edge² 投影谱值分布")
    print("=" * 100)

    for label, pts in [("N=6", points_N6), ("N=7", points_N7)]:
        if not pts:
            continue
        all_eigs = [e for p in pts for e in p["edge_eigs"]]
        # 分类
        classes = Counter()
        for e in all_eigs:
            c, name = algebraic_complexity(e)
            classes[c] += 1
        print(f"\n  {label}: 总本征值 {len(all_eigs)}")
        print(f"    复杂度分布:")
        labels_map = {0: "0", 1: "整数", 2: "简单分数(÷2,3,4)",
                      3: "有理数(÷5..20)", 4: "二次代数数", 5: "混乱"}
        for c in sorted(classes.keys()):
            print(f"      {labels_map[c]}: {classes[c]} "
                  f"({classes[c]/len(all_eigs):.1%})")

    # ============================================================
    # Q5: N=6 vs N=7 的 S_edge² 谱代数数分类
    # ============================================================
    print("\n" + "=" * 100)
    print("Q5. N=6 vs N=7 简并点恢复率的并排对比")
    print("=" * 100)

    print(f"\n  {'指标':<40} | {'N=6':>12} | {'N=7':>12}")
    print(f"  {'-'*40}-+-{'-'*12}-+-{'-'*12}")

    for label, pts in [("N=6", points_N6), ("N=7", points_N7)]:
        pass  # 后面用

    metrics = {
        "简并谐振点数": [len(points_N6), len(points_N7)],
        "非整数点数": [
            sum(1 for p in points_N6 if p["raw_int_rate"] < 0.99),
            sum(1 for p in points_N7 if p["raw_int_rate"] < 0.99),
        ],
        "S_edge² 恢复点数": [
            sum(1 for p in points_N6
                if p["raw_int_rate"] < 0.99 and
                p["edge_int_rate"] > p["raw_int_rate"] + 0.05),
            sum(1 for p in points_N7
                if p["raw_int_rate"] < 0.99 and
                p["edge_int_rate"] > p["raw_int_rate"] + 0.05),
        ],
        "恢复率": [
            sum(1 for p in points_N6
                if p["raw_int_rate"] < 0.99 and
                p["edge_int_rate"] > p["raw_int_rate"] + 0.05) /
            max(1, sum(1 for p in points_N6 if p["raw_int_rate"] < 0.99)),
            sum(1 for p in points_N7
                if p["raw_int_rate"] < 0.99 and
                p["edge_int_rate"] > p["raw_int_rate"] + 0.05) /
            max(1, sum(1 for p in points_N7 if p["raw_int_rate"] < 0.99)),
        ],
    }

    for name, vals in metrics.items():
        if "率" in name:
            print(f"  {name:<40} | {vals[0]:>11.1%} | {vals[1]:>11.1%}")
        else:
            print(f"  {name:<40} | {vals[0]:>12} | {vals[1]:>12}")

    # 深度：谱代数复杂度对比
    n6_complexity = []
    n7_complexity = []
    for p in points_N6:
        n6_complexity.extend([c for c, _ in p["edge_eigs_complexity"]])
    for p in points_N7:
        n7_complexity.extend([c for c, _ in p["edge_eigs_complexity"]])
    print(f"\n  S_edge² 谱复杂度均值:")
    print(f"    N=6: {np.mean(n6_complexity):.2f}")
    print(f"    N=7: {np.mean(n7_complexity):.2f}")

    print(f"\n  S_edge² 谱含混乱值 (>4) 的点比例:")
    n6_chaotic = sum(1 for p in points_N6 if p["has_chaotic"]) / max(1, len(points_N6))
    n7_chaotic = sum(1 for p in points_N7 if p["has_chaotic"]) / max(1, len(points_N7))
    print(f"    N=6: {n6_chaotic:.1%}")
    print(f"    N=7: {n7_chaotic:.1%}")

    # ============================================================
    # 导出
    # ============================================================
    out = {
        "N6": {
            "n_points": len(points_N6),
            "n_recovered": metrics["S_edge² 恢复点数"][0],
            "recovery_rate": metrics["恢复率"][0],
        },
        "N7": {
            "n_points": len(points_N7),
            "n_recovered": metrics["S_edge² 恢复点数"][1],
            "recovery_rate": metrics["恢复率"][1],
        },
    }
    out_path = os.path.join(WORK_DIR, "照妖镜_v20_代数条件.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("v20.0 完成。")
    print("=" * 100)


if __name__ == "__main__":
    main()