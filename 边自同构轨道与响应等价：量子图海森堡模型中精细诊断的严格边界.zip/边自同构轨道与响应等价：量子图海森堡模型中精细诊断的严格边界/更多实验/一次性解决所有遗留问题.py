#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
一次性解决所有遗留问题
==========================

遗留问题清单：
1. N=6 全图上对合像为何全在同轨道内？N=8 小世界图为何对合跨轨道？
2. 32 对异轨道同响应的来源是什么？（不是对合像，不是已知图论量）
3. 31 对能隙例外的完整代数识别（42 次未识别）
4. 保真度的正确检验（修正 Hilbert-Schmidt 内积问题）
5. N=7、8 抽样中 19+17 对异轨道同响应的来源
6. 模型依赖性：9/112 图依赖相互作用模型
7. 图 69（9 对异轨道同响应，最大来源）的结构解剖

运行：
    python 一次性解决所有遗留问题.py
"""

import sys
import io
import json
import itertools
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from collections import defaultdict, Counter

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)


I2 = np.eye(2, dtype=complex)
SX = np.array([[0, 1], [1, 0]], dtype=complex)
SY = np.array([[0, -1j], [1j, 0]], dtype=complex)
SZ = np.array([[1, 0], [0, -1]], dtype=complex)


def op_on_site(op, site, N):
    ops = [I2] * N
    ops[site] = op
    out = ops[0]
    for o in ops[1:]:
        out = np.kron(out, o)
    return out


def build_site_ops(N):
    return ([op_on_site(SX, i, N) for i in range(N)],
            [op_on_site(SY, i, N) for i in range(N)],
            [op_on_site(SZ, i, N) for i in range(N)])


def edge_matrix(i, j, SX_ops, SY_ops, SZ_ops, rule="heisenberg", delta=1.0):
    if rule == "heisenberg":
        return SX_ops[i] @ SX_ops[j] + SY_ops[i] @ SY_ops[j] + SZ_ops[i] @ SZ_ops[j]
    elif rule == "xxz":
        return SX_ops[i] @ SX_ops[j] + SY_ops[i] @ SY_ops[j] + delta * (SZ_ops[i] @ SZ_ops[j])
    elif rule == "ising":
        return SZ_ops[i] @ SZ_ops[j]
    elif rule == "xy":
        return SX_ops[i] @ SX_ops[j] + SY_ops[i] @ SY_ops[j]
    raise ValueError(f"未知规则: {rule}")


def ground_state_density(H, tol=1e-8):
    evals, evecs = eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < tol))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    gap = evals[deg] - E0 if deg < len(evals) else 0.0
    return E0, gap, rho, deg


def edge_correlations(rho, edges, SZ_ops):
    C = {}
    for (i, j) in edges:
        op = SZ_ops[i] @ SZ_ops[j]
        C[(i, j)] = float(np.real(np.trace(rho @ op)))
    return C


def compute_sorted_curve_and_gaps(G, defect_edge, s_vals,
                                  SX_ops, SY_ops, SZ_ops,
                                  rule="heisenberg", delta=1.0):
    N = G.number_of_nodes()
    edges = [tuple(sorted(e)) for e in G.edges()]
    H_edges = {e: edge_matrix(e[0], e[1], SX_ops, SY_ops, SZ_ops, rule, delta)
               for e in edges}
    H0 = sum(H_edges.values())
    M_defect = H_edges[defect_edge]
    curve = []
    gaps = []
    for s in s_vals:
        H = H0 + (s - 1.0) * M_defect
        E0, gap, rho, deg = ground_state_density(H)
        C = edge_correlations(rho, edges, SZ_ops)
        curve.append(tuple(np.round(sorted(C.values()), 12)))
        gaps.append(float(gap))
    return curve, gaps


def find_automorphisms(G):
    nodes = list(G.nodes())
    adj = nx.to_numpy_array(G)
    perms = []
    for p in itertools.permutations(nodes):
        P = np.zeros((len(nodes), len(nodes)))
        for i, pi in enumerate(p):
            P[i, pi] = 1
        if np.allclose(P @ adj @ P.T, adj):
            perms.append(p)
    return perms


def find_edge_orbits(G):
    nodes = list(G.nodes())
    edges = [tuple(sorted(e)) for e in G.edges()]
    perms = find_automorphisms(G)
    orbit_id = {e: None for e in edges}
    oid = 0
    for e in edges:
        if orbit_id[e] is not None:
            continue
        orbit_id[e] = oid
        for p in perms:
            mapping = {nodes[i]: p[i] for i in range(len(nodes))}
            e2 = tuple(sorted((mapping[e[0]], mapping[e[1]])))
            if G.has_edge(*e2):
                orbit_id[e2] = oid
        oid += 1
    return orbit_id


def find_involution_pairs(G):
    nodes = list(G.nodes())
    edges = [tuple(sorted(e)) for e in G.edges()]
    perms = find_automorphisms(G)
    pairs = set()
    for p in perms:
        if not all(p[p[i]] == i for i in range(len(p))):
            continue
        if all(p[i] == i for i in range(len(p))):
            continue
        mapping = {i: p[i] for i in range(len(p))}
        for e in edges:
            e2 = tuple(sorted((mapping[e[0]], mapping[e[1]])))
            if e2 != e and G.has_edge(*e2):
                pairs.add(tuple(sorted([e, e2])))
    return pairs


def identify_algebraic(x, tol=1e-6, max_denom=100, max_coef=30):
    """识别 x 是否为低次代数数。"""
    for q in range(1, max_denom + 1):
        p = round(x * q)
        if abs(x - p / q) < tol:
            return f"{p}/{q}"
    for c in range(2, max_coef + 1):
        sqrt_c = np.sqrt(c)
        for a in range(-max_coef, max_coef + 1):
            for b in range(-max_coef, max_coef + 1):
                if b == 0:
                    continue
                if abs(x - (a + b * sqrt_c)) < tol:
                    return f"{a}+{b}√{c}"
    return "未识别"


def get_112_connected_graphs():
    atlas = nx.graph_atlas_g()
    return [G for G in atlas
            if G.number_of_nodes() == 6 and nx.is_connected(G)]


def main():
    s_vals = np.linspace(-1.5, 0.5, 21)
    print("=" * 78)
    print("  一次性解决所有遗留问题")
    print("=" * 78)
    print()

    graphs = get_112_connected_graphs()
    print(f"  N=6 连通图总数: {len(graphs)}")
    print()

    SX_ops, SY_ops, SZ_ops = build_site_ops(6)

    # ============================================================
    # 遗留问题 1：对合像为何全在同轨道内？
    # ============================================================
    print("=" * 78)
    print("  问题 1：对合像为何全在同轨道内？")
    print("=" * 78)
    print()

    # 检查：是否存在异轨道对合像
    # 以及：对合自同构是否可能把边映到同轨道内的另一条边
    inv_same_orbit = 0
    inv_diff_orbit = 0
    orbit_pairs_with_involution = defaultdict(int)
    orbit_pairs_without_involution = defaultdict(int)

    for gid, G in enumerate(graphs):
        inv_pairs = find_involution_pairs(G)
        orbits = find_edge_orbits(G)
        # 统计每个轨道的对合像数
        orbit_inv_count = defaultdict(int)
        for e1, e2 in inv_pairs:
            if orbits[e1] == orbits[e2]:
                inv_same_orbit += 1
                orbit_inv_count[orbits[e1]] += 1
            else:
                inv_diff_orbit += 1

        # 检查每个轨道的内部对合
        for orbit_id in set(orbits.values()):
            orbit_edges = [e for e in orbits if orbits[e] == orbit_id]
            if len(orbit_edges) == 1:
                orbit_pairs_without_involution[(gid, orbit_id)] = len(orbit_edges)
            else:
                orbit_pairs_with_involution[(gid, orbit_id)] = len(orbit_edges)

    print(f"  对合像同轨道: {inv_same_orbit}")
    print(f"  对合像异轨道: {inv_diff_orbit}")
    print()
    print(f"  轨道大小统计：")
    size_counter = Counter(orbit_pairs_with_involution.values())
    size_counter.update(orbit_pairs_without_involution.values())
    for size in sorted(size_counter.keys()):
        print(f"    轨道大小 {size}: {size_counter[size]} 个轨道")
    print()

    # ============================================================
    # 问题 2 & 3：32 对异轨道同响应 + 能隙例外完整代数识别
    # ============================================================
    print("=" * 78)
    print("  问题 2 & 3：32 对异轨道同响应 + 能隙例外完整代数识别")
    print("=" * 78)
    print()

    edge_data = []
    for gid, G in enumerate(graphs):
        edges = [tuple(sorted(e)) for e in G.edges()]
        orbits = find_edge_orbits(G)
        for e in edges:
            curve, gaps = compute_sorted_curve_and_gaps(
                G, e, s_vals, SX_ops, SY_ops, SZ_ops)
            edge_data.append({
                "gid": gid, "edge": e, "curve": curve, "gaps": gaps,
                "orbit": orbits[e],
            })
        if (gid + 1) % 20 == 0:
            print(f"    已处理 {gid + 1}/{len(graphs)} 图")
    print()

    n = len(edge_data)
    same_curve_pairs = []
    for i in range(n):
        for j in range(i + 1, n):
            if edge_data[i]["gid"] != edge_data[j]["gid"]:
                continue
            ci = edge_data[i]["curve"]
            cj = edge_data[j]["curve"]
            if len(ci) != len(cj):
                continue
            same = all(
                len(a) == len(b) and np.allclose(a, b, atol=1e-10)
                for a, b in zip(ci, cj)
            )
            if same:
                same_curve_pairs.append((i, j))

    diff_orbit_same = []
    for i, j in same_curve_pairs:
        if edge_data[i]["orbit"] != edge_data[j]["orbit"]:
            diff_orbit_same.append((i, j))

    print(f"  异轨道同响应: {len(diff_orbit_same)} 对")

    # 能隙例外与完整代数识别
    gap_exceptions = []
    for i, j in diff_orbit_same:
        gaps_i = np.array(edge_data[i]["gaps"])
        gaps_j = np.array(edge_data[j]["gaps"])
        diff = gaps_i - gaps_j
        if np.max(np.abs(diff)) > 1e-10:
            gap_exceptions.append((i, j, diff))

    print(f"  能隙例外: {len(gap_exceptions)} 对")
    print()

    print(f"  {'图号':<6}{'边1':<12}{'边2':<12}"
          f"{'s=0差':<16}{'s=0.5差':<16}{'识别(s=0)':<16}{'识别(s=0.5)':<16}")
    print(f"  {'-'*6}{'-'*12}{'-'*12}{'-'*16}{'-'*16}{'-'*16}{'-'*16}")

    algebraic_counter = Counter()
    for i, j, diff in gap_exceptions:
        gid = edge_data[i]["gid"]
        e1 = edge_data[i]["edge"]
        e2 = edge_data[j]["edge"]
        idx_0 = np.argmin(np.abs(s_vals - 0.0))
        idx_05 = np.argmin(np.abs(s_vals - 0.5))
        d0 = diff[idx_0]
        d05 = diff[idx_05]
        id_0 = identify_algebraic(d0)
        id_05 = identify_algebraic(d05)
        algebraic_counter[id_0] += 1
        algebraic_counter[id_05] += 1
        print(f"  {gid:<6}{str(e1):<12}{str(e2):<12}"
              f"{d0:<16.8f}{d05:<16.8f}{id_0:<16}{id_05:<16}")

    print()
    print(f"  代数识别统计：")
    for val, count in algebraic_counter.most_common():
        print(f"    {val}: {count}")

    # ============================================================
    # 问题 4：保真度的正确检验
    # ============================================================
    print()
    print("=" * 78)
    print("  问题 4：保真度的正确检验（修正版）")
    print("=" * 78)
    print()

    # 正确的保真度：F(ρ₁, ρ₂) = Tr(sqrt(sqrt(ρ₁) ρ₂ sqrt(ρ₁)))
    # 对于纯态投影，简化为 |⟨ψ₁|ψ₂⟩|²
    # 对于混合态，需要矩阵平方根

    def fidelity_correct(rho1, rho2):
        """正确的保真度。"""
        # 计算 sqrt(rho1)
        evals1, evecs1 = np.linalg.eigh(rho1)
        evals1 = np.clip(evals1, 0, None)
        sqrt_rho1 = evecs1 @ np.diag(np.sqrt(evals1)) @ evecs1.conj().T
        # M = sqrt_rho1 @ rho2 @ sqrt_rho1
        M = sqrt_rho1 @ rho2 @ sqrt_rho1
        evals_M = np.linalg.eigvalsh(M)
        evals_M = np.clip(evals_M, 0, None)
        return float(np.sum(np.sqrt(evals_M)) ** 2)

    # 对图108，检验对合像的保真度
    gid_108 = None
    for gid, G in enumerate(graphs):
        edges = [tuple(sorted(e)) for e in G.edges()]
        if len(edges) == 13 and G.number_of_nodes() == 6:
            # 找图108
            if (2, 5) not in edges and (3, 5) not in edges:
                if (2, 3) in edges and (0, 4) in edges and (0, 1) in edges:
                    gid_108 = gid
                    break

    if gid_108 is not None:
        G = graphs[gid_108]
        edges = [tuple(sorted(e)) for e in G.edges()]
        print(f"  图108: 边 = {edges}")
        print(f"  对合像: {list(find_involution_pairs(G))}")
        print()

        # 计算每条边的 rho
        H_edges = {e: edge_matrix(e[0], e[1], SX_ops, SY_ops, SZ_ops)
                   for e in edges}
        H0 = sum(H_edges.values())
        s = 0.0
        rhos = {}
        for e in edges:
            M_defect = H_edges[e]
            H = H0 + (s - 1.0) * M_defect
            E0, gap, rho, deg = ground_state_density(H)
            rhos[e] = rho

        # 检验对合像的保真度
        print(f"  对合像的保真度（s=0）：")
        for e1, e2 in find_involution_pairs(G):
            f = fidelity_correct(rhos[e1], rhos[e2])
            print(f"    {e1} vs {e2}: F = {f:.10f}")
        print()

    # ============================================================
    # 问题 5：N=7、8 抽样异常解剖
    # ============================================================
    print("=" * 78)
    print("  问题 5：N=7、8 抽样异常解剖")
    print("=" * 78)
    print()

    # 对 N=7 和 N=8，检查 19 对和 17 对的共同结构
    for N_test in [7, 8]:
        print(f"  N={N_test}:")
        SX_ops_t, SY_ops_t, SZ_ops_t = build_site_ops(N_test)
        s_vals_t = np.linspace(-1.5, 0.0, 11)

        diff_orbit_same_count = 0
        diff_orbit_same_samples = []

        for sample in range(200):
            G = nx.gnp_random_graph(N_test, 0.5, seed=sample)
            if not nx.is_connected(G):
                continue
            edges = [tuple(sorted(e)) for e in G.edges()]
            if len(edges) < 3:
                continue

            orbits = find_edge_orbits(G)
            inv_pairs = find_involution_pairs(G)

            curves = {}
            for e in edges:
                curve, _ = compute_sorted_curve_and_gaps(
                    G, e, s_vals_t, SX_ops_t, SY_ops_t, SZ_ops_t)
                curves[e] = curve

            for i, e1 in enumerate(edges):
                for j in range(i + 1, len(edges)):
                    e2 = edges[j]
                    if orbits[e1] == orbits[e2]:
                        continue
                    same = all(
                        len(a) == len(b) and np.allclose(a, b, atol=1e-10)
                        for a, b in zip(curves[e1], curves[e2])
                    )
                    if same:
                        is_inv = tuple(sorted([e1, e2])) in inv_pairs
                        diff_orbit_same_count += 1
                        if not is_inv and len(diff_orbit_same_samples) < 5:
                            diff_orbit_same_samples.append({
                                "sample": sample,
                                "e1": list(e1),
                                "e2": list(e2),
                                "n_edges": len(edges),
                            })

        print(f"    异轨道同响应: {diff_orbit_same_count}")
        for s in diff_orbit_same_samples:
            print(f"      样本 {s['sample']}: {s['e1']} vs {s['e2']} (边数={s['n_edges']})")
        print()

    # ============================================================
    # 问题 6：模型依赖性
    # ============================================================
    print("=" * 78)
    print("  问题 6：模型依赖性（9/112 图依赖相互作用）")
    print("=" * 78)
    print()

    # 对每个图，比较四种规则下的同轨道异曲线数
    model_dependent_graphs = []

    for gid, G in enumerate(graphs):
        edges = [tuple(sorted(e)) for e in G.edges()]
        orbits = find_edge_orbits(G)

        # 对每种规则，统计同轨道异曲线数
        results_by_rule = {}
        for rule in ["heisenberg", "xxz", "ising", "xy"]:
            curves = {}
            for e in edges:
                curve, _ = compute_sorted_curve_and_gaps(
                    G, e, s_vals, SX_ops, SY_ops, SZ_ops,
                    rule=rule, delta=1.0)
                curves[e] = curve

            same_orbit_diff = 0
            for i, e1 in enumerate(edges):
                for j in range(i + 1, len(edges)):
                    e2 = edges[j]
                    if orbits[e1] != orbits[e2]:
                        continue
                    same = all(
                        len(a) == len(b) and np.allclose(a, b, atol=1e-10)
                        for a, b in zip(curves[e1], curves[e2])
                    )
                    if not same:
                        same_orbit_diff += 1
            results_by_rule[rule] = same_orbit_diff

        # 如果某个规则有反例而其他没有，标记为模型依赖
        if len(set(results_by_rule.values())) > 1:
            model_dependent_graphs.append({
                "gid": gid,
                "results": results_by_rule,
            })

    print(f"  模型依赖的图数: {len(model_dependent_graphs)}")
    for md in model_dependent_graphs[:10]:
        print(f"    图 {md['gid']}: {md['results']}")
    print()

    # ============================================================
    # 问题 7：图 69 的结构解剖
    # ============================================================
    print("=" * 78)
    print("  问题 7：图 69 的结构解剖（9 对异轨道同响应的最大来源）")
    print("=" * 78)
    print()

    G69 = graphs[69]
    edges_69 = list(G69.edges())
    print(f"  图69 边: {edges_69}")
    print(f"  图69 节点数: {G69.number_of_nodes()}")
    print(f"  图69 边数: {G69.number_of_edges()}")
    print(f"  图69 度序列: {sorted(dict(G69.degree()).values(), reverse=True)}")
    print(f"  图69 三角形数: {sum(nx.triangles(G69).values()) // 3}")
    print(f"  图69 直径: {nx.diameter(G69)}")
    print(f"  图69 自同构数: {len(find_automorphisms(G69))}")
    print()

    orbits_69 = find_edge_orbits(G69)
    print(f"  图69 边轨道:")
    orbit_groups = defaultdict(list)
    for e, oid in orbits_69.items():
        orbit_groups[oid].append(e)
    for oid, es in sorted(orbit_groups.items()):
        print(f"    轨道 {oid}: {es}")
    print()

    inv_pairs_69 = find_involution_pairs(G69)
    print(f"  图69 对合像: {list(inv_pairs_69)}")
    print()

    # 图69 的 9 对异轨道同响应
    print(f"  图69 的异轨道同响应:")
    curves_69 = {}
    for e in [tuple(sorted(e)) for e in G69.edges()]:
        curve, _ = compute_sorted_curve_and_gaps(
            G69, e, s_vals, SX_ops, SY_ops, SZ_ops)
        curves_69[e] = curve

    edges_69_sorted = [tuple(sorted(e)) for e in G69.edges()]
    for i, e1 in enumerate(edges_69_sorted):
        for j in range(i + 1, len(edges_69_sorted)):
            e2 = edges_69_sorted[j]
            if orbits_69[e1] == orbits_69[e2]:
                continue
            same = all(
                len(a) == len(b) and np.allclose(a, b, atol=1e-10)
                for a, b in zip(curves_69[e1], curves_69[e2])
            )
            if same:
                is_inv = tuple(sorted([e1, e2])) in inv_pairs_69
                print(f"    {e1} vs {e2} (对合像={is_inv})")

    print()

    # ============================================================
    # 保存
    # ============================================================
    output = {
        "involution_same_orbit": inv_same_orbit,
        "involution_diff_orbit": inv_diff_orbit,
        "diff_orbit_same": len(diff_orbit_same),
        "gap_exceptions": len(gap_exceptions),
        "algebraic_counter": dict(algebraic_counter),
        "model_dependent_count": len(model_dependent_graphs),
    }
    with open("一次性解决所有遗留问题结果.json", "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2, default=str)
    print("已保存: 一次性解决所有遗留问题结果.json")


if __name__ == "__main__":
    main()