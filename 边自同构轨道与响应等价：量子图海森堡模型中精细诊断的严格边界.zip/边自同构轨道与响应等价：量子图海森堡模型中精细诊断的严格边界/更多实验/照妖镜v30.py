#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 v30.0：S 值相同的 2457 对中的第二层条件穷举搜索
================================================================

v29 发现：
  - S 值相同是必要条件（274 对 S 值不同的全部异响应）
  - 但 S 值相同不充分（2457 对中只有 47 对同响应）

v30 集中攻击：
  在 S 值相同的 2457 对中，穷举搜索能区分 47 同响应 vs 2410 异响应的第二层条件。

五个追问：
  Q1. sd1@0.5 = sd2@0.5 是第二层条件吗？
  Q2. sd1(s) = sd2(s) 处处相等（即 pS 曲线相等）是第二层条件吗？
  Q3. 简并度条件 d1 = d2 是第二层条件吗？
  Q4. 组合条件的效果如何？
  Q5. 是否存在"全覆盖 47 对且只覆盖 47 对"的条件？
"""

import sys, io, itertools, json, os
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from collections import Counter, defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"


# ============================================================
# 基础
# ============================================================

def build_atlas_graphs(N):
    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    return graphs


def build_sz0_sector(N):
    n_up = N // 2
    basis = []
    for comb in itertools.combinations(range(N), n_up):
        state = [0]*N
        for i in comb: state[i] = 1
        basis.append(tuple(state))
    dim = len(basis)
    idx = {s: i for i, s in enumerate(basis)}
    SZ_ops = []
    for site in range(N):
        SZ = np.zeros((dim, dim), dtype=complex)
        for i, state in enumerate(basis):
            SZ[i, i] = 1 if state[site] == 1 else -1
        SZ_ops.append(SZ)
    return basis, idx, SZ_ops


def build_edge_op(i, j, basis, idx):
    dim = len(basis)
    op = np.zeros((dim, dim), dtype=complex)
    for a_idx, state_a in enumerate(basis):
        sa, sb = state_a[i], state_a[j]
        if sa == sb:
            op[a_idx, a_idx] += 1
        else:
            op[a_idx, a_idx] += -1
            new_state = list(state_a)
            new_state[i], new_state[j] = new_state[j], new_state[i]
            b_idx = idx.get(tuple(new_state))
            if b_idx is not None:
                op[b_idx, a_idx] += 2
    return op


def build_S2_op(basis, idx, N):
    dim = len(basis)
    S2 = np.zeros((dim, dim), dtype=complex)
    for i in range(N):
        S2 += 3/4 * np.eye(dim, dtype=complex)
        for j in range(N):
            if i == j: continue
            S2 += 1/4 * build_edge_op(i, j, basis, idx)
    return S2


def analyze_at_s(edge_ops, defect, s, SZ_ops, S2_op, ref_dim):
    H = np.zeros((ref_dim, ref_dim), dtype=complex)
    for e, M in edge_ops.items():
        c = s if e == defect else 1.0
        H += c * M
    try:
        evals, evecs = eigh(H)
    except Exception:
        return None
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < 1e-8))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    S2_val = float(np.real(np.trace(rho @ S2_op)))
    S_total = (-1 + np.sqrt(1 + 4*max(S2_val, 0))) / 2
    i, j = defect
    szsz_diag = np.diag(SZ_ops[i] @ SZ_ops[j])
    szsz = float(np.real(np.sum(np.diag(rho) * szsz_diag)))
    p_S = (1 - 3 * szsz) / 4
    sd = float(np.real(np.trace(rho @ edge_ops[defect])))
    return {"S": S_total, "pS": p_S, "sd": sd, "deg": deg}


def load_patterns():
    with open(os.path.join(WORK_DIR, "照妖镜_v5_1_模式.json"), "r",
              encoding="utf-8") as f:
        v51 = json.load(f)
    patterns = {}
    for key, s in v51["patterns"].items():
        gid, e1_str, e2_str = key.split("_", 2)
        gid = int(gid)
        e1 = tuple(map(int, e1_str.strip("()").split(",")))
        e2 = tuple(map(int, e2_str.strip("()").split(",")))
        patterns[(gid, tuple(sorted(e1)), tuple(sorted(e2)))] = s
    return patterns


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 100)
    print("照妖镜 v30.0：S 值相同的 2457 对中的第二层条件穷举搜索")
    print("=" * 100)

    N = 6
    graphs = build_atlas_graphs(N)
    patterns = load_patterns()
    print(f"\n  N={N} 图集: {len(graphs)} 图")
    print(f"  已知同响应对: {len(patterns)}")

    basis, idx, SZ_ops = build_sz0_sector(N)
    ref_dim = len(basis)
    S2_op = build_S2_op(basis, idx, N)

    # s 采样点
    s_vals = [0.0, 0.25, 0.5, 0.75, 1.0, 1.5, 2.0]

    # 扫描全部 2731 对
    print(f"\n  扫描全部 2731 对（采样 {len(s_vals)} 个 s 值）...")
    all_pairs = []
    for gid, G in enumerate(graphs):
        if gid % 30 == 0:
            print(f"    {gid}/{len(graphs)}")
        edges = [tuple(sorted(e)) for e in G.edges()]
        GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
        autos = list(GM.isomorphisms_iter())
        orbits = {}
        for e in edges:
            orbit = frozenset(frozenset({a[e[0]], a[e[1]]}) for a in autos)
            orbits[e] = orbit

        edge_ops = {e: build_edge_op(e[0], e[1], basis, idx) for e in edges}

        # 每条边在所有 s 处的特征
        edge_features = {}
        for e in edges:
            edge_features[e] = {}
            for s in s_vals:
                r = analyze_at_s(edge_ops, e, s, SZ_ops, S2_op, ref_dim)
                edge_features[e][s] = r

        for i in range(len(edges)):
            for j in range(i + 1, len(edges)):
                e1, e2 = edges[i], edges[j]
                if orbits[e1] == orbits[e2]:
                    continue
                key = (gid, e1, e2)
                n_true = patterns[key].count("1") if key in patterns else 0

                # 提取关键值
                f1 = edge_features[e1][0.5]
                f2 = edge_features[e2][0.5]
                if not f1 or not f2:
                    continue

                # 曲线
                pS1_curve = np.array([edge_features[e1][s]["pS"]
                                       for s in s_vals])
                pS2_curve = np.array([edge_features[e2][s]["pS"]
                                       for s in s_vals])
                sd1_curve = np.array([edge_features[e1][s]["sd"]
                                       for s in s_vals])
                sd2_curve = np.array([edge_features[e2][s]["sd"]
                                       for s in s_vals])

                all_pairs.append({
                    "gid": gid, "e1": e1, "e2": e2,
                    "n_true": n_true,
                    "S1": f1["S"], "S2": f2["S"],
                    "d1": f1["deg"], "d2": f2["deg"],
                    "pS1_curve": pS1_curve.tolist(),
                    "pS2_curve": pS2_curve.tolist(),
                    "sd1_curve": sd1_curve.tolist(),
                    "sd2_curve": sd2_curve.tolist(),
                    "pS1_at_0.5": f1["pS"], "pS2_at_0.5": f2["pS"],
                    "sd1_at_0.5": f1["sd"], "sd2_at_0.5": f2["sd"],
                    "sd1_at_0": edge_features[e1][0.0]["sd"],
                    "sd2_at_0": edge_features[e2][0.0]["sd"],
                    "sd1_at_1": edge_features[e1][1.0]["sd"],
                    "sd2_at_1": edge_features[e2][1.0]["sd"],
                    "S_same": abs(f1["S"] - f2["S"]) < 1e-3,
                })

    print(f"\n  总对数: {len(all_pairs)}")

    # ============================================================
    # 过滤到 S 值相同的对
    # ============================================================
    S_same_pairs = [p for p in all_pairs if p["S_same"]]
    S_same_same_resp = [p for p in S_same_pairs if p["n_true"] > 0]
    S_same_diff_resp = [p for p in S_same_pairs if p["n_true"] == 0]

    print(f"  S 值相同: {len(S_same_pairs)}")
    print(f"  其中同响应: {len(S_same_same_resp)}")
    print(f"  其中异响应: {len(S_same_diff_resp)}")

    # ============================================================
    # Q1: sd1@0.5 = sd2@0.5 条件
    # ============================================================
    print("\n" + "=" * 100)
    print("Q1. sd1@0.5 = sd2@0.5 条件")
    print("=" * 100)

    conditions = [
        ("sd1@0.5 == sd2@0.5", lambda p: abs(p["sd1_at_0.5"] - p["sd2_at_0.5"]) < 1e-6),
        ("|sd1@0.5 - sd2@0.5| < 0.01", lambda p: abs(p["sd1_at_0.5"] - p["sd2_at_0.5"]) < 0.01),
        ("|sd1@0.5 - sd2@0.5| < 0.1", lambda p: abs(p["sd1_at_0.5"] - p["sd2_at_0.5"]) < 0.1),
        ("sd1@0.5 == sd2@0.5 且 = -1", lambda p: abs(p["sd1_at_0.5"] + 1) < 1e-6 and abs(p["sd2_at_0.5"] + 1) < 1e-6),
        ("sd1@0.5 == sd2@0.5 且 = +1", lambda p: abs(p["sd1_at_0.5"] - 1) < 1e-6 and abs(p["sd2_at_0.5"] - 1) < 1e-6),
        ("sd1@0.5 == sd2@0.5 且 = 0", lambda p: abs(p["sd1_at_0.5"]) < 1e-6 and abs(p["sd2_at_0.5"]) < 1e-6),
    ]

    print(f"\n  {'条件':<40} | {'候选数':>6} | {'命中同响应':>8} | {'精度':>6} | {'召回':>6}")
    print(f"  {'-'*40}-+-{'-'*6}-+-{'-'*8}-+-{'-'*6}-+-{'-'*6}")
    for name, cond in conditions:
        subset = [p for p in S_same_pairs if cond(p)]
        n_hit = sum(1 for p in subset if p["n_true"] > 0)
        prec = n_hit / len(subset) if subset else 0
        rec = n_hit / len(S_same_same_resp) if S_same_same_resp else 0
        print(f"  {name:<40} | {len(subset):>6} | {n_hit:>8} | "
              f"{prec:>5.1%} | {rec:>5.1%}")

    # ============================================================
    # Q2: pS 曲线相等条件
    # ============================================================
    print("\n" + "=" * 100)
    print("Q2. pS 曲线相等 / sd 曲线相等条件")
    print("=" * 100)

    conditions2 = [
        ("pS 曲线完全相等（<1e-10）", lambda p: np.max(np.abs(
            np.array(p["pS1_curve"]) - np.array(p["pS2_curve"]))) < 1e-10),
        ("pS 曲线相等（<1e-6）", lambda p: np.max(np.abs(
            np.array(p["pS1_curve"]) - np.array(p["pS2_curve"]))) < 1e-6),
        ("pS 曲线相等（<1e-4）", lambda p: np.max(np.abs(
            np.array(p["pS1_curve"]) - np.array(p["pS2_curve"]))) < 1e-4),
        ("sd 曲线完全相等（<1e-10）", lambda p: np.max(np.abs(
            np.array(p["sd1_curve"]) - np.array(p["sd2_curve"]))) < 1e-10),
        ("sd 曲线相等（<1e-6）", lambda p: np.max(np.abs(
            np.array(p["sd1_curve"]) - np.array(p["sd2_curve"]))) < 1e-6),
        ("pS 曲线在 s=0.5 处相交", lambda p: abs(p["pS1_at_0.5"] - p["pS2_at_0.5"]) < 1e-6),
    ]

    print(f"\n  {'条件':<40} | {'候选数':>6} | {'命中同响应':>8} | {'精度':>6} | {'召回':>6}")
    print(f"  {'-'*40}-+-{'-'*6}-+-{'-'*8}-+-{'-'*6}-+-{'-'*6}")
    for name, cond in conditions2:
        subset = [p for p in S_same_pairs if cond(p)]
        n_hit = sum(1 for p in subset if p["n_true"] > 0)
        prec = n_hit / len(subset) if subset else 0
        rec = n_hit / len(S_same_same_resp) if S_same_same_resp else 0
        print(f"  {name:<40} | {len(subset):>6} | {n_hit:>8} | "
              f"{prec:>5.1%} | {rec:>5.1%}")

    # ============================================================
    # Q3: 简并度条件
    # ============================================================
    print("\n" + "=" * 100)
    print("Q3. 简并度条件")
    print("=" * 100)

    conditions3 = [
        ("d1 == d2", lambda p: p["d1"] == p["d2"]),
        ("d1 == d2 == 1（都非简并）", lambda p: p["d1"] == 1 and p["d2"] == 1),
        ("max(d1,d2) == 1", lambda p: max(p["d1"], p["d2"]) == 1),
        ("max(d1,d2) > 1", lambda p: max(p["d1"], p["d2"]) > 1),
        ("min(d1,d2) > 1", lambda p: min(p["d1"], p["d2"]) > 1),
    ]

    print(f"\n  {'条件':<40} | {'候选数':>6} | {'命中同响应':>8} | {'精度':>6} | {'召回':>6}")
    print(f"  {'-'*40}-+-{'-'*6}-+-{'-'*8}-+-{'-'*6}-+-{'-'*6}")
    for name, cond in conditions3:
        subset = [p for p in S_same_pairs if cond(p)]
        n_hit = sum(1 for p in subset if p["n_true"] > 0)
        prec = n_hit / len(subset) if subset else 0
        rec = n_hit / len(S_same_same_resp) if S_same_same_resp else 0
        print(f"  {name:<40} | {len(subset):>6} | {n_hit:>8} | "
              f"{prec:>5.1%} | {rec:>5.1%}")

    # ============================================================
    # Q4: 组合条件
    # ============================================================
    print("\n" + "=" * 100)
    print("Q4. 组合条件")
    print("=" * 100)

    def comb1(p):
        return (abs(p["sd1_at_0.5"] - p["sd2_at_0.5"]) < 1e-6 and p["d1"] == 1 and p["d2"] == 1)

    def comb2(p):
        return (np.max(np.abs(np.array(p["pS1_curve"]) - np.array(p["pS2_curve"]))) < 1e-6 and p["d1"] == 1 and p["d2"] == 1)

    def comb3(p):
        return (abs(p["sd1_at_0.5"] - p["sd2_at_0.5"]) < 1e-6 and p["d1"] == p["d2"])

    def comb4(p):
        return (abs(p["sd1_at_0"] - p["sd2_at_0"]) < 1e-6 and p["d1"] == p["d2"])

    def comb5(p):
        return (abs(p["sd1_at_1"] - p["sd2_at_1"]) < 1e-6 and p["d1"] == p["d2"])

    conditions4 = [
        ("sd1@0.5 == sd2@0.5 & d1=d2=1", comb1),
        ("pS 曲线相等 & d1=d2=1", comb2),
        ("sd1@0.5 == sd2@0.5 & d1=d2", comb3),
        ("sd1@0 == sd2@0 & d1=d2", comb4),
        ("sd1@1 == sd2@1 & d1=d2", comb5),
    ]

    print(f"\n  {'条件':<40} | {'候选数':>6} | {'命中同响应':>8} | {'精度':>6} | {'召回':>6}")
    print(f"  {'-'*40}-+-{'-'*6}-+-{'-'*8}-+-{'-'*6}-+-{'-'*6}")
    for name, cond in conditions4:
        subset = [p for p in S_same_pairs if cond(p)]
        n_hit = sum(1 for p in subset if p["n_true"] > 0)
        prec = n_hit / len(subset) if subset else 0
        rec = n_hit / len(S_same_same_resp) if S_same_same_resp else 0
        print(f"  {name:<40} | {len(subset):>6} | {n_hit:>8} | "
              f"{prec:>5.1%} | {rec:>5.1%}")

    # ============================================================
    # Q5: 是否存在完美条件？
    # ============================================================
    print("\n" + "=" * 100)
    print("Q5. 是否存在完美条件（精确率=100%，召回率=100%）？")
    print("=" * 100)

    # 用更细的搜索：对所有 sd 值取不同阈值
    print(f"\n  --- sd1@0.5 的值分布（47 同响应 vs 其他）---")
    same_sd_vals = sorted(set(round(p["sd1_at_0.5"], 3) for p in S_same_same_resp))
    diff_sd_vals = sorted(set(round(p["sd1_at_0.5"], 3) for p in S_same_diff_resp))
    print(f"  同响应 sd1@0.5 值: {same_sd_vals[:20]}")
    print(f"  异响应 sd1@0.5 值: {diff_sd_vals[:20]}")

    # 检查 sd1@0.5 的特殊值
    print(f"\n  --- sd1@0.5 == -1 或 sd1@0.5 == 1 的对 ---")
    for sd_val in [-1.0, 0.0, 1.0]:
        subset = [p for p in S_same_pairs if abs(p["sd1_at_0.5"] - sd_val) < 1e-6]
        n_hit = sum(1 for p in subset if p["n_true"] > 0)
        print(f"  sd1@0.5 == {sd_val}: 候选 {len(subset)}, 命中 {n_hit}, "
              f"精度 {n_hit/len(subset):.1%}" if subset else "")

    # ============================================================
    # 额外追问：S = 0 vs S = 1 的分开分析
    # ============================================================
    print("\n" + "=" * 100)
    print("额外追问：按 S 值分层，第二层条件的效果")
    print("=" * 100)

    for S_val in [0.0, 1.0]:
        print(f"\n  --- S = {S_val} ---")
        S_subset = [p for p in S_same_pairs if abs(p["S1"] - S_val) < 1e-6]
        S_same_resp = [p for p in S_subset if p["n_true"] > 0]
        S_diff_resp = [p for p in S_subset if p["n_true"] == 0]
        print(f"  S 值相同的对: {len(S_subset)}")
        print(f"  同响应: {len(S_same_resp)}")
        print(f"  异响应: {len(S_diff_resp)}")

        # 在这个 S 值内，测试 sd1@0.5 == sd2@0.5 条件
        cond_subset = [p for p in S_subset if abs(p["sd1_at_0.5"] - p["sd2_at_0.5"]) < 1e-6]
        n_hit = sum(1 for p in cond_subset if p["n_true"] > 0)
        print(f"  sd1@0.5 == sd2@0.5: 候选 {len(cond_subset)}, 命中 {n_hit}")
        if cond_subset:
            print(f"    精度: {n_hit/len(cond_subset):.1%}")
            print(f"    召回: {n_hit/len(S_same_resp):.1%}" if S_same_resp else "")

    # ============================================================
    # 导出
    # ============================================================
    out = {
        "n_total_pairs": len(all_pairs),
        "n_S_same": len(S_same_pairs),
        "n_S_same_same_resp": len(S_same_same_resp),
        "n_S_same_diff_resp": len(S_same_diff_resp),
    }
    out_path = os.path.join(WORK_DIR, "照妖镜_v30_第二层条件.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("v30.0 完成。")
    print("=" * 100)


if __name__ == "__main__":
    main()