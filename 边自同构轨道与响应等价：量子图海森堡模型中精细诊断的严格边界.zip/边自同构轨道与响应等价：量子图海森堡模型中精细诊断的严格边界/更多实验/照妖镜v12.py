#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 v12.0：补齐 N=7 的 p_S 分析
================================================================

目标：
  用与 N=6 完全相同的方法，对 N=7 的 853 个连通图做 p_S 分析。

五个追问并行：
  Q1. N=7 的 p_S(s) 是否单调？谐振点在哪？
  Q2. 谐振 s 值是否也是 0.5 的倍数？
  Q3. 非简并基态下 <σ·σ> = -1 是否精确成立？
  Q4. 简并基态的自旋扇区结构是否和 N=6 一样？
  Q5. 谐振点总数、唯一 s 值数、非简并/简并比例是否和 N=6 同量级？

晶脉哲学：
  · 关系本体论：S_z=0 扇区是关系网络的一个对称切片
  · 对象化=截断=产生方向：每个谐振点都是一个截断
  · 只查同与不同：不筛选，不排序
  · 反对对齐：不预设结论
"""

import sys, io, itertools, json, os
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from scipy.optimize import brentq
from collections import Counter, defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"
N = 7
TOL = 1e-10


# ============================================================
# S_z=0 扇区的构建
# ============================================================

def build_sz0_sector(N):
    """构建 S_z=0 扇区的基矢和单点 σ^z 算符"""
    n_up = N // 2
    basis = []
    for comb in itertools.combinations(range(N), n_up):
        state = [0]*N
        for i in comb: state[i] = 1
        basis.append(tuple(state))
    dim = len(basis)
    idx = {s: i for i, s in enumerate(basis)}

    # σ^z 算符（对角）
    SZ_ops = []
    for site in range(N):
        SZ = np.zeros((dim, dim), dtype=complex)
        for i, state in enumerate(basis):
            SZ[i, i] = 1 if state[site] == 1 else -1
        SZ_ops.append(SZ)

    return basis, idx, SZ_ops


def build_edge_op(i, j, basis, idx):
    """在 S_z=0 扇区中构建 σ_i · σ_j 算符"""
    dim = len(basis)
    op = np.zeros((dim, dim), dtype=complex)
    for a_idx, state_a in enumerate(basis):
        sa, sb = state_a[i], state_a[j]
        if sa == sb:
            # 两者都向上或都向下：σ_i·σ_j = +1
            op[a_idx, a_idx] += 1
        else:
            # 反平行：σ^z σ^z = -1，翻转项交换
            op[a_idx, a_idx] += -1
            new_state = list(state_a)
            new_state[i], new_state[j] = new_state[j], new_state[i]
            b_idx = idx.get(tuple(new_state))
            if b_idx is not None:
                op[b_idx, a_idx] += 2
    return op


def build_S2_op(basis, idx, N):
    """总 S² = (1/4) Σ_ij σ_i · σ_j（在 S_z=0 扇区中）"""
    dim = len(basis)
    S2 = np.zeros((dim, dim), dtype=complex)
    for i in range(N):
        S2 += 3/4 * np.eye(dim, dtype=complex)
        for j in range(N):
            if i == j: continue
            S2 += 1/4 * build_edge_op(i, j, basis, idx)
    return S2


# ============================================================
# p_S 计算
# ============================================================

def pS_at_s(edge_ops, defect, s, SZ_ops):
    """在 s 处计算 p_S 和基态简并度"""
    # 哈密顿量
    H = np.zeros_like(next(iter(edge_ops.values())))
    for e, M in edge_ops.items():
        c = s if e == defect else 1.0
        H += c * M
    evals, evecs = eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < 1e-8))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    # ⟨σ^z_i σ^z_j⟩
    i, j = defect
    szsz_diag = np.diag(SZ_ops[i] @ SZ_ops[j])
    szsz = float(np.real(np.sum(np.diag(rho) * szsz_diag)))
    # p_S = (1 - 3⟨σ^z σ^z⟩)/4
    p_S = (1 - 3 * szsz) / 4
    return p_S, deg, E0, evals, evecs


def analyze_resonance(edge_ops, defect, s, SZ_ops, S2_op):
    """在谐振点 s 处分析简并自旋结构"""
    p_S, deg, E0, evals, evecs = pS_at_s(edge_ops, defect, s, SZ_ops)
    V = evecs[:, :deg]

    per_state_sigdot = []
    per_state_S = []
    for k in range(deg):
        v = V[:, k]
        sd = float(np.real(v.conj() @ edge_ops[defect] @ v))
        s2 = float(np.real(v.conj() @ S2_op @ v))
        S_val = (-1 + np.sqrt(1 + 4*max(s2, 0))) / 2
        per_state_sigdot.append(sd)
        per_state_S.append(S_val)

    return {
        "p_S": p_S,
        "deg": deg,
        "E0": float(E0),
        "mean_sigdot": float(np.mean(per_state_sigdot)),
        "per_state_sigdot": per_state_sigdot,
        "per_state_S": per_state_S,
    }


# ============================================================
# 代数识别
# ============================================================

def identify_algebraic(s):
    """识别有理数或简单二次代数数"""
    if abs(s) < 1e-10: return "0"
    # 0.5 倍数
    if abs(s - round(s*2)/2) < 1e-10:
        v = round(s*2)/2
        return f"{v}（0.5 倍数）"
    # 有理数
    for q in range(1, 21):
        p = round(s * q)
        if abs(s - p/q) < 1e-10:
            return f"{p}/{q}"
    # 二次代数数：a·s² + b·s + c = 0，a,b,c 小整数
    for a in range(1, 11):
        for b in range(-20, 21):
            for c in range(-20, 21):
                if abs(a*s*s + b*s + c) < 1e-8:
                    disc = b*b - 4*a*c
                    return f"({-b}±√{disc})/{2*a}"
    return "未识别"


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 100)
    print("照妖镜 v12.0：补齐 N=7 的 p_S 分析")
    print("=" * 100)

    # 图集
    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    print(f"\n  N={N} 图集: {len(cand)} 个（未去重）")

    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    print(f"  去重后: {len(graphs)} 个连通图")

    # S_z=0 扇区
    basis, idx, SZ_ops = build_sz0_sector(N)
    print(f"  S_z=0 扇区维度: {len(basis)}")

    S2_op = build_S2_op(basis, idx, N)
    print(f"  S² 算符构建完成")

    # s 网格
    s_grid_coarse = np.linspace(-2.0, 2.0, 41)
    print(f"  s 网格（粗）: [{s_grid_coarse[0]}, {s_grid_coarse[-1]}], "
          f"{len(s_grid_coarse)} 点")

    # 逐图扫描
    all_resonances = []
    print(f"\n  扫描 {len(graphs)} 个图...")

    for gid, G in enumerate(graphs):
        if gid % 100 == 0:
            print(f"    {gid}/{len(graphs)}")
        edges = [tuple(sorted(e)) for e in G.edges()]
        # 预计算边算符
        edge_ops = {e: build_edge_op(e[0], e[1], basis, idx) for e in edges}

        for defect in edges:
            # 粗扫 p_S(s)
            pS_curve = np.array([
                pS_at_s(edge_ops, defect, s, SZ_ops)[0]
                for s in s_grid_coarse
            ])

            # 找 p_S = 1/2 的交叉
            for k in range(len(s_grid_coarse) - 1):
                if (pS_curve[k] - 0.5) * (pS_curve[k+1] - 0.5) < 0:
                    try:
                        s_res = brentq(
                            lambda s: pS_at_s(edge_ops, defect, s, SZ_ops)[0] - 0.5,
                            s_grid_coarse[k], s_grid_coarse[k+1], xtol=1e-10)
                        info = analyze_resonance(
                            edge_ops, defect, s_res, SZ_ops, S2_op)
                        all_resonances.append({
                            "gid": gid,
                            "defect": list(defect),
                            "s": float(s_res),
                            **info,
                        })
                    except Exception:
                        pass

    print(f"\n  总谐振点数: {len(all_resonances)}")

    # ============================================================
    # 汇总分析
    # ============================================================
    print("\n" + "=" * 100)
    print("N=7 谐振点汇总")
    print("=" * 100)

    if not all_resonances:
        print("\n  未找到谐振点。")
        return

    # s 值分布
    print(f"\n  --- s 值分布 ---")
    s_counter = Counter(round(r["s"], 8) for r in all_resonances)
    unique_s = sorted(s_counter.keys())
    print(f"  唯一 s 值: {len(unique_s)} 个")
    print(f"\n  {'s 值':>16} | {'数量':>6} | {'代数识别':>20}")
    print(f"  {'-'*16}-+-{'-'*6}-+-{'-'*20}")
    for s_val in unique_s[:30]:
        cnt = s_counter[s_val]
        ident = identify_algebraic(s_val)
        print(f"  {s_val:>16.10f} | {cnt:>6} | {ident:>20}")

    # 非简并 vs 简并
    nondeg = [r for r in all_resonances if r["deg"] == 1]
    deg = [r for r in all_resonances if r["deg"] > 1]
    print(f"\n  --- 简并度分布 ---")
    print(f"  非简并（deg=1）: {len(nondeg)} 个 "
          f"({len(nondeg)/len(all_resonances):.1%})")
    print(f"  简并（deg>1）:   {len(deg)} 个 "
          f"({len(deg)/len(all_resonances):.1%})")

    if nondeg:
        sd = np.array([r["mean_sigdot"] for r in nondeg])
        print(f"\n  非简并的 <σ·σ>:")
        print(f"    mean = {np.mean(sd):.10f}")
        print(f"    min  = {np.min(sd):.10f}")
        print(f"    max  = {np.max(sd):.10f}")
        dev = np.abs(sd + 1)
        print(f"    与 -1 的偏差 max = {np.max(dev):.3e}")
        n_exact = int(np.sum(dev < 1e-8))
        print(f"    |<σ·σ> - (-1)| < 1e-8 的数量: {n_exact}/{len(nondeg)}")

    if deg:
        sd_deg = np.array([r["mean_sigdot"] for r in deg])
        print(f"\n  简并的 <σ·σ>:")
        print(f"    mean = {np.mean(sd_deg):.10f}")
        dev = np.abs(sd_deg + 1)
        n_exact = int(np.sum(dev < 1e-8))
        print(f"    |<σ·σ> - (-1)| < 1e-8 的数量: {n_exact}/{len(deg)}")

    # d↔S 对应
    print(f"\n  --- 简并度 ↔ 总自旋 S 对应 ---")
    print(f"\n  {'deg':>6} | {'数量':>6} | {'S 均值':>8} | {'S 范围':>20}")
    print(f"  {'-'*6}-+-{'-'*6}-+-{'-'*8}-+-{'-'*20}")
    by_deg = defaultdict(list)
    for r in all_resonances:
        by_deg[r["deg"]].append(r)

    for d in sorted(by_deg.keys()):
        items = by_deg[d]
        all_S = [s for r in items for s in r["per_state_S"]]
        print(f"  {d:>6} | {len(items):>6} | {np.mean(all_S):>8.4f} | "
              f"[{np.min(all_S):.4f}, {np.max(all_S):.4f}]")

    # ============================================================
    # 与 N=6 并排
    # ============================================================
    print("\n" + "=" * 100)
    print("与 N=6 并排比较")
    print("=" * 100)

    print(f"""
  {'指标':<35} | {'N=6':>12} | {'N=7':>12}
  {'-'*35}-+-{'-'*12}-+-{'-'*12}
  {'图数（连通）':<35} | {'112':>12} | {len(graphs):>12}
  {'S_z=0 扇区维度':<35} | {'20':>12} | {len(basis):>12}
  {'总谐振点数':<35} | {'48':>12} | {len(all_resonances):>12}
  {'唯一 s 值数':<35} | {'11':>12} | {len(unique_s):>12}
  {'非简并（deg=1）数':<35} | {'19':>12} | {len(nondeg):>12}
  {'简并（deg>1）数':<35} | {'29':>12} | {len(deg):>12}
  {'非简并 -1 命中率':<35} | {'18/19':>12} | {f"{sum(1 for r in nondeg if abs(r['mean_sigdot']+1)<1e-8)}/{len(nondeg)}":>12}
  {'简并 -1 命中率':<35} | {'19/29':>12} | {f"{sum(1 for r in deg if abs(r['mean_sigdot']+1)<1e-8)}/{len(deg)}":>12}
  {'s=0.5 倍数占比':<35} | {'75%':>12} | {f"{sum(1 for s in unique_s if abs(s-round(s*2)/2)<1e-8)/len(unique_s):.0%}":>12}
""")

    # ============================================================
    # 导出
    # ============================================================
    out = {
        "N": N,
        "n_graphs": len(graphs),
        "sz0_dim": len(basis),
        "total_resonances": len(all_resonances),
        "unique_s_values": {str(k): v for k, v in s_counter.items()},
        "nondeg_count": len(nondeg),
        "deg_count": len(deg),
        "nondeg_hits": sum(1 for r in nondeg
                          if abs(r["mean_sigdot"] + 1) < 1e-8),
        "deg_hits": sum(1 for r in deg
                       if abs(r["mean_sigdot"] + 1) < 1e-8),
        "resonances": all_resonances,
    }
    out_path = os.path.join(WORK_DIR, "照妖镜_v12_N7_pS.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("v12.0 完成。N=7 的 p_S 分析被补齐。")
    print("=" * 100)


if __name__ == "__main__":
    main()