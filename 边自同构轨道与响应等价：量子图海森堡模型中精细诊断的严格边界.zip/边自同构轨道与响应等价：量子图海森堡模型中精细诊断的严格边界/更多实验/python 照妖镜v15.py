#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 v15.0：跨尺度离散性起源的五问并行攻击
================================================================

已知（v13-v14）：
  N=6: 11 个唯一 s 值，75% 是 0.5 倍数，82% 可代数识别 → 离散
  N=7: 4172 个唯一 s 值，0.2% 是 0.5 倍数，1% 可识别 → 连续
  N=8: 136 个唯一 s 值，1.5% 是 0.5 倍数，2.2% 可识别 → 连续

五个追问并行：
  Q1. 贡献图 vs 非贡献图的"关系位置指纹"
  Q2. N=6 的 47 对是否全部来自"高对称性"图？
  Q3. 唯一的 s 值是否集中在少数几对？是否存在"共享 s 值"
  Q4. N=6 的 8 个特殊图有共同的关系结构吗？
  Q5. 如果只保留"贡献图"，N=7 和 N=8 的代数识别率会提升吗？

晶脉哲学：
  · 关系本体论：图的关系位置由其边集、度序列、谱共同刻画
  · 对象化=截断=产生方向：每一个特征都是一次截断
  · 只查同与不同：不筛选，不排序
  · 反对对齐：不预设结论
"""

import sys, io, itertools, json, os, random
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from scipy.optimize import brentq
from collections import Counter, defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"


# ============================================================
# S_z=0 扇区
# ============================================================

def build_sz0_sector(N):
    n_up = N // 2
    basis = []
    for comb in itertools.combinations(range(N), n_up):
        state = [0]*N
        for i in comb: state[i] = 1
        basis.append(tuple(state))
    dim = len(basis)
    idx = {s: i for i, s in enumerate(basis)}
    SZ_ops = []
    for site in range(N):
        SZ = np.zeros((dim, dim), dtype=complex)
        for i, state in enumerate(basis):
            SZ[i, i] = 1 if state[site] == 1 else -1
        SZ_ops.append(SZ)
    return basis, idx, SZ_ops


def build_edge_op(i, j, basis, idx):
    dim = len(basis)
    op = np.zeros((dim, dim), dtype=complex)
    for a_idx, state_a in enumerate(basis):
        sa, sb = state_a[i], state_a[j]
        if sa == sb:
            op[a_idx, a_idx] += 1
        else:
            op[a_idx, a_idx] += -1
            new_state = list(state_a)
            new_state[i], new_state[j] = new_state[j], new_state[i]
            b_idx = idx.get(tuple(new_state))
            if b_idx is not None:
                op[b_idx, a_idx] += 2
    return op


def pS_at_s(edge_ops, defect, s, SZ_ops, ref_dim):
    H = np.zeros((ref_dim, ref_dim), dtype=complex)
    for e, M in edge_ops.items():
        c = s if e == defect else 1.0
        H += c * M
    try:
        evals, evecs = eigh(H)
    except Exception:
        return None
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < 1e-8))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    i, j = defect
    szsz_diag = np.diag(SZ_ops[i] @ SZ_ops[j])
    szsz = float(np.real(np.sum(np.diag(rho) * szsz_diag)))
    p_S = (1 - 3 * szsz) / 4
    return p_S


def find_resonances(edge_ops, defect, SZ_ops, ref_dim,
                    n_grid=41, s_lo=-2.0, s_hi=2.0):
    s_grid = np.linspace(s_lo, s_hi, n_grid)
    pS_vals = []
    for s in s_grid:
        p = pS_at_s(edge_ops, defect, s, SZ_ops, ref_dim)
        pS_vals.append(p if p is not None else 0.0)
    pS_vals = np.array(pS_vals)
    crossings = []
    for k in range(len(s_grid) - 1):
        if (pS_vals[k] - 0.5) * (pS_vals[k+1] - 0.5) < 0:
            try:
                s_res = brentq(
                    lambda s: pS_at_s(edge_ops, defect, s, SZ_ops, ref_dim) - 0.5,
                    s_grid[k], s_grid[k+1], xtol=1e-10)
                crossings.append(s_res)
            except Exception:
                pass
    return crossings


# ============================================================
# 代数识别
# ============================================================

def identify_algebraic(s, tol=1e-6):
    if abs(s) < 1e-9: return "half"
    if abs(s - round(s*2)/2) < 1e-9: return "half"
    for q in [2,3,4,5,6,7,8,10,12,15,20]:
        p = round(s * q)
        if abs(s - p/q) < tol:
            return "rational"
    for a in range(1, 6):
        for b in range(-10, 11):
            for c in range(-10, 11):
                if abs(a*s*s + b*s + c) < tol:
                    return "quadratic"
    return "unidentified"


# ============================================================
# 图的关系特征
# ============================================================

def relation_fingerprint(G):
    """提取图的多种关系特征"""
    n = G.number_of_nodes()
    edges = list(G.edges())
    n_e = len(edges)

    # 度分布
    degs = [d for _, d in G.degree()]
    deg_entropy = 0.0
    deg_counter = Counter(degs)
    for d, c in deg_counter.items():
        p = c / n
        if p > 0:
            deg_entropy -= p * np.log(p)

    # 谱
    L = nx.laplacian_matrix(G).astype(float).toarray()
    L_eigs = sorted(np.linalg.eigvalsh(L))
    L_gap = L_eigs[1] if len(L_eigs) > 1 else 0

    A = nx.to_numpy_array(G)
    A_eigs = sorted(np.linalg.eigvalsh(A))
    A_radius = A_eigs[-1]

    # 拓扑
    n_bridges = len(list(nx.bridges(G)))
    n_triangles = sum(nx.triangles(G).values()) // 3
    try:
        G_conn = nx.is_connected(G)
    except Exception:
        G_conn = False

    # 自同构轨道
    GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
    n_autos = 0
    for _ in GM.isomorphisms_iter():
        n_autos += 1
        if n_autos > 2000:
            break

    # 轨道大小
    try:
        orbits = {}
        GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
        autos = []
        for p in GM.isomorphisms_iter():
            autos.append(p)
            if len(autos) > 500:
                break
        for e in edges:
            orbit = set()
            for p in autos:
                orbit.add(frozenset({p[e[0]], p[e[1]]}))
            orbits[e] = len(orbit)
        orbit_sizes = list(orbits.values())
        orbit_max = max(orbit_sizes) if orbit_sizes else 0
        orbit_entropy = 0.0
        cnt = Counter(orbit_sizes)
        for o, c in cnt.items():
            p = c / len(orbit_sizes)
            if p > 0:
                orbit_entropy -= p * np.log(p)
    except Exception:
        orbit_max = 0
        orbit_entropy = 0

    return {
        "n_edges": n_e,
        "deg_entropy": deg_entropy,
        "L_gap": L_gap,
        "A_radius": A_radius,
        "n_bridges": n_bridges,
        "n_triangles": n_triangles,
        "n_autos": n_autos,
        "orbit_max": orbit_max,
        "orbit_entropy": orbit_entropy,
    }


# ============================================================
# 图集
# ============================================================

def build_atlas_graphs(N):
    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    return graphs


def build_N8_samples(n_samples=40, seed=42):
    random.seed(seed)
    np.random.seed(seed)
    graphs = []
    K8 = nx.complete_graph(8)
    K8_edges = list(K8.edges())
    for n_remove in [2, 3, 4]:
        for _ in range(n_samples // 6):
            removed = random.sample(K8_edges, n_remove)
            G = K8.copy()
            G.remove_edges_from(removed)
            if nx.is_connected(G):
                graphs.append(G)
    for p in [0.4, 0.5, 0.6]:
        for _ in range(n_samples // 6):
            G = nx.gnp_random_graph(8, p, seed=random.randint(0, 10**6))
            if nx.is_connected(G):
                graphs.append(G)
    # 去重
    unique = []
    for G in graphs:
        if not any(nx.is_isomorphic(G, H) for H in unique):
            unique.append(G)
    return unique[:n_samples]


# ============================================================
# Q1: 贡献图 vs 非贡献图的关系指纹
# ============================================================

def q1_contribution_fingerprint(graphs, N, max_edges_per_graph=4):
    print("\n" + "=" * 100)
    print(f"Q1. N={N} 贡献图 vs 非贡献图的关系指纹")
    print("=" * 100)

    basis, idx, SZ_ops = build_sz0_sector(N)
    ref_dim = len(basis)

    contributing = []
    non_contributing = []

    for gid, G in enumerate(graphs):
        edges = [tuple(sorted(e)) for e in G.edges()]
        edge_ops = {e: build_edge_op(e[0], e[1], basis, idx) for e in edges}
        # 抽样边
        sample_edges = edges[:max_edges_per_graph]
        has_resonance = False
        for defect in sample_edges:
            crossings = find_resonances(edge_ops, defect, SZ_ops, ref_dim)
            if crossings:
                has_resonance = True
                break
        fp = relation_fingerprint(G)
        fp["gid"] = gid
        if has_resonance:
            contributing.append(fp)
        else:
            non_contributing.append(fp)

    print(f"\n  贡献图: {len(contributing)}")
    print(f"  非贡献图: {len(non_contributing)}")

    if not contributing:
        return

    # 特征对比
    print(f"\n  {'特征':>20} | {'贡献图均值':>12} | {'非贡献图均值':>14} | {'差值':>8}")
    print(f"  {'-'*20}-+-{'-'*12}-+-{'-'*14}-+-{'-'*8}")

    feature_names = ["n_edges", "deg_entropy", "L_gap", "A_radius",
                     "n_bridges", "n_triangles", "n_autos",
                     "orbit_max", "orbit_entropy"]
    for fname in feature_names:
        c_vals = [fp[fname] for fp in contributing]
        n_vals = [fp[fname] for fp in non_contributing]
        c_mean = np.mean(c_vals)
        n_mean = np.mean(n_vals) if n_vals else 0
        diff = c_mean - n_mean
        print(f"  {fname:>20} | {c_mean:>12.4f} | {n_mean:>14.4f} | {diff:>+8.4f}")

    # 贡献图中"特殊"的特征
    print(f"\n  --- 贡献图的特征范围 ---")
    for fname in feature_names:
        vals = [fp[fname] for fp in contributing]
        print(f"  {fname:>20}: [{min(vals):.4f}, {max(vals):.4f}]")

    return contributing, non_contributing


# ============================================================
# Q2: 47 对是否全部来自"高对称性"图？
# ============================================================

def q2_symmetry_of_contributing(N6_contrib, N6_all):
    print("\n" + "=" * 100)
    print("Q2. N=6 的 47 对是否全部来自高对称性图？")
    print("=" * 100)

    # v10/v11-Q2 报告的贡献图
    known_gids = [9, 26, 33, 38, 42, 49, 55, 60, 64, 69, 83, 103, 106, 108]

    print(f"\n  {'gid':>4} | {'|Aut|':>8} | {'边数':>4} | {'度熵':>8} | "
          f"{'L 间隙':>8} | {'桥数':>4} | {'三角形':>6}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*4}-+-{'-'*8}-+-{'-'*8}-+-{'-'*4}-+-{'-'*6}")

    aut_values = []
    for gid in known_gids:
        if gid >= len(N6_all): continue
        G = N6_all[gid]
        fp = relation_fingerprint(G)
        aut_values.append(fp["n_autos"])
        print(f"  {gid:>4} | {fp['n_autos']:>8} | {fp['n_edges']:>4} | "
              f"{fp['deg_entropy']:>8.4f} | {fp['L_gap']:>8.4f} | "
              f"{fp['n_bridges']:>4} | {fp['n_triangles']:>6}")

    # 全部 N=6 图的自同构分布
    all_aut = []
    for G in N6_all:
        try:
            GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
            n = sum(1 for _ in GM.isomorphisms_iter())
            all_aut.append(n)
        except Exception:
            pass

    print(f"\n  --- 贡献图 |Aut| vs 全部 N=6 图 ---")
    print(f"  贡献图 |Aut| 中位数: {np.median(aut_values):.1f}")
    print(f"  全部图 |Aut| 中位数: {np.median(all_aut):.1f}")
    print(f"  贡献图 |Aut| 均值: {np.mean(aut_values):.1f}")
    print(f"  全部图 |Aut| 均值: {np.mean(all_aut):.1f}")
    print(f"  贡献图 |Aut| 分布: {Counter(aut_values)}")

    # 高对称性的定义：|Aut| ≥ 中位数
    median_aut = np.median(all_aut)
    n_contrib_above = sum(1 for a in aut_values if a >= median_aut)
    print(f"\n  |Aut| ≥ {median_aut:.0f} 的贡献图: {n_contrib_above}/{len(aut_values)}")


# ============================================================
# Q3: 唯一 s 值是否集中在少数几对？
# ============================================================

def q3_shared_s_values(graphs, N, max_edges_per_graph=4):
    print("\n" + "=" * 100)
    print(f"Q3. N={N} 的 s 值共享结构")
    print("=" * 100)

    basis, idx, SZ_ops = build_sz0_sector(N)
    ref_dim = len(basis)

    all_resonances = []  # [(s, gid, defect)]
    for gid, G in enumerate(graphs):
        edges = [tuple(sorted(e)) for e in G.edges()]
        edge_ops = {e: build_edge_op(e[0], e[1], basis, idx) for e in edges}
        for defect in edges[:max_edges_per_graph]:
            crossings = find_resonances(edge_ops, defect, SZ_ops, ref_dim)
            for s in crossings:
                all_resonances.append((s, gid, defect))

    print(f"\n  总谐振点: {len(all_resonances)}")

    # 按 s 值分组（精度 1e-6）
    by_s = defaultdict(list)
    for s, gid, defect in all_resonances:
        by_s[round(s, 6)].append((gid, defect))

    # 共享 s 值：出现次数 > 1
    shared = {s: items for s, items in by_s.items() if len(items) > 1}
    single = {s: items for s, items in by_s.items() if len(items) == 1}

    print(f"  唯一 s 值: {len(by_s)}")
    print(f"  被多对共享的: {len(shared)} ({sum(len(v) for v in shared.values())} 个谐振点)")
    print(f"  只出现一次的: {len(single)} ({len(single)} 个谐振点)")

    # 共享最多的 s 值
    print(f"\n  --- 共享最多的 s 值 ---")
    print(f"  {'s 值':>12} | {'共享次数':>8} | {'贡献图数':>8}")
    print(f"  {'-'*12}-+-{'-'*8}-+-{'-'*8}")
    top_shared = sorted(shared.items(), key=lambda x: -len(x[1]))[:10]
    for s_val, items in top_shared:
        unique_gids = len(set(g for g, _ in items))
        print(f"  {s_val:>12.6f} | {len(items):>8} | {unique_gids:>8}")

    # 0.5 倍数在共享中的占比
    n_half = sum(1 for s in shared if abs(s - round(s*2)/2) < 1e-6)
    print(f"\n  共享 s 值中 0.5 倍数: {n_half}/{len(shared)} = {n_half/len(shared):.1%}")


# ============================================================
# Q4: N=6 的 8 个特殊图有共同关系结构吗？
# ============================================================

def q4_special_common_structure(N6_all):
    print("\n" + "=" * 100)
    print("Q4. N=6 的 8 个特殊图的共同关系结构")
    print("=" * 100)

    special_gids = [9, 26, 33, 38, 42, 49, 55, 60, 64, 69, 83, 103, 106, 108]

    # 计算所有特征
    features = {}
    for gid in special_gids:
        if gid >= len(N6_all): continue
        G = N6_all[gid]
        fp = relation_fingerprint(G)
        features[gid] = fp

    # 分析哪些特征在所有特殊图中"同样"
    print(f"\n  --- 特殊图的特征汇总 ---")
    feature_names = ["n_edges", "deg_entropy", "L_gap", "A_radius",
                     "n_bridges", "n_triangles", "n_autos"]

    # 特征分布
    for fname in feature_names:
        vals = [features[gid][fname] for gid in features]
        print(f"\n  {fname}:")
        print(f"    min={min(vals):.4f}, max={max(vals):.4f}, "
              f"median={np.median(vals):.4f}")

    # "低边数"假设
    n_edges_vals = [features[gid]["n_edges"] for gid in features]
    print(f"\n  --- 特殊图的共同属性检测 ---")
    print(f"  边数: {sorted(n_edges_vals)}")
    print(f"  全部边数 ≤ 13: {all(v <= 13 for v in n_edges_vals)}")
    print(f"  全部边数 ≥ 6: {all(v >= 6 for v in n_edges_vals)}")

    # 对比非特殊图
    non_special_gids = [g for g in range(len(N6_all)) if g not in special_gids]
    non_special_edges = []
    for gid in non_special_gids[:20]:
        G = N6_all[gid]
        non_special_edges.append(G.number_of_edges())
    print(f"\n  非特殊图（前 20 个）的边数: {sorted(non_special_edges)}")


# ============================================================
# Q5: 只保留"贡献图"的代数识别率
# ============================================================

def q5_contribution_only(graphs, N, max_edges_per_graph=4):
    print("\n" + "=" * 100)
    print(f"Q5. N={N} 只保留贡献图的代数识别率")
    print("=" * 100)

    basis, idx, SZ_ops = build_sz0_sector(N)
    ref_dim = len(basis)

    # 第一遍：找贡献图
    contributing_gids = set()
    for gid, G in enumerate(graphs):
        edges = [tuple(sorted(e)) for e in G.edges()]
        edge_ops = {e: build_edge_op(e[0], e[1], basis, idx) for e in edges}
        for defect in edges[:max_edges_per_graph]:
            crossings = find_resonances(edge_ops, defect, SZ_ops, ref_dim)
            if crossings:
                contributing_gids.add(gid)
                break

    print(f"  贡献图数: {len(contributing_gids)}/{len(graphs)}")

    # 第二遍：只扫贡献图的全部 s 值
    all_s = []
    for gid in contributing_gids:
        G = graphs[gid]
        edges = [tuple(sorted(e)) for e in G.edges()]
        edge_ops = {e: build_edge_op(e[0], e[1], basis, idx) for e in edges}
        for defect in edges[:max_edges_per_graph]:
            crossings = find_resonances(edge_ops, defect, SZ_ops, ref_dim)
            all_s.extend(crossings)

    if not all_s:
        print("  无谐振点")
        return

    unique_s = sorted(set(round(s, 6) for s in all_s))
    cats = Counter(identify_algebraic(s) for s in unique_s)
    n_id = cats["half"] + cats["rational"] + cats["quadratic"]

    print(f"  唯一 s 值: {len(unique_s)}")
    print(f"  代数识别: {n_id}/{len(unique_s)} = {n_id/len(unique_s):.1%}")
    print(f"  0.5 倍数: {cats['half']}/{len(unique_s)} = {cats['half']/len(unique_s):.1%}")
    print(f"  分类: {dict(cats)}")

    return {
        "n_contributing": len(contributing_gids),
        "n_unique_s": len(unique_s),
        "n_identified": n_id,
        "rate": n_id / len(unique_s),
    }


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 100)
    print("照妖镜 v15.0：跨尺度离散性起源的五问并行攻击")
    print("=" * 100)

    # 加载图集
    print(f"\n  加载图集...")
    graphs_N6 = build_atlas_graphs(6)
    graphs_N7 = build_atlas_graphs(7)
    graphs_N8 = build_N8_samples(n_samples=40)
    print(f"  N=6: {len(graphs_N6)} 图")
    print(f"  N=7: {len(graphs_N7)} 图")
    print(f"  N=8: {len(graphs_N8)} 图")

    # Q1
    q1_result = q1_contribution_fingerprint(
        graphs_N6[:50], 6, max_edges_per_graph=3)

    # Q2
    q2_symmetry_of_contributing(None, graphs_N6)

    # Q3
    q3_shared_s_values(graphs_N6[:50], 6, max_edges_per_graph=3)

    # Q4
    q4_special_common_structure(graphs_N6)

    # Q5: N=6, N=7, N=8 只保留贡献图的代数识别率
    print("\n" + "=" * 100)
    print("Q5. 跨尺度：只保留贡献图的代数识别率")
    print("=" * 100)
    r6 = q5_contribution_only(graphs_N6, 6, max_edges_per_graph=2)
    r7 = q5_contribution_only(graphs_N7[:100], 7, max_edges_per_graph=2)
    r8 = q5_contribution_only(graphs_N8, 8, max_edges_per_graph=2)

    print("\n" + "=" * 100)
    print("跨尺度总结")
    print("=" * 100)
    print(f"\n  {'N':>4} | {'贡献图/总图':>12} | {'唯一 s':>8} | {'代数识别率':>10}")
    print(f"  {'-'*4}-+-{'-'*12}-+-{'-'*8}-+-{'-'*10}")
    for N, r in [(6, r6), (7, r7), (8, r8)]:
        if r:
            print(f"  {N:>4} | {r['n_contributing']:>12} | {r['n_unique_s']:>8} | "
                  f"{r['rate']:>10.1%}")

    print("\n" + "=" * 100)
    print("v15.0 完成。")
    print("=" * 100)


if __name__ == "__main__":
    main()