#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 v9.0：攻击 s(p_S=1/2) 的四个离散值
================================================================

已知事实：
  s(p_S=1/2) 精确取 {0.0, 0.5, 1.0, 1.5}，全部是 0.5 的整数倍

五个追问并行：
  Q1. s(p_S=1/2) 是否对应能级交叉？
  Q2. s(p_S=1/2) 与缺陷边两端度的解析关系？
  Q3. s(p_S=1/2) 与缺陷边断开后子图能量的关系？
  Q4. 在 s(p_S=1/2) 处，基态波函数的特殊结构？
  Q5. 如果改变网格分辨率（brentq 精确定位），四个值是否稳定？
"""

import sys, io, itertools, json, os
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from scipy.optimize import brentq
from collections import Counter, defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"
N = 6
TOL = 1e-10

# ============================================================
# 自旋算符
# ============================================================

I2 = np.eye(2, dtype=complex)
SX = np.array([[0,1],[1,0]], dtype=complex)
SY = np.array([[0,-1j],[1j,0]], dtype=complex)
SZ = np.array([[1,0],[0,-1]], dtype=complex)


def op_on_site(op, site, N):
    ops = [I2]*N; ops[site] = op
    out = ops[0]
    for o in ops[1:]: out = np.kron(out, o)
    return out


def build_site_ops(N):
    return ([op_on_site(SX,i,N) for i in range(N)],
            [op_on_site(SY,i,N) for i in range(N)],
            [op_on_site(SZ,i,N) for i in range(N)])


def edge_matrix(i, j, SXo, SYo, SZo):
    return SXo[i]@SXo[j] + SYo[i]@SYo[j] + SZo[i]@SZo[j]


# ============================================================
# 约化密度矩阵
# ============================================================

def partial_trace_2sites(rho, i, j, N):
    dims = [2]*N
    rho_t = rho.reshape(dims + dims)
    perm = []
    for k in [i, j]: perm.append(k)
    for k in range(N):
        if k not in (i, j): perm.append(k)
    for k in [i, j]: perm.append(N+k)
    for k in range(N):
        if k not in (i, j): perm.append(N+k)
    rho_p = np.transpose(rho_t, perm)
    d_keep = 4
    d_trace = 2**(N-2)
    rho_r = rho_p.reshape(d_keep, d_trace, d_keep, d_trace)
    return np.trace(rho_r, axis1=1, axis2=3)


def get_pS_at_s(G, defect, s, SXo, SYo, SZo):
    """给定 s，返回 p_S"""
    edges = [tuple(sorted(e)) for e in G.edges()]
    H_edges = [edge_matrix(e[0], e[1], SXo, SYo, SZo) for e in edges]
    couplings = [s if e == defect else 1.0 for e in edges]
    H = sum(c*M for c, M in zip(couplings, H_edges))
    evals, evecs = eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < 1e-8))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    rho_ij = partial_trace_2sites(rho, defect[0], defect[1], N)
    p_S = 0.5 * (rho_ij[1,1].real - rho_ij[1,2].real
                 - rho_ij[2,1].real + rho_ij[2,2].real)
    return p_S


def full_spectrum_at_s(G, defect, s, SXo, SYo, SZo, n_eigs=10):
    """返回 s 处的最低 n_eigs 个本征值"""
    edges = [tuple(sorted(e)) for e in G.edges()]
    H_edges = [edge_matrix(e[0], e[1], SXo, SYo, SZo) for e in edges]
    couplings = [s if e == defect else 1.0 for e in edges]
    H = sum(c*M for c, M in zip(couplings, H_edges))
    evals = eigh(H, eigvals_only=True)
    return evals[:n_eigs]


# ============================================================
# 从 v5.1 加载同响应对
# ============================================================

def load_same_response_pairs():
    with open(os.path.join(WORK_DIR, "照妖镜_v5_1_模式.json"), "r",
              encoding="utf-8") as f:
        v51 = json.load(f)
    pairs = set()
    for key, s in v51["patterns"].items():
        gid, e1_str, e2_str = key.split("_", 2)
        gid = int(gid)
        e1 = tuple(map(int, e1_str.strip("()").split(",")))
        e2 = tuple(map(int, e2_str.strip("()").split(",")))
        pairs.add((gid, e1, e2))
    return pairs


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 100)
    print("照妖镜 v9.0：攻击 s(p_S=1/2) 的四个离散值")
    print("=" * 100)

    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    print(f"\n  图集: {len(graphs)} 个 N=6 连通图")

    same_pairs = load_same_response_pairs()
    defect_edges = set()
    for gid, e1, e2 in same_pairs:
        defect_edges.add((gid, e1))
        defect_edges.add((gid, e2))
    print(f"  缺陷边: {len(defect_edges)}")

    SXo, SYo, SZo = build_site_ops(N)

    # ============================================================
    # Q5（先做）：用 brentq 精确定位 s(p_S=1/2)
    # ============================================================
    print("\n" + "=" * 100)
    print("Q5. brentq 精确定位 s(p_S = 1/2)")
    print("=" * 100)

    # 先用粗网格找近似 s，再用 brentq 精确定位
    coarse_s = np.linspace(0.0, 2.0, 401)
    resonance_data = {}  # (gid, defect) -> (s_exact, p_S_curve)

    for gid, defect in sorted(defect_edges):
        G = graphs[gid]
        # 粗网格
        pS_vals = np.array([get_pS_at_s(G, defect, s, SXo, SYo, SZo)
                            for s in coarse_s])
        # 找 p_S 穿过 0.5 的区间
        crossings = []
        for i in range(len(coarse_s) - 1):
            if (pS_vals[i] - 0.5) * (pS_vals[i+1] - 0.5) < 0:
                try:
                    s_exact = brentq(lambda s: get_pS_at_s(G, defect, s,
                                                           SXo, SYo, SZo) - 0.5,
                                     coarse_s[i], coarse_s[i+1],
                                     xtol=1e-12)
                    crossings.append(s_exact)
                except Exception:
                    pass
        resonance_data[(gid, defect)] = {
            "coarse_s": coarse_s.tolist(),
            "pS_curve": pS_vals.tolist(),
            "crossings": crossings,
        }

    # 并排输出
    print(f"\n  {'gid':>4} | {'defect':>8} | {'s(p_S=1/2) 精确定位':>25}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*25}")
    all_crossings = []
    for (gid, defect), data in sorted(resonance_data.items()):
        crossings = data["crossings"]
        if crossings:
            s_str = ", ".join(f"{s:.8f}" for s in crossings)
            print(f"  {gid:>4} | {str(defect):>8} | {s_str:>25}")
            for s in crossings:
                all_crossings.append((gid, defect, s))

    print(f"\n  总交叉点: {len(all_crossings)}")

    # 聚类：所有 s 值应该聚集在 {0, 0.5, 1.0, 1.5}
    s_vals_arr = np.array([s for _, _, s in all_crossings])
    if len(s_vals_arr) > 0:
        print(f"\n  --- s 值的分布 ---")
        print(f"  min={s_vals_arr.min():.8f}, max={s_vals_arr.max():.8f}")
        # 聚类到最近的 0.5 倍
        nearest_half = np.round(s_vals_arr * 2) / 2
        print(f"\n  s 值聚类（四舍五入到 0.5 的整数倍）：")
        cnt = Counter(nearest_half)
        for v, c in sorted(cnt.items()):
            print(f"    s ≈ {v:.2f}: {c} 次")
        # 偏差分析
        diffs = np.abs(s_vals_arr - nearest_half)
        print(f"\n  最大偏差: {diffs.max():.3e}")
        print(f"  平均偏差: {diffs.mean():.3e}")
        if diffs.max() < 1e-6:
            print(f"  → 四个 s 值是精确的 0, 0.5, 1.0, 1.5")
        else:
            print(f"  → s 值可能不是精确的 0.5 倍")

    # ============================================================
    # Q1：s(p_S=1/2) 是否对应能级交叉？
    # ============================================================
    print("\n" + "=" * 100)
    print("Q1. s(p_S=1/2) 是否对应能级交叉？")
    print("=" * 100)

    print(f"\n  {'gid':>4} | {'defect':>8} | {'s':>10} | {'E0':>12} | {'E1':>12} | {'E2':>12} | {'gap01':>12} | {'gap12':>12} | {'简并':>6}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*10}-+-{'-'*12}-+-{'-'*12}-+-{'-'*12}-+-{'-'*12}-+-{'-'*12}-+-{'-'*6}")
    for gid, defect, s in all_crossings[:40]:
        G = graphs[gid]
        evals = full_spectrum_at_s(G, defect, s, SXo, SYo, SZo, n_eigs=5)
        E0, E1, E2 = evals[0], evals[1], evals[2]
        # 简并
        deg = int(np.sum(np.abs(evals - E0) < 1e-8))
        gap01 = E1 - E0
        gap12 = E2 - E1 if len(evals) > 2 else 0
        print(f"  {gid:>4} | {str(defect):>8} | {s:>10.6f} | "
              f"{E0:>12.6f} | {E1:>12.6f} | {E2:>12.6f} | "
              f"{gap01:>12.6f} | {gap12:>12.6f} | {deg:>6}")

    # 检查：s(p_S=1/2) 处是否 gap01 = 0（能级交叉）
    n_zero_gap = 0
    for gid, defect, s in all_crossings:
        G = graphs[gid]
        evals = full_spectrum_at_s(G, defect, s, SXo, SYo, SZo, n_eigs=3)
        if evals[1] - evals[0] < 1e-8:
            n_zero_gap += 1
    print(f"\n  gap01 = 0（能级交叉）的交叉点数: {n_zero_gap}/{len(all_crossings)}")

    # ============================================================
    # Q2：s(p_S=1/2) 与缺陷边两端度的解析关系？
    # ============================================================
    print("\n" + "=" * 100)
    print("Q2. s(p_S=1/2) 与缺陷边两端度的解析关系")
    print("=" * 100)

    print(f"\n  {'gid':>4} | {'defect':>8} | {'度1':>4} | {'度2':>4} | {'d1+d2':>6} | {'s':>10} | {'s*(d1+d2)':>12} | {'s/d1':>10} | {'s/d2':>10}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*4}-+-{'-'*4}-+-{'-'*6}-+-{'-'*10}-+-{'-'*12}-+-{'-'*10}-+-{'-'*10}")
    for gid, defect, s in all_crossings[:40]:
        G = graphs[gid]
        d1 = G.degree(defect[0])
        d2 = G.degree(defect[1])
        print(f"  {gid:>4} | {str(defect):>8} | {d1:>4} | {d2:>4} | {d1+d2:>6} | "
              f"{s:>10.6f} | {s*(d1+d2):>12.6f} | {s/d1:>10.6f} | {s/d2:>10.6f}")

    # 检查是否有 s = f(d1, d2) 的解析形式
    print(f"\n  --- 检查 s 是否与 (d1, d2) 有简单解析关系 ---")
    # 按 s 值分组
    by_s = defaultdict(list)
    for gid, defect, s in all_crossings:
        s_round = round(s * 2) / 2  # 0, 0.5, 1.0, 1.5
        by_s[s_round].append((gid, defect))

    for s_val, items in sorted(by_s.items()):
        print(f"\n  s = {s_val}:")
        deg_pairs = [(graphs[g].degree(d[0]), graphs[g].degree(d[1]))
                     for g, d in items]
        print(f"    (度1, 度2) 集合: {sorted(set(deg_pairs))}")
        # 特征：度和
        deg_sums = [a+b for a,b in deg_pairs]
        print(f"    度和范围: {min(deg_sums)}–{max(deg_sums)}, 平均: {np.mean(deg_sums):.2f}")

    # ============================================================
    # Q3：s(p_S=1/2) 与缺陷边断开后子图能量的关系？
    # ============================================================
    print("\n" + "=" * 100)
    print("Q3. s(p_S=1/2) 与缺陷边断开后子图能量的关系")
    print("=" * 100)

    def subgraph_gs_energy(sub, SX_sub, SY_sub, SZ_sub, N_sub):
        """子图基态能量"""
        edges = [tuple(sorted(e)) for e in sub.edges()]
        if len(edges) == 0:
            return 0.0
        H_edges = [edge_matrix(e[0], e[1], SX_sub, SY_sub, SZ_sub)
                   for e in edges]
        H = sum(H_edges)
        evals = eigh(H, eigvals_only=True)
        return float(evals[0])

    print(f"\n  {'gid':>4} | {'defect':>8} | {'s':>8} | {'E0(H)':>12} | {'E0断开':>12} | {'E0完整 - E0断开':>16}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*8}-+-{'-'*12}-+-{'-'*12}-+-{'-'*16}")

    for gid, defect, s in all_crossings[:40]:
        G = graphs[gid]
        # 完整图在 s 处的基态能量
        edges = [tuple(sorted(e)) for e in G.edges()]
        H_edges = [edge_matrix(e[0], e[1], SXo, SYo, SZo) for e in edges]
        couplings = [s if e == defect else 1.0 for e in edges]
        H = sum(c*M for c, M in zip(couplings, H_edges))
        E0_full = float(eigh(H, eigvals_only=True)[0])

        # 断开缺陷边后两个子图
        G_broken = G.copy()
        G_broken.remove_edge(*defect)
        comps = list(nx.connected_components(G_broken))

        E0_broken = 0.0
        for comp in comps:
            nodes = sorted(comp)
            sub = G_broken.subgraph(nodes)
            n_sub = len(nodes)
            sub = nx.convert_node_labels_to_integers(sub)
            SX_s, SY_s, SZ_s = build_site_ops(n_sub)
            E0_broken += subgraph_gs_energy(sub, SX_s, SY_s, SZ_s, n_sub)

        print(f"  {gid:>4} | {str(defect):>8} | {s:>8.4f} | "
              f"{E0_full:>12.6f} | {E0_broken:>12.6f} | "
              f"{E0_full - E0_broken:>16.6f}")

    # ============================================================
    # Q4：在 s(p_S=1/2) 处，基态波函数的特殊结构？
    # ============================================================
    print("\n" + "=" * 100)
    print("Q4. 在 s(p_S=1/2) 处，基态波函数的特殊结构")
    print("=" * 100)

    # 对每个 s(p_S=1/2)，输出 ρ_ij 完整形式
    print(f"\n  抽样：s(p_S=1/2) 处的 ρ_ij（每个 s 值取一个代表）")
    shown_s = set()
    for gid, defect, s in all_crossings:
        s_round = round(s * 2) / 2
        if s_round in shown_s:
            continue
        shown_s.add(s_round)
        G = graphs[gid]
        edges = [tuple(sorted(e)) for e in G.edges()]
        H_edges = [edge_matrix(e[0], e[1], SXo, SYo, SZo) for e in edges]
        couplings = [s if e == defect else 1.0 for e in edges]
        H = sum(c*M for c, M in zip(couplings, H_edges))
        evals, evecs = eigh(H)
        E0 = evals[0]
        deg = int(np.sum(np.abs(evals - E0) < 1e-8))
        V = evecs[:, :deg]
        rho = V @ V.conj().T / deg
        rho_ij = partial_trace_2sites(rho, defect[0], defect[1], N)

        print(f"\n  --- s = {s_round:.2f} (gid={gid}, defect={defect}) ---")
        print(f"  基态简并度: {deg}, gap01 = {evals[1]-evals[0]:.6f}")
        print(f"  ρ_ij =")
        for row in rho_ij.real:
            print(f"    [{row[0]:>8.5f} {row[1]:>8.5f} {row[2]:>8.5f} {row[3]:>8.5f}]")

    # ============================================================
    # 深度追问：s(p_S=1/2) 是否恰好是某个本征值的比例？
    # ============================================================
    print("\n" + "=" * 100)
    print("深度追问：s(p_S=1/2) 是否恰好是某个本征值的比例？")
    print("=" * 100)

    # H(s) = H0 + (s-1) M_defect
    # 在 s(p_S=1/2) 处，检查 M_defect 的本征值、H0 的本征值
    print(f"\n  {'gid':>4} | {'defect':>8} | {'s':>6} | {'<M_defect>':>12} | {'<H0>':>12} | {'<H0>/<M>':>12}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*6}-+-{'-'*12}-+-{'-'*12}-+-{'-'*12}")

    for gid, defect, s in all_crossings[:40]:
        G = graphs[gid]
        edges = [tuple(sorted(e)) for e in G.edges()]
        H_edges = [edge_matrix(e[0], e[1], SXo, SYo, SZo) for e in edges]
        # H0 = sum of all edge matrices (uniform coupling)
        H0 = sum(H_edges)
        M_defect = H_edges[edges.index(defect)]
        # H(s) = H0 + (s-1) M_defect
        couplings = [s if e == defect else 1.0 for e in edges]
        H = sum(c*M for c, M in zip(couplings, H_edges))
        evals, evecs = eigh(H)
        psi0 = evecs[:, 0]
        M_exp = float(np.real(psi0.conj() @ M_defect @ psi0))
        H0_exp = float(np.real(psi0.conj() @ H0 @ psi0))
        ratio = H0_exp / M_exp if abs(M_exp) > 1e-10 else np.nan
        print(f"  {gid:>4} | {str(defect):>8} | {s:>6.4f} | "
              f"{M_exp:>12.6f} | {H0_exp:>12.6f} | {ratio:>12.6f}")

    # ============================================================
    # 深度追问 2：s(p_S=1/2) 处的缺陷边关联函数与"平衡条件"
    # ============================================================
    print("\n" + "=" * 100)
    print("深度追问 2：s(p_S=1/2) 处的平衡条件")
    print("=" * 100)

    print("""
  假设：s(p_S=1/2) 处，缺陷边的耦合能与图的"内部能量"达到平衡。
  即：d⟨H(s)⟩/ds = ⟨M_defect⟩ = 某个特定值。

  在 s=1 时，H = H0，⟨M_defect⟩ 是均匀 Heisenberg 的缺陷边关联。
  在 s=0 时，缺陷边断开，⟨M_defect⟩ 反映两侧子图的耦合。
""")

    print(f"\n  {'gid':>4} | {'defect':>8} | {'s':>6} | {'dE/ds':>12} | {'E0(s)':>12} | {'E0(0)':>12} | {'E0(1)':>12} | {'E0(2)':>12}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*6}-+-{'-'*12}-+-{'-'*12}-+-{'-'*12}-+-{'-'*12}-+-{'-'*12}")

    for gid, defect, s in all_crossings[:20]:
        G = graphs[gid]
        edges = [tuple(sorted(e)) for e in G.edges()]
        H_edges = [edge_matrix(e[0], e[1], SXo, SYo, SZo) for e in edges]
        idx_def = edges.index(defect)
        M_defect = H_edges[idx_def]
        # s 处的 dE/ds
        couplings = [s if e == defect else 1.0 for e in edges]
        H = sum(c*M for c, M in zip(couplings, H_edges))
        evals, evecs = eigh(H)
        psi0 = evecs[:, 0]
        dE_ds = float(np.real(psi0.conj() @ M_defect @ psi0))
        E0_s = float(evals[0])
        # E0 在其他 s
        def get_E0(s_val):
            c = [s_val if e == defect else 1.0 for e in edges]
            H_v = sum(c_i*M for c_i, M in zip(c, H_edges))
            return float(eigh(H_v, eigvals_only=True)[0])
        E0_0 = get_E0(0.0)
        E0_1 = get_E0(1.0)
        E0_2 = get_E0(2.0)
        print(f"  {gid:>4} | {str(defect):>8} | {s:>6.4f} | "
              f"{dE_ds:>12.6f} | {E0_s:>12.6f} | "
              f"{E0_0:>12.6f} | {E0_1:>12.6f} | {E0_2:>12.6f}")

    # ============================================================
    # 导出
    # ============================================================
    out = {
        "crossings": [{"gid": g, "defect": list(d), "s": s}
                      for g, d, s in all_crossings],
        "s_clusters": {str(k): v for k, v in
                       Counter(np.round(s_vals_arr * 2) / 2).items()},
    }
    out_path = os.path.join(WORK_DIR, "照妖镜_v9_s四个值.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("v9.0 完成。s(p_S=1/2) 的四个离散值被攻击。")
    print("=" * 100)


if __name__ == "__main__":
    main()