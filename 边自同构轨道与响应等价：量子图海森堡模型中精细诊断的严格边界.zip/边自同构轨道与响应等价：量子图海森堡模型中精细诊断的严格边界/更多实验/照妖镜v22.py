#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 v22.0：核心层的 4 节点核心结构
================================================================

v21 暴露：
  - 核心对的缺陷边不是桥
  - 核心对边集覆盖 4 个节点，2 个节点不参与
  - 断开缺陷边不产生两个分量

新假设：
  核心对的缺陷边在一个 4 节点"核心子图"内，该子图有特殊对称性，
  使基态在缺陷边上的投影始终是纯三重态 (p_S ≡ 0)。

五个追问并行：
  Q1. 4 节点核心子图的结构是什么？（是 K_4 减边？环？）
  Q2. 4 节点核心在完整图中的对称角色
  Q3. 不参与节点与 4 节点核心的连接模式
  Q4. 缺陷边在 4 节点核心内的位置类型
  Q5. 核心对的 ⟨σ·σ⟩_defect 是否在 s=0.5 处精确等于 +1？
"""

import sys, io, itertools, json, os
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from collections import Counter, defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"


# ============================================================
# 从 v5.1 加载核心对
# ============================================================

def load_core_pairs():
    with open(os.path.join(WORK_DIR, "照妖镜_v5_1_模式.json"), "r",
              encoding="utf-8") as f:
        v51 = json.load(f)
    pairs = []
    for key, s in v51["patterns"].items():
        if s.count("1") == 24:
            gid, e1_str, e2_str = key.split("_", 2)
            gid = int(gid)
            e1 = tuple(map(int, e1_str.strip("()").split(",")))
            e2 = tuple(map(int, e2_str.strip("()").split(",")))
            pairs.append({"gid": gid, "e1": e1, "e2": e2})
    return pairs


def build_atlas_graphs(N):
    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    return graphs


# ============================================================
# S_z=0 扇区
# ============================================================

def build_sz0_sector(N):
    n_up = N // 2
    basis = []
    for comb in itertools.combinations(range(N), n_up):
        state = [0]*N
        for i in comb: state[i] = 1
        basis.append(tuple(state))
    dim = len(basis)
    idx = {s: i for i, s in enumerate(basis)}
    SZ_ops = []
    for site in range(N):
        SZ = np.zeros((dim, dim), dtype=complex)
        for i, state in enumerate(basis):
            SZ[i, i] = 1 if state[site] == 1 else -1
        SZ_ops.append(SZ)
    return basis, idx, SZ_ops


def build_edge_op(i, j, basis, idx):
    dim = len(basis)
    op = np.zeros((dim, dim), dtype=complex)
    for a_idx, state_a in enumerate(basis):
        sa, sb = state_a[i], state_a[j]
        if sa == sb:
            op[a_idx, a_idx] += 1
        else:
            op[a_idx, a_idx] += -1
            new_state = list(state_a)
            new_state[i], new_state[j] = new_state[j], new_state[i]
            b_idx = idx.get(tuple(new_state))
            if b_idx is not None:
                op[b_idx, a_idx] += 2
    return op


def compute_pS_at_s(edge_ops, defect, s, SZ_ops, ref_dim):
    """计算 s 处的 p_S 和缺陷边的 ⟨σ·σ⟩"""
    H = np.zeros((ref_dim, ref_dim), dtype=complex)
    for e, M in edge_ops.items():
        c = s if e == defect else 1.0
        H += c * M
    try:
        evals, evecs = eigh(H)
    except Exception:
        return None
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < 1e-8))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    i, j = defect
    szsz_diag = np.diag(SZ_ops[i] @ SZ_ops[j])
    szsz = float(np.real(np.sum(np.diag(rho) * szsz_diag)))
    p_S = (1 - 3 * szsz) / 4
    sd = float(np.real(np.trace(rho @ edge_ops[defect])))
    return {"p_S": p_S, "szsz": szsz, "sd": sd, "deg": deg}


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 100)
    print("照妖镜 v22.0：核心层的 4 节点核心结构")
    print("=" * 100)

    N = 6
    graphs = build_atlas_graphs(N)
    core_pairs = load_core_pairs()
    print(f"\n  N={N} 图集: {len(graphs)} 图")
    print(f"  核心对: {len(core_pairs)} 对")

    basis, idx, SZ_ops = build_sz0_sector(N)
    ref_dim = len(basis)
    print(f"  S_z=0 维度: {ref_dim}")

    # ============================================================
    # Q1: 4 节点核心子图的结构
    # ============================================================
    print("\n" + "=" * 100)
    print("Q1. 4 节点核心子图的结构")
    print("=" * 100)

    # 收集每个图的核心对边集
    by_gid = defaultdict(list)
    for cp in core_pairs:
        by_gid[cp["gid"]].append(cp)

    print(f"\n  {'gid':>4} | {'边集节点':>16} | {'核心子图边集':>35} | {'核心子图类型':>20}")
    print(f"  {'-'*4}-+-{'-'*16}-+-{'-'*35}-+-{'-'*20}")

    core_subgraph_info = {}
    for gid, pairs in sorted(by_gid.items()):
        G = graphs[gid]
        # 收集该图所有核心对的边
        edges_set = set()
        for cp in pairs:
            edges_set.add(tuple(sorted(cp["e1"])))
            edges_set.add(tuple(sorted(cp["e2"])))
        # 节点集
        nodes_set = set()
        for e in edges_set:
            nodes_set.update(e)
        # 诱导子图
        sub = G.subgraph(nodes_set).copy()
        sub_edges = sorted(tuple(sorted(e)) for e in sub.edges())
        # 核心对涉及的边（不含其他）
        core_edges = sorted(edges_set)
        # 类型判断
        n_nodes = len(nodes_set)
        n_edges = len(core_edges)
        if n_nodes == 4 and n_edges == 6:
            sub_type = "K_4"
        elif n_nodes == 4 and n_edges == 5:
            sub_type = "K_4 - 1边"
        elif n_nodes == 4 and n_edges == 4:
            sub_type = "C_4 或 K_4 - 2边"
        else:
            sub_type = f"{n_nodes}节点 {n_edges}边"
        print(f"  {gid:>4} | {str(sorted(nodes_set)):>16} | "
              f"{str(core_edges):>35} | {sub_type:>20}")

        core_subgraph_info[gid] = {
            "nodes": sorted(nodes_set),
            "core_edges": core_edges,
            "sub_type": sub_type,
        }

    # ============================================================
    # Q2: 4 节点核心在完整图中的对称角色
    # ============================================================
    print("\n" + "=" * 100)
    print("Q2. 4 节点核心在完整图中的对称角色")
    print("=" * 100)

    print(f"\n  {'gid':>4} | {'核心边在轨道内':>15} | {'轨道大小':>8} | {'核心对是否是轨道内不同边':>22}")
    print(f"  {'-'*4}-+-{'-'*15}-+-{'-'*8}-+-{'-'*22}")

    for gid, pairs in sorted(by_gid.items()):
        G = graphs[gid]
        # 计算边自同构轨道
        GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
        autos = list(GM.isomorphisms_iter())
        edges = [tuple(sorted(e)) for e in G.edges()]
        orbits = {}
        for e in edges:
            orbit = frozenset(frozenset({a[e[0]], a[e[1]]}) for a in autos)
            orbits[e] = orbit
        # 检查每对是否是同轨道
        n_same_orbit = sum(1 for cp in pairs if orbits[tuple(sorted(cp["e1"]))] == orbits[tuple(sorted(cp["e2"]))])
        n_diff_orbit = len(pairs) - n_same_orbit
        # 核心对的轨道大小
        orbit_sizes = [len(orbits[tuple(sorted(cp["e1"]))]) for cp in pairs]
        orbit_sizes += [len(orbits[tuple(sorted(cp["e2"]))]) for cp in pairs]
        # 唯一轨道大小
        unique_orbit_sizes = sorted(set(orbit_sizes))
        print(f"  {gid:>4} | {str(unique_orbit_sizes):>15} | "
              f"{str(len(set(orbit_sizes))):>8} | "
              f"同轨道={n_same_orbit}, 异轨道={n_diff_orbit}")

    # ============================================================
    # Q3: 不参与节点与 4 节点核心的连接模式
    # ============================================================
    print("\n" + "=" * 100)
    print("Q3. 不参与节点与 4 节点核心的连接模式")
    print("=" * 100)

    print(f"\n  {'gid':>4} | {'不参与节点':>12} | {'它们与核心的连接边':>30} | {'连接数':>8}")
    print(f"  {'-'*4}-+-{'-'*12}-+-{'-'*30}-+-{'-'*8}")

    for gid, pairs in sorted(by_gid.items()):
        G = graphs[gid]
        core_nodes = set(core_subgraph_info[gid]["nodes"])
        other_nodes = set(G.nodes()) - core_nodes
        # 不参与节点与核心节点的连接边
        cross_edges = []
        for e in G.edges():
            a, b = e
            if (a in core_nodes and b in other_nodes) or (b in core_nodes and a in other_nodes):
                cross_edges.append(tuple(sorted(e)))
        # 不参与节点的度
        degrees_other = {n: G.degree(n) for n in other_nodes}
        print(f"  {gid:>4} | {str(sorted(other_nodes)):>12} | "
              f"{str(sorted(cross_edges)):>30} | {len(cross_edges):>8}")
        # 不参与节点的度
        print(f"        度: {degrees_other}")

    # ============================================================
    # Q4: 缺陷边在 4 节点核心内的位置类型
    # ============================================================
    print("\n" + "=" * 100)
    print("Q4. 缺陷边在 4 节点核心内的位置类型")
    print("=" * 100)

    print(f"\n  {'gid':>4} | {'缺陷边':>10} | {'边两端在核心内度数':>20} | {'边在图中的度':>15}")
    print(f"  {'-'*4}-+-{'-'*10}-+-{'-'*20}-+-{'-'*15}")

    for gid, pairs in sorted(by_gid.items()):
        G = graphs[gid]
        for cp in pairs:
            for e in [cp["e1"], cp["e2"]]:
                e_sorted = tuple(sorted(e))
                deg_1 = G.degree(e_sorted[0])
                deg_2 = G.degree(e_sorted[1])
                # 在核心内度数
                core_nodes = set(core_subgraph_info[gid]["nodes"])
                sub = G.subgraph(core_nodes)
                core_deg_1 = sub.degree(e_sorted[0])
                core_deg_2 = sub.degree(e_sorted[1])
                print(f"  {gid:>4} | {str(e_sorted):>10} | "
                      f"{f'({core_deg_1}, {core_deg_2})':>20} | "
                      f"{f'({deg_1}, {deg_2})':>15}")

    # ============================================================
    # Q5: 核心对的 p_S 曲线 - 在 s=0.5 处是否精确等于 0？
    # ============================================================
    print("\n" + "=" * 100)
    print("Q5. 核心对的 p_S 曲线")
    print("=" * 100)

    print(f"\n  {'gid':>4} | {'defect':>10} | {'p_S@-2':>10} | {'p_S@-1':>10} | {'p_S@0':>10} | {'p_S@0.5':>10} | {'p_S@1':>10} | {'p_S@2':>10}")
    print(f"  {'-'*4}-+-{'-'*10}-+-{'-'*10}-+-{'-'*10}-+-{'-'*10}-+-{'-'*10}-+-{'-'*10}-+-{'-'*10}")

    for gid, pairs in sorted(by_gid.items()):
        G = graphs[gid]
        edges = [tuple(sorted(e)) for e in G.edges()]
        edge_ops = {e: build_edge_op(e[0], e[1], basis, idx) for e in edges}
        # 只取前 3 个缺陷边输出
        shown = 0
        for cp in pairs:
            for e in [cp["e1"], cp["e2"]]:
                if shown >= 3:
                    break
                e_sorted = tuple(sorted(e))
                row = [e_sorted]
                for s in [-2.0, -1.0, 0.0, 0.5, 1.0, 2.0]:
                    r = compute_pS_at_s(edge_ops, e_sorted, s, SZ_ops, ref_dim)
                    row.append(r["p_S"] if r else float('nan'))
                print(f"  {gid:>4} | {str(e_sorted):>10} | " +
                      " | ".join(f"{v:>10.6f}" for v in row[1:]))
                shown += 1
            if shown >= 3:
                break

    # ============================================================
    # 深度追问：4 节点核心的自同构
    # ============================================================
    print("\n" + "=" * 100)
    print("深度追问：4 节点核心的自同构")
    print("=" * 100)

    for gid, pairs in sorted(by_gid.items()):
        G = graphs[gid]
        core_nodes = core_subgraph_info[gid]["nodes"]
        core_edges = set(core_subgraph_info[gid]["core_edges"])
        sub = G.subgraph(core_nodes)
        # 核心子图的自同构
        sub_autos = list(nx.algorithms.isomorphism.GraphMatcher(sub, sub).isomorphisms_iter())
        # 完整图的自同构中，有多少保持核心集不变
        full_autos = list(nx.algorithms.isomorphism.GraphMatcher(G, G).isomorphisms_iter())
        n_preserve_core = sum(1 for a in full_autos if set(a[n] for n in core_nodes) == set(core_nodes))
        print(f"\n  gid={gid}: 核心 {core_nodes}")
        print(f"    核心子图自同构: {len(sub_autos)}")
        print(f"    完整图自同构: {len(full_autos)}")
        print(f"    保持核心集的完整图自同构: {n_preserve_core}")

    # ============================================================
    # 导出
    # ============================================================
    out = {
        "n_core_pairs": len(core_pairs),
        "by_gid": {str(gid): len(pairs) for gid, pairs in by_gid.items()},
        "core_subgraph_info": {str(k): v for k, v in core_subgraph_info.items()},
    }
    out_path = os.path.join(WORK_DIR, "照妖镜_v22_4节点核心.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("v22.0 完成。核心层的 4 节点结构被攻击。")
    print("=" * 100)


if __name__ == "__main__":
    main()