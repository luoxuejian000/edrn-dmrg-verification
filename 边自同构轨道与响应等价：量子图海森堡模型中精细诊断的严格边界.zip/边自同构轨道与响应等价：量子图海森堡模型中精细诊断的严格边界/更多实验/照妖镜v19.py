#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 v19.0：为什么 N=6 恢复整数、N=7 不行？
================================================================

v17/v18 关键发现：
  N=6: S_edge² 对角化后，22.6% 的非整数恢复整数
  N=7: S_edge² 对角化后，0% 的非整数恢复整数

核心问题：
  是什么差异导致 N=6 可以恢复，N=7 不行？

五个追问并行：
  Q1. 恢复整数的 N=6 点，在 S_edge² 谱上有什么共同结构？
  Q2. N=6 和 N=7 简并子空间的 S_edge² 谱对比
  Q3. 泄漏量的双峰结构（v18 发现）
  Q4. 恢复整数需要什么额外条件？（对称性？S² 谱？）
  Q5. 如果不只对角化 S_edge²，还同时对角化 S²，N=7 能恢复吗？

晶脉哲学：
  · 关系本体论：简并子空间是关系网络在对称性下的退化
  · 对象化=截断=产生方向：每个投影都是一次截断
  · 只查同与不同：不筛选，不排序
  · 反对对齐：不预设结论
"""

import sys, io, itertools, json, os
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from scipy.optimize import brentq
from collections import Counter, defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"


# ============================================================
# 基础构建
# ============================================================

def build_sz0_sector(N):
    n_up = N // 2
    basis = []
    for comb in itertools.combinations(range(N), n_up):
        state = [0]*N
        for i in comb: state[i] = 1
        basis.append(tuple(state))
    dim = len(basis)
    idx = {s: i for i, s in enumerate(basis)}
    SZ_ops = []
    for site in range(N):
        SZ = np.zeros((dim, dim), dtype=complex)
        for i, state in enumerate(basis):
            SZ[i, i] = 1 if state[site] == 1 else -1
        SZ_ops.append(SZ)
    return basis, idx, SZ_ops


def build_edge_op(i, j, basis, idx):
    dim = len(basis)
    op = np.zeros((dim, dim), dtype=complex)
    for a_idx, state_a in enumerate(basis):
        sa, sb = state_a[i], state_a[j]
        if sa == sb:
            op[a_idx, a_idx] += 1
        else:
            op[a_idx, a_idx] += -1
            new_state = list(state_a)
            new_state[i], new_state[j] = new_state[j], new_state[i]
            b_idx = idx.get(tuple(new_state))
            if b_idx is not None:
                op[b_idx, a_idx] += 2
    return op


def build_S2_op(basis, idx, N):
    dim = len(basis)
    S2 = np.zeros((dim, dim), dtype=complex)
    for i in range(N):
        S2 += 3/4 * np.eye(dim, dtype=complex)
        for j in range(N):
            if i == j: continue
            S2 += 1/4 * build_edge_op(i, j, basis, idx)
    return S2


# ============================================================
# 核心分析：恢复整数的条件
# ============================================================

def analyze_recovery(edge_ops, defect, s, SZ_ops, S2_op, ref_dim):
    """
    分析简并子空间的"恢复能力"：
    1. 原始 eigh 基下的 ⟨σ·σ⟩ 整数率
    2. S_edge² 对角化后的整数率
    3. S_edge² + η S² 联合对角化后的整数率
    4. 简并子空间的 S_edge² 谱和 S² 谱
    5. 简并子空间内 [S_edge², S²] 的对易性
    6. 泄漏量
    """
    H = np.zeros((ref_dim, ref_dim), dtype=complex)
    for e, M in edge_ops.items():
        c = s if e == defect else 1.0
        H += c * M

    evals, evecs = eigh(H)
    E0 = evals[0]
    degen_mask = np.abs(evals - E0) < 1e-8
    deg = int(np.sum(degen_mask))
    V = evecs[:, degen_mask]
    V_out = evecs[:, ~degen_mask]

    S_edge_sq = 6 * np.eye(ref_dim, dtype=complex) + 2 * edge_ops[defect]

    # (1) 原始基下的 ⟨σ·σ⟩
    raw_sds = []
    for k in range(deg):
        v = V[:, k]
        sd = float(np.real(v.conj() @ edge_ops[defect] @ v))
        raw_sds.append(sd)
    raw_n_int = sum(1 for x in raw_sds if abs(x - round(x)) < 1e-6)

    # (2) S_edge² 对角化
    M_edge = V.conj().T @ S_edge_sq @ V
    se2_evals, W_edge = eigh(M_edge)
    V_edge = V @ W_edge
    edge_sds = []
    for k in range(deg):
        v = V_edge[:, k]
        sd = float(np.real(v.conj() @ edge_ops[defect] @ v))
        edge_sds.append(sd)
    edge_n_int = sum(1 for x in edge_sds if abs(x - round(x)) < 1e-6)

    # (3) S_edge² + η S² 联合对角化（η 为无理数以避免简并）
    M_S2 = V.conj().T @ S2_op @ V
    comm_in = M_S2 @ M_edge - M_edge @ M_S2
    comm_in_norm = float(np.linalg.norm(comm_in))

    eta = 0.123456789012345
    M_comb = M_edge + eta * M_S2
    _, W_comb = eigh(M_comb)
    V_comb = V @ W_comb
    comb_sds = []
    for k in range(deg):
        v = V_comb[:, k]
        sd = float(np.real(v.conj() @ edge_ops[defect] @ v))
        comb_sds.append(sd)
    comb_n_int = sum(1 for x in comb_sds if abs(x - round(x)) < 1e-6)

    # (4) 简并子空间内的 S_edge² 谱和 S² 谱
    edge_eigs = sorted(np.linalg.eigvalsh(M_edge))
    s2_eigs = sorted(np.linalg.eigvalsh(M_S2))

    # (5) 泄漏量
    proj_out = np.eye(ref_dim) - V @ V.conj().T
    leak_S_edge = float(np.linalg.norm(proj_out @ S_edge_sq @ V))

    # (6) S_edge² 投影谱的整数性
    n_pure_se2 = sum(1 for e in edge_eigs
                     if abs(e) < 1e-4 or abs(e - 8) < 1e-4)

    return {
        "s": s, "deg": deg,
        "raw_sds": raw_sds, "raw_n_int": raw_n_int,
        "edge_sds": edge_sds, "edge_n_int": edge_n_int,
        "comb_sds": comb_sds, "comb_n_int": comb_n_int,
        "edge_eigs": [float(x) for x in edge_eigs],
        "s2_eigs": [float(x) for x in s2_eigs],
        "leak_S_edge": leak_S_edge,
        "comm_in_S2_S_edge": comm_in_norm,
        "n_pure_se2": n_pure_se2,
        "raw_int_rate": raw_n_int / deg,
        "edge_int_rate": edge_n_int / deg,
        "comb_int_rate": comb_n_int / deg,
    }


def build_atlas_graphs(N):
    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    return graphs


def run_analysis(N, max_graphs=None, sample_edges=4):
    print(f"\n  N={N} 分析...")
    graphs = build_atlas_graphs(N)
    if max_graphs:
        step = max(1, len(graphs) // max_graphs)
        graphs = graphs[::step][:max_graphs]
    print(f"    图集: {len(graphs)} 图")

    basis, idx, SZ_ops = build_sz0_sector(N)
    ref_dim = len(basis)
    S2_op = build_S2_op(basis, idx, N)

    results = []
    for gid, G in enumerate(graphs):
        if gid % 30 == 0:
            print(f"    {gid}/{len(graphs)}")
        edges = [tuple(sorted(e)) for e in G.edges()]
        edge_ops = {e: build_edge_op(e[0], e[1], basis, idx) for e in edges}
        for defect in edges[:sample_edges]:
            s_grid = np.linspace(-2.0, 2.5, 41)
            pS_vals = []
            for s in s_grid:
                H = np.zeros((ref_dim, ref_dim), dtype=complex)
                for e, M in edge_ops.items():
                    c = s if e == defect else 1.0
                    H += c * M
                try:
                    evals, evecs = eigh(H)
                except Exception:
                    pS_vals.append(0.0)
                    continue
                E0 = evals[0]
                deg = int(np.sum(np.abs(evals - E0) < 1e-8))
                Vv = evecs[:, :deg]
                rho = Vv @ Vv.conj().T / deg
                i, j = defect
                szsz_diag = np.diag(SZ_ops[i] @ SZ_ops[j])
                szsz = float(np.real(np.sum(np.diag(rho) * szsz_diag)))
                pS_vals.append((1 - 3 * szsz) / 4)
            pS_vals = np.array(pS_vals)

            for k in range(len(s_grid) - 1):
                if (pS_vals[k] - 0.5) * (pS_vals[k+1] - 0.5) < 0:
                    try:
                        s_res = brentq(
                            lambda s: _pS(edge_ops, defect, s, SZ_ops, ref_dim) - 0.5,
                            s_grid[k], s_grid[k+1], xtol=1e-10)
                        H = np.zeros((ref_dim, ref_dim), dtype=complex)
                        for e, M in edge_ops.items():
                            c = s_res if e == defect else 1.0
                            H += c * M
                        evals = np.linalg.eigvalsh(H)
                        deg = int(np.sum(np.abs(evals - evals[0]) < 1e-8))
                        if deg > 1:
                            info = analyze_recovery(
                                edge_ops, defect, s_res, SZ_ops,
                                S2_op, ref_dim)
                            results.append({
                                "gid": gid, "defect": list(defect), **info
                            })
                    except Exception:
                        pass
    print(f"    简并谐振点: {len(results)}")
    return results


def _pS(edge_ops, defect, s, SZ_ops, ref_dim):
    H = np.zeros((ref_dim, ref_dim), dtype=complex)
    for e, M in edge_ops.items():
        c = s if e == defect else 1.0
        H += c * M
    evals, evecs = eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < 1e-8))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    i, j = defect
    szsz_diag = np.diag(SZ_ops[i] @ SZ_ops[j])
    szsz = float(np.real(np.sum(np.diag(rho) * szsz_diag)))
    return (1 - 3 * szsz) / 4


def main():
    print("=" * 100)
    print("照妖镜 v19.0：为什么 N=6 恢复整数、N=7 不行？")
    print("=" * 100)

    points_N6 = run_analysis(6, max_graphs=None, sample_edges=4)
    points_N7 = run_analysis(7, max_graphs=150, sample_edges=4)

    # ============================================================
    # Q1: 恢复整数的 N=6 点有什么共同结构？
    # ============================================================
    print("\n" + "=" * 100)
    print("Q1. 恢复整数的 N=6 点的特征")
    print("=" * 100)

    for label, pts in [("N=6", points_N6), ("N=7", points_N7)]:
        if not pts:
            continue
        # 分类
        recovered = [p for p in pts
                     if p["raw_int_rate"] < 0.99 and p["edge_int_rate"] > p["raw_int_rate"] + 0.05]
        not_recovered = [p for p in pts
                         if p["raw_int_rate"] < 0.99 and p["edge_int_rate"] <= p["raw_int_rate"] + 0.05]
        print(f"\n  {label}:")
        print(f"    原始已整数 (raw≥0.99): "
              f"{sum(1 for p in pts if p['raw_int_rate'] >= 0.99)}")
        print(f"    原始非整数、S_edge² 恢复: {len(recovered)}")
        print(f"    原始非整数、S_edge² 未恢复: {len(not_recovered)}")

        # 恢复点的特征
        if recovered:
            print(f"\n    恢复整数的点特征:")
            print(f"      d 范围: [{min(p['deg'] for p in recovered)}, "
                  f"{max(p['deg'] for p in recovered)}]")
            leaks = [p["leak_S_edge"] for p in recovered]
            print(f"      泄漏量: max={max(leaks):.3f}, mean={np.mean(leaks):.3f}")

    # ============================================================
    # Q2: N=6 vs N=7 简并子空间的 S_edge² 谱对比
    # ============================================================
    print("\n" + "=" * 100)
    print("Q2. N=6 vs N=7 简并子空间的 S_edge² 谱对比")
    print("=" * 100)

    for label, pts in [("N=6", points_N6), ("N=7", points_N7)]:
        if not pts:
            continue
        # 提取所有投影谱特征值
        all_eigs = [e for p in pts for e in p["edge_eigs"]]
        # 分类
        near_0 = sum(1 for e in all_eigs if abs(e) < 0.3)
        near_8 = sum(1 for e in all_eigs if abs(e - 8) < 0.3)
        mid = len(all_eigs) - near_0 - near_8
        print(f"\n  {label}: 总投影本征值 {len(all_eigs)}")
        print(f"    ≈0 (单态): {near_0} ({near_0/len(all_eigs):.1%})")
        print(f"    ≈8 (三重态): {near_8} ({near_8/len(all_eigs):.1%})")
        print(f"    中间 (其他): {mid} ({mid/len(all_eigs):.1%})")

        # 中间值的分布
        mid_vals = [e for e in all_eigs if 0.3 <= abs(e) <= 7.7]
        if mid_vals:
            print(f"    中间值范围: [{min(mid_vals):.4f}, {max(mid_vals):.4f}]")

    # ============================================================
    # Q3: 泄漏量的双峰结构
    # ============================================================
    print("\n" + "=" * 100)
    print("Q3. 泄漏量的双峰结构")
    print("=" * 100)

    for label, pts in [("N=6", points_N6), ("N=7", points_N7)]:
        if not pts:
            continue
        leaks = np.array([p["leak_S_edge"] for p in pts])
        # 直方图
        bins = [0, 0.01, 0.1, 0.5, 1.0, 2.0, 4.0, 10.0]
        print(f"\n  {label}: 泄漏量分布")
        print(f"    {'区间':>12} | {'数量':>6} | {'整数率':>8}")
        print(f"    {'-'*12}-+-{'-'*6}-+-{'-'*8}")
        for i in range(len(bins)-1):
            mask = (leaks >= bins[i]) & (leaks < bins[i+1])
            if mask.sum() > 0:
                avg_int = np.mean([p["raw_int_rate"] for p, m in zip(pts, mask) if m])
                print(f"    [{bins[i]:>4.2f},{bins[i+1]:>4.2f}) | {mask.sum():>6} | "
                      f"{avg_int:>8.1%}")

    # ============================================================
    # Q4: 恢复整数的额外条件
    # ============================================================
    print("\n" + "=" * 100)
    print("Q4. 恢复整数的额外条件")
    print("=" * 100)

    for label, pts in [("N=6", points_N6), ("N=7", points_N7)]:
        if not pts:
            continue
        # 分类：低泄漏 vs 高泄漏
        low_leak = [p for p in pts if p["leak_S_edge"] < 0.1]
        high_leak = [p for p in pts if p["leak_S_edge"] > 1.0]

        print(f"\n  {label}:")
        print(f"    低泄漏 (<0.1): {len(low_leak)} 点")
        if low_leak:
            print(f"      raw 整数率 = {np.mean([p['raw_int_rate'] for p in low_leak]):.1%}")
            print(f"      S_edge² 整数率 = {np.mean([p['edge_int_rate'] for p in low_leak]):.1%}")
            print(f"      联合对角化整数率 = {np.mean([p['comb_int_rate'] for p in low_leak]):.1%}")

        print(f"    高泄漏 (>1): {len(high_leak)} 点")
        if high_leak:
            print(f"      raw 整数率 = {np.mean([p['raw_int_rate'] for p in high_leak]):.1%}")
            print(f"      S_edge² 整数率 = {np.mean([p['edge_int_rate'] for p in high_leak]):.1%}")
            print(f"      联合对角化整数率 = {np.mean([p['comb_int_rate'] for p in high_leak]):.1%}")

    # ============================================================
    # Q5: 联合对角化 S_edge² + η S² 能否让 N=7 恢复整数？
    # ============================================================
    print("\n" + "=" * 100)
    print("Q5. 联合对角化 S_edge² + η S² 的恢复效果")
    print("=" * 100)

    for label, pts in [("N=6", points_N6), ("N=7", points_N7)]:
        if not pts:
            continue
        raw_rates = [p["raw_int_rate"] for p in pts]
        edge_rates = [p["edge_int_rate"] for p in pts]
        comb_rates = [p["comb_int_rate"] for p in pts]
        print(f"\n  {label}:")
        print(f"    平均 raw 整数率: {np.mean(raw_rates):.1%}")
        print(f"    平均 S_edge² 后: {np.mean(edge_rates):.1%}")
        print(f"    平均联合后: {np.mean(comb_rates):.1%}")

        # 联合对 raw 的提升
        improvements = [c - r for c, r in zip(comb_rates, raw_rates)]
        n_improved = sum(1 for x in improvements if x > 0.05)
        print(f"    联合后提升 >5% 的点: {n_improved}/{len(pts)}")

    # ============================================================
    # 深度追问：N=6 恢复 vs N=7 不恢复的差异
    # ============================================================
    print("\n" + "=" * 100)
    print("深度追问：N=6 恢复 vs N=7 不恢复的差异")
    print("=" * 100)

    # 只看非整数简并点
    for label, pts in [("N=6", points_N6), ("N=7", points_N7)]:
        if not pts:
            continue
        nonint_pts = [p for p in pts if p["raw_int_rate"] < 0.99]
        if not nonint_pts:
            continue
        print(f"\n  {label}: 非整数点 {len(nonint_pts)} 个")

        # 分类：提升 vs 不提升
        improved = [p for p in nonint_pts
                    if p["edge_int_rate"] > p["raw_int_rate"] + 0.05]
        not_improved = [p for p in nonint_pts
                        if p["edge_int_rate"] <= p["raw_int_rate"] + 0.05]

        print(f"    S_edge² 后提升 >5%: {len(improved)} ({len(improved)/len(nonint_pts):.1%})")
        print(f"    S_edge² 后未提升: {len(not_improved)}")

        # 提升点的特征
        if improved:
            print(f"\n    提升点的 S_edge² 谱:")
            for p in improved[:5]:
                eigs = [round(e, 3) for e in p["edge_eigs"]]
                print(f"      gid={p['gid']}, d={p['deg']}: {eigs}")
                print(f"        raw={[round(x, 3) for x in p['raw_sds']]}")
                print(f"        edge={[round(x, 3) for x in p['edge_sds']]}")

        if not_improved:
            print(f"\n    未提升点的 S_edge² 谱（前 5 个）:")
            for p in not_improved[:5]:
                eigs = [round(e, 3) for e in p["edge_eigs"]]
                print(f"      gid={p['gid']}, d={p['deg']}: {eigs}")
                print(f"        raw={[round(x, 3) for x in p['raw_sds']]}")
                print(f"        edge={[round(x, 3) for x in p['edge_sds']]}")

    # ============================================================
    # 导出
    # ============================================================
    out = {
        "N6": {
            "n_points": len(points_N6),
            "n_nonint": sum(1 for p in points_N6 if p["raw_int_rate"] < 0.99),
            "n_improved": sum(1 for p in points_N6
                              if p["raw_int_rate"] < 0.99 and
                              p["edge_int_rate"] > p["raw_int_rate"] + 0.05),
            "raw_int_rate_mean": float(np.mean([p["raw_int_rate"] for p in points_N6])) if points_N6 else 0,
            "edge_int_rate_mean": float(np.mean([p["edge_int_rate"] for p in points_N6])) if points_N6 else 0,
        },
        "N7": {
            "n_points": len(points_N7),
            "n_nonint": sum(1 for p in points_N7 if p["raw_int_rate"] < 0.99),
            "n_improved": sum(1 for p in points_N7
                              if p["raw_int_rate"] < 0.99 and
                              p["edge_int_rate"] > p["raw_int_rate"] + 0.05),
            "raw_int_rate_mean": float(np.mean([p["raw_int_rate"] for p in points_N7])) if points_N7 else 0,
            "edge_int_rate_mean": float(np.mean([p["edge_int_rate"] for p in points_N7])) if points_N7 else 0,
        },
    }
    out_path = os.path.join(WORK_DIR, "照妖镜_v19_恢复差异.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("v19.0 完成。")
    print("=" * 100)


if __name__ == "__main__":
    main()