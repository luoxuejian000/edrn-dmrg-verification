#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
N=7、8 抽样验证：对合自同构充要条件在更大 N 上是否成立
=========================================================

核心追问：
- N=6 的结论是偶然吗？
- N=7、8 上，E(s) 相同 ⟺ 对合像 是否仍然成立？

理论精髓：
- 关系本体论：响应的分类由对合对称位置决定
- 只查同与不同：不拟合，不预设
- 反对对齐：不预设"对合像必然同响应"
- 严防工具理性悖论：不用平滑、聚类、排序

运行：
    python N78抽样验证.py --N 7 8 --n_samples 200
"""

import sys
import io
import json
import itertools
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from networkx.algorithms.isomorphism import GraphMatcher
from collections import defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)


I2 = np.eye(2, dtype=complex)
SX = np.array([[0, 1], [1, 0]], dtype=complex)
SY = np.array([[0, -1j], [1j, 0]], dtype=complex)
SZ = np.array([[1, 0], [0, -1]], dtype=complex)


def op_on_site(op, site, N):
    ops = [I2] * N
    ops[site] = op
    out = ops[0]
    for o in ops[1:]:
        out = np.kron(out, o)
    return out


def build_site_ops(N):
    return ([op_on_site(SX, i, N) for i in range(N)],
            [op_on_site(SY, i, N) for i in range(N)],
            [op_on_site(SZ, i, N) for i in range(N)])


def edge_matrix(i, j, SX_ops, SY_ops, SZ_ops):
    return SX_ops[i] @ SX_ops[j] + SY_ops[i] @ SY_ops[j] + SZ_ops[i] @ SZ_ops[j]


def ground_state_density(H, tol=1e-8):
    evals, evecs = eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < tol))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    return E0, rho, deg


def edge_correlations(rho, edges, SZ_ops):
    C = {}
    for (i, j) in edges:
        op = SZ_ops[i] @ SZ_ops[j]
        C[(i, j)] = float(np.real(np.trace(rho @ op)))
    return C


def compute_sorted_curve(G, defect_edge, s_vals, SX_ops, SY_ops, SZ_ops):
    N = G.number_of_nodes()
    edges = [tuple(sorted(e)) for e in G.edges()]
    H_edges = {e: edge_matrix(e[0], e[1], SX_ops, SY_ops, SZ_ops) for e in edges}
    H0 = sum(H_edges.values())
    M_defect = H_edges[defect_edge]
    curve = []
    for s in s_vals:
        H = H0 + (s - 1.0) * M_defect
        E0, rho, deg = ground_state_density(H)
        C = edge_correlations(rho, edges, SZ_ops)
        vals = sorted(C.values())
        curve.append(tuple(np.round(vals, 12)))
    return curve


def find_involution_pairs(G):
    """用 NetworkX GraphMatcher 找非平凡对合自同构的边配对。"""
    nodes = list(G.nodes())
    edges = [tuple(sorted(e)) for e in G.edges()]
    matcher = GraphMatcher(G, G)
    pairs = set()
    for mapping in matcher.isomorphisms_iter():
        # 检查对合
        if not all(mapping[mapping[u]] == u for u in nodes):
            continue
        if all(mapping[u] == u for u in nodes):
            continue
        for u, v in G.edges():
            e1 = tuple(sorted((u, v)))
            u2, v2 = mapping[u], mapping[v]
            e2 = tuple(sorted((u2, v2)))
            if e1 != e2 and G.has_edge(u2, v2):
                pairs.add(tuple(sorted([e1, e2])))
    return pairs


def find_edge_orbits(G):
    """用 GraphMatcher 找边自同构轨道。"""
    nodes = list(G.nodes())
    edges = [tuple(sorted(e)) for e in G.edges()]
    matcher = GraphMatcher(G, G)
    orbit_id = {e: None for e in edges}
    oid = 0
    for e in edges:
        if orbit_id[e] is not None:
            continue
        orbit_id[e] = oid
        for mapping in matcher.isomorphisms_iter():
            u, v = e
            u2, v2 = mapping[u], mapping[v]
            e2 = tuple(sorted((u2, v2)))
            if G.has_edge(u2, v2):
                orbit_id[e2] = oid
        oid += 1
    return orbit_id


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--N", type=int, nargs="+", default=[7, 8])
    parser.add_argument("--n_samples", type=int, default=200)
    parser.add_argument("--s_min", type=float, default=-1.5)
    parser.add_argument("--s_max", type=float, default=0.0)
    parser.add_argument("--s_steps", type=int, default=11)
    parser.add_argument("--out", type=str, default="N78抽样验证结果.json")
    args = parser.parse_args()

    s_vals = np.linspace(args.s_min, args.s_max, args.s_steps)
    print("=" * 78)
    print("  N=7、8 抽样验证：对合自同构充要条件")
    print("=" * 78)
    print(f"  N: {args.N}")
    print(f"  抽样数: {args.n_samples}")
    print(f"  s: [{args.s_min}, {args.s_max}], {args.s_steps} 点")
    print()

    all_results = {}

    for N in args.N:
        print("=" * 78)
        print(f"  N={N}")
        print("=" * 78)

        SX_ops, SY_ops, SZ_ops = build_site_ops(N)

        same_orbit_same = 0
        same_orbit_diff = 0
        diff_orbit_same = 0
        diff_orbit_diff = 0
        involution_match = 0
        involution_mismatch = 0
        reverse_match = 0
        reverse_mismatch = 0

        n_processed = 0
        for sample in range(args.n_samples):
            G = nx.gnp_random_graph(N, 0.5, seed=sample)
            if not nx.is_connected(G):
                continue
            edges = [tuple(sorted(e)) for e in G.edges()]
            if len(edges) < 3:
                continue

            orbits = find_edge_orbits(G)
            involution_pairs = find_involution_pairs(G)

            curves = {}
            for e in edges:
                curves[e] = compute_sorted_curve(G, e, s_vals,
                                                 SX_ops, SY_ops, SZ_ops)

            for i, e1 in enumerate(edges):
                for j in range(i + 1, len(edges)):
                    e2 = edges[j]
                    same = all(
                        len(a) == len(b) and np.allclose(a, b, atol=1e-10)
                        for a, b in zip(curves[e1], curves[e2])
                    )
                    same_orbit = (orbits[e1] == orbits[e2])
                    is_inv = tuple(sorted([e1, e2])) in involution_pairs

                    if same_orbit and same:
                        same_orbit_same += 1
                    elif same_orbit and not same:
                        same_orbit_diff += 1
                    elif not same_orbit and same:
                        diff_orbit_same += 1
                        if is_inv:
                            involution_match += 1
                        else:
                            involution_mismatch += 1
                    else:
                        diff_orbit_diff += 1

                    if is_inv and same:
                        reverse_match += 1
                    elif is_inv and not same:
                        reverse_mismatch += 1

            n_processed += 1
            if n_processed % 20 == 0:
                print(f"    已处理 {n_processed} 图")

        print()
        print(f"  N={N} 结果（处理 {n_processed} 图）：")
        print(f"    同轨道同曲线: {same_orbit_same}")
        print(f"    同轨道异曲线: {same_orbit_diff}  ← 必须为 0")
        print(f"    异轨道同曲线: {diff_orbit_same}")
        print(f"    异轨道异曲线: {diff_orbit_diff}")
        print(f"    异轨道同曲线中，是对合像: {involution_match}")
        print(f"    异轨道同曲线中，不是对合像: {involution_mismatch}  ← 必须为 0")
        print(f"    对合像中，同响应: {reverse_match}")
        print(f"    对合像中，不同响应: {reverse_mismatch}  ← 必须为 0")
        print()

        all_results[N] = {
            "n_processed": n_processed,
            "same_orbit_same": same_orbit_same,
            "same_orbit_diff": same_orbit_diff,
            "diff_orbit_same": diff_orbit_same,
            "diff_orbit_diff": diff_orbit_diff,
            "involution_match": involution_match,
            "involution_mismatch": involution_mismatch,
            "reverse_match": reverse_match,
            "reverse_mismatch": reverse_mismatch,
        }

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(all_results, f, ensure_ascii=False, indent=2, default=str)
    print(f"已保存: {args.out}")


if __name__ == "__main__":
    main()