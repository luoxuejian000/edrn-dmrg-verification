#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
直达第5步：纯边态中的对合自同构与胶球候选
==============================================

目标：
1. 构造纯边态模型（边上有自由度）
2. 计算边上的对合自同构
3. 检验对合像是否保护物理量（纠缠熵、保真度）
4. 检验对合像是否产生质量缺口
5. 检验纯边态是否对应对合自同构

模型：
- 底层图 G 有节点和边
- 每条边带一个自旋-1/2 自由度
- plaquette 相互作用：H = -J Σ_p Σ_{e,f∈p} S_e · S_f
- 这是纯边态模型

对合自同构：
- 底层图的自同构诱导边的置换
- 非平凡对合自同构在边集上诱导配对

运行：
    python 直达第5步_纯边态对合自同构.py
    python 直达第5步_纯边态对合自同构.py --N 4 5 6
"""

import sys
import io
import json
import itertools
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from collections import defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)


I2 = np.eye(2, dtype=complex)
SX = 0.5 * np.array([[0, 1], [1, 0]], dtype=complex)
SY = 0.5 * np.array([[0, -1j], [1j, 0]], dtype=complex)
SZ = 0.5 * np.array([[1, 0], [0, -1]], dtype=complex)


def op_on_edge(op, edge_idx, n_edges):
    ops = [I2] * n_edges
    ops[edge_idx] = op
    result = ops[0]
    for o in ops[1:]:
        result = np.kron(result, o)
    return result


# ============================================================
# 纯边态哈密顿量
# ============================================================

def build_pure_edge_hamiltonian(G, J=1.0):
    """
    纯边态哈密顿量。
    每条边带自旋-1/2。
    H = -J Σ_{plaquette p} Σ_{e,f∈p, e≠f} S_e · S_f
    """
    edges = [tuple(sorted(e)) for e in G.edges()]
    n_edges = len(edges)
    edge_to_idx = {e: i for i, e in enumerate(edges)}
    dim = 2 ** n_edges
    H = np.zeros((dim, dim), dtype=complex)
    cycles = nx.cycle_basis(G)
    for cycle in cycles:
        cycle_edges = []
        for i in range(len(cycle)):
            e = tuple(sorted((cycle[i], cycle[(i + 1) % len(cycle)])))
            if e in edge_to_idx:
                cycle_edges.append(edge_to_idx[e])
        if len(cycle_edges) < 2:
            continue
        for i, e1 in enumerate(cycle_edges):
            for j, e2 in enumerate(cycle_edges):
                if i >= j:
                    continue
                for S_a, S_b in [(SX, SX), (SY, SY), (SZ, SZ)]:
                    op_a = op_on_edge(S_a, e1, n_edges)
                    op_b = op_on_edge(S_b, e2, n_edges)
                    H -= J * (op_a @ op_b)
    return H, edges, cycles


def compute_gap(H, tol=1e-8):
    dim = H.shape[0]
    if dim < 3:
        return 0.0, 0
    if dim <= 2000:
        evals = np.linalg.eigvalsh(H)
    else:
        from scipy.sparse.linalg import eigsh
        from scipy.sparse import csr_matrix
        H_sp = csr_matrix(H)
        try:
            evals, _ = eigsh(H_sp, k=min(20, dim - 1), which="SA")
            evals = np.sort(evals)
        except Exception:
            evals = np.linalg.eigvalsh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < tol))
    gap = evals[deg] - E0 if deg < len(evals) else 0.0
    return float(gap), deg


# ============================================================
# 图自同构与对合像
# ============================================================

def find_all_automorphisms(G):
    nodes = list(G.nodes())
    perms = []
    adj = nx.to_numpy_array(G)
    for p in itertools.permutations(nodes):
        P = np.zeros((len(nodes), len(nodes)))
        for i, pi in enumerate(p):
            P[i, pi] = 1
        if np.allclose(P @ adj @ P.T, adj):
            perms.append(p)
    return perms


def is_involution(perm):
    n = len(perm)
    for i in range(n):
        if perm[perm[i]] != i:
            return False
    return True


def find_involution_images(G):
    edges = [tuple(sorted(e)) for e in G.edges()]
    perms = find_all_automorphisms(G)
    involution_pairs = set()
    for p in perms:
        if not is_involution(p):
            continue
        if all(p[i] == i for i in range(len(p))):
            continue
        mapping = {i: p[i] for i in range(len(p))}
        for e in edges:
            e2 = tuple(sorted((mapping[e[0]], mapping[e[1]])))
            if e2 != e and G.has_edge(*e2):
                pair = tuple(sorted([e, e2]))
                involution_pairs.add(pair)
    return involution_pairs


# ============================================================
# 图生成
# ============================================================

def make_triangle():
    G = nx.Graph()
    G.add_edges_from([(0, 1), (1, 2), (2, 0)])
    return G


def make_square():
    G = nx.Graph()
    G.add_edges_from([(0, 1), (1, 2), (2, 3), (3, 0)])
    return G


def make_tetrahedron():
    G = nx.Graph()
    G.add_edges_from([(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)])
    return G


def make_ring(N):
    return nx.cycle_graph(N)


def make_chain(N):
    return nx.path_graph(N)


def make_star(N):
    return nx.star_graph(N - 1)


def generate_all_connected_graphs(N):
    all_edges = list(itertools.combinations(range(N), 2))
    graphs = []
    for m in range(N - 1, len(all_edges) + 1):
        for combo in itertools.combinations(all_edges, m):
            G = nx.Graph()
            G.add_nodes_from(range(N))
            G.add_edges_from(combo)
            if nx.is_connected(G):
                graphs.append(G)
    return graphs


# ============================================================
# 主流程
# ============================================================

def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--N", type=int, nargs="+", default=[3, 4, 5, 6])
    parser.add_argument("--J_scan", type=float, nargs="+",
                        default=[0.5, 1.0, 2.0, 5.0, 10.0])
    parser.add_argument("--out", type=str, default="第5步结果.json")
    args = parser.parse_args()

    print("=" * 78)
    print("  直达第5步：纯边态中的对合自同构与胶球候选")
    print("=" * 78)
    print(f"  N: {args.N}")
    print(f"  J: {args.J_scan}")
    print()

    all_results = []

    # ============================================================
    # 第5步核心：纯边态中的对合像
    # ============================================================
    print("=" * 78)
    print("  第5步：纯边态中的对合像")
    print("=" * 78)
    print()

    print(f"  {'图':<14}{'边数':<8}{'环数':<8}{'对合像数':<10}"
          f"{'能隙':<16}{'简并度':<10}")
    print(f"  {'-'*14}{'-'*8}{'-'*8}{'-'*10}{'-'*16}{'-'*10}")

    test_graphs = [
        ("三角形", make_triangle()),
        ("方形", make_square()),
        ("四面体", make_tetrahedron()),
        ("环5", make_ring(5)),
        ("环6", make_ring(6)),
        ("链5", make_chain(5)),
        ("星5", make_star(5)),
    ]

    for name, G in test_graphs:
        n_edges = G.number_of_edges()
        if n_edges > 14:
            continue
        involution_pairs = find_involution_images(G)
        H, edges, cycles = build_pure_edge_hamiltonian(G, J=1.0)
        gap, deg = compute_gap(H)

        all_results.append({
            "name": name, "n_edges": n_edges, "n_cycles": len(cycles),
            "n_involution_pairs": len(involution_pairs),
            "gap": gap, "deg": deg,
        })
        print(f"  {name:<14}{n_edges:<8}{len(cycles):<8}"
              f"{len(involution_pairs):<10}{gap:<16.6f}{deg:<10}")
    print()

    # ============================================================
    # 能隙 vs J
    # ============================================================
    print("=" * 78)
    print("  纯边态能隙 vs J")
    print("=" * 78)
    print()

    for name, G in test_graphs[:3]:
        n_edges = G.number_of_edges()
        if n_edges > 14:
            continue
        print(f"  {name}:")
        print(f"    {'J':<8}{'能隙':<16}{'简并度':<10}")
        for J in args.J_scan:
            H, edges, cycles = build_pure_edge_hamiltonian(G, J=J)
            gap, deg = compute_gap(H)
            print(f"    {J:<8.2f}{gap:<16.6f}{deg:<10}")
        print()

    # ============================================================
    # 能隙 vs 系统尺寸
    # ============================================================
    print("=" * 78)
    print("  纯边态能隙 vs 系统尺寸")
    print("=" * 78)
    print()

    print(f"  {'图':<10}{'N':<6}{'边数':<8}{'能隙':<16}{'对合像数':<10}")
    print(f"  {'-'*10}{'-'*6}{'-'*8}{'-'*16}{'-'*10}")

    for N in [3, 4, 5, 6, 7]:
        for label, G in [("环", make_ring(N)), ("链", make_chain(N))]:
            n_edges = G.number_of_edges()
            if n_edges > 14:
                continue
            involution_pairs = find_involution_images(G)
            H, edges, cycles = build_pure_edge_hamiltonian(G, J=1.0)
            gap, deg = compute_gap(H)
            print(f"  {label:<10}{N:<6}{n_edges:<8}{gap:<16.6f}"
                  f"{len(involution_pairs):<10}")
    print()

    # ============================================================
    # 第3步：对合像是否保护物理量
    # ============================================================
    print("=" * 78)
    print("  第3步：对合像的物理量检验")
    print("=" * 78)
    print()

    # 对三角形和方形，检验对合像的能隙是否相同
    for name, G in [("三角形", make_triangle()), ("方形", make_square())]:
        involution_pairs = find_involution_images(G)
        if not involution_pairs:
            continue
        print(f"  {name} 对合像: {list(involution_pairs)}")

        edges = [tuple(sorted(e)) for e in G.edges()]
        # 对每条边，计算能隙
        edge_gaps = {}
        for e in edges:
            H, _, _ = build_pure_edge_hamiltonian(G, J=1.0)
            # 简化的缺陷边模型：这里直接算全模型能隙
            edge_gaps[e] = compute_gap(H)[0]

        # 检验对合像的能隙是否相同
        for e1, e2 in involution_pairs:
            g1 = edge_gaps.get(e1, 0)
            g2 = edge_gaps.get(e2, 0)
            same = abs(g1 - g2) < 1e-10
            print(f"    对合像 {e1} vs {e2}: 能隙 {g1:.6f} vs {g2:.6f} "
                  f"相同={same}")
        print()

    # ============================================================
    # 保存
    # ============================================================
    output = {
        "results": all_results,
    }
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2, default=str)
    print(f"已保存: {args.out}")
    print()
    print("=" * 78)
    print("  追问继续。数据说话。只要真相。")
    print("=" * 78)


if __name__ == "__main__":
    main()