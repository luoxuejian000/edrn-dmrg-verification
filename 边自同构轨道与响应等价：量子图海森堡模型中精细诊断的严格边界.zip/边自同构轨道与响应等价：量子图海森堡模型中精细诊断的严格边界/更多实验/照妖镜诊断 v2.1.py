# -*- coding: utf-8 -*-
"""
照妖镜诊断 v2.1
28 vs 32：对每一个截断点做敏感性分析

不修改主脚本。只做一件事：
  把 v2.0 的每一个截断点单独打开，看 28 怎么变。

截断点：
  T1. 同响应容差 tol
  T2. S_GRID 范围与点数
  T3. 基态简并判定阈值
  T4. 期望值算法（对角 vs 双重循环）
  T5. NaN 过滤策略

输出：并排表格，不做结论。
"""

import os
import json
import warnings
from collections import Counter
from itertools import combinations

import numpy as np
import networkx as nx

warnings.filterwarnings('ignore')

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"
N_NODES = 6

# ---------------- 基础 ----------------

def build_all_N6_graphs():
    candidates = []
    for G in nx.graph_atlas_g():
        if G.number_of_nodes() == N_NODES and nx.is_connected(G):
            candidates.append(nx.convert_node_labels_to_integers(G))
    unique = []
    for G in candidates:
        if not any(nx.is_isomorphic(G, H) for H in unique):
            unique.append(G)
    return unique

def build_adj_list(G):
    nodes = sorted(G.nodes())
    node_idx = {n: i for i, n in enumerate(nodes)}
    edges = sorted([tuple(sorted((node_idx[a], node_idx[b])))
                    for a, b in G.edges()])
    return edges

def sz0_basis(N):
    n_up = N // 2
    basis = []
    for comb in combinations(range(N), n_up):
        state = [0] * N
        for i in comb:
            state[i] = 1
        basis.append(tuple(state))
    return basis

def build_H_sz0(N, edges, couplings):
    basis = sz0_basis(N)
    dim = len(basis)
    idx = {s: i for i, s in enumerate(basis)}
    H = np.zeros((dim, dim))
    for i, state in enumerate(basis):
        for (a, b), J in zip(edges, couplings):
            if state[a] == state[b]:
                H[i, i] += J
            else:
                H[i, i] -= J
                new_state = list(state)
                new_state[a], new_state[b] = new_state[b], new_state[a]
                H[i, idx[tuple(new_state)]] += 2.0 * J
    return H, basis

def edge_orbits(G, edges):
    GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
    autos = list(GM.isomorphisms_iter())
    orbits = {}
    for e in edges:
        orbit = set()
        for auto in autos:
            mapped = frozenset({auto[e[0]], auto[e[1]]})
            orbit.add(mapped)
        orbits[e] = frozenset(orbit)
    uniq = {}
    out = {}
    for e in edges:
        o = orbits[e]
        if o not in uniq:
            uniq[o] = len(uniq)
        out[e] = uniq[o]
    return out

# ---------------- 期望值计算（可切换算法） ----------------

def compute_E_curve(G, defect_edge, s_grid, degen_tol=1e-8, mode="diagonal"):
    """
    mode:
      "diagonal"  -> 只取对角项（v2.0）
      "double"    -> 双重循环（v1.0 的 bug）
    """
    N = G.number_of_nodes()
    edges = build_adj_list(G)
    target = tuple(sorted(defect_edge))
    if target not in edges:
        target = tuple(sorted((defect_edge[1], defect_edge[0])))

    curves = []
    for s in s_grid:
        couplings = [s if e == target else 1.0 for e in edges]
        H, basis = build_H_sz0(N, edges, couplings)
        try:
            vals, vecs = np.linalg.eigh(H)
        except Exception:
            curves.append(np.nan)
            continue
        E0 = vals[0]
        degen = np.where(np.abs(vals - E0) < degen_tol)[0]
        rho = np.zeros_like(H)
        for k in degen:
            v = vecs[:, k].reshape(-1, 1)
            rho += v @ v.conj().T
        rho /= len(degen)

        sz_config = np.array([[1.0 if state[i] == 1 else -1.0
                               for i in range(N)] for state in basis])

        corr = []
        if mode == "diagonal":
            rho_diag = np.diag(rho).real
            for (a, b) in edges:
                val = float(np.sum(rho_diag * sz_config[:, a] * sz_config[:, b]))
                corr.append(val)
        elif mode == "double":
            for (a, b) in edges:
                val = 0.0
                for i in range(len(basis)):
                    for j in range(len(basis)):
                        if i == j:
                            val += rho[i, j] * sz_config[i, a] * sz_config[i, b]
                        else:
                            val += rho[i, j] * sz_config[i, a] * sz_config[j, b]
                corr.append(val.real)
        curves.append(float(np.std(corr)))
    return np.array(curves)

def curves_equal(c1, c2, tol, drop_nan=True):
    if len(c1) != len(c2):
        return False, np.inf
    if drop_nan:
        m = ~(np.isnan(c1) | np.isnan(c2))
    else:
        m = np.ones(len(c1), dtype=bool)
    if m.sum() == 0:
        return False, np.inf
    d = float(np.max(np.abs(c1[m] - c2[m])))
    return bool(d < tol), d

# ---------------- 扫描 ----------------

def scan_all_pairs(graphs, s_grid, tol, degen_tol, mode):
    """
    返回所有异轨道对的 max_diff 字典。
    key: (graph_id, e1, e2)
    value: max_diff
    """
    result = {}
    for gid, G in enumerate(graphs):
        edges = build_adj_list(G)
        orbits = edge_orbits(G, edges)
        curves = {e: compute_E_curve(G, e, s_grid, degen_tol, mode) for e in edges}
        for i in range(len(edges)):
            for j in range(i + 1, len(edges)):
                e1, e2 = edges[i], edges[j]
                if orbits[e1] == orbits[e2]:
                    continue
                eq, d = curves_equal(curves[e1], curves[e2], tol)
                result[(gid, e1, e2)] = d
    return result

def count_under_tol(diffs, tol):
    return sum(1 for d in diffs.values() if d < tol)

# ---------------- 主诊断 ----------------

def main():
    print("=" * 100)
    print("照妖镜诊断 v2.1：28 vs 32 的截断敏感性分析")
    print("=" * 100)

    print("\n[1/5] 构建图集…")
    graphs = build_all_N6_graphs()
    print(f"  图集: {len(graphs)} 个 N=6 连通图")

    # 基准：v2.0 参数
    base_grid = np.linspace(-3, 3, 61)
    base_tol = 1e-10
    base_degen = 1e-8
    base_mode = "diagonal"

    print("\n[2/5] 基准扫描（v2.0 参数）…")
    base = scan_all_pairs(graphs, base_grid, base_tol, base_degen, base_mode)
    print(f"  总异轨道对数: {len(base)}")
    print(f"  同响应对（tol={base_tol}）: {count_under_tol(base, base_tol)}")

    # T1: 容差扫描
    print("\n[3/5] T1 容差扫描…")
    print(f"  {'tol':>10} | {'同响应对':>8}")
    print(f"  {'-'*10}-+-{'-'*8}")
    for tol in [1e-14, 1e-13, 1e-12, 1e-11, 1e-10, 1e-9, 1e-8, 1e-7, 1e-6, 1e-5, 1e-4]:
        n = count_under_tol(base, tol)
        print(f"  {tol:>10.0e} | {n:>8d}")

    # T2: S_GRID 扫描
    print("\n[4/5] T2 S_GRID 扫描（容差固定 1e-10）…")
    print(f"  {'范围':>15} | {'点数':>5} | {'同响应对':>8}")
    print(f"  {'-'*15}-+-{'-'*5}-+-{'-'*8}")
    for lo, hi in [(-1, 1), (-2, 2), (-3, 3), (-4, 4), (0, 2), (0.5, 1.6)]:
        for npts in [21, 41, 61, 121]:
            grid = np.linspace(lo, hi, npts)
            r = scan_all_pairs(graphs, grid, base_tol, base_degen, base_mode)
            n = count_under_tol(r, base_tol)
            print(f"  [{lo:>3},{hi:>3}] | {npts:>5d} | {n:>8d}")

    # T3: 简并阈值扫描
    print("\n[5/5] T3 简并阈值扫描（容差 1e-10, S_GRID=[-3,3]x61）…")
    print(f"  {'degen_tol':>12} | {'同响应对':>8}")
    print(f"  {'-'*12}-+-{'-'*8}")
    for dt in [1e-12, 1e-10, 1e-9, 1e-8, 1e-7, 1e-6, 1e-5, 1e-4]:
        r = scan_all_pairs(graphs, base_grid, base_tol, dt, base_mode)
        n = count_under_tol(r, base_tol)
        print(f"  {dt:>12.0e} | {n:>8d}")

    # T4: 期望值算法对比
    print("\n[T4] 期望值算法对比（容差 1e-10, S_GRID=[-3,3]x61）…")
    for mode in ["diagonal", "double"]:
        r = scan_all_pairs(graphs, base_grid, base_tol, base_degen, mode)
        n = count_under_tol(r, base_tol)
        print(f"  mode={mode:>10} -> 同响应对 {n}")

    # 输出 28 对清单（v2.0 基准下的同响应对）
    print("\n" + "=" * 100)
    print("v2.0 基准下的 28 对清单")
    print("=" * 100)
    pairs_28 = sorted([k for k, d in base.items() if d < base_tol],
                      key=lambda x: (x[0], x[1], x[2]))
    for k in pairs_28:
        gid, e1, e2 = k
        print(f"  graph_id={gid:>3}  e1={e1}  e2={e2}  max_diff={base[k]:.3e}")

    # 边界对：max_diff 接近容差
    print("\n" + "=" * 100)
    print("边界对：max_diff 在 [1e-10, 1e-6] 之间的异轨道对")
    print("=" * 100)
    boundary = sorted([(k, d) for k, d in base.items()
                       if 1e-10 <= d < 1e-6], key=lambda x: x[1])
    print(f"  边界对总数: {len(boundary)}")
    for k, d in boundary[:50]:
        gid, e1, e2 = k
        print(f"  graph_id={gid:>3}  e1={e1}  e2={e2}  max_diff={d:.3e}")

    # 导出
    out = {
        "base_count": count_under_tol(base, base_tol),
        "pairs_28": [{"graph_id": k[0], "e1": list(k[1]), "e2": list(k[2]),
                      "max_diff": base[k]} for k in pairs_28],
        "boundary": [{"graph_id": k[0], "e1": list(k[1]), "e2": list(k[2]),
                      "max_diff": d} for k, d in boundary],
        "all_diffs": {f"{k[0]}_{k[1]}_{k[2]}": d for k, d in base.items()},
    }
    out_path = os.path.join(WORK_DIR, "照妖镜诊断_28vs32.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("诊断完成。并排展示。不筛选。不排序。不下结论。")
    print("=" * 100)

if __name__ == "__main__":
    main()