#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 v29.0：攻击"S 值相同"这个全类覆盖条件
================================================================

v28 发现：
  - "S 值相同（|S1 - S2| < 1e-3）" 是 47 对中唯一 100% 覆盖的条件
  - 类 1（非简并 38 对）: 38/38 满足
  - 类 2（简并 9 对）: 9/9 满足
  - 其他条件都不是 100% 覆盖

v29 集中攻击：
  Q1. "S 值相同"是 47 对的特异条件吗？还是 2731 对中大部分都满足？
  Q2. 如果大部分满足，它不是判别器；如果只有 47 对满足，它就是机制的核心条件。
  Q3. S 值如何分布？47 对 vs 2684 对是否有不同的 S 分布？
  Q4. "S 值相同"是否在非简并对和简并对上都有机制含义？
  Q5. 如果在 N=7 上也检验，它是否成立？
"""

import sys, io, itertools, json, os
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from collections import Counter, defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"


# ============================================================
# 基础
# ============================================================

def build_atlas_graphs(N):
    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    return graphs


def build_sz0_sector(N):
    n_up = N // 2
    basis = []
    for comb in itertools.combinations(range(N), n_up):
        state = [0]*N
        for i in comb: state[i] = 1
        basis.append(tuple(state))
    dim = len(basis)
    idx = {s: i for i, s in enumerate(basis)}
    SZ_ops = []
    for site in range(N):
        SZ = np.zeros((dim, dim), dtype=complex)
        for i, state in enumerate(basis):
            SZ[i, i] = 1 if state[site] == 1 else -1
        SZ_ops.append(SZ)
    return basis, idx, SZ_ops


def build_edge_op(i, j, basis, idx):
    dim = len(basis)
    op = np.zeros((dim, dim), dtype=complex)
    for a_idx, state_a in enumerate(basis):
        sa, sb = state_a[i], state_a[j]
        if sa == sb:
            op[a_idx, a_idx] += 1
        else:
            op[a_idx, a_idx] += -1
            new_state = list(state_a)
            new_state[i], new_state[j] = new_state[j], new_state[i]
            b_idx = idx.get(tuple(new_state))
            if b_idx is not None:
                op[b_idx, a_idx] += 2
    return op


def build_S2_op(basis, idx, N):
    dim = len(basis)
    S2 = np.zeros((dim, dim), dtype=complex)
    for i in range(N):
        S2 += 3/4 * np.eye(dim, dtype=complex)
        for j in range(N):
            if i == j: continue
            S2 += 1/4 * build_edge_op(i, j, basis, idx)
    return S2


def analyze_at_s(edge_ops, defect, s, SZ_ops, S2_op, ref_dim):
    """在 s 处返回 S_total, pS, sd"""
    H = np.zeros((ref_dim, ref_dim), dtype=complex)
    for e, M in edge_ops.items():
        c = s if e == defect else 1.0
        H += c * M
    try:
        evals, evecs = eigh(H)
    except Exception:
        return None
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < 1e-8))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    S2_val = float(np.real(np.trace(rho @ S2_op)))
    S_total = (-1 + np.sqrt(1 + 4*max(S2_val, 0))) / 2
    i, j = defect
    szsz_diag = np.diag(SZ_ops[i] @ SZ_ops[j])
    szsz = float(np.real(np.sum(np.diag(rho) * szsz_diag)))
    p_S = (1 - 3 * szsz) / 4
    sd = float(np.real(np.trace(rho @ edge_ops[defect])))
    return {
        "S": S_total, "pS": p_S, "sd": sd, "deg": deg,
    }


def load_patterns():
    with open(os.path.join(WORK_DIR, "照妖镜_v5_1_模式.json"), "r",
              encoding="utf-8") as f:
        v51 = json.load(f)
    patterns = {}
    for key, s in v51["patterns"].items():
        gid, e1_str, e2_str = key.split("_", 2)
        gid = int(gid)
        e1 = tuple(map(int, e1_str.strip("()").split(",")))
        e2 = tuple(map(int, e2_str.strip("()").split(",")))
        patterns[(gid, tuple(sorted(e1)), tuple(sorted(e2)))] = s
    return patterns


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 100)
    print("照妖镜 v29.0：攻击 S 值相同这个全类覆盖条件")
    print("=" * 100)

    N = 6
    graphs = build_atlas_graphs(N)
    patterns = load_patterns()
    print(f"\n  N={N} 图集: {len(graphs)} 图")
    print(f"  已知同响应对: {len(patterns)}")

    basis, idx, SZ_ops = build_sz0_sector(N)
    ref_dim = len(basis)
    S2_op = build_S2_op(basis, idx, N)

    # ============================================================
    # 扫描全部 2731 对异轨道对，计算 S1, S2 at s=0.5
    # ============================================================
    print(f"\n  扫描全部 2731 对，计算 S 值...")
    all_pairs = []
    for gid, G in enumerate(graphs):
        if gid % 30 == 0:
            print(f"    {gid}/{len(graphs)}")
        edges = [tuple(sorted(e)) for e in G.edges()]
        # 轨道
        GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
        autos = list(GM.isomorphisms_iter())
        orbits = {}
        for e in edges:
            orbit = frozenset(frozenset({a[e[0]], a[e[1]]}) for a in autos)
            orbits[e] = orbit

        edge_ops = {e: build_edge_op(e[0], e[1], basis, idx) for e in edges}
        # 缓存 S 值
        S_cache = {}
        for e in edges:
            r = analyze_at_s(edge_ops, e, 0.5, SZ_ops, S2_op, ref_dim)
            S_cache[e] = r

        for i in range(len(edges)):
            for j in range(i + 1, len(edges)):
                e1, e2 = edges[i], edges[j]
                if orbits[e1] == orbits[e2]:
                    continue
                key = (gid, e1, e2)
                n_true = patterns[key].count("1") if key in patterns else 0

                S1 = S_cache[e1]["S"] if S_cache[e1] else None
                S2 = S_cache[e2]["S"] if S_cache[e2] else None
                sd1 = S_cache[e1]["sd"] if S_cache[e1] else None
                sd2 = S_cache[e2]["sd"] if S_cache[e2] else None
                d1 = S_cache[e1]["deg"] if S_cache[e1] else None
                d2 = S_cache[e2]["deg"] if S_cache[e2] else None

                S_same = abs(S1 - S2) < 1e-3 if S1 is not None and S2 is not None else False

                all_pairs.append({
                    "gid": gid, "e1": e1, "e2": e2,
                    "n_true": n_true,
                    "S1": S1, "S2": S2,
                    "S_same": S_same,
                    "sd1": sd1, "sd2": sd2,
                    "d1": d1, "d2": d2,
                })

    print(f"\n  总对数: {len(all_pairs)}")
    n_same_response = sum(1 for p in all_pairs if p["n_true"] > 0)
    n_diff_response = sum(1 for p in all_pairs if p["n_true"] == 0)
    print(f"  同响应: {n_same_response}")
    print(f"  异响应: {n_diff_response}")

    # ============================================================
    # Q1: S 值相同在 2731 对中的分布
    # ============================================================
    print("\n" + "=" * 100)
    print("Q1. S 值相同在全部异轨道对中的分布")
    print("=" * 100)

    s_same_pairs = [p for p in all_pairs if p["S_same"]]
    s_diff_pairs = [p for p in all_pairs if not p["S_same"]]
    print(f"\n  S1 == S2 的对: {len(s_same_pairs)}")
    print(f"  S1 != S2 的对: {len(s_diff_pairs)}")

    n_s_same_in_same_resp = sum(1 for p in s_same_pairs if p["n_true"] > 0)
    n_s_same_in_diff_resp = sum(1 for p in s_same_pairs if p["n_true"] == 0)
    n_s_diff_in_same_resp = sum(1 for p in s_diff_pairs if p["n_true"] > 0)
    n_s_diff_in_diff_resp = sum(1 for p in s_diff_pairs if p["n_true"] == 0)

    print(f"\n  --- 2x2 交叉表 ---")
    print(f"  {'':>18} | {'同响应':>8} | {'异响应':>8} | {'总数':>8}")
    print(f"  {'-'*18}-+-{'-'*8}-+-{'-'*8}-+-{'-'*8}")
    print(f"  {'S1 == S2':>18} | {n_s_same_in_same_resp:>8} | "
          f"{n_s_same_in_diff_resp:>8} | {len(s_same_pairs):>8}")
    print(f"  {'S1 != S2':>18} | {n_s_diff_in_same_resp:>8} | "
          f"{n_s_diff_in_diff_resp:>8} | {len(s_diff_pairs):>8}")

    # 精度 & 召回
    print(f"\n  --- S 值相同作为判别器 ---")
    prec = n_s_same_in_same_resp / len(s_same_pairs) if s_same_pairs else 0
    rec = n_s_same_in_same_resp / n_same_response if n_same_response else 0
    f1 = 2 * prec * rec / (prec + rec) if (prec + rec) > 0 else 0
    print(f"  候选数: {len(s_same_pairs)}")
    print(f"  命中同响应: {n_s_same_in_same_resp}")
    print(f"  精度: {prec:.1%}")
    print(f"  召回: {rec:.1%}")
    print(f"  F1: {f1:.1%}")

    # ============================================================
    # Q2: S 值相同的对中，n_true 的分布
    # ============================================================
    print("\n" + "=" * 100)
    print("Q2. S 值相同的对中，n_true 的分布")
    print("=" * 100)

    print(f"\n  {'n_true':>8} | {'数量':>6}")
    print(f"  {'-'*8}-+-{'-'*6}")
    by_n_true = Counter(p["n_true"] for p in s_same_pairs)
    for nt in sorted(by_n_true.keys(), reverse=True):
        print(f"  {nt:>8} | {by_n_true[nt]:>6}")

    # ============================================================
    # Q3: S 值分布
    # ============================================================
    print("\n" + "=" * 100)
    print("Q3. S 值分布：同响应 vs 异响应")
    print("=" * 100)

    same_resp_S = []
    for p in all_pairs:
        if p["n_true"] > 0:
            same_resp_S.append((p["S1"], p["S2"]))

    diff_resp_S = []
    for p in all_pairs:
        if p["n_true"] == 0:
            diff_resp_S.append((p["S1"], p["S2"]))

    print(f"\n  --- 同响应（47 对）的 (S1, S2) 分布 ---")
    cnt_same = Counter()
    for S1, S2 in same_resp_S:
        cnt_same[(round(S1, 1) if S1 is not None else None,
                  round(S2, 1) if S2 is not None else None)] += 1
    for key in sorted(cnt_same.keys(), key=lambda x: (x[0] is None, x[0] or 0, x[1] or 0)):
        print(f"    (S1, S2) = {key}: {cnt_same[key]}")

    print(f"\n  --- 异响应（2684 对）的 (S1, S2) 分布 ---")
    cnt_diff = Counter()
    for S1, S2 in diff_resp_S:
        cnt_diff[(round(S1, 1) if S1 is not None else None,
                  round(S2, 1) if S2 is not None else None)] += 1
    for key in sorted(cnt_diff.keys(), key=lambda x: (x[0] is None, x[0] or 0, x[1] or 0)):
        print(f"    (S1, S2) = {key}: {cnt_diff[key]}")

    # ============================================================
    # Q4: S 值相同的对中，非简并 vs 简并
    # ============================================================
    print("\n" + "=" * 100)
    print("Q4. S 值相同的对：非简并 vs 简并")
    print("=" * 100)

    s_same_nondeg = [p for p in s_same_pairs if max(p["d1"], p["d2"]) == 1]
    s_same_deg = [p for p in s_same_pairs if max(p["d1"], p["d2"]) > 1]
    print(f"\n  S 值相同 + 非简并: {len(s_same_nondeg)}")
    print(f"  S 值相同 + 简并: {len(s_same_deg)}")

    n_same_in_nondeg = sum(1 for p in s_same_nondeg if p["n_true"] > 0)
    n_same_in_deg = sum(1 for p in s_same_deg if p["n_true"] > 0)
    print(f"\n  其中同响应:")
    print(f"    S 值相同 + 非简并 + 同响应: {n_same_in_nondeg}/{len(s_same_nondeg)}")
    print(f"    S 值相同 + 简并 + 同响应: {n_same_in_deg}/{len(s_same_deg)}")

    # ============================================================
    # Q5: 逐图检查 S 值相同的分布
    # ============================================================
    print("\n" + "=" * 100)
    print("Q5. 逐图检查 S 值相同的分布")
    print("=" * 100)

    by_gid_s_same = defaultdict(list)
    for p in s_same_pairs:
        by_gid_s_same[p["gid"]].append(p)

    print(f"\n  {'gid':>4} | {'S 值相同对数':>12} | {'其中同响应':>10} | {'同响应比例':>10}")
    print(f"  {'-'*4}-+-{'-'*12}-+-{'-'*10}-+-{'-'*10}")
    for gid in sorted(by_gid_s_same.keys())[:30]:
        group = by_gid_s_same[gid]
        n_same = sum(1 for p in group if p["n_true"] > 0)
        print(f"  {gid:>4} | {len(group):>12} | {n_same:>10} | "
              f"{n_same/len(group):>10.1%}")

    # ============================================================
    # 深度追问：S 值相同的对是否本身是一个自然类？
    # ============================================================
    print("\n" + "=" * 100)
    print("深度追问：S 值相同是否是一个自然类")
    print("=" * 100)

    # 计算 S 值相同 + 同响应的对的图论特征
    s_same_same = [p for p in s_same_pairs if p["n_true"] > 0]
    s_same_diff = [p for p in s_same_pairs if p["n_true"] == 0]

    print(f"\n  S 值相同 + 同响应: {len(s_same_same)}")
    print(f"  S 值相同 + 异响应: {len(s_same_diff)}")

    # 这些对的 S 值分布
    print(f"\n  --- S 值相同 + 同响应的 S 值分布 ---")
    cnt_S = Counter()
    for p in s_same_same:
        cnt_S[round(p["S1"], 2)] += 1
    for S_val in sorted(cnt_S.keys()):
        print(f"    S = {S_val}: {cnt_S[S_val]} 对")

    print(f"\n  --- S 值相同 + 异响应的 S 值分布 ---")
    cnt_S_diff = Counter()
    for p in s_same_diff:
        cnt_S_diff[round(p["S1"], 2)] += 1
    for S_val in sorted(cnt_S_diff.keys())[:20]:
        print(f"    S = {S_val}: {cnt_S_diff[S_val]} 对")

    # ============================================================
    # 关键问题：S 值相同 + 非简并 + 同响应 vs 异响应
    # ============================================================
    print("\n" + "=" * 100)
    print("关键追问：S 值相同 + 非简并 能否区分同响应/异响应？")
    print("=" * 100)

    s_same_nondeg_same = [p for p in s_same_nondeg if p["n_true"] > 0]
    s_same_nondeg_diff = [p for p in s_same_nondeg if p["n_true"] == 0]

    print(f"\n  S 值相同 + 非简并 + 同响应: {len(s_same_nondeg_same)}")
    print(f"  S 值相同 + 非简并 + 异响应: {len(s_same_nondeg_diff)}")

    prec2 = len(s_same_nondeg_same) / len(s_same_nondeg) if s_same_nondeg else 0
    print(f"  精度: {prec2:.1%}")

    # ============================================================
    # 导出
    # ============================================================
    out = {
        "n_total": len(all_pairs),
        "n_s_same": len(s_same_pairs),
        "n_s_same_same_response": n_s_same_in_same_resp,
        "n_s_same_diff_response": n_s_same_in_diff_resp,
        "precision": prec,
        "recall": rec,
        "f1": f1,
        "s_same_nondeg": len(s_same_nondeg),
        "s_same_deg": len(s_same_deg),
        "n_same_in_nondeg": n_same_in_nondeg,
        "n_same_in_deg": n_same_in_deg,
    }
    out_path = os.path.join(WORK_DIR, "照妖镜_v29_S值相同.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("v29.0 完成。S 值相同条件被攻击。")
    print("=" * 100)


if __name__ == "__main__":
    main()