#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
N=7 异轨道同响应解剖（修正版）
====================================

修正点：
- 只枚举 N=7 的 853 个非同构连通图（用 nx.graph_atlas_g）。
- 不再枚举 1866256 个带标号图。

运行：
    python N7异轨道同响应解剖_修正版.py
"""

import sys
import io
import json
import itertools
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from collections import defaultdict, Counter

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)


I2 = np.eye(2, dtype=complex)
SX = np.array([[0, 1], [1, 0]], dtype=complex)
SY = np.array([[0, -1j], [1j, 0]], dtype=complex)
SZ = np.array([[1, 0], [0, -1]], dtype=complex)


def op_on_site(op, site, N):
    ops = [I2] * N
    ops[site] = op
    out = ops[0]
    for o in ops[1:]:
        out = np.kron(out, o)
    return out


def build_site_ops(N):
    return ([op_on_site(SX, i, N) for i in range(N)],
            [op_on_site(SY, i, N) for i in range(N)],
            [op_on_site(SZ, i, N) for i in range(N)])


def edge_matrix(i, j, SX_ops, SY_ops, SZ_ops):
    return SX_ops[i] @ SX_ops[j] + SY_ops[i] @ SY_ops[j] + SZ_ops[i] @ SZ_ops[j]


def ground_state_density(H, tol=1e-8):
    evals, evecs = eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < tol))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    return E0, rho, deg


def edge_correlations(rho, edges, SZ_ops):
    C = {}
    for (i, j) in edges:
        op = SZ_ops[i] @ SZ_ops[j]
        C[(i, j)] = float(np.real(np.trace(rho @ op)))
    return C


def compute_sorted_curve(G, defect_edge, s_vals, SX_ops, SY_ops, SZ_ops):
    N = G.number_of_nodes()
    edges = [tuple(sorted(e)) for e in G.edges()]
    H_edges = {e: edge_matrix(e[0], e[1], SX_ops, SY_ops, SZ_ops) for e in edges}
    H0 = sum(H_edges.values())
    M_defect = H_edges[defect_edge]
    curve = []
    for s in s_vals:
        H = H0 + (s - 1.0) * M_defect
        E0, rho, deg = ground_state_density(H)
        C = edge_correlations(rho, edges, SZ_ops)
        curve.append(tuple(np.round(sorted(C.values()), 12)))
    return curve


def find_automorphisms(G):
    nodes = list(G.nodes())
    adj = nx.to_numpy_array(G)
    perms = []
    for p in itertools.permutations(nodes):
        P = np.zeros((len(nodes), len(nodes)))
        for i, pi in enumerate(p):
            P[i, pi] = 1
        if np.allclose(P @ adj @ P.T, adj):
            perms.append(p)
    return perms


def find_edge_orbits(G):
    nodes = list(G.nodes())
    edges = [tuple(sorted(e)) for e in G.edges()]
    perms = find_automorphisms(G)
    orbit_id = {e: None for e in edges}
    oid = 0
    for e in edges:
        if orbit_id[e] is not None:
            continue
        orbit_id[e] = oid
        for p in perms:
            mapping = {nodes[i]: p[i] for i in range(len(nodes))}
            e2 = tuple(sorted((mapping[e[0]], mapping[e[1]])))
            if G.has_edge(*e2):
                orbit_id[e2] = oid
        oid += 1
    return orbit_id


def find_involution_pairs(G):
    nodes = list(G.nodes())
    edges = [tuple(sorted(e)) for e in G.edges()]
    perms = find_automorphisms(G)
    pairs = set()
    for p in perms:
        if not all(p[p[i]] == i for i in range(len(p))):
            continue
        if all(p[i] == i for i in range(len(p))):
            continue
        mapping = {i: p[i] for i in range(len(p))}
        for e in edges:
            e2 = tuple(sorted((mapping[e[0]], mapping[e[1]])))
            if e2 != e and G.has_edge(*e2):
                pairs.add(tuple(sorted([e, e2])))
    return pairs


def edge_features(G, edge):
    u, v = edge
    deg_u = G.degree(u)
    deg_v = G.degree(v)
    H = G.copy()
    H.remove_edge(u, v)
    is_bridge = not nx.is_connected(H)
    common_neighbors = len(set(G.neighbors(u)) & set(G.neighbors(v)))
    try:
        ecc_u = nx.eccentricity(G, u)
        ecc_v = nx.eccentricity(G, v)
        ecc_sum = ecc_u + ecc_v
    except Exception:
        ecc_sum = 0
    try:
        edge_bc = nx.edge_betweenness_centrality(G)
        bc = edge_bc.get((u, v), edge_bc.get((v, u), 0.0))
    except Exception:
        bc = 0.0
    cc_sum = nx.clustering(G, u) + nx.clustering(G, v)
    return {
        "deg_pair": tuple(sorted([deg_u, deg_v])),
        "is_bridge": is_bridge,
        "common_neighbors": common_neighbors,
        "ecc_sum": ecc_sum,
        "edge_betweenness": round(bc, 6),
        "cc_sum": round(cc_sum, 6),
    }


def get_853_connected_graphs():
    """返回 N=7 的 853 个非同构连通图。"""
    atlas = nx.graph_atlas_g()
    return [G for G in atlas
            if G.number_of_nodes() == 7 and nx.is_connected(G)]


def main():
    s_vals = np.linspace(-1.5, 0.0, 11)
    print("=" * 78)
    print("  N=7 异轨道同响应解剖（修正版，853 个非同构连通图）")
    print("=" * 78)
    print(f"  s: [{s_vals[0]}, {s_vals[-1]}], {len(s_vals)} 点")
    print()

    graphs = get_853_connected_graphs()
    print(f"  N=7 非同构连通图总数: {len(graphs)}")
    if len(graphs) != 853:
        print(f"  ⚠ 警告: 预期 853，实际 {len(graphs)}")
    print()

    SX_ops, SY_ops, SZ_ops = build_site_ops(7)

    diff_orbit_same_list = []

    for gid, G in enumerate(graphs):
        edges = [tuple(sorted(e)) for e in G.edges()]
        orbits = find_edge_orbits(G)
        inv_pairs = find_involution_pairs(G)

        curves = {}
        for e in edges:
            curves[e] = compute_sorted_curve(G, e, s_vals,
                                             SX_ops, SY_ops, SZ_ops)

        for i, e1 in enumerate(edges):
            for j in range(i + 1, len(edges)):
                e2 = edges[j]
                if orbits[e1] == orbits[e2]:
                    continue
                same = all(
                    len(a) == len(b) and np.allclose(a, b, atol=1e-10)
                    for a, b in zip(curves[e1], curves[e2])
                )
                if same:
                    is_inv = tuple(sorted([e1, e2])) in inv_pairs
                    diff_orbit_same_list.append({
                        "gid": gid,
                        "e1": list(e1),
                        "e2": list(e2),
                        "is_involution": is_inv,
                        "n_edges": len(edges),
                        "features_e1": edge_features(G, e1),
                        "features_e2": edge_features(G, e2),
                    })

        if (gid + 1) % 50 == 0:
            print(f"    已处理 {gid + 1}/{len(graphs)} 图")

    print()
    print(f"  异轨道同响应总数: {len(diff_orbit_same_list)}")
    inv_count = sum(1 for p in diff_orbit_same_list if p["is_involution"])
    non_inv_count = len(diff_orbit_same_list) - inv_count
    print(f"    是对合像: {inv_count}")
    print(f"    不是对合像: {non_inv_count}")
    print()

    # 特征统计
    print("=" * 78)
    print("  特征统计：异轨道同响应 vs 随机异轨道")
    print("=" * 78)
    print()

    all_diff_orbit = []
    for gid, G in enumerate(graphs):
        edges = [tuple(sorted(e)) for e in G.edges()]
        orbits = find_edge_orbits(G)
        for i, e1 in enumerate(edges):
            for j in range(i + 1, len(edges)):
                e2 = edges[j]
                if orbits[e1] != orbits[e2]:
                    all_diff_orbit.append({
                        "features_e1": edge_features(G, e1),
                        "features_e2": edge_features(G, e2),
                    })

    feature_names = ["deg_pair", "is_bridge", "common_neighbors",
                     "ecc_sum", "edge_betweenness", "cc_sum"]

    print(f"  {'特征':<24}{'异轨道同响应':<16}{'随机异轨道':<16}{'差值':<12}")
    print(f"  {'-'*24}{'-'*16}{'-'*16}{'-'*12}")

    for fname in feature_names:
        same_resp = sum(
            1 for p in diff_orbit_same_list
            if p["features_e1"][fname] == p["features_e2"][fname]
        ) / len(diff_orbit_same_list) if diff_orbit_same_list else 0

        same_rand = sum(
            1 for p in all_diff_orbit
            if p["features_e1"][fname] == p["features_e2"][fname]
        ) / len(all_diff_orbit) if all_diff_orbit else 0

        diff = same_resp - same_rand
        print(f"  {fname:<24}{same_resp:<16.4f}{same_rand:<16.4f}{diff:<12.4f}")

    print()

    # 图号分布
    gid_counter = Counter(p["gid"] for p in diff_orbit_same_list)
    print(f"  涉及图数: {len(gid_counter)}")
    print()
    print(f"  {'图号':<8}{'对数':<8}")
    print(f"  {'-'*8}{'-'*8}")
    for gid, count in gid_counter.most_common(20):
        print(f"  {gid:<8}{count:<8}")
    print()

    output = {
        "total_diff_orbit_same": len(diff_orbit_same_list),
        "involution_match": inv_count,
        "involution_mismatch": non_inv_count,
        "gid_distribution": dict(gid_counter),
    }
    with open("N7异轨道同响应解剖结果_修正版.json", "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2, default=str)
    print(f"已保存: N7异轨道同响应解剖结果_修正版.json")


if __name__ == "__main__":
    main()