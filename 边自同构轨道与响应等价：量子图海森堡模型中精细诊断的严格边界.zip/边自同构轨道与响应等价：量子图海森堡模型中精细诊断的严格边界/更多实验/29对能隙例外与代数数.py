#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
29对能隙例外与代数数：精确代数结构
========================================

核心追问：
- 29 对能隙例外的能隙差是否取精确代数数？
- 有多少对在 s=0 或 s=0.5 处取 −2 或 1−√3？
- 这些对是否都是对合像？

理论精髓：
- 矛盾动力论：能隙例外是矛盾在激发态的残余
- 只查同与不同：不拟合，不预设
- 反对对齐：不预设"能隙差必须是 −2 或 1−√3"
- 严防工具理性悖论：不做代数识别，直接对比已知值

运行：
    python 29对能隙例外与代数数.py
"""

import sys
import io
import json
import itertools
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from networkx.algorithms.isomorphism import GraphMatcher

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)


I2 = np.eye(2, dtype=complex)
SX = np.array([[0, 1], [1, 0]], dtype=complex)
SY = np.array([[0, -1j], [1j, 0]], dtype=complex)
SZ = np.array([[1, 0], [0, -1]], dtype=complex)


def op_on_site(op, site, N):
    ops = [I2] * N
    ops[site] = op
    out = ops[0]
    for o in ops[1:]:
        out = np.kron(out, o)
    return out


def build_site_ops(N):
    return ([op_on_site(SX, i, N) for i in range(N)],
            [op_on_site(SY, i, N) for i in range(N)],
            [op_on_site(SZ, i, N) for i in range(N)])


def edge_matrix(i, j, SX_ops, SY_ops, SZ_ops):
    return SX_ops[i] @ SX_ops[j] + SY_ops[i] @ SY_ops[j] + SZ_ops[i] @ SZ_ops[j]


def ground_state_density(H, tol=1e-8):
    evals, evecs = eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < tol))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    gap = evals[deg] - E0 if deg < len(evals) else 0.0
    return E0, gap, rho, deg


def edge_correlations(rho, edges, SZ_ops):
    C = {}
    for (i, j) in edges:
        op = SZ_ops[i] @ SZ_ops[j]
        C[(i, j)] = float(np.real(np.trace(rho @ op)))
    return C


def compute_sorted_curve_and_gaps(G, defect_edge, s_vals,
                                  SX_ops, SY_ops, SZ_ops):
    N = G.number_of_nodes()
    edges = [tuple(sorted(e)) for e in G.edges()]
    H_edges = {e: edge_matrix(e[0], e[1], SX_ops, SY_ops, SZ_ops) for e in edges}
    H0 = sum(H_edges.values())
    M_defect = H_edges[defect_edge]
    curve = []
    gaps = []
    for s in s_vals:
        H = H0 + (s - 1.0) * M_defect
        E0, gap, rho, deg = ground_state_density(H)
        C = edge_correlations(rho, edges, SZ_ops)
        curve.append(tuple(np.round(sorted(C.values()), 12)))
        gaps.append(float(gap))
    return curve, gaps


def find_involution_pairs(G):
    nodes = list(G.nodes())
    matcher = GraphMatcher(G, G)
    pairs = set()
    for mapping in matcher.isomorphisms_iter():
        if not all(mapping[mapping[u]] == u for u in nodes):
            continue
        if all(mapping[u] == u for u in nodes):
            continue
        for u, v in G.edges():
            e1 = tuple(sorted((u, v)))
            u2, v2 = mapping[u], mapping[v]
            e2 = tuple(sorted((u2, v2)))
            if e1 != e2 and G.has_edge(u2, v2):
                pairs.add(tuple(sorted([e1, e2])))
    return pairs


def find_edge_orbits(G):
    nodes = list(G.nodes())
    edges = [tuple(sorted(e)) for e in G.edges()]
    matcher = GraphMatcher(G, G)
    orbit_id = {e: None for e in edges}
    oid = 0
    for e in edges:
        if orbit_id[e] is not None:
            continue
        orbit_id[e] = oid
        for mapping in matcher.isomorphisms_iter():
            u, v = e
            u2, v2 = mapping[u], mapping[v]
            e2 = tuple(sorted((u2, v2)))
            if G.has_edge(u2, v2):
                orbit_id[e2] = oid
        oid += 1
    return orbit_id


def generate_all_connected_graphs(N):
    all_edges = list(itertools.combinations(range(N), 2))
    graphs = []
    for m in range(N - 1, len(all_edges) + 1):
        for combo in itertools.combinations(all_edges, m):
            G = nx.Graph()
            G.add_nodes_from(range(N))
            G.add_edges_from(combo)
            if nx.is_connected(G):
                graphs.append(G)
    return graphs


def main():
    s_vals = np.linspace(-1.5, 0.5, 21)
    print("=" * 78)
    print("  29 对能隙例外与代数数")
    print("=" * 78)
    print(f"  s: [{s_vals[0]}, {s_vals[-1]}], {len(s_vals)} 点")
    print()

    SX_ops, SY_ops, SZ_ops = build_site_ops(6)
    graphs = generate_all_connected_graphs(6)
    print(f"  N=6 连通图总数: {len(graphs)}")
    print()

    edge_data = []
    for gid, G in enumerate(graphs):
        edges = [tuple(sorted(e)) for e in G.edges()]
        orbits = find_edge_orbits(G)
        for e in edges:
            curve, gaps = compute_sorted_curve_and_gaps(
                G, e, s_vals, SX_ops, SY_ops, SZ_ops)
            edge_data.append({
                "gid": gid, "edge": e, "curve": curve,
                "gaps": gaps, "orbit": orbits[e],
            })
        if (gid + 1) % 20 == 0:
            print(f"    已处理 {gid + 1}/{len(graphs)} 图")

    print()
    n = len(edge_data)
    same_curve_pairs = []
    for i in range(n):
        for j in range(i + 1, n):
            if edge_data[i]["gid"] != edge_data[j]["gid"]:
                continue
            ci = edge_data[i]["curve"]
            cj = edge_data[j]["curve"]
            if len(ci) != len(cj):
                continue
            same = all(
                len(a) == len(b) and np.allclose(a, b, atol=1e-10)
                for a, b in zip(ci, cj)
            )
            if same:
                same_curve_pairs.append((i, j))

    same_orbit_same = []
    diff_orbit_same = []
    for i, j in same_curve_pairs:
        if edge_data[i]["orbit"] == edge_data[j]["orbit"]:
            same_orbit_same.append((i, j))
        else:
            diff_orbit_same.append((i, j))

    print(f"  同轨道同响应: {len(same_orbit_same)}")
    print(f"  异轨道同响应: {len(diff_orbit_same)}")
    print()

    # 关键：29 对能隙例外
    gap_exceptions = []
    for i, j in diff_orbit_same:
        gaps_i = np.array(edge_data[i]["gaps"])
        gaps_j = np.array(edge_data[j]["gaps"])
        diff = gaps_i - gaps_j
        if np.max(np.abs(diff)) > 1e-10:
            gap_exceptions.append((i, j, diff))

    print(f"  能隙例外: {len(gap_exceptions)} 对")
    print()

    target_minus_2 = -2.0
    target_1_sqrt3 = 1 - np.sqrt(3)

    minus_2_count = 0
    one_minus_sqrt3_count = 0
    other_count = 0

    print(f"  {'图号':<6}{'边1':<12}{'边2':<12}"
          f"{'s=0差':<14}{'s=0.5差':<14}{'识别':<12}")
    print(f"  {'-'*6}{'-'*12}{'-'*12}{'-'*14}{'-'*14}{'-'*12}")

    for i, j, diff in gap_exceptions:
        gid = edge_data[i]["gid"]
        e1 = edge_data[i]["edge"]
        e2 = edge_data[j]["edge"]
        idx_0 = np.argmin(np.abs(s_vals - 0.0))
        idx_05 = np.argmin(np.abs(s_vals - 0.5))
        d0 = diff[idx_0]
        d05 = diff[idx_05]

        identified = ""
        if abs(abs(d0) - 2.0) < 1e-6:
            minus_2_count += 1
            identified = "−2"
        elif abs(d05 - target_1_sqrt3) < 1e-6 or abs(d05 + target_1_sqrt3) < 1e-6:
            one_minus_sqrt3_count += 1
            identified = "1−√3"
        else:
            other_count += 1
            identified = "其他"

        print(f"  {gid:<6}{str(e1):<12}{str(e2):<12}"
              f"{d0:<14.8f}{d05:<14.8f}{identified:<12}")

    print()
    print(f"  总结：")
    print(f"    在 s=0 处取 −2 的: {minus_2_count}")
    print(f"    在 s=0.5 处取 1−√3 的: {one_minus_sqrt3_count}")
    print(f"    其他: {other_count}")
    print()

    output = {
        "gap_exceptions": len(gap_exceptions),
        "minus_2_count": minus_2_count,
        "one_minus_sqrt3_count": one_minus_sqrt3_count,
        "other_count": other_count,
    }
    with open("29对能隙例外结果.json", "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2, default=str)
    print("已保存: 29对能隙例外结果.json")


if __name__ == "__main__":
    main()