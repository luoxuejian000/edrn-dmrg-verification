#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 vB.3：收敛检验 + 扫描找根
================================================================
"""

import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq
import json, os

G = 1.0
M = 1.0
R = 1.0


def make_density(profile):
    if profile == "uniform":
        rho0 = M / (4/3 * np.pi * R**3)
        return lambda r: rho0
    elif profile == "quadratic":
        norm = quad(lambda r: 4*np.pi*r**2 * (1 - r**2/R**2), 0, R)[0]
        rho0 = M / norm
        return lambda r: rho0 * (1 - r**2/R**2)
    elif profile == "exponential":
        norm = quad(lambda r: 4*np.pi*r**2 * np.exp(-5*r/R), 0, R)[0]
        rho0 = M / norm
        return lambda r: rho0 * np.exp(-5*r/R)
    else:
        rho0 = M / (4/3 * np.pi * R**3)
        return lambda r: rho0


def internal_gravity(r, rho_func):
    if r < 1e-12:
        return 0.0
    M_r = quad(lambda rp: 4*np.pi*rp**2 * rho_func(rp), 0, r)[0]
    return G * M_r / r**2


def scan_root(f, bracket, n=500):
    """扫描 bracket 内所有符号变化，返回根列表"""
    x_grid = np.linspace(bracket[0], bracket[1], n)
    vals = []
    for x in x_grid:
        try:
            vals.append(f(x))
        except Exception:
            vals.append(np.nan)
    vals = np.array(vals)
    roots = []
    for i in range(len(x_grid) - 1):
        if np.isnan(vals[i]) or np.isnan(vals[i+1]):
            continue
        if vals[i] * vals[i+1] < 0:
            try:
                x_root = brentq(f, x_grid[i], x_grid[i+1], xtol=1e-14)
                roots.append(x_root)
            except Exception:
                pass
    return roots


def local_flattening(omega, profile="uniform"):
    rho_func = make_density(profile)
    
    def equation(f):
        b = R * (1 - f/3)
        a = R * (1 + 2*f/3)
        p_pole, _ = quad(
            lambda r: rho_func(r) * internal_gravity(r, rho_func),
            0, b
        )
        p_eq, _ = quad(
            lambda r: rho_func(r) * (internal_gravity(r, rho_func) - omega**2 * r),
            0, a
        )
        return p_pole - p_eq
    
    roots = scan_root(equation, (0.0, 0.5), n=200)
    return roots


def surface_potential(theta, f, omega, J2_coeff):
    cos_t = np.cos(theta)
    sin_t = np.sin(theta)
    r = R * (1 + f * (1/3 - cos_t**2))
    J2 = J2_coeff * f
    P2 = 0.5 * (3 * cos_t**2 - 1)
    Phi_grav = -G * M / r * (1 - J2 * (R/r)**2 * P2)
    Phi_cent = -0.5 * omega**2 * r**2 * sin_t**2
    return Phi_grav + Phi_cent


def global_flattening(omega, J2_coeff):
    def equation(f):
        return surface_potential(0, f, omega, J2_coeff) - \
               surface_potential(np.pi/2, f, omega, J2_coeff)
    
    roots = scan_root(equation, (0.0, 0.5), n=200)
    if roots:
        return roots[0]
    # fallback
    return (1/(2*J2_coeff)) * omega**2


def main():
    print("=" * 100)
    print("照妖镜 vB.3：收敛检验 + 扫描找根")
    print("=" * 100)
    
    # ---------- Q1: omega 收敛检验 ----------
    print("\n" + "=" * 100)
    print("Q1. omega 收敛检验：看是否收敛到 0.5 / 1.25 / 2.5")
    print("=" * 100)
    
    print(f"\n  {'omega':>10} | {'C_local':>14} | {'C_global':>14} | {'ratio':>12}")
    print(f"  {'-'*10}-+-{'-'*14}-+-{'-'*14}-+-{'-'*12}")
    
    for omega in [0.5, 0.3, 0.1, 0.05, 0.02, 0.01, 0.005, 0.001]:
        q = omega**2
        loc_roots = local_flattening(omega, "uniform")
        f_loc = loc_roots[0] if loc_roots else np.nan
        f_glo = global_flattening(omega, J2_coeff=2/5)
        C_loc = f_loc / q if not np.isnan(f_loc) else np.nan
        C_glo = f_glo / q
        ratio = C_glo / C_loc if not np.isnan(C_loc) and C_loc > 1e-12 else np.nan
        print(f"  {omega:>10.4f} | {C_loc:>14.10f} | {C_glo:>14.10f} | {ratio:>12.8f}")
    
    # ---------- Q2: 密度剖面 ----------
    print("\n" + "=" * 100)
    print("Q2. 密度剖面（omega=0.01，接近极限）")
    print("=" * 100)
    
    omega = 0.01
    q = omega**2
    profiles = ["uniform", "quadratic", "exponential"]
    J2_map = {"uniform": 2/5, "quadratic": 2/5 * 0.8, "exponential": 2/5 * 0.6}
    
    print(f"\n  {'密度剖面':>14} | {'局部 C':>14} | {'全局 C':>14} | {'比值':>10}")
    print(f"  {'-'*14}-+-{'-'*14}-+-{'-'*14}-+-{'-'*10}")
    
    for profile in profiles:
        loc_roots = local_flattening(omega, profile)
        f_loc = loc_roots[0] if loc_roots else np.nan
        C_loc = f_loc / q if not np.isnan(f_loc) else np.nan
        f_glo = global_flattening(omega, J2_coeff=J2_map[profile])
        C_glo = f_glo / q
        ratio = C_glo / C_loc if not np.isnan(C_loc) and C_loc > 1e-12 else np.nan
        print(f"  {profile:>14} | {C_loc:>14.8f} | {C_glo:>14.8f} | {ratio:>10.6f}")
    
    # ---------- Q3: 引力势指数 ----------
    print("\n" + "=" * 100)
    print("Q3. 引力势指数扫描（omega=0.01）")
    print("=" * 100)
    
    print(f"\n  {'n':>4} | {'J2 系数':>12} | {'全局 C':>14} | {'约束因子':>12}")
    print(f"  {'-'*4}-+-{'-'*12}-+-{'-'*14}-+-{'-'*12}")
    
    for n in [1, 2, 3, 4, 5]:
        J2c = 2/(2*n+3)
        f_glo = global_flattening(omega, J2_coeff=J2c)
        C_glo = f_glo / q
        constraint = C_glo / 0.5
        print(f"  {n:>4} | {J2c:>12.8f} | {C_glo:>14.10f} | {constraint:>12.8f}")
    
    # 导出
    out_path = os.path.join(os.path.expanduser("~"), "照妖镜_vB3_收敛.json")
    print(f"\n[完成]")


if __name__ == "__main__":
    main()