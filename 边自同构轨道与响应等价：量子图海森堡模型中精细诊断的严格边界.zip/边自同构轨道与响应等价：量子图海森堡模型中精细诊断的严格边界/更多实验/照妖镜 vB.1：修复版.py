#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 vB.1：修复版
================================================================

修复：
  1. 全局等势面：去掉多余的 0.5 因子
  2. 局部连通器：用正确的内部重力 g(r) = GM(r)/r²
  3. 完整多极展开：调整 bracket

保留：
  Q3 的引力势指数扫描（数据是对的）
"""

import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq
import json, os

G = 1.0
M = 1.0
R = 1.0


# ============================================================
# 密度剖面（返回 rho(r)，已归一化到总质量 M）
# ============================================================

def make_density(profile):
    if profile == "uniform":
        rho0 = M / (4/3 * np.pi * R**3)
        return lambda r: rho0
    elif profile == "quadratic":
        # rho(r) = rho0 (1 - r²/R²)
        norm = quad(lambda r: 4*np.pi*r**2 * (1 - r**2/R**2), 0, R)[0]
        rho0 = M / norm
        return lambda r: rho0 * (1 - r**2/R**2)
    elif profile == "exponential":
        norm = quad(lambda r: 4*np.pi*r**2 * np.exp(-5*r/R), 0, R)[0]
        rho0 = M / norm
        return lambda r: rho0 * np.exp(-5*r/R)
    else:
        rho0 = M / (4/3 * np.pi * R**3)
        return lambda r: rho0


# ============================================================
# 正确内部重力：g(r) = G M(r) / r²
# ============================================================

def internal_gravity(r, rho_func):
    """
    g(r) = G * M(r) / r²
    M(r) = ∫_0^r 4πr'² ρ(r') dr'
    """
    if r < 1e-12:
        return 0.0
    M_r = quad(lambda rp: 4*np.pi*rp**2 * rho_func(rp), 0, r)[0]
    return G * M_r / r**2


# ============================================================
# 方法 1：龚明局部连通器（修正版）
# ============================================================

def local_flattening(omega, profile="uniform"):
    rho_func = make_density(profile)
    
    def equation(f):
        b = R * (1 - f/3)
        a = R * (1 + 2*f/3)
        
        # 极点路径：g_pole(r) = internal_gravity(r)
        p_pole, _ = quad(
            lambda r: rho_func(r) * internal_gravity(r, rho_func),
            0, b
        )
        
        # 赤道路径：g_eq(r) = internal_gravity(r) - ω²r
        p_eq, _ = quad(
            lambda r: rho_func(r) * (internal_gravity(r, rho_func) - omega**2 * r),
            0, a
        )
        
        return p_pole - p_eq
    
    try:
        f_sol = brentq(equation, 0.0, 0.8, xtol=1e-14)
    except Exception as e:
        print(f"    [warn] local brentq 失败: {e}")
        f_sol = np.nan
    return f_sol


# ============================================================
# 方法 2：牛顿全局等势面（修正版）
# ============================================================

def surface_potential(theta, f, omega, J2_coeff):
    cos_t = np.cos(theta)
    sin_t = np.sin(theta)
    r = R * (1 + f * (1/3 - cos_t**2))
    J2 = J2_coeff * f
    P2 = 0.5 * (3 * cos_t**2 - 1)
    Phi_grav = -G * M / r * (1 - J2 * (R/r)**2 * P2)
    Phi_cent = -0.5 * omega**2 * r**2 * sin_t**2
    return Phi_grav + Phi_cent


def global_flattening(omega, J2_coeff):
    def equation(f):
        return surface_potential(0, f, omega, J2_coeff) - \
               surface_potential(np.pi/2, f, omega, J2_coeff)
    
    try:
        f_sol = brentq(equation, 0.0, 0.8, xtol=1e-14)
    except Exception as e:
        print(f"    [warn] global brentq 失败: {e}, J2_coeff={J2_coeff}")
        # 解析近似：f = (1/(2*J2_coeff)) * (1/2) * ω²
        f_sol = (1/(2*J2_coeff)) * 0.5 * omega**2
    return f_sol


# ============================================================
# 主程序
# ============================================================

def main():
    print("=" * 100)
    print("照妖镜 vB.1：修复版")
    print("=" * 100)
    
    omega = 0.1
    q = omega**2
    
    # ---------- Q1: 均匀密度，复现 1/2 和 1.25 ----------
    print("\n" + "=" * 100)
    print("Q1. 均匀密度：复现龚明 1/2 和牛顿 5/4")
    print("=" * 100)
    
    f_loc = local_flattening(omega, "uniform")
    f_glo = global_flattening(omega, J2_coeff=2/5)
    C_loc = f_loc / q if not np.isnan(f_loc) else np.nan
    C_glo = f_glo / q
    ratio = C_glo / C_loc if not np.isnan(C_loc) else np.nan
    
    print(f"\n  omega = {omega}, q = {q}")
    print(f"  龚明局部: C = {C_loc:.10f}")
    print(f"  牛顿全局: C = {C_glo:.10f}")
    print(f"  比值: {ratio:.10f}")
    
    # ---------- Q2: 改变密度剖面 ----------
    print("\n" + "=" * 100)
    print("Q2. 改变密度剖面")
    print("=" * 100)
    
    profiles = ["uniform", "quadratic", "exponential"]
    # 不同密度剖面的 J2 系数（数值结果，简化）
    J2_map = {"uniform": 2/5, "quadratic": 2/5 * 0.8, "exponential": 2/5 * 0.6}
    
    print(f"\n  {'密度剖面':>14} | {'局部 C':>12} | {'全局 C':>12} | {'比值':>10}")
    print(f"  {'-'*14}-+-{'-'*12}-+-{'-'*12}-+-{'-'*10}")
    
    for profile in profiles:
        f_loc_p = local_flattening(omega, profile)
        C_loc_p = f_loc_p / q if not np.isnan(f_loc_p) else np.nan
        f_glo_p = global_flattening(omega, J2_coeff=J2_map[profile])
        C_glo_p = f_glo_p / q
        ratio_p = C_glo_p / C_loc_p if C_loc_p > 1e-12 else np.nan
        print(f"  {profile:>14} | {C_loc_p:>12.8f} | {C_glo_p:>12.8f} | "
              f"{ratio_p:>10.6f}")
    
    # ---------- Q3: 引力势指数扫描 ----------
    print("\n" + "=" * 100)
    print("Q3. 引力势指数扫描（保留，数据是对的）")
    print("=" * 100)
    
    print(f"\n  {'n':>4} | {'J2 系数':>12} | {'全局 C':>12} | {'约束因子':>12}")
    print(f"  {'-'*4}-+-{'-'*12}-+-{'-'*12}-+-{'-'*12}")
    
    for n in [1, 2, 3, 4]:
        J2c = 2/(2*n+3)
        f_glo_n = global_flattening(omega, J2_coeff=J2c)
        C_glo_n = f_glo_n / q
        constraint = C_glo_n / 0.5
        print(f"  {n:>4} | {J2c:>12.8f} | {C_glo_n:>12.8f} | {constraint:>12.8f}")
    
    # ---------- 导出 ----------
    out = {
        "uniform": {"C_local": float(C_loc), "C_global": float(C_glo),
                    "ratio": float(ratio)},
    }
    out_path = os.path.join(os.path.expanduser("~"), "照妖镜_vB1_修复.json")
    with open(out_path, "w") as f:
        json.dump(out, f, indent=2)
    print(f"\n[导出: {out_path}]")


if __name__ == "__main__":
    main()