#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
遗留问题统一测试：只测 112 个连通图
========================================

测试五个遗留问题：
1. N=6 上对合像是否都在同轨道内？（解释对合匹配为 0）
2. 32 对异轨道同响应的共同结构是什么？
3. 31 对能隙例外的完整代数识别
4. 同轨道必同响应在四种相互作用下的零反例确认
5. 32 对是否由某种非对合的对称性产生？

运行：
    python 遗留问题统一测试.py
"""

import sys
import io
import json
import itertools
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from collections import defaultdict, Counter

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)


I2 = np.eye(2, dtype=complex)
SX = np.array([[0, 1], [1, 0]], dtype=complex)
SY = np.array([[0, -1j], [1j, 0]], dtype=complex)
SZ = np.array([[1, 0], [0, -1]], dtype=complex)


def op_on_site(op, site, N):
    ops = [I2] * N
    ops[site] = op
    out = ops[0]
    for o in ops[1:]:
        out = np.kron(out, o)
    return out


def build_site_ops(N):
    return ([op_on_site(SX, i, N) for i in range(N)],
            [op_on_site(SY, i, N) for i in range(N)],
            [op_on_site(SZ, i, N) for i in range(N)])


def edge_matrix(i, j, SX_ops, SY_ops, SZ_ops, rule="heisenberg", delta=1.0):
    if rule == "heisenberg":
        return SX_ops[i] @ SX_ops[j] + SY_ops[i] @ SY_ops[j] + SZ_ops[i] @ SZ_ops[j]
    elif rule == "xxz":
        return SX_ops[i] @ SX_ops[j] + SY_ops[i] @ SY_ops[j] + delta * (SZ_ops[i] @ SZ_ops[j])
    elif rule == "ising":
        return SZ_ops[i] @ SZ_ops[j]
    elif rule == "xy":
        return SX_ops[i] @ SX_ops[j] + SY_ops[i] @ SY_ops[j]
    raise ValueError(f"未知规则: {rule}")


def ground_state_density(H, tol=1e-8):
    evals, evecs = eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < tol))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    gap = evals[deg] - E0 if deg < len(evals) else 0.0
    return E0, gap, rho, deg


def edge_correlations(rho, edges, SZ_ops):
    C = {}
    for (i, j) in edges:
        op = SZ_ops[i] @ SZ_ops[j]
        C[(i, j)] = float(np.real(np.trace(rho @ op)))
    return C


def compute_sorted_curve_and_gaps(G, defect_edge, s_vals,
                                  SX_ops, SY_ops, SZ_ops,
                                  rule="heisenberg", delta=1.0):
    N = G.number_of_nodes()
    edges = [tuple(sorted(e)) for e in G.edges()]
    H_edges = {e: edge_matrix(e[0], e[1], SX_ops, SY_ops, SZ_ops, rule, delta)
               for e in edges}
    H0 = sum(H_edges.values())
    M_defect = H_edges[defect_edge]
    curve = []
    gaps = []
    for s in s_vals:
        H = H0 + (s - 1.0) * M_defect
        E0, gap, rho, deg = ground_state_density(H)
        C = edge_correlations(rho, edges, SZ_ops)
        curve.append(tuple(np.round(sorted(C.values()), 12)))
        gaps.append(float(gap))
    return curve, gaps


def find_automorphisms(G):
    nodes = list(G.nodes())
    adj = nx.to_numpy_array(G)
    perms = []
    for p in itertools.permutations(nodes):
        P = np.zeros((len(nodes), len(nodes)))
        for i, pi in enumerate(p):
            P[i, pi] = 1
        if np.allclose(P @ adj @ P.T, adj):
            perms.append(p)
    return perms


def find_edge_orbits(G):
    nodes = list(G.nodes())
    edges = [tuple(sorted(e)) for e in G.edges()]
    perms = find_automorphisms(G)
    orbit_id = {e: None for e in edges}
    oid = 0
    for e in edges:
        if orbit_id[e] is not None:
            continue
        orbit_id[e] = oid
        for p in perms:
            mapping = {nodes[i]: p[i] for i in range(len(nodes))}
            e2 = tuple(sorted((mapping[e[0]], mapping[e[1]])))
            if G.has_edge(*e2):
                orbit_id[e2] = oid
        oid += 1
    return orbit_id


def find_involution_pairs(G):
    nodes = list(G.nodes())
    edges = [tuple(sorted(e)) for e in G.edges()]
    perms = find_automorphisms(G)
    pairs = set()
    for p in perms:
        if not all(p[p[i]] == i for i in range(len(p))):
            continue
        if all(p[i] == i for i in range(len(p))):
            continue
        mapping = {i: p[i] for i in range(len(p))}
        for e in edges:
            e2 = tuple(sorted((mapping[e[0]], mapping[e[1]])))
            if e2 != e and G.has_edge(*e2):
                pairs.add(tuple(sorted([e, e2])))
    return pairs


def identify_algebraic(x, tol=1e-6, max_denom=100, max_coef=30):
    """识别 x 是否为低次代数数。"""
    for q in range(1, max_denom + 1):
        p = round(x * q)
        if abs(x - p / q) < tol:
            return f"{p}/{q}"
    for c in range(2, max_coef + 1):
        sqrt_c = np.sqrt(c)
        for a in range(-max_coef, max_coef + 1):
            for b in range(-max_coef, max_coef + 1):
                if b == 0:
                    continue
                if abs(x - (a + b * sqrt_c)) < tol:
                    return f"{a}+{b}√{c}"
    return "未识别"


def edge_features(G, edge):
    u, v = edge
    deg_u = G.degree(u)
    deg_v = G.degree(v)
    H = G.copy()
    H.remove_edge(u, v)
    is_bridge = not nx.is_connected(H)
    common_neighbors = len(set(G.neighbors(u)) & set(G.neighbors(v)))
    neighbors_u = [G.degree(w) for w in G.neighbors(u) if w != v]
    neighbors_v = [G.degree(w) for w in G.neighbors(v) if w != u]
    neighbor_deg_seq = tuple(sorted(neighbors_u + neighbors_v))
    try:
        ecc_u = nx.eccentricity(G, u)
        ecc_v = nx.eccentricity(G, v)
        ecc_sum = ecc_u + ecc_v
    except Exception:
        ecc_sum = 0
    try:
        edge_bc = nx.edge_betweenness_centrality(G)
        bc = edge_bc.get((u, v), edge_bc.get((v, u), 0.0))
    except Exception:
        bc = 0.0
    cc_sum = nx.clustering(G, u) + nx.clustering(G, v)
    return {
        "deg_pair": tuple(sorted([deg_u, deg_v])),
        "is_bridge": is_bridge,
        "common_neighbors": common_neighbors,
        "neighbor_deg_seq": neighbor_deg_seq,
        "ecc_sum": ecc_sum,
        "edge_betweenness": round(bc, 6),
        "cc_sum": round(cc_sum, 6),
    }


def get_112_connected_graphs():
    atlas = nx.graph_atlas_g()
    return [G for G in atlas
            if G.number_of_nodes() == 6 and nx.is_connected(G)]


def main():
    s_vals = np.linspace(-1.5, 0.5, 21)
    print("=" * 78)
    print("  遗留问题统一测试：112 个连通图")
    print("=" * 78)
    print(f"  s: [{s_vals[0]}, {s_vals[-1]}], {len(s_vals)} 点")
    print()

    graphs = get_112_connected_graphs()
    print(f"  N=6 连通图总数: {len(graphs)}")
    print()

    SX_ops, SY_ops, SZ_ops = build_site_ops(6)

    # ============================================================
    # 遗留问题 1：N=6 上对合像是否都在同轨道内？
    # ============================================================
    print("=" * 78)
    print("  遗留问题 1：对合像是否都在同轨道内？")
    print("=" * 78)
    print()

    total_involution_pairs = 0
    inv_same_orbit = 0
    inv_diff_orbit = 0
    inv_diff_orbit_examples = []

    for gid, G in enumerate(graphs):
        inv_pairs = find_involution_pairs(G)
        orbits = find_edge_orbits(G)
        for e1, e2 in inv_pairs:
            total_involution_pairs += 1
            if orbits[e1] == orbits[e2]:
                inv_same_orbit += 1
            else:
                inv_diff_orbit += 1
                inv_diff_orbit_examples.append({
                    "gid": gid, "e1": list(e1), "e2": list(e2),
                })

    print(f"  对合像总数: {total_involution_pairs}")
    print(f"  其中同轨道: {inv_same_orbit}")
    print(f"  其中异轨道: {inv_diff_orbit}")
    print()
    if inv_diff_orbit > 0:
        print(f"  异轨道对合像示例（前 10）：")
        for ex in inv_diff_orbit_examples[:10]:
            print(f"    图 {ex['gid']}: {ex['e1']} vs {ex['e2']}")
    print()

    # ============================================================
    # 遗留问题 2 & 3：32 对异轨道同响应 + 能隙例外代数识别
    # ============================================================
    print("=" * 78)
    print("  遗留问题 2 & 3：32 对异轨道同响应 + 能隙例外代数识别")
    print("=" * 78)
    print()

    edge_data = []
    for gid, G in enumerate(graphs):
        edges = [tuple(sorted(e)) for e in G.edges()]
        orbits = find_edge_orbits(G)
        for e in edges:
            curve, gaps = compute_sorted_curve_and_gaps(
                G, e, s_vals, SX_ops, SY_ops, SZ_ops)
            ef = edge_features(G, e)
            edge_data.append({
                "gid": gid, "edge": e, "curve": curve, "gaps": gaps,
                "orbit": orbits[e], "features": ef,
            })
        if (gid + 1) % 20 == 0:
            print(f"    已处理 {gid + 1}/{len(graphs)} 图")

    print()

    n = len(edge_data)
    same_curve_pairs = []
    for i in range(n):
        for j in range(i + 1, n):
            if edge_data[i]["gid"] != edge_data[j]["gid"]:
                continue
            ci = edge_data[i]["curve"]
            cj = edge_data[j]["curve"]
            if len(ci) != len(cj):
                continue
            same = all(
                len(a) == len(b) and np.allclose(a, b, atol=1e-10)
                for a, b in zip(ci, cj)
            )
            if same:
                same_curve_pairs.append((i, j))

    diff_orbit_same = []
    for i, j in same_curve_pairs:
        if edge_data[i]["orbit"] != edge_data[j]["orbit"]:
            diff_orbit_same.append((i, j))

    print(f"  异轨道同响应: {len(diff_orbit_same)} 对")
    print()

    # 能隙例外与代数识别
    gap_exceptions = []
    for i, j in diff_orbit_same:
        gaps_i = np.array(edge_data[i]["gaps"])
        gaps_j = np.array(edge_data[j]["gaps"])
        diff = gaps_i - gaps_j
        if np.max(np.abs(diff)) > 1e-10:
            gap_exceptions.append((i, j, diff))

    print(f"  能隙例外: {len(gap_exceptions)} 对")
    print()

    print(f"  {'图号':<6}{'边1':<12}{'边2':<12}{'s=0差':<14}{'s=0.5差':<14}"
          f"{'识别(s=0)':<16}{'识别(s=0.5)':<16}")
    print(f"  {'-'*6}{'-'*12}{'-'*12}{'-'*14}{'-'*14}{'-'*16}{'-'*16}")

    algebraic_types = Counter()

    for i, j, diff in gap_exceptions:
        gid = edge_data[i]["gid"]
        e1 = edge_data[i]["edge"]
        e2 = edge_data[j]["edge"]
        idx_0 = np.argmin(np.abs(s_vals - 0.0))
        idx_05 = np.argmin(np.abs(s_vals - 0.5))
        d0 = diff[idx_0]
        d05 = diff[idx_05]

        id_0 = identify_algebraic(d0)
        id_05 = identify_algebraic(d05)
        algebraic_types[id_0] += 1
        algebraic_types[id_05] += 1

        print(f"  {gid:<6}{str(e1):<12}{str(e2):<12}"
              f"{d0:<14.8f}{d05:<14.8f}{id_0:<16}{id_05:<16}")

    print()
    print(f"  代数识别统计（s=0 和 s=0.5 合并）：")
    for val, count in algebraic_types.most_common():
        print(f"    {val}: {count}")

    # ============================================================
    # 遗留问题 4：同轨道必同响应在四种相互作用下
    # ============================================================
    print()
    print("=" * 78)
    print("  遗留问题 4：同轨道必同响应在四种相互作用下")
    print("=" * 78)
    print()

    for rule in ["heisenberg", "xxz", "ising", "xy"]:
        same_orbit_diff_count = 0
        same_orbit_same_count = 0

        for gid, G in enumerate(graphs):
            edges = [tuple(sorted(e)) for e in G.edges()]
            orbits = find_edge_orbits(G)
            curves = {}
            for e in edges:
                curve, _ = compute_sorted_curve_and_gaps(
                    G, e, s_vals, SX_ops, SY_ops, SZ_ops,
                    rule=rule, delta=1.0)
                curves[e] = curve

            for i, e1 in enumerate(edges):
                for j in range(i + 1, len(edges)):
                    e2 = edges[j]
                    if orbits[e1] != orbits[e2]:
                        continue
                    same = all(
                        len(a) == len(b) and np.allclose(a, b, atol=1e-10)
                        for a, b in zip(curves[e1], curves[e2])
                    )
                    if same:
                        same_orbit_same_count += 1
                    else:
                        same_orbit_diff_count += 1

        print(f"  {rule:<14} 同轨道同曲线: {same_orbit_same_count:<6}"
              f" 同轨道异曲线: {same_orbit_diff_count:<6}"
              f" → {'零反例 ✓' if same_orbit_diff_count == 0 else '有反例 ✗'}")

    # ============================================================
    # 遗留问题 5：32 对是否由对合像产生？
    # ============================================================
    print()
    print("=" * 78)
    print("  遗留问题 5：32 对是否由对合像产生？")
    print("=" * 78)
    print()

    # 收集所有对合像（与轨道无关）
    all_involution_pairs = {}
    for gid, G in enumerate(graphs):
        inv_pairs = find_involution_pairs(G)
        for e1, e2 in inv_pairs:
            all_involution_pairs[(gid, tuple(sorted([e1, e2])))] = True

    involution_match = 0
    involution_mismatch = 0
    for i, j in diff_orbit_same:
        gid = edge_data[i]["gid"]
        e1 = edge_data[i]["edge"]
        e2 = edge_data[j]["edge"]
        key = (gid, tuple(sorted([e1, e2])))
        if key in all_involution_pairs:
            involution_match += 1
        else:
            involution_mismatch += 1

    print(f"  32 对异轨道同响应中：")
    print(f"    是对合像: {involution_match}")
    print(f"    不是对合像: {involution_mismatch}")
    print()

    if involution_mismatch > 0:
        print("  不是对合像的示例（前 10）：")
        cnt = 0
        for i, j in diff_orbit_same:
            gid = edge_data[i]["gid"]
            e1 = edge_data[i]["edge"]
            e2 = edge_data[j]["edge"]
            key = (gid, tuple(sorted([e1, e2])))
            if key not in all_involution_pairs:
                print(f"    图 {gid}: {e1} vs {e2}")
                cnt += 1
                if cnt >= 10:
                    break

    # ============================================================
    # 保存
    # ============================================================
    output = {
        "involution_total": total_involution_pairs,
        "involution_same_orbit": inv_same_orbit,
        "involution_diff_orbit": inv_diff_orbit,
        "diff_orbit_same_count": len(diff_orbit_same),
        "gap_exceptions": len(gap_exceptions),
        "algebraic_types": dict(algebraic_types),
        "involution_match": involution_match,
        "involution_mismatch": involution_mismatch,
    }
    with open("遗留问题统一测试结果.json", "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2, default=str)
    print()
    print("已保存: 遗留问题统一测试结果.json")


if __name__ == "__main__":
    main()