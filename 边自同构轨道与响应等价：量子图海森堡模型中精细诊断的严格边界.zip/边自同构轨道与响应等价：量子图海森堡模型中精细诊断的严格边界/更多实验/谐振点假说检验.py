#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
谐振点假说检验
================

假说：异轨道同响应由"整体混合状态落在某个谐振点"决定。
     不是各维度对齐，是整体状态落在某个吸引子上。

检验方法：
  1. 定义"整体状态空间"——图的关联矩阵的整体谱特征
  2. 对每对边，计算其整体状态向量（不依赖于该对的特征，是图+缺陷边的整体状态）
  3. 看同响应对在整体状态空间里是否聚集
  4. 如果聚集，找聚集中心——那就是谐振点
  5. 比较硬核/中环/外壳/异响应在整体状态空间里的位置
"""

import sys, io, itertools, json, os
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from collections import Counter, defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"
N = 6
TOL = 1e-10

I2 = np.eye(2, dtype=complex)
SX = np.array([[0,1],[1,0]], dtype=complex)
SY = np.array([[0,-1j],[1j,0]], dtype=complex)
SZ = np.array([[1,0],[0,-1]], dtype=complex)


def op_on_site(op, site, N):
    ops = [I2]*N; ops[site] = op
    out = ops[0]
    for o in ops[1:]: out = np.kron(out, o)
    return out


def build_site_ops(N):
    return ([op_on_site(SX,i,N) for i in range(N)],
            [op_on_site(SY,i,N) for i in range(N)],
            [op_on_site(SZ,i,N) for i in range(N)])


def edge_matrix(i, j, SXo, SYo, SZo):
    return SXo[i]@SXo[j] + SYo[i]@SYo[j] + SZo[i]@SZo[j]


def gs_rho(H, tol=1e-8):
    evals, evecs = eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < tol))
    V = evecs[:, :deg]
    return V @ V.conj().T / deg


def find_automorphisms(G):
    nodes = list(G.nodes())
    adj = nx.to_numpy_array(G)
    perms = []
    for p in itertools.permutations(nodes):
        P = np.zeros((len(nodes), len(nodes)))
        for i, pi in enumerate(p): P[i, pi] = 1
        if np.allclose(P @ adj @ P.T, adj): perms.append(p)
    return perms


def find_edge_orbits(G):
    nodes = list(G.nodes())
    edges = [tuple(sorted(e)) for e in G.edges()]
    perms = find_automorphisms(G)
    orbit_id = {e: None for e in edges}
    oid = 0
    for e in edges:
        if orbit_id[e] is not None: continue
        orbit_id[e] = oid
        for p in perms:
            m = {nodes[i]: p[i] for i in range(len(nodes))}
            e2 = tuple(sorted((m[e[0]], m[e[1]])))
            if G.has_edge(*e2): orbit_id[e2] = oid
        oid += 1
    return orbit_id


# ============================================================
# 整体状态特征
# ============================================================

def overall_state_features(G, defect_edge, SXo, SYo, SZo, s_val=0.5):
    """
    计算一个"整体状态向量"。
    不是针对某一对边，是针对 (图, 缺陷边) 这个整体。
    """
    edges = [tuple(sorted(e)) for e in G.edges()]
    H_edges = [edge_matrix(e[0], e[1], SXo, SYo, SZo) for e in edges]
    couplings = [s_val if e == defect_edge else 1.0 for e in edges]
    H = sum(c*M for c, M in zip(couplings, H_edges))
    rho = gs_rho(H)

    # 关联函数向量（所有边）
    SZo_pairs = [(SZo[e[0]], SZo[e[1]]) for e in edges]
    corr = np.array([float(np.real(np.trace(rho @ (Za @ Zb))))
                     for Za, Zb in SZo_pairs])

    # 整体状态特征
    feats = {}

    # 1. 关联分布的统计量
    feats["corr_mean"] = float(np.mean(corr))
    feats["corr_std"] = float(np.std(corr))
    feats["corr_range"] = float(np.max(corr) - np.min(corr))
    feats["corr_skew"] = float(((corr - corr.mean())**3).mean() / (corr.std()**3 + 1e-12))
    feats["corr_kurt"] = float(((corr - corr.mean())**4).mean() / (corr.std()**4 + 1e-12))

    # 2. 归一化熵
    r = corr - corr.min()
    if r.max() > 1e-12:
        r = r / r.max()
        p = r / r.sum()
        p = p[p > 1e-12]
        feats["corr_entropy"] = float(-np.sum(p * np.log(p)))
    else:
        feats["corr_entropy"] = 0.0

    # 3. 关联矩阵的谱（外积矩阵的谱）
    corr_matrix = np.outer(corr, corr)
    evals = np.linalg.eigvalsh(corr_matrix)
    evals_pos = evals[evals > 1e-10]
    feats["corr_spectral_radius"] = float(np.max(np.abs(evals)))
    if len(evals_pos) > 0:
        p = evals_pos / evals_pos.sum()
        feats["corr_spectral_entropy"] = float(-np.sum(p * np.log(p)))
    else:
        feats["corr_spectral_entropy"] = 0.0

    # 4. 缺陷边的关联函数值（它自己在整体状态中的位置）
    idx_defect = edges.index(defect_edge)
    feats["defect_corr"] = float(corr[idx_defect])
    feats["defect_rank"] = float(np.sum(corr < corr[idx_defect])) / len(corr)

    # 5. 图的全局特征
    feats["graph_n_edges"] = len(edges)
    feats["graph_n_nodes"] = G.number_of_nodes()

    return feats


def relation_features(G, e1, e2, orbits):
    """关系特征，用于对照"""
    n1a, n1b = e1; n2a, n2b = e2
    orbit_size = Counter(orbits.values())
    return {
        "orbit_size_sym": orbit_size[orbits[e1]] == orbit_size[orbits[e2]],
    }


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 100)
    print("谐振点假说检验")
    print("异轨道同响应 = 整体混合状态落在某个谐振点")
    print("=" * 100)

    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    print(f"\n  图集: {len(graphs)} 个 N=6 连通图")

    all_orbits = {gid: find_edge_orbits(G) for gid, G in enumerate(graphs)}
    SXo, SYo, SZo = build_site_ops(N)

    # 加载 v5.1 的模式数据
    patterns_file = os.path.join(WORK_DIR, "照妖镜_v5_1_模式.json")
    with open(patterns_file, "r", encoding="utf-8") as f:
        v51 = json.load(f)

    patterns = {}
    for key, s in v51["patterns"].items():
        gid, e1_str, e2_str = key.split("_", 2)
        gid = int(gid)
        e1 = tuple(map(int, e1_str.strip("()").split(",")))
        e2 = tuple(map(int, e2_str.strip("()").split(",")))
        patterns[(gid, e1, e2)] = s

    # 硬核/中环/外壳分类
    hard_core_keys = set()
    middle_keys = set()
    outer_keys = set()
    for key, s in patterns.items():
        n_true = s.count("1")
        if n_true == 24:
            hard_core_keys.add(key)
        elif n_true > 1:
            middle_keys.add(key)
        elif n_true == 1:
            outer_keys.add(key)

    # 对每对边，计算整体状态特征
    print(f"\n  计算每对的整体状态特征（s=0.5）…")
    pair_data = []
    for gid, G in enumerate(graphs):
        edges = [tuple(sorted(e)) for e in G.edges()]
        orbits = all_orbits[gid]
        # 缓存 (图, 缺陷边) 的整体特征
        defect_features = {}
        for defect in edges:
            defect_features[defect] = overall_state_features(
                G, defect, SXo, SYo, SZo, s_val=0.5)

        for i, e1 in enumerate(edges):
            for j in range(i+1, len(edges)):
                e2 = edges[j]
                if orbits[e1] == orbits[e2]: continue
                key = (gid, e1, e2)
                f1 = defect_features[e1]
                f2 = defect_features[e2]
                # 整体状态差异向量
                diff = {k: abs(f1[k] - f2[k]) for k in f1.keys()}
                pair_data.append({
                    "key": key,
                    "f1": f1, "f2": f2, "diff": diff,
                    "pattern": patterns.get(key, "0"*24),
                    "is_hard_core": key in hard_core_keys,
                    "is_middle": key in middle_keys,
                    "is_outer": key in outer_keys,
                    "is_same_response": key in patterns,
                })

    print(f"  完成 {len(pair_data)} 对")

    # ============================================================
    # 检验 1：同响应 vs 异响应在整体状态差异上的分布
    # ============================================================
    print("\n" + "=" * 100)
    print("检验 1：同响应 vs 异响应在整体状态差异上的分布")
    print("=" * 100)

    same = [r for r in pair_data if r["is_same_response"]]
    diff = [r for r in pair_data if not r["is_same_response"]]
    print(f"\n  同响应: {len(same)}, 异响应: {len(diff)}")

    # 对每个整体状态特征，比较同响应和异响应的差异
    feature_names = ["corr_mean", "corr_std", "corr_range", "corr_skew",
                     "corr_kurt", "corr_entropy", "corr_spectral_radius",
                     "corr_spectral_entropy", "defect_corr", "defect_rank"]

    print(f"\n  {'特征':>22} | {'同响应均差':>10} | {'异响应均差':>10} | {'比值':>8}")
    print(f"  {'-'*22}-+-{'-'*10}-+-{'-'*10}-+-{'-'*8}")
    for fname in feature_names:
        s_vals = [r["diff"][fname] for r in same]
        d_vals = [r["diff"][fname] for r in diff]
        s_mean = np.mean(s_vals) if s_vals else 0
        d_mean = np.mean(d_vals) if d_vals else 0
        ratio = s_mean / d_mean if d_mean > 1e-12 else float('inf')
        print(f"  {fname:>22} | {s_mean:>10.4f} | {d_mean:>10.4f} | {ratio:>8.3f}")

    # ============================================================
    # 检验 2：在整体状态空间里找谐振点
    # ============================================================
    print("\n" + "=" * 100)
    print("检验 2：在整体状态空间里找谐振点")
    print("=" * 100)

    # 用一个简单的整体状态坐标：
    # x = defect_corr（缺陷边的关联函数值）
    # y = corr_std（整体关联分布的标准差）
    # 看同响应是否在这些坐标上聚集

    print(f"\n  --- 整体状态坐标 (defect_corr, corr_std) 的分布 ---")
    print(f"\n  {'组':>8} | {'defect_corr 均值':>16} | {'corr_std 均值':>14} | {'对数':>5}")
    print(f"  {'-'*8}-+-{'-'*16}-+-{'-'*14}-+-{'-'*5}")

    groups = {
        "硬核": [r for r in pair_data if r["is_hard_core"]],
        "中环": [r for r in pair_data if r["is_middle"]],
        "外壳": [r for r in pair_data if r["is_outer"]],
        "异响应": [r for r in pair_data if not r["is_same_response"]],
    }
    for gname, group in groups.items():
        if not group: continue
        dc = [r["f1"]["defect_corr"] for r in group] + \
             [r["f2"]["defect_corr"] for r in group]
        cs = [r["f1"]["corr_std"] for r in group] + \
             [r["f2"]["corr_std"] for r in group]
        print(f"  {gname:>8} | {np.mean(dc):>16.6f} | {np.mean(cs):>14.6f} | {len(group):>5}")

    # ============================================================
    # 检验 3：中环和外壳的谐振点在哪
    # ============================================================
    print("\n" + "=" * 100)
    print("检验 3：中环和外壳的谐振点在哪")
    print("=" * 100)

    # 对中环和外壳，列出每对的整体状态坐标
    for gname, group in [("中环", groups["中环"]), ("外壳", groups["外壳"])]:
        print(f"\n  --- {gname} ({len(group)} 对) ---")
        print(f"  {'gid':>4} | {'e1':>8} | {'e2':>8} | {'defect_corr_1':>14} | {'defect_corr_2':>14} | {'corr_std_1':>10} | {'corr_std_2':>10}")
        print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*8}-+-{'-'*14}-+-{'-'*14}-+-{'-'*10}-+-{'-'*10}")
        for r in group[:30]:
            gid, e1, e2 = r["key"]
            print(f"  {gid:>4} | {str(e1):>8} | {str(e2):>8} | "
                  f"{r['f1']['defect_corr']:>14.6f} | {r['f2']['defect_corr']:>14.6f} | "
                  f"{r['f1']['corr_std']:>10.4f} | {r['f2']['corr_std']:>10.4f}")

    # ============================================================
    # 检验 4：整体状态差异是否比关系特征差异更能预测同响应
    # ============================================================
    print("\n" + "=" * 100)
    print("检验 4：整体状态差异的预测能力")
    print("=" * 100)

    # 用整体状态差异（defect_corr 差 + corr_std 差）作为分数
    # 看同响应是否在这个分数上聚集

    for r in pair_data:
        r["overall_diff_score"] = (r["diff"]["defect_corr"] +
                                    r["diff"]["corr_std"] +
                                    r["diff"]["corr_spectral_radius"])

    same_scores = [r["overall_diff_score"] for r in same]
    diff_scores = [r["overall_diff_score"] for r in diff]

    print(f"\n  同响应整体差异分数: mean={np.mean(same_scores):.6f}, "
          f"std={np.std(same_scores):.6f}")
    print(f"  异响应整体差异分数: mean={np.mean(diff_scores):.6f}, "
          f"std={np.std(diff_scores):.6f}")

    # 看同响应对是否聚集在某个分数区间
    print(f"\n  分数分布（同响应占比）:")
    print(f"  {'分数区间':>15} | {'同响应':>6} | {'总对数':>6} | {'占比':>6}")
    print(f"  {'-'*15}-+-{'-'*6}-+-{'-'*6}-+-{'-'*6}")
    all_scores = same_scores + diff_scores
    if all_scores:
        smin, smax = min(all_scores), max(all_scores)
        n_bins = 10
        for i in range(n_bins):
            lo = smin + (smax - smin) * i / n_bins
            hi = smin + (smax - smin) * (i + 1) / n_bins
            n_same = sum(1 for s in same_scores if lo <= s < hi)
            n_diff = sum(1 for s in diff_scores if lo <= s < hi)
            n_total = n_same + n_diff
            ratio = n_same / n_total if n_total > 0 else 0
            bar = "█" * int(ratio * 20)
            print(f"  [{lo:>6.4f},{hi:>6.4f}] | {n_same:>6} | {n_total:>6} | {ratio:>5.1%} {bar}")

    # ============================================================
    # 导出
    # ============================================================
    out = {
        "n_same": len(same),
        "n_diff": len(diff),
        "groups": {
            "hard_core": [{"key": list(r["key"]),
                           "defect_corr_1": r["f1"]["defect_corr"],
                           "defect_corr_2": r["f2"]["defect_corr"],
                           "corr_std_1": r["f1"]["corr_std"],
                           "corr_std_2": r["f2"]["corr_std"]}
                          for r in groups["硬核"]],
            "middle": [{"key": list(r["key"]),
                        "defect_corr_1": r["f1"]["defect_corr"],
                        "defect_corr_2": r["f2"]["defect_corr"],
                        "corr_std_1": r["f1"]["corr_std"],
                        "corr_std_2": r["f2"]["corr_std"]}
                       for r in groups["中环"]],
            "outer": [{"key": list(r["key"]),
                       "defect_corr_1": r["f1"]["defect_corr"],
                       "defect_corr_2": r["f2"]["defect_corr"],
                       "corr_std_1": r["f1"]["corr_std"],
                       "corr_std_2": r["f2"]["corr_std"]}
                      for r in groups["外壳"]],
        },
    }
    out_path = os.path.join(WORK_DIR, "谐振点假说检验结果.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("谐振点假说检验完成。")
    print("=" * 100)


if __name__ == "__main__":
    main()