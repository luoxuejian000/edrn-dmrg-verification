# -*- coding: utf-8 -*-
"""
================================================================================
照妖镜协议 v1.0
32对异轨道同响应的穷举关系特征攻击

晶脉哲学立场：
  1. 关系本体论：不看节点，只看关系。边不是"两个点之间的线"，
     而是关系网络中的一个位置。
  2. 对象化=截断=产生方向：每一次计算都是一次截断。
     我们承认这一点，并在每一步标注截断的位置。
  3. 只查同与不同：不拟合，不回归，不预设"正确"答案。
  4. 反对对齐：不使用任何"目标函数"来引导搜索。
  5. 严防工具理性悖论：不用技术手段解决技术逻辑造成的问题。
     脚本只是对象化工具，追问才是行动。

方法论：
  - 一次并行计算所有关系特征，不单线作战。
  - 结果并排放置，不一个一个找。
  - 每个特征追问"为什么"。
  - 不筛选，不排名，不省略。
================================================================================
"""

import os
import json
import itertools
import warnings
from collections import defaultdict, Counter
from fractions import Fraction
from itertools import combinations, product

import numpy as np
import networkx as nx

warnings.filterwarnings('ignore')

# ==============================================================================
# 第0部分：基础设置
# ==============================================================================

TOL = 1e-10
S_GRID = np.linspace(-3, 3, 61)   # 与主扫描一致
N_NODES = 6                        # 当前锁定 N=6
WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"

# 晶脉哲学：只查同与不同
def same(a, b, tol=TOL):
    """只判断同或不同。不判断对错，不判断重要性。"""
    try:
        return abs(float(a) - float(b)) < tol
    except (TypeError, ValueError):
        return a == b

def fmt(x, nd=10):
    """统一格式化，方便并排看"""
    if isinstance(x, (bool, np.bool_)):
        return "True" if x else "False"
    if isinstance(x, (int, np.integer)):
        return str(int(x))
    if isinstance(x, float) or isinstance(x, np.floating):
        if np.isnan(x):
            return "nan"
        if abs(x) < 1e-14:
            return "0"
        return f"{x:.{nd}f}"
    return str(x)

# ==============================================================================
# 第1部分：加载 32 对
# ==============================================================================

def load_json_safe(path):
    if os.path.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"  [warn] 无法解析 {path}: {e}")
    return None

def load_32_pairs():
    """
    尝试从已有 JSON 加载 32 对。如果找不到，暴力重建。
    返回: list of dict {graph_id, edges, edge1, edge2}
    """
    candidates = [
        "32对假阴性解剖结果.json",
        "32对特征解剖_连通图结果.json",
        "32对特征解剖结果.json",
        "遗留问题统一测试结果.json",
    ]
    for name in candidates:
        path = os.path.join(WORK_DIR, name)
        data = load_json_safe(path)
        if data is None:
            continue
        # 尝试多种键名
        for key in ("pairs", "32_pairs", "假阴性对", "results"):
            if isinstance(data, dict) and key in data:
                data = data[key]
                break
        if isinstance(data, list) and len(data) > 0:
            out = []
            for item in data:
                if isinstance(item, dict):
                    out.append(item)
            if out:
                print(f"  [ok] 从 {name} 加载 {len(out)} 对")
                return out
    print("  [info] 未找到 32 对 JSON，启动暴力重建…")
    return rebuild_32_pairs()

def rebuild_32_pairs():
    """
    暴力重建：扫描 N=6 全部 112 个连通图，
    对每个图的每一对边，计算 E(s) 曲线，找出异轨道同曲线对。
    """
    graphs = build_all_N6_graphs()
    print(f"  [ok] 构建 {len(graphs)} 个 N=6 连通图")
    pairs = []
    for gid, G in enumerate(graphs):
        edges = sorted(G.edges())
        orbits = edge_orbits(G, edges)
        # 对每一对边计算 E(s)
        curves = {}
        for e in edges:
            curves[e] = compute_E_curve(G, e, S_GRID)
        for i in range(len(edges)):
            for j in range(i + 1, len(edges)):
                e1, e2 = edges[i], edges[j]
                if orbits[e1] == orbits[e2]:
                    continue
                if curves_equal(curves[e1], curves[e2]):
                    pairs.append({
                        "graph_id": gid,
                        "edges": edges,
                        "edge1": list(e1),
                        "edge2": list(e2),
                    })
    print(f"  [ok] 重建得到 {len(pairs)} 对异轨道同响应")
    return pairs

# ---------- N=6 图构建 ----------

def build_all_N6_graphs():
    """构建 N=6 的 112 个连通图。使用 graph_atlas 或枚举。"""
    graphs = []
    seen = set()
    # 使用 networkx 的 graph_atlas（包含所有 N<=7 的图）
    for G in nx.graph_atlas_g():
        if G.number_of_nodes() != N_NODES:
            continue
        if not nx.is_connected(G):
            continue
        # 规范化避免重复
        key = nx.weisfeiler_lehman_graph_hash(G)
        if key in seen:
            continue
        seen.add(key)
        graphs.append(G)
    # 如果 atlas 不够（某些 N=6 图可能不在 atlas 中），补充随机
    if len(graphs) < 112:
        print(f"  [warn] atlas 只给出 {len(graphs)} 个图，尝试补充…")
        # 补充：从完全图删边
        K6 = nx.complete_graph(N_NODES)
        for r in range(1, 6):
            for removed in combinations(K6.edges(), r):
                G = K6.copy()
                G.remove_edges_from(removed)
                if nx.is_connected(G):
                    key = nx.weisfeiler_lehman_graph_hash(G)
                    if key not in seen:
                        seen.add(key)
                        graphs.append(G)
    return graphs

def edge_orbits(G, edges):
    """计算每条边的自同构轨道 id"""
    GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
    autos = list(GM.isomorphisms_iter())
    orbits = {}
    for e in edges:
        e_set = frozenset(e)
        orbit = set()
        for auto in autos:
            mapped = frozenset({auto[e[0]], auto[e[1]]})
            orbit.add(mapped)
        orbits[e] = frozenset(orbit)
    # 归一化为整数 id
    uniq = {}
    out = {}
    for e in edges:
        o = orbits[e]
        if o not in uniq:
            uniq[o] = len(uniq)
        out[e] = uniq[o]
    return out

# ---------- E(s) 曲线 ----------

def sz0_basis(N):
    n_up = N // 2
    basis = []
    for comb in combinations(range(N), n_up):
        state = [0] * N
        for i in comb:
            state[i] = 1
        basis.append(tuple(state))
    return basis

def build_H_sz0(N, edges, couplings):
    """在 Sz=0 子空间构造 H = sum J (sx sx + sy sy + sz sz)，S=sigma"""
    basis = sz0_basis(N)
    dim = len(basis)
    idx = {s: i for i, s in enumerate(basis)}
    H = np.zeros((dim, dim))
    for i, state in enumerate(basis):
        for (a, b), J in zip(edges, couplings):
            if state[a] == state[b]:
                H[i, i] += J
            else:
                H[i, i] -= J
                new_state = list(state)
                new_state[a], new_state[b] = new_state[b], new_state[a]
                H[i, idx[tuple(new_state)]] += 2.0 * J
    return H, basis

def compute_E_curve(G, defect_edge, s_grid):
    """计算 E(s) = std{<sz_i sz_j>} 在 s_grid 上的曲线"""
    N = G.number_of_nodes()
    edges = sorted(G.edges())
    node_idx = {n: i for i, n in enumerate(sorted(G.nodes()))}
    edges = [(node_idx[a], node_idx[b]) for a, b in edges]
    target = tuple(sorted((node_idx[defect_edge[0]], node_idx[defect_edge[1]])))
    curves = []
    for s in s_grid:
        couplings = [s if tuple(sorted(e)) == target else 1.0 for e in edges]
        H, basis = build_H_sz0(N, edges, couplings)
        try:
            vals, vecs = np.linalg.eigh(H)
        except Exception:
            curves.append(np.nan)
            continue
        # 对称性约化密度矩阵：等权混合基态简并子空间
        E0 = vals[0]
        degen = np.where(np.abs(vals - E0) < 1e-8)[0]
        rho = np.zeros_like(H)
        for k in degen:
            v = vecs[:, k].reshape(-1, 1)
            rho += v @ v.conj().T
        rho /= len(degen)
        # 计算 <sz_i sz_j>
        sz_diag = []
        for state in basis:
            sz_diag.append([1.0 if state[i] == 1 else -1.0 for i in range(N)])
        sz_diag = np.array(sz_diag)  # (dim, N)
        corr = []
        for (a, b) in edges:
            sz_a = sz_diag[:, a]
            sz_b = sz_diag[:, b]
            val = 0.0
            for i in range(len(basis)):
                for j in range(len(basis)):
                    if i == j:
                        val += rho[i, j] * sz_a[i] * sz_b[i]
                    else:
                        val += rho[i, j] * sz_a[i] * sz_b[j]
            corr.append(val)
        curves.append(float(np.std(corr)))
    return np.array(curves)

def curves_equal(c1, c2, tol=TOL):
    if len(c1) != len(c2):
        return False
    m = ~(np.isnan(c1) | np.isnan(c2))
    if m.sum() == 0:
        return False
    return np.all(np.abs(c1[m] - c2[m]) < tol)

# ==============================================================================
# 第2部分：关系特征定义（六类，穷举）
# ==============================================================================

# ---------- 2A：结构关系特征 ----------
def feat_structural(G, e1, e2):
    out = {}
    n1a, n1b = e1
    n2a, n2b = e2
    s1 = {n1a, n1b}
    s2 = {n2a, n2b}
    out["share_endpoint"] = len(s1 & s2) > 0
    out["common_neighbors"] = len(
        (set(G.neighbors(n1a)) | set(G.neighbors(n1b))) &
        (set(G.neighbors(n2a)) | set(G.neighbors(n2b)))
    )
    out["neighbor_union"] = len(
        (set(G.neighbors(n1a)) | set(G.neighbors(n1b))) |
        (set(G.neighbors(n2a)) | set(G.neighbors(n2b)))
    )
    inter = (set(G.neighbors(n1a)) | set(G.neighbors(n1b))) & \
            (set(G.neighbors(n2a)) | set(G.neighbors(n2b)))
    union = (set(G.neighbors(n1a)) | set(G.neighbors(n1b))) | \
            (set(G.neighbors(n2a)) | set(G.neighbors(n2b)))
    out["neighbor_jaccard"] = len(inter) / len(union) if union else 0.0
    out["degree_pair_1"] = tuple(sorted([G.degree(n1a), G.degree(n1b)]))
    out["degree_pair_2"] = tuple(sorted([G.degree(n2a), G.degree(n2b)]))
    out["degree_sum_1"] = G.degree(n1a) + G.degree(n1b)
    out["degree_sum_2"] = G.degree(n2a) + G.degree(n2b)
    # 边距（最短路径）
    try:
        out["edge_distance"] = nx.shortest_path_length(G, n1a, n2a)
    except Exception:
        out["edge_distance"] = -1
    # 三角形参与
    out["triangle_1"] = sum(1 for _ in nx.common_neighbors(G, n1a, n1b))
    out["triangle_2"] = sum(1 for _ in nx.common_neighbors(G, n2a, n2b))
    # k-core
    core = nx.core_number(G)
    out["kcore_1"] = min(core[n1a], core[n1b])
    out["kcore_2"] = min(core[n2a], core[n2b])
    # 桥状态
    bridges = set(map(frozenset, nx.bridges(G)))
    out["is_bridge_1"] = frozenset(e1) in bridges
    out["is_bridge_2"] = frozenset(e2) in bridges
    return out

# ---------- 2B：谱关系特征 ----------
def feat_spectral(G, e1, e2):
    out = {}
    L = nx.laplacian_matrix(G).astype(float).toarray()
    try:
        evals = np.linalg.eigvalsh(L)
        out["laplacian_gap"] = float(evals[1] - evals[0])
        out["laplacian_max"] = float(evals[-1])
    except Exception:
        out["laplacian_gap"] = np.nan
        out["laplacian_max"] = np.nan
    # 有效电阻（用伪逆）
    try:
        Lpinv = np.linalg.pinv(L)
        def eff_res(u, v):
            return float(Lpinv[u, u] + Lpinv[v, v] - 2 * Lpinv[u, v])
        out["eff_resistance_1"] = eff_res(*e1)
        out["eff_resistance_2"] = eff_res(*e2)
    except Exception:
        out["eff_resistance_1"] = np.nan
        out["eff_resistance_2"] = np.nan
    # 邻接谱
    A = nx.to_numpy_array(G)
    try:
        ev = np.linalg.eigvalsh(A)
        out["adj_spectral_radius"] = float(ev[-1])
        out["adj_gap"] = float(ev[-1] - ev[-2]) if len(ev) > 1 else np.nan
    except Exception:
        out["adj_spectral_radius"] = np.nan
        out["adj_gap"] = np.nan
    # 随机游走命中时间（近似）
    try:
        out["commute_time"] = float(out.get("eff_resistance_1", np.nan) *
                                    2 * G.number_of_edges())
    except Exception:
        out["commute_time"] = np.nan
    return out

# ---------- 2C：自同构关系特征 ----------
def feat_automorphism(G, e1, e2, orbits):
    out = {}
    out["same_orbit"] = orbits[e1] == orbits[e2]
    out["orbit_id_1"] = orbits[e1]
    out["orbit_id_2"] = orbits[e2]
    GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
    autos = list(GM.isomorphisms_iter())
    out["num_automorphisms"] = len(autos)
    # 是否有自同构把 e1 映射到 e2
    found_auto = False
    found_involution = False
    for auto in autos:
        m = frozenset({auto[e1[0]], auto[e1[1]]})
        if m == frozenset(e2):
            found_auto = True
            # 检查是否对合
            if all(auto[auto[n]] == n for n in G.nodes()):
                found_involution = True
                break
    out["has_automorphism_map"] = found_auto
    out["has_involution_map"] = found_involution
    # 轨道大小
    orbit_size = Counter()
    for e in G.edges():
        orbit_size[orbits[e]] += 1
    out["orbit_size_1"] = orbit_size[orbits[e1]]
    out["orbit_size_2"] = orbit_size[orbits[e2]]
    return out

# ---------- 2D：量子关系特征 ----------
def feat_quantum(G, e1, e2, s_grid):
    out = {}
    c1 = compute_E_curve(G, e1, s_grid)
    c2 = compute_E_curve(G, e2, s_grid)
    out["E_curve_equal"] = curves_equal(c1, c2)
    out["E_curve_max_diff"] = float(np.nanmax(np.abs(c1 - c2))) if len(c1) == len(c2) else np.nan
    # 能隙曲线
    g1 = compute_gap_curve(G, e1, s_grid)
    g2 = compute_gap_curve(G, e2, s_grid)
    if g1 is not None and g2 is not None:
        diff = g1 - g2
        out["gap_curve_equal"] = bool(np.all(np.abs(diff) < TOL))
        out["gap_diff_mean"] = float(np.nanmean(diff))
        out["gap_diff_std"] = float(np.nanstd(diff))
        out["gap_diff_is_constant"] = bool(np.nanstd(diff) < 1e-8)
        # 尝试识别代数数
        val = float(np.nanmean(diff))
        out["gap_diff_value"] = val
        out["gap_diff_identified"] = identify_algebraic(val)
    else:
        out["gap_curve_equal"] = None
        out["gap_diff_mean"] = np.nan
        out["gap_diff_std"] = np.nan
        out["gap_diff_is_constant"] = None
        out["gap_diff_value"] = np.nan
        out["gap_diff_identified"] = "n/a"
    return out

def compute_gap_curve(G, defect_edge, s_grid):
    N = G.number_of_nodes()
    edges = sorted(G.edges())
    node_idx = {n: i for i, n in enumerate(sorted(G.nodes()))}
    edges = [(node_idx[a], node_idx[b]) for a, b in edges]
    target = tuple(sorted((node_idx[defect_edge[0]], node_idx[defect_edge[1]])))
    gaps = []
    for s in s_grid:
        couplings = [s if tuple(sorted(e)) == target else 1.0 for e in edges]
        H, _ = build_H_sz0(N, edges, couplings)
        try:
            vals = np.linalg.eigvalsh(H)
            gaps.append(float(vals[1] - vals[0]))
        except Exception:
            gaps.append(np.nan)
    return np.array(gaps)

def identify_algebraic(x):
    """识别有理数或二次代数数"""
    if np.isnan(x):
        return "nan"
    if abs(x) < 1e-10:
        return "0"
    # 有理数
    for q in range(1, 1001):
        p = round(x * q)
        if abs(x - p / q) < 1e-10:
            return f"{p}/{q}"
    # 二次代数数
    for c in range(1, 21):
        for a in range(-20, 21):
            for b in range(-20, 21):
                if abs(a + b * x + c * x * x) < 1e-8:
                    disc = b * b - 4 * a * c
                    if disc >= 0:
                        r = np.sqrt(disc)
                        return f"(-{b}+-sqrt({disc}))/{2*a}" if a != 0 else f"sqrt({disc})"
    return "未识别"

# ---------- 2E：拓扑关系特征 ----------
def feat_topological(G, e1, e2):
    out = {}
    # 桥数
    out["num_bridges"] = len(list(nx.bridges(G)))
    # 边在生成树中的参与（近似：用边介数）
    try:
        eb = nx.edge_betweenness_centrality(G)
        out["edge_betw_1"] = eb[e1]
        out["edge_betw_2"] = eb[e2]
    except Exception:
        out["edge_betw_1"] = np.nan
        out["edge_betw_2"] = np.nan
    # 圈空间维数
    out["cycle_rank"] = G.number_of_edges() - G.number_of_nodes() + 1
    # 共同圈参与：边是否在同一个 4-圈中
    try:
        cycles = nx.cycle_basis(G)
        def in_cycles(e):
            es = frozenset(e)
            return sum(1 for c in cycles if es.issubset(set(map(frozenset, combinations(c, 2)))))
        out["cycle_participation_1"] = in_cycles(e1)
        out["cycle_participation_2"] = in_cycles(e2)
    except Exception:
        out["cycle_participation_1"] = -1
        out["cycle_participation_2"] = -1
    return out

# ---------- 2F：全局关系特征 ----------
def feat_global(G, e1, e2):
    out = {}
    try:
        bc = nx.betweenness_centrality(G)
        out["node_betw_1"] = (bc[e1[0]] + bc[e1[1]]) / 2
        out["node_betw_2"] = (bc[e2[0]] + bc[e2[1]]) / 2
    except Exception:
        out["node_betw_1"] = np.nan
        out["node_betw_2"] = np.nan
    try:
        cc = nx.clustering(G)
        out["clustering_1"] = (cc[e1[0]] + cc[e1[1]]) / 2
        out["clustering_2"] = (cc[e2[0]] + cc[e2[1]]) / 2
    except Exception:
        out["clustering_1"] = np.nan
        out["clustering_2"] = np.nan
    # 全局效率
    try:
        out["global_efficiency"] = nx.global_efficiency(G)
    except Exception:
        out["global_efficiency"] = np.nan
    return out

# ==============================================================================
# 第3部分：计算引擎
# ==============================================================================

def compute_all_features(pairs):
    """
    对每一对，计算所有关系特征。
    返回: list of dict，每个 dict 是 {feature_name: (value1, value2, same?)}
    """
    results = []
    for idx, p in enumerate(pairs):
        gid = p.get("graph_id", p.get("graph", -1))
        e1 = tuple(p["edge1"])
        e2 = tuple(p["edge2"])
        # 重建图
        G = build_graph_from_id(gid)
        if G is None:
            print(f"  [warn] 无法重建图 {gid}，跳过")
            continue
        # 计算自同构轨道
        try:
            orbits = edge_orbits(G, sorted(G.edges()))
        except Exception:
            orbits = {e: -1 for e in G.edges()}
        # 计算所有特征
        row = {
            "pair_id": idx,
            "graph_id": gid,
            "edge1": e1,
            "edge2": e2,
        }
        row.update(feat_structural(G, e1, e2))
        row.update(feat_spectral(G, e1, e2))
        row.update(feat_automorphism(G, e1, e2, orbits))
        row.update(feat_topological(G, e1, e2))
        row.update(feat_global(G, e1, e2))
        row.update(feat_quantum(G, e1, e2, S_GRID))
        results.append(row)
    return results

def build_graph_from_id(gid):
    """根据 graph_id 重建 N=6 图。这里假设 gid 是 build_all_N6_graphs 的索引。"""
    graphs = build_all_N6_graphs()
    if 0 <= gid < len(graphs):
        return graphs[gid]
    return None

# ==============================================================================
# 第4部分：并排比较
# ==============================================================================

def side_by_side_report(rows):
    """
    输出并排比较表。
    对每个特征，列出 32 对中的值，标记哪些相同、哪些不同。
    """
    if not rows:
        print("  [warn] 没有可比较的行")
        return
    # 收集所有特征名（排除元数据）
    meta = {"pair_id", "graph_id", "edge1", "edge2"}
    feature_names = []
    for k in rows[0].keys():
        if k not in meta:
            feature_names.append(k)
    print("\n" + "=" * 100)
    print("并排比较：32 对异轨道同响应的穷举关系特征")
    print("=" * 100)
    for fname in feature_names:
        values = [row.get(fname) for row in rows]
        # 判断这一列是否"同"
        same_count = 0
        for i in range(len(values)):
            for j in range(i + 1, len(values)):
                if same(values[i], values[j]):
                    same_count += 1
        total_pairs = len(values) * (len(values) - 1) // 2
        print(f"\n--- {fname} ---")
        print(f"  同值对数: {same_count}/{total_pairs}  "
              f"异值对数: {total_pairs - same_count}/{total_pairs}")
        # 并排展示（每行 4 对，避免太长）
        line = []
        for i, v in enumerate(values):
            line.append(f"[{i:02d}]={fmt(v)}")
            if (i + 1) % 4 == 0:
                print("  " + "  ".join(line))
                line = []
        if line:
            print("  " + "  ".join(line))

# ==============================================================================
# 第5部分：追问生成
# ==============================================================================

def ask_why(rows):
    """
    对每个特征，生成追问。
    不是结论，是追问。
    """
    print("\n" + "=" * 100)
    print("追问生成：每个特征为什么同，为什么不同")
    print("=" * 100)
    meta = {"pair_id", "graph_id", "edge1", "edge2"}
    feature_names = [k for k in rows[0].keys() if k not in meta]
    for fname in feature_names:
        values = [row.get(fname) for row in rows]
        # 统计同异
        same_pairs = 0
        diff_pairs = 0
        for i in range(len(values)):
            for j in range(i + 1, len(values)):
                if same(values[i], values[j]):
                    same_pairs += 1
                else:
                    diff_pairs += 1
        total = same_pairs + diff_pairs
        print(f"\n### 追问：{fname}")
        print(f"  · 同值对数 {same_pairs}/{total}，异值对数 {diff_pairs}/{total}")
        if diff_pairs == 0:
            print(f"  · 为什么这个特征在所有 32 对中完全相同？")
            print(f"    ——它可能是响应等价的必要条件？")
            print(f"    ——它可能是图同构的副产品？")
            print(f"    ——它可能是被我们截断掉的关系维度？")
        elif same_pairs == 0:
            print(f"  · 为什么这个特征在所有 32 对中完全不同？")
            print(f"    ——它可能是响应等价的无关项？")
            print(f"    ——它可能是节点对象化的残留？")
            print(f"    ——它可能是被我们误认为关系特征的节点属性？")
        else:
            print(f"  · 为什么部分对同、部分对不同？")
            print(f"    ——同的那些对，共享了什么关系结构？")
            print(f"    ——不同的那些对，缺失了什么关系结构？")
            print(f"    ——这个特征是否只是相关，不是因果？")
        print(f"  · 这个特征的截断点在哪里？")
        print(f"  · 如果把节点全部抹掉，这个特征还剩什么？")

# ==============================================================================
# 第6部分：导出
# ==============================================================================

def export_results(rows, out_dir=WORK_DIR):
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "照妖镜_32对穷举特征.json")
    # 转换 numpy 类型
    def convert(o):
        if isinstance(o, (np.integer,)):
            return int(o)
        if isinstance(o, (np.floating,)):
            return float(o)
        if isinstance(o, (np.bool_,)):
            return bool(o)
        if isinstance(o, np.ndarray):
            return o.tolist()
        return str(o)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=2, default=convert)
    print(f"\n[ok] 结果已导出: {out_path}")

# ==============================================================================
# 主流程
# ==============================================================================

def main():
    print("=" * 100)
    print("照妖镜协议 v1.0")
    print("32 对异轨道同响应的穷举关系特征攻击")
    print("=" * 100)

    print("\n[1/4] 加载 32 对…")
    pairs = load_32_pairs()
    print(f"  共 {len(pairs)} 对")

    print("\n[2/4] 穷举计算所有关系特征…")
    rows = compute_all_features(pairs)
    print(f"  完成 {len(rows)} 对")

    print("\n[3/4] 并排比较…")
    side_by_side_report(rows)

    print("\n[4/4] 追问生成…")
    ask_why(rows)

    export_results(rows)

    print("\n" + "=" * 100)
    print("照妖镜协议完成。")
    print("结果并排展示。不筛选。不排序。不下结论。")
    print("过程继续。")
    print("=" * 100)

if __name__ == "__main__":
    main()