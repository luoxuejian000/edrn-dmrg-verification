#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 v16.0：N=7 简并情形下的 p_S 行为
================================================================

核心问题：
  N=6 简并 -1 命中率 65.5% (19/29)
  N=7 简并 -1 命中率 37.6% (530/1411)
  为什么 N=7 低这么多？

五个追问并行：
  Q1. N=7 简并态的 <σ·σ> 值分布 —— 是 {−3, +1} 两种还是更多？
  Q2. N=7 简并度 d 与总自旋 S 的对应 —— 比 N=6 更杂吗？
  Q3. 简并命中率低是因为"配不平"，还是"值种类多"？
  Q4. N=7 是否存在"奇偶自旋混合"？
  Q5. 如果把 N=7 的简并点按 d 分类，命中率各是多少？

晶脉哲学：
  · 关系本体论：简并子空间是关系网络在对称性下的退化
  · 对象化=截断=产生方向：每个简并态都是一个截断
  · 只查同与不同：不筛选，不排序
  · 反对对齐：不预设结论
"""

import sys, io, itertools, json, os
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from scipy.optimize import brentq
from collections import Counter, defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"


# ============================================================
# S_z=0 扇区
# ============================================================

def build_sz0_sector(N):
    n_up = N // 2
    basis = []
    for comb in itertools.combinations(range(N), n_up):
        state = [0]*N
        for i in comb: state[i] = 1
        basis.append(tuple(state))
    dim = len(basis)
    idx = {s: i for i, s in enumerate(basis)}
    SZ_ops = []
    for site in range(N):
        SZ = np.zeros((dim, dim), dtype=complex)
        for i, state in enumerate(basis):
            SZ[i, i] = 1 if state[site] == 1 else -1
        SZ_ops.append(SZ)
    return basis, idx, SZ_ops


def build_edge_op(i, j, basis, idx):
    dim = len(basis)
    op = np.zeros((dim, dim), dtype=complex)
    for a_idx, state_a in enumerate(basis):
        sa, sb = state_a[i], state_a[j]
        if sa == sb:
            op[a_idx, a_idx] += 1
        else:
            op[a_idx, a_idx] += -1
            new_state = list(state_a)
            new_state[i], new_state[j] = new_state[j], new_state[i]
            b_idx = idx.get(tuple(new_state))
            if b_idx is not None:
                op[b_idx, a_idx] += 2
    return op


def build_S2_op(basis, idx, N):
    dim = len(basis)
    S2 = np.zeros((dim, dim), dtype=complex)
    for i in range(N):
        S2 += 3/4 * np.eye(dim, dtype=complex)
        for j in range(N):
            if i == j: continue
            S2 += 1/4 * build_edge_op(i, j, basis, idx)
    return S2


# ============================================================
# p_S 计算
# ============================================================

def pS_at_s(edge_ops, defect, s, SZ_ops, ref_dim):
    H = np.zeros((ref_dim, ref_dim), dtype=complex)
    for e, M in edge_ops.items():
        c = s if e == defect else 1.0
        H += c * M
    try:
        evals, evecs = eigh(H)
    except Exception:
        return None
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < 1e-8))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    i, j = defect
    szsz_diag = np.diag(SZ_ops[i] @ SZ_ops[j])
    szsz = float(np.real(np.sum(np.diag(rho) * szsz_diag)))
    p_S = (1 - 3 * szsz) / 4
    return p_S, deg, evals, evecs


def find_resonances(edge_ops, defect, SZ_ops, ref_dim, n_grid=61):
    s_grid = np.linspace(-2.0, 2.5, n_grid)
    pS_vals = []
    for s in s_grid:
        r = pS_at_s(edge_ops, defect, s, SZ_ops, ref_dim)
        pS_vals.append(r[0] if r else 0.0)
    pS_vals = np.array(pS_vals)
    crossings = []
    for k in range(len(s_grid) - 1):
        if (pS_vals[k] - 0.5) * (pS_vals[k+1] - 0.5) < 0:
            try:
                s_res = brentq(
                    lambda s: pS_at_s(edge_ops, defect, s, SZ_ops, ref_dim)[0] - 0.5,
                    s_grid[k], s_grid[k+1], xtol=1e-10)
                crossings.append(s_res)
            except Exception:
                pass
    return crossings


def analyze_at_resonance(edge_ops, defect, s, SZ_ops, S2_op, ref_dim):
    """在谐振点处分析：p_S、简并度、每个简并态的 <σ·σ> 和 S"""
    r = pS_at_s(edge_ops, defect, s, SZ_ops, ref_dim)
    if r is None:
        return None
    p_S, deg, evals, evecs = r
    V = evecs[:, :deg]
    per_state_sigdot = []
    per_state_S = []
    for k in range(deg):
        v = V[:, k]
        sd = float(np.real(v.conj() @ edge_ops[defect] @ v))
        s2 = float(np.real(v.conj() @ S2_op @ v))
        S_val = (-1 + np.sqrt(1 + 4*max(s2, 0))) / 2
        per_state_sigdot.append(sd)
        per_state_S.append(S_val)
    # 对称化平均值
    rho = V @ V.conj().T / deg
    sd_mean = float(np.real(np.trace(rho @ edge_ops[defect])))
    return {
        "p_S": p_S, "deg": deg, "mean_sigdot": sd_mean,
        "per_state_sigdot": per_state_sigdot,
        "per_state_S": per_state_S,
    }


# ============================================================
# 图集
# ============================================================

def build_atlas_graphs(N):
    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    return graphs


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 100)
    print("照妖镜 v16.0：N=7 简并情形下的 p_S 行为")
    print("=" * 100)

    N = 7
    graphs = build_atlas_graphs(N)
    print(f"\n  N={N} 图集: {len(graphs)} 图")

    basis, idx, SZ_ops = build_sz0_sector(N)
    ref_dim = len(basis)
    print(f"  S_z=0 扇区维度: {ref_dim}")

    S2_op = build_S2_op(basis, idx, N)
    print(f"  S² 算符构建完成")

    # 扫描全部图，每个图取全部边
    print(f"\n  扫描所有图的谐振点（这会花些时间）...")
    all_resonances = []
    for gid, G in enumerate(graphs):
        if gid % 50 == 0:
            print(f"    {gid}/{len(graphs)}")
        edges = [tuple(sorted(e)) for e in G.edges()]
        edge_ops = {e: build_edge_op(e[0], e[1], basis, idx) for e in edges}
        for defect in edges:
            crossings = find_resonances(edge_ops, defect, SZ_ops, ref_dim)
            for s_res in crossings:
                info = analyze_at_resonance(
                    edge_ops, defect, s_res, SZ_ops, S2_op, ref_dim)
                if info:
                    all_resonances.append({
                        "gid": gid, "defect": list(defect),
                        "s": float(s_res), **info
                    })

    print(f"\n  总谐振点: {len(all_resonances)}")

    # 分开非简并和简并
    nondeg = [r for r in all_resonances if r["deg"] == 1]
    deg = [r for r in all_resonances if r["deg"] > 1]
    print(f"  非简并: {len(nondeg)}")
    print(f"  简并: {len(deg)}")

    # ============================================================
    # Q1: N=7 简并态 <σ·σ> 值分布
    # ============================================================
    print("\n" + "=" * 100)
    print("Q1. N=7 简并态的 <σ·σ> 值分布")
    print("=" * 100)

    all_per_state = []
    for r in deg:
        all_per_state.extend(r["per_state_sigdot"])

    all_per_state = np.array(all_per_state)
    print(f"\n  总简并态数: {len(all_per_state)}")
    print(f"  范围: [{all_per_state.min():.4f}, {all_per_state.max():.4f}]")

    # 整数化统计（四舍五入到最近的整数）
    rounded = np.round(all_per_state)
    cnt = Counter(rounded)
    print(f"\n  {'值':>6} | {'数量':>8} | {'占比':>8}")
    print(f"  {'-'*6}-+-{'-'*8}-+-{'-'*8}")
    for val in sorted(cnt.keys()):
        c = cnt[val]
        bar = "█" * int(c / len(all_per_state) * 50)
        print(f"  {val:>6.0f} | {c:>8} | {c/len(all_per_state):>7.1%} {bar}")

    # 非整数部分
    non_int = all_per_state[np.abs(all_per_state - rounded) > 0.05]
    print(f"\n  非整数部分: {len(non_int)}/{len(all_per_state)} = {len(non_int)/len(all_per_state):.1%}")
    if len(non_int) > 0:
        print(f"  非整数范围: [{non_int.min():.4f}, {non_int.max():.4f}]")
        print(f"  非整数均值: {non_int.mean():.4f}")

    # 对比 N=6 已知数据: {-3: 大量, +1: 大量, 无其他}
    print(f"\n  --- 对比 N=6（v11-Q1 数据）---")
    print(f"  N=6: 只有 {{-3, +1}} 两种值")
    print(f"  N=7: {len(cnt)} 种整数值")

    # ============================================================
    # Q2: N=7 简并度 d 与总自旋 S 的对应
    # ============================================================
    print("\n" + "=" * 100)
    print("Q2. N=7 简并度 d 与总自旋 S 的对应")
    print("=" * 100)

    print(f"\n  {'d':>4} | {'数量':>6} | {'S 分布':>40}")
    print(f"  {'-'*4}-+-{'-'*6}-+-{'-'*40}")

    by_deg = defaultdict(list)
    for r in deg:
        by_deg[r["deg"]].append(r)

    for d in sorted(by_deg.keys()):
        items = by_deg[d]
        all_S = [s for r in items for s in r["per_state_S"]]
        # S 分布（0.5 精度）
        S_cnt = Counter(round(s*2)/2 for s in all_S)
        dist = ", ".join(f"S={sv}:{c}" for sv, c in sorted(S_cnt.items()))
        print(f"  {d:>4} | {len(items):>6} | {dist:>40}")

    # ============================================================
    # Q3: 简并命中率低是因为"配不平"，还是"值种类多"？
    # ============================================================
    print("\n" + "=" * 100)
    print("Q3. 简并命中率低的原因")
    print("=" * 100)

    # 命中 -1 的简并点
    hit = [r for r in deg if abs(r["mean_sigdot"] + 1) < 1e-6]
    miss = [r for r in deg if abs(r["mean_sigdot"] + 1) >= 1e-6]
    print(f"\n  简并点总数: {len(deg)}")
    print(f"  命中 -1: {len(hit)} ({len(hit)/len(deg):.1%})")
    print(f"  未命中: {len(miss)} ({len(miss)/len(deg):.1%})")

    print(f"\n  --- 命中的简并点 ---")
    for r in hit[:20]:
        per_state = r["per_state_sigdot"]
        per_state_S = r["per_state_S"]
        r_sd = [round(v, 2) for v in per_state]
        r_S = [round(v, 2) for v in per_state_S]
        print(f"  gid={r['gid']:>4}, defect={r['defect']}, d={r['deg']}: "
              f"σ·σ={r_sd}, S={r_S}, mean={r['mean_sigdot']:.4f}")

    print(f"\n  --- 未命中的简并点（前 20 个）---")
    for r in miss[:20]:
        per_state = r["per_state_sigdot"]
        per_state_S = r["per_state_S"]
        r_sd = [round(v, 2) for v in per_state]
        r_S = [round(v, 2) for v in per_state_S]
        print(f"  gid={r['gid']:>4}, defect={r['defect']}, d={r['deg']}: "
              f"σ·σ={r_sd}, S={r_S}, mean={r['mean_sigdot']:.4f}")

    # ============================================================
    # Q4: 奇偶自旋混合
    # ============================================================
    print("\n" + "=" * 100)
    print("Q4. N=7 简并态的奇偶自旋混合")
    print("=" * 100)

    # 对每个简并点，看它的 S 值是否全为整数（偶数自旋）或全为半整数（奇数自旋）
    same_parity = 0
    mixed_parity = 0
    for r in deg:
        S_vals = r["per_state_S"]
        # 判断奇偶：整数 S 是玻色子，半整数是费米子
        is_int = [abs(s - round(s)) < 1e-6 for s in S_vals]
        if all(is_int) or not any(is_int):
            same_parity += 1
        else:
            mixed_parity += 1
    print(f"\n  简并点总数: {len(deg)}")
    print(f"  单一奇偶（全整数或全半整数）: {same_parity} ({same_parity/len(deg):.1%})")
    print(f"  混合奇偶（两者都有）: {mixed_parity} ({mixed_parity/len(deg):.1%})")

    # ============================================================
    # Q5: 按简并度 d 分类的命中率
    # ============================================================
    print("\n" + "=" * 100)
    print("Q5. 按简并度 d 分类的命中率")
    print("=" * 100)

    print(f"\n  {'d':>4} | {'总数':>6} | {'命中 -1':>8} | {'命中率':>8} | {'S 类型':>15}")
    print(f"  {'-'*4}-+-{'-'*6}-+-{'-'*8}-+-{'-'*8}-+-{'-'*15}")

    for d in sorted(by_deg.keys()):
        items = by_deg[d]
        n_hit = sum(1 for r in items if abs(r["mean_sigdot"] + 1) < 1e-6)
        all_S = [s for r in items for s in r["per_state_S"]]
        # S 类型
        is_int = [abs(s - round(s)) < 1e-6 for s in all_S]
        if all(is_int):
            S_type = "全整数"
        elif not any(is_int):
            S_type = "全半整数"
        else:
            S_type = "混合"
        print(f"  {d:>4} | {len(items):>6} | {n_hit:>8} | "
              f"{n_hit/len(items):>7.1%} | {S_type:>15}")

    # ============================================================
    # 深度追问：N=6 vs N=7 简并结构对比
    # ============================================================
    print("\n" + "=" * 100)
    print("N=6 vs N=7 简并结构对比")
    print("=" * 100)

    # N=6 已知数据（从 v11-Q1 输出）
    n6_deg_data = {
        "d=2": {"count": 15, "hit": 15, "values": [(-3, +1)]},
        "d=3": {"count": 2, "hit": 1, "values": [(-3, +1, +1), (1, -3, -3)]},
        "d=4": {"count": 6, "hit": 3, "values": [(-3, +1, +1, +1), ...]},
        "d=6": {"count": 5, "hit": 5, "values": [(-3, -3, -3, +1, +1, +1)]},
        "d=10": {"count": 1, "hit": 0, "values": [...]},
    }

    print(f"\n  --- 简并度分布对比 ---")
    print(f"  {'d':>4} | {'N=6 数量':>10} | {'N=7 数量':>10}")
    print(f"  {'-'*4}-+-{'-'*10}-+-{'-'*10}")
    # N=7 简并度分布
    n7_d_cnt = Counter(r["deg"] for r in deg)
    for d in sorted(set(list(n6_deg_data.keys()) + [f"d={k}" for k in n7_d_cnt.keys()])):
        d_int = int(d.split("=")[1]) if isinstance(d, str) else d
        n6_c = n6_deg_data.get(f"d={d_int}", {}).get("count", "-")
        n7_c = n7_d_cnt.get(d_int, 0)
        print(f"  {d_int:>4} | {str(n6_c):>10} | {n7_c:>10}")

    print(f"\n  --- 关键对比 ---")
    print(f"  N=6: 简并态取值 {set([-3, +1])}, d∈{{2,3,4,6,10}}")
    print(f"  N=7: 简并态取值种类 {len(cnt)}, d∈{sorted(n7_d_cnt.keys())}")
    print(f"  N=6 简并命中率: 65.5%")
    print(f"  N=7 简并命中率: {len(hit)/len(deg):.1%}")

    # ============================================================
    # 导出
    # ============================================================
    out = {
        "N": N,
        "n_resonances": len(all_resonances),
        "n_nondeg": len(nondeg),
        "n_deg": len(deg),
        "deg_hit_rate": len(hit) / len(deg) if deg else 0,
        "deg_sigdot_distribution": {str(k): v for k, v in cnt.items()},
        "non_int_fraction": len(non_int) / len(all_per_state) if len(all_per_state) else 0,
        "by_deg": {
            str(d): {
                "count": len(by_deg[d]),
                "hits": sum(1 for r in by_deg[d] if abs(r["mean_sigdot"] + 1) < 1e-6),
            } for d in by_deg
        },
        "resonances": all_resonances,
    }
    out_path = os.path.join(WORK_DIR, "照妖镜_v16_N7_degenerate.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("v16.0 完成。N=7 简并情形被攻击。")
    print("=" * 100)


if __name__ == "__main__":
    main()