#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 v7.0：从 Heisenberg 哈密顿量解析推导 ±1/3 的条件
================================================================

核心解析结果（先行）：
  对于总自旋单态基态 |ψ⟩，对任意一对自旋 (i,j)：

    ⟨σˣᵢσˣⱼ⟩ = ⟨σʸᵢσʸⱼ⟩ = ⟨σᶻᵢσᶻⱼ⟩ = ⟨σᵢ·σⱼ⟩/3

  缺陷边约化密度矩阵：ρ_ij = (1/4)I + c(σᵢ·σⱼ)，其中 c = ⟨σᶻσᶻ⟩/4
  单态-三重态混合比：p_S = (1 - 3⟨σᶻσᶻ⟩)/4

  谐振点条件：
    ⟨σᶻσᶻ⟩ = +1/3  ⟺  p_S = 0    ⟺  纯三重态
    ⟨σᶻσᶻ⟩ = -1/3  ⟺  p_S = 1/2  ⟺  单态-三重态等量混合
    ⟨σᶻσᶻ⟩ = -1    ⟺  p_S = 1    ⟺  纯单态

五个追问并行：
  Q1. ρ_ij 是否与 SU(2) 对易？⟨σˣσˣ⟩=⟨σʸσʸ⟩=⟨σᶻσᶻ⟩ 是否成立？
  Q2. p_S 如何随 s 变化？
  Q3. p_S = 0（+1/3）和 p_S = 1/2（-1/3）的 s 条件是什么？
  Q4. 这些 s 条件与图几何（桥、度、距离）的关系？
  Q5. 为什么是 ±1/3，不是其他值？
"""

import sys, io, itertools, json, os
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from collections import Counter, defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"
N = 6
TOL = 1e-10

# ============================================================
# 自旋算符
# ============================================================

I2 = np.eye(2, dtype=complex)
SX = np.array([[0,1],[1,0]], dtype=complex)
SY = np.array([[0,-1j],[1j,0]], dtype=complex)
SZ = np.array([[1,0],[0,-1]], dtype=complex)


def op_on_site(op, site, N):
    ops = [I2]*N; ops[site] = op
    out = ops[0]
    for o in ops[1:]: out = np.kron(out, o)
    return out


def build_site_ops(N):
    return ([op_on_site(SX,i,N) for i in range(N)],
            [op_on_site(SY,i,N) for i in range(N)],
            [op_on_site(SZ,i,N) for i in range(N)])


def edge_matrix(i, j, SXo, SYo, SZo):
    return SXo[i]@SXo[j] + SYo[i]@SYo[j] + SZo[i]@SZo[j]


def ground_state(H, tol=1e-8):
    evals, evecs = eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < tol))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    return E0, rho


# ============================================================
# 约化密度矩阵（用 reshape + trace）
# ============================================================

def partial_trace_2sites(rho, i, j, N):
    """
    从完整密度矩阵 rho 计算保留自旋 i, j 的约化密度矩阵。
    返回 4x4 矩阵，基顺序 {|↑↑⟩, |↑↓⟩, |↓↑⟩, |↓↓⟩}
    """
    dims = [2] * N
    rho_t = rho.reshape(dims + dims)
    perm = []
    for k in [i, j]:
        perm.append(k)
    for k in range(N):
        if k not in (i, j):
            perm.append(k)
    for k in [i, j]:
        perm.append(N + k)
    for k in range(N):
        if k not in (i, j):
            perm.append(N + k)
    rho_p = np.transpose(rho_t, perm)
    d_keep = 4
    d_trace = 2 ** (N - 2)
    rho_r = rho_p.reshape(d_keep, d_trace, d_keep, d_trace)
    return np.trace(rho_r, axis1=1, axis2=3)


# ============================================================
# 关键解析量
# ============================================================

def analyze_reduced_rho(rho_ij):
    """
    给定 4x4 约化密度矩阵，提取解析量。
    基：{|↑↑⟩, |↑↓⟩, |↓↑⟩, |↓↓⟩}
    """
    # 单态 |S⟩ = (|↑↓⟩ - |↓↑⟩)/√2
    # 三重态：|T₊⟩ = |↑↑⟩, |T₀⟩ = (|↑↓⟩+|↓↑⟩)/√2, |T₋⟩ = |↓↓⟩
    # p_S = ⟨S|ρ|S⟩
    # p_T = 1 - p_S
    # 注意：SU(2) 对称的 ρ 满足 p_T₊ = p_T₀ = p_T₋ = p_T/3

    # 单态概率
    # ⟨S|ρ|S⟩ = (1/2)(ρ_11 - ρ_12 - ρ_21 + ρ_22) 其中下标对应 |↑↓⟩, |↓↑⟩ 在计算基中
    # 计算基顺序：0=|↑↑⟩, 1=|↑↓⟩, 2=|↓↑⟩, 3=|↓↓⟩
    p_S = 0.5 * (rho_ij[1,1].real - rho_ij[1,2].real - rho_ij[2,1].real + rho_ij[2,2].real)

    # 检查 SU(2) 对称性：ρ 应该与 σᵢ·σⱼ 对易且与总自旋对易
    # 用 σᵢ·σⱼ 在计算基下的矩阵
    sigma_dot = np.array([
        [1, 0, 0, 0],
        [0, -1, 2, 0],
        [0, 2, -1, 0],
        [0, 0, 0, 1]
    ], dtype=complex)

    comm = rho_ij @ sigma_dot - sigma_dot @ rho_ij
    su2_symmetric = np.allclose(comm, 0, atol=1e-8)

    # 从 SU(2) 对称的 ρ 中提取 c：
    # ρ = (1/4)I + c(σᵢ·σⱼ)
    # 迹：Tr(ρ) = 1 自动满足
    # Tr(ρ σᵢ·σⱼ) = Tr((σᵢ·σⱼ)/4) + c·Tr((σᵢ·σⱼ)²) = 0 + c·12 = 12c
    # 所以 ⟨σᵢ·σⱼ⟩ = 12c → c = ⟨σᵢ·σⱼ⟩/12
    sigma_dot_val = float(np.real(np.trace(rho_ij @ sigma_dot)))

    # ⟨σᶻσᶻ⟩
    sz_sz = np.array([
        [1, 0, 0, 0],
        [0, -1, 0, 0],
        [0, 0, -1, 0],
        [0, 0, 0, 1]
    ], dtype=complex)
    szsz_val = float(np.real(np.trace(rho_ij @ sz_sz)))

    # ⟨σˣσˣ⟩, ⟨σʸσʸ⟩
    sx_sx = np.array([
        [0, 0, 0, 1],
        [0, 0, 1, 0],
        [0, 1, 0, 0],
        [1, 0, 0, 0]
    ], dtype=complex)
    sy_sy = np.array([
        [0, 0, 0, -1],
        [0, 0, 1, 0],
        [0, 1, 0, 0],
        [-1, 0, 0, 0]
    ], dtype=complex)
    sxsx_val = float(np.real(np.trace(rho_ij @ sx_sx)))
    sysy_val = float(np.real(np.trace(rho_ij @ sy_sy)))

    # 从 ⟨σᶻσᶻ⟩ 反推 p_S
    p_S_from_szsz = (1 - 3 * szsz_val) / 4

    return {
        "p_S": p_S,
        "p_S_from_szsz": p_S_from_szsz,
        "szsz": szsz_val,
        "sxsx": sxsx_val,
        "sysy": sysy_val,
        "sigma_dot": sigma_dot_val,
        "su2_symmetric": su2_symmetric,
        "c": sigma_dot_val / 12,
    }


# ============================================================
# 同响应对清单（从 v5.1 加载）
# ============================================================

def load_same_response_pairs():
    with open(os.path.join(WORK_DIR, "照妖镜_v5_1_模式.json"), "r",
              encoding="utf-8") as f:
        v51 = json.load(f)
    pairs = {}
    for key, s in v51["patterns"].items():
        gid, e1_str, e2_str = key.split("_", 2)
        gid = int(gid)
        e1 = tuple(map(int, e1_str.strip("()").split(",")))
        e2 = tuple(map(int, e2_str.strip("()").split(",")))
        pairs[(gid, e1, e2)] = s
    return pairs


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 100)
    print("照妖镜 v7.0：从 Heisenberg 哈密顿量解析推导 ±1/3 的条件")
    print("=" * 100)

    # ---------- 解析关系先行 ----------
    print("\n[解析框架]")
    print("  对于总自旋单态基态：")
    print("    ⟨σˣᵢσˣⱼ⟩ = ⟨σʸᵢσʸⱼ⟩ = ⟨σᶻᵢσᶻⱼ⟩ = ⟨σᵢ·σⱼ⟩/3")
    print("  缺陷边约化密度矩阵：ρ_ij = (1/4)I + c(σᵢ·σⱼ)")
    print("  p_S = (1 - 3⟨σᶻσᶻ⟩)/4")
    print("  谐振点条件：")
    print("    ⟨σᶻσᶻ⟩ = +1/3  ⟺  p_S = 0   ⟺  纯三重态")
    print("    ⟨σᶻσᶻ⟩ = -1/3  ⟺  p_S = 1/2 ⟺  单态-三重态等量混合")
    print("    ⟨σᶻσᶻ⟩ = -1    ⟺  p_S = 1   ⟺  纯单态")

    # ---------- 图集 ----------
    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    print(f"\n  图集: {len(graphs)} 个 N=6 连通图")

    # 加载同响应对
    same_pairs = load_same_response_pairs()
    same_keys = set(same_pairs.keys())
    print(f"  同响应对: {len(same_keys)}")

    # 自旋算符
    SXo, SYo, SZo = build_site_ops(N)

    # ---------- s 网格 ----------
    s_vals = np.linspace(-2.0, 2.0, 81)
    print(f"  s 网格: [{s_vals[0]}, {s_vals[-1]}], {len(s_vals)} 点")

    # ---------- 只对同响应对涉及的图和边做精细分析 ----------
    relevant_gids = sorted(set(gid for gid, _, _ in same_keys))
    print(f"  相关图数: {len(relevant_gids)}")

    # 收集所有 (图, 缺陷边) 对
    defect_edges = set()
    for gid in relevant_gids:
        for key in same_keys:
            if key[0] == gid:
                defect_edges.add((gid, key[1]))
                defect_edges.add((gid, key[2]))

    print(f"  相关缺陷边: {len(defect_edges)}")

    # ---------- 逐 (图, 缺陷边) 计算 p_S 曲线 ----------
    print(f"\n  计算 p_S 曲线…")
    pS_cache = {}  # (gid, edge) -> {s_val: analysis_dict}
    for idx, (gid, defect) in enumerate(sorted(defect_edges)):
        if idx % 20 == 0:
            print(f"    {idx}/{len(defect_edges)}")
        G = graphs[gid]
        edges = [tuple(sorted(e)) for e in G.edges()]
        H_edges = [edge_matrix(e[0], e[1], SXo, SYo, SZo) for e in edges]
        idx_def = edges.index(defect)
        pS_cache[(gid, defect)] = {}
        for s in s_vals:
            couplings = [s if e == defect else 1.0 for e in edges]
            H = sum(c*M for c, M in zip(couplings, H_edges))
            E0, rho = ground_state(H)
            rho_ij = partial_trace_2sites(rho, defect[0], defect[1], N)
            analysis = analyze_reduced_rho(rho_ij)
            pS_cache[(gid, defect)][s] = analysis
    print(f"  完成")

    # ============================================================
    # Q1: ρ_ij 是否与 SU(2) 对易？⟨σˣσˣ⟩=⟨σʸσʸ⟩=⟨σᶻσᶻ⟩ 是否成立？
    # ============================================================
    print("\n" + "=" * 100)
    print("Q1. ρ_ij 是否与 SU(2) 对易？⟨σˣσˣ⟩=⟨σʸσʸ⟩=⟨σᶻσᶻ⟩ 是否成立？")
    print("=" * 100)

    su2_count = 0
    total_count = 0
    isospin_violations = 0
    for key, by_s in pS_cache.items():
        for s, a in by_s.items():
            total_count += 1
            if a["su2_symmetric"]:
                su2_count += 1
            # 检查 ⟨σˣσˣ⟩ ≈ ⟨σʸσʸ⟩ ≈ ⟨σᶻσᶻ⟩
            if abs(a["sxsx"] - a["szsz"]) > 1e-6 or \
               abs(a["sysy"] - a["szsz"]) > 1e-6:
                isospin_violations += 1

    print(f"\n  总采样点: {total_count}")
    print(f"  ρ_ij 与 SU(2) 对易: {su2_count}/{total_count} = {su2_count/total_count:.2%}")
    print(f"  ⟨σˣσˣ⟩=⟨σʸσʸ⟩=⟨σᶻσᶻ⟩ 违反: {isospin_violations}/{total_count} = {isospin_violations/total_count:.2%}")

    # 抽样展示
    print(f"\n  抽样展示（前 10 个 (图, 缺陷边, s) 三元组）：")
    print(f"  {'gid':>4} | {'defect':>8} | {'s':>6} | {'p_S':>10} | {'<σᶻσᶻ>':>10} | {'<σˣσˣ>':>10} | {'<σʸσʸ>':>10} | {'SU(2)':>6}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*6}-+-{'-'*10}-+-{'-'*10}-+-{'-'*10}-+-{'-'*10}-+-{'-'*6}")
    shown = 0
    for (gid, defect) in sorted(pS_cache.keys()):
        for s in [-1.5, -0.5, 0.0, 0.5]:
            a = pS_cache[(gid, defect)][s]
            print(f"  {gid:>4} | {str(defect):>8} | {s:>6.2f} | "
                  f"{a['p_S']:>10.6f} | {a['szsz']:>10.6f} | {a['sxsx']:>10.6f} | "
                  f"{a['sysy']:>10.6f} | {str(a['su2_symmetric']):>6}")
            shown += 1
            if shown >= 20:
                break
        if shown >= 20:
            break

    # ============================================================
    # Q2: p_S 如何随 s 变化
    # ============================================================
    print("\n" + "=" * 100)
    print("Q2. p_S 如何随 s 变化？")
    print("=" * 100)

    # 对每个同响应对，看 p_S 的差异
    print(f"\n  {'gid':>4} | {'e1':>8} | {'e2':>8} | {'p_S@-1.5':>10} | {'p_S@0':>10} | {'p_S@0.5':>10} | {'p_S@1.5':>10} | {'p_S_diff@0.5':>14}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*8}-+-{'-'*10}-+-{'-'*10}-+-{'-'*10}-+-{'-'*10}-+-{'-'*14}")
    for key in sorted(same_keys)[:30]:
        gid, e1, e2 = key
        a1 = pS_cache[(gid, e1)]
        a2 = pS_cache[(gid, e2)]
        def v(d, s): return d[s]['p_S']
        print(f"  {gid:>4} | {str(e1):>8} | {str(e2):>8} | "
              f"{v(a1,-1.5):>10.6f} | {v(a1,0.0):>10.6f} | "
              f"{v(a1,0.5):>10.6f} | {v(a1,1.5):>10.6f} | "
              f"{abs(v(a1,0.5)-v(a2,0.5)):>14.6f}")

    # ============================================================
    # Q3: p_S = 0 和 p_S = 1/2 的 s 条件
    # ============================================================
    print("\n" + "=" * 100)
    print("Q3. p_S = 0（+1/3）和 p_S = 1/2（-1/3）的 s 条件")
    print("=" * 100)

    # 对每个 (gid, defect)，找 p_S 最接近 0 和 1/2 的 s
    print(f"\n  {'gid':>4} | {'defect':>8} | {'s(p_S=0)':>12} | {'p_S@该 s':>12} | {'s(p_S=1/2)':>12} | {'p_S@该 s':>12} | {'<σᶻσᶻ>@p_S=0':>16}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*12}-+-{'-'*12}-+-{'-'*12}-+-{'-'*12}-+-{'-'*16}")
    for (gid, defect) in sorted(pS_cache.keys()):
        by_s = pS_cache[(gid, defect)]
        # 找 p_S 最接近 0 的 s
        s_best_0 = min(by_s.keys(), key=lambda s: abs(by_s[s]['p_S']))
        s_best_half = min(by_s.keys(), key=lambda s: abs(by_s[s]['p_S'] - 0.5))
        a0 = by_s[s_best_0]
        a_half = by_s[s_best_half]
        print(f"  {gid:>4} | {str(defect):>8} | {s_best_0:>12.2f} | "
              f"{a0['p_S']:>12.6f} | {s_best_half:>12.2f} | "
              f"{a_half['p_S']:>12.6f} | {a0['szsz']:>16.6f}")

    # ============================================================
    # Q4: 与图几何的关系
    # ============================================================
    print("\n" + "=" * 100)
    print("Q4. 谐振点 s 与图几何的关系")
    print("=" * 100)

    print(f"\n  {'gid':>4} | {'defect':>8} | {'边数':>4} | {'桥数':>4} | {'defect度对':>12} | {'s(p_S=0)':>12} | {'s(p_S=1/2)':>12} | {'Laplacian[1]':>12}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*4}-+-{'-'*4}-+-{'-'*12}-+-{'-'*12}-+-{'-'*12}-+-{'-'*12}")
    for (gid, defect) in sorted(pS_cache.keys()):
        G = graphs[gid]
        n_bridges = len(list(nx.bridges(G)))
        degs = sorted([G.degree(defect[0]), G.degree(defect[1])])
        L = nx.laplacian_matrix(G).astype(float).toarray()
        L_eigs = sorted(np.linalg.eigvalsh(L))
        L1 = L_eigs[1] if len(L_eigs) > 1 else 0
        by_s = pS_cache[(gid, defect)]
        s_best_0 = min(by_s.keys(), key=lambda s: abs(by_s[s]['p_S']))
        s_best_half = min(by_s.keys(), key=lambda s: abs(by_s[s]['p_S'] - 0.5))
        print(f"  {gid:>4} | {str(defect):>8} | {len(list(G.edges())):>4} | "
              f"{n_bridges:>4} | {str(tuple(degs)):>12} | "
              f"{s_best_0:>12.2f} | {s_best_half:>12.2f} | {L1:>12.4f}")

    # ============================================================
    # Q5: 为什么是 ±1/3
    # ============================================================
    print("\n" + "=" * 100)
    print("Q5. 为什么是 ±1/3，不是其他值？")
    print("=" * 100)

    # 扫描所有 s 点，统计 ⟨σᶻσᶻ⟩ 的值分布
    print(f"\n  所有 ⟨σᶻσᶻ⟩ 值的直方图：")
    all_szsz = []
    for key, by_s in pS_cache.items():
        for s, a in by_s.items():
            all_szsz.append(a['szsz'])
    all_szsz = np.array(all_szsz)
    print(f"  总数: {len(all_szsz)}")
    print(f"  范围: [{all_szsz.min():.4f}, {all_szsz.max():.4f}]")

    # 统计特殊值命中
    print(f"\n  特殊值命中统计：")
    targets = {
        "+1/3": 1/3,
        "-1/3": -1/3,
        "-1": -1.0,
        "0": 0.0,
        "+1": 1.0,
        "+1/2": 0.5,
    }
    print(f"  {'值':>8} | {'命中数':>6} | {'占比':>8}")
    print(f"  {'-'*8}-+-{'-'*6}-+-{'-'*8}")
    for name, val in targets.items():
        hits = np.sum(np.abs(all_szsz - val) < 1e-6)
        print(f"  {name:>8} | {hits:>6} | {hits/len(all_szsz):>8.3%}")

    # ============================================================
    # 为什么是 1/3：三重态投影的代数
    # ============================================================
    print("\n" + "=" * 100)
    print("代数说明：1/3 = 三重态投影")
    print("=" * 100)

    print("""
  对于自旋 1/2 体系，总自旋 S = (σ₁ + σ₂)/2。
  单态：S=0，三重态：S=1，三个分量 |T₊⟩, |T₀⟩, |T₋⟩。

  在 S_z = 0 的 SU(2) 单态基底下：
    ⟨S|σᶻσᶻ|S⟩ = -1
    ⟨T₊|σᶻσᶻ|T₊⟩ = +1
    ⟨T₀|σᶻσᶻ|T₀⟩ = -1
    ⟨T₋|σᶻσᶻ|T₋⟩ = +1

  SU(2) 对称混合态 ρ = p_S|S⟩⟨S| + (p_T/3)(|T₊⟩⟨T₊|+|T₀⟩⟨T₀|+|T₋⟩⟨T₋|)
    ⟨σᶻσᶻ⟩ = p_S(-1) + (p_T/3)(1-1+1) = -p_S + p_T/3

  p_S + p_T = 1:
    ⟨σᶻσᶻ⟩ = -p_S + (1-p_S)/3 = 1/3 - 4p_S/3

  故：
    ⟨σᶻσᶻ⟩ = +1/3  ⟺  p_S = 0    （纯三重态）
    ⟨σᶻσᶻ⟩ = -1/3  ⟺  p_S = 1/2  （单态-三重态等量混合）
    ⟨σᶻσᶻ⟩ = -1    ⟺  p_S = 1    （纯单态）

  关键：±1/3 不是任意值，它们是 SU(2) 单态和三重态投影的精确代数投影。
  这就是"谐振点"的数学本质：缺陷边的约化态落在单态-三重态混合空间的特定点上。
""")

    # ============================================================
    # 导出
    # ============================================================
    out = {}
    for key, by_s in pS_cache.items():
        gid, defect = key
        out[f"{gid}_{defect}"] = {
            "s_vals": list(s_vals),
            "p_S": [by_s[s]["p_S"] for s in s_vals],
            "szsz": [by_s[s]["szsz"] for s in s_vals],
            "su2_symmetric": all(by_s[s]["su2_symmetric"] for s in s_vals),
        }
    out_path = os.path.join(WORK_DIR, "照妖镜_v7_pS曲线.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("v7.0 完成。±1/3 的解析条件：p_S = 0（纯三重态）和 p_S = 1/2（等量混合）。")
    print("=" * 100)


if __name__ == "__main__":
    main()