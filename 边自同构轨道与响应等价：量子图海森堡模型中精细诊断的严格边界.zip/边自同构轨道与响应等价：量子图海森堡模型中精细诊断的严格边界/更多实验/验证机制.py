# -*- coding: utf-8 -*-
"""
验证机制：桥 + 简并 + 空间选择 → 诊断量差异
"""

import sys, io, itertools
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from collections import Counter

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

I2 = np.eye(2, dtype=complex)
SX = np.array([[0,1],[1,0]], dtype=complex)
SY = np.array([[0,-1j],[1j,0]], dtype=complex)
SZ = np.array([[1,0],[0,-1]], dtype=complex)


def op_on_site(op, site, N):
    ops = [I2]*N; ops[site] = op
    out = ops[0]
    for o in ops[1:]: out = np.kron(out, o)
    return out

def build_ops(N):
    return ([op_on_site(SX,i,N) for i in range(N)],
            [op_on_site(SY,i,N) for i in range(N)],
            [op_on_site(SZ,i,N) for i in range(N)])

def edge_matrix(i, j, SXo, SYo, SZo):
    return SXo[i]@SXo[j] + SYo[i]@SYo[j] + SZo[i]@SZo[j]

def sz0_basis(N):
    n_up = N//2
    basis = []
    for comb in itertools.combinations(range(N), n_up):
        s = [0]*N
        for i in comb: s[i] = 1
        basis.append(tuple(s))
    return basis

def build_H_sz0(N, edges, couplings, SXo, SYo, SZo):
    basis = sz0_basis(N)
    dim = len(basis); idx = {s:i for i,s in enumerate(basis)}
    H = np.zeros((dim, dim))
    for i, state in enumerate(basis):
        for (a,b), J in zip(edges, couplings):
            if state[a] == state[b]:
                H[i,i] += J
            else:
                H[i,i] -= J
                new = list(state); new[a], new[b] = new[b], new[a]
                H[i, idx[tuple(new)]] += 2.0*J
    return H, basis

def gs_degeneracy(H, tol=1e-8):
    evals = np.linalg.eigvalsh(H)
    return int(np.sum(np.abs(evals - evals[0]) < tol))


def main():
    # 旧方法独有的 8 对：检查缺陷边是不是桥
    cases = [
        # (N, 边集, 缺陷边, 标签)
        (6, [(0,1),(0,2),(0,3),(0,4),(0,5),(1,2),(1,3),(2,3),(4,5)], (0,1), "图69-对A"),
        (6, [(0,1),(0,2),(0,3),(0,4),(0,5),(1,2),(1,3),(2,3),(4,5)], (1,2), "图69-对B"),
    ]

    # 图108 的边集 (K6 减 (3,5),(4,5))
    K6 = nx.complete_graph(6)
    K6.remove_edges_from([(3,5),(4,5)])
    g108_edges = [tuple(sorted(e)) for e in K6.edges()]
    # 图106 的边集 (K6 减 (2,5),(3,4))
    K6b = nx.complete_graph(6)
    K6b.remove_edges_from([(2,5),(3,4)])
    g106_edges = [tuple(sorted(e)) for e in K6b.edges()]

    # 检测桥
    for gid, edges in [(108, g108_edges), (106, g106_edges)]:
        G = nx.Graph(edges)
        bridges = set(map(frozenset, nx.bridges(G)))
        print(f"\n图 {gid}:")
        print(f"  边数: {len(edges)}")
        print(f"  桥数: {len(bridges)}")
        print(f"  桥列表: {[tuple(b) for b in bridges]}")
        # 检查缺陷边（先取一条非桥的边做示例）
        for e in edges[:3]:
            is_b = frozenset(e) in bridges
            print(f"  边 {e}: {'桥' if is_b else '非桥'}")

    # 检查 s=0 时的基态简并
    print("\n" + "="*60)
    print("s=0 时的基态简并度（完整空间 vs Sz=0 子空间）")
    print("="*60)
    N = 6
    SXo, SYo, SZo = build_ops(N)
    for gid, edges in [(108, g108_edges), (106, g106_edges)]:
        G = nx.Graph(edges)
        bridges = set(map(frozenset, nx.bridges(G)))
        for defect in edges[:5]:
            is_b = frozenset(defect) in bridges
            # s=0：缺陷边耦合 0
            couplings = [0.0 if e == defect else 1.0 for e in edges]
            # 完整空间
            H_edges = {e: edge_matrix(e[0], e[1], SXo, SYo, SZo) for e in edges}
            H_full = sum(c * H_edges[e] for e, c in zip(edges, couplings))
            deg_full = gs_degeneracy(H_full)
            # Sz=0 子空间
            H_sz0, _ = build_H_sz0(N, edges, couplings, SXo, SYo, SZo)
            deg_sz0 = gs_degeneracy(H_sz0)
            print(f"  图{gid} 缺陷边{defect} 桥={is_b}: "
                  f"完整空间简并={deg_full}, Sz=0 简并={deg_sz0}")


if __name__ == "__main__":
    main()