#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
拓扑穷举：什么关系拓扑会给出质量缺口？
============================================

前几轮结果：
- 单环：能隙 = (N/2)·J（周长律）
- 格点 L=2→3：能隙下降（2.0→1.186）
- 链：能隙 = 0

核心追问：
1. 能隙在热力学极限下趋于零、常数、还是发散？
2. 激发态是集体的还是局域的？
3. 对合自同构的数量与能隙有什么关系？
4. 什么关系拓扑给出常数能隙？

穷举拓扑：
- 环 C_N
- 链 P_N
- 星 S_N
- 完全图 K_N
- 完全二分图 K_{m,m}
- 二维格点 L×L
- 三角形格点
- 分形（Sierpiński gasket）
- 小世界图
- 随机图
- 树
- 双曲格点（近似）

原则：
- 只查同与不同
- 不拟合，不回归，不预设
- 标准物理与关系本体论并排
- 数据说话，只要真相

运行：
    python 拓扑穷举_质量缺口追问.py
    python 拓扑穷举_质量缺口追问.py --max_edges 14
"""

import sys
import io
import json
import itertools
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from scipy.sparse.linalg import eigsh
from scipy.sparse import csr_matrix
from collections import defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)


I2 = np.eye(2, dtype=complex)
SX = 0.5 * np.array([[0, 1], [1, 0]], dtype=complex)
SY = 0.5 * np.array([[0, -1j], [1j, 0]], dtype=complex)
SZ = 0.5 * np.array([[1, 0], [0, -1]], dtype=complex)


def op_on_edge(op, edge_idx, n_edges):
    ops = [I2] * n_edges
    ops[edge_idx] = op
    result = ops[0]
    for o in ops[1:]:
        result = np.kron(result, o)
    return result


# ============================================================
# 纯边态哈密顿量
# ============================================================

def build_pure_edge_hamiltonian(G, J=1.0):
    edges = [tuple(sorted(e)) for e in G.edges()]
    n_edges = len(edges)
    edge_to_idx = {e: i for i, e in enumerate(edges)}
    dim = 2 ** n_edges
    H = np.zeros((dim, dim), dtype=complex)
    cycles = nx.cycle_basis(G)
    for cycle in cycles:
        cycle_edges = []
        for i in range(len(cycle)):
            e = tuple(sorted((cycle[i], cycle[(i + 1) % len(cycle)])))
            if e in edge_to_idx:
                cycle_edges.append(edge_to_idx[e])
        if len(cycle_edges) < 2:
            continue
        for i, e1 in enumerate(cycle_edges):
            for j, e2 in enumerate(cycle_edges):
                if i >= j:
                    continue
                for S_a, S_b in [(SX, SX), (SY, SY), (SZ, SZ)]:
                    op_a = op_on_edge(S_a, e1, n_edges)
                    op_b = op_on_edge(S_b, e2, n_edges)
                    H -= J * (op_a @ op_b)
    return H, edges, cycles


def compute_gap_and_ipr(H, tol=1e-8):
    """计算能隙和激发态的逆参与比（IPR）。"""
    dim = H.shape[0]
    if dim < 3:
        return 0.0, 0, 0.0, 0.0
    if dim <= 2000:
        evals, evecs = np.linalg.eigh(H)
        E0 = evals[0]
        deg = int(np.sum(np.abs(evals - E0) < tol))
        gap = evals[deg] - E0 if deg < len(evals) else 0.0
        # 第一激发态的 IPR
        if deg < len(evals):
            psi = evecs[:, deg]
            ipr = float(np.sum(np.abs(psi) ** 4))
        else:
            ipr = 0.0
        return float(gap), deg, ipr, dim
    else:
        H_sp = csr_matrix(H)
        try:
            evals, evecs = eigsh(H_sp, k=min(6, dim - 1), which="SA")
            idx = np.argsort(evals)
            evals = evals[idx]
            evecs = evecs[:, idx]
            E0 = evals[0]
            deg = int(np.sum(np.abs(evals - E0) < tol))
            gap = evals[deg] - E0 if deg < len(evals) else 0.0
            if deg < evecs.shape[1]:
                psi = evecs[:, deg]
                ipr = float(np.sum(np.abs(psi) ** 4))
            else:
                ipr = 0.0
            return float(gap), deg, ipr, dim
        except Exception:
            evals, evecs = np.linalg.eigh(H)
            E0 = evals[0]
            deg = int(np.sum(np.abs(evals - E0) < tol))
            gap = evals[deg] - E0 if deg < len(evals) else 0.0
            if deg < len(evals):
                psi = evecs[:, deg]
                ipr = float(np.sum(np.abs(psi) ** 4))
            else:
                ipr = 0.0
            return float(gap), deg, ipr, dim


# ============================================================
# 对合自同构计数
# ============================================================

def count_involution_images(G):
    nodes = list(G.nodes())
    edges = [tuple(sorted(e)) for e in G.edges()]
    adj = nx.to_numpy_array(G)
    n_inv = 0
    pairs = set()
    for p in itertools.permutations(nodes):
        P = np.zeros((len(nodes), len(nodes)))
        for i, pi in enumerate(p):
            P[i, pi] = 1
        if not np.allclose(P @ adj @ P.T, adj):
            continue
        # 检查是否对合
        is_inv = all(p[p[i]] == i for i in range(len(p)))
        if not is_inv:
            continue
        if all(p[i] == i for i in range(len(p))):
            continue
        n_inv += 1
        mapping = {i: p[i] for i in range(len(p))}
        for e in edges:
            e2 = tuple(sorted((mapping[e[0]], mapping[e[1]])))
            if e2 != e and G.has_edge(*e2):
                pairs.add(tuple(sorted([e, e2])))
    return n_inv, len(pairs)


# ============================================================
# 图生成
# ============================================================

def make_ring(N):
    return nx.cycle_graph(N)


def make_chain(N):
    return nx.path_graph(N)


def make_star(N):
    return nx.star_graph(N - 1)


def make_complete(N):
    return nx.complete_graph(N)


def make_bipartite(N):
    if N % 2 == 0:
        return nx.complete_bipartite_graph(N // 2, N // 2)
    return None


def make_lattice(L):
    return nx.grid_2d_graph(L, L)


def make_triangular_lattice(L):
    """三角形格点。"""
    G = nx.Graph()
    for i in range(L):
        for j in range(L):
            node = i * L + j
            if j + 1 < L:
                G.add_edge(node, i * L + (j + 1))
            if i + 1 < L:
                G.add_edge(node, (i + 1) * L + j)
            if i + 1 < L and j + 1 < L:
                G.add_edge(node, (i + 1) * L + (j + 1))
    return G


def make_sierpinski(level):
    """Sierpiński gasket。"""
    G = nx.Graph()
    G.add_edges_from([(0, 1), (1, 2), (2, 0)])
    for _ in range(level):
        G = nx.sierpinski_gasket_graph(G) if hasattr(nx, 'sierpinski_gasket_graph') else G
    return G


def make_smallworld(N, k=4, p=0.3):
    return nx.watts_strogatz_graph(N, k, p, seed=42)


def make_random(N, p=0.5):
    G = nx.gnp_random_graph(N, p, seed=42)
    if nx.is_connected(G):
        return G
    return None


def make_tree(N):
    return nx.balanced_tree(2, int(np.log2(N)))


# ============================================================
# 主流程
# ============================================================

def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--max_edges", type=int, default=14,
                        help="最大边数（维度 2^max_edges）")
    parser.add_argument("--J", type=float, default=1.0)
    parser.add_argument("--out", type=str, default="拓扑穷举结果.json")
    args = parser.parse_args()

    max_edges = args.max_edges
    print("=" * 78)
    print("  拓扑穷举：什么关系拓扑会给出质量缺口？")
    print("=" * 78)
    print(f"  最大边数: {max_edges}（维度 2^{max_edges} = {2**max_edges}）")
    print(f"  J = {args.J}")
    print()

    all_results = []

    # ============================================================
    # 1. 单环 C_N
    # ============================================================
    print("=" * 78)
    print("  1. 单环 C_N")
    print("=" * 78)
    print()
    print(f"  {'N':<6}{'边数':<8}{'能隙':<16}{'能隙/N':<12}{'对合像':<10}{'IPR':<12}")
    print(f"  {'-'*6}{'-'*8}{'-'*16}{'-'*12}{'-'*10}{'-'*12}")

    for N in range(3, max_edges + 1):
        G = make_ring(N)
        n_edges = G.number_of_edges()
        if n_edges > max_edges:
            continue
        H, edges, cycles = build_pure_edge_hamiltonian(G, J=args.J)
        gap, deg, ipr, dim = compute_gap_and_ipr(H)
        n_inv, n_pairs = count_involution_images(G)
        print(f"  {N:<6}{n_edges:<8}{gap:<16.6f}{gap/N:<12.6f}"
              f"{n_pairs:<10}{ipr:<12.6f}")
        all_results.append({
            "family": "ring", "N": N, "n_edges": n_edges,
            "gap": gap, "gap_over_N": gap / N,
            "deg": deg, "ipr": ipr, "dim": dim,
            "n_involution_pairs": n_pairs,
        })
    print()

    # ============================================================
    # 2. 链 P_N
    # ============================================================
    print("=" * 78)
    print("  2. 链 P_N")
    print("=" * 78)
    print()
    print(f"  {'N':<6}{'边数':<8}{'能隙':<16}{'对合像':<10}{'IPR':<12}")
    print(f"  {'-'*6}{'-'*8}{'-'*16}{'-'*10}{'-'*12}")

    for N in range(3, max_edges + 2):
        G = make_chain(N)
        n_edges = G.number_of_edges()
        if n_edges > max_edges:
            continue
        H, edges, cycles = build_pure_edge_hamiltonian(G, J=args.J)
        gap, deg, ipr, dim = compute_gap_and_ipr(H)
        n_inv, n_pairs = count_involution_images(G)
        print(f"  {N:<6}{n_edges:<8}{gap:<16.6f}{n_pairs:<10}{ipr:<12.6f}")
        all_results.append({
            "family": "chain", "N": N, "n_edges": n_edges,
            "gap": gap, "deg": deg, "ipr": ipr, "dim": dim,
            "n_involution_pairs": n_pairs,
        })
    print()

    # ============================================================
    # 3. 星 S_N
    # ============================================================
    print("=" * 78)
    print("  3. 星 S_N")
    print("=" * 78)
    print()
    print(f"  {'N':<6}{'边数':<8}{'能隙':<16}{'对合像':<10}{'IPR':<12}")
    print(f"  {'-'*6}{'-'*8}{'-'*16}{'-'*10}{'-'*12}")

    for N in range(3, max_edges + 2):
        G = make_star(N)
        n_edges = G.number_of_edges()
        if n_edges > max_edges:
            continue
        H, edges, cycles = build_pure_edge_hamiltonian(G, J=args.J)
        gap, deg, ipr, dim = compute_gap_and_ipr(H)
        n_inv, n_pairs = count_involution_images(G)
        print(f"  {N:<6}{n_edges:<8}{gap:<16.6f}{n_pairs:<10}{ipr:<12.6f}")
        all_results.append({
            "family": "star", "N": N, "n_edges": n_edges,
            "gap": gap, "deg": deg, "ipr": ipr, "dim": dim,
            "n_involution_pairs": n_pairs,
        })
    print()

    # ============================================================
    # 4. 完全图 K_N
    # ============================================================
    print("=" * 78)
    print("  4. 完全图 K_N")
    print("=" * 78)
    print()
    print(f"  {'N':<6}{'边数':<8}{'能隙':<16}{'对合像':<10}{'IPR':<12}")
    print(f"  {'-'*6}{'-'*8}{'-'*16}{'-'*10}{'-'*12}")

    for N in range(3, 8):
        G = make_complete(N)
        n_edges = G.number_of_edges()
        if n_edges > max_edges:
            continue
        H, edges, cycles = build_pure_edge_hamiltonian(G, J=args.J)
        gap, deg, ipr, dim = compute_gap_and_ipr(H)
        n_inv, n_pairs = count_involution_images(G)
        print(f"  {N:<6}{n_edges:<8}{gap:<16.6f}{n_pairs:<10}{ipr:<12.6f}")
        all_results.append({
            "family": "complete", "N": N, "n_edges": n_edges,
            "gap": gap, "deg": deg, "ipr": ipr, "dim": dim,
            "n_involution_pairs": n_pairs,
        })
    print()

    # ============================================================
    # 5. 二维格点 L×L
    # ============================================================
    print("=" * 78)
    print("  5. 二维格点 L×L")
    print("=" * 78)
    print()
    print(f"  {'L':<6}{'边数':<8}{'环数':<8}{'能隙':<16}{'能隙/L':<12}{'对合像':<10}{'IPR':<12}")
    print(f"  {'-'*6}{'-'*8}{'-'*8}{'-'*16}{'-'*12}{'-'*10}{'-'*12}")

    for L in range(2, 10):
        G = make_lattice(L)
        n_edges = G.number_of_edges()
        if n_edges > max_edges:
            break
        H, edges, cycles = build_pure_edge_hamiltonian(G, J=args.J)
        gap, deg, ipr, dim = compute_gap_and_ipr(H)
        n_inv, n_pairs = count_involution_images(G)
        print(f"  {L:<6}{n_edges:<8}{len(cycles):<8}{gap:<16.6f}"
              f"{gap/L:<12.6f}{n_pairs:<10}{ipr:<12.6f}")
        all_results.append({
            "family": "lattice", "L": L, "N": L*L,
            "n_edges": n_edges, "n_cycles": len(cycles),
            "gap": gap, "gap_over_L": gap / L,
            "deg": deg, "ipr": ipr, "dim": dim,
            "n_involution_pairs": n_pairs,
        })
    print()

    # ============================================================
    # 6. 三角形格点 L×L
    # ============================================================
    print("=" * 78)
    print("  6. 三角形格点 L×L")
    print("=" * 78)
    print()
    print(f"  {'L':<6}{'边数':<8}{'环数':<8}{'能隙':<16}{'能隙/L':<12}{'对合像':<10}{'IPR':<12}")
    print(f"  {'-'*6}{'-'*8}{'-'*8}{'-'*16}{'-'*12}{'-'*10}{'-'*12}")

    for L in range(2, 8):
        G = make_triangular_lattice(L)
        n_edges = G.number_of_edges()
        if n_edges > max_edges:
            break
        H, edges, cycles = build_pure_edge_hamiltonian(G, J=args.J)
        gap, deg, ipr, dim = compute_gap_and_ipr(H)
        n_inv, n_pairs = count_involution_images(G)
        print(f"  {L:<6}{n_edges:<8}{len(cycles):<8}{gap:<16.6f}"
              f"{gap/L:<12.6f}{n_pairs:<10}{ipr:<12.6f}")
        all_results.append({
            "family": "triangular", "L": L, "N": L*L,
            "n_edges": n_edges, "n_cycles": len(cycles),
            "gap": gap, "gap_over_L": gap / L,
            "deg": deg, "ipr": ipr, "dim": dim,
            "n_involution_pairs": n_pairs,
        })
    print()

    # ============================================================
    # 7. 小世界图、随机图、树
    # ============================================================
    print("=" * 78)
    print("  7. 小世界图、随机图、树")
    print("=" * 78)
    print()
    print(f"  {'家族':<12}{'N':<6}{'边数':<8}{'能隙':<16}{'对合像':<10}{'IPR':<12}")
    print(f"  {'-'*12}{'-'*6}{'-'*8}{'-'*16}{'-'*10}{'-'*12}")

    for N in range(4, max_edges + 2):
        for fam_name, fam_func in [("smallworld", make_smallworld),
                                    ("random", make_random),
                                    ("tree", make_tree)]:
            try:
                if fam_name == "smallworld":
                    G = fam_func(N, k=4, p=0.3)
                elif fam_name == "random":
                    G = fam_func(N, p=0.5)
                else:
                    G = fam_func(N)
            except Exception:
                continue
            if G is None or not nx.is_connected(G):
                continue
            n_edges = G.number_of_edges()
            if n_edges > max_edges:
                continue
            H, edges, cycles = build_pure_edge_hamiltonian(G, J=args.J)
            gap, deg, ipr, dim = compute_gap_and_ipr(H)
            n_inv, n_pairs = count_involution_images(G)
            print(f"  {fam_name:<12}{N:<6}{n_edges:<8}{gap:<16.6f}"
                  f"{n_pairs:<10}{ipr:<12.6f}")
            all_results.append({
                "family": fam_name, "N": N, "n_edges": n_edges,
                "gap": gap, "deg": deg, "ipr": ipr, "dim": dim,
                "n_involution_pairs": n_pairs,
            })
    print()

    # ============================================================
    # 8. 并排：能隙 vs 系统尺寸
    # ============================================================
    print("=" * 78)
    print("  8. 并排：能隙 vs 系统尺寸")
    print("=" * 78)
    print()

    # 按家族分组
    by_family = defaultdict(list)
    for r in all_results:
        by_family[r["family"]].append(r)

    print(f"  {'家族':<14}{'标度律':<20}{'能隙 vs 尺寸':<40}")
    print(f"  {'-'*14}{'-'*20}{'-'*40}")

    for fam, recs in by_family.items():
        recs_sorted = sorted(recs, key=lambda x: x.get("N", x.get("L", 0)))
        gaps = [r["gap"] for r in recs_sorted]
        sizes = [r.get("N", r.get("L", 0)) for r in recs_sorted]

        # 判断标度律
        if len(gaps) < 2:
            scale = "数据不足"
        elif all(abs(g) < 1e-6 for g in gaps):
            scale = "零"
        elif len(gaps) >= 3:
            # 检查是否线性
            ratios = [gaps[i+1] / gaps[i] if gaps[i] > 1e-10 else 0
                      for i in range(len(gaps)-1)]
            if all(abs(r - 1.0) < 0.2 for r in ratios if r > 0):
                scale = "常数"
            elif all(r > 1.0 for r in ratios if r > 0):
                scale = "增长"
            elif all(r < 1.0 for r in ratios if r > 0):
                scale = "衰减"
            else:
                scale = "混合"
        else:
            scale = "数据不足"

        gaps_str = ",".join(f"{g:.3f}" for g in gaps)
        print(f"  {fam:<14}{scale:<20}{gaps_str:<40}")
    print()

    # ============================================================
    # 9. 保存
    # ============================================================
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump({"results": all_results}, f,
                  ensure_ascii=False, indent=2, default=str)
    print(f"已保存: {args.out}")
    print()
    print("=" * 78)
    print("  追问继续。数据说话。只要真相。")
    print("=" * 78)


if __name__ == "__main__":
    main()