#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
32 对假阴性解剖：寻找比轨道更粗的等价关系
==============================================

背景：
    轨道精确率 = 1.0000（同轨道必同响应，零假阳性）
    轨道召回率 = 0.9709（32 对响应相同但轨道不同）
    这 32 对是唯一未解决问题。

核心追问：
    1. 这 32 对有什么共同结构？
    2. 它们是否由某种“非对合”的自同构产生？
    3. 它们是否由自同构的复合产生？
    4. 它们是否在某个“商图”上等价？
    5. 它们是否与图的补图有关？
    6. 它们是否与边的“轨道对”有关？
    7. 它们是否在某个更粗的边分类下相同？

方法：
    穷举 N=6 全部 112 连通图。
    找 32 对假阴性。
    对每一对，穷举所有可能的关系特征。
    并排输出所有结果。

原则：
    只查同与不同。不拟合，不回归，不预设。
    穷举一切可能，不遗漏一个死角。
    数据说话，只要真相。

运行：
    python 32对假阴性解剖.py
"""

import sys
import io
import json
import itertools
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from collections import defaultdict, Counter
from networkx.algorithms.isomorphism import GraphMatcher

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)


I2 = np.eye(2, dtype=complex)
SX = np.array([[0, 1], [1, 0]], dtype=complex)
SY = np.array([[0, -1j], [1j, 0]], dtype=complex)
SZ = np.array([[1, 0], [0, -1]], dtype=complex)


def op_on_site(op, site, N):
    ops = [I2] * N
    ops[site] = op
    out = ops[0]
    for o in ops[1:]:
        out = np.kron(out, o)
    return out


def build_site_ops(N):
    return ([op_on_site(SX, i, N) for i in range(N)],
            [op_on_site(SY, i, N) for i in range(N)],
            [op_on_site(SZ, i, N) for i in range(N)])


def edge_matrix(i, j, SX_ops, SY_ops, SZ_ops, rule="heisenberg", delta=1.0):
    if rule == "heisenberg":
        return SX_ops[i] @ SX_ops[j] + SY_ops[i] @ SY_ops[j] + SZ_ops[i] @ SZ_ops[j]
    elif rule == "xxz":
        return SX_ops[i] @ SX_ops[j] + SY_ops[i] @ SY_ops[j] + delta * (SZ_ops[i] @ SZ_ops[j])
    elif rule == "ising":
        return SZ_ops[i] @ SZ_ops[j]
    elif rule == "xy":
        return SX_ops[i] @ SX_ops[j] + SY_ops[i] @ SY_ops[j]
    raise ValueError(f"未知规则: {rule}")


def ground_state_density(H, tol=1e-8):
    evals, evecs = eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < tol))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    return E0, rho, deg


def edge_correlations(rho, edges, SZ_ops):
    C = {}
    for (i, j) in edges:
        op = SZ_ops[i] @ SZ_ops[j]
        C[(i, j)] = float(np.real(np.trace(rho @ op)))
    return C


def compute_sorted_curve(G, defect_edge, s_vals, SX_ops, SY_ops, SZ_ops,
                         rule="heisenberg"):
    N = G.number_of_nodes()
    edges = [tuple(sorted(e)) for e in G.edges()]
    H_edges = {e: edge_matrix(e[0], e[1], SX_ops, SY_ops, SZ_ops, rule)
               for e in edges}
    H0 = sum(H_edges.values())
    M_defect = H_edges[defect_edge]
    curve = []
    for s in s_vals:
        H = H0 + (s - 1.0) * M_defect
        E0, rho, deg = ground_state_density(H)
        C = edge_correlations(rho, edges, SZ_ops)
        curve.append(tuple(np.round(sorted(C.values()), 12)))
    return curve


def find_automorphisms(G):
    nodes = list(G.nodes())
    adj = nx.to_numpy_array(G)
    perms = []
    for p in itertools.permutations(nodes):
        P = np.zeros((len(nodes), len(nodes)))
        for i, pi in enumerate(p):
            P[i, pi] = 1
        if np.allclose(P @ adj @ P.T, adj):
            perms.append(p)
    return perms


def find_edge_orbits(G):
    nodes = list(G.nodes())
    edges = [tuple(sorted(e)) for e in G.edges()]
    perms = find_automorphisms(G)
    orbit_id = {e: None for e in edges}
    oid = 0
    for e in edges:
        if orbit_id[e] is not None:
            continue
        orbit_id[e] = oid
        for p in perms:
            mapping = {nodes[i]: p[i] for i in range(len(nodes))}
            e2 = tuple(sorted((mapping[e[0]], mapping[e[1]])))
            if G.has_edge(*e2):
                orbit_id[e2] = oid
        oid += 1
    return orbit_id


def find_involution_pairs(G):
    nodes = list(G.nodes())
    edges = [tuple(sorted(e)) for e in G.edges()]
    perms = find_automorphisms(G)
    pairs = set()
    for p in perms:
        if not all(p[p[i]] == i for i in range(len(p))):
            continue
        if all(p[i] == i for i in range(len(p))):
            continue
        mapping = {i: p[i] for i in range(len(p))}
        for e in edges:
            e2 = tuple(sorted((mapping[e[0]], mapping[e[1]])))
            if e2 != e and G.has_edge(*e2):
                pairs.add(tuple(sorted([e, e2])))
    return pairs


def get_112_connected_graphs():
    atlas = nx.graph_atlas_g()
    return [G for G in atlas
            if G.number_of_nodes() == 6 and nx.is_connected(G)]


# ============================================================
# 32 对的穷举解剖
# ============================================================

def analyze_pair(G, e1, e2, orbits, inv_pairs, aut_perms):
    """
    对一对假阴性边，穷举所有可能的关系特征。
    """
    nodes = list(G.nodes())
    edges = [tuple(sorted(e)) for e in G.edges()]

    results = {}

    # ---- 1. 轨道信息 ----
    results["orbit_e1"] = orbits[e1]
    results["orbit_e2"] = orbits[e2]

    # ---- 2. 对合信息 ----
    results["is_involution_pair"] = tuple(sorted([e1, e2])) in inv_pairs

    # ---- 3. 是否存在任意自同构映射 e1 到 e2？ ----
    found_aut = False
    for p in aut_perms:
        mapping = {nodes[i]: p[i] for i in range(len(nodes))}
        e2_mapped = tuple(sorted((mapping[e1[0]], mapping[e1[1]])))
        if e2_mapped == e2:
            found_aut = True
            break
    results["has_automorphism_mapping"] = found_aut

    # ---- 4. 是否存在非对合自同构映射 e1 到 e2？ ----
    found_non_inv_aut = False
    for p in aut_perms:
        is_inv = all(p[p[i]] == i for i in range(len(nodes)))
        if is_inv:
            continue
        mapping = {nodes[i]: p[i] for i in range(len(nodes))}
        e2_mapped = tuple(sorted((mapping[e1[0]], mapping[e1[1]])))
        if e2_mapped == e2:
            found_non_inv_aut = True
            break
    results["has_non_involution_automorphism"] = found_non_inv_aut

    # ---- 5. 局部特征 ----
    u1, v1 = e1
    u2, v2 = e2
    results["deg_pair_e1"] = tuple(sorted([G.degree(u1), G.degree(v1)]))
    results["deg_pair_e2"] = tuple(sorted([G.degree(u2), G.degree(v2)]))

    # 公共邻居
    cn1 = len(set(G.neighbors(u1)) & set(G.neighbors(v1)))
    cn2 = len(set(G.neighbors(u2)) & set(G.neighbors(v2)))
    results["common_neighbors_e1"] = cn1
    results["common_neighbors_e2"] = cn2

    # 二跳子图度序列
    def two_hop_deg(e):
        u, v = e
        s = set()
        for w in G.neighbors(u):
            if w != v:
                s.add(G.degree(w))
        for w in G.neighbors(v):
            if w != u:
                s.add(G.degree(w))
        return tuple(sorted(s))
    results["two_hop_e1"] = two_hop_deg(e1)
    results["two_hop_e2"] = two_hop_deg(e2)

    # 邻居度序列
    def nbr_deg_seq(e):
        u, v = e
        nb = [G.degree(w) for w in G.neighbors(u) if w != v]
        nb += [G.degree(w) for w in G.neighbors(v) if w != u]
        return tuple(sorted(nb))
    results["nbr_deg_seq_e1"] = nbr_deg_seq(e1)
    results["nbr_deg_seq_e2"] = nbr_deg_seq(e2)

    # ---- 6. 删除后 ----
    H1 = G.copy(); H1.remove_edge(*e1)
    H2 = G.copy(); H2.remove_edge(*e2)
    results["components_after_del_e1"] = nx.number_connected_components(H1)
    results["components_after_del_e2"] = nx.number_connected_components(H2)

    # ---- 7. 收缩后 ----
    try:
        G1c = nx.contracted_edge(G, e1, self_loops=False)
        G2c = nx.contracted_edge(G, e2, self_loops=False)
        results["contraction_deg_seq_e1"] = tuple(sorted(dict(G1c.degree()).values()))
        results["contraction_deg_seq_e2"] = tuple(sorted(dict(G2c.degree()).values()))
    except Exception:
        results["contraction_deg_seq_e1"] = ()
        results["contraction_deg_seq_e2"] = ()

    # ---- 8. 环参与 ----
    cycles = nx.cycle_basis(G)
    def cycles_with_edge(e):
        result = []
        for cycle in cycles:
            cycle_edges = []
            for i in range(len(cycle)):
                ce = tuple(sorted((cycle[i], cycle[(i + 1) % len(cycle)])))
                cycle_edges.append(ce)
            if tuple(sorted(e)) in cycle_edges:
                result.append(len(cycle))
        return tuple(sorted(result))
    results["cycles_e1"] = cycles_with_edge(e1)
    results["cycles_e2"] = cycles_with_edge(e2)

    # ---- 9. 全局：边介数 ----
    try:
        bc = nx.edge_betweenness_centrality(G)
        results["bc_e1"] = round(bc.get(e1, bc.get((e1[1], e1[0]), 0.0)), 6)
        results["bc_e2"] = round(bc.get(e2, bc.get((e2[1], e2[0]), 0.0)), 6)
    except Exception:
        results["bc_e1"] = 0.0
        results["bc_e2"] = 0.0

    # ---- 10. 端点离心率 ----
    try:
        ecc = nx.eccentricity(G)
        results["ecc_sum_e1"] = ecc[u1] + ecc[v1]
        results["ecc_sum_e2"] = ecc[u2] + ecc[v2]
    except Exception:
        results["ecc_sum_e1"] = 0
        results["ecc_sum_e2"] = 0

    # ---- 11. 端点聚类系数 ----
    results["cc_sum_e1"] = round(nx.clustering(G, u1) + nx.clustering(G, v1), 6)
    results["cc_sum_e2"] = round(nx.clustering(G, u2) + nx.clustering(G, v2), 6)

    # ---- 12. 端点对在自同构群下的轨道 ----
    # 节点轨道
    node_orbits = {}
    nid = 0
    for n in nodes:
        if n in node_orbits:
            continue
        node_orbits[n] = nid
        for p in aut_perms:
            mapping = {nodes[i]: p[i] for i in range(len(nodes))}
            node_orbits[mapping[n]] = nid
        nid += 1
    results["node_orbit_u1"] = node_orbits[u1]
    results["node_orbit_v1"] = node_orbits[v1]
    results["node_orbit_u2"] = node_orbits[u2]
    results["node_orbit_v2"] = node_orbits[v2]

    # ---- 13. 两端的度对是否交换 ----
    results["deg_swap"] = (G.degree(u1) == G.degree(v2) and G.degree(v1) == G.degree(u2))

    # ---- 14. 边 e1 与 e2 是否共享端点 ----
    results["share_endpoint"] = len(set(e1) & set(e2)) > 0

    # ---- 15. e1 与 e2 是否邻接（共享一个节点） ----
    results["adjacent_edges"] = len(set(e1) & set(e2)) == 1

    return results


def main():
    s_vals = np.linspace(-1.5, 0.0, 11)
    print("=" * 78)
    print("  32 对假阴性解剖：寻找比轨道更粗的等价关系")
    print("=" * 78)
    print()

    graphs = get_112_connected_graphs()
    print(f"  N=6 连通图总数: {len(graphs)}")
    print()

    SX_ops, SY_ops, SZ_ops = build_site_ops(6)

    # ============================================================
    # 第 1 步：找出 32 对假阴性
    # ============================================================
    print("=" * 78)
    print("  第 1 步：找出 32 对假阴性")
    print("=" * 78)

    false_negatives = []

    for gid, G in enumerate(graphs):
        edges = [tuple(sorted(e)) for e in G.edges()]
        orbits = find_edge_orbits(G)
        inv_pairs = find_involution_pairs(G)
        aut_perms = find_automorphisms(G)

        curves = {}
        for e in edges:
            curves[e] = compute_sorted_curve(G, e, s_vals,
                                             SX_ops, SY_ops, SZ_ops)

        for i, e1 in enumerate(edges):
            for j in range(i + 1, len(edges)):
                e2 = edges[j]
                if orbits[e1] == orbits[e2]:
                    continue  # 同轨道，跳过
                same = all(
                    len(a) == len(b) and np.allclose(a, b, atol=1e-10)
                    for a, b in zip(curves[e1], curves[e2])
                )
                if same:
                    analysis = analyze_pair(G, e1, e2, orbits, inv_pairs, aut_perms)
                    false_negatives.append({
                        "gid": gid,
                        "e1": list(e1),
                        "e2": list(e2),
                        "analysis": analysis,
                    })

        if (gid + 1) % 20 == 0:
            print(f"    已处理 {gid + 1}/{len(graphs)} 图")

    print()
    print(f"  假阴性总数: {len(false_negatives)}")
    print()

    # ============================================================
    # 第 2 步：并排输出所有 32 对
    # ============================================================
    print("=" * 78)
    print("  第 2 步：32 对完整解剖")
    print("=" * 78)
    print()

    for idx, fn in enumerate(false_negatives):
        gid = fn["gid"]
        e1 = fn["e1"]
        e2 = fn["e2"]
        a = fn["analysis"]

        print(f"  ── 第 {idx + 1} 对 ──")
        print(f"  图 {gid}: {e1} vs {e2}")
        print(f"    轨道: {a['orbit_e1']} vs {a['orbit_e2']}")
        print(f"    对合像: {a['is_involution_pair']}")
        print(f"    存在自同构映射: {a['has_automorphism_mapping']}")
        print(f"    存在非对合自同构映射: {a['has_non_involution_automorphism']}")
        print(f"    共享端点: {a['share_endpoint']}")
        print(f"    邻接边: {a['adjacent_edges']}")
        print(f"    度对: {a['deg_pair_e1']} vs {a['deg_pair_e2']}")
        print(f"    度交换: {a['deg_swap']}")
        print(f"    公共邻居: {a['common_neighbors_e1']} vs {a['common_neighbors_e2']}")
        print(f"    邻居度序列: {a['nbr_deg_seq_e1']} vs {a['nbr_deg_seq_e2']}")
        print(f"    二跳度序列: {a['two_hop_e1']} vs {a['two_hop_e2']}")
        print(f"    删除后分量: {a['components_after_del_e1']} vs {a['components_after_del_e2']}")
        print(f"    收缩度序列: {a['contraction_deg_seq_e1']} vs {a['contraction_deg_seq_e2']}")
        print(f"    环参与: {a['cycles_e1']} vs {a['cycles_e2']}")
        print(f"    边介数: {a['bc_e1']} vs {a['bc_e2']}")
        print(f"    离心率和: {a['ecc_sum_e1']} vs {a['ecc_sum_e2']}")
        print(f"    聚类系数和: {a['cc_sum_e1']} vs {a['cc_sum_e2']}")
        print(f"    节点轨道: u1={a['node_orbit_u1']}, v1={a['node_orbit_v1']}, "
              f"u2={a['node_orbit_u2']}, v2={a['node_orbit_v2']}")
        print()

    # ============================================================
    # 第 3 步：统计每个特征在 32 对中的“相同率”
    # ============================================================
    print("=" * 78)
    print("  第 3 步：特征在 32 对中的相同率")
    print("=" * 78)
    print()

    # 收集所有特征
    feature_names = list(false_negatives[0]["analysis"].keys())
    feature_same_rate = {}
    for fname in feature_names:
        same_count = 0
        for fn in false_negatives:
            a = fn["analysis"]
            if fname in a:
                # 对于非比较型特征，直接看值
                if isinstance(a[fname], bool):
                    if a[fname]:
                        same_count += 1
                else:
                    # 比较型特征：检查 e1 和 e2 的值是否相同
                    key1 = fname + "_e1"
                    key2 = fname + "_e2"
                    if key1 in a and key2 in a:
                        if a[key1] == a[key2]:
                            same_count += 1
                    else:
                        # 非比较型：看值是否为 True 或特定值
                        pass
        feature_same_rate[fname] = same_count

    print(f"  {'特征':<40}{'相同数':<10}{'比例':<10}")
    print(f"  {'-'*40}{'-'*10}{'-'*10}")
    for fname, count in sorted(feature_same_rate.items(),
                                key=lambda x: -x[1]):
        if count > 0:
            rate = count / len(false_negatives)
            print(f"  {fname:<40}{count:<10}{rate:<10.4f}")
    print()

    # ============================================================
    # 第 4 步：检查“共享端点”对
    # ============================================================
    print("=" * 78)
    print("  第 4 步：共享端点的对数")
    print("=" * 78)
    print()

    share_count = sum(1 for fn in false_negatives
                      if fn["analysis"]["share_endpoint"])
    adjacent_count = sum(1 for fn in false_negatives
                         if fn["analysis"]["adjacent_edges"])
    print(f"  共享端点的对数: {share_count} / {len(false_negatives)}")
    print(f"  邻接边的对数: {adjacent_count} / {len(false_negatives)}")
    print()

    # ============================================================
    # 第 5 步：检查“非对合自同构”对
    # ============================================================
    print("=" * 78)
    print("  第 5 步：非对合自同构的对数")
    print("=" * 78)
    print()

    non_inv_count = sum(1 for fn in false_negatives
                        if fn["analysis"]["has_non_involution_automorphism"])
    aut_count = sum(1 for fn in false_negatives
                    if fn["analysis"]["has_automorphism_mapping"])
    inv_count = sum(1 for fn in false_negatives
                    if fn["analysis"]["is_involution_pair"])
    print(f"  存在自同构映射的对数: {aut_count} / {len(false_negatives)}")
    print(f"  存在非对合自同构映射的对数: {non_inv_count} / {len(false_negatives)}")
    print(f"  对合像的对数: {inv_count} / {len(false_negatives)}")
    print()

    if aut_count == 0:
        print("  ★ 所有 32 对都没有自同构映射！")
        print("  ★ 这确认了它们不是由任何自同构产生的。")
    elif non_inv_count == len(false_negatives):
        print("  ★ 所有 32 对都由非对合自同构产生！")
        print("  ★ 这是一个新的发现：非对合自同构也保护响应。")
    else:
        print(f"  ⚠ 有 {non_inv_count} 对由非对合自同构产生，"
              f"其余 {len(false_negatives) - non_inv_count} 对来源未知。")

    # ============================================================
    # 第 6 步：按图分组
    # ============================================================
    print()
    print("=" * 78)
    print("  第 6 步：按图分组")
    print("=" * 78)
    print()

    by_gid = defaultdict(list)
    for fn in false_negatives:
        by_gid[fn["gid"]].append(fn)

    print(f"  {'图号':<6}{'对数':<8}")
    print(f"  {'-'*6}{'-'*8}")
    for gid in sorted(by_gid.keys()):
        print(f"  {gid:<6}{len(by_gid[gid]):<8}")
    print()

    # ============================================================
    # 第 7 步：保存
    # ============================================================
    output = {
        "false_negatives": false_negatives,
        "feature_same_rate": feature_same_rate,
        "share_endpoint_count": share_count,
        "non_involution_automorphism_count": non_inv_count,
    }
    with open("32对假阴性解剖结果.json", "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2, default=str)
    print(f"已保存: 32对假阴性解剖结果.json")


if __name__ == "__main__":
    main()