#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
检验收缩等价：是否能完美刻画 32 对假阴性
============================================

发现：21/32 对具有相同的收缩度序列 (2,2,2,2,4)。
追问：收缩等价是否能完美刻画 32 对？

方法：
1. 对 32 对，计算收缩后的图同构类。
2. 检查是否有 32 对都满足“收缩后同构”。
3. 检查随机异轨道对中，收缩后同构的比例。

运行：
    python 检验收缩等价.py
"""

import sys
import io
import json
import itertools
import numpy as np
import networkx as nx
from scipy.linalg import eigh

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)


I2 = np.eye(2, dtype=complex)
SX = np.array([[0, 1], [1, 0]], dtype=complex)
SY = np.array([[0, -1j], [1j, 0]], dtype=complex)
SZ = np.array([[1, 0], [0, -1]], dtype=complex)


def op_on_site(op, site, N):
    ops = [I2] * N
    ops[site] = op
    out = ops[0]
    for o in ops[1:]:
        out = np.kron(out, o)
    return out


def build_site_ops(N):
    return ([op_on_site(SX, i, N) for i in range(N)],
            [op_on_site(SY, i, N) for i in range(N)],
            [op_on_site(SZ, i, N) for i in range(N)])


def edge_matrix(i, j, SX_ops, SY_ops, SZ_ops, rule="heisenberg"):
    return SX_ops[i] @ SX_ops[j] + SY_ops[i] @ SY_ops[j] + SZ_ops[i] @ SZ_ops[j]


def ground_state_density(H, tol=1e-8):
    evals, evecs = eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < tol))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    return E0, rho, deg


def edge_correlations(rho, edges, SZ_ops):
    C = {}
    for (i, j) in edges:
        op = SZ_ops[i] @ SZ_ops[j]
        C[(i, j)] = float(np.real(np.trace(rho @ op)))
    return C


def compute_sorted_curve(G, defect_edge, s_vals, SX_ops, SY_ops, SZ_ops):
    N = G.number_of_nodes()
    edges = [tuple(sorted(e)) for e in G.edges()]
    H_edges = {e: edge_matrix(e[0], e[1], SX_ops, SY_ops, SZ_ops)
               for e in edges}
    H0 = sum(H_edges.values())
    M_defect = H_edges[defect_edge]
    curve = []
    for s in s_vals:
        H = H0 + (s - 1.0) * M_defect
        E0, rho, deg = ground_state_density(H)
        C = edge_correlations(rho, edges, SZ_ops)
        curve.append(tuple(np.round(sorted(C.values()), 12)))
    return curve


def find_automorphisms(G):
    nodes = list(G.nodes())
    adj = nx.to_numpy_array(G)
    perms = []
    for p in itertools.permutations(nodes):
        P = np.zeros((len(nodes), len(nodes)))
        for i, pi in enumerate(p):
            P[i, pi] = 1
        if np.allclose(P @ adj @ P.T, adj):
            perms.append(p)
    return perms


def find_edge_orbits(G):
    nodes = list(G.nodes())
    edges = [tuple(sorted(e)) for e in G.edges()]
    perms = find_automorphisms(G)
    orbit_id = {e: None for e in edges}
    oid = 0
    for e in edges:
        if orbit_id[e] is not None:
            continue
        orbit_id[e] = oid
        for p in perms:
            mapping = {nodes[i]: p[i] for i in range(len(nodes))}
            e2 = tuple(sorted((mapping[e[0]], mapping[e[1]])))
            if G.has_edge(*e2):
                orbit_id[e2] = oid
        oid += 1
    return orbit_id


def contraction_isomorphic(G, e1, e2):
    """检查边 e1 和 e2 收缩后得到的图是否同构。"""
    try:
        G1 = nx.contracted_edge(G, e1, self_loops=False)
        G2 = nx.contracted_edge(G, e2, self_loops=False)
        return nx.is_isomorphic(G1, G2)
    except Exception:
        return False


def contraction_deg_seq_equal(G, e1, e2):
    """检查边 e1 和 e2 收缩后的度序列是否相同。"""
    try:
        G1 = nx.contracted_edge(G, e1, self_loops=False)
        G2 = nx.contracted_edge(G, e2, self_loops=False)
        s1 = tuple(sorted(dict(G1.degree()).values()))
        s2 = tuple(sorted(dict(G2.degree()).values()))
        return s1 == s2
    except Exception:
        return False


def get_112_connected_graphs():
    atlas = nx.graph_atlas_g()
    return [G for G in atlas
            if G.number_of_nodes() == 6 and nx.is_connected(G)]


def main():
    s_vals = np.linspace(-1.5, 0.0, 11)
    print("=" * 78)
    print("  检验收缩等价")
    print("=" * 78)
    print()

    graphs = get_112_connected_graphs()
    SX_ops, SY_ops, SZ_ops = build_site_ops(6)

    # 收集所有异轨道对
    all_pairs = []
    for gid, G in enumerate(graphs):
        edges = [tuple(sorted(e)) for e in G.edges()]
        orbits = find_edge_orbits(G)
        curves = {}
        for e in edges:
            curves[e] = compute_sorted_curve(G, e, s_vals,
                                             SX_ops, SY_ops, SZ_ops)
        for i, e1 in enumerate(edges):
            for j in range(i + 1, len(edges)):
                e2 = edges[j]
                if orbits[e1] == orbits[e2]:
                    continue
                same = all(
                    len(a) == len(b) and np.allclose(a, b, atol=1e-10)
                    for a, b in zip(curves[e1], curves[e2])
                )
                all_pairs.append({
                    "gid": gid,
                    "G": G,
                    "e1": e1,
                    "e2": e2,
                    "same_response": same,
                    "contraction_iso": contraction_isomorphic(G, e1, e2),
                    "contraction_deg_seq": contraction_deg_seq_equal(G, e1, e2),
                })
        if (gid + 1) % 20 == 0:
            print(f"    已处理 {gid + 1}/{len(graphs)} 图")

    print()
    print(f"  总异轨道对数: {len(all_pairs)}")
    print()

    # 统计
    same_resp_pairs = [p for p in all_pairs if p["same_response"]]
    diff_resp_pairs = [p for p in all_pairs if not p["same_response"]]

    print(f"  同响应对: {len(same_resp_pairs)}")
    print(f"  不同响应对: {len(diff_resp_pairs)}")
    print()

    # 收缩同构
    same_resp_contraction_iso = sum(1 for p in same_resp_pairs
                                     if p["contraction_iso"])
    diff_resp_contraction_iso = sum(1 for p in diff_resp_pairs
                                     if p["contraction_iso"])
    print(f"  收缩后同构（同响应对）: {same_resp_contraction_iso} / {len(same_resp_pairs)}")
    print(f"  收缩后同构（不同响应对）: {diff_resp_contraction_iso} / {len(diff_resp_pairs)}")
    print()

    # 收缩度序列相同
    same_resp_deg_seq = sum(1 for p in same_resp_pairs
                             if p["contraction_deg_seq"])
    diff_resp_deg_seq = sum(1 for p in diff_resp_pairs
                             if p["contraction_deg_seq"])
    print(f"  收缩度序列相同（同响应对）: {same_resp_deg_seq} / {len(same_resp_pairs)}")
    print(f"  收缩度序列相同（不同响应对）: {diff_resp_deg_seq} / {len(diff_resp_pairs)}")
    print()

    # 检查：收缩度序列相同是否完美刻画同响应？
    # 即：是否所有同响应对都收缩度序列相同？
    all_same_deg_seq = all(p["contraction_deg_seq"] for p in same_resp_pairs)
    print(f"  所有同响应对都收缩度序列相同: {all_same_deg_seq}")
    print()

    # 反向检查：收缩度序列相同是否必然同响应？
    deg_seq_same_pairs = [p for p in all_pairs if p["contraction_deg_seq"]]
    deg_seq_same_resp = sum(1 for p in deg_seq_same_pairs
                             if p["same_response"])
    print(f"  收缩度序列相同的对中，同响应的: {deg_seq_same_resp} / {len(deg_seq_same_pairs)}")
    print()

    if all_same_deg_seq and deg_seq_same_resp == len(deg_seq_same_pairs):
        print("  ★ 收缩度序列相同 ⟺ 同响应！")
        print("  ★ 这是一个完美的充要条件！")
    else:
        print("  ⚠ 收缩度序列相同不是完美充要条件。")

    print()

    output = {
        "same_resp_count": len(same_resp_pairs),
        "contraction_iso_same_resp": same_resp_contraction_iso,
        "contraction_deg_seq_same_resp": same_resp_deg_seq,
        "all_same_deg_seq": all_same_deg_seq,
        "deg_seq_same_resp": deg_seq_same_resp,
        "deg_seq_same_total": len(deg_seq_same_pairs),
    }
    with open("收缩等价检验结果.json", "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2, default=str)
    print("已保存: 收缩等价检验结果.json")


if __name__ == "__main__":
    main()