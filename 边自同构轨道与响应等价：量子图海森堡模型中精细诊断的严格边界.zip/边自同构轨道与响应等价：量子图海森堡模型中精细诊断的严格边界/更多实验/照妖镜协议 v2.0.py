# -*- coding: utf-8 -*-
"""
================================================================================
照妖镜协议 v2.0
32对异轨道同响应的穷举关系特征攻击（修正版）

v1.0 的三个截断污染：
  (1) 用 WL hash 去重 → 丢失 3 个图（109 ≠ 112）
  (2) 期望值双重循环包含非对角项 → 2684 对 ≠ 32 对
  (3) 截断点没有显式标注 → 看不见自己在哪里截断

v2.0 的修正：
  (1) 直接用 atlas，用 is_isomorphic 去重
  (2) 期望值只取对角项：<sz_i sz_j> = sum_k rho_kk * sz_i(k) * sz_j(k)
  (3) 每个截断点都显式打印 [截断]

晶脉哲学立场：
  · 关系本体论：边不是"两点间的线"，是关系网络中的一个位置。
  · 对象化=截断=产生方向：每一步计算都标注截断点。
  · 只查同与不同：不拟合，不回归，不预设正确答案。
  · 反对对齐：不使用任何目标函数引导搜索。
  · 严防工具理性悖论：脚本是对象化工具，追问才是行动。
================================================================================
"""

import os
import json
import warnings
from collections import Counter
from itertools import combinations

import numpy as np
import networkx as nx

warnings.filterwarnings('ignore')

# ==============================================================================
# 第0部分：基础设置与截断标注
# ==============================================================================

TOL = 1e-10
S_GRID = np.linspace(-3, 3, 61)
N_NODES = 6
WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"

def log_truncation(name, detail):
    """显式标注每一个截断点。这是元反思律的操作化。"""
    print(f"    [截断] {name}: {detail}")

def same(a, b, tol=TOL):
    """只判断同或不同。不判断对错，不判断重要性。"""
    try:
        return abs(float(a) - float(b)) < tol
    except (TypeError, ValueError):
        return a == b

def fmt(x, nd=10):
    if isinstance(x, (bool, np.bool_)):
        return "True" if x else "False"
    if isinstance(x, (int, np.integer)):
        return str(int(x))
    if isinstance(x, (float, np.floating)):
        if np.isnan(x):
            return "nan"
        if abs(x) < 1e-14:
            return "0"
        return f"{x:.{nd}f}"
    return str(x)

# ==============================================================================
# 第1部分：构建 N=6 全部 112 个连通图
# ==============================================================================

def build_all_N6_graphs():
    """
    构建 N=6 的全部连通图。
    修正 v1.0 的 WL hash 去重 bug。
    """
    candidates = []
    for G in nx.graph_atlas_g():
        if G.number_of_nodes() == N_NODES and nx.is_connected(G):
            candidates.append(nx.convert_node_labels_to_integers(G))

    print(f"  [info] atlas 给出 {len(candidates)} 个 N=6 连通图")

    # 用 is_isomorphic 去重（笨方法，但正确）
    unique = []
    for G in candidates:
        dup = False
        for H in unique:
            if nx.is_isomorphic(G, H):
                dup = True
                break
        if not dup:
            unique.append(G)

    print(f"  [info] is_isomorphic 去重后 {len(unique)} 个图")
    log_truncation("图去重", "nx.is_isomorphic，不用 WL hash")

    if len(unique) != 112:
        print(f"  [警告] 期望 112 个图，实际 {len(unique)} 个。"
              f"图集不完整，结论需要重新审视。")
    return unique


def build_adj_list(G):
    """返回图的规范化边列表和节点映射"""
    nodes = sorted(G.nodes())
    node_idx = {n: i for i, n in enumerate(nodes)}
    edges = sorted([tuple(sorted((node_idx[a], node_idx[b])))
                    for a, b in G.edges()])
    return nodes, edges


# ==============================================================================
# 第2部分：哈密顿量与 E(s) 曲线（修正期望值计算）
# ==============================================================================

def sz0_basis(N):
    """构造 S_z = 0 子空间基"""
    n_up = N // 2
    basis = []
    for comb in combinations(range(N), n_up):
        state = [0] * N
        for i in comb:
            state[i] = 1
        basis.append(tuple(state))
    return basis


def build_H_sz0(N, edges, couplings):
    """
    在 Sz=0 子空间构造 H = sum J (sx sx + sy sy + sz sz)，S=sigma。

    对角项：自旋相同 +J，自旋不同 -J
    非对角项：自旋不同时翻转到相反状态，系数 2J
    （对于 S=sigma：σ^x σ^x + σ^y σ^y 在双自旋基下翻转振幅为 2）
    """
    basis = sz0_basis(N)
    dim = len(basis)
    idx = {s: i for i, s in enumerate(basis)}
    H = np.zeros((dim, dim))
    for i, state in enumerate(basis):
        for (a, b), J in zip(edges, couplings):
            if state[a] == state[b]:
                H[i, i] += J
            else:
                H[i, i] -= J
                new_state = list(state)
                new_state[a], new_state[b] = new_state[b], new_state[a]
                H[i, idx[tuple(new_state)]] += 2.0 * J
    return H, basis


def compute_E_curve(G, defect_edge, s_grid):
    """
    计算 E(s) = std{<sz_i sz_j>} 在 s_grid 上的曲线。

    v2.0 修正：期望值只取对角项。
    <sz_i sz_j> = sum_k rho_kk * sz_i(k) * sz_j(k)
    """
    N = G.number_of_nodes()
    _, edges = build_adj_list(G)
    # 找到缺陷边的索引
    target = tuple(sorted(defect_edge))
    # 缺陷边必须在 edges 里
    if target not in edges:
        target = tuple(sorted((defect_edge[1], defect_edge[0])))

    curves = []
    for s in s_grid:
        couplings = [s if e == target else 1.0 for e in edges]
        H, basis = build_H_sz0(N, edges, couplings)
        try:
            vals, vecs = np.linalg.eigh(H)
        except Exception:
            curves.append(np.nan)
            continue
        # 基态简并处理：对称性约化密度矩阵
        E0 = vals[0]
        degen = np.where(np.abs(vals - E0) < 1e-8)[0]
        rho = np.zeros_like(H)
        for k in degen:
            v = vecs[:, k].reshape(-1, 1)
            rho += v @ v.conj().T
        rho /= len(degen)

        # 自旋构型矩阵 (dim, N)
        sz_config = np.array([[1.0 if state[i] == 1 else -1.0
                               for i in range(N)] for state in basis])
        # 只取对角项
        rho_diag = np.diag(rho).real  # 确保实数

        corr = []
        for (a, b) in edges:
            # <sz_a sz_b> = sum_k rho_kk * sz_a(k) * sz_b(k)
            val = float(np.sum(rho_diag * sz_config[:, a] * sz_config[:, b]))
            corr.append(val)
        curves.append(float(np.std(corr)))
    return np.array(curves)


def compute_gap_curve(G, defect_edge, s_grid):
    """计算能隙曲线"""
    N = G.number_of_nodes()
    _, edges = build_adj_list(G)
    target = tuple(sorted(defect_edge))
    if target not in edges:
        target = tuple(sorted((defect_edge[1], defect_edge[0])))

    gaps = []
    for s in s_grid:
        couplings = [s if e == target else 1.0 for e in edges]
        H, _ = build_H_sz0(N, edges, couplings)
        try:
            vals = np.linalg.eigvalsh(H)
            gaps.append(float(vals[1] - vals[0]))
        except Exception:
            gaps.append(np.nan)
    return np.array(gaps)


def curves_equal(c1, c2, tol=TOL):
    if len(c1) != len(c2):
        return False
    m = ~(np.isnan(c1) | np.isnan(c2))
    if m.sum() == 0:
        return False
    return bool(np.all(np.abs(c1[m] - c2[m]) < tol))


# ==============================================================================
# 第3部分：边自同构轨道
# ==============================================================================

def edge_orbits(G, edges):
    """计算每条边的自同构轨道 id"""
    GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
    autos = list(GM.isomorphisms_iter())
    orbits = {}
    for e in edges:
        orbit = set()
        for auto in autos:
            mapped = frozenset({auto[e[0]], auto[e[1]]})
            orbit.add(mapped)
        orbits[e] = frozenset(orbit)

    uniq = {}
    out = {}
    for e in edges:
        o = orbits[e]
        if o not in uniq:
            uniq[o] = len(uniq)
        out[e] = uniq[o]
    return out


# ==============================================================================
# 第4部分：找到 32 对异轨道同响应
# ==============================================================================

def find_32_pairs(graphs):
    """
    扫描所有图，找出异轨道同响应对。
    预期：32 对（如果 v2.0 期望值计算正确）。
    """
    pairs = []
    total_异轨道 = 0
    print(f"  [info] 开始扫描 {len(graphs)} 个图，"
          f"S_GRID={len(S_GRID)} 点…")
    for gid, G in enumerate(graphs):
        if gid % 20 == 0:
            print(f"    已处理 {gid}/{len(graphs)} 图")
        _, edges = build_adj_list(G)
        orbits = edge_orbits(G, edges)
        # 缓存每条边的 E(s)
        curves = {e: compute_E_curve(G, e, S_GRID) for e in edges}
        for i in range(len(edges)):
            for j in range(i + 1, len(edges)):
                e1, e2 = edges[i], edges[j]
                if orbits[e1] == orbits[e2]:
                    continue
                total_异轨道 += 1
                if curves_equal(curves[e1], curves[e2]):
                    pairs.append({
                        "graph_id": gid,
                        "edges": edges,
                        "edge1": list(e1),
                        "edge2": list(e2),
                    })
    print(f"  [info] 总异轨道对数: {total_异轨道}")
    print(f"  [info] 异轨道同响应对: {len(pairs)}")
    log_truncation("同响应判定", f"tol={TOL}, NaN 过滤, 逐点比较")
    return pairs


# ==============================================================================
# 第5部分：关系特征（穷举）
# ==============================================================================

def feat_structural(G, e1, e2):
    """结构关系特征"""
    out = {}
    n1a, n1b = e1
    n2a, n2b = e2
    s1 = {n1a, n1b}
    s2 = {n2a, n2b}
    out["share_endpoint"] = len(s1 & s2) > 0
    out["common_neighbors"] = len(
        (set(G.neighbors(n1a)) | set(G.neighbors(n1b))) &
        (set(G.neighbors(n2a)) | set(G.neighbors(n2b)))
    )
    inter = (set(G.neighbors(n1a)) | set(G.neighbors(n1b))) & \
            (set(G.neighbors(n2a)) | set(G.neighbors(n2b)))
    union = (set(G.neighbors(n1a)) | set(G.neighbors(n1b))) | \
            (set(G.neighbors(n2a)) | set(G.neighbors(n2b)))
    out["neighbor_jaccard"] = len(inter) / len(union) if union else 0.0
    out["degree_pair_1"] = tuple(sorted([G.degree(n1a), G.degree(n1b)]))
    out["degree_pair_2"] = tuple(sorted([G.degree(n2a), G.degree(n2b)]))
    out["degree_sum_1"] = G.degree(n1a) + G.degree(n1b)
    out["degree_sum_2"] = G.degree(n2a) + G.degree(n2b)
    try:
        out["edge_distance"] = nx.shortest_path_length(G, n1a, n2a)
    except Exception:
        out["edge_distance"] = -1
    out["triangle_1"] = sum(1 for _ in nx.common_neighbors(G, n1a, n1b))
    out["triangle_2"] = sum(1 for _ in nx.common_neighbors(G, n2a, n2b))
    core = nx.core_number(G)
    out["kcore_1"] = min(core[n1a], core[n1b])
    out["kcore_2"] = min(core[n2a], core[n2b])
    bridges = set(map(frozenset, nx.bridges(G)))
    out["is_bridge_1"] = frozenset(e1) in bridges
    out["is_bridge_2"] = frozenset(e2) in bridges
    return out


def feat_spectral(G, e1, e2):
    """谱关系特征"""
    out = {}
    L = nx.laplacian_matrix(G).astype(float).toarray()
    try:
        evals = np.linalg.eigvalsh(L)
        out["laplacian_gap"] = float(evals[1] - evals[0])
        out["laplacian_max"] = float(evals[-1])
    except Exception:
        out["laplacian_gap"] = np.nan
        out["laplacian_max"] = np.nan
    try:
        Lpinv = np.linalg.pinv(L)
        def eff_res(u, v):
            return float(Lpinv[u, u] + Lpinv[v, v] - 2 * Lpinv[u, v])
        out["eff_resistance_1"] = eff_res(*e1)
        out["eff_resistance_2"] = eff_res(*e2)
    except Exception:
        out["eff_resistance_1"] = np.nan
        out["eff_resistance_2"] = np.nan
    try:
        A = nx.to_numpy_array(G)
        ev = np.linalg.eigvalsh(A)
        out["adj_spectral_radius"] = float(ev[-1])
        out["adj_gap"] = float(ev[-1] - ev[-2]) if len(ev) > 1 else np.nan
    except Exception:
        out["adj_spectral_radius"] = np.nan
        out["adj_gap"] = np.nan
    return out


def feat_automorphism(G, e1, e2, orbits):
    """自同构关系特征"""
    out = {}
    out["same_orbit"] = orbits[e1] == orbits[e2]
    out["orbit_id_1"] = orbits[e1]
    out["orbit_id_2"] = orbits[e2]
    GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
    autos = list(GM.isomorphisms_iter())
    out["num_automorphisms"] = len(autos)

    found_auto = False
    found_involution = False
    for auto in autos:
        m = frozenset({auto[e1[0]], auto[e1[1]]})
        if m == frozenset(e2):
            found_auto = True
            if all(auto[auto[n]] == n for n in G.nodes()):
                found_involution = True
                break
    out["has_automorphism_map"] = found_auto
    out["has_involution_map"] = found_involution

    orbit_size = Counter()
    for e in G.edges():
        orbit_size[orbits[e]] += 1
    out["orbit_size_1"] = orbit_size[orbits[e1]]
    out["orbit_size_2"] = orbit_size[orbits[e2]]
    return out


def feat_quantum(G, e1, e2):
    """量子关系特征"""
    out = {}
    g1 = compute_gap_curve(G, e1, S_GRID)
    g2 = compute_gap_curve(G, e2, S_GRID)
    if g1 is not None and g2 is not None:
        diff = g1 - g2
        out["gap_curve_equal"] = bool(np.all(np.abs(diff) < TOL))
        out["gap_diff_mean"] = float(np.nanmean(diff))
        out["gap_diff_std"] = float(np.nanstd(diff))
        out["gap_diff_is_constant"] = bool(np.nanstd(diff) < 1e-8)
        val = float(np.nanmean(diff))
        out["gap_diff_value"] = val
        out["gap_diff_identified"] = identify_algebraic(val)
    return out


def identify_algebraic(x):
    """识别有理数或二次代数数"""
    if np.isnan(x):
        return "nan"
    if abs(x) < 1e-10:
        return "0"
    for q in range(1, 1001):
        p = round(x * q)
        if abs(x - p / q) < 1e-10:
            return f"{p}/{q}"
    for c in range(1, 21):
        for a in range(-20, 21):
            for b in range(-20, 21):
                if abs(a + b * x + c * x * x) < 1e-8:
                    disc = b * b - 4 * a * c
                    if disc >= 0:
                        r = np.sqrt(disc)
                        return f"(-{b}+-sqrt({disc}))/{2*a}" if a != 0 else f"sqrt({disc})"
    return "未识别"


# ==============================================================================
# 第6部分：并排比较与追问
# ==============================================================================

def side_by_side_report(rows):
    """并排比较：每个特征在 32 对中的值"""
    if not rows:
        print("  [warn] 没有可比较的行")
        return
    meta = {"pair_id", "graph_id", "edge1", "edge2"}
    feature_names = [k for k in rows[0].keys() if k not in meta]

    print("\n" + "=" * 100)
    print("并排比较：32 对异轨道同响应的穷举关系特征")
    print("=" * 100)
    for fname in feature_names:
        values = [row.get(fname) for row in rows]
        same_count = 0
        total_pairs = 0
        for i in range(len(values)):
            for j in range(i + 1, len(values)):
                total_pairs += 1
                if same(values[i], values[j]):
                    same_count += 1
        print(f"\n--- {fname} ---")
        print(f"  同值对数: {same_count}/{total_pairs}  "
              f"异值对数: {total_pairs - same_count}/{total_pairs}")
        line = []
        for i, v in enumerate(values):
            line.append(f"[{i:02d}]={fmt(v)}")
            if (i + 1) % 3 == 0:
                print("  " + "  ".join(line))
                line = []
        if line:
            print("  " + "  ".join(line))


def ask_why(rows):
    """追问生成：不是结论，是追问"""
    print("\n" + "=" * 100)
    print("追问生成：每个特征为什么同，为什么不同")
    print("=" * 100)
    meta = {"pair_id", "graph_id", "edge1", "edge2"}
    feature_names = [k for k in rows[0].keys() if k not in meta]
    for fname in feature_names:
        values = [row.get(fname) for row in rows]
        same_pairs = 0
        diff_pairs = 0
        for i in range(len(values)):
            for j in range(i + 1, len(values)):
                if same(values[i], values[j]):
                    same_pairs += 1
                else:
                    diff_pairs += 1
        total = same_pairs + diff_pairs
        print(f"\n### 追问：{fname}")
        print(f"  · 同值对数 {same_pairs}/{total}，异值对数 {diff_pairs}/{total}")
        if diff_pairs == 0:
            print(f"  · 为什么这个特征在所有 32 对中完全相同？")
            print(f"    ——它是响应等价的必要条件？")
            print(f"    ——它是图同构的副产品？")
            print(f"    ——它是被我们截断掉的关系维度？")
        elif same_pairs == 0:
            print(f"  · 为什么这个特征在所有 32 对中完全不同？")
            print(f"    ——它是响应等价的无关项？")
            print(f"    ——它是节点对象化的残留？")
        else:
            print(f"  · 为什么部分对同、部分对不同？")
            print(f"    ——同的那些对，共享了什么关系结构？")
            print(f"    ——不同的那些对，缺失了什么关系结构？")
        print(f"  · 这个特征的截断点在哪里？")
        print(f"  · 如果把节点全部抹掉，这个特征还剩什么？")


# ==============================================================================
# 第7部分：导出
# ==============================================================================

def export_results(rows, pairs, out_dir=WORK_DIR):
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "照妖镜_32对穷举特征_v2.json")
    out_pairs_path = os.path.join(out_dir, "照妖镜_32对清单_v2.json")
    def convert(o):
        if isinstance(o, (np.integer,)):
            return int(o)
        if isinstance(o, (np.floating,)):
            return float(o)
        if isinstance(o, (np.bool_,)):
            return bool(o)
        if isinstance(o, np.ndarray):
            return o.tolist()
        if isinstance(o, tuple):
            return list(o)
        return str(o)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=2, default=convert)
    with open(out_pairs_path, "w", encoding="utf-8") as f:
        json.dump(pairs, f, ensure_ascii=False, indent=2, default=convert)
    print(f"\n[ok] 结果已导出: {out_path}")
    print(f"[ok] 32对清单已导出: {out_pairs_path}")


# ==============================================================================
# 主流程
# ==============================================================================

def main():
    print("=" * 100)
    print("照妖镜协议 v2.0")
    print("32 对异轨道同响应的穷举关系特征攻击（修正版）")
    print("=" * 100)

    print("\n[1/5] 构建 N=6 全部连通图…")
    graphs = build_all_N6_graphs()

    print("\n[2/5] 找到 32 对异轨道同响应…")
    pairs = find_32_pairs(graphs)
    print(f"  找到 {len(pairs)} 对")
    if len(pairs) != 32:
        print(f"  [警告] 期望 32 对，实际 {len(pairs)} 对。")
        print(f"  [追问] 为什么不是 32？")
        print(f"    ——期望值计算是否还有残余错误？")
        print(f"    ——S_GRID 是否与旧脚本一致？")
        print(f"    ——图集是否完整？")
        print(f"    ——同响应判定容差是否过松或过紧？")
        return

    print("\n[3/5] 穷举计算所有关系特征…")
    rows = []
    for idx, p in enumerate(pairs):
        gid = p["graph_id"]
        e1 = tuple(p["edge1"])
        e2 = tuple(p["edge2"])
        G = graphs[gid]
        _, edges = build_adj_list(G)
        orbits = edge_orbits(G, edges)
        row = {
            "pair_id": idx,
            "graph_id": gid,
            "edge1": e1,
            "edge2": e2,
        }
        row.update(feat_structural(G, e1, e2))
        row.update(feat_spectral(G, e1, e2))
        row.update(feat_automorphism(G, e1, e2, orbits))
        row.update(feat_quantum(G, e1, e2))
        rows.append(row)
    print(f"  完成 {len(rows)} 对")

    print("\n[4/5] 并排比较…")
    side_by_side_report(rows)

    print("\n[5/5] 追问生成…")
    ask_why(rows)

    export_results(rows, pairs)

    print("\n" + "=" * 100)
    print("照妖镜协议完成。")
    print("结果并排展示。不筛选。不排序。不下结论。")
    print("过程继续。")
    print("=" * 100)


if __name__ == "__main__":
    main()