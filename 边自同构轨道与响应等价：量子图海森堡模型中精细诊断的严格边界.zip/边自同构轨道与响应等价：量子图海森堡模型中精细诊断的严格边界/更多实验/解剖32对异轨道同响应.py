#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
32对异轨道同响应的解剖：寻找更粗等价类
============================================

论文核心结果：
- 同轨道必同响应：0 反例
- 异轨道可能同响应：32 对
- 无图论量能刻画更粗等价类

PRB 会问：
- 这 32 对有什么共同结构？
- 是否存在一个更粗的等价类？
- 这个等价类是否依赖相互作用？

本脚本：
1. 穷举 N=6 全部 112 连通图
2. 对每条边计算排序关联分布曲线
3. 找 32 对异轨道同响应
4. 对每对计算所有可能的图论特征
5. 检查是否有特征能完美区分这 32 对和普通异轨道对
6. 用海森堡、XXZ、Ising、XY 重复
7. 并排输出所有结果

原则：
- 只查同与不同
- 不拟合，不回归，不预设
- 标准物理与关系本体论并排
- 数据说话，只要真相

运行：
    python 解剖32对异轨道同响应.py
    python 解剖32对异轨道同响应.py --rules heisenberg xxz ising xy
"""

import sys
import io
import json
import itertools
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from collections import defaultdict, Counter

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)


# ============================================================
# 泡利矩阵（S = σ，与论文一致）
# ============================================================

I2 = np.eye(2, dtype=complex)
SX = np.array([[0, 1], [1, 0]], dtype=complex)
SY = np.array([[0, -1j], [1j, 0]], dtype=complex)
SZ = np.array([[1, 0], [0, -1]], dtype=complex)


def op_on_site(op, site, N):
    ops = [I2] * N
    ops[site] = op
    out = ops[0]
    for o in ops[1:]:
        out = np.kron(out, o)
    return out


def build_site_ops(N):
    return ([op_on_site(SX, i, N) for i in range(N)],
            [op_on_site(SY, i, N) for i in range(N)],
            [op_on_site(SZ, i, N) for i in range(N)])


# ============================================================
# 哈密顿量（支持四种相互作用）
# ============================================================

def edge_matrix(i, j, SX_ops, SY_ops, SZ_ops, rule="heisenberg", delta=1.0):
    if rule == "heisenberg":
        return SX_ops[i] @ SX_ops[j] + SY_ops[i] @ SY_ops[j] + SZ_ops[i] @ SZ_ops[j]
    elif rule == "xxz":
        return SX_ops[i] @ SX_ops[j] + SY_ops[i] @ SY_ops[j] + delta * (SZ_ops[i] @ SZ_ops[j])
    elif rule == "ising":
        return SZ_ops[i] @ SZ_ops[j]
    elif rule == "xy":
        return SX_ops[i] @ SX_ops[j] + SY_ops[i] @ SY_ops[j]
    else:
        raise ValueError(f"未知规则: {rule}")


def ground_state_density(H, tol=1e-8):
    evals, evecs = eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < tol))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    gap = evals[deg] - E0 if deg < len(evals) else 0.0
    return E0, gap, rho, deg, evals


def edge_correlations(rho, edges, SZ_ops):
    C = {}
    for (i, j) in edges:
        op = SZ_ops[i] @ SZ_ops[j]
        C[(i, j)] = float(np.real(np.trace(rho @ op)))
    return C


def compute_sorted_curve(G, defect_edge, s_vals, SX_ops, SY_ops, SZ_ops,
                         rule="heisenberg", delta=1.0):
    """计算排序关联分布曲线。"""
    N = G.number_of_nodes()
    edges = [tuple(sorted(e)) for e in G.edges()]
    H_edges = {e: edge_matrix(e[0], e[1], SX_ops, SY_ops, SZ_ops, rule, delta)
               for e in edges}
    H0 = sum(H_edges.values())
    M_defect = H_edges[defect_edge]

    curve = []
    for s in s_vals:
        H = H0 + (s - 1.0) * M_defect
        E0, gap, rho, deg, evals = ground_state_density(H)
        C = edge_correlations(rho, edges, SZ_ops)
        vals = sorted(C.values())
        curve.append(tuple(np.round(vals, 12)))
    return curve


# ============================================================
# 图论特征
# ============================================================

def graph_features(G):
    N = G.number_of_nodes()
    m = G.number_of_edges()
    triangles = sum(nx.triangles(G).values()) // 3
    L = nx.laplacian_matrix(G).toarray().astype(float)
    evals_L = np.sort(np.linalg.eigvalsh(L))
    spectral_gap = float(evals_L[1] - evals_L[0]) if len(evals_L) > 1 else 0.0

    try:
        bridges = set(tuple(sorted(b)) for b in nx.bridges(G))
    except Exception:
        bridges = set()

    try:
        cut_nodes = set(nx.articulation_points(G))
    except Exception:
        cut_nodes = set()

    return {
        "N": N, "m": m, "triangles": triangles,
        "cycle_rank": m - N + 1,
        "spectral_gap": spectral_gap,
        "num_bridges": len(bridges),
        "num_cut_nodes": len(cut_nodes),
        "bridges": [list(b) for b in bridges],
        "cut_nodes": list(cut_nodes),
    }


def edge_features(G, edge):
    """计算边的局域特征。"""
    u, v = edge
    N = G.number_of_nodes()

    # 端点度
    deg_u = G.degree(u)
    deg_v = G.degree(v)

    # 是否桥
    H = G.copy()
    H.remove_edge(u, v)
    is_bridge = not nx.is_connected(H)

    # 公共邻居数
    common_neighbors = len(set(G.neighbors(u)) & set(G.neighbors(v)))

    # 三角形数（包含这条边的三角形）
    triangles_with_edge = common_neighbors

    # 端点邻居度序列
    neighbors_u = [G.degree(w) for w in G.neighbors(u) if w != v]
    neighbors_v = [G.degree(w) for w in G.neighbors(v) if w != u]
    neighbor_deg_seq = tuple(sorted(neighbors_u + neighbors_v))

    # 端点离心率和
    try:
        ecc_u = nx.eccentricity(G, u)
        ecc_v = nx.eccentricity(G, v)
        ecc_sum = ecc_u + ecc_v
    except Exception:
        ecc_sum = 0

    # 边介数
    try:
        edge_betweenness = nx.edge_betweenness_centrality(G)
        bc = edge_betweenness.get((u, v), edge_betweenness.get((v, u), 0.0))
    except Exception:
        bc = 0.0

    # 端点聚类系数和
    cc_u = nx.clustering(G, u)
    cc_v = nx.clustering(G, v)
    cc_sum = cc_u + cc_v

    return {
        "deg_u": deg_u, "deg_v": deg_v,
        "deg_pair": tuple(sorted([deg_u, deg_v])),
        "is_bridge": is_bridge,
        "common_neighbors": common_neighbors,
        "triangles_with_edge": triangles_with_edge,
        "neighbor_deg_seq": neighbor_deg_seq,
        "ecc_sum": ecc_sum,
        "edge_betweenness": bc,
        "cc_sum": cc_sum,
    }


def edge_orbits(G):
    """计算边自同构轨道。"""
    nodes = list(G.nodes())
    edges = [tuple(sorted(e)) for e in G.edges()]
    perms = list(itertools.permutations(nodes))
    orbit_id = {e: None for e in edges}
    oid = 0
    for e in edges:
        if orbit_id[e] is not None:
            continue
        orbit_id[e] = oid
        for p in perms:
            mapping = {nodes[i]: p[i] for i in range(len(nodes))}
            e2 = tuple(sorted((mapping[e[0]], mapping[e[1]])))
            if G.has_edge(*e2):
                orbit_id[e2] = oid
        oid += 1
    return orbit_id


def generate_all_connected_graphs(N):
    all_edges = list(itertools.combinations(range(N), 2))
    graphs = []
    for m in range(N - 1, len(all_edges) + 1):
        for combo in itertools.combinations(all_edges, m):
            G = nx.Graph()
            G.add_nodes_from(range(N))
            G.add_edges_from(combo)
            if nx.is_connected(G):
                graphs.append(G)
    return graphs


# ============================================================
# 主流程
# ============================================================

def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--s_min", type=float, default=-1.5)
    parser.add_argument("--s_max", type=float, default=0.0)
    parser.add_argument("--s_steps", type=int, default=11)
    parser.add_argument("--rules", type=str, nargs="+",
                        default=["heisenberg"])
    parser.add_argument("--delta", type=float, nargs="+", default=[1.0])
    parser.add_argument("--out", type=str, default="解剖32对结果.json")
    args = parser.parse_args()

    s_vals = np.linspace(args.s_min, args.s_max, args.s_steps)

    print("=" * 78)
    print("  32对异轨道同响应的解剖")
    print("=" * 78)
    print(f"  s: [{args.s_min}, {args.s_max}], {args.s_steps} 点")
    print(f"  规则: {args.rules}")
    print(f"  Δ: {args.delta}")
    print()

    all_results = {}

    for rule in args.rules:
        for delta in args.delta:
            if rule != "xxz" and delta != 1.0:
                continue
            print("=" * 78)
            print(f"  规则: {rule}, Δ={delta}")
            print("=" * 78)
            print()

            SX_ops, SY_ops, SZ_ops = build_site_ops(6)
            graphs = generate_all_connected_graphs(6)
            print(f"  N=6 连通图总数: {len(graphs)}")

            # 收集所有 (图, 边) 的曲线
            edge_curves = []  # list of (gid, edge, curve, features, orbit)
            for gid, G in enumerate(graphs):
                edges = [tuple(sorted(e)) for e in G.edges()]
                orbits = edge_orbits(G)
                feats = graph_features(G)
                for e in edges:
                    curve = compute_sorted_curve(G, e, s_vals,
                                                 SX_ops, SY_ops, SZ_ops,
                                                 rule, delta)
                    ef = edge_features(G, e)
                    edge_curves.append({
                        "gid": gid,
                        "edge": e,
                        "curve": curve,
                        "graph_features": feats,
                        "edge_features": ef,
                        "orbit": orbits[e],
                    })
                if (gid + 1) % 20 == 0:
                    print(f"    已处理 {gid + 1}/{len(graphs)} 图")

            print(f"  总边数: {len(edge_curves)}")

            # 找同响应对（曲线相同）
            print(f"\n  寻找同响应对...")
            same_curve_pairs = []
            n = len(edge_curves)
            for i in range(n):
                for j in range(i + 1, n):
                    ci = edge_curves[i]["curve"]
                    cj = edge_curves[j]["curve"]
                    if len(ci) != len(cj):
                        continue
                    same = all(
                        len(a) == len(b) and np.allclose(a, b, atol=1e-10)
                        for a, b in zip(ci, cj)
                    )
                    if same:
                        same_curve_pairs.append((i, j))

            print(f"  同响应边对数: {len(same_curve_pairs)}")

            # 分类：同轨道同响应、异轨道同响应
            same_orbit_same = []
            diff_orbit_same = []
            for i, j in same_curve_pairs:
                if edge_curves[i]["gid"] != edge_curves[j]["gid"]:
                    continue
                if edge_curves[i]["orbit"] == edge_curves[j]["orbit"]:
                    same_orbit_same.append((i, j))
                else:
                    diff_orbit_same.append((i, j))

            print(f"    同轨道同响应: {len(same_orbit_same)}")
            print(f"    异轨道同响应: {len(diff_orbit_same)}")
            print()

            # ============================================================
            # 解剖 32 对异轨道同响应
            # ============================================================
            print("=" * 78)
            print(f"  异轨道同响应对的解剖（{rule}, Δ={delta}）")
            print("=" * 78)
            print()

            if not diff_orbit_same:
                print("  无异轨道同响应对")
                continue

            # 提取所有特征
            feature_names = [
                "deg_pair", "is_bridge", "common_neighbors",
                "triangles_with_edge", "neighbor_deg_seq",
                "ecc_sum", "edge_betweenness", "cc_sum",
            ]

            print(f"  {'图号':<6}{'边1':<10}{'边2':<10}"
                  f"{'deg_pair':<16}{'is_bridge':<12}{'common_nb':<12}"
                  f"{'tri':<6}{'ecc_sum':<10}{'bc':<10}{'cc_sum':<10}")
            print(f"  {'-'*6}{'-'*10}{'-'*10}"
                  f"{'-'*16}{'-'*12}{'-'*12}{'-'*6}{'-'*10}{'-'*10}{'-'*10}")

            for i, j in diff_orbit_same:
                gi = edge_curves[i]
                gj = edge_curves[j]
                fi = gi["edge_features"]
                fj = gj["edge_features"]
                print(f"  {gi['gid']:<6}{str(gi['edge']):<10}{str(gj['edge']):<10}"
                      f"{str(fi['deg_pair']):<16}{str(fi['is_bridge']):<12}"
                      f"{fi['common_neighbors']:<12}{fi['triangles_with_edge']:<6}"
                      f"{fi['ecc_sum']:<10}{fi['edge_betweenness']:<10.4f}"
                      f"{fi['cc_sum']:<10.4f}")
                # 检查边特征是否相同
                same_feats = []
                for fname in feature_names:
                    if fi[fname] == fj[fname]:
                        same_feats.append(fname)
                print(f"        相同特征: {same_feats}")

            print()

            # 统计：32 对中，哪些特征相同
            print("  特征相同统计：")
            for fname in feature_names:
                same_count = 0
                for i, j in diff_orbit_same:
                    if edge_curves[i]["edge_features"][fname] == \
                       edge_curves[j]["edge_features"][fname]:
                        same_count += 1
                ratio = same_count / len(diff_orbit_same) if diff_orbit_same else 0
                print(f"    {fname:<24}: {same_count}/{len(diff_orbit_same)} "
                      f"= {ratio:.2%}")

            print()

            # ============================================================
            # 对照：随机异轨道对的特征相同率
            # ============================================================
            print("  对照：随机异轨道对的特征相同率")
            print()

            # 收集所有异轨道对（不要求同响应）
            all_diff_orbit = []
            by_gid = defaultdict(list)
            for idx, ec in enumerate(edge_curves):
                by_gid[ec["gid"]].append(idx)
            for gid, indices in by_gid.items():
                for ii in range(len(indices)):
                    for jj in range(ii + 1, len(indices)):
                        i, j = indices[ii], indices[jj]
                        if edge_curves[i]["orbit"] != edge_curves[j]["orbit"]:
                            all_diff_orbit.append((i, j))

            print(f"  总异轨道对数: {len(all_diff_orbit)}")
            print()

            print(f"  {'特征':<24}{'32对同响应':<16}{'随机异轨道':<16}{'差值':<12}")
            print(f"  {'-'*24}{'-'*16}{'-'*16}{'-'*12}")
            for fname in feature_names:
                same_resp = sum(
                    1 for i, j in diff_orbit_same
                    if edge_curves[i]["edge_features"][fname] ==
                       edge_curves[j]["edge_features"][fname]
                ) / len(diff_orbit_same) if diff_orbit_same else 0

                same_rand = sum(
                    1 for i, j in all_diff_orbit
                    if edge_curves[i]["edge_features"][fname] ==
                       edge_curves[j]["edge_features"][fname]
                ) / len(all_diff_orbit) if all_diff_orbit else 0

                diff = same_resp - same_rand
                print(f"  {fname:<24}{same_resp:<16.4f}{same_rand:<16.4f}"
                      f"{diff:<12.4f}")
            print()

            # 保存
            all_results[f"{rule}_delta{delta}"] = {
                "same_orbit_same": len(same_orbit_same),
                "diff_orbit_same": len(diff_orbit_same),
                "pairs": [
                    {
                        "gid": edge_curves[i]["gid"],
                        "edge1": list(edge_curves[i]["edge"]),
                        "edge2": list(edge_curves[j]["edge"]),
                        "features1": edge_curves[i]["edge_features"],
                        "features2": edge_curves[j]["edge_features"],
                    }
                    for i, j in diff_orbit_same
                ],
            }

    # ============================================================
    # 保存
    # ============================================================
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(all_results, f, ensure_ascii=False, indent=2, default=str)
    print(f"已保存: {args.out}")
    print()
    print("=" * 78)
    print("  追问继续。数据说话。只要真相。")
    print("=" * 78)


if __name__ == "__main__":
    main()