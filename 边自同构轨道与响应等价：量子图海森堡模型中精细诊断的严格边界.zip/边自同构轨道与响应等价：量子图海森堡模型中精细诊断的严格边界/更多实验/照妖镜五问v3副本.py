# -*- coding: utf-8 -*-
"""
================================================================================
照妖镜协议 v3.0
同时追问五个问题

五问：
  Q1. 旧脚本的 S_GRID 是什么？28 vs 32 是怎么产生的？
  Q2. 图 69、83 等贡献者的边集与关系结构是什么？
  Q3. 28 对里 share_endpoint、edge_distance、orbit_size 的分布是什么？
  Q4. 把 S_GRID 从 [-3,3] 缩到 [-1,1]，多出来的对是什么？
  Q5. 图 106、108 在哪？-2 和 1-√3 从哪来？
================================================================================
"""

import os
import json
import warnings
from collections import Counter
from itertools import combinations

import numpy as np
import networkx as nx

warnings.filterwarnings('ignore')

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"
N_NODES = 6
TOL = 1e-10


# ============================================================
# 基础
# ============================================================

def log_truncation(name, detail):
    print(f"    [截断] {name}: {detail}")


def fmt(x, nd=10):
    if isinstance(x, (bool, np.bool_)):
        return "True" if x else "False"
    if isinstance(x, (int, np.integer)):
        return str(int(x))
    if isinstance(x, (float, np.floating)):
        if np.isnan(x):
            return "nan"
        if abs(x) < 1e-14:
            return "0"
        return f"{x:.{nd}f}"
    return str(x)


def build_all_N6_graphs():
    candidates = []
    for G in nx.graph_atlas_g():
        if G.number_of_nodes() == N_NODES and nx.is_connected(G):
            candidates.append(nx.convert_node_labels_to_integers(G))
    unique = []
    for G in candidates:
        if not any(nx.is_isomorphic(G, H) for H in unique):
            unique.append(G)
    return unique


def build_adj_list(G):
    nodes = sorted(G.nodes())
    node_idx = {n: i for i, n in enumerate(nodes)}
    edges = sorted([tuple(sorted((node_idx[a], node_idx[b])))
                    for a, b in G.edges()])
    return edges


def sz0_basis(N):
    n_up = N // 2
    basis = []
    for comb in combinations(range(N), n_up):
        state = [0] * N
        for i in comb:
            state[i] = 1
        basis.append(tuple(state))
    return basis


def build_H_sz0(N, edges, couplings):
    basis = sz0_basis(N)
    dim = len(basis)
    idx = {s: i for i, s in enumerate(basis)}
    H = np.zeros((dim, dim))
    for i, state in enumerate(basis):
        for (a, b), J in zip(edges, couplings):
            if state[a] == state[b]:
                H[i, i] += J
            else:
                H[i, i] -= J
                new_state = list(state)
                new_state[a], new_state[b] = new_state[b], new_state[a]
                H[i, idx[tuple(new_state)]] += 2.0 * J
    return H, basis


def edge_orbits(G, edges):
    GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
    autos = list(GM.isomorphisms_iter())
    orbits = {}
    for e in edges:
        orbit = set()
        for auto in autos:
            mapped = frozenset({auto[e[0]], auto[e[1]]})
            orbit.add(mapped)
        orbits[e] = frozenset(orbit)
    uniq = {}
    out = {}
    for e in edges:
        o = orbits[e]
        if o not in uniq:
            uniq[o] = len(uniq)
        out[e] = uniq[o]
    return out


def compute_E_curve(G, defect_edge, s_grid, degen_tol=1e-8):
    N = G.number_of_nodes()
    edges = build_adj_list(G)
    target = tuple(sorted(defect_edge))
    if target not in edges:
        target = tuple(sorted((defect_edge[1], defect_edge[0])))
    curves = []
    for s in s_grid:
        couplings = [s if e == target else 1.0 for e in edges]
        H, basis = build_H_sz0(N, edges, couplings)
        try:
            vals, vecs = np.linalg.eigh(H)
        except Exception:
            curves.append(np.nan)
            continue
        E0 = vals[0]
        degen = np.where(np.abs(vals - E0) < degen_tol)[0]
        rho = np.zeros_like(H)
        for k in degen:
            v = vecs[:, k].reshape(-1, 1)
            rho += v @ v.conj().T
        rho /= len(degen)
        sz_config = np.array([[1.0 if state[i] == 1 else -1.0
                               for i in range(N)] for state in basis])
        rho_diag = np.diag(rho).real
        corr = []
        for (a, b) in edges:
            val = float(np.sum(rho_diag * sz_config[:, a] * sz_config[:, b]))
            corr.append(val)
        curves.append(float(np.std(corr)))
    return np.array(curves)


def compute_gap_curve(G, defect_edge, s_grid):
    N = G.number_of_nodes()
    edges = build_adj_list(G)
    target = tuple(sorted(defect_edge))
    if target not in edges:
        target = tuple(sorted((defect_edge[1], defect_edge[0])))
    gaps = []
    for s in s_grid:
        couplings = [s if e == target else 1.0 for e in edges]
        H, _ = build_H_sz0(N, edges, couplings)
        try:
            vals = np.linalg.eigvalsh(H)
            gaps.append(float(vals[1] - vals[0]))
        except Exception:
            gaps.append(np.nan)
    return np.array(gaps)


def curves_equal(c1, c2, tol=TOL):
    if len(c1) != len(c2):
        return False, np.inf
    m = ~(np.isnan(c1) | np.isnan(c2))
    if m.sum() == 0:
        return False, np.inf
    d = float(np.max(np.abs(c1[m] - c2[m])))
    return bool(d < tol), d


def identify_algebraic(x):
    if np.isnan(x):
        return "nan"
    if abs(x) < 1e-10:
        return "0"
    if abs(x - (-2.0)) < 1e-10:
        return "-2"
    if abs(x - (1 - np.sqrt(3))) < 1e-10:
        return "1-sqrt(3)"
    for q in range(1, 1001):
        p = round(x * q)
        if abs(x - p / q) < 1e-10:
            return f"{p}/{q}"
    for c in range(1, 21):
        for a in range(-20, 21):
            for b in range(-20, 21):
                if abs(a + b * x + c * x * x) < 1e-8:
                    disc = b * b - 4 * a * c
                    if disc >= 0:
                        r = np.sqrt(disc)
                        if a != 0:
                            return f"(-{b}+-sqrt({disc}))/{2*a}"
                        else:
                            return f"sqrt({disc})"
    return "未识别"


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 100)
    print("照妖镜协议 v3.0")
    print("五问并行：S_GRID、图贡献者、28对特征、窄窗口多出来的对、图106/108与-2/1-√3")
    print("=" * 100)

    print("\n[准备] 构建图集…")
    graphs = build_all_N6_graphs()
    print(f"  图集: {len(graphs)} 个 N=6 连通图")
    log_truncation("图去重", "nx.is_isomorphic")

    print("\n[准备] 预计算所有 E 曲线（宽网格 [-4,4] × 241 点）…")
    wide_grid = np.linspace(-4, 4, 241)
    all_curves = {}
    for gid, G in enumerate(graphs):
        if gid % 20 == 0:
            print(f"    {gid}/{len(graphs)}")
        edges = build_adj_list(G)
        all_curves[gid] = {e: compute_E_curve(G, e, wide_grid) for e in edges}
    print("  完成")
    log_truncation("E 曲线", "宽网格 [-4,4] × 241 点，后续所有窗口复用")

    # ============================================================
    # Q1
    # ============================================================
    print("\n" + "=" * 100)
    print("Q1. S_GRID 扫描：哪个窗口给出 32？")
    print("=" * 100)

    windows = [
        (-4, 4), (-3.5, 3.5), (-3, 3), (-2.5, 2.5), (-2, 2), (-1.5, 1.5),
        (-1, 1), (-0.5, 0.5), (0, 1), (0, 1.5), (0, 2), (0, 2.5), (0, 3),
        (0.5, 1.5), (0.5, 1.6), (0.5, 1.7), (0.5, 2.0), (0.5, 3.0),
        (-1, 2), (-1, 3), (-2, 3), (-2, 1),
    ]

    q1_results = {}
    print(f"\n  {'窗口':>18} | {'点数':>5} | {'同响应对':>8}")
    print(f"  {'-'*18}-+-{'-'*5}-+-{'-'*8}")
    for lo, hi in windows:
        mask = (wide_grid >= lo) & (wide_grid <= hi)
        n_in = int(mask.sum())
        if n_in < 5:
            continue
        pairs = set()
        for gid, G in enumerate(graphs):
            edges = build_adj_list(G)
            orbits = edge_orbits(G, edges)
            curves = all_curves[gid]
            for i in range(len(edges)):
                for j in range(i + 1, len(edges)):
                    e1, e2 = edges[i], edges[j]
                    if orbits[e1] == orbits[e2]:
                        continue
                    c1 = curves[e1][mask]
                    c2 = curves[e2][mask]
                    m = ~(np.isnan(c1) | np.isnan(c2))
                    if m.sum() == 0:
                        continue
                    d = float(np.max(np.abs(c1[m] - c2[m])))
                    if d < TOL:
                        pairs.add((gid, e1, e2))
        q1_results[(lo, hi)] = pairs
        print(f"  [{lo:>5},{hi:>5}] | {n_in:>5d} | {len(pairs):>8d}")
    log_truncation("Q1 判定", f"tol={TOL}")

    best = min(q1_results.items(), key=lambda kv: abs(len(kv[1]) - 32))
    print(f"\n  最接近 32 的窗口: {best[0]} -> {len(best[1])} 对")

    # ============================================================
    # Q3
    # ============================================================
    print("\n" + "=" * 100)
    print("Q3. 28 对（[-3,3] 窗口）的关系特征")
    print("=" * 100)

    base_window = (-3, 3)
    pairs_28 = q1_results[base_window]
    print(f"  [-3,3] 窗口：{len(pairs_28)} 对")

    rows_28 = []
    for gid, e1, e2 in sorted(pairs_28):
        G = graphs[gid]
        n1a, n1b = e1
        n2a, n2b = e2
        s1 = {n1a, n1b}
        s2 = {n2a, n2b}
        share = len(s1 & s2) > 0
        try:
            dist = nx.shortest_path_length(G, n1a, n2a)
        except Exception:
            dist = -1
        edges = build_adj_list(G)
        orbits = edge_orbits(G, edges)
        orbit_size = Counter(orbits.values())
        inter = (set(G.neighbors(n1a)) | set(G.neighbors(n1b))) & \
                (set(G.neighbors(n2a)) | set(G.neighbors(n2b)))
        union = (set(G.neighbors(n1a)) | set(G.neighbors(n1b))) | \
                (set(G.neighbors(n2a)) | set(G.neighbors(n2b)))
        row = {
            "graph_id": gid,
            "e1": e1, "e2": e2,
            "share_endpoint": share,
            "edge_distance": dist,
            "common_neighbors": len(inter),
            "neighbor_jaccard": len(inter) / len(union) if union else 0.0,
            "degree_pair_1": tuple(sorted([G.degree(n1a), G.degree(n1b)])),
            "degree_pair_2": tuple(sorted([G.degree(n2a), G.degree(n2b)])),
            "orbit_size_1": orbit_size[orbits[e1]],
            "orbit_size_2": orbit_size[orbits[e2]],
        }
        rows_28.append(row)

    print("\n  --- 关系特征汇总 ---")
    for fname in ["share_endpoint", "edge_distance", "common_neighbors",
                  "neighbor_jaccard", "orbit_size_1", "orbit_size_2",
                  "degree_pair_1", "degree_pair_2"]:
        values = [r[fname] for r in rows_28]
        cnt = Counter(values)
        print(f"\n  {fname}:")
        for v, c in sorted(cnt.items(), key=lambda x: -x[1]):
            print(f"    {fmt(v):>20}: {c}")

    print("\n  --- 28 对逐对清单 ---")
    print(f"  {'gid':>4} | {'e1':>8} | {'e2':>8} | {'share':>6} | {'dist':>4} | {'comm':>4} | {'jacc':>6}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*8}-+-{'-'*6}-+-{'-'*4}-+-{'-'*4}-+-{'-'*6}")
    for r in rows_28:
        print(f"  {r['graph_id']:>4} | {str(r['e1']):>8} | {str(r['e2']):>8} | "
              f"{fmt(r['share_endpoint']):>6} | {r['edge_distance']:>4} | "
              f"{r['common_neighbors']:>4} | {r['neighbor_jaccard']:>6.3f}")

    # ============================================================
    # Q4
    # ============================================================
    print("\n" + "=" * 100)
    print("Q4. [-1,1] 窗口比 [-3,3] 多出来的对")
    print("=" * 100)

    narrow_window = (-1, 1)
    pairs_37 = q1_results[narrow_window]
    extra = pairs_37 - pairs_28
    missing = pairs_28 - pairs_37
    print(f"  [-1,1] 窗口：{len(pairs_37)} 对")
    print(f"  [-3,3] 窗口：{len(pairs_28)} 对")
    print(f"  多出来的：{len(extra)} 对")
    print(f"  少掉的：{len(missing)} 对")

    print("\n  --- 多出来的对清单（及其在 [-3,3] 上的 max_diff）---")
    print(f"  {'gid':>4} | {'e1':>8} | {'e2':>8} | {'share':>6} | {'dist':>4} | {'max_diff@[-3,3]':>18} | {'s_at_max':>10}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*8}-+-{'-'*6}-+-{'-'*4}-+-{'-'*18}-+-{'-'*10}")
    for gid, e1, e2 in sorted(extra):
        G = graphs[gid]
        n1a, n1b = e1
        n2a, n2b = e2
        share = len({n1a, n1b} & {n2a, n2b}) > 0
        try:
            dist = nx.shortest_path_length(G, n1a, n2a)
        except Exception:
            dist = -1
        mask3 = (wide_grid >= -3) & (wide_grid <= 3)
        c1 = all_curves[gid][e1][mask3]
        c2 = all_curves[gid][e2][mask3]
        m = ~(np.isnan(c1) | np.isnan(c2))
        if m.sum() > 0:
            diffs = np.abs(c1 - c2)
            d = float(np.max(diffs[m]))
            idx_full = int(np.nanargmax(diffs))
            s_at_max = wide_grid[mask3][idx_full]
            print(f"  {gid:>4} | {str(e1):>8} | {str(e2):>8} | {fmt(share):>6} | {dist:>4} | {d:>18.3e} | {s_at_max:>10.3f}")

    # ============================================================
    # Q2
    # ============================================================
    print("\n" + "=" * 100)
    print("Q2. 贡献者图（9、26、33、49、55、64、69、83）的边集与关系结构")
    print("=" * 100)

    contributor_gids = sorted(set(g for g, _, _ in pairs_28))
    for gid in contributor_gids:
        G = graphs[gid]
        edges = build_adj_list(G)
        degs = sorted(d for _, d in G.degree())
        orbits = edge_orbits(G, edges)
        orbit_size = Counter(orbits.values())
        contributed = [(g, e1, e2) for (g, e1, e2) in pairs_28 if g == gid]
        print(f"\n  图 {gid}:")
        print(f"    边数: {G.number_of_edges()}")
        print(f"    边集: {edges}")
        print(f"    度序列: {degs}")
        print(f"    轨道数: {len(orbit_size)}, 轨道大小: {dict(orbit_size)}")
        print(f"    贡献 {len(contributed)} 对:")
        for g, e1, e2 in contributed:
            print(f"      {e1} - {e2}")

    # ============================================================
    # Q5
    # ============================================================
    print("\n" + "=" * 100)
    print("Q5. 图 106、108 定位与 -2 / 1-sqrt(3)")
    print("=" * 100)

    K6 = nx.complete_graph(N_NODES)
    K6_edges = list(K6.edges())
    k6minus2_matches = []
    for removed_pair in combinations(K6_edges, 2):
        G_test = K6.copy()
        G_test.remove_edges_from(removed_pair)
        if not nx.is_connected(G_test):
            continue
        for gid, G in enumerate(graphs):
            if nx.is_isomorphic(G_test, G):
                shared = bool(set(removed_pair[0]) & set(removed_pair[1]))
                k6minus2_matches.append({
                    "gid": gid,
                    "removed": removed_pair,
                    "shared": shared,
                })
                break

    unique_k6 = {}
    for m in k6minus2_matches:
        unique_k6[m["gid"]] = m
    k6minus2_unique = list(unique_k6.values())

    print(f"\n  在 112 个图中，K6 减两条边的连通图：{len(k6minus2_unique)} 个")
    shared_count = sum(1 for m in k6minus2_unique if m["shared"])
    disjoint_count = sum(1 for m in k6minus2_unique if not m["shared"])
    print(f"    共享端点类型（对应 图108 类型）: {shared_count}")
    print(f"    不共享端点类型（对应 图106 类型）: {disjoint_count}")

    print("\n  --- K6 减两条边的图清单 ---")
    print(f"  {'gid':>4} | {'removed':>20} | {'shared':>8}")
    print(f"  {'-'*4}-+-{'-'*20}-+-{'-'*8}")
    for m in k6minus2_unique:
        print(f"  {m['gid']:>4} | {str(m['removed']):>20} | {fmt(m['shared']):>8}")

    print("\n  --- 这些图中识别出的常数能隙差（按代数数识别）---")
    print(f"  {'gid':>4} | {'e1':>8} | {'e2':>8} | {'gap_diff_mean':>16} | {'std':>10} | {'identified':>15}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*8}-+-{'-'*16}-+-{'-'*10}-+-{'-'*15}")
    for m in k6minus2_unique:
        gid = m["gid"]
        G = graphs[gid]
        edges = build_adj_list(G)
        gap_cache = {}
        for e in edges:
            gap_cache[e] = compute_gap_curve(G, e, wide_grid)
        for i in range(len(edges)):
            for j in range(i + 1, len(edges)):
                e1, e2 = edges[i], edges[j]
                g1 = gap_cache[e1]
                g2 = gap_cache[e2]
                diff = g1 - g2
                m_valid = ~(np.isnan(diff))
                if m_valid.sum() == 0:
                    continue
                mean_diff = float(np.mean(diff[m_valid]))
                std_diff = float(np.std(diff[m_valid]))
                identified = identify_algebraic(mean_diff)
                if identified != "未识别" or std_diff < 1e-8:
                    print(f"  {gid:>4} | {str(e1):>8} | {str(e2):>8} | "
                          f"{mean_diff:>16.10f} | {std_diff:>10.3e} | {identified:>15}")

    print("\n  --- 专门检查：s=0 处 gap_diff == -2，s=0.5 处 gap_diff == 1-sqrt(3) ---")
    print(f"  {'场景':>8} | {'gid':>4} | {'e1':>8} | {'e2':>8} | {'gap_diff':>16} | {'命中':>10}")
    print(f"  {'-'*8}-+-{'-'*4}-+-{'-'*8}-+-{'-'*8}-+-{'-'*16}-+-{'-'*10}")
    target_minus2 = -2.0
    target_1msqrt3 = 1 - np.sqrt(3)
    hits = []
    for m in k6minus2_unique:
        gid = m["gid"]
        G = graphs[gid]
        edges = build_adj_list(G)
        for i in range(len(edges)):
            for j in range(i + 1, len(edges)):
                e1, e2 = edges[i], edges[j]
                for s_val, target, name in [(0.0, target_minus2, "s=0"),
                                            (0.5, target_1msqrt3, "s=0.5")]:
                    g1 = compute_gap_curve(G, e1, np.array([s_val]))[0]
                    g2 = compute_gap_curve(G, e2, np.array([s_val]))[0]
                    d = g1 - g2
                    hit = abs(d - target) < 1e-10
                    if hit:
                        hits.append({
                            "scene": name, "gid": gid,
                            "e1": e1, "e2": e2,
                            "gap_diff": d,
                            "target": target,
                        })
                        print(f"  {name:>8} | {gid:>4} | {str(e1):>8} | {str(e2):>8} | "
                              f"{d:>16.10f} | {fmt(hit):>10}")
    if not hits:
        print("  （无命中）")

    # ============================================================
    # 导出
    # ============================================================
    out = {
        "Q1_windows": {f"{lo}_{hi}": len(p) for (lo, hi), p in q1_results.items()},
        "Q3_28_pairs": [
            {"gid": r["graph_id"], "e1": list(r["e1"]), "e2": list(r["e2"]),
             "share": r["share_endpoint"], "dist": r["edge_distance"],
             "common_neighbors": r["common_neighbors"],
             "neighbor_jaccard": r["neighbor_jaccard"],
             "orbit_size_1": r["orbit_size_1"],
             "orbit_size_2": r["orbit_size_2"]} for r in rows_28
        ],
        "Q4_extra": [{"gid": g, "e1": list(e1), "e2": list(e2)}
                     for g, e1, e2 in sorted(extra)],
        "Q2_figures": {
            gid: {
                "edges": [list(e) for e in build_adj_list(graphs[gid])],
                "deg_seq": sorted(d for _, d in graphs[gid].degree()),
            } for gid in contributor_gids
        },
        "Q5_k6minus2": [
            {"gid": m["gid"],
             "removed": [list(e) for e in m["removed"]],
             "shared": m["shared"]} for m in k6minus2_unique
        ],
        "Q5_hits": [
            {"scene": h["scene"], "gid": h["gid"],
             "e1": list(h["e1"]), "e2": list(h["e2"]),
             "gap_diff": h["gap_diff"], "target": h["target"]}
            for h in hits
        ],
    }

    def convert(o):
        if isinstance(o, np.integer):
            return int(o)
        if isinstance(o, np.floating):
            return float(o)
        if isinstance(o, np.bool_):
            return bool(o)
        if isinstance(o, np.ndarray):
            return o.tolist()
        if isinstance(o, tuple):
            return list(o)
        if isinstance(o, set):
            return list(o)
        return str(o)

    out_path = os.path.join(WORK_DIR, "照妖镜_五问_v3.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=convert)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("五问完成。结果并排。不筛选。不下结论。")
    print("脚本是对象化，追问是行动。")
    print("=" * 100)


if __name__ == "__main__":
    main()