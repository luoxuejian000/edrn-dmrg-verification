#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 vA.0：精确定位路径 A 的临界扰动
================================================================

已知：
  路径 A（纯关系网络）给出 A-B = 0 的临界扰动
  N=20 时 ≈ 0.28，N=50 时 ≈ 0.29
  路径 B 给 1.25（稳定），路径 C 给 0.5（漂移）

五个追问并行：
  Q1. 临界扰动如何随 N 缩放？是否收敛到一个代数数？
  Q2. 临界扰动在随机种子间是否稳定？数值假象还是关系结构？
  Q3. A 和 B 的平均值在临界扰动处是否相等？等于什么？
  Q4. 临界扰动与 1.25 和 0.5 是否有代数关系？
  Q5. 所有响应量（std、mean、ratio、A-B）在临界点是否同时锁定？
"""

import numpy as np
import networkx as nx
from itertools import combinations
from scipy.optimize import brentq
from collections import Counter, defaultdict
import json, os

# ============================================================
# 基础：构建纯关系网络
# ============================================================

def build_network(N, seed=42):
    np.random.seed(seed)
    positions = []
    for _ in range(N):
        while True:
            p = np.random.uniform(-1, 1, 3)
            if np.linalg.norm(p) <= 1:
                positions.append(p)
                break
    positions = np.array(positions)
    G = nx.Graph()
    for i in range(N):
        G.add_node(i, pos=positions[i])
    for i, j in combinations(range(N), 2):
        d = np.linalg.norm(positions[i] - positions[j])
        if d > 1e-6:
            G.add_edge(i, j, weight=1.0/d**2, dist=d)
    return G, positions


def mark_types(G, positions):
    for i, j in G.edges:
        mid = (positions[i] + positions[j]) / 2
        if abs(mid[2]) > np.sqrt(mid[0]**2 + mid[1]**2):
            G[i][j]['type'] = 'A'
        else:
            G[i][j]['type'] = 'B'


def response_A(G, perturb):
    w_A, w_B = [], []
    for i, j in G.edges:
        w = G[i][j]['weight']
        w_eff = w * (1 - perturb) if G[i][j]['type'] == 'B' else w
        if G[i][j]['type'] == 'A':
            w_A.append(w_eff)
        else:
            w_B.append(w_eff)
    if not w_A or not w_B:
        return None
    all_w = np.array(w_A + w_B)
    return {
        "std": float(np.std(all_w)),
        "mean": float(np.mean(all_w)),
        "ratio_std_mean": float(np.std(all_w) / (np.mean(all_w) + 1e-12)),
        "A_mean": float(np.mean(w_A)),
        "B_mean": float(np.mean(w_B)),
        "diff_A_B": float(np.mean(w_A) - np.mean(w_B)),
    }


# ============================================================
# Q1: 临界扰动随 N 的缩放
# ============================================================

def find_critical_perturbation(N, seed=42, bracket=(-0.5, 1.0)):
    """用 brentq 精确求解 A-B = 0 的扰动值。"""
    G, positions = build_network(N, seed)
    mark_types(G, positions)
    
    def f(pert):
        r = response_A(G, pert)
        return r["diff_A_B"] if r else np.nan
    
    # 扫描 bracket 内所有符号变化
    x_grid = np.linspace(bracket[0], bracket[1], 200)
    vals = np.array([f(x) for x in x_grid])
    crossings = []
    for i in range(len(x_grid) - 1):
        if np.isnan(vals[i]) or np.isnan(vals[i+1]):
            continue
        if vals[i] * vals[i+1] < 0:
            try:
                x_root = brentq(f, x_grid[i], x_grid[i+1], xtol=1e-14)
                crossings.append(x_root)
            except Exception:
                pass
    return crossings, G


def scan_N(N_list, seed=42):
    print("=" * 100)
    print("Q1. 临界扰动随 N 的缩放")
    print("=" * 100)
    print(f"\n  {'N':>6} | {'边数':>6} | {'A边':>5} | {'B边':>5} | {'临界扰动':>16} | {'A-B@临界':>12}")
    print(f"  {'-'*6}-+-{'-'*6}-+-{'-'*5}-+-{'-'*5}-+-{'-'*16}-+-{'-'*12}")
    
    results = []
    for N in N_list:
        crossings, G = find_critical_perturbation(N, seed)
        n_edges = G.number_of_edges()
        n_A = sum(1 for i,j in G.edges if G[i][j]['type']=='A')
        n_B = n_edges - n_A
        if crossings:
            for x in crossings:
                r = response_A(G, x)
                print(f"  {N:>6} | {n_edges:>6} | {n_A:>5} | {n_B:>5} | "
                      f"{x:>16.10f} | {r['diff_A_B']:>12.2e}")
                results.append({"N": N, "seed": seed, "x_critical": x,
                                "n_edges": n_edges, "n_A": n_A, "n_B": n_B})
        else:
            print(f"  {N:>6} | {n_edges:>6} | {n_A:>5} | {n_B:>5} | {'无临界点':>16} | {'-':>12}")
    return results


# ============================================================
# Q2: 临界扰动在种子间的稳定性
# ============================================================

def scan_seeds(N, seeds=range(10)):
    print("\n" + "=" * 100)
    print(f"Q2. 临界扰动在 {len(list(seeds))} 个随机种子间的稳定性（N={N}）")
    print("=" * 100)
    print(f"\n  {'seed':>6} | {'A边':>5} | {'B边':>5} | {'临界扰动':>16}")
    print(f"  {'-'*6}-+-{'-'*5}-+-{'-'*5}-+-{'-'*16}")
    
    all_crossings = []
    for seed in seeds:
        crossings, G = find_critical_perturbation(N, seed)
        n_A = sum(1 for i,j in G.edges if G[i][j]['type']=='A')
        n_B = G.number_of_edges() - n_A
        for x in crossings:
            print(f"  {seed:>6} | {n_A:>5} | {n_B:>5} | {x:>16.10f}")
            all_crossings.append(x)
    
    if all_crossings:
        arr = np.array(all_crossings)
        print(f"\n  统计:")
        print(f"    mean = {np.mean(arr):.10f}")
        print(f"    std  = {np.std(arr):.10f}")
        print(f"    min  = {np.min(arr):.10f}")
        print(f"    max  = {np.max(arr):.10f}")
        # 代数数识别
        print(f"\n  代数数识别:")
        print(f"    mean × 7 = {np.mean(arr)*7:.10f}")
        print(f"    mean × 3.5 = {np.mean(arr)*3.5:.10f}")
        print(f"    mean × 2 = {np.mean(arr)*2:.10f}")
        print(f"    1/mean = {1/np.mean(arr):.10f}")
    return all_crossings


# ============================================================
# Q3: 临界点处 A 和 B 的平均值
# ============================================================

def scan_AB_at_critical(N_list, seed=42):
    print("\n" + "=" * 100)
    print("Q3. 临界点处 A 和 B 的平均值")
    print("=" * 100)
    print(f"\n  {'N':>6} | {'perturb':>12} | {'A_mean':>12} | {'B_mean':>12} | {'A/B':>10} | {'A-B':>12}")
    print(f"  {'-'*6}-+-{'-'*12}-+-{'-'*12}-+-{'-'*12}-+-{'-'*10}-+-{'-'*12}")
    
    for N in N_list:
        crossings, G = find_critical_perturbation(N, seed)
        for x in crossings:
            r = response_A(G, x)
            ratio = r['A_mean'] / r['B_mean'] if r['B_mean'] > 1e-12 else np.nan
            print(f"  {N:>6} | {x:>12.8f} | {r['A_mean']:>12.8f} | "
                  f"{r['B_mean']:>12.8f} | {ratio:>10.6f} | {r['diff_A_B']:>12.2e}")


# ============================================================
# Q4: 临界扰动与 1.25 / 0.5 的代数关系
# ============================================================

def scan_algebraic_relation(N_list, seed=42):
    print("\n" + "=" * 100)
    print("Q4. 临界扰动与 1.25 和 0.5 的代数关系")
    print("=" * 100)
    print(f"\n  {'N':>6} | {'x_critical':>14} | {'1.25/x':>10} | {'0.5/x':>10} | {'x×4':>10} | {'x×7':>10}")
    print(f"  {'-'*6}-+-{'-'*14}-+-{'-'*10}-+-{'-'*10}-+-{'-'*10}-+-{'-'*10}")
    
    for N in N_list:
        crossings, G = find_critical_perturbation(N, seed)
        for x in crossings:
            print(f"  {N:>6} | {x:>14.10f} | {1.25/x:>10.6f} | "
                  f"{0.5/x:>10.6f} | {x*4:>10.6f} | {x*7:>10.6f}")


# ============================================================
# Q5: 所有响应量在临界点是否同时锁定
# ============================================================

def scan_all_quantities(N, seed=42, delta=0.05):
    print("\n" + "=" * 100)
    print(f"Q5. 所有响应量在临界点附近的行为（N={N}）")
    print("=" * 100)
    
    crossings, G = find_critical_perturbation(N, seed)
    if not crossings:
        print("  无临界点")
        return
    x_c = crossings[0]
    
    print(f"\n  临界扰动 x_c = {x_c:.10f}")
    print(f"\n  {'perturb':>10} | {'std':>10} | {'mean':>10} | {'ratio':>10} | {'A_mean':>10} | {'B_mean':>10} | {'A-B':>12}")
    print(f"  {'-'*10}-+-{'-'*10}-+-{'-'*10}-+-{'-'*10}-+-{'-'*10}-+-{'-'*10}-+-{'-'*12}")
    
    for pert in np.linspace(x_c - delta, x_c + delta, 11):
        r = response_A(G, pert)
        if r:
            print(f"  {pert:>10.6f} | {r['std']:>10.6f} | {r['mean']:>10.6f} | "
                  f"{r['ratio_std_mean']:>10.6f} | {r['A_mean']:>10.6f} | "
                  f"{r['B_mean']:>10.6f} | {r['diff_A_B']:>12.2e}")


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 100)
    print("照妖镜 vA.0：精确定位路径 A 的临界扰动")
    print("=" * 100)
    
    # Q1: N 缩放
    N_list = [10, 15, 20, 30, 40, 50, 75, 100, 150, 200]
    q1_results = scan_N(N_list)
    
    # Q2: 种子稳定性
    q2_results = scan_seeds(N=50, seeds=range(20))
    
    # Q3: 临界点处 A/B 的平均值
    scan_AB_at_critical([20, 50, 100])
    
    # Q4: 代数关系
    scan_algebraic_relation([20, 50, 100])
    
    # Q5: 所有响应量
    scan_all_quantities(N=50, delta=0.05)
    
    # 导出
    out = {
        "Q1_N_scaling": q1_results,
        "Q2_seed_stability": q2_results,
    }
    out_path = os.path.join(os.path.expanduser("~"), "照妖镜_vA_临界扰动.json")
    with open(out_path, "w") as f:
        json.dump(out, f, indent=2, default=str)
    print(f"\n[导出: {out_path}]")


if __name__ == "__main__":
    main()