#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
32对异轨道同响应的特征解剖：更粗等价类的候选特征
======================================================

核心追问：
- 32 对异轨道同响应有什么共同结构？
- 是否存在一个特征在 32 对中相同率远高于随机？

理论精髓：
- 关系本体论：更粗等价类是关系场的对称结构
- 只查同与不同：8 个特征并行
- 反对对齐：不预设"必然存在一个特征完美刻画 32 对"
- 严防工具理性悖论：不做拟合，直接统计

运行：
    python 32对特征解剖.py
"""

import sys
import io
import json
import itertools
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from networkx.algorithms.isomorphism import GraphMatcher
from collections import defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)


I2 = np.eye(2, dtype=complex)
SX = np.array([[0, 1], [1, 0]], dtype=complex)
SY = np.array([[0, -1j], [1j, 0]], dtype=complex)
SZ = np.array([[1, 0], [0, -1]], dtype=complex)


def op_on_site(op, site, N):
    ops = [I2] * N
    ops[site] = op
    out = ops[0]
    for o in ops[1:]:
        out = np.kron(out, o)
    return out


def build_site_ops(N):
    return ([op_on_site(SX, i, N) for i in range(N)],
            [op_on_site(SY, i, N) for i in range(N)],
            [op_on_site(SZ, i, N) for i in range(N)])


def edge_matrix(i, j, SX_ops, SY_ops, SZ_ops):
    return SX_ops[i] @ SX_ops[j] + SY_ops[i] @ SY_ops[j] + SZ_ops[i] @ SZ_ops[j]


def ground_state_density(H, tol=1e-8):
    evals, evecs = eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < tol))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    return E0, rho, deg


def edge_correlations(rho, edges, SZ_ops):
    C = {}
    for (i, j) in edges:
        op = SZ_ops[i] @ SZ_ops[j]
        C[(i, j)] = float(np.real(np.trace(rho @ op)))
    return C


def compute_sorted_curve(G, defect_edge, s_vals, SX_ops, SY_ops, SZ_ops):
    N = G.number_of_nodes()
    edges = [tuple(sorted(e)) for e in G.edges()]
    H_edges = {e: edge_matrix(e[0], e[1], SX_ops, SY_ops, SZ_ops) for e in edges}
    H0 = sum(H_edges.values())
    M_defect = H_edges[defect_edge]
    curve = []
    for s in s_vals:
        H = H0 + (s - 1.0) * M_defect
        E0, rho, deg = ground_state_density(H)
        C = edge_correlations(rho, edges, SZ_ops)
        curve.append(tuple(np.round(sorted(C.values()), 12)))
    return curve


def find_involution_pairs(G):
    nodes = list(G.nodes())
    matcher = GraphMatcher(G, G)
    pairs = set()
    for mapping in matcher.isomorphisms_iter():
        if not all(mapping[mapping[u]] == u for u in nodes):
            continue
        if all(mapping[u] == u for u in nodes):
            continue
        for u, v in G.edges():
            e1 = tuple(sorted((u, v)))
            u2, v2 = mapping[u], mapping[v]
            e2 = tuple(sorted((u2, v2)))
            if e1 != e2 and G.has_edge(u2, v2):
                pairs.add(tuple(sorted([e1, e2])))
    return pairs


def find_edge_orbits(G):
    nodes = list(G.nodes())
    edges = [tuple(sorted(e)) for e in G.edges()]
    matcher = GraphMatcher(G, G)
    orbit_id = {e: None for e in edges}
    oid = 0
    for e in edges:
        if orbit_id[e] is not None:
            continue
        orbit_id[e] = oid
        for mapping in matcher.isomorphisms_iter():
            u, v = e
            u2, v2 = mapping[u], mapping[v]
            e2 = tuple(sorted((u2, v2)))
            if G.has_edge(u2, v2):
                orbit_id[e2] = oid
        oid += 1
    return orbit_id


def edge_features(G, edge):
    u, v = edge
    deg_u = G.degree(u)
    deg_v = G.degree(v)
    H = G.copy()
    H.remove_edge(u, v)
    is_bridge = not nx.is_connected(H)
    common_neighbors = len(set(G.neighbors(u)) & set(G.neighbors(v)))
    neighbors_u = [G.degree(w) for w in G.neighbors(u) if w != v]
    neighbors_v = [G.degree(w) for w in G.neighbors(v) if w != u]
    neighbor_deg_seq = tuple(sorted(neighbors_u + neighbors_v))
    try:
        ecc_u = nx.eccentricity(G, u)
        ecc_v = nx.eccentricity(G, v)
        ecc_sum = ecc_u + ecc_v
    except Exception:
        ecc_sum = 0
    try:
        edge_bc = nx.edge_betweenness_centrality(G)
        bc = edge_bc.get((u, v), edge_bc.get((v, u), 0.0))
    except Exception:
        bc = 0.0
    cc_sum = nx.clustering(G, u) + nx.clustering(G, v)
    return {
        "deg_pair": tuple(sorted([deg_u, deg_v])),
        "is_bridge": is_bridge,
        "common_neighbors": common_neighbors,
        "neighbor_deg_seq": neighbor_deg_seq,
        "ecc_sum": ecc_sum,
        "edge_betweenness": bc,
        "cc_sum": cc_sum,
    }


def generate_all_connected_graphs(N):
    all_edges = list(itertools.combinations(range(N), 2))
    graphs = []
    for m in range(N - 1, len(all_edges) + 1):
        for combo in itertools.combinations(all_edges, m):
            G = nx.Graph()
            G.add_nodes_from(range(N))
            G.add_edges_from(combo)
            if nx.is_connected(G):
                graphs.append(G)
    return graphs


def main():
    s_vals = np.linspace(-1.5, 0.0, 11)
    print("=" * 78)
    print("  32 对异轨道同响应的特征解剖")
    print("=" * 78)
    print(f"  s: [{s_vals[0]}, {s_vals[-1]}], {len(s_vals)} 点")
    print()

    SX_ops, SY_ops, SZ_ops = build_site_ops(6)
    graphs = generate_all_connected_graphs(6)
    print(f"  N=6 连通图总数: {len(graphs)}")
    print()

    edge_data = []
    for gid, G in enumerate(graphs):
        edges = [tuple(sorted(e)) for e in G.edges()]
        orbits = find_edge_orbits(G)
        for e in edges:
            curve = compute_sorted_curve(G, e, s_vals,
                                         SX_ops, SY_ops, SZ_ops)
            ef = edge_features(G, e)
            edge_data.append({
                "gid": gid, "edge": e, "curve": curve,
                "orbit": orbits[e], "features": ef,
            })
        if (gid + 1) % 20 == 0:
            print(f"    已处理 {gid + 1}/{len(graphs)} 图")

    print()
    n = len(edge_data)
    same_curve_pairs = []
    for i in range(n):
        for j in range(i + 1, n):
            if edge_data[i]["gid"] != edge_data[j]["gid"]:
                continue
            ci = edge_data[i]["curve"]
            cj = edge_data[j]["curve"]
            if len(ci) != len(cj):
                continue
            same = all(
                len(a) == len(b) and np.allclose(a, b, atol=1e-10)
                for a, b in zip(ci, cj)
            )
            if same:
                same_curve_pairs.append((i, j))

    same_orbit_same = []
    diff_orbit_same = []
    for i, j in same_curve_pairs:
        if edge_data[i]["orbit"] == edge_data[j]["orbit"]:
            same_orbit_same.append((i, j))
        else:
            diff_orbit_same.append((i, j))

    print(f"  同轨道同响应: {len(same_orbit_same)}")
    print(f"  异轨道同响应: {len(diff_orbit_same)}")
    print()

    # 收集所有异轨道对（包括同响应和不同响应）
    all_diff_orbit = []
    by_gid = defaultdict(list)
    for idx, ed in enumerate(edge_data):
        by_gid[ed["gid"]].append(idx)
    for gid, indices in by_gid.items():
        for ii in range(len(indices)):
            for jj in range(ii + 1, len(indices)):
                i, j = indices[ii], indices[jj]
                if edge_data[i]["orbit"] != edge_data[j]["orbit"]:
                    all_diff_orbit.append((i, j))

    feature_names = ["deg_pair", "is_bridge", "common_neighbors",
                     "neighbor_deg_seq", "ecc_sum", "edge_betweenness", "cc_sum"]

    print(f"  {'特征':<24}{'32对同响应':<16}{'随机异轨道':<16}{'差值':<12}")
    print(f"  {'-'*24}{'-'*16}{'-'*16}{'-'*12}")

    for fname in feature_names:
        same_resp = sum(
            1 for i, j in diff_orbit_same
            if edge_data[i]["features"][fname] == edge_data[j]["features"][fname]
        ) / len(diff_orbit_same) if diff_orbit_same else 0

        same_rand = sum(
            1 for i, j in all_diff_orbit
            if edge_data[i]["features"][fname] == edge_data[j]["features"][fname]
        ) / len(all_diff_orbit) if all_diff_orbit else 0

        diff = same_resp - same_rand
        print(f"  {fname:<24}{same_resp:<16.4f}{same_rand:<16.4f}{diff:<12.4f}")

    print()

    output = {
        "diff_orbit_same": len(diff_orbit_same),
        "all_diff_orbit": len(all_diff_orbit),
    }
    with open("32对特征解剖结果.json", "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2, default=str)
    print("已保存: 32对特征解剖结果.json")


if __name__ == "__main__":
    main()