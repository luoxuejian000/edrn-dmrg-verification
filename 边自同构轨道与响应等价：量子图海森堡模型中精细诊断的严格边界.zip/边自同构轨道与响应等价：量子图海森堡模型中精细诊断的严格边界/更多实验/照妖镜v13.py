#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 v13.0：五问并行攻击 N=7 的结构差异
================================================================

五问：
  Q1. N=7 的 p_S(s) 曲线形状：连续穿过 1/2 还是台阶？
  Q2. N=7 的 S 值分布：为什么 S 有 0.5 到 2.5，不集中在 S=1/2？
  Q3. N=6 的 0.5 倍数规律从哪来：偶自旋特有还是对称性强制？
  Q4. N=7 的简并 -1 命中率 37.6%：比 N=6 的 65.5% 低一半，为什么？
  Q5. N=7 的 4172 个唯一 s 值：能代数识别多少？

晶脉哲学：
  · 关系本体论：S_z=0 扇区是关系网络的对称切片
  · 对象化=截断=产生方向：每个分析都是一次截断
  · 只查同与不同：不筛选，不排序
  · 反对对齐：不预设结论
"""

import sys, io, itertools, json, os
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from scipy.optimize import brentq
from collections import Counter, defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"
TOL = 1e-10


# ============================================================
# 基础：S_z=0 扇区构建
# ============================================================

def build_sz0_sector(N):
    n_up = N // 2
    basis = []
    for comb in itertools.combinations(range(N), n_up):
        state = [0]*N
        for i in comb: state[i] = 1
        basis.append(tuple(state))
    dim = len(basis)
    idx = {s: i for i, s in enumerate(basis)}
    SZ_ops = []
    for site in range(N):
        SZ = np.zeros((dim, dim), dtype=complex)
        for i, state in enumerate(basis):
            SZ[i, i] = 1 if state[site] == 1 else -1
        SZ_ops.append(SZ)
    return basis, idx, SZ_ops


def build_edge_op(i, j, basis, idx):
    dim = len(basis)
    op = np.zeros((dim, dim), dtype=complex)
    for a_idx, state_a in enumerate(basis):
        sa, sb = state_a[i], state_a[j]
        if sa == sb:
            op[a_idx, a_idx] += 1
        else:
            op[a_idx, a_idx] += -1
            new_state = list(state_a)
            new_state[i], new_state[j] = new_state[j], new_state[i]
            b_idx = idx.get(tuple(new_state))
            if b_idx is not None:
                op[b_idx, a_idx] += 2
    return op


def build_S2_op(basis, idx, N):
    dim = len(basis)
    S2 = np.zeros((dim, dim), dtype=complex)
    for i in range(N):
        S2 += 3/4 * np.eye(dim, dtype=complex)
        for j in range(N):
            if i == j: continue
            S2 += 1/4 * build_edge_op(i, j, basis, idx)
    return S2


# ============================================================
# p_S 计算
# ============================================================

def pS_at_s(edge_ops, defect, s, SZ_ops, ref_dim):
    H = np.zeros((ref_dim, ref_dim), dtype=complex)
    for e, M in edge_ops.items():
        c = s if e == defect else 1.0
        H += c * M
    evals, evecs = eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < 1e-8))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    i, j = defect
    szsz_diag = np.diag(SZ_ops[i] @ SZ_ops[j])
    szsz = float(np.real(np.sum(np.diag(rho) * szsz_diag)))
    p_S = (1 - 3 * szsz) / 4
    return p_S, deg, E0, evals, evecs


def analyze_at_s(edge_ops, defect, s, SZ_ops, S2_op, ref_dim):
    p_S, deg, E0, evals, evecs = pS_at_s(edge_ops, defect, s, SZ_ops, ref_dim)
    V = evecs[:, :deg]
    per_state_sigdot = []
    per_state_S = []
    for k in range(deg):
        v = V[:, k]
        sd = float(np.real(v.conj() @ edge_ops[defect] @ v))
        s2 = float(np.real(v.conj() @ S2_op @ v))
        S_val = (-1 + np.sqrt(1 + 4*max(s2, 0))) / 2
        per_state_sigdot.append(sd)
        per_state_S.append(S_val)
    return {
        "p_S": p_S, "deg": deg, "E0": float(E0),
        "mean_sigdot": float(np.mean(per_state_sigdot)),
        "per_state_sigdot": per_state_sigdot,
        "per_state_S": per_state_S,
    }


# ============================================================
# 代数识别（扩展版）
# ============================================================

def identify_algebraic(s, max_coef=30, tol=1e-8):
    """
    搜索整数 a,b,c ∈ [-max_coef, max_coef]，a ≠ 0，
    使得 |a·s² + b·s + c| < tol。
    """
    if abs(s) < 1e-10: return "0"
    # 0.5 倍数
    if abs(s - round(s*2)/2) < 1e-10:
        return f"{round(s*2)/2}（0.5 倍数）"
    # 有理数
    for q in range(1, 21):
        p = round(s * q)
        if abs(s - p/q) < 1e-10:
            return f"{p}/{q}"
    # 二次代数数
    for a in range(1, max_coef+1):
        for b in range(-max_coef, max_coef+1):
            for c in range(-max_coef, max_coef+1):
                if abs(a*s*s + b*s + c) < tol:
                    disc = b*b - 4*a*c
                    if disc >= 0:
                        return f"({-b}±√{disc})/{2*a}"
    return "未识别"


# ============================================================
# 图集构建
# ============================================================

def build_graphs(N, max_count=None):
    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    if max_count:
        # 均匀抽样
        step = max(1, len(graphs) // max_count)
        graphs = graphs[::step][:max_count]
    return graphs


# ============================================================
# Q1: N=7 的 p_S(s) 曲线形状
# ============================================================

def q1_curve_shape(graphs, N, basis, idx, SZ_ops, S2_op, ref_dim,
                   n_samples=50, n_points=101):
    """
    对抽样图的抽样缺陷边，精细采样 p_S(s)，分析曲线形状：
    - 单调性
    - 导数
    - 是否穿越 1/2
    """
    print("\n" + "=" * 100)
    print(f"Q1. N={N} 的 p_S(s) 曲线形状（{n_samples} 图 × {n_points} 点采样）")
    print("=" * 100)

    s_grid = np.linspace(-2.0, 2.0, n_points)
    results = []

    sample_graphs = graphs[::max(1, len(graphs)//n_samples)][:n_samples]
    for gid, G in enumerate(sample_graphs):
        edges = [tuple(sorted(e)) for e in G.edges()]
        edge_ops = {e: build_edge_op(e[0], e[1], basis, idx) for e in edges}
        # 每条边作为缺陷边采样
        for defect in edges[:3]:  # 取前 3 条边
            curve = []
            for s in s_grid:
                p_S, _, _, _, _ = pS_at_s(edge_ops, defect, s, SZ_ops, ref_dim)
                curve.append(p_S)
            curve = np.array(curve)

            # 单调性分析
            diffs = np.diff(curve)
            pos = int((diffs > 1e-6).sum())
            neg = int((diffs < -1e-6).sum())
            flat = int((np.abs(diffs) <= 1e-6).sum())

            # 导数最大值
            max_deriv = float(np.max(np.abs(diffs)))

            # 是否穿越 1/2
            crosses_half = bool((curve.min() < 0.5) and (curve.max() > 0.5))

            # 台阶检测：连续 5 点导数 < 1e-8 但后面又有大跳
            is_step = False
            # 简化：如果 flat 比例 > 50%
            if flat / len(diffs) > 0.5:
                is_step = True

            results.append({
                "gid": gid, "defect": list(defect),
                "pos": pos, "neg": neg, "flat": flat,
                "n_diffs": len(diffs),
                "max_deriv": max_deriv,
                "crosses_half": crosses_half,
                "curve": curve.tolist(),
                "is_step": is_step,
            })

    # 汇总
    n_total = len(results)
    n_cross = sum(1 for r in results if r["crosses_half"])
    n_step = sum(1 for r in results if r["is_step"])
    n_monotone = sum(1 for r in results
                     if r["pos"] == 0 or r["neg"] == 0)

    print(f"\n  样本数: {n_total}")
    print(f"  穿越 1/2 的: {n_cross}/{n_total} = {n_cross/n_total:.1%}")
    print(f"  是台阶的: {n_step}/{n_total} = {n_step/n_total:.1%}")
    print(f"  单调的: {n_monotone}/{n_total} = {n_monotone/n_total:.1%}")

    print(f"\n  {'gid':>4} | {'defect':>8} | {'pos':>4} | {'neg':>4} | {'flat':>4} | "
          f"{'max_deriv':>12} | {'穿越':>4} | {'台阶':>4}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*4}-+-{'-'*4}-+-{'-'*4}-+-"
          f"{'-'*12}-+-{'-'*4}-+-{'-'*4}")
    for r in results[:30]:
        print(f"  {r['gid']:>4} | {str(r['defect']):>8} | {r['pos']:>4} | "
              f"{r['neg']:>4} | {r['flat']:>4} | {r['max_deriv']:>12.6f} | "
              f"{str(r['crosses_half']):>4} | {str(r['is_step']):>4}")

    return results


# ============================================================
# Q2: N=7 的 S 值分布
# ============================================================

def q2_spin_distribution(graphs, N, basis, idx, SZ_ops, S2_op, ref_dim,
                         n_samples=100):
    """
    对抽样图的每条缺陷边，计算基态的 S 值，统计分布。
    """
    print("\n" + "=" * 100)
    print(f"Q2. N={N} 的 S 值分布（{n_samples} 图，每个图的每条边）")
    print("=" * 100)

    sample_graphs = graphs[::max(1, len(graphs)//n_samples)][:n_samples]
    all_S = []
    all_deg = []
    by_gid = defaultdict(list)

    for gid, G in enumerate(sample_graphs):
        edges = [tuple(sorted(e)) for e in G.edges()]
        edge_ops = {e: build_edge_op(e[0], e[1], basis, idx) for e in edges}
        for defect in edges:
            # 在 s=0 处采样
            for s in [0.0, 0.5, 1.0]:
                p_S, deg, _, _, evecs = pS_at_s(edge_ops, defect, s, SZ_ops, ref_dim)
                V = evecs[:, :deg]
                S_vals = []
                for k in range(deg):
                    v = V[:, k]
                    s2 = float(np.real(v.conj() @ S2_op @ v))
                    S_val = (-1 + np.sqrt(1 + 4*max(s2, 0))) / 2
                    S_vals.append(S_val)
                all_S.extend(S_vals)
                all_deg.append(deg)
                by_gid[gid].extend(S_vals)

    all_S = np.array(all_S)
    print(f"\n  总采样点: {len(all_S)}")
    print(f"  S 值范围: [{all_S.min():.4f}, {all_S.max():.4f}]")
    print(f"  S 均值: {all_S.mean():.4f}")
    print(f"  S 标准差: {all_S.std():.4f}")

    # S 值分布直方图
    print(f"\n  --- S 值分布 ---")
    rounded_S = np.round(all_S * 2) / 2  # 到 0.5 精度
    cnt = Counter(rounded_S)
    print(f"  {'S':>6} | {'数量':>8} | {'占比':>8}")
    print(f"  {'-'*6}-+-{'-'*8}-+-{'-'*8}")
    total = len(all_S)
    for s_val in sorted(cnt.keys()):
        c = cnt[s_val]
        bar = "█" * int(c / total * 50)
        print(f"  {s_val:>6.1f} | {c:>8} | {c/total:>7.1%} {bar}")

    # 简并度 vs S
    print(f"\n  --- 简并度分布 ---")
    deg_cnt = Counter(all_deg)
    print(f"  {'deg':>6} | {'数量':>8} | {'占比':>8}")
    print(f"  {'-'*6}-+-{'-'*8}-+-{'-'*8}")
    for d in sorted(deg_cnt.keys()):
        c = deg_cnt[d]
        print(f"  {d:>6} | {c:>8} | {c/len(all_deg):>7.1%}")

    return all_S


# ============================================================
# Q3: N=6 的 0.5 倍数起源
# ============================================================

def q3_half_multiple_origin():
    """
    从 v10 的 48 个谐振 s 值分析 0.5 倍数规律。
    """
    print("\n" + "=" * 100)
    print("Q3. N=6 的 0.5 倍数规律从哪来")
    print("=" * 100)

    # v10 报告的 48 个谐振点
    v10_s_values = [
        0.0, 0.0, 0.0, 0.0,  # 4
        0.3225, 0.3225,       # 2
        0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5,  # 10
        0.9653, 0.9653, 0.9653, 0.9653,  # 4
        1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,  # 14
        1.2808, 1.2808,       # 2
        1.4549,               # 1
        1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5,  # 7
        1.5119,               # 1
        1.6, 1.6,             # 2
        2.0,                  # 1
    ]

    print(f"\n  N=6 谐振 s 值总数: {len(v10_s_values)}")

    # 是否是 0.5 倍数
    half_multiples = [s for s in v10_s_values if abs(s - round(s*2)/2) < 1e-6]
    non_half = [s for s in v10_s_values if abs(s - round(s*2)/2) > 1e-6]
    print(f"  0.5 倍数: {len(half_multiples)}/{len(v10_s_values)} = "
          f"{len(half_multiples)/len(v10_s_values):.1%}")

    # 是否是有理数 p/q
    rationals = []
    for s in non_half:
        found = False
        for q in range(1, 21):
            p = round(s * q)
            if abs(s - p/q) < 1e-6:
                rationals.append((s, p, q))
                found = True
                break
        if not found:
            rationals.append((s, None, None))
    print(f"\n  非 0.5 倍数的 {len(non_half)} 个值及其有理识别:")
    print(f"  {'s':>12} | {'识别':>20}")
    print(f"  {'-'*12}-+-{'-'*20}")
    for s, p, q in rationals:
        if p is not None:
            print(f"  {s:>12.6f} | {p}/{q}")
        else:
            # 试二次
            ident = identify_algebraic(s)
            print(f"  {s:>12.6f} | {ident}")

    # 0.5 倍数和非 0.5 倍数的图分布
    # 从 v10 数据: {0.0: 4, 0.5: 10, 1.0: 14, 1.5: 7, 2.0: 1}
    # 对应的图 id
    print(f"\n  --- 0.5 倍数对应的图 ---")
    half_data = {
        0.0: ["33", "33", "9", "9"],
        0.5: ["38", "38", "49", "49", "49", "55", "55", "55", "55", "60"],
        1.0: ["60", "60", "60", "69", "69", "103", "38", "69", "69", "69",
              "103", "38", "38", "60"],
        1.5: ["108", "108", "26", "26", "108", "108", "106"],
        2.0: ["103"],
    }
    for s_val, gids in half_data.items():
        unique_gids = sorted(set(gids))
        print(f"  s={s_val}: 图 ID {unique_gids}")

    # 追问：0.5 倍数是否都是图的特殊点？
    # 提示：s=1 是均匀点，s=0 是断开点，s=0.5/1.5/2.0 是什么？
    print(f"\n  --- 关键洞察 ---")
    print(f"  s=0.0: 缺陷边断开（35 次命中中的 4 次在 N=6）")
    print(f"  s=1.0: 均匀耦合点（14 次命中，最多）")
    print(f"  s=0.5: 缺陷边半耦合（10 次）")
    print(f"  s=1.5: 缺陷边 1.5 倍耦合（7 次）")
    print(f"  s=2.0: 缺陷边 2 倍耦合（1 次）")
    print(f"\n  追问：s=1 是均匀点，对称性最高。s=0.5、1.5、2.0 是否是某种比值条件？")

    return half_multiples, non_half


# ============================================================
# Q4: N=7 的简并 -1 命中率
# ============================================================

def q4_degenerate_hits(graphs, N, basis, idx, SZ_ops, S2_op, ref_dim,
                       n_samples=200):
    """
    对 N=7 的简并谐振点，分析为什么 -1 命中率只有 37.6%。
    """
    print("\n" + "=" * 100)
    print(f"Q4. N={N} 的简并 -1 命中率低的原因")
    print("=" * 100)

    s_grid_coarse = np.linspace(-2.0, 2.0, 21)
    sample_graphs = graphs[::max(1, len(graphs)//n_samples)][:n_samples]

    resonances = []
    for gid, G in enumerate(sample_graphs):
        edges = [tuple(sorted(e)) for e in G.edges()]
        edge_ops = {e: build_edge_op(e[0], e[1], basis, idx) for e in edges}
        for defect in edges[:2]:  # 每条边取前 2 个
            pS_curve = np.array([
                pS_at_s(edge_ops, defect, s, SZ_ops, ref_dim)[0]
                for s in s_grid_coarse
            ])
            for k in range(len(s_grid_coarse) - 1):
                if (pS_curve[k] - 0.5) * (pS_curve[k+1] - 0.5) < 0:
                    try:
                        s_res = brentq(
                            lambda s: pS_at_s(edge_ops, defect, s, SZ_ops, ref_dim)[0] - 0.5,
                            s_grid_coarse[k], s_grid_coarse[k+1], xtol=1e-10)
                        info = analyze_at_s(edge_ops, defect, s_res, SZ_ops, S2_op, ref_dim)
                        if info["deg"] > 1:  # 只看简并
                            resonances.append({
                                "gid": gid, "defect": list(defect),
                                "s": float(s_res), **info
                            })
                    except Exception:
                        pass

    print(f"\n  简并谐振点样本数: {len(resonances)}")

    if not resonances:
        print("  无样本")
        return

    # 分类：是否命中 -1
    hit = [r for r in resonances if abs(r["mean_sigdot"] + 1) < 1e-6]
    miss = [r for r in resonances if abs(r["mean_sigdot"] + 1) >= 1e-6]
    print(f"  命中 -1: {len(hit)}/{len(resonances)} = {len(hit)/len(resonances):.1%}")
    print(f"  未命中: {len(miss)}/{len(resonances)} = {len(miss)/len(resonances):.1%}")

    # 未命中的 <σ·σ> 分布
    if miss:
        miss_sd = np.array([r["mean_sigdot"] for r in miss])
        print(f"\n  未命中 <σ·σ> 分布:")
        print(f"    mean = {miss_sd.mean():.4f}")
        print(f"    min  = {miss_sd.min():.4f}")
        print(f"    max  = {miss_sd.max():.4f}")

    # 按简并度分类
    print(f"\n  --- 按简并度分类 ---")
    print(f"  {'deg':>6} | {'总数':>6} | {'命中 -1':>8} | {'命中率':>8}")
    print(f"  {'-'*6}-+-{'-'*6}-+-{'-'*8}-+-{'-'*8}")
    by_deg = defaultdict(list)
    for r in resonances:
        by_deg[r["deg"]].append(r)
    for d in sorted(by_deg.keys()):
        items = by_deg[d]
        n_hit = sum(1 for r in items if abs(r["mean_sigdot"] + 1) < 1e-6)
        print(f"  {d:>6} | {len(items):>6} | {n_hit:>8} | {n_hit/len(items):>8.1%}")

    # 每个简并态 <σ·σ> 值分布
    print(f"\n  --- 每个简并态的 <σ·σ> 值分布 ---")
    all_sigdot = [v for r in resonances for v in r["per_state_sigdot"]]
    print(f"  总数: {len(all_sigdot)}")
    print(f"  mean = {np.mean(all_sigdot):.4f}")
    # 分类
    cnt = Counter(round(v) for v in all_sigdot)
    print(f"  整数值分布: {dict(cnt)}")

    # S 值分布
    all_S = [v for r in resonances for v in r["per_state_S"]]
    print(f"\n  --- S 值分布 ---")
    S_cnt = Counter(round(v, 1) for v in all_S)
    print(f"  S 值分布: {dict(sorted(S_cnt.items()))}")

    return resonances


# ============================================================
# Q5: N=7 的 4172 个唯一 s 值的代数识别
# ============================================================

def q5_algebraic_identify():
    """
    从 v12 导出文件读取 N=7 的 s 值，做代数识别统计。
    """
    print("\n" + "=" * 100)
    print("Q5. N=7 的 4172 个唯一 s 值的代数识别")
    print("=" * 100)

    v12_path = os.path.join(WORK_DIR, "照妖镜_v12_N7_pS.json")
    if not os.path.exists(v12_path):
        print(f"  找不到 {v12_path}，跳过 Q5")
        return

    with open(v12_path, "r", encoding="utf-8") as f:
        v12 = json.load(f)

    unique_s = list(v12["unique_s_values"].keys())
    unique_s = [float(s) for s in unique_s]
    print(f"\n  N=7 唯一 s 值: {len(unique_s)}")

    # 分类
    categories = {
        "0.5 倍数": 0,
        "有理数（非 0.5 倍数）": 0,
        "二次代数数": 0,
        "未识别": 0,
    }

    examples = defaultdict(list)
    for s in unique_s:
        if abs(s) < 1e-10:
            categories["0.5 倍数"] += 1
            examples["0.5 倍数"].append(s)
            continue
        if abs(s - round(s*2)/2) < 1e-6:
            categories["0.5 倍数"] += 1
            examples["0.5 倍数"].append(s)
            continue
        # 有理数
        is_rational = False
        for q in range(1, 21):
            p = round(s * q)
            if abs(s - p/q) < 1e-6:
                categories["有理数（非 0.5 倍数）"] += 1
                examples["有理数（非 0.5 倍数）"].append(s)
                is_rational = True
                break
        if is_rational:
            continue
        # 二次代数数（小整数系数）
        is_quad = False
        for a in range(1, 11):
            for b in range(-15, 16):
                for c in range(-15, 16):
                    if abs(a*s*s + b*s + c) < 1e-6:
                        categories["二次代数数"] += 1
                        examples["二次代数数"].append(s)
                        is_quad = True
                        break
                if is_quad: break
            if is_quad: break
        if is_quad:
            continue
        categories["未识别"] += 1
        examples["未识别"].append(s)

    print(f"\n  {'类别':<25} | {'数量':>6} | {'占比':>8}")
    print(f"  {'-'*25}-+-{'-'*6}-+-{'-'*8}")
    for cat, cnt in categories.items():
        print(f"  {cat:<25} | {cnt:>6} | {cnt/len(unique_s):>7.1%}")

    print(f"\n  --- 抽样 ---")
    for cat, vals in examples.items():
        if vals:
            print(f"  {cat}: {vals[:5]}...")


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 100)
    print("照妖镜 v13.0：五问并行攻击 N=7 的结构差异")
    print("=" * 100)

    # 图集（抽样以控制运行时间）
    graphs_N7 = build_graphs(7, max_count=150)
    print(f"\n  N=7 抽样图集: {len(graphs_N7)}")

    # S_z=0 扇区
    basis, idx, SZ_ops = build_sz0_sector(7)
    print(f"  S_z=0 扇区维度: {len(basis)}")
    S2_op = build_S2_op(basis, idx, 7)
    ref_dim = len(basis)
    print(f"  S² 算符构建完成")

    # Q1
    q1_results = q1_curve_shape(graphs_N7, 7, basis, idx, SZ_ops, S2_op,
                                ref_dim, n_samples=30, n_points=81)

    # Q2
    q2_results = q2_spin_distribution(graphs_N7, 7, basis, idx, SZ_ops, S2_op,
                                      ref_dim, n_samples=80)

    # Q3（分析 N=6 数据）
    q3_half, q3_nonhalf = q3_half_multiple_origin()

    # Q4
    q4_results = q4_degenerate_hits(graphs_N7, 7, basis, idx, SZ_ops, S2_op,
                                     ref_dim, n_samples=150)

    # Q5
    q5_algebraic_identify()

    # 汇总
    print("\n" + "=" * 100)
    print("五问汇总")
    print("=" * 100)
    print(f"""
  Q1. N=7 p_S(s) 曲线形状: 见上
  Q2. N=7 S 值分布: 见上
  Q3. N=6 0.5 倍数起源: 见上
  Q4. N=7 简并 -1 命中率: 见上
  Q5. N=7 s 值代数识别: 见上
""")

    print("\n" + "=" * 100)
    print("v13.0 完成。五问并行。结果并排。")
    print("=" * 100)


if __name__ == "__main__":
    main()