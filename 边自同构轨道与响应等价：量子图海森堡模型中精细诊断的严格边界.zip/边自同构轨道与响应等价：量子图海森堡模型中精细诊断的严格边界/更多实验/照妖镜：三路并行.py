#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜：三路并行
====================================

规矩：
  假设没有牛顿，没有龚明，没有"地球"。
  三条路各自跑，不互相参照，不预设谁对。
  结果并排，不筛选，不结论。

路径 A：纯关系网络（照妖镜）
  - 只有节点、边、边权重
  - 只有关系类型 A/B
  - 只有扰动
  - 只看整体响应

路径 B：全局等势面（牛顿方向）
  - 标准物理，椭球面上等势条件

路径 C：局部连通器（龚明方向）
  - 标准物理，球心压强各向同性
"""

import numpy as np
import networkx as nx
from itertools import combinations
from scipy.integrate import quad
from scipy.optimize import brentq
import json, os

# 归一化单位
G_const = 1.0
M_total = 1.0
R_scale = 1.0

# ============================================================
# 路径 A：纯关系网络
# ============================================================

def build_network(N, seed=42):
    """构建纯关系网络。不叫地球，不叫引力。"""
    np.random.seed(seed)
    positions = []
    for _ in range(N):
        while True:
            p = np.random.uniform(-1, 1, 3)
            if np.linalg.norm(p) <= 1:
                positions.append(p)
                break
    positions = np.array(positions)
    
    G = nx.Graph()
    for i in range(N):
        G.add_node(i, pos=positions[i])
    for i, j in combinations(range(N), 2):
        d = np.linalg.norm(positions[i] - positions[j])
        if d > 1e-6:
            G.add_edge(i, j, weight=1.0/d**2, dist=d)
    return G, positions


def mark_types(G, positions):
    """标记关系类型 A/B。不叫自由/束缚，不叫短轴/长轴。"""
    for i, j in G.edges:
        mid = (positions[i] + positions[j]) / 2
        if abs(mid[2]) > np.sqrt(mid[0]**2 + mid[1]**2):
            G[i][j]['type'] = 'A'
        else:
            G[i][j]['type'] = 'B'


def response_A(G, perturb):
    """
    纯关系网络的整体响应。
    对 type_B 的边施加扰动。看整体响应。
    并排算几种整体量。
    """
    w_A, w_B = [], []
    for i, j in G.edges:
        w = G[i][j]['weight']
        w_eff = w * (1 - perturb) if G[i][j]['type'] == 'B' else w
        if G[i][j]['type'] == 'A':
            w_A.append(w_eff)
        else:
            w_B.append(w_eff)
    
    all_w = np.array(w_A + w_B)
    if len(all_w) == 0:
        return None
    return {
        "std": float(np.std(all_w)),
        "mean": float(np.mean(all_w)),
        "ratio_std_mean": float(np.std(all_w) / (np.mean(all_w) + 1e-12)),
        "A_mean": float(np.mean(w_A)) if w_A else 0,
        "B_mean": float(np.mean(w_B)) if w_B else 0,
        "diff_A_B": float(np.mean(w_A) - np.mean(w_B)) if (w_A and w_B) else 0,
    }


# ============================================================
# 路径 B：全局等势面（牛顿方向）
# ============================================================

def surface_potential(theta, f, omega):
    """标准牛顿：椭球面上一阶展开，含引力四极矩。"""
    cos_t = np.cos(theta)
    sin_t = np.sin(theta)
    r = R_scale * (1 + f * (1/3 - cos_t**2))
    J2 = (2/5) * f
    P2 = 0.5 * (3 * cos_t**2 - 1)
    Phi_grav = -G_const * M_total / r * (1 - J2 * (R_scale/r)**2 * P2)
    Phi_cent = -0.5 * omega**2 * r**2 * sin_t**2
    return Phi_grav + Phi_cent


def flattening_B(omega):
    """牛顿方向：全局等势面条件。"""
    def eq(f):
        return surface_potential(0, f, omega) - surface_potential(np.pi/2, f, omega)
    try:
        f_sol = brentq(eq, 0.0, 0.5, xtol=1e-14)
    except Exception:
        f_sol = (5/4) * omega**2
    return f_sol


# ============================================================
# 路径 C：局部连通器（龚明方向）
# ============================================================

def local_flattening_C(omega):
    """龚明方向：球心压强各向同性，局部连通器积分。"""
    rho = M_total / (4/3 * np.pi * R_scale**3)
    def eq(f):
        b = R_scale * (1 - f/3)
        a = R_scale * (1 + 2*f/3)
        p_pole, _ = quad(lambda r: rho * (4/3 * np.pi * G_const * rho * r), 0, b)
        p_eq, _ = quad(lambda r: rho * (4/3 * np.pi * G_const * rho * r - omega**2 * r), 0, a)
        return p_pole - p_eq
    try:
        f_sol = brentq(eq, 0.0, 0.5, xtol=1e-14)
    except Exception:
        f_sol = 0.5 * omega**2
    return f_sol


# ============================================================
# 三路并排
# ============================================================

def main():
    print("="*100)
    print("照妖镜：三路并行")
    print("路径 A：纯关系网络 | 路径 B：全局等势面 | 路径 C：局部连通器")
    print("="*100)
    
    # ---------- 路径 B 和 C：标准物理 ----------
    print("\n[路径 B 和 C] 标准物理，不同 omega 下的扁率系数 f/omega²")
    print(f"\n  {'omega':>8} | {'B: 全局等势面':>16} | {'C: 局部连通器':>16} | {'B/C':>8}")
    print(f"  {'-'*8}-+-{'-'*16}-+-{'-'*16}-+-{'-'*8}")
    
    BC_results = []
    for omega in [0.01, 0.05, 0.1, 0.2, 0.3]:
        f_B = flattening_B(omega)
        f_C = local_flattening_C(omega)
        q = omega**2
        C_B = f_B / q if q > 1e-12 else 0
        C_C = f_C / q if q > 1e-12 else 0
        ratio = C_B / C_C if C_C > 1e-12 else 0
        print(f"  {omega:>8.3f} | {C_B:>16.8f} | {C_C:>16.8f} | {ratio:>8.4f}")
        BC_results.append({"omega": omega, "C_B": C_B, "C_C": C_C, "ratio": ratio})
    
    # ---------- 路径 A：纯关系网络 ----------
    print("\n" + "="*100)
    print("[路径 A] 纯关系网络，不同 N 和扰动下的整体响应")
    print("="*100)
    
    A_results = []
    for N in [10, 20, 50]:
        print(f"\n  N = {N}")
        G, positions = build_network(N)
        mark_types(G, positions)
        n_A = sum(1 for i,j in G.edges if G[i][j]['type']=='A')
        n_B = sum(1 for i,j in G.edges if G[i][j]['type']=='B')
        print(f"  边数: A={n_A}, B={n_B}")
        print(f"  {'perturb':>8} | {'std':>10} | {'mean':>10} | {'ratio':>10} | {'A_mean':>10} | {'B_mean':>10} | {'A-B':>10}")
        print(f"  {'-'*8}-+-{'-'*10}-+-{'-'*10}-+-{'-'*10}-+-{'-'*10}-+-{'-'*10}-+-{'-'*10}")
        for pert in np.linspace(0.0, 0.5, 6):
            r = response_A(G, pert)
            if r:
                print(f"  {pert:>8.3f} | {r['std']:>10.6f} | {r['mean']:>10.6f} | "
                      f"{r['ratio_std_mean']:>10.6f} | {r['A_mean']:>10.6f} | "
                      f"{r['B_mean']:>10.6f} | {r['diff_A_B']:>10.6f}")
                A_results.append({"N": N, "perturb": pert, **r})
    
    # ---------- 导出 ----------
    out = {
        "path_B_C": BC_results,
        "path_A": A_results,
    }
    out_path = os.path.join(os.path.expanduser("~"), "three_paths_results.json")
    with open(out_path, "w") as f:
        json.dump(out, f, indent=2)
    print(f"\n[导出: {out_path}]")


if __name__ == "__main__":
    main()