#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
整体状态假说检验
====================

假说：异轨道同响应由多个关系维度同时对齐形成的整体状态决定。
     不是单一特征，是整体对齐程度。

检验方法：
  1. 对每对边，计算所有关系维度上的"对齐"（相等与否）
  2. 求总对齐分数（可加权或不加权）
  3. 比较同响应对和异响应对的对齐分数分布
  4. 比较内核/中环/外壳三层的对齐分数
  5. 看是否存在对齐阈值

数据来源：
  - 2731 对异轨道对的全部关系特征
  - v5.1 已算出的 24 位响应模式
"""

import sys, io, itertools, json, os
import numpy as np
import networkx as nx
from collections import Counter, defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"
N = 6

# ============================================================
# 关系特征清单：每个特征给出一个"是否对齐"的判断
# ============================================================

def compute_alignment_features(G, e1, e2, orbits):
    """
    对一对边，计算所有关系维度的对齐状态。
    每个维度返回 True（对齐）或 False（不对齐）。
    """
    n1a, n1b = e1
    n2a, n2b = e2
    orbit_size = Counter(orbits.values())
    bridges = set(map(frozenset, nx.bridges(G)))

    feats = {}

    # 1. 自同构轨道大小对齐
    feats["orbit_size_sym"] = orbit_size[orbits[e1]] == orbit_size[orbits[e2]]

    # 2. 端点度序列对齐
    feats["degree_pair_sym"] = sorted([G.degree(n1a), G.degree(n1b)]) == \
                               sorted([G.degree(n2a), G.degree(n2b)])

    # 3. 度之和对齐
    feats["degree_sum_sym"] = (G.degree(n1a) + G.degree(n1b)) == \
                              (G.degree(n2a) + G.degree(n2b))

    # 4. 桥状态对齐
    feats["bridge_sym"] = (frozenset(e1) in bridges) == (frozenset(e2) in bridges)

    # 5. k-core 对齐
    core = nx.core_number(G)
    feats["kcore_sym"] = min(core[n1a], core[n1b]) == min(core[n2a], core[n2b])

    # 6. 三角形参与对齐
    t1 = sum(1 for _ in nx.common_neighbors(G, n1a, n1b))
    t2 = sum(1 for _ in nx.common_neighbors(G, n2a, n2b))
    feats["triangle_sym"] = t1 == t2

    # 7. 有效电阻对齐
    try:
        L = nx.laplacian_matrix(G).astype(float).toarray()
        Lpinv = np.linalg.pinv(L)
        def er(u, v):
            return Lpinv[u, u] + Lpinv[v, v] - 2 * Lpinv[u, v]
        feats["eff_res_sym"] = abs(er(n1a, n1b) - er(n2a, n2b)) < 1e-6
    except Exception:
        feats["eff_res_sym"] = False

    # 8. 邻域重叠对齐（neighbor_jaccard 只取是否相同）
    inter = (set(G.neighbors(n1a)) | set(G.neighbors(n1b))) & \
            (set(G.neighbors(n2a)) | set(G.neighbors(n2b)))
    union = (set(G.neighbors(n1a)) | set(G.neighbors(n1b))) | \
            (set(G.neighbors(n2a)) | set(G.neighbors(n2b)))
    jacc = len(inter) / len(union) if union else 0.0
    # 是否和 2/3 对齐（N=6 的典型值）
    feats["jaccard_23"] = abs(jacc - 2/3) < 0.01
    # 或者：是否存在对齐（两条边的局部邻域同构）
    # 这个先不定义，暂用 jaccard_23 代替

    # 9. 共同邻居数对齐
    feats["common_neighbors_sym"] = len(inter) >= 4  # 高邻近度

    # 10. 收缩度序列对齐
    try:
        G1 = nx.contracted_edge(G, e1, self_loops=False)
        G2 = nx.contracted_edge(G, e2, self_loops=False)
        ds1 = tuple(sorted(d for _, d in G1.degree()))
        ds2 = tuple(sorted(d for _, d in G2.degree()))
        feats["contract_deg_seq_sym"] = ds1 == ds2
    except Exception:
        feats["contract_deg_seq_sym"] = False

    # 11. 边距离对齐（是否邻近）
    try:
        dist = nx.shortest_path_length(G, n1a, n2a)
        feats["edge_distance_le2"] = dist <= 2
    except Exception:
        feats["edge_distance_le2"] = False

    # 12. 聚类系数之和对齐
    try:
        cc = nx.clustering(G)
        cc1 = cc[n1a] + cc[n1b]
        cc2 = cc[n2a] + cc[n2b]
        feats["cc_sum_sym"] = abs(cc1 - cc2) < 0.01
    except Exception:
        feats["cc_sum_sym"] = False

    return feats


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 100)
    print("整体状态假说检验")
    print("异轨道同响应 = 多个关系维度同时对齐形成的整体状态")
    print("=" * 100)

    # 构建图集
    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    print(f"\n  图集: {len(graphs)} 个 N=6 连通图")

    # 自同构轨道
    def find_automorphisms(G):
        nodes = list(G.nodes())
        adj = nx.to_numpy_array(G)
        perms = []
        for p in itertools.permutations(nodes):
            P = np.zeros((len(nodes), len(nodes)))
            for i, pi in enumerate(p): P[i, pi] = 1
            if np.allclose(P @ adj @ P.T, adj): perms.append(p)
        return perms

    def find_edge_orbits(G):
        nodes = list(G.nodes())
        edges = [tuple(sorted(e)) for e in G.edges()]
        perms = find_automorphisms(G)
        orbit_id = {e: None for e in edges}
        oid = 0
        for e in edges:
            if orbit_id[e] is not None: continue
            orbit_id[e] = oid
            for p in perms:
                m = {nodes[i]: p[i] for i in range(len(nodes))}
                e2 = tuple(sorted((m[e[0]], m[e[1]])))
                if G.has_edge(*e2): orbit_id[e2] = oid
            oid += 1
        return orbit_id

    # 从 v5.1 导出的模式文件读取
    patterns_file = os.path.join(WORK_DIR, "照妖镜_v5_1_模式.json")
    if not os.path.exists(patterns_file):
        print(f"\n  [错误] 找不到 {patterns_file}")
        print(f"  请先跑照妖镜 v5.1")
        return

    with open(patterns_file, "r", encoding="utf-8") as f:
        v51 = json.load(f)

    print(f"\n  已加载 v5.1 数据: {len(v51['patterns'])} 对")

    # 解析模式
    patterns = {}
    for key, s in v51["patterns"].items():
        gid, e1_str, e2_str = key.split("_", 2)
        gid = int(gid)
        # e1_str 形如 "(0, 1)"
        e1 = tuple(map(int, e1_str.strip("()").split(",")))
        e2 = tuple(map(int, e2_str.strip("()").split(",")))
        patterns[(gid, e1, e2)] = s

    # 对每对算对齐分数
    print(f"\n  计算每对的关系对齐分数…")
    all_pairs_data = []
    for gid, G in enumerate(graphs):
        edges = [tuple(sorted(e)) for e in G.edges()]
        orbits = find_edge_orbits(G)
        for i, e1 in enumerate(edges):
            for j in range(i+1, len(edges)):
                e2 = edges[j]
                if orbits[e1] == orbits[e2]: continue
                feats = compute_alignment_features(G, e1, e2, orbits)
                align_score = sum(1 for v in feats.values() if v)
                key = (gid, e1, e2)
                pattern = patterns.get(key, "0" * 24)
                n_true = pattern.count("1")
                all_pairs_data.append({
                    "gid": gid, "e1": e1, "e2": e2,
                    "features": feats,
                    "align_score": align_score,
                    "n_dims": len(feats),
                    "pattern": pattern,
                    "n_true_pattern": n_true,
                    "is_same_response": n_true > 0,
                })
    print(f"  完成 {len(all_pairs_data)} 对")

    # ============================================================
    # 检验 1：同响应 vs 异响应的对齐分数分布
    # ============================================================
    print("\n" + "=" * 100)
    print("检验 1：同响应 vs 异响应的对齐分数分布")
    print("=" * 100)

    same = [r for r in all_pairs_data if r["is_same_response"]]
    diff = [r for r in all_pairs_data if not r["is_same_response"]]
    print(f"\n  同响应对: {len(same)}")
    print(f"  异响应对: {len(diff)}")

    same_scores = [r["align_score"] for r in same]
    diff_scores = [r["align_score"] for r in diff]

    print(f"\n  同响应对对齐分数:")
    print(f"    mean = {np.mean(same_scores):.3f}")
    print(f"    std  = {np.std(same_scores):.3f}")
    print(f"    min  = {np.min(same_scores)}")
    print(f"    max  = {np.max(same_scores)}")
    print(f"\n  异响应对对齐分数:")
    print(f"    mean = {np.mean(diff_scores):.3f}")
    print(f"    std  = {np.std(diff_scores):.3f}")
    print(f"    min  = {np.min(diff_scores)}")
    print(f"    max  = {np.max(diff_scores)}")

    print(f"\n  分布直方图（对齐分数 → 同响应占比）:")
    print(f"  {'分数':>4} | {'同响应数':>8} | {'总对数':>8} | {'占比':>8}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*8}-+-{'-'*8}")
    max_score = max(max(same_scores), max(diff_scores))
    for sc in range(max_score + 1):
        n_same = sum(1 for s in same_scores if s == sc)
        n_total = n_same + sum(1 for s in diff_scores if s == sc)
        if n_total > 0:
            ratio = n_same / n_total
            bar = "█" * int(ratio * 20)
            print(f"  {sc:>4} | {n_same:>8} | {n_total:>8} | {ratio:>7.1%} {bar}")

    # ============================================================
    # 检验 2：三层（内核/中环/外壳）的对齐分数
    # ============================================================
    print("\n" + "=" * 100)
    print("检验 2：三层（内核/中环/外壳）的对齐分数")
    print("=" * 100)

    hard_core = [r for r in same if r["n_true_pattern"] == 24]
    middle = [r for r in same if 1 < r["n_true_pattern"] < 24]
    outer = [r for r in same if r["n_true_pattern"] == 1]

    print(f"\n  内核（全 24 位真）: {len(hard_core)} 对")
    if hard_core:
        hc_scores = [r["align_score"] for r in hard_core]
        print(f"    对齐分数: mean={np.mean(hc_scores):.3f}, "
              f"range=[{np.min(hc_scores)}, {np.max(hc_scores)}]")

    print(f"\n  中环（部分真）: {len(middle)} 对")
    if middle:
        md_scores = [r["align_score"] for r in middle]
        print(f"    对齐分数: mean={np.mean(md_scores):.3f}, "
              f"range=[{np.min(md_scores)}, {np.max(md_scores)}]")

    print(f"\n  外壳（1 位真）: {len(outer)} 对")
    if outer:
        ot_scores = [r["align_score"] for r in outer]
        print(f"    对齐分数: mean={np.mean(ot_scores):.3f}, "
              f"range=[{np.min(ot_scores)}, {np.max(ot_scores)}]")

    print(f"\n  异响应: {len(diff)} 对")
    if diff:
        print(f"    对齐分数: mean={np.mean(diff_scores):.3f}, "
              f"range=[{np.min(diff_scores)}, {np.max(diff_scores)}]")

    # ============================================================
    # 检验 3：每个关系维度的区分度
    # ============================================================
    print("\n" + "=" * 100)
    print("检验 3：每个关系维度的区分度")
    print("=" * 100)

    feature_names = list(same[0]["features"].keys()) if same else []
    print(f"\n  {'维度':>24} | {'同响应中占比':>12} | {'异响应中占比':>12} | {'差':>8}")
    print(f"  {'-'*24}-+-{'-'*12}-+-{'-'*12}-+-{'-'*8}")
    for fname in feature_names:
        p_same = sum(1 for r in same if r["features"][fname]) / len(same) if same else 0
        p_diff = sum(1 for r in diff if r["features"][fname]) / len(diff) if diff else 0
        print(f"  {fname:>24} | {p_same:>12.3f} | {p_diff:>12.3f} | {p_same - p_diff:>+8.3f}")

    # ============================================================
    # 检验 4：是否所有硬核对都在特定对齐分数上
    # ============================================================
    print("\n" + "=" * 100)
    print("检验 4：硬核的共同对齐特征")
    print("=" * 100)

    if hard_core:
        print(f"\n  硬核 {len(hard_core)} 对，各维度的对齐情况:")
        for fname in feature_names:
            n_true = sum(1 for r in hard_core if r["features"][fname])
            bar = "█" * n_true
            print(f"    {fname:>24}: {n_true:>3}/{len(hard_core)} {bar}")

    # ============================================================
    # 导出
    # ============================================================
    out = {
        "n_same": len(same),
        "n_diff": len(diff),
        "same_align_mean": float(np.mean(same_scores)) if same else 0,
        "diff_align_mean": float(np.mean(diff_scores)) if diff else 0,
        "hard_core": [
            {"gid": r["gid"], "e1": list(r["e1"]), "e2": list(r["e2"]),
             "align_score": r["align_score"], "features": r["features"]}
            for r in hard_core
        ],
        "middle": [
            {"gid": r["gid"], "e1": list(r["e1"]), "e2": list(r["e2"]),
             "align_score": r["align_score"], "n_true_pattern": r["n_true_pattern"]}
            for r in middle
        ],
        "outer": [
            {"gid": r["gid"], "e1": list(r["e1"]), "e2": list(r["e2"]),
             "align_score": r["align_score"], "n_true_pattern": r["n_true_pattern"]}
            for r in outer
        ],
    }
    out_path = os.path.join(WORK_DIR, "整体状态假说检验结果.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("整体状态假说检验完成。")
    print("=" * 100)


if __name__ == "__main__":
    main()