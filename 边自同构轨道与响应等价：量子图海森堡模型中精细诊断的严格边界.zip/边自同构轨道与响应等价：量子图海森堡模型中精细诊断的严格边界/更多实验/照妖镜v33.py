#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 v33.0：9 个局域谐振对的窗口结构穷举
================================================================

v32 发现：
  Layer 4: |sd1(s)| = |sd2(s)| for s ∈ [-1,1]
    候选 38，命中 38，精度 100%，召回 80.9%
  剩余 9 个同响应对未被覆盖

v33 集中攻击那 9 对：
  Q1. 那 9 对具体是什么？
  Q2. 它们的 sd 曲线在各 s 上的差异是多少？
  Q3. 它们有共同的更窄窗口吗？
  Q4. 窗口边界与图结构相关吗？
  Q5. 用"最大连续覆盖窗口"作为条件，能否覆盖 47 对？
"""

import sys, io, itertools, json, os
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from collections import Counter, defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"


# ============================================================
# 基础
# ============================================================

def build_atlas_graphs(N):
    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    return graphs


def build_sz0_sector(N):
    n_up = N // 2
    basis = []
    for comb in itertools.combinations(range(N), n_up):
        state = [0]*N
        for i in comb: state[i] = 1
        basis.append(tuple(state))
    dim = len(basis)
    idx = {s: i for i, s in enumerate(basis)}
    SZ_ops = []
    for site in range(N):
        SZ = np.zeros((dim, dim), dtype=complex)
        for i, state in enumerate(basis):
            SZ[i, i] = 1 if state[site] == 1 else -1
        SZ_ops.append(SZ)
    return basis, idx, SZ_ops


def build_edge_op(i, j, basis, idx):
    dim = len(basis)
    op = np.zeros((dim, dim), dtype=complex)
    for a_idx, state_a in enumerate(basis):
        sa, sb = state_a[i], state_a[j]
        if sa == sb:
            op[a_idx, a_idx] += 1
        else:
            op[a_idx, a_idx] += -1
            new_state = list(state_a)
            new_state[i], new_state[j] = new_state[j], new_state[i]
            b_idx = idx.get(tuple(new_state))
            if b_idx is not None:
                op[b_idx, a_idx] += 2
    return op


def build_S2_op(basis, idx, N):
    dim = len(basis)
    S2 = np.zeros((dim, dim), dtype=complex)
    for i in range(N):
        S2 += 3/4 * np.eye(dim, dtype=complex)
        for j in range(N):
            if i == j: continue
            S2 += 1/4 * build_edge_op(i, j, basis, idx)
    return S2


def analyze_at_s(edge_ops, defect, s, SZ_ops, S2_op, ref_dim):
    H = np.zeros((ref_dim, ref_dim), dtype=complex)
    for e, M in edge_ops.items():
        c = s if e == defect else 1.0
        H += c * M
    try:
        evals, evecs = eigh(H)
    except Exception:
        return None
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < 1e-8))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    i, j = defect
    szsz_diag = np.diag(SZ_ops[i] @ SZ_ops[j])
    szsz = float(np.real(np.sum(np.diag(rho) * szsz_diag)))
    p_S = (1 - 3 * szsz) / 4
    sd = float(np.real(np.trace(rho @ edge_ops[defect])))
    S2_val = float(np.real(np.trace(rho @ S2_op)))
    S_total = (-1 + np.sqrt(1 + 4*max(S2_val, 0))) / 2
    return {"S": S_total, "pS": p_S, "sd": sd, "deg": deg}


def load_patterns():
    with open(os.path.join(WORK_DIR, "照妖镜_v5_1_模式.json"), "r",
              encoding="utf-8") as f:
        v51 = json.load(f)
    patterns = {}
    for key, s in v51["patterns"].items():
        gid, e1_str, e2_str = key.split("_", 2)
        gid = int(gid)
        e1 = tuple(map(int, e1_str.strip("()").split(",")))
        e2 = tuple(map(int, e2_str.strip("()").split(",")))
        patterns[(gid, tuple(sorted(e1)), tuple(sorted(e2)))] = s
    return patterns


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 100)
    print("照妖镜 v33.0：9 个局域谐振对的窗口结构穷举")
    print("=" * 100)

    N = 6
    graphs = build_atlas_graphs(N)
    patterns = load_patterns()
    print(f"\n  N={N} 图集: {len(graphs)} 图")
    print(f"  已知同响应对: {len(patterns)}")

    basis, idx, SZ_ops = build_sz0_sector(N)
    ref_dim = len(basis)
    S2_op = build_S2_op(basis, idx, N)

    # 密集 s 网格
    s_vals = np.linspace(-2.0, 2.0, 81)

    # 扫描 47 对
    print(f"\n  扫描 47 对同响应对（81 点 s 采样）...")
    same_response_data = []
    for i, ((gid, e1, e2), pattern) in enumerate(sorted(patterns.items())):
        if i % 10 == 0:
            print(f"    {i}/47")
        G = graphs[gid]
        edges = [tuple(sorted(e)) for e in G.edges()]
        edge_ops = {e: build_edge_op(e[0], e[1], basis, idx) for e in edges}

        per_defect = {}
        for d_edge in [e1, e2]:
            curve_pS = []
            curve_sd = []
            curve_S = []
            curve_deg = []
            for s in s_vals:
                r = analyze_at_s(edge_ops, d_edge, s, SZ_ops, S2_op, ref_dim)
                if r:
                    curve_pS.append(r["pS"])
                    curve_sd.append(r["sd"])
                    curve_S.append(r["S"])
                    curve_deg.append(r["deg"])
                else:
                    curve_pS.append(np.nan)
                    curve_sd.append(np.nan)
                    curve_S.append(np.nan)
                    curve_deg.append(np.nan)
            per_defect[d_edge] = {
                "pS_curve": np.array(curve_pS),
                "sd_curve": np.array(curve_sd),
                "S_curve": np.array(curve_S),
                "deg_curve": np.array(curve_deg),
            }

        S1_at_05 = per_defect[e1]["S_curve"][np.argmin(np.abs(s_vals - 0.5))]
        S2_at_05 = per_defect[e2]["S_curve"][np.argmin(np.abs(s_vals - 0.5))]

        # 计算 |sd1(s)| - |sd2(s)| 曲线
        abs_diff = np.abs(np.abs(per_defect[e1]["sd_curve"]) -
                          np.abs(per_defect[e2]["sd_curve"]))

        same_response_data.append({
            "gid": gid, "e1": e1, "e2": e2,
            "n_true": pattern.count("1"),
            "S1_at_05": float(S1_at_05),
            "S2_at_05": float(S2_at_05),
            "abs_diff_curve": abs_diff.tolist(),
            "max_abs_diff": float(np.nanmax(abs_diff)),
            "sd1_curve": per_defect[e1]["sd_curve"].tolist(),
            "sd2_curve": per_defect[e2]["sd_curve"].tolist(),
        })

    print(f"  完成 {len(same_response_data)} 对")

    # 分类
    L4_pass = [p for p in same_response_data if p["max_abs_diff"] < 1e-6]  # 全域等值
    L4_narrow = [p for p in same_response_data if 1e-6 <= p["max_abs_diff"] < 1e-2]
    L4_fail = [p for p in same_response_data if p["max_abs_diff"] >= 1e-2]
    # 注意：L4_pass 是"所有 s 上等值"，还需单独判定在 [-1,1] 上等值

    # 重新定义 Layer 4（s ∈ [-1,1]）
    def in_window(p, lo=-1.0, hi=1.0):
        s_arr = s_vals
        m = (s_arr >= lo) & (s_arr <= hi)
        return np.nanmax(np.array(p["abs_diff_curve"])[m])

    p_L4_win = [p for p in same_response_data if in_window(p, -1.0, 1.0) < 1e-6]
    p_L4_fail = [p for p in same_response_data if in_window(p, -1.0, 1.0) >= 1e-6]

    print(f"\n  Layer 4 (s∈[-1,1]) 通过: {len(p_L4_win)}")
    print(f"  Layer 4 未通过: {len(p_L4_fail)}")

    # ============================================================
    # Q1: 那 9 对具体是什么？
    # ============================================================
    print("\n" + "=" * 100)
    print("Q1. Layer 4 未覆盖的 9 对清单")
    print("=" * 100)

    print(f"\n  {'gid':>4} | {'e1':>8} | {'e2':>8} | {'n_true':>6} | "
          f"{'max|Δ|':>12} | {'S1':>5} | {'S2':>5}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*8}-+-{'-'*6}-+-{'-'*12}-+-{'-'*5}-+-{'-'*5}")

    for p in sorted(p_L4_fail, key=lambda x: (x["gid"], x["e1"])):
        max_diff = in_window(p, -1.0, 1.0)
        print(f"  {p['gid']:>4} | {str(p['e1']):>8} | {str(p['e2']):>8} | "
              f"{p['n_true']:>6} | {max_diff:>12.4e} | "
              f"{p['S1_at_05']:>5.2f} | {p['S2_at_05']:>5.2f}")

    # ============================================================
    # Q2: sd 曲线差异分布
    # ============================================================
    print("\n" + "=" * 100)
    print("Q2. 9 对在各个 s 点的 |sd1(s)| - |sd2(s)|")
    print("=" * 100)

    # 抽样 s 点
    s_sample = [-2.0, -1.5, -1.0, -0.5, 0.0, 0.5, 1.0, 1.5, 2.0]
    s_sample_idx = [np.argmin(np.abs(s_vals - s)) for s in s_sample]

    print(f"\n  {'gid':>4} | {'e1':>8} | {'e2':>8} | " +
          " | ".join(f"{s:>7.2f}" for s in s_sample))
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*8}-+-" +
          "-+-".join("-" * 7 for _ in s_sample))

    for p in sorted(p_L4_fail, key=lambda x: (x["gid"], x["e1"])):
        diffs = [p["abs_diff_curve"][i] for i in s_sample_idx]
        print(f"  {p['gid']:>4} | {str(p['e1']):>8} | {str(p['e2']):>8} | " +
              " | ".join(f"{d:>7.4f}" for d in diffs))

    # ============================================================
    # Q3: 每对的"最大连续等价窗口"
    # ============================================================
    print("\n" + "=" * 100)
    print("Q3. 每对的'最大连续等价窗口'")
    print("=" * 100)

    def find_max_window(p, tol=1e-6):
        """找到 |Δ(s)| < tol 的最大连续 s 窗口"""
        diffs = np.array(p["abs_diff_curve"])
        mask = diffs < tol
        # 找最长连续 True 区间
        best_len = 0
        best_start = -1
        cur_len = 0
        cur_start = -1
        for i, v in enumerate(mask):
            if v:
                if cur_len == 0:
                    cur_start = i
                cur_len += 1
                if cur_len > best_len:
                    best_len = cur_len
                    best_start = cur_start
            else:
                cur_len = 0
        if best_len == 0:
            return None
        lo = s_vals[best_start]
        hi = s_vals[best_start + best_len - 1]
        return {"lo": lo, "hi": hi, "n_points": best_len}

    print(f"\n  {'gid':>4} | {'e1':>8} | {'e2':>8} | {'窗口':>20} | {'点数':>5}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*8}-+-{'-'*20}-+-{'-'*5}")

    for p in sorted(same_response_data, key=lambda x: (x["gid"], x["e1"])):
        w = find_max_window(p)
        if w is None:
            w_str = "none"
            n_str = "0"
        else:
            w_str = f"[{w['lo']:.2f}, {w['hi']:.2f}]"
            n_str = str(w["n_points"])
        print(f"  {p['gid']:>4} | {str(p['e1']):>8} | {str(p['e2']):>8} | "
              f"{w_str:>20} | {n_str:>5}")

    # ============================================================
    # Q4: 窗口边界的图结构相关性
    # ============================================================
    print("\n" + "=" * 100)
    print("Q4. 窗口边界 vs 图结构")
    print("=" * 100)

    # 对每对，记录它的窗口右边界 hi
    window_data = []
    for p in same_response_data:
        w = find_max_window(p)
        if w is not None:
            window_data.append((p["gid"], p["e1"], p["e2"], w["lo"], w["hi"]))

    # 按 gid 分组
    by_gid_window = defaultdict(list)
    for gid, e1, e2, lo, hi in window_data:
        by_gid_window[gid].append((lo, hi))

    print(f"\n  {'gid':>4} | {'窗口数':>6} | {'窗口 lo 均值':>12} | {'窗口 hi 均值':>12}")
    print(f"  {'-'*4}-+-{'-'*6}-+-{'-'*12}-+-{'-'*12}")
    for gid in sorted(by_gid_window.keys()):
        wins = by_gid_window[gid]
        los = [w[0] for w in wins]
        his = [w[1] for w in wins]
        print(f"  {gid:>4} | {len(wins):>6} | {np.mean(los):>12.3f} | "
              f"{np.mean(his):>12.3f}")

    # ============================================================
    # Q5: 用"更窄窗口"作为条件穷举
    # ============================================================
    print("\n" + "=" * 100)
    print("Q5. 更窄窗口穷举：覆盖 47 对的最小窗口")
    print("=" * 100)

    # 尝试多个窗口 (lo, hi)
    # 目标：在窗口内 |Δ(s)| < 1e-6 的对，尽量覆盖 47 对
    # 但需要同时评估精度（用全部 2731 对做候选筛选，不只是 47 对）

    # 先扫描全部 2731 对，计算每对的 abs_diff_curve
    print(f"\n  扫描全部 2731 对（81 点 s 采样）...")
    all_pairs = []
    for gid, G in enumerate(graphs):
        if gid % 30 == 0:
            print(f"    {gid}/{len(graphs)}")
        edges = [tuple(sorted(e)) for e in G.edges()]
        GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
        autos = list(GM.isomorphisms_iter())
        orbits = {}
        for e in edges:
            orbit = frozenset(frozenset({a[e[0]], a[e[1]]}) for a in autos)
            orbits[e] = orbit

        edge_ops = {e: build_edge_op(e[0], e[1], basis, idx) for e in edges}
        edge_features = {}
        for e in edges:
            S_curve = []
            sd_curve = []
            for s in s_vals:
                r = analyze_at_s(edge_ops, e, s, SZ_ops, S2_op, ref_dim)
                if r:
                    S_curve.append(r["S"])
                    sd_curve.append(r["sd"])
                else:
                    S_curve.append(np.nan)
                    sd_curve.append(np.nan)
            edge_features[e] = {
                "S_curve": np.array(S_curve),
                "sd_curve": np.array(sd_curve),
            }

        for i in range(len(edges)):
            for j in range(i + 1, len(edges)):
                e1, e2 = edges[i], edges[j]
                if orbits[e1] == orbits[e2]:
                    continue
                key = (gid, e1, e2)
                n_true = patterns[key].count("1") if key in patterns else 0

                abs_diff = np.abs(np.abs(edge_features[e1]["sd_curve"]) -
                                  np.abs(edge_features[e2]["sd_curve"]))
                S1_05 = edge_features[e1]["S_curve"][np.argmin(np.abs(s_vals - 0.5))]
                S2_05 = edge_features[e2]["S_curve"][np.argmin(np.abs(s_vals - 0.5))]

                all_pairs.append({
                    "gid": gid, "e1": e1, "e2": e2,
                    "n_true": n_true,
                    "S1": float(S1_05),
                    "S2": float(S2_05),
                    "abs_diff_curve": abs_diff.tolist(),
                })

    print(f"\n  完成 {len(all_pairs)} 对")

    # 穷举窗口
    print(f"\n  穷举窗口...")
    windows_to_test = [
        (-2.0, 2.0), (-2.0, 1.5), (-1.5, 1.5), (-1.5, 1.0),
        (-1.5, 0.5), (-1.0, 1.0), (-1.0, 0.5), (-1.0, 0.0),
        (-0.5, 0.5), (-0.5, 0.0), (-1.5, 0.0), (-1.5, -0.5),
        (-2.0, 0.0), (-2.0, -0.5),
    ]

    print(f"\n  {'窗口':>15} | {'候选':>6} | {'命中':>6} | {'精度':>6} | {'召回':>6} | {'F1':>6}")
    print(f"  {'-'*15}-+-{'-'*6}-+-{'-'*6}-+-{'-'*6}-+-{'-'*6}-+-{'-'*6}")

    for lo, hi in windows_to_test:
        m = (s_vals >= lo) & (s_vals <= hi)
        n_cand = 0
        n_hit = 0
        for p in all_pairs:
            abs_arr = np.array(p["abs_diff_curve"])[m]
            if np.all(abs_arr < 1e-6):
                n_cand += 1
                if p["n_true"] > 0:
                    n_hit += 1
        prec = n_hit / n_cand if n_cand else 0
        rec = n_hit / 47
        f1 = 2 * prec * rec / (prec + rec) if (prec + rec) > 0 else 0
        print(f"  [{lo:>5.2f},{hi:>5.2f}] | {n_cand:>6} | {n_hit:>6} | "
              f"{prec:>5.1%} | {rec:>5.1%} | {f1:>5.1%}")

    # ============================================================
    # 深度追问：图 38 和 图 103 的 s 窗口
    # ============================================================
    print("\n" + "=" * 100)
    print("深度追问：图 38 和 图 103 的 s 窗口")
    print("=" * 100)

    for gid in [38, 103]:
        print(f"\n  --- gid = {gid} 的 9 对 ---")
        for p in sorted(same_response_data, key=lambda x: (x["gid"], x["e1"])):
            if p["gid"] != gid:
                continue
            w = find_max_window(p)
            print(f"    e1={p['e1']}, e2={p['e2']}, n_true={p['n_true']}")
            if w:
                print(f"      窗口: [{w['lo']:.3f}, {w['hi']:.3f}], {w['n_points']} 点")
            else:
                print(f"      窗口: none")

    # ============================================================
    # 导出
    # ============================================================
    out = {
        "n_same_response": len(same_response_data),
        "n_L4_pass": len(p_L4_win),
        "n_L4_fail": len(p_L4_fail),
        "L4_fail_list": [
            {"gid": p["gid"], "e1": list(p["e1"]), "e2": list(p["e2"]),
             "n_true": p["n_true"],
             "max_abs_diff_win": in_window(p, -1.0, 1.0)}
            for p in p_L4_fail
        ],
    }
    out_path = os.path.join(WORK_DIR, "照妖镜_v33_L4窗口.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("v33.0 完成。")
    print("=" * 100)


if __name__ == "__main__":
    main()