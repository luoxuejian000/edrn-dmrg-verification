# -*- coding: utf-8 -*-
"""
================================================================================
照妖镜协议 v4.0
用 32 倒推：找到 32 对，提取共同 DNA

三个阶段：
  1. 搜索产生 32 的窗口（穷举所有可能的 s 范围）
  2. 提取 32 对的共同 DNA（在所有 32 对中恒定的关系特征）
  3. 并排比较不同 32 配置的 DNA

晶脉哲学：
  · 关系本体论：只看关系位置，不看节点标签
  · 对象化=截断=产生方向：每个窗口都标注
  · 只查同与不同：不拟合，不回归，不预设
  · 反对对齐：不预设"32 是对的"，只报告数据说了什么
  · 严防工具理性悖论：脚本是工具，追问是行动
================================================================================
"""

import os
import json
import warnings
from collections import Counter, defaultdict
from itertools import combinations

import numpy as np
import networkx as nx

warnings.filterwarnings('ignore')

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"
N_NODES = 6
TARGET = 32
TOL = 1e-10

# ============================================================
# 基础
# ============================================================

def fmt(x, nd=10):
    if isinstance(x, (bool, np.bool_)):
        return "True" if x else "False"
    if isinstance(x, (int, np.integer)):
        return str(int(x))
    if isinstance(x, (float, np.floating)):
        if np.isnan(x):
            return "nan"
        if abs(x) < 1e-14:
            return "0"
        return f"{x:.{nd}f}"
    return str(x)


def build_all_N6_graphs():
    candidates = []
    for G in nx.graph_atlas_g():
        if G.number_of_nodes() == N_NODES and nx.is_connected(G):
            candidates.append(nx.convert_node_labels_to_integers(G))
    unique = []
    for G in candidates:
        if not any(nx.is_isomorphic(G, H) for H in unique):
            unique.append(G)
    return unique


def build_adj_list(G):
    nodes = sorted(G.nodes())
    node_idx = {n: i for i, n in enumerate(nodes)}
    edges = sorted([tuple(sorted((node_idx[a], node_idx[b])))
                    for a, b in G.edges()])
    return edges


def sz0_basis(N):
    n_up = N // 2
    basis = []
    for comb in combinations(range(N), n_up):
        state = [0] * N
        for i in comb:
            state[i] = 1
        basis.append(tuple(state))
    return basis


def build_H_sz0(N, edges, couplings):
    basis = sz0_basis(N)
    dim = len(basis)
    idx = {s: i for i, s in enumerate(basis)}
    H = np.zeros((dim, dim))
    for i, state in enumerate(basis):
        for (a, b), J in zip(edges, couplings):
            if state[a] == state[b]:
                H[i, i] += J
            else:
                H[i, i] -= J
                new_state = list(state)
                new_state[a], new_state[b] = new_state[b], new_state[a]
                H[i, idx[tuple(new_state)]] += 2.0 * J
    return H, basis


def edge_orbits(G, edges):
    GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
    autos = list(GM.isomorphisms_iter())
    orbits = {}
    for e in edges:
        orbit = set()
        for auto in autos:
            mapped = frozenset({auto[e[0]], auto[e[1]]})
            orbit.add(mapped)
        orbits[e] = frozenset(orbit)
    uniq = {}
    out = {}
    for e in edges:
        o = orbits[e]
        if o not in uniq:
            uniq[o] = len(uniq)
        out[e] = uniq[o]
    return out


def compute_E_curve(G, defect_edge, s_grid, degen_tol=1e-8):
    N = G.number_of_nodes()
    edges = build_adj_list(G)
    target = tuple(sorted(defect_edge))
    if target not in edges:
        target = tuple(sorted((defect_edge[1], defect_edge[0])))
    curves = []
    for s in s_grid:
        couplings = [s if e == target else 1.0 for e in edges]
        H, basis = build_H_sz0(N, edges, couplings)
        try:
            vals, vecs = np.linalg.eigh(H)
        except Exception:
            curves.append(np.nan)
            continue
        E0 = vals[0]
        degen = np.where(np.abs(vals - E0) < degen_tol)[0]
        rho = np.zeros_like(H)
        for k in degen:
            v = vecs[:, k].reshape(-1, 1)
            rho += v @ v.conj().T
        rho /= len(degen)
        sz_config = np.array([[1.0 if state[i] == 1 else -1.0
                               for i in range(N)] for state in basis])
        rho_diag = np.diag(rho).real
        corr = []
        for (a, b) in edges:
            val = float(np.sum(rho_diag * sz_config[:, a] * sz_config[:, b]))
            corr.append(val)
        curves.append(float(np.std(corr)))
    return np.array(curves)


def extract_pair_features(G, e1, e2, orbits):
    """提取一对边的所有关系特征"""
    n1a, n1b = e1
    n2a, n2b = e2
    s1 = {n1a, n1b}
    s2 = {n2a, n2b}
    inter = (set(G.neighbors(n1a)) | set(G.neighbors(n1b))) & \
            (set(G.neighbors(n2a)) | set(G.neighbors(n2b)))
    union = (set(G.neighbors(n1a)) | set(G.neighbors(n1b))) | \
            (set(G.neighbors(n2a)) | set(G.neighbors(n2b)))
    try:
        dist = nx.shortest_path_length(G, n1a, n2a)
    except Exception:
        dist = -1
    orbit_size = Counter(orbits.values())
    bridges = set(map(frozenset, nx.bridges(G)))
    try:
        L = nx.laplacian_matrix(G).astype(float).toarray()
        Lpinv = np.linalg.pinv(L)
        def eff_res(u, v):
            return float(Lpinv[u, u] + Lpinv[v, v] - 2 * Lpinv[u, v])
        er1, er2 = eff_res(*e1), eff_res(*e2)
    except Exception:
        er1 = er2 = np.nan
    # 收缩度序列
    try:
        G1 = nx.contracted_edge(G, e1, self_loops=False)
        ds1 = tuple(sorted(d for _, d in G1.degree()))
    except Exception:
        ds1 = ()
    try:
        G2 = nx.contracted_edge(G, e2, self_loops=False)
        ds2 = tuple(sorted(d for _, d in G2.degree()))
    except Exception:
        ds2 = ()
    return {
        "share_endpoint": len(s1 & s2) > 0,
        "edge_distance": dist,
        "common_neighbors": len(inter),
        "neighbor_union": len(union),
        "neighbor_jaccard": len(inter) / len(union) if union else 0.0,
        "degree_1a": G.degree(n1a), "degree_1b": G.degree(n1b),
        "degree_2a": G.degree(n2a), "degree_2b": G.degree(n2b),
        "degree_pair_1": tuple(sorted([G.degree(n1a), G.degree(n1b)])),
        "degree_pair_2": tuple(sorted([G.degree(n2a), G.degree(n2b)])),
        "degree_sum_1": G.degree(n1a) + G.degree(n1b),
        "degree_sum_2": G.degree(n2a) + G.degree(n2b),
        "orbit_size_1": orbit_size[orbits[e1]],
        "orbit_size_2": orbit_size[orbits[e2]],
        "orbit_size_sym": orbit_size[orbits[e1]] == orbit_size[orbits[e2]],
        "triangle_1": sum(1 for _ in nx.common_neighbors(G, n1a, n1b)),
        "triangle_2": sum(1 for _ in nx.common_neighbors(G, n2a, n2b)),
        "kcore_1": min(nx.core_number(G)[n1a], nx.core_number(G)[n1b]),
        "kcore_2": min(nx.core_number(G)[n2a], nx.core_number(G)[n2b]),
        "is_bridge_1": frozenset(e1) in bridges,
        "is_bridge_2": frozenset(e2) in bridges,
        "eff_res_1": er1, "eff_res_2": er2,
        "eff_res_sym": (not np.isnan(er1)) and (not np.isnan(er2)) and abs(er1 - er2) < 1e-8,
        "contract_deg_seq_1": ds1, "contract_deg_seq_2": ds2,
        "contract_deg_seq_sym": ds1 == ds2 and len(ds1) > 0,
    }


# ============================================================
# 阶段 1：搜索产生 32 的窗口
# ============================================================

def search_windows(graphs, all_curves, wide_grid):
    """
    穷举窗口，返回所有给出恰好 TARGET 对的窗口。
    """
    # 生成大量候选窗口
    windows = set()
    # 对称窗口
    for center in np.arange(-2.0, 2.01, 0.1):
        for half_width in np.arange(0.1, 4.01, 0.1):
            lo = round(center - half_width, 2)
            hi = round(center + half_width, 2)
            if lo >= -4 and hi <= 4 and hi > lo:
                windows.add((lo, hi))
    # 不对称窗口
    for lo in np.arange(-3.0, 1.01, 0.5):
        for hi in np.arange(lo + 0.3, 3.01, 0.3):
            if hi - lo >= 0.5 and lo >= -4 and hi <= 4:
                windows.add((round(lo, 2), round(hi, 2)))
    # 从 0.5 开始的窗口（沉默区间相关）
    for hi in np.arange(0.7, 3.01, 0.1):
        windows.add((0.5, round(hi, 2)))

    windows = sorted(windows)
    print(f"  候选窗口数: {len(windows)}")

    # 预处理：对每个图，建立边对列表
    pair_list = []
    for gid, G in enumerate(graphs):
        edges = build_adj_list(G)
        orbits = edge_orbits(G, edges)
        for i in range(len(edges)):
            for j in range(i + 1, len(edges)):
                e1, e2 = edges[i], edges[j]
                if orbits[e1] == orbits[e2]:
                    continue
                pair_list.append((gid, e1, e2))
    print(f"  总异轨道对数: {len(pair_list)}")

    # 预计算每对的 |diff| 曲线（在宽网格上）
    print(f"  预计算每对的 |diff| 曲线...")
    diff_curves = {}
    for idx, (gid, e1, e2) in enumerate(pair_list):
        if idx % 500 == 0:
            print(f"    {idx}/{len(pair_list)}")
        c1 = all_curves[gid][e1]
        c2 = all_curves[gid][e2]
        d = np.abs(c1 - c2)
        # 处理 NaN
        d[np.isnan(d)] = np.inf
        diff_curves[(gid, e1, e2)] = d
    print(f"  完成")

    # 对每个窗口，计算对数
    print(f"  扫描窗口...")
    results = []
    for wi, (lo, hi) in enumerate(windows):
        if wi % 200 == 0:
            print(f"    窗口 {wi}/{len(windows)}")
        mask = (wide_grid >= lo) & (wide_grid <= hi)
        if mask.sum() < 5:
            continue
        count = 0
        pairs_in_window = []
        for key, d in diff_curves.items():
            if np.max(d[mask]) < TOL:
                count += 1
                pairs_in_window.append(key)
        results.append({
            "window": (lo, hi),
            "n_points": int(mask.sum()),
            "n_pairs": count,
            "pairs": pairs_in_window,
        })

    return results


# ============================================================
# 阶段 2：提取 DNA
# ============================================================

def analyze_dna(pairs, graphs):
    """
    对一组对（例如32对），提取共同 DNA。
    DNA = 在所有对中恒定的关系特征。
    """
    rows = []
    for gid, e1, e2 in pairs:
        G = graphs[gid]
        edges = build_adj_list(G)
        orbits = edge_orbits(G, edges)
        feats = extract_pair_features(G, e1, e2, orbits)
        feats["graph_id"] = gid
        feats["e1"] = e1
        feats["e2"] = e2
        rows.append(feats)

    if not rows:
        return None, []

    # 分析每个特征
    feature_names = [k for k in rows[0].keys()
                     if k not in ("graph_id", "e1", "e2")]
    dna = []       # 恒定的特征
    variable = []  # 变化的特征
    for fname in feature_names:
        values = [r[fname] for r in rows]
        cnt = Counter([str(v) for v in values])
        if len(cnt) == 1:
            dna.append((fname, values[0]))
        else:
            variable.append((fname, dict(cnt)))

    return rows, dna, variable


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 100)
    print("照妖镜协议 v4.0")
    print("用 32 倒推：找到 32 对，提取共同 DNA")
    print("=" * 100)

    # ---------- 准备 ----------
    print("\n[准备] 构建图集…")
    graphs = build_all_N6_graphs()
    print(f"  图集: {len(graphs)} 个 N=6 连通图")

    print("\n[准备] 预计算所有 E 曲线（宽网格 [-4.5,4.5] × 181 点）…")
    wide_grid = np.linspace(-4.5, 4.5, 181)
    all_curves = {}
    for gid, G in enumerate(graphs):
        if gid % 20 == 0:
            print(f"    {gid}/{len(graphs)}")
        edges = build_adj_list(G)
        all_curves[gid] = {e: compute_E_curve(G, e, wide_grid) for e in edges}
    print("  完成")

    # ---------- 阶段 1 ----------
    print("\n" + "=" * 100)
    print("阶段 1：搜索产生 32 的窗口")
    print("=" * 100)
    results = search_windows(graphs, all_curves, wide_grid)

    # 找到 32 的窗口
    exact_32 = [r for r in results if r["n_pairs"] == TARGET]
    closest = sorted(results, key=lambda r: abs(r["n_pairs"] - TARGET))[:10]

    print(f"\n  给出恰好 32 对的窗口数: {len(exact_32)}")
    if exact_32:
        print(f"\n  --- 所有 32 对窗口 ---")
        for r in exact_32:
            print(f"    {r['window']}: {r['n_pairs']} 对 ({r['n_points']} 点)")
    else:
        print(f"\n  --- 没有窗口给出恰好 32 对 ---")
        print(f"\n  --- 最接近 32 的 10 个窗口 ---")
        print(f"  {'窗口':>18} | {'点数':>5} | {'对数':>5}")
        print(f"  {'-'*18}-+-{'-'*5}-+-{'-'*5}")
        for r in closest:
            print(f"  {str(r['window']):>18} | {r['n_points']:>5} | {r['n_pairs']:>5}")

    # 选择要深入分析的集合
    if exact_32:
        print(f"\n  [选择] 使用第一个给出 32 的窗口进行分析")
        analyze_set = exact_32[0]
        source = "exact_32"
    else:
        print(f"\n  [选择] 没有 32，使用最接近的窗口进行分析")
        analyze_set = closest[0]
        source = "closest"

    pairs = analyze_set["pairs"]
    print(f"  分析窗口: {analyze_set['window']}")
    print(f"  分析对数: {len(pairs)}")

    # ---------- 阶段 2 ----------
    print("\n" + "=" * 100)
    print(f"阶段 2：提取 DNA（{len(pairs)} 对）")
    print("=" * 100)
    rows, dna, variable = analyze_dna(pairs, graphs)

    print(f"\n  --- DNA（在所有 {len(pairs)} 对中恒定）---")
    if dna:
        for fname, value in dna:
            print(f"    {fname:>25} = {fmt(value)}")
    else:
        print(f"    （没有任何特征在所有对中恒定）")

    print(f"\n  --- 变化特征（分布）---")
    for fname, cnt in variable:
        # 按出现次数排序
        items = sorted(cnt.items(), key=lambda x: -x[1])
        # 只显示前 6 个
        top = items[:6]
        rest = len(items) - len(top)
        line = ", ".join(f"{v}:{c}" for v, c in top)
        if rest > 0:
            line += f", ... (+{rest} 种)"
        print(f"    {fname:>25}: {line}")

    # ---------- 阶段 2b：按图分组 ----------
    print(f"\n  --- 按 graph_id 分组 ---")
    gid_groups = defaultdict(list)
    for r in rows:
        gid_groups[r["graph_id"]].append(r)
    print(f"  {'gid':>4} | {'对数':>4} | {'边对':>50}")
    print(f"  {'-'*4}-+-{'-'*4}-+-{'-'*50}")
    for gid in sorted(gid_groups.keys()):
        group = gid_groups[gid]
        edge_strs = [f"{r['e1']}-{r['e2']}" for r in group]
        edge_str = ", ".join(edge_strs[:5])
        if len(edge_strs) > 5:
            edge_str += f", ... (+{len(edge_strs)-5})"
        print(f"  {gid:>4} | {len(group):>4} | {edge_str:>50}")

    # ---------- 阶段 3：并排比较 ----------
    if len(exact_32) > 1:
        print("\n" + "=" * 100)
        print(f"阶段 3：并排比较 {len(exact_32)} 个 32-配置")
        print("=" * 100)
        pair_sets = [set(map(tuple, [list(p) for p in r["pairs"]])) for r in exact_32]
        # 两两比较
        print(f"\n  --- 对集重叠矩阵 ---")
        print(f"  {'':>4} | " + " | ".join(f"{i:>5}" for i in range(len(exact_32))))
        print(f"  {'-'*4}-+-" + "-+-".join("-" * 5 for _ in exact_32))
        for i, si in enumerate(pair_sets):
            row_str = f"  {i:>4} | "
            for j, sj in enumerate(pair_sets):
                common = len(si & sj)
                row_str += f"{common:>5} | "
            print(row_str)

        # 所有 32-配置的并集与交集
        all_union = set().union(*pair_sets)
        all_inter = set.intersection(*pair_sets) if len(pair_sets) > 1 else pair_sets[0]
        print(f"\n  所有 32-配置的并集: {len(all_union)} 对")
        print(f"  所有 32-配置的交集: {len(all_inter)} 对")
        print(f"  始终在 32 中的对（交集）:")
        for key in sorted(all_inter):
            print(f"    {key}")
    else:
        print("\n  （只有 0 或 1 个 32-配置，跳过阶段 3）")

    # ---------- 导出 ----------
    out = {
        "target": TARGET,
        "n_windows_searched": len(results),
        "n_exact_32_windows": len(exact_32),
        "exact_32_windows": [
            {"window": list(r["window"]), "n_pairs": r["n_pairs"]}
            for r in exact_32
        ],
        "closest_10": [
            {"window": list(r["window"]), "n_pairs": r["n_pairs"]}
            for r in closest
        ],
        "analyzed_window": list(analyze_set["window"]),
        "analyzed_n_pairs": len(pairs),
        "analyzed_pairs": [
            {"gid": g, "e1": list(e1), "e2": list(e2)}
            for g, e1, e2 in pairs
        ],
        "DNA": [(f, str(v)) for f, v in dna],
        "variable_summary": [(f, dict(c)) for f, c in variable],
    }
    out_path = os.path.join(WORK_DIR, "照妖镜_32倒推_v4.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("32 倒推完成。结果并排。不筛选。不下结论。")
    print("脚本是对象化，追问是行动。")
    print("=" * 100)


if __name__ == "__main__":
    main()