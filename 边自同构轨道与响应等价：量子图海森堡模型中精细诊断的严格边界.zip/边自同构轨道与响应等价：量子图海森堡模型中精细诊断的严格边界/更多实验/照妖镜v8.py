#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 v8.0：攻击 p_S = 0 和 p_S = 1/2 的解析条件
================================================================

机制链条已经锁死：
  SU(2) 单态基态 → ρ_ij 单参数 → ⟨σᶻσᶻ⟩ = 1/3 - 4p_S/3
  谐振点 = p_S 的精确代数点

现在攻击最后一层：为什么特定图在特定 s 下 p_S 恰好等于 0 或 1/2？

五个追问并行：
  Q1. p_S = 0 的图/边/s 有什么共同关系结构？
  Q2. p_S = 1/2 的图/边/s 有什么共同关系结构？
  Q3. p_S(s) 曲线的形状：单调、台阶、还是共振峰？
  Q4. 基态波函数在缺陷边两端的自旋结构是什么？
  Q5. p_S = 0 或 1/2 的 s 值是否可由图的不变量（度、Laplacian、桥、距离）解析预测？
"""

import sys, io, itertools, json, os
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from collections import Counter, defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"
N = 6
TOL = 1e-10

# ============================================================
# 自旋算符
# ============================================================

I2 = np.eye(2, dtype=complex)
SX = np.array([[0,1],[1,0]], dtype=complex)
SY = np.array([[0,-1j],[1j,0]], dtype=complex)
SZ = np.array([[1,0],[0,-1]], dtype=complex)


def op_on_site(op, site, N):
    ops = [I2]*N; ops[site] = op
    out = ops[0]
    for o in ops[1:]: out = np.kron(out, o)
    return out


def build_site_ops(N):
    return ([op_on_site(SX,i,N) for i in range(N)],
            [op_on_site(SY,i,N) for i in range(N)],
            [op_on_site(SZ,i,N) for i in range(N)])


def edge_matrix(i, j, SXo, SYo, SZo):
    return SXo[i]@SXo[j] + SYo[i]@SYo[j] + SZo[i]@SZo[j]


def ground_state_all(H, tol=1e-8):
    """返回 E0, 简并数, 基态子空间（列向量矩阵）"""
    evals, evecs = eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < tol))
    V = evecs[:, :deg]
    return E0, deg, V, evals


def gs_rho(H, tol=1e-8):
    E0, deg, V, _ = ground_state_all(H, tol)
    return V @ V.conj().T / deg


# ============================================================
# 约化密度矩阵
# ============================================================

def partial_trace_2sites(rho, i, j, N):
    dims = [2]*N
    rho_t = rho.reshape(dims + dims)
    perm = []
    for k in [i, j]: perm.append(k)
    for k in range(N):
        if k not in (i, j): perm.append(k)
    for k in [i, j]: perm.append(N+k)
    for k in range(N):
        if k not in (i, j): perm.append(N+k)
    rho_p = np.transpose(rho_t, perm)
    d_keep = 4
    d_trace = 2**(N-2)
    rho_r = rho_p.reshape(d_keep, d_trace, d_keep, d_trace)
    return np.trace(rho_r, axis1=1, axis2=3)


def analyze_rho2(rho_ij):
    """提取 p_S, c, ⟨σᶻσᶻ⟩ 等"""
    p_S = 0.5 * (rho_ij[1,1].real - rho_ij[1,2].real
                 - rho_ij[2,1].real + rho_ij[2,2].real)
    sz_sz = np.array([[1,0,0,0],[0,-1,0,0],[0,0,-1,0],[0,0,0,1]], dtype=complex)
    szsz = float(np.real(np.trace(rho_ij @ sz_sz)))
    # 纠缠熵
    evals = np.linalg.eigvalsh(rho_ij)
    evals = evals[evals > 1e-14]
    S_ent = float(-np.sum(evals * np.log(evals)))
    # 纯度
    purity = float(np.real(np.trace(rho_ij @ rho_ij)))
    return {
        "p_S": p_S, "szsz": szsz,
        "entropy": S_ent, "purity": purity,
    }


# ============================================================
# 从 v5.1 加载同响应对
# ============================================================

def load_same_response_pairs():
    with open(os.path.join(WORK_DIR, "照妖镜_v5_1_模式.json"), "r",
              encoding="utf-8") as f:
        v51 = json.load(f)
    pairs = {}
    for key, s in v51["patterns"].items():
        gid, e1_str, e2_str = key.split("_", 2)
        gid = int(gid)
        e1 = tuple(map(int, e1_str.strip("()").split(",")))
        e2 = tuple(map(int, e2_str.strip("()").split(",")))
        pairs[(gid, e1, e2)] = s
    return pairs


# ============================================================
# 关键分析：找 p_S 精确等于 0 或 1/2 的 s
# ============================================================

def find_resonance_s(pS_curve, s_vals, target, tol=1e-6):
    """找 pS_curve 最接近 target 的 s 值"""
    diffs = np.abs(np.array(pS_curve) - target)
    idx = int(np.argmin(diffs))
    return s_vals[idx], pS_curve[idx], diffs[idx]


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 100)
    print("照妖镜 v8.0：攻击 p_S = 0 和 p_S = 1/2 的解析条件")
    print("=" * 100)

    # 图集
    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    print(f"\n  图集: {len(graphs)} 个 N=6 连通图")

    same_pairs = load_same_response_pairs()
    same_keys = set(same_pairs.keys())
    print(f"  同响应对: {len(same_keys)}")

    SXo, SYo, SZo = build_site_ops(N)

    # 收集所有相关 (gid, defect)
    defect_edges = set()
    for gid, e1, e2 in same_keys:
        defect_edges.add((gid, e1))
        defect_edges.add((gid, e2))

    # 精细 s 网格
    s_vals = np.linspace(-2.0, 2.0, 81)
    print(f"  s 网格: [{s_vals[0]}, {s_vals[-1]}], {len(s_vals)} 点")

    # 对每个 (gid, defect) 计算完整 p_S 曲线 + 波函数信息
    print(f"\n  计算 p_S 曲线…")
    pS_cache = {}
    for idx, (gid, defect) in enumerate(sorted(defect_edges)):
        if idx % 10 == 0:
            print(f"    {idx}/{len(defect_edges)}")
        G = graphs[gid]
        edges = [tuple(sorted(e)) for e in G.edges()]
        H_edges = [edge_matrix(e[0], e[1], SXo, SYo, SZo) for e in edges]
        pS_cache[(gid, defect)] = {"s": s_vals.tolist(),
                                   "p_S": [], "szsz": [],
                                   "entropy": [], "purity": [],
                                   "deg": []}
        for s in s_vals:
            couplings = [s if e == defect else 1.0 for e in edges]
            H = sum(c*M for c, M in zip(couplings, H_edges))
            E0, deg, V, _ = ground_state_all(H)
            rho = V @ V.conj().T / deg
            rho_ij = partial_trace_2sites(rho, defect[0], defect[1], N)
            a = analyze_rho2(rho_ij)
            pS_cache[(gid, defect)]["p_S"].append(a["p_S"])
            pS_cache[(gid, defect)]["szsz"].append(a["szsz"])
            pS_cache[(gid, defect)]["entropy"].append(a["entropy"])
            pS_cache[(gid, defect)]["purity"].append(a["purity"])
            pS_cache[(gid, defect)]["deg"].append(deg)
    print(f"  完成")

    # ============================================================
    # Q1: p_S = 0 的图/边/s 有什么共同关系结构？
    # ============================================================
    print("\n" + "=" * 100)
    print("Q1. p_S = 0 的图/边/s 有什么共同关系结构？")
    print("=" * 100)

    # 找所有 p_S 精确等于 0 的 (gid, defect, s)
    zero_hits = []
    for (gid, defect), data in pS_cache.items():
        for si, pS in enumerate(data["p_S"]):
            if abs(pS) < 1e-6:
                zero_hits.append((gid, defect, s_vals[si], pS))

    print(f"\n  总命中 (p_S = 0): {len(zero_hits)} 次")
    print(f"\n  {'gid':>4} | {'defect':>8} | {'s':>6} | {'p_S':>12} | {'边数':>4} | {'桥数':>4} | {'Laplacian[1]':>12} | {'defect度对':>12}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*6}-+-{'-'*12}-+-{'-'*4}-+-{'-'*4}-+-{'-'*12}-+-{'-'*12}")
    for gid, defect, s, pS in zero_hits[:60]:
        G = graphs[gid]
        L = nx.laplacian_matrix(G).astype(float).toarray()
        L1 = sorted(np.linalg.eigvalsh(L))[1]
        degs = tuple(sorted([G.degree(defect[0]), G.degree(defect[1])]))
        n_bridges = len(list(nx.bridges(G)))
        print(f"  {gid:>4} | {str(defect):>8} | {s:>6.2f} | {pS:>12.2e} | "
              f"{len(list(G.edges())):>4} | {n_bridges:>4} | {L1:>12.4f} | {str(degs):>12}")

    # ============================================================
    # Q2: p_S = 1/2 的图/边/s 有什么共同关系结构？
    # ============================================================
    print("\n" + "=" * 100)
    print("Q2. p_S = 1/2 的图/边/s 有什么共同关系结构？")
    print("=" * 100)

    half_hits = []
    for (gid, defect), data in pS_cache.items():
        for si, pS in enumerate(data["p_S"]):
            if abs(pS - 0.5) < 1e-6:
                half_hits.append((gid, defect, s_vals[si], pS))

    print(f"\n  总命中 (p_S = 1/2): {len(half_hits)} 次")
    print(f"\n  {'gid':>4} | {'defect':>8} | {'s':>6} | {'p_S':>12} | {'边数':>4} | {'桥数':>4} | {'Laplacian[1]':>12} | {'defect度对':>12}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*6}-+-{'-'*12}-+-{'-'*4}-+-{'-'*4}-+-{'-'*12}-+-{'-'*12}")
    for gid, defect, s, pS in half_hits[:60]:
        G = graphs[gid]
        L = nx.laplacian_matrix(G).astype(float).toarray()
        L1 = sorted(np.linalg.eigvalsh(L))[1]
        degs = tuple(sorted([G.degree(defect[0]), G.degree(defect[1])]))
        n_bridges = len(list(nx.bridges(G)))
        print(f"  {gid:>4} | {str(defect):>8} | {s:>6.2f} | {pS:>12.2e} | "
              f"{len(list(G.edges())):>4} | {n_bridges:>4} | {L1:>12.4f} | {str(degs):>12}")

    # ============================================================
    # Q3: p_S(s) 曲线的形状
    # ============================================================
    print("\n" + "=" * 100)
    print("Q3. p_S(s) 曲线的形状：单调、台阶、还是共振峰？")
    print("=" * 100)

    # 分类：单调递增/单调递减/有极值/多台阶
    def classify_curve(curve):
        diffs = np.diff(curve)
        pos = (diffs > 1e-6).sum()
        neg = (diffs < -1e-6).sum()
        zero = (np.abs(diffs) <= 1e-6).sum()
        if pos == 0 and neg == 0:
            return "平坦"
        if neg == 0:
            return "单调递增"
        if pos == 0:
            return "单调递减"
        return f"混合(pos={pos}, neg={neg}, flat={zero})"

    print(f"\n  {'gid':>4} | {'defect':>8} | {'曲线类型':>20} | {'p_S@-2':>10} | {'p_S@0':>10} | {'p_S@2':>10} | {'是否穿过 0':>10} | {'是否穿过 1/2':>12}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*20}-+-{'-'*10}-+-{'-'*10}-+-{'-'*10}-+-{'-'*10}-+-{'-'*12}")
    for (gid, defect) in sorted(pS_cache.keys()):
        curve = np.array(pS_cache[(gid, defect)]["p_S"])
        ctype = classify_curve(curve)
        # 是否穿过 0
        crosses_0 = (np.min(curve) < 0) and (np.max(curve) > 0)
        crosses_half = (np.min(curve) < 0.5) and (np.max(curve) > 0.5)
        print(f"  {gid:>4} | {str(defect):>8} | {ctype:>20} | "
              f"{curve[0]:>10.4f} | {curve[len(curve)//2]:>10.4f} | "
              f"{curve[-1]:>10.4f} | {str(crosses_0):>10} | {str(crosses_half):>12}")

    # ============================================================
    # Q4: 基态波函数在缺陷边两端的自旋结构
    # ============================================================
    print("\n" + "=" * 100)
    print("Q4. 基态波函数在缺陷边两端的自旋结构")
    print("=" * 100)

    # 对 p_S = 0 的 (gid, defect, s)，输出约化密度矩阵的完整形式
    print(f"\n  抽样输出：p_S = 0 处的完整 ρ_ij")
    print(f"\n  (ρ_ij 基顺序: |↑↑⟩, |↑↓⟩, |↓↑⟩, |↓↓⟩)")
    print()
    shown = 0
    for gid, defect, s, pS in zero_hits:
        if shown >= 5:
            break
        G = graphs[gid]
        edges = [tuple(sorted(e)) for e in G.edges()]
        H_edges = [edge_matrix(e[0], e[1], SXo, SYo, SZo) for e in edges]
        couplings = [s if e == defect else 1.0 for e in edges]
        H = sum(c*M for c, M in zip(couplings, H_edges))
        E0, deg, V, evals = ground_state_all(H)
        rho = V @ V.conj().T / deg
        rho_ij = partial_trace_2sites(rho, defect[0], defect[1], N)
        print(f"  --- gid={gid}, defect={defect}, s={s:.2f}, p_S={pS:.2e}, 基态简并={deg} ---")
        print(f"  ρ_ij =")
        for row in rho_ij.real:
            print(f"    [{row[0]:>8.5f} {row[1]:>8.5f} {row[2]:>8.5f} {row[3]:>8.5f}]")
        # 能量谱
        print(f"  基态能量: {E0:.6f}, 第一激发能: {evals[1]:.6f}, gap={evals[1]-E0:.6f}")
        print()
        shown += 1

    # 对 p_S = 1/2 的抽样
    print(f"  抽样输出：p_S = 1/2 处的完整 ρ_ij")
    print()
    shown = 0
    for gid, defect, s, pS in half_hits:
        if shown >= 5:
            break
        G = graphs[gid]
        edges = [tuple(sorted(e)) for e in G.edges()]
        H_edges = [edge_matrix(e[0], e[1], SXo, SYo, SZo) for e in edges]
        couplings = [s if e == defect else 1.0 for e in edges]
        H = sum(c*M for c, M in zip(couplings, H_edges))
        E0, deg, V, evals = ground_state_all(H)
        rho = V @ V.conj().T / deg
        rho_ij = partial_trace_2sites(rho, defect[0], defect[1], N)
        print(f"  --- gid={gid}, defect={defect}, s={s:.2f}, p_S={pS:.6f}, 基态简并={deg} ---")
        print(f"  ρ_ij =")
        for row in rho_ij.real:
            print(f"    [{row[0]:>8.5f} {row[1]:>8.5f} {row[2]:>8.5f} {row[3]:>8.5f}]")
        print(f"  基态能量: {E0:.6f}, 第一激发能: {evals[1]:.6f}, gap={evals[1]-E0:.6f}")
        print()
        shown += 1

    # ============================================================
    # Q5: p_S = 0 或 1/2 的 s 值可否由图不变量解析预测？
    # ============================================================
    print("\n" + "=" * 100)
    print("Q5. p_S = 0 或 1/2 的 s 值可否由图不变量预测？")
    print("=" * 100)

    # 对每个图，输出 s(p_S=0) 和 s(p_S=1/2) 与图不变量的关系
    print(f"\n  {'gid':>4} | {'defect':>8} | {'s(p_S=0)':>12} | {'s(p_S=1/2)':>12} | {'边数':>4} | {'桥数':>4} | {'L1':>8} | {'defect度':>10} | {'L1/度和':>10}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*12}-+-{'-'*12}-+-{'-'*4}-+-{'-'*4}-+-{'-'*8}-+-{'-'*10}-+-{'-'*10}")
    data_by_graph = defaultdict(list)
    for (gid, defect) in sorted(pS_cache.keys()):
        G = graphs[gid]
        L = nx.laplacian_matrix(G).astype(float).toarray()
        L1 = sorted(np.linalg.eigvalsh(L))[1]
        degs = G.degree(defect[0]) + G.degree(defect[1])
        curve = np.array(pS_cache[(gid, defect)]["p_S"])
        # 找 p_S 最接近 0 和 1/2 的 s
        s_at_0, pS_0, _ = find_resonance_s(curve, s_vals, 0.0)
        s_at_half, pS_half, _ = find_resonance_s(curve, s_vals, 0.5)
        n_bridges = len(list(nx.bridges(G)))
        print(f"  {gid:>4} | {str(defect):>8} | {s_at_0:>12.2f} | "
              f"{s_at_half:>12.2f} | {len(list(G.edges())):>4} | "
              f"{n_bridges:>4} | {L1:>8.4f} | {degs:>10} | {L1/degs:>10.4f}")
        data_by_graph[gid].append({
            "defect": defect, "s_at_0": s_at_0, "pS_0": pS_0,
            "s_at_half": s_at_half, "pS_half": pS_half,
            "n_edges": len(list(G.edges())),
            "n_bridges": n_bridges, "L1": L1, "deg_sum": degs,
            "L1_over_deg": L1/degs,
        })

    # 统计：如果 p_S 精确等于 0，s 值是否有解析形式？
    print(f"\n  --- p_S = 0 处的 s 值及其代数识别 ---")
    s_at_0_vals = set()
    for gid, items in data_by_graph.items():
        for it in items:
            if it["pS_0"] < 1e-6:
                s_at_0_vals.add(round(it["s_at_0"], 2))
    print(f"  出现过的 s(p_S=0) 值: {sorted(s_at_0_vals)}")

    print(f"\n  --- p_S = 1/2 处的 s 值及其代数识别 ---")
    s_at_half_vals = set()
    for gid, items in data_by_graph.items():
        for it in items:
            if abs(it["pS_half"] - 0.5) < 1e-6:
                s_at_half_vals.add(round(it["s_at_half"], 2))
    print(f"  出现过的 s(p_S=1/2) 值: {sorted(s_at_half_vals)}")

    # 关联性分析：s(p_S=1/2) vs L1, 边数, 桥数
    print(f"\n  --- 相关性分析：s(p_S=1/2) vs 图不变量 ---")
    s_half_list = []
    L1_list = []
    n_edges_list = []
    n_bridges_list = []
    deg_sum_list = []
    for gid, items in data_by_graph.items():
        for it in items:
            if abs(it["pS_half"] - 0.5) < 1e-6:
                s_half_list.append(it["s_at_half"])
                L1_list.append(it["L1"])
                n_edges_list.append(it["n_edges"])
                n_bridges_list.append(it["n_bridges"])
                deg_sum_list.append(it["deg_sum"])
    if len(s_half_list) >= 3:
        s_half = np.array(s_half_list)
        for name, vals in [("L1", L1_list), ("n_edges", n_edges_list),
                           ("n_bridges", n_bridges_list),
                           ("deg_sum", deg_sum_list)]:
            corr = np.corrcoef(s_half, np.array(vals))[0,1]
            print(f"    corr(s, {name:>10}) = {corr:>8.4f}")

    # ============================================================
    # 深度追问：p_S = 0 的边是不是"因子分解边"？
    # ============================================================
    print("\n" + "=" * 100)
    print("深度追问：p_S = 0 的边是不是'因子分解边'？")
    print("=" * 100)

    # 假设：p_S = 0 意味着缺陷边两端是"因子分解"的——它们不属于同一单态
    # 检验：p_S = 0 的缺陷边，其两端是否属于图的不同二分子图？
    # 或者：缺陷边是否为桥？

    print(f"\n  {'gid':>4} | {'defect':>8} | {'s(p_S=0)':>12} | {'桥?':>6} | {'割点?':>6} | {'边两端距离':>10}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*12}-+-{'-'*6}-+-{'-'*6}-+-{'-'*10}")
    for gid, items in sorted(data_by_graph.items()):
        G = graphs[gid]
        bridges = set(map(frozenset, nx.bridges(G)))
        for it in items:
            defect = it["defect"]
            if it["pS_0"] < 1e-6:
                is_bridge = frozenset(defect) in bridges
                # 检查是否是割点对
                G_copy = G.copy()
                G_copy.remove_node(defect[0])
                is_cut_a = not nx.is_connected(G_copy) if G_copy.number_of_nodes() > 0 else False
                G_copy2 = G.copy()
                G_copy2.remove_node(defect[1])
                is_cut_b = not nx.is_connected(G_copy2) if G_copy2.number_of_nodes() > 0 else False
                print(f"  {gid:>4} | {str(defect):>8} | {it['s_at_0']:>12.2f} | "
                      f"{str(is_bridge):>6} | {str(is_cut_a or is_cut_b):>6} | {'—':>10}")

    # ============================================================
    # 深度追问 2：p_S = 0 时基态是否因子分解？
    # ============================================================
    print("\n" + "=" * 100)
    print("深度追问 2：p_S = 0 时基态是否因子分解为两个单态？")
    print("=" * 100)

    # 假设：p_S = 0 意味着缺陷边断开后，两侧各自形成单态基态
    # 检验：在 s = s(p_S=0) 处，缺陷边断开（耦合 = 0），两侧基态总自旋
    print(f"\n  {'gid':>4} | {'defect':>8} | {'s(p_S=0)':>10} | {'断开后两侧基态自旋 S1, S2':>30}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*10}-+-{'-'*30}")

    def spin_squared(G_sub, SXo_sub, SYo_sub, SZo_sub, N_sub):
        """计算子图基态的总自旋 S(S+1)"""
        edges = [tuple(sorted(e)) for e in G_sub.edges()]
        if len(edges) == 0:
            return 0.0
        H = sum(edge_matrix(e[0], e[1], SXo_sub, SYo_sub, SZo_sub) for e in edges)
        E0, deg, V, _ = ground_state_all(H)
        # 总自旋算符 S² = sum_i,j S_i·S_j / 4（注意 σ 归一化）
        # 简化：用 ⟨S²⟩ = (3/4)N + (1/2)∑⟨σ_i·σ_j⟩/... 直接用算符
        dim = 2**N_sub
        S2_op = np.zeros((dim, dim), dtype=complex)
        for i in range(N_sub):
            for j in range(N_sub):
                if i == j:
                    S2_op += 3/4 * np.eye(dim, dtype=complex)
                else:
                    S2_op += 1/4 * (SXo_sub[i]@SXo_sub[j] +
                                     SYo_sub[i]@SYo_sub[j] +
                                     SZo_sub[i]@SZo_sub[j])
        rho = V @ V.conj().T / deg
        S2_val = float(np.real(np.trace(rho @ S2_op)))
        S_val = (-1 + np.sqrt(1 + 4*S2_val))/2
        return S_val

    for gid, items in sorted(data_by_graph.items()):
        G = graphs[gid]
        for it in items:
            if it["pS_0"] >= 1e-6:
                continue
            defect = it["defect"]
            # 断开缺陷边
            G_broken = G.copy()
            G_broken.remove_edge(*defect)
            comps = list(nx.connected_components(G_broken))
            if len(comps) != 2:
                continue
            # 对每个分量单独计算基态总自旋
            spin_info = []
            for comp in comps:
                nodes = sorted(comp)
                sub = G_broken.subgraph(nodes)
                n_sub = len(nodes)
                # 重标记节点
                sub = nx.convert_node_labels_to_integers(sub)
                SX_sub, SY_sub, SZ_sub = build_site_ops(n_sub)
                S_val = spin_squared(sub, SX_sub, SY_sub, SZ_sub, n_sub)
                spin_info.append((n_sub, round(S_val, 4)))
            print(f"  {gid:>4} | {str(defect):>8} | {it['s_at_0']:>10.2f} | {spin_info}")

    # ============================================================
    # 导出
    # ============================================================
    out = {
        "zero_hits": [{"gid": g, "defect": list(d), "s": s, "p_S": pS}
                      for g, d, s, pS in zero_hits],
        "half_hits": [{"gid": g, "defect": list(d), "s": s, "p_S": pS}
                      for g, d, s, pS in half_hits],
        "pS_curves": {
            f"{gid}_{defect}": {
                "s": pS_cache[(gid, defect)]["s"],
                "p_S": pS_cache[(gid, defect)]["p_S"],
            } for (gid, defect) in pS_cache
        },
    }
    out_path = os.path.join(WORK_DIR, "照妖镜_v8_谐振条件.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("v8.0 完成。p_S = 0 和 p_S = 1/2 的条件被攻击。")
    print("=" * 100)


if __name__ == "__main__":
    main()