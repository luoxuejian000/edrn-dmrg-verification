#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜协议 v5.1：击中要害

不再只数 24 组合的对数，而是给每对画一张 24 位响应模式。

核心数据结构：
  pattern[(gid, e1, e2)] = 24 位布尔串
  每一位对应一个截断组合：(空间, 诊断量, 窗口)

要害输出：
  1. 模式分布：哪些对在哪些截断下同响应
  2. 按模式分组，特征解剖
  3. 边际贡献：去掉某个截断，多少对消失
  4. 三变量分离：换诊断量/换窗口/换空间，各自影响哪几对
"""

import sys, io, itertools, json, os
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from collections import Counter, defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"
N = 6
TOL = 1e-10

I2 = np.eye(2, dtype=complex)
SX = np.array([[0,1],[1,0]], dtype=complex)
SY = np.array([[0,-1j],[1j,0]], dtype=complex)
SZ = np.array([[1,0],[0,-1]], dtype=complex)


def op_on_site(op, site, N):
    ops = [I2]*N; ops[site] = op
    out = ops[0]
    for o in ops[1:]: out = np.kron(out, o)
    return out


def build_site_ops(N):
    return ([op_on_site(SX,i,N) for i in range(N)],
            [op_on_site(SY,i,N) for i in range(N)],
            [op_on_site(SZ,i,N) for i in range(N)])


def edge_matrix(i, j, SXo, SYo, SZo):
    return SXo[i]@SXo[j] + SYo[i]@SYo[j] + SZo[i]@SZo[j]


def sz0_basis(N):
    basis = []
    for comb in itertools.combinations(range(N), N//2):
        s = [0]*N
        for i in comb: s[i] = 1
        basis.append(tuple(s))
    return basis


def build_H_sz0(N, edges, couplings):
    basis = sz0_basis(N)
    dim = len(basis); idx = {s:i for i,s in enumerate(basis)}
    H = np.zeros((dim, dim))
    for i, state in enumerate(basis):
        for (a,b), J in zip(edges, couplings):
            if state[a] == state[b]:
                H[i,i] += J
            else:
                H[i,i] -= J
                new = list(state); new[a], new[b] = new[b], new[a]
                H[i, idx[tuple(new)]] += 2.0*J
    return H


def gs_rho(H, tol=1e-8):
    evals, evecs = eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < tol))
    V = evecs[:, :deg]
    return V @ V.conj().T / deg


def find_automorphisms(G):
    nodes = list(G.nodes())
    adj = nx.to_numpy_array(G)
    perms = []
    for p in itertools.permutations(nodes):
        P = np.zeros((len(nodes), len(nodes)))
        for i, pi in enumerate(p): P[i, pi] = 1
        if np.allclose(P @ adj @ P.T, adj): perms.append(p)
    return perms


def find_edge_orbits(G):
    nodes = list(G.nodes())
    edges = [tuple(sorted(e)) for e in G.edges()]
    perms = find_automorphisms(G)
    orbit_id = {e: None for e in edges}
    oid = 0
    for e in edges:
        if orbit_id[e] is not None: continue
        orbit_id[e] = oid
        for p in perms:
            m = {nodes[i]: p[i] for i in range(len(nodes))}
            e2 = tuple(sorted((m[e[0]], m[e[1]])))
            if G.has_edge(*e2): orbit_id[e2] = oid
        oid += 1
    return orbit_id


# ============================================================
# 一次算，多次用：预计算所有关联函数
# ============================================================

def precompute_correlations(graphs, s_vals_max, SXo, SYo, SZo):
    """
    cache[space][gid][defect] = array (n_s, n_edges)
    """
    cache = {"full": {}, "sz0": {}}
    basis_sz0 = sz0_basis(N)
    sz_config_sz0 = np.array([[1.0 if st[i]==1 else -1.0
                               for i in range(N)] for st in basis_sz0])

    for gid, G in enumerate(graphs):
        edges = [tuple(sorted(e)) for e in G.edges()]
        n_e = len(edges)
        H_edges_full = [edge_matrix(e[0], e[1], SXo, SYo, SZo) for e in edges]
        SZ_ops_pairs = [(SZo[e[0]], SZo[e[1]]) for e in edges]

        cache["full"][gid] = {}
        cache["sz0"][gid] = {}
        for defect in edges:
            corr_full = np.zeros((len(s_vals_max), n_e))
            corr_sz0 = np.zeros((len(s_vals_max), n_e))
            for si, s in enumerate(s_vals_max):
                couplings = [s if e == defect else 1.0 for e in edges]
                # full
                H_full = sum(c*M for c, M in zip(couplings, H_edges_full))
                rho_full = gs_rho(H_full)
                for k, (Za, Zb) in enumerate(SZ_ops_pairs):
                    corr_full[si, k] = float(np.real(
                        np.trace(rho_full @ (Za @ Zb))))
                # sz0
                H_sz0 = build_H_sz0(N, edges, couplings)
                rho_sz0 = gs_rho(H_sz0)
                rho_diag = np.diag(rho_sz0).real
                for k, e in enumerate(edges):
                    corr_sz0[si, k] = float(np.sum(
                        rho_diag * sz_config_sz0[:, e[0]] * sz_config_sz0[:, e[1]]))
            cache["full"][gid][defect] = corr_full
            cache["sz0"][gid][defect] = corr_sz0

    return cache


# ============================================================
# 诊断量
# ============================================================

def apply_diagnostic(corr, mode):
    """corr: (n_s, n_e)"""
    if mode == "vector":
        return tuple(tuple(np.round(sorted(row), 12)) for row in corr)
    if mode == "std":
        return tuple(float(np.std(row)) for row in corr)
    if mode == "range":
        return tuple(float(np.max(row) - np.min(row)) for row in corr)
    if mode == "entropy":
        out = []
        for row in corr:
            r = row - row.min()
            if r.max() > 1e-12:
                r = r / r.max()
                p = r / r.sum()
                p = p[p > 1e-12]
                out.append(float(-np.sum(p * np.log(p))))
            else:
                out.append(0.0)
        return tuple(out)
    return None


def curves_equal(c1, c2, tol=TOL):
    if len(c1) != len(c2): return False
    for a, b in zip(c1, c2):
        if isinstance(a, tuple):
            if len(a) != len(b): return False
            if not np.allclose(a, b, atol=tol): return False
        else:
            if abs(a - b) > tol: return False
    return True


def pair_features(G, e1, e2, orbits):
    n1a, n1b = e1; n2a, n2b = e2
    s1, s2 = {n1a, n1b}, {n2a, n2b}
    inter = (set(G.neighbors(n1a)) | set(G.neighbors(n1b))) & \
            (set(G.neighbors(n2a)) | set(G.neighbors(n2b)))
    union = (set(G.neighbors(n1a)) | set(G.neighbors(n1b))) | \
            (set(G.neighbors(n2a)) | set(G.neighbors(n2b)))
    orbit_size = Counter(orbits.values())
    try:
        dist = nx.shortest_path_length(G, n1a, n2a)
    except Exception:
        dist = -1
    return {
        "share_endpoint": len(s1 & s2) > 0,
        "edge_distance": dist,
        "common_neighbors": len(inter),
        "neighbor_jaccard": round(len(inter) / len(union), 3) if union else 0.0,
        "orbit_size_sym": orbit_size[orbits[e1]] == orbit_size[orbits[e2]],
    }


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 100)
    print("照妖镜协议 v5.1：击中要害")
    print("给每对画一张 24 位响应模式，机制藏在轨迹里")
    print("=" * 100)

    # 图集
    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    print(f"\n  图集: {len(graphs)} 个 N=6 连通图")

    all_orbits = {gid: find_edge_orbits(G) for gid, G in enumerate(graphs)}
    all_edges = {gid: [tuple(sorted(e)) for e in G.edges()]
                 for gid, G in enumerate(graphs)}

    # 全局异轨道对清单（不管同不同）
    all_pairs = []
    pair_meta = {}
    for gid, G in enumerate(graphs):
        edges = all_edges[gid]
        orbits = all_orbits[gid]
        for i, e1 in enumerate(edges):
            for j in range(i+1, len(edges)):
                e2 = edges[j]
                if orbits[e1] == orbits[e2]: continue
                key = (gid, e1, e2)
                all_pairs.append(key)
                pair_meta[key] = pair_features(G, e1, e2, orbits)
    print(f"  总异轨道对: {len(all_pairs)}")

    # 预计算
    SXo, SYo, SZo = build_site_ops(N)
    max_grid = np.linspace(-4.0, 4.0, 181)  # 最大网格，覆盖所有窗口
    print(f"\n  预计算所有关联函数（{len(max_grid)} 点 × 2 空间）…")
    cache = precompute_correlations(graphs, max_grid, SXo, SYo, SZo)
    print(f"  预计算完成")

    # 定义 24 组合
    windows = {
        "W1": (-1.5, 0.0),
        "W2": (-3.0, 3.0),
        "W3": (-4.0, 4.0),
    }
    diagnostics = ["vector", "std", "range", "entropy"]
    spaces = ["full", "sz0"]

    combo_keys = []
    for space in spaces:
        for diag in diagnostics:
            for wn in windows:
                combo_keys.append((space, diag, wn))
    print(f"\n  组合数: {len(combo_keys)}")

    # 对每个组合，计算它在每对上的判定
    # 关键：pattern[key] = tuple of 24 bools
    print(f"\n  计算 24 组合 × {len(all_pairs)} 对 的响应模式…")
    patterns = {k: [] for k in all_pairs}

    for ci, (space, diag, wn) in enumerate(combo_keys):
        lo, hi = windows[wn]
        # 找出 max_grid 上的窗口切片
        s_idx = np.where((max_grid >= lo - 1e-9) & (max_grid <= hi + 1e-9))[0]
        if len(s_idx) < 5:
            for k in all_pairs:
                patterns[k].append(False)
            continue

        # 对每个 gid，先算每条边的诊断曲线
        gid_curves = {}
        for gid in range(len(graphs)):
            edges = all_edges[gid]
            curves = {}
            for e in edges:
                corr = cache[space][gid][e][s_idx, :]
                curves[e] = apply_diagnostic(corr, diag)
            gid_curves[gid] = curves

        # 判定每对
        for (gid, e1, e2) in all_pairs:
            same = curves_equal(gid_curves[gid][e1], gid_curves[gid][e2])
            patterns[(gid, e1, e2)].append(same)

        print(f"    [{ci+1:>2}/24] {space:>4}/{diag:>7}/{wn}: "
              f"{sum(1 for k in all_pairs if patterns[k][-1])} 对")

    # ============================================================
    # 输出 1：24 组合并排
    # ============================================================
    print("\n" + "=" * 100)
    print("输出 1：24 组合并排")
    print("=" * 100)
    print(f"\n  {'组合':>4} | {'空间':>4} | {'诊断量':>7} | {'窗口':>6} | {'对数':>5}")
    print(f"  {'-'*4}-+-{'-'*4}-+-{'-'*7}-+-{'-'*6}-+-{'-'*5}")
    for ci, (space, diag, wn) in enumerate(combo_keys):
        n = sum(1 for k in all_pairs if patterns[k][ci])
        print(f"  {ci:>4} | {space:>4} | {diag:>7} | {wn:>6} | {n:>5}")

    # ============================================================
    # 输出 2：响应模式分组（核心）
    # ============================================================
    print("\n" + "=" * 100)
    print("输出 2：响应模式分组（核心）")
    print("=" * 100)

    mode_groups = defaultdict(list)
    for k in all_pairs:
        mode = tuple(patterns[k])
        if any(mode):
            mode_groups[mode].append(k)

    print(f"\n  非全零模式数: {len(mode_groups)}")
    print(f"  按包含对数排序：\n")

    # 排序：按模式中 True 的个数
    sorted_modes = sorted(mode_groups.items(),
                          key=lambda x: (-sum(x[0]), -len(x[1])))

    for mode, pairs in sorted_modes:
        n_true = sum(mode)
        if n_true < 1: continue
        # 模式串
        s = "".join("1" if b else "0" for b in mode)
        print(f"\n  模式 [{s}]  ({n_true} 位真, {len(pairs)} 对)")
        # 这组的特征分布
        feats = [pair_meta[k] for k in pairs]
        for fname in ["share_endpoint", "edge_distance", "neighbor_jaccard",
                      "orbit_size_sym"]:
            values = [f[fname] for f in feats]
            cnt = Counter(values)
            top = sorted(cnt.items(), key=lambda x: -x[1])[:5]
            line = ", ".join(f"{v}:{c}" for v, c in top)
            print(f"    {fname:>18}: {line}")
        # 图分布
        gid_cnt = Counter(k[0] for k in pairs)
        print(f"    {'graph_id':>18}: {dict(gid_cnt.most_common(8))}")
        # 如果对数不太多，列出来
        if len(pairs) <= 15:
            for k in sorted(pairs):
                gid, e1, e2 = k
                print(f"      {gid}: {e1} - {e2}")

    # ============================================================
    # 输出 3：边际贡献（去掉一个组合，多少对消失）
    # ============================================================
    print("\n" + "=" * 100)
    print("输出 3：边际贡献（该组合去掉后，总体并集缩小多少）")
    print("=" * 100)

    all_union = set(k for k in all_pairs if any(patterns[k]))
    print(f"\n  并集总对数: {len(all_union)}")

    print(f"\n  {'组合':>4} | {'空间':>4} | {'诊断量':>7} | {'窗口':>6} | {'独有':>5} | {'边际丢':>6}")
    print(f"  {'-'*4}-+-{'-'*4}-+-{'-'*7}-+-{'-'*6}-+-{'-'*5}-+-{'-'*6}")
    for ci, (space, diag, wn) in enumerate(combo_keys):
        # 独有：只在组合 ci 里为 True
        unique = [k for k in all_union
                  if patterns[k][ci] and sum(patterns[k]) == 1]
        # 边际：去掉 ci 后并集缩小的部分
        others = set()
        for k in all_union:
            if any(patterns[k][j] for j in range(len(combo_keys)) if j != ci):
                others.add(k)
        lost = len(all_union) - len(others)
        print(f"  {ci:>4} | {space:>4} | {diag:>7} | {wn:>6} | {len(unique):>5} | {lost:>6}")

    # ============================================================
    # 输出 4：三变量分离
    # ============================================================
    print("\n" + "=" * 100)
    print("输出 4：三变量分离——单独换一个变量，对集怎么变")
    print("=" * 100)

    def find_key(space, diag, wn):
        for ci, (s, d, w) in enumerate(combo_keys):
            if s == space and d == diag and w == wn:
                return ci
        return None

    def pairs_at(ci):
        return set(k for k in all_union if patterns[k][ci])

    # 基准组合
    ref_space, ref_diag, ref_wn = "full", "vector", "W1"

    print(f"\n  基准: {ref_space}/{ref_diag}/{ref_wn}")
    ref_ci = find_key(ref_space, ref_diag, ref_wn)
    ref_set = pairs_at(ref_ci)
    print(f"  → {len(ref_set)} 对")

    print(f"\n  --- 只换诊断量 ---")
    for diag in diagnostics:
        ci = find_key(ref_space, diag, ref_wn)
        s = pairs_at(ci)
        added = s - ref_set
        lost = ref_set - s
        print(f"    {diag:>7}: {len(s)} 对，"
              f"比基准多 {len(added)}，少 {len(lost)}")

    print(f"\n  --- 只换窗口 ---")
    for wn in windows:
        ci = find_key(ref_space, ref_diag, wn)
        s = pairs_at(ci)
        added = s - ref_set
        lost = ref_set - s
        print(f"    {wn:>3}: {len(s)} 对，"
              f"比基准多 {len(added)}，少 {len(lost)}")

    print(f"\n  --- 只换空间 ---")
    for space in spaces:
        ci = find_key(space, ref_diag, ref_wn)
        s = pairs_at(ci)
        added = s - ref_set
        lost = ref_set - s
        print(f"    {space:>4}: {len(s)} 对，"
              f"比基准多 {len(added)}，少 {len(lost)}")

    # ============================================================
    # 输出 5：硬核（所有 24 组合都同响应的对）
    # ============================================================
    print("\n" + "=" * 100)
    print("输出 5：硬核（所有 24 组合都同响应的对）")
    print("=" * 100)
    hard_core = [k for k in all_pairs if all(patterns[k])]
    print(f"\n  硬核对数: {len(hard_core)}")
    if hard_core:
        print(f"\n  {'gid':>4} | {'e1':>8} | {'e2':>8} | {'share':>6} | {'dist':>4} | {'jacc':>6} | {'orbit_sym':>9}")
        print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*8}-+-{'-'*6}-+-{'-'*4}-+-{'-'*6}-+-{'-'*9}")
        for k in sorted(hard_core):
            f = pair_meta[k]
            gid, e1, e2 = k
            print(f"  {gid:>4} | {str(e1):>8} | {str(e2):>8} | "
                  f"{str(f['share_endpoint']):>6} | {f['edge_distance']:>4} | "
                  f"{f['neighbor_jaccard']:>6} | {str(f['orbit_size_sym']):>9}")

    # ============================================================
    # 导出
    # ============================================================
    out = {
        "combo_keys": [list(k) for k in combo_keys],
        "combo_counts": {str(ci): sum(1 for k in all_pairs if patterns[k][ci])
                         for ci in range(len(combo_keys))},
        "patterns": {
            f"{k[0]}_{k[1]}_{k[2]}": "".join("1" if b else "0" for b in patterns[k])
            for k in all_pairs if any(patterns[k])
        },
        "hard_core": [{"gid": g, "e1": list(e1), "e2": list(e2)}
                      for g, e1, e2 in hard_core],
    }
    out_path = os.path.join(WORK_DIR, "照妖镜_v5_1_模式.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("v5.1 完成。每对 24 位模式已画出。机制藏在轨迹里。")
    print("=" * 100)


if __name__ == "__main__":
    main()