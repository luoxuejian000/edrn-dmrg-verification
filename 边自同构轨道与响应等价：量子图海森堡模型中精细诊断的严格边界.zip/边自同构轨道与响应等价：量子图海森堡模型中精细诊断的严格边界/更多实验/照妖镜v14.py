#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 v14.0：跨尺度谐振谱离散性
================================================================

核心问题：
  N=6 谐振 s 谱：11 个唯一值，75% 是 0.5 倍数，82% 可代数识别 → 离散
  N=7 谐振 s 谱：4172 个唯一值，0.2% 是 0.5 倍数，1% 可识别 → 连续
  N=8 谐振 s 谱：？

五个追问并行：
  Q1. 自同构群大小在 N=6 / N=7 / N=8 的分布
  Q2. 边数与谐振点数的关系
  Q3. N=8 抽样（~100 图）的谐振 s 谱离散性
  Q4. N=6 特殊图（贡献谐振的 8 个图）的共同属性
  Q5. 离散性度量：代数识别率随 N 的衰减

晶脉哲学：
  · 关系本体论：自同构群是关系网络对称性的全局刻画
  · 对象化=截断=产生方向：每个图的对称性都是一次截断
  · 只查同与不同：不筛选，不排序
  · 反对对齐：不预设结论
"""

import sys, io, itertools, json, os, random
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from scipy.optimize import brentq
from collections import Counter, defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"


# ============================================================
# S_z=0 扇区构建
# ============================================================

def build_sz0_sector(N):
    n_up = N // 2
    basis = []
    for comb in itertools.combinations(range(N), n_up):
        state = [0]*N
        for i in comb: state[i] = 1
        basis.append(tuple(state))
    dim = len(basis)
    idx = {s: i for i, s in enumerate(basis)}
    SZ_ops = []
    for site in range(N):
        SZ = np.zeros((dim, dim), dtype=complex)
        for i, state in enumerate(basis):
            SZ[i, i] = 1 if state[site] == 1 else -1
        SZ_ops.append(SZ)
    return basis, idx, SZ_ops


def build_edge_op(i, j, basis, idx):
    dim = len(basis)
    op = np.zeros((dim, dim), dtype=complex)
    for a_idx, state_a in enumerate(basis):
        sa, sb = state_a[i], state_a[j]
        if sa == sb:
            op[a_idx, a_idx] += 1
        else:
            op[a_idx, a_idx] += -1
            new_state = list(state_a)
            new_state[i], new_state[j] = new_state[j], new_state[i]
            b_idx = idx.get(tuple(new_state))
            if b_idx is not None:
                op[b_idx, a_idx] += 2
    return op


# ============================================================
# p_S 计算
# ============================================================

def pS_at_s(edge_ops, defect, s, SZ_ops, ref_dim):
    H = np.zeros((ref_dim, ref_dim), dtype=complex)
    for e, M in edge_ops.items():
        c = s if e == defect else 1.0
        H += c * M
    try:
        evals, evecs = eigh(H)
    except Exception:
        return None, None
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < 1e-8))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    i, j = defect
    szsz_diag = np.diag(SZ_ops[i] @ SZ_ops[j])
    szsz = float(np.real(np.sum(np.diag(rho) * szsz_diag)))
    p_S = (1 - 3 * szsz) / 4
    return p_S, deg


def find_resonance_s(edge_ops, defect, SZ_ops, ref_dim,
                     s_lo=-2.0, s_hi=2.0, n_grid=41):
    s_grid = np.linspace(s_lo, s_hi, n_grid)
    pS_vals = np.array([pS_at_s(edge_ops, defect, s, SZ_ops, ref_dim)[0]
                        or 0.0 for s in s_grid])
    crossings = []
    for k in range(len(s_grid) - 1):
        if (pS_vals[k] - 0.5) * (pS_vals[k+1] - 0.5) < 0:
            try:
                s_res = brentq(
                    lambda s: pS_at_s(edge_ops, defect, s, SZ_ops, ref_dim)[0] - 0.5,
                    s_grid[k], s_grid[k+1], xtol=1e-10)
                crossings.append(s_res)
            except Exception:
                pass
    return crossings


# ============================================================
# 代数识别（快速版）
# ============================================================

def identify_algebraic(s, tol=1e-6):
    """快速代数识别：0.5 倍数 / 有理数 / 二次代数数"""
    if abs(s) < 1e-9: return "0.5"
    if abs(s - round(s*2)/2) < 1e-9: return "0.5"
    for q in [2,3,4,5,6,7,8,10,12]:
        p = round(s * q)
        if abs(s - p/q) < tol:
            return "rational"
    # 二次：a·s² + b·s + c = 0，小整数
    for a in range(1, 8):
        for b in range(-12, 13):
            for c in range(-12, 13):
                if abs(a*s*s + b*s + c) < tol:
                    return "quadratic"
    return "unidentified"


# ============================================================
# 图集构建
# ============================================================

def build_atlas_graphs(N):
    """从 atlas 加载 N 个节点的连通图"""
    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    return graphs


def build_N8_samples(n_samples=100, seed=42):
    """生成 N=8 的随机连通图样本"""
    random.seed(seed)
    np.random.seed(seed)
    graphs = []

    # 策略 1：K8 减边（对称图）
    K8 = nx.complete_graph(8)
    K8_edges = list(K8.edges())
    for n_remove in [2, 3, 4, 5]:
        for _ in range(n_samples // 20):
            removed = random.sample(K8_edges, n_remove)
            G = K8.copy()
            G.remove_edges_from(removed)
            if nx.is_connected(G):
                graphs.append(G)

    # 策略 2：ER 随机图
    for p in [0.3, 0.4, 0.5, 0.6, 0.7]:
        for _ in range(n_samples // 10):
            G = nx.gnp_random_graph(8, p, seed=random.randint(0, 10**6))
            if nx.is_connected(G):
                graphs.append(G)

    # 策略 3：随机正则图
    for d in [2, 3, 4, 5]:
        for _ in range(n_samples // 20):
            try:
                G = nx.random_regular_graph(d, 8, seed=random.randint(0, 10**6))
                if nx.is_connected(G):
                    graphs.append(G)
            except Exception:
                pass

    # 策略 4：环+随机长程边
    for _ in range(n_samples // 20):
        G = nx.cycle_graph(8)
        extra = random.sample([(i, j) for i in range(8) for j in range(i+1, 8)
                               if not G.has_edge(i, j)], 3)
        G.add_edges_from(extra)
        if nx.is_connected(G):
            graphs.append(G)

    # 去重
    unique = []
    for G in graphs:
        if not any(nx.is_isomorphic(G, H) for H in unique):
            unique.append(G)
    return unique[:n_samples]


# ============================================================
# 自同构群大小（限制迭代次数）
# ============================================================

def count_automorphisms(G, max_count=10000):
    """计算 |Aut(G)|，超过 max_count 就提前停止"""
    GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
    count = 0
    for _ in GM.isomorphisms_iter():
        count += 1
        if count >= max_count:
            return f">{max_count}"
    return count


# ============================================================
# Q1: 自同构群大小分布
# ============================================================

def q1_automorphism_sizes(graphs_dict):
    print("\n" + "=" * 100)
    print("Q1. 自同构群大小分布（跨 N）")
    print("=" * 100)

    all_aut = {}
    for N, graphs in graphs_dict.items():
        aut_sizes = []
        for G in graphs:
            n = count_automorphisms(G, max_count=5000)
            aut_sizes.append(n)
        all_aut[N] = aut_sizes

        # 统计（排除 >5000 的大值）
        finite = [a for a in aut_sizes if isinstance(a, int)]
        print(f"\n  N={N} ({len(graphs)} 图):")
        print(f"    |Aut| 中位数: {np.median(finite):.0f}")
        print(f"    |Aut| 均值: {np.mean(finite):.1f}")
        print(f"    |Aut| 最大: {max(finite) if finite else 'N/A'}")
        print(f"    |Aut| > 5000 的图数: {len(aut_sizes) - len(finite)}")
        # 直方图
        cnt = Counter(finite)
        top = sorted(cnt.items(), key=lambda x: -x[1])[:8]
        print(f"    最常见 |Aut|: {top}")

    return all_aut


# ============================================================
# Q2: 边数与谐振点数
# ============================================================

def q2_edges_vs_resonances(graphs_dict, max_edges_per_graph=4):
    print("\n" + "=" * 100)
    print("Q2. 边数 vs 谐振点数（跨 N）")
    print("=" * 100)

    results = {}
    for N, graphs in graphs_dict.items():
        basis, idx, SZ_ops = build_sz0_sector(N)
        ref_dim = len(basis)
        print(f"\n  N={N} (S_z=0 扇区维度 = {ref_dim})")

        edge_to_res = defaultdict(int)
        edge_to_unique = defaultdict(set)

        for G in graphs:
            edges = [tuple(sorted(e)) for e in G.edges()]
            edge_ops = {e: build_edge_op(e[0], e[1], basis, idx) for e in edges}
            n_e = len(edges)
            sample_edges = edges[:max_edges_per_graph]
            for defect in sample_edges:
                crossings = find_resonance_s(edge_ops, defect, SZ_ops, ref_dim)
                for s in crossings:
                    edge_to_res[n_e] += 1
                    edge_to_unique[n_e].add(round(s, 6))

        print(f"    {'边数':>4} | {'谐振点':>6} | {'唯一 s':>6} | {'代数率':>8}")
        print(f"    {'-'*4}-+-{'-'*6}-+-{'-'*6}-+-{'-'*8}")
        total_res = 0
        total_id = 0
        for n_e in sorted(edge_to_res.keys()):
            n_res = edge_to_res[n_e]
            n_uniq = len(edge_to_unique[n_e])
            # 代数识别
            n_id = sum(1 for s in edge_to_unique[n_e]
                       if identify_algebraic(s) != "unidentified")
            rate = n_id / n_uniq if n_uniq > 0 else 0
            print(f"    {n_e:>4} | {n_res:>6} | {n_uniq:>6} | {rate:>7.1%}")
            total_res += n_uniq
            total_id += n_id
        rate = total_id / total_res if total_res > 0 else 0
        print(f"    整体代数识别率: {total_id}/{total_res} = {rate:.1%}")
        results[N] = {"total": total_res, "identified": total_id, "rate": rate}

    return results


# ============================================================
# Q3: N=8 抽样谐振谱
# ============================================================

def q3_N8_sampling(graphs, max_edges_per_graph=4):
    print("\n" + "=" * 100)
    print("Q3. N=8 抽样谐振谱离散性")
    print("=" * 100)

    N = 8
    basis, idx, SZ_ops = build_sz0_sector(N)
    ref_dim = len(basis)
    print(f"  S_z=0 扇区维度: {ref_dim}")
    print(f"  抽样图数: {len(graphs)}")

    all_s_values = []
    all_aut = []

    for gi, G in enumerate(graphs):
        if gi % 20 == 0:
            print(f"    处理 {gi}/{len(graphs)}")
        edges = [tuple(sorted(e)) for e in G.edges()]
        edge_ops = {e: build_edge_op(e[0], e[1], basis, idx) for e in edges}
        sample_edges = edges[:max_edges_per_graph]
        for defect in sample_edges:
            crossings = find_resonance_s(edge_ops, defect, SZ_ops, ref_dim)
            for s in crossings:
                all_s_values.append(s)
        all_aut.append(count_automorphisms(G, max_count=5000))

    print(f"\n  总谐振点数: {len(all_s_values)}")
    if not all_s_values:
        print("  未找到谐振点")
        return

    # 唯一 s 值
    unique_s = sorted(set(round(s, 6) for s in all_s_values))
    print(f"  唯一 s 值数: {len(unique_s)}")

    # 0.5 倍数
    n_half = sum(1 for s in unique_s if abs(s - round(s*2)/2) < 1e-6)
    print(f"  0.5 倍数: {n_half}/{len(unique_s)} = {n_half/len(unique_s):.1%}")

    # 代数识别
    cats = Counter()
    for s in unique_s:
        cats[identify_algebraic(s)] += 1
    print(f"\n  代数识别分布:")
    for cat, cnt in cats.most_common():
        print(f"    {cat:<15}: {cnt:>6} ({cnt/len(unique_s):>6.1%})")

    # 离散性度量
    discrete_rate = (cats["0.5"] + cats["rational"] + cats["quadratic"]) / len(unique_s)
    print(f"\n  离散性度量（代数识别率）= {discrete_rate:.1%}")

    # 自同构分布
    finite_aut = [a for a in all_aut if isinstance(a, int)]
    if finite_aut:
        print(f"\n  样本自同构群大小:")
        print(f"    中位数: {np.median(finite_aut):.0f}")
        print(f"    均值: {np.mean(finite_aut):.1f}")
        print(f"    最大: {max(finite_aut)}")

    return {
        "n_resonances": len(all_s_values),
        "n_unique": len(unique_s),
        "n_half": n_half,
        "discrete_rate": discrete_rate,
        "categories": dict(cats),
    }


# ============================================================
# Q4: N=6 特殊图属性
# ============================================================

def q4_N6_special_graphs():
    print("\n" + "=" * 100)
    print("Q4. N=6 贡献谐振的 8 个特殊图")
    print("=" * 100)

    # v10/v11-Q2 报告的贡献图
    special_gids = [9, 26, 33, 38, 42, 49, 55, 60, 64, 69, 83, 103, 106, 108]
    print(f"\n  贡献谐振的图 ID: {special_gids}")

    # 从 atlas 加载这些图
    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == 6 and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)

    print(f"\n  {'gid':>4} | {'边数':>4} | {'|Aut|':>8} | {'度序列':>25} | {'谱间隙':>8} | {'桥数':>4}")
    print(f"  {'-'*4}-+-{'-'*4}-+-{'-'*8}-+-{'-'*25}-+-{'-'*8}-+-{'-'*4}")

    for gid in special_gids:
        if gid >= len(graphs):
            continue
        G = graphs[gid]
        n_e = G.number_of_edges()
        aut = count_automorphisms(G, max_count=5000)
        degs = tuple(sorted(d for _, d in G.degree()))
        L = nx.laplacian_matrix(G).astype(float).toarray()
        L_eigs = sorted(np.linalg.eigvalsh(L))
        L1 = L_eigs[1] if len(L_eigs) > 1 else 0
        n_bridges = len(list(nx.bridges(G)))
        print(f"  {gid:>4} | {n_e:>4} | {str(aut):>8} | {str(degs):>25} | "
              f"{L1:>8.4f} | {n_bridges:>4}")

    # 对比：不贡献谐振的图
    print(f"\n  --- 对比：不贡献谐振的图（前 10 个）---")
    contributing = set(special_gids)
    print(f"  {'gid':>4} | {'边数':>4} | {'|Aut|':>8} | {'度序列':>25} | {'谱间隙':>8} | {'桥数':>4}")
    print(f"  {'-'*4}-+-{'-'*4}-+-{'-'*8}-+-{'-'*25}-+-{'-'*8}-+-{'-'*4}")
    non_contrib = [i for i in range(len(graphs)) if i not in contributing][:10]
    for gid in non_contrib:
        G = graphs[gid]
        n_e = G.number_of_edges()
        aut = count_automorphisms(G, max_count=5000)
        degs = tuple(sorted(d for _, d in G.degree()))
        L = nx.laplacian_matrix(G).astype(float).toarray()
        L_eigs = sorted(np.linalg.eigvalsh(L))
        L1 = L_eigs[1] if len(L_eigs) > 1 else 0
        n_bridges = len(list(nx.bridges(G)))
        print(f"  {gid:>4} | {n_e:>4} | {str(aut):>8} | {str(degs):>25} | "
              f"{L1:>8.4f} | {n_bridges:>4}")


# ============================================================
# Q5: 离散性度量跨 N 对比
# ============================================================

def q5_discreteness_summary(results):
    print("\n" + "=" * 100)
    print("Q5. 离散性度量跨 N 对比")
    print("=" * 100)

    # 已知数据
    known = {
        6: {"n_unique": 11, "n_res": 48, "half_rate": 0.75, "alg_rate": 0.82},
        7: {"n_unique": 4172, "n_res": 9314, "half_rate": 0.002, "alg_rate": 0.01},
    }

    print(f"\n  {'N':>4} | {'图数':>6} | {'谐振点':>6} | {'唯一 s':>8} | "
          f"{'0.5 倍数率':>10} | {'代数识别率':>10}")
    print(f"  {'-'*4}-+-{'-'*6}-+-{'-'*6}-+-{'-'*8}-+-{'-'*10}-+-{'-'*10}")

    for N in sorted(known.keys()):
        d = known[N]
        print(f"  {N:>4} | {'112' if N==6 else '853':>6} | {d['n_res']:>6} | "
              f"{d['n_unique']:>8} | {d['half_rate']:>10.1%} | {d['alg_rate']:>10.1%}")

    # N=8 结果
    if 8 in results and results[8]:
        r = results[8]
        print(f"  {'8':>4} | {'~100':>6} | {r['n_resonances']:>6} | "
              f"{r['n_unique']:>8} | {r['n_half']/r['n_unique']:>10.1%} | "
              f"{r['discrete_rate']:>10.1%}")

    print(f"\n  --- 关键发现 ---")
    print(f"  N=6: 离散谐振谱，代数识别率 82%")
    print(f"  N=7: 连续谐振谱，代数识别率 1%")
    if 8 in results and results[8]:
        r = results[8]
        print(f"  N=8: 代数识别率 {r['discrete_rate']:.1%}，"
              f"介于 N=6 和 N=7 之间" if 0.01 < r['discrete_rate'] < 0.82
              else f"  N=8: 代数识别率 {r['discrete_rate']:.1%}")


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 100)
    print("照妖镜 v14.0：跨尺度谐振谱离散性")
    print("=" * 100)

    # 图集
    print(f"\n  加载图集...")
    graphs_N6 = build_atlas_graphs(6)
    graphs_N7 = build_atlas_graphs(7)
    print(f"  N=6: {len(graphs_N6)} 图")
    print(f"  N=7: {len(graphs_N7)} 图")

    print(f"  生成 N=8 样本...")
    graphs_N8 = build_N8_samples(n_samples=100)
    print(f"  N=8: {len(graphs_N8)} 图")

    # Q1
    q1_automorphism_sizes({6: graphs_N6[:30], 7: graphs_N7[:50], 8: graphs_N8[:30]})

    # Q2
    q2_results = q2_edges_vs_resonances(
        {6: graphs_N6[:40], 7: graphs_N7[:80]},
        max_edges_per_graph=3)

    # Q3
    q3_result = q3_N8_sampling(graphs_N8[:60], max_edges_per_graph=3)

    # Q4
    q4_N6_special_graphs()

    # Q5
    q5_discreteness_summary({8: q3_result})

    print("\n" + "=" * 100)
    print("v14.0 完成。")
    print("=" * 100)


if __name__ == "__main__":
    main()