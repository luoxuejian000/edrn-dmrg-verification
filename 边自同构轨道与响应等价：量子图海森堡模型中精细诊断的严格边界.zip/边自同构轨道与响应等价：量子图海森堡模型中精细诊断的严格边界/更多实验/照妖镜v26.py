#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 v26.0：pS_curves_equal 的 35 对分类
================================================================

v25 发现：
  - pS_curves_equal: 35 对候选（24 核心 + 11 非核心）
  - 核心 24 对中：13 共享端点，11 不共享端点
  - 图论条件无一能区分

v26 追问：
  Q1. 那 11 个非核心对是什么？中环？外壳？还是别的东西？
  Q2. 那 11 个不共享端点的核心对，与 13 个共享端点的核心对有何不同？
  Q3. 35 对按 n_true 分类，各类的图论特征是什么？
  Q4. pS_curves_equal 的真正定义域是什么？
  Q5. 是否存在"更精确的量子条件"能把 35 对分成 {24 核心} vs {11 其他}？
"""

import sys, io, itertools, json, os
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from collections import Counter, defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"


# ============================================================
# 基础
# ============================================================

def build_atlas_graphs(N):
    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    return graphs


def edge_orbits(G):
    edges = [tuple(sorted(e)) for e in G.edges()]
    GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
    autos = list(GM.isomorphisms_iter())
    orbits = {}
    for e in edges:
        orbit = frozenset(frozenset({a[e[0]], a[e[1]]}) for a in autos)
        orbits[e] = orbit
    return orbits


def load_v51_patterns():
    with open(os.path.join(WORK_DIR, "照妖镜_v5_1_模式.json"), "r",
              encoding="utf-8") as f:
        v51 = json.load(f)
    patterns = {}
    for key, s in v51["patterns"].items():
        gid, e1_str, e2_str = key.split("_", 2)
        gid = int(gid)
        e1 = tuple(map(int, e1_str.strip("()").split(",")))
        e2 = tuple(map(int, e2_str.strip("()").split(",")))
        patterns[(gid, tuple(sorted(e1)), tuple(sorted(e2)))] = s
    return patterns


def build_sz0_sector(N):
    n_up = N // 2
    basis = []
    for comb in itertools.combinations(range(N), n_up):
        state = [0]*N
        for i in comb: state[i] = 1
        basis.append(tuple(state))
    dim = len(basis)
    idx = {s: i for i, s in enumerate(basis)}
    SZ_ops = []
    for site in range(N):
        SZ = np.zeros((dim, dim), dtype=complex)
        for i, state in enumerate(basis):
            SZ[i, i] = 1 if state[site] == 1 else -1
        SZ_ops.append(SZ)
    return basis, idx, SZ_ops


def build_edge_op(i, j, basis, idx):
    dim = len(basis)
    op = np.zeros((dim, dim), dtype=complex)
    for a_idx, state_a in enumerate(basis):
        sa, sb = state_a[i], state_a[j]
        if sa == sb:
            op[a_idx, a_idx] += 1
        else:
            op[a_idx, a_idx] += -1
            new_state = list(state_a)
            new_state[i], new_state[j] = new_state[j], new_state[i]
            b_idx = idx.get(tuple(new_state))
            if b_idx is not None:
                op[b_idx, a_idx] += 2
    return op


def pS_curve(edge_ops, defect, s_grid, SZ_ops, ref_dim):
    curve = []
    for s in s_grid:
        H = np.zeros((ref_dim, ref_dim), dtype=complex)
        for e, M in edge_ops.items():
            c = s if e == defect else 1.0
            H += c * M
        try:
            evals, evecs = eigh(H)
        except Exception:
            curve.append(np.nan)
            continue
        E0 = evals[0]
        deg = int(np.sum(np.abs(evals - E0) < 1e-8))
        V = evecs[:, :deg]
        rho = V @ V.conj().T / deg
        i, j = defect
        szsz_diag = np.diag(SZ_ops[i] @ SZ_ops[j])
        szsz = float(np.real(np.sum(np.diag(rho) * szsz_diag)))
        p_S = (1 - 3 * szsz) / 4
        curve.append(p_S)
    return np.array(curve)


# ============================================================
# 图论特征
# ============================================================

def graph_features(G, e1, e2, orbits):
    n1a, n1b = e1
    n2a, n2b = e2
    s1, s2 = {n1a, n1b}, {n2a, n2b}

    deg1 = tuple(sorted([G.degree(n1a), G.degree(n1b)]))
    deg2 = tuple(sorted([G.degree(n2a), G.degree(n2b)]))

    neigh1 = set(G.neighbors(n1a)) | set(G.neighbors(n1b))
    neigh2 = set(G.neighbors(n2a)) | set(G.neighbors(n2b))
    common_neigh = neigh1 & neigh2
    union_neigh = neigh1 | neigh2

    try:
        bridges = set(map(frozenset, nx.bridges(G)))
        is_bridge_1 = frozenset(e1) in bridges
        is_bridge_2 = frozenset(e2) in bridges
    except Exception:
        is_bridge_1 = is_bridge_2 = False

    tri_1 = sum(1 for _ in nx.common_neighbors(G, n1a, n1b))
    tri_2 = sum(1 for _ in nx.common_neighbors(G, n2a, n2b))

    try:
        d_aa = nx.shortest_path_length(G, n1a, n2a)
    except Exception:
        d_aa = -1

    combined_nodes = s1 | s2
    sub = G.subgraph(combined_nodes)
    combined_edges = len(set(tuple(sorted(e)) for e in sub.edges()))

    return {
        "share_endpoint": len(s1 & s2) > 0,
        "deg_pair_1": deg1, "deg_pair_2": deg2,
        "common_neighbors": len(common_neigh),
        "jaccard": len(common_neigh) / len(union_neigh) if union_neigh else 0,
        "is_bridge_1": is_bridge_1, "is_bridge_2": is_bridge_2,
        "triangle_1": tri_1, "triangle_2": tri_2,
        "edge_distance": d_aa,
        "combined_nodes": len(combined_nodes),
        "combined_edges": combined_edges,
        "orbit_size_1": len(orbits[e1]),
        "orbit_size_2": len(orbits[e2]),
        "combined_node_set": tuple(sorted(combined_nodes)),
    }


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 100)
    print("照妖镜 v26.0：pS_curves_equal 的 35 对分类")
    print("=" * 100)

    N = 6
    graphs = build_atlas_graphs(N)
    patterns = load_v51_patterns()
    print(f"\n  N={N} 图集: {len(graphs)} 图")
    print(f"  已知同响应对: {len(patterns)}")

    basis, idx, SZ_ops = build_sz0_sector(N)
    ref_dim = len(basis)

    # 精细 s 网格（v25 用的）
    s_grid = np.linspace(-1.0, 1.0, 41)

    # 扫描全部异轨道对
    print(f"\n  扫描全部异轨道对（计算 p_S 曲线）...")
    all_pairs = []
    for gid, G in enumerate(graphs):
        if gid % 30 == 0:
            print(f"    {gid}/{len(graphs)}")
        edges = [tuple(sorted(e)) for e in G.edges()]
        orbits = edge_orbits(G)
        edge_ops = {e: build_edge_op(e[0], e[1], basis, idx) for e in edges}
        pS_cache = {e: pS_curve(edge_ops, e, s_grid, SZ_ops, ref_dim) for e in edges}

        for i in range(len(edges)):
            for j in range(i + 1, len(edges)):
                e1, e2 = edges[i], edges[j]
                if orbits[e1] == orbits[e2]:
                    continue
                key = (gid, e1, e2)
                n_true = patterns[key].count("1") if key in patterns else 0

                diff = np.abs(pS_cache[e1] - pS_cache[e2])
                pS_max_diff = float(np.nanmax(diff))
                pS_curves_equal = pS_max_diff < 1e-10

                gf = graph_features(G, e1, e2, orbits)
                all_pairs.append({
                    "gid": gid, "e1": e1, "e2": e2,
                    "n_true": n_true,
                    "pS_curves_equal": pS_curves_equal,
                    "pS_max_diff": pS_max_diff,
                    "pS_curve_1": pS_cache[e1].tolist(),
                    "pS_curve_2": pS_cache[e2].tolist(),
                    **gf,
                })

    print(f"\n  总对数: {len(all_pairs)}")

    # pS_curves_equal 的 35 对
    pS_equal_pairs = [p for p in all_pairs if p["pS_curves_equal"]]
    print(f"  pS_curves_equal: {len(pS_equal_pairs)} 对")

    # ============================================================
    # Q1: 35 对按 n_true 分类
    # ============================================================
    print("\n" + "=" * 100)
    print("Q1. 35 对按 n_true（模式类型）分类")
    print("=" * 100)

    by_n_true = Counter(p["n_true"] for p in pS_equal_pairs)
    print(f"\n  {'n_true':>8} | {'数量':>6} | {'类别':>12}")
    print(f"  {'-'*8}-+-{'-'*6}-+-{'-'*12}")
    for nt in sorted(by_n_true.keys(), reverse=True):
        cnt = by_n_true[nt]
        if nt == 24: cat = "核心"
        elif nt == 1: cat = "外壳"
        elif nt > 1: cat = "中环"
        else: cat = "异响应"
        print(f"  {nt:>8} | {cnt:>6} | {cat:>12}")

    # 列出非核心对
    print(f"\n  --- 非核心的 {len(pS_equal_pairs) - 24} 对 ---")
    print(f"  {'gid':>4} | {'e1':>8} | {'e2':>8} | {'n_true':>6} | {'类别':>8} | {'share_ep':>8}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*8}-+-{'-'*6}-+-{'-'*8}-+-{'-'*8}")
    for p in sorted(pS_equal_pairs, key=lambda x: x["n_true"]):
        if p["n_true"] < 24:
            cat = "外壳" if p["n_true"] == 1 else "中环"
            print(f"  {p['gid']:>4} | {str(p['e1']):>8} | {str(p['e2']):>8} | "
                  f"{p['n_true']:>6} | {cat:>8} | {str(p['share_endpoint']):>8}")

    # ============================================================
    # Q2: 核心 24 对内的共享端点 vs 不共享端点
    # ============================================================
    print("\n" + "=" * 100)
    print("Q2. 核心 24 对：共享端点 vs 不共享端点")
    print("=" * 100)

    core_pairs = [p for p in pS_equal_pairs if p["n_true"] == 24]
    shared = [p for p in core_pairs if p["share_endpoint"]]
    not_shared = [p for p in core_pairs if not p["share_endpoint"]]
    print(f"\n  核心对: {len(core_pairs)}")
    print(f"  共享端点: {len(shared)}")
    print(f"  不共享端点: {len(not_shared)}")

    # 两组的图论特征对比
    print(f"\n  --- 共享端点组（{len(shared)} 对）---")
    print(f"  {'gid':>4} | {'e1':>8} | {'e2':>8} | {'deg1':>8} | {'deg2':>8} | {'comm':>4} | {'jacc':>6} | {'d':>3}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*8}-+-{'-'*8}-+-{'-'*8}-+-{'-'*4}-+-{'-'*6}-+-{'-'*3}")
    for p in shared:
        print(f"  {p['gid']:>4} | {str(p['e1']):>8} | {str(p['e2']):>8} | "
              f"{str(p['deg_pair_1']):>8} | {str(p['deg_pair_2']):>8} | "
              f"{p['common_neighbors']:>4} | {p['jaccard']:>6.3f} | "
              f"{p['edge_distance']:>3}")

    print(f"\n  --- 不共享端点组（{len(not_shared)} 对）---")
    print(f"  {'gid':>4} | {'e1':>8} | {'e2':>8} | {'deg1':>8} | {'deg2':>8} | {'comm':>4} | {'jacc':>6} | {'d':>3}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*8}-+-{'-'*8}-+-{'-'*8}-+-{'-'*4}-+-{'-'*6}-+-{'-'*3}")
    for p in not_shared:
        print(f"  {p['gid']:>4} | {str(p['e1']):>8} | {str(p['e2']):>8} | "
              f"{str(p['deg_pair_1']):>8} | {str(p['deg_pair_2']):>8} | "
              f"{p['common_neighbors']:>4} | {p['jaccard']:>6.3f} | "
              f"{p['edge_distance']:>3}")

    # ============================================================
    # Q3: 35 对按 gid 分类
    # ============================================================
    print("\n" + "=" * 100)
    print("Q3. 35 对按 gid 分类")
    print("=" * 100)

    by_gid = defaultdict(list)
    for p in pS_equal_pairs:
        by_gid[p["gid"]].append(p)

    print(f"\n  {'gid':>4} | {'总数':>6} | {'核心':>4} | {'中环':>4} | {'外壳':>4} | {'异响应':>6}")
    print(f"  {'-'*4}-+-{'-'*6}-+-{'-'*4}-+-{'-'*4}-+-{'-'*4}-+-{'-'*6}")
    for gid in sorted(by_gid.keys()):
        pairs = by_gid[gid]
        n_core = sum(1 for p in pairs if p["n_true"] == 24)
        n_mid = sum(1 for p in pairs if 1 < p["n_true"] < 24)
        n_out = sum(1 for p in pairs if p["n_true"] == 1)
        n_diff = sum(1 for p in pairs if p["n_true"] == 0)
        print(f"  {gid:>4} | {len(pairs):>6} | {n_core:>4} | {n_mid:>4} | "
              f"{n_out:>4} | {n_diff:>6}")

    # ============================================================
    # Q4: pS_curves_equal 的真正定义域
    # ============================================================
    print("\n" + "=" * 100)
    print("Q4. pS_curves_equal 的真正定义域")
    print("=" * 100)

    # pS_curves_equal 的 35 对 vs 全部 2731 对
    n_total = len(all_pairs)
    n_pS_eq = len(pS_equal_pairs)
    print(f"\n  pS_curves_equal / 全部异轨道对: {n_pS_eq}/{n_total} = {n_pS_eq/n_total:.2%}")

    # 不同阈值下的候选数
    print(f"\n  --- 不同 pS_max_diff 阈值下的候选数 ---")
    print(f"  {'阈值':>12} | {'候选数':>8} | {'核心':>6} | {'中环':>6} | {'外壳':>6} | {'异响应':>8}")
    print(f"  {'-'*12}-+-{'-'*8}-+-{'-'*6}-+-{'-'*6}-+-{'-'*6}-+-{'-'*8}")
    for thr in [1e-10, 1e-8, 1e-6, 1e-4, 1e-2, 0.1, 0.5]:
        cand = [p for p in all_pairs if p["pS_max_diff"] < thr]
        n_core = sum(1 for p in cand if p["n_true"] == 24)
        n_mid = sum(1 for p in cand if 1 < p["n_true"] < 24)
        n_out = sum(1 for p in cand if p["n_true"] == 1)
        n_diff = sum(1 for p in cand if p["n_true"] == 0)
        print(f"  {thr:>12.0e} | {len(cand):>8} | {n_core:>6} | {n_mid:>6} | "
              f"{n_out:>6} | {n_diff:>8}")

    # ============================================================
    # Q5: 更精确的量子条件
    # ============================================================
    print("\n" + "=" * 100)
    print("Q5. 更精确的量子条件")
    print("=" * 100)

    # 对每对，计算 p_S 曲线在 s=0, 0.5, 1 处的差异
    s_idx_0 = np.argmin(np.abs(s_grid - 0.0))
    s_idx_05 = np.argmin(np.abs(s_grid - 0.5))
    s_idx_1 = np.argmin(np.abs(s_grid - 1.0))

    for p in pS_equal_pairs:
        c1 = np.array(p["pS_curve_1"])
        c2 = np.array(p["pS_curve_2"])
        # 曲线本身的值（不是差异）
        p["pS_1_at_0"] = float(c1[s_idx_0])
        p["pS_1_at_05"] = float(c1[s_idx_05])
        p["pS_1_at_1"] = float(c1[s_idx_1])
        p["pS_1_mean"] = float(np.nanmean(c1))
        p["pS_1_std"] = float(np.nanstd(c1))
        p["pS_1_min"] = float(np.nanmin(c1))
        p["pS_1_max"] = float(np.nanmax(c1))

    # 对 35 对，看是否能用 p_S 曲线的值把 24 核心分出来
    print(f"\n  --- 35 对按 n_true 分组的 p_S 曲线统计 ---")
    print(f"  {'类别':>8} | {'数量':>6} | {'p_S@0 均值':>12} | {'p_S@0.5 均值':>14} | {'p_S@1 均值':>12} | {'p_S 均值':>10} | {'p_S std 均值':>14}")
    print(f"  {'-'*8}-+-{'-'*6}-+-{'-'*12}-+-{'-'*14}-+-{'-'*12}-+-{'-'*10}-+-{'-'*14}")

    for cat_name, cat_pairs in [
        ("核心", [p for p in pS_equal_pairs if p["n_true"] == 24]),
        ("中环", [p for p in pS_equal_pairs if 1 < p["n_true"] < 24]),
        ("外壳", [p for p in pS_equal_pairs if p["n_true"] == 1]),
    ]:
        if not cat_pairs:
            continue
        pS_0 = [p["pS_1_at_0"] for p in cat_pairs]
        pS_05 = [p["pS_1_at_05"] for p in cat_pairs]
        pS_1 = [p["pS_1_at_1"] for p in cat_pairs]
        pS_mean = [p["pS_1_mean"] for p in cat_pairs]
        pS_std = [p["pS_1_std"] for p in cat_pairs]
        print(f"  {cat_name:>8} | {len(cat_pairs):>6} | {np.mean(pS_0):>12.4f} | "
              f"{np.mean(pS_05):>14.4f} | {np.mean(pS_1):>12.4f} | "
              f"{np.mean(pS_mean):>10.4f} | {np.mean(pS_std):>14.4f}")

    # 尝试: 用 p_S@0 < 0.1 区分核心 vs 其他
    print(f"\n  --- 尝试新条件（p_S 曲线本身的值）---")
    print(f"  {'条件':<40} | {'候选数':>6} | {'命中核心':>8} | {'精度':>6} | {'召回':>6}")
    print(f"  {'-'*40}-+-{'-'*6}-+-{'-'*8}-+-{'-'*6}-+-{'-'*6}")

    new_conditions = [
        ("pS@0 == 0", lambda p: abs(p.get("pS_1_at_0", 1)) < 1e-6),
        ("pS@0 < 0.1", lambda p: p.get("pS_1_at_0", 1) < 0.1),
        ("pS@0.5 < 0.1", lambda p: p.get("pS_1_at_05", 1) < 0.1),
        ("pS@0.5 == 0", lambda p: abs(p.get("pS_1_at_05", 1)) < 1e-6),
        ("pS@1 < 0.1", lambda p: p.get("pS_1_at_1", 1) < 0.1),
        ("pS_std < 0.05", lambda p: p.get("pS_1_std", 1) < 0.05),
        ("pS_mean < 0.3", lambda p: p.get("pS_1_mean", 1) < 0.3),
        ("pS_mean < 0.5", lambda p: p.get("pS_1_mean", 1) < 0.5),
        ("pS_min == 0", lambda p: abs(p.get("pS_1_min", 1)) < 1e-6),
    ]

    for name, cond in new_conditions:
        # 条件应用在 35 对内
        subset = [p for p in pS_equal_pairs if cond(p)]
        n_core = sum(1 for p in subset if p["n_true"] == 24)
        precision = n_core / len(subset) if subset else 0
        recall = n_core / 24 if 24 > 0 else 0
        print(f"  {name:<40} | {len(subset):>6} | {n_core:>8} | "
              f"{precision:>5.1%} | {recall:>5.1%}")

    # ============================================================
    # 深度追问：13 对共享端点核心对的精确图论位置
    # ============================================================
    print("\n" + "=" * 100)
    print("深度追问：13 对共享端点核心对的结构")
    print("=" * 100)

    print(f"\n  13 对共享端点核心对：")
    print(f"  {'gid':>4} | {'e1':>8} | {'e2':>8} | {'共享节点':>8} | {'combined 节点':>20} | {'combined 边':>10}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*8}-+-{'-'*8}-+-{'-'*20}-+-{'-'*10}")
    for p in shared:
        s1 = set(p["e1"])
        s2 = set(p["e2"])
        shared_node = list(s1 & s2)
        print(f"  {p['gid']:>4} | {str(p['e1']):>8} | {str(p['e2']):>8} | "
              f"{str(shared_node):>8} | {str(p['combined_node_set']):>20} | "
              f"{p['combined_edges']:>10}")

    # ============================================================
    # 深度追问：11 对不共享端点核心对的结构
    # ============================================================
    print("\n" + "=" * 100)
    print("深度追问：11 对不共享端点核心对的结构")
    print("=" * 100)

    print(f"\n  11 对不共享端点核心对：")
    print(f"  {'gid':>4} | {'e1':>8} | {'e2':>8} | {'combined 节点':>20} | {'combined 边':>10} | {'4 节点子图':>12}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*8}-+-{'-'*20}-+-{'-'*10}-+-{'-'*12}")
    for p in not_shared:
        n_nodes = p["combined_nodes"]
        n_edges = p["combined_edges"]
        if n_nodes == 4 and n_edges == 6:
            subtype = "K4"
        elif n_nodes == 4 and n_edges == 5:
            subtype = "K4-1"
        elif n_nodes == 4 and n_edges == 4:
            subtype = "C4 或 K4-2"
        else:
            subtype = f"{n_nodes}n {n_edges}e"
        print(f"  {p['gid']:>4} | {str(p['e1']):>8} | {str(p['e2']):>8} | "
              f"{str(p['combined_node_set']):>20} | {n_edges:>10} | {subtype:>12}")

    # ============================================================
    # 导出
    # ============================================================
    # 去掉 pS_curve 大数组
    out_pairs = []
    for p in pS_equal_pairs:
        pp = {k: v for k, v in p.items() if k not in ("pS_curve_1", "pS_curve_2")}
        out_pairs.append(pp)

    out = {
        "n_total": n_total,
        "n_pS_equal": n_pS_eq,
        "n_core": len(core_pairs),
        "n_shared_core": len(shared),
        "n_not_shared_core": len(not_shared),
        "n_middle_in_pS_eq": sum(1 for p in pS_equal_pairs if 1 < p["n_true"] < 24),
        "n_outer_in_pS_eq": sum(1 for p in pS_equal_pairs if p["n_true"] == 1),
        "n_diff_in_pS_eq": sum(1 for p in pS_equal_pairs if p["n_true"] == 0),
        "pS_equal_pairs": out_pairs,
    }
    out_path = os.path.join(WORK_DIR, "照妖镜_v26_35对分类.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("v26.0 完成。")
    print("=" * 100)


if __name__ == "__main__":
    main()