#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 v31.0：S=1 分支的机制
================================================================

v30 发现：
  - S=0 分支: sd1@0.5 = sd2@0.5 是必要条件（40/40 召回）
  - S=1 分支: sd1@0.5 = sd2@0.5 完全不适用（0/7 召回）

v31 集中攻击 S=1 分支：
  Q1. S=1 的 7 对是什么？它们的共同特征？
  Q2. sd1(s) = -sd2(s) 是否是 S=1 的必要条件？
  Q3. 图 38 的 6 对与第 7 对（非图 38）有何区别？
  Q4. S=1 分支的充分条件是什么？
  Q5. 是否存在跨 S 值的统一条件？
"""

import sys, io, itertools, json, os
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from collections import Counter, defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"


# ============================================================
# 基础
# ============================================================

def build_atlas_graphs(N):
    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    return graphs


def build_sz0_sector(N):
    n_up = N // 2
    basis = []
    for comb in itertools.combinations(range(N), n_up):
        state = [0]*N
        for i in comb: state[i] = 1
        basis.append(tuple(state))
    dim = len(basis)
    idx = {s: i for i, s in enumerate(basis)}
    SZ_ops = []
    for site in range(N):
        SZ = np.zeros((dim, dim), dtype=complex)
        for i, state in enumerate(basis):
            SZ[i, i] = 1 if state[site] == 1 else -1
        SZ_ops.append(SZ)
    return basis, idx, SZ_ops


def build_edge_op(i, j, basis, idx):
    dim = len(basis)
    op = np.zeros((dim, dim), dtype=complex)
    for a_idx, state_a in enumerate(basis):
        sa, sb = state_a[i], state_a[j]
        if sa == sb:
            op[a_idx, a_idx] += 1
        else:
            op[a_idx, a_idx] += -1
            new_state = list(state_a)
            new_state[i], new_state[j] = new_state[j], new_state[i]
            b_idx = idx.get(tuple(new_state))
            if b_idx is not None:
                op[b_idx, a_idx] += 2
    return op


def build_S2_op(basis, idx, N):
    dim = len(basis)
    S2 = np.zeros((dim, dim), dtype=complex)
    for i in range(N):
        S2 += 3/4 * np.eye(dim, dtype=complex)
        for j in range(N):
            if i == j: continue
            S2 += 1/4 * build_edge_op(i, j, basis, idx)
    return S2


def analyze_at_s(edge_ops, defect, s, SZ_ops, S2_op, ref_dim):
    H = np.zeros((ref_dim, ref_dim), dtype=complex)
    for e, M in edge_ops.items():
        c = s if e == defect else 1.0
        H += c * M
    try:
        evals, evecs = eigh(H)
    except Exception:
        return None
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < 1e-8))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    S2_val = float(np.real(np.trace(rho @ S2_op)))
    S_total = (-1 + np.sqrt(1 + 4*max(S2_val, 0))) / 2
    i, j = defect
    szsz_diag = np.diag(SZ_ops[i] @ SZ_ops[j])
    szsz = float(np.real(np.sum(np.diag(rho) * szsz_diag)))
    p_S = (1 - 3 * szsz) / 4
    sd = float(np.real(np.trace(rho @ edge_ops[defect])))
    return {"S": S_total, "pS": p_S, "sd": sd, "deg": deg}


def load_patterns():
    with open(os.path.join(WORK_DIR, "照妖镜_v5_1_模式.json"), "r",
              encoding="utf-8") as f:
        v51 = json.load(f)
    patterns = {}
    for key, s in v51["patterns"].items():
        gid, e1_str, e2_str = key.split("_", 2)
        gid = int(gid)
        e1 = tuple(map(int, e1_str.strip("()").split(",")))
        e2 = tuple(map(int, e2_str.strip("()").split(",")))
        patterns[(gid, tuple(sorted(e1)), tuple(sorted(e2)))] = s
    return patterns


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 100)
    print("照妖镜 v31.0：S=1 分支的机制")
    print("=" * 100)

    N = 6
    graphs = build_atlas_graphs(N)
    patterns = load_patterns()
    print(f"\n  N={N} 图集: {len(graphs)} 图")
    print(f"  已知同响应对: {len(patterns)}")

    basis, idx, SZ_ops = build_sz0_sector(N)
    ref_dim = len(basis)
    S2_op = build_S2_op(basis, idx, N)

    # 密集 s 采样
    s_vals = np.linspace(-2.0, 2.0, 41)

    # 先扫描同响应对（只算 47 对）
    print(f"\n  分析 47 对同响应对...")
    same_response_data = []
    for i, ((gid, e1, e2), pattern) in enumerate(sorted(patterns.items())):
        if i % 10 == 0:
            print(f"    {i}/47")
        G = graphs[gid]
        edges = [tuple(sorted(e)) for e in G.edges()]
        edge_ops = {e: build_edge_op(e[0], e[1], basis, idx) for e in edges}

        per_defect = {}
        for d_edge in [e1, e2]:
            curve_pS = []
            curve_sd = []
            curve_S = []
            curve_deg = []
            for s in s_vals:
                r = analyze_at_s(edge_ops, d_edge, s, SZ_ops, S2_op, ref_dim)
                if r:
                    curve_pS.append(r["pS"])
                    curve_sd.append(r["sd"])
                    curve_S.append(r["S"])
                    curve_deg.append(r["deg"])
                else:
                    curve_pS.append(np.nan)
                    curve_sd.append(np.nan)
                    curve_S.append(np.nan)
                    curve_deg.append(np.nan)
            per_defect[d_edge] = {
                "pS_curve": np.array(curve_pS),
                "sd_curve": np.array(curve_sd),
                "S_curve": np.array(curve_S),
                "deg_curve": np.array(curve_deg),
            }

        S1_at_05 = per_defect[e1]["S_curve"][np.argmin(np.abs(s_vals - 0.5))]
        S2_at_05 = per_defect[e2]["S_curve"][np.argmin(np.abs(s_vals - 0.5))]

        same_response_data.append({
            "gid": gid, "e1": e1, "e2": e2,
            "n_true": pattern.count("1"),
            "S1_at_05": float(S1_at_05),
            "S2_at_05": float(S2_at_05),
            "pS1_curve": per_defect[e1]["pS_curve"].tolist(),
            "pS2_curve": per_defect[e2]["pS_curve"].tolist(),
            "sd1_curve": per_defect[e1]["sd_curve"].tolist(),
            "sd2_curve": per_defect[e2]["sd_curve"].tolist(),
            "S1_curve": per_defect[e1]["S_curve"].tolist(),
            "S2_curve": per_defect[e2]["S_curve"].tolist(),
            "deg1_curve": per_defect[e1]["deg_curve"].tolist(),
            "deg2_curve": per_defect[e2]["deg_curve"].tolist(),
        })

    print(f"  完成 {len(same_response_data)} 对")

    # 过滤 S=1 的对
    S1_pairs = [p for p in same_response_data
                if abs(p["S1_at_05"] - 1.0) < 1e-3
                and abs(p["S2_at_05"] - 1.0) < 1e-3]
    S0_pairs = [p for p in same_response_data
                if abs(p["S1_at_05"] - 0.0) < 1e-3
                and abs(p["S2_at_05"] - 0.0) < 1e-3]
    other_pairs = [p for p in same_response_data
                   if p not in S1_pairs and p not in S0_pairs]

    print(f"\n  S=0 对: {len(S0_pairs)}")
    print(f"  S=1 对: {len(S1_pairs)}")
    print(f"  其他: {len(other_pairs)}")

    # ============================================================
    # Q1: S=1 的 7 对是什么？
    # ============================================================
    print("\n" + "=" * 100)
    print("Q1. S=1 的 7 对清单")
    print("=" * 100)

    print(f"\n  {'gid':>4} | {'e1':>8} | {'e2':>8} | {'n_true':>6} | "
          f"{'sd1@0.5':>10} | {'sd2@0.5':>10} | {'deg1':>5} | {'deg2':>5}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*8}-+-{'-'*6}-+-"
          f"{'-'*10}-+-{'-'*10}-+-{'-'*5}-+-{'-'*5}")

    for p in sorted(S1_pairs, key=lambda x: (x["gid"], x["e1"])):
        s_idx = np.argmin(np.abs(s_vals - 0.5))
        sd1 = p["sd1_curve"][s_idx]
        sd2 = p["sd2_curve"][s_idx]
        d1 = p["deg1_curve"][s_idx]
        d2 = p["deg2_curve"][s_idx]
        print(f"  {p['gid']:>4} | {str(p['e1']):>8} | {str(p['e2']):>8} | "
              f"{p['n_true']:>6} | {sd1:>10.4f} | {sd2:>10.4f} | "
              f"{d1:>5.0f} | {d2:>5.0f}")

    # ============================================================
    # Q2: sd1(s) = -sd2(s) 是否在所有 s 上成立？
    # ============================================================
    print("\n" + "=" * 100)
    print("Q2. S=1 对的 sd1(s) = -sd2(s) 条件")
    print("=" * 100)

    print(f"\n  {'gid':>4} | {'e1':>8} | {'e2':>8} | "
          f"{'max|sd1+sd2|':>15} | {'max|sd1-sd2|':>15} | {'判定':>15}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*8}-+-"
          f"{'-'*15}-+-{'-'*15}-+-{'-'*15}")

    for p in sorted(S1_pairs, key=lambda x: (x["gid"], x["e1"])):
        sd1 = np.array(p["sd1_curve"])
        sd2 = np.array(p["sd2_curve"])
        diff_sum = np.nanmax(np.abs(sd1 + sd2))
        diff_minus = np.nanmax(np.abs(sd1 - sd2))
        if diff_sum < 1e-6:
            verdict = "sd1 = -sd2"
        elif diff_minus < 1e-6:
            verdict = "sd1 = sd2"
        else:
            verdict = "neither"
        print(f"  {p['gid']:>4} | {str(p['e1']):>8} | {str(p['e2']):>8} | "
              f"{diff_sum:>15.4e} | {diff_minus:>15.4e} | {verdict:>15}")

    # ============================================================
    # Q3: 图 38 的 6 对 vs 第 7 对
    # ============================================================
    print("\n" + "=" * 100)
    print("Q3. 图 38 的 6 对 vs 第 7 对")
    print("=" * 100)

    g38_pairs = [p for p in S1_pairs if p["gid"] == 38]
    non_g38_pairs = [p for p in S1_pairs if p["gid"] != 38]
    print(f"\n  图 38 的 S=1 对: {len(g38_pairs)}")
    print(f"  非图 38 的 S=1 对: {len(non_g38_pairs)}")

    for p in non_g38_pairs:
        print(f"\n  非图 38 的 S=1 对: gid={p['gid']}, e1={p['e1']}, e2={p['e2']}")
        print(f"    n_true = {p['n_true']}")
        print(f"    S1@0.5 = {p['S1_at_05']:.4f}, S2@0.5 = {p['S2_at_05']:.4f}")
        # 输出 sd 曲线
        sd1 = np.array(p["sd1_curve"])
        sd2 = np.array(p["sd2_curve"])
        print(f"    sd1 曲线: {[round(v, 3) for v in sd1[:10]]}...")
        print(f"    sd2 曲线: {[round(v, 3) for v in sd2[:10]]}...")

    # ============================================================
    # Q4: S=1 分支的候选条件穷举
    # ============================================================
    print("\n" + "=" * 100)
    print("Q4. S=1 分支的候选条件穷举")
    print("=" * 100)

    # 先扫描全部 S=1 的对（同响应 + 异响应）
    print(f"\n  扫描全部 S=1 的异轨道对...")
    S1_all = []
    for gid, G in enumerate(graphs):
        if gid % 30 == 0:
            print(f"    {gid}/{len(graphs)}")
        edges = [tuple(sorted(e)) for e in G.edges()]
        GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
        autos = list(GM.isomorphisms_iter())
        orbits = {}
        for e in edges:
            orbit = frozenset(frozenset({a[e[0]], a[e[1]]}) for a in autos)
            orbits[e] = orbit
        edge_ops = {e: build_edge_op(e[0], e[1], basis, idx) for e in edges}

        # 缓存 S, sd
        S_cache = {}
        sd_cache = {}
        for e in edges:
            r05 = analyze_at_s(edge_ops, e, 0.5, SZ_ops, S2_op, ref_dim)
            r0 = analyze_at_s(edge_ops, e, 0.0, SZ_ops, S2_op, ref_dim)
            r1 = analyze_at_s(edge_ops, e, 1.0, SZ_ops, S2_op, ref_dim)
            S_cache[e] = r05["S"] if r05 else None
            sd_cache[e] = {
                "sd@0.5": r05["sd"] if r05 else None,
                "sd@0": r0["sd"] if r0 else None,
                "sd@1": r1["sd"] if r1 else None,
                "deg@0.5": r05["deg"] if r05 else None,
            }

        for i in range(len(edges)):
            for j in range(i + 1, len(edges)):
                e1, e2 = edges[i], edges[j]
                if orbits[e1] == orbits[e2]:
                    continue
                S1 = S_cache[e1]
                S2 = S_cache[e2]
                if S1 is None or S2 is None:
                    continue
                if abs(S1 - 1.0) < 1e-3 and abs(S2 - 1.0) < 1e-3:
                    key = (gid, e1, e2)
                    n_true = patterns[key].count("1") if key in patterns else 0
                    S1_all.append({
                        "gid": gid, "e1": e1, "e2": e2,
                        "n_true": n_true,
                        "sd1@0.5": sd_cache[e1]["sd@0.5"],
                        "sd2@0.5": sd_cache[e2]["sd@0.5"],
                        "sd1@0": sd_cache[e1]["sd@0"],
                        "sd2@0": sd_cache[e2]["sd@0"],
                        "sd1@1": sd_cache[e1]["sd@1"],
                        "sd2@1": sd_cache[e2]["sd@1"],
                        "deg1": sd_cache[e1]["deg@0.5"],
                        "deg2": sd_cache[e2]["deg@0.5"],
                    })

    print(f"\n  S=1 的对: {len(S1_all)}")
    n_same = sum(1 for p in S1_all if p["n_true"] > 0)
    print(f"  其中同响应: {n_same}")
    print(f"  其中异响应: {len(S1_all) - n_same}")

    # 穷举条件
    conditions = [
        ("sd1@0.5 = -sd2@0.5", lambda p: abs(p["sd1@0.5"] + p["sd2@0.5"]) < 1e-6),
        ("sd1@0.5 + sd2@0.5 < 0.01", lambda p: abs(p["sd1@0.5"] + p["sd2@0.5"]) < 0.01),
        ("sd1@0 + sd2@0 < 0.01", lambda p: abs(p["sd1@0"] + p["sd2@0"]) < 0.01),
        ("sd1@1 + sd2@1 < 0.01", lambda p: abs(p["sd1@1"] + p["sd2@1"]) < 0.01),
        ("sd1@0.5 = 1 且 sd2@0.5 = -1", lambda p: abs(p["sd1@0.5"] - 1) < 1e-6 and abs(p["sd2@0.5"] + 1) < 1e-6),
        ("sd1@0.5 = -1 且 sd2@0.5 = 1", lambda p: abs(p["sd1@0.5"] + 1) < 1e-6 and abs(p["sd2@0.5"] - 1) < 1e-6),
        ("|sd1@0.5| = |sd2@0.5| = 1", lambda p: abs(abs(p["sd1@0.5"]) - 1) < 1e-6 and abs(abs(p["sd2@0.5"]) - 1) < 1e-6),
        ("deg1 = deg2", lambda p: p["deg1"] == p["deg2"]),
        ("deg1=1 且 deg2=1", lambda p: p["deg1"] == 1 and p["deg2"] == 1),
        ("max(deg1,deg2) = 2", lambda p: max(p["deg1"], p["deg2"]) == 2),
    ]

    print(f"\n  {'条件':<40} | {'候选数':>6} | {'命中同响应':>8} | {'精度':>6} | {'召回':>6}")
    print(f"  {'-'*40}-+-{'-'*6}-+-{'-'*8}-+-{'-'*6}-+-{'-'*6}")
    for name, cond in conditions:
        subset = [p for p in S1_all if cond(p)]
        n_hit = sum(1 for p in subset if p["n_true"] > 0)
        prec = n_hit / len(subset) if subset else 0
        rec = n_hit / n_same if n_same > 0 else 0
        print(f"  {name:<40} | {len(subset):>6} | {n_hit:>8} | "
              f"{prec:>5.1%} | {rec:>5.1%}")

    # ============================================================
    # Q5: 跨 S 值的统一条件
    # ============================================================
    print("\n" + "=" * 100)
    print("Q5. 跨 S 值的统一条件：|sd1| + |sd2| 的对称性")
    print("=" * 100)

    # 对 S=0 和 S=1 的对，计算 |sd1| + |sd2|
    print(f"\n  --- S=0 同响应对的 sd 特征 ---")
    print(f"  {'gid':>4} | {'e1':>8} | {'e2':>8} | {'sd1@0.5':>10} | "
          f"{'sd2@0.5':>10} | {'|sd1|+|sd2|':>12}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*8}-+-{'-'*10}-+-{'-'*10}-+-{'-'*12}")
    for p in sorted(S0_pairs, key=lambda x: (x["gid"], x["e1"]))[:15]:
        s_idx = np.argmin(np.abs(s_vals - 0.5))
        sd1 = p["sd1_curve"][s_idx]
        sd2 = p["sd2_curve"][s_idx]
        print(f"  {p['gid']:>4} | {str(p['e1']):>8} | {str(p['e2']):>8} | "
              f"{sd1:>10.4f} | {sd2:>10.4f} | "
              f"{abs(sd1) + abs(sd2):>12.4f}")

    # ============================================================
    # 深度追问：S=1 对的图结构
    # ============================================================
    print("\n" + "=" * 100)
    print("深度追问：S=1 对的图结构")
    print("=" * 100)

    for p in S1_pairs:
        gid = p["gid"]
        G = graphs[gid]
        print(f"\n  gid={gid}, e1={p['e1']}, e2={p['e2']}")
        print(f"    边集: {sorted(G.edges())}")
        print(f"    度序列: {sorted(d for _, d in G.degree())}")
        # e1, e2 在图中
        print(f"    e1 = {p['e1']}, e2 = {p['e2']}")
        print(f"    e1 的度: {G.degree(p['e1'][0])}, {G.degree(p['e1'][1])}")
        print(f"    e2 的度: {G.degree(p['e2'][0])}, {G.degree(p['e2'][1])}")

    # ============================================================
    # 导出
    # ============================================================
    out = {
        "n_S0": len(S0_pairs),
        "n_S1": len(S1_pairs),
        "S1_pairs": [
            {k: v for k, v in p.items()
             if k not in ("pS1_curve", "pS2_curve", "sd1_curve", "sd2_curve",
                          "S1_curve", "S2_curve", "deg1_curve", "deg2_curve")}
            for p in S1_pairs
        ],
    }
    out_path = os.path.join(WORK_DIR, "照妖镜_v31_S1机制.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("v31.0 完成。")
    print("=" * 100)


if __name__ == "__main__":
    main()