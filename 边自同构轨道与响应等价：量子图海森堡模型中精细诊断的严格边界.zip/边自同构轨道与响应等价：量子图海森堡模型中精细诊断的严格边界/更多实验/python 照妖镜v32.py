#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 v32.0：Layer 1+2+3 之后的下一层条件穷举
================================================================

v29-v31 发现：
  Layer 1: S1 = S2（47/47 召回，零假阴性）
  Layer 2: |sd1@0.5| = |sd2@0.5|（47/47 召回）
  Layer 3: 符号规则（S=0 同号，S=1 反号）（47/47 召回）

v32 集中攻击：
  在 Layer 1+2+3 过滤后的约 130 个候选中，穷举下一层条件。

五个追问：
  Q1. |sd1(s)| = |sd2(s)| 对所有 s 成立是下一层吗？
  Q2. sd1(s) ± sd2(s) = 常数是下一层吗？
  Q3. 简并度条件是下一层吗？
  Q4. S 曲线条件是下一层吗？
  Q5. 是否存在"47/47 召回，高精度"的条件？
"""

import sys, io, itertools, json, os
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from collections import Counter, defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"


# ============================================================
# 基础
# ============================================================

def build_atlas_graphs(N):
    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    return graphs


def build_sz0_sector(N):
    n_up = N // 2
    basis = []
    for comb in itertools.combinations(range(N), n_up):
        state = [0]*N
        for i in comb: state[i] = 1
        basis.append(tuple(state))
    dim = len(basis)
    idx = {s: i for i, s in enumerate(basis)}
    SZ_ops = []
    for site in range(N):
        SZ = np.zeros((dim, dim), dtype=complex)
        for i, state in enumerate(basis):
            SZ[i, i] = 1 if state[site] == 1 else -1
        SZ_ops.append(SZ)
    return basis, idx, SZ_ops


def build_edge_op(i, j, basis, idx):
    dim = len(basis)
    op = np.zeros((dim, dim), dtype=complex)
    for a_idx, state_a in enumerate(basis):
        sa, sb = state_a[i], state_a[j]
        if sa == sb:
            op[a_idx, a_idx] += 1
        else:
            op[a_idx, a_idx] += -1
            new_state = list(state_a)
            new_state[i], new_state[j] = new_state[j], new_state[i]
            b_idx = idx.get(tuple(new_state))
            if b_idx is not None:
                op[b_idx, a_idx] += 2
    return op


def build_S2_op(basis, idx, N):
    dim = len(basis)
    S2 = np.zeros((dim, dim), dtype=complex)
    for i in range(N):
        S2 += 3/4 * np.eye(dim, dtype=complex)
        for j in range(N):
            if i == j: continue
            S2 += 1/4 * build_edge_op(i, j, basis, idx)
    return S2


def analyze_at_s(edge_ops, defect, s, SZ_ops, S2_op, ref_dim):
    H = np.zeros((ref_dim, ref_dim), dtype=complex)
    for e, M in edge_ops.items():
        c = s if e == defect else 1.0
        H += c * M
    try:
        evals, evecs = eigh(H)
    except Exception:
        return None
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < 1e-8))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    S2_val = float(np.real(np.trace(rho @ S2_op)))
    S_total = (-1 + np.sqrt(1 + 4*max(S2_val, 0))) / 2
    i, j = defect
    szsz_diag = np.diag(SZ_ops[i] @ SZ_ops[j])
    szsz = float(np.real(np.sum(np.diag(rho) * szsz_diag)))
    p_S = (1 - 3 * szsz) / 4
    sd = float(np.real(np.trace(rho @ edge_ops[defect])))
    return {"S": S_total, "pS": p_S, "sd": sd, "deg": deg}


def load_patterns():
    with open(os.path.join(WORK_DIR, "照妖镜_v5_1_模式.json"), "r",
              encoding="utf-8") as f:
        v51 = json.load(f)
    patterns = {}
    for key, s in v51["patterns"].items():
        gid, e1_str, e2_str = key.split("_", 2)
        gid = int(gid)
        e1 = tuple(map(int, e1_str.strip("()").split(",")))
        e2 = tuple(map(int, e2_str.strip("()").split(",")))
        patterns[(gid, tuple(sorted(e1)), tuple(sorted(e2)))] = s
    return patterns


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 100)
    print("照妖镜 v32.0：Layer 1+2+3 之后的下一层条件穷举")
    print("=" * 100)

    N = 6
    graphs = build_atlas_graphs(N)
    patterns = load_patterns()
    print(f"\n  N={N} 图集: {len(graphs)} 图")
    print(f"  已知同响应对: {len(patterns)}")

    basis, idx, SZ_ops = build_sz0_sector(N)
    ref_dim = len(basis)
    S2_op = build_S2_op(basis, idx, N)

    s_vals = np.linspace(-2.0, 2.0, 41)
    s_idx_05 = np.argmin(np.abs(s_vals - 0.5))

    # 扫描 2731 对
    print(f"\n  扫描全部 2731 对（41 点 s 采样）...")
    all_pairs = []
    for gid, G in enumerate(graphs):
        if gid % 30 == 0:
            print(f"    {gid}/{len(graphs)}")
        edges = [tuple(sorted(e)) for e in G.edges()]
        GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
        autos = list(GM.isomorphisms_iter())
        orbits = {}
        for e in edges:
            orbit = frozenset(frozenset({a[e[0]], a[e[1]]}) for a in autos)
            orbits[e] = orbit

        edge_ops = {e: build_edge_op(e[0], e[1], basis, idx) for e in edges}

        edge_features = {}
        for e in edges:
            full_data = {"pS_curve": [], "sd_curve": [],
                         "S_curve": [], "deg_curve": []}
            for s in s_vals:
                r = analyze_at_s(edge_ops, e, s, SZ_ops, S2_op, ref_dim)
                if r:
                    full_data["pS_curve"].append(r["pS"])
                    full_data["sd_curve"].append(r["sd"])
                    full_data["S_curve"].append(r["S"])
                    full_data["deg_curve"].append(r["deg"])
                else:
                    for k in full_data:
                        full_data[k].append(np.nan)
            full_data = {k: np.array(v) for k, v in full_data.items()}
            edge_features[e] = full_data

        for i in range(len(edges)):
            for j in range(i + 1, len(edges)):
                e1, e2 = edges[i], edges[j]
                if orbits[e1] == orbits[e2]:
                    continue
                key = (gid, e1, e2)
                n_true = patterns[key].count("1") if key in patterns else 0

                f1 = edge_features[e1]
                f2 = edge_features[e2]

                all_pairs.append({
                    "gid": gid, "e1": e1, "e2": e2,
                    "n_true": n_true,
                    "S1": float(f1["S_curve"][s_idx_05]),
                    "S2": float(f2["S_curve"][s_idx_05]),
                    "sd1@0.5": float(f1["sd_curve"][s_idx_05]),
                    "sd2@0.5": float(f2["sd_curve"][s_idx_05]),
                    "deg1": float(f1["deg_curve"][s_idx_05]),
                    "deg2": float(f2["deg_curve"][s_idx_05]),
                    "sd1_curve": f1["sd_curve"].tolist(),
                    "sd2_curve": f2["sd_curve"].tolist(),
                    "pS1_curve": f1["pS_curve"].tolist(),
                    "pS2_curve": f2["pS_curve"].tolist(),
                    "S1_curve": f1["S_curve"].tolist(),
                    "S2_curve": f2["S_curve"].tolist(),
                    "deg1_curve": f1["deg_curve"].tolist(),
                    "deg2_curve": f2["deg_curve"].tolist(),
                })

    print(f"\n  完成 {len(all_pairs)} 对")

    # ============================================================
    # Layer 1+2+3 过滤
    # ============================================================
    layer123 = []
    for p in all_pairs:
        S1, S2 = p["S1"], p["S2"]
        if abs(S1 - S2) > 1e-3:
            continue
        sd1, sd2 = p["sd1@0.5"], p["sd2@0.5"]
        if S1 < 0.5:  # S=0
            if abs(sd1 - sd2) > 1e-6:
                continue
        else:  # S=1
            if abs(sd1 + sd2) > 1e-6:
                continue
        layer123.append(p)

    n_same_123 = sum(1 for p in layer123 if p["n_true"] > 0)
    n_diff_123 = sum(1 for p in layer123 if p["n_true"] == 0)
    print(f"\n  Layer 1+2+3 候选: {len(layer123)}")
    print(f"    同响应: {n_same_123}")
    print(f"    异响应: {n_diff_123}")

    S0_candidates = [p for p in layer123 if p["S1"] < 0.5]
    S1_candidates = [p for p in layer123 if p["S1"] > 0.5]
    n_same_S0 = sum(1 for p in S0_candidates if p["n_true"] > 0)
    n_same_S1 = sum(1 for p in S1_candidates if p["n_true"] > 0)
    print(f"\n  S=0 候选: {len(S0_candidates)} (其中同响应 {n_same_S0})")
    print(f"  S=1 候选: {len(S1_candidates)} (其中同响应 {n_same_S1})")

    # ============================================================
    # 下一层条件穷举
    # ============================================================

    def eval_cond(cond, scope):
        subset = [p for p in scope if cond(p)]
        hits = sum(1 for p in subset if p["n_true"] > 0)
        prec = hits / len(subset) if subset else 0
        n_same_scope = sum(1 for p in scope if p["n_true"] > 0)
        rec = hits / n_same_scope if n_same_scope else 0
        f1 = 2 * prec * rec / (prec + rec) if (prec + rec) > 0 else 0
        return len(subset), hits, prec, rec, f1

    # --- Q1 ---
    print("\n" + "=" * 100)
    print("Q1. |sd1(s)| = |sd2(s)| 对所有 s / 窗口")
    print("=" * 100)

    def c_abs_all(p):
        c1 = np.array(p["sd1_curve"])
        c2 = np.array(p["sd2_curve"])
        return np.nanmax(np.abs(np.abs(c1) - np.abs(c2))) < 1e-6

    def c_abs_01(p):
        c1 = np.array(p["sd1_curve"])
        c2 = np.array(p["sd2_curve"])
        m = (s_vals >= -1) & (s_vals <= 1)
        return np.nanmax(np.abs(np.abs(c1[m]) - np.abs(c2[m]))) < 1e-6

    def c_abs_neg(p):
        c1 = np.array(p["sd1_curve"])
        c2 = np.array(p["sd2_curve"])
        m = s_vals <= 0
        return np.nanmax(np.abs(np.abs(c1[m]) - np.abs(c2[m]))) < 1e-6

    def c_sd_eq_all(p):
        c1 = np.array(p["sd1_curve"])
        c2 = np.array(p["sd2_curve"])
        return np.nanmax(np.abs(c1 - c2)) < 1e-6

    def c_sd_neg_all(p):
        c1 = np.array(p["sd1_curve"])
        c2 = np.array(p["sd2_curve"])
        return np.nanmax(np.abs(c1 + c2)) < 1e-6

    q1_conds = [
        ("|sd1(s)| = |sd2(s)| 对所有 s", c_abs_all),
        ("|sd1(s)| = |sd2(s)| 在 s∈[-1,1]", c_abs_01),
        ("|sd1(s)| = |sd2(s)| 在 s≤0", c_abs_neg),
        ("sd1(s) = sd2(s) 对所有 s", c_sd_eq_all),
        ("sd1(s) = -sd2(s) 对所有 s", c_sd_neg_all),
    ]

    print(f"\n  {'条件':<45} | {'候选':>6} | {'命中':>6} | {'精度':>6} | {'召回':>6}")
    print(f"  {'-'*45}-+-{'-'*6}-+-{'-'*6}-+-{'-'*6}-+-{'-'*6}")
    for name, cond in q1_conds:
        n, h, p, r, f = eval_cond(cond, layer123)
        print(f"  {name:<45} | {n:>6} | {h:>6} | {p:>5.1%} | {r:>5.1%}")

    # --- Q2 ---
    print("\n" + "=" * 100)
    print("Q2. sd1(s) ± sd2(s) = 常数 / 差值恒定")
    print("=" * 100)

    def c_sum_const(p):
        c1 = np.array(p["sd1_curve"])
        c2 = np.array(p["sd2_curve"])
        return np.nanstd(c1 + c2) < 1e-6

    def c_diff_const(p):
        c1 = np.array(p["sd1_curve"])
        c2 = np.array(p["sd2_curve"])
        return np.nanstd(c1 - c2) < 1e-6

    def c_absdiff_const(p):
        c1 = np.array(p["sd1_curve"])
        c2 = np.array(p["sd2_curve"])
        return np.nanstd(np.abs(c1) - np.abs(c2)) < 1e-6

    def c_absdiff_small(p):
        c1 = np.array(p["sd1_curve"])
        c2 = np.array(p["sd2_curve"])
        return np.nanmax(np.abs(np.abs(c1) - np.abs(c2))) < 1e-3

    def c_absdiff_01(p):
        c1 = np.array(p["sd1_curve"])
        c2 = np.array(p["sd2_curve"])
        return np.nanmax(np.abs(np.abs(c1) - np.abs(c2))) < 0.1

    q2_conds = [
        ("sd1(s) + sd2(s) = 常数", c_sum_const),
        ("sd1(s) - sd2(s) = 常数", c_diff_const),
        ("|sd1(s)| - |sd2(s)| = 常数", c_absdiff_const),
        ("max||sd1|-|sd2|| < 1e-3", c_absdiff_small),
        ("max||sd1|-|sd2|| < 0.1", c_absdiff_01),
    ]

    print(f"\n  {'条件':<45} | {'候选':>6} | {'命中':>6} | {'精度':>6} | {'召回':>6}")
    print(f"  {'-'*45}-+-{'-'*6}-+-{'-'*6}-+-{'-'*6}-+-{'-'*6}")
    for name, cond in q2_conds:
        n, h, p, r, f = eval_cond(cond, layer123)
        print(f"  {name:<45} | {n:>6} | {h:>6} | {p:>5.1%} | {r:>5.1%}")

    # --- Q3 ---
    print("\n" + "=" * 100)
    print("Q3. 简并度条件")
    print("=" * 100)

    def c_deg_eq(p):
        return p["deg1"] == p["deg2"]

    def c_deg_eq_all(p):
        c1 = np.array(p["deg1_curve"])
        c2 = np.array(p["deg2_curve"])
        return np.nanmax(np.abs(c1 - c2)) < 1e-6

    def c_deg_both_1(p):
        return p["deg1"] == 1 and p["deg2"] == 1

    def c_deg_both_gt1(p):
        return p["deg1"] > 1 and p["deg2"] > 1

    def c_deg_max_le2(p):
        return max(p["deg1"], p["deg2"]) <= 2

    q3_conds = [
        ("deg1 = deg2 at 0.5", c_deg_eq),
        ("deg1(s) = deg2(s) 对所有 s", c_deg_eq_all),
        ("deg1 = deg2 = 1", c_deg_both_1),
        ("deg1 > 1 且 deg2 > 1", c_deg_both_gt1),
        ("max(deg1, deg2) ≤ 2", c_deg_max_le2),
    ]

    print(f"\n  {'条件':<45} | {'候选':>6} | {'命中':>6} | {'精度':>6} | {'召回':>6}")
    print(f"  {'-'*45}-+-{'-'*6}-+-{'-'*6}-+-{'-'*6}-+-{'-'*6}")
    for name, cond in q3_conds:
        n, h, p, r, f = eval_cond(cond, layer123)
        print(f"  {name:<45} | {n:>6} | {h:>6} | {p:>5.1%} | {r:>5.1%}")

    # --- Q4 ---
    print("\n" + "=" * 100)
    print("Q4. S 曲线 / pS 曲线 条件")
    print("=" * 100)

    def c_S_eq_all(p):
        c1 = np.array(p["S1_curve"])
        c2 = np.array(p["S2_curve"])
        return np.nanmax(np.abs(c1 - c2)) < 1e-6

    def c_pS_eq_all(p):
        c1 = np.array(p["pS1_curve"])
        c2 = np.array(p["pS2_curve"])
        return np.nanmax(np.abs(c1 - c2)) < 1e-6

    def c_pS_eq_01(p):
        c1 = np.array(p["pS1_curve"])
        c2 = np.array(p["pS2_curve"])
        m = (s_vals >= -1) & (s_vals <= 1)
        return np.nanmax(np.abs(c1[m] - c2[m])) < 1e-6

    def c_pS_cross_05(p):
        c1 = np.array(p["pS1_curve"])
        c2 = np.array(p["pS2_curve"])
        return abs(c1[s_idx_05] - 0.5) < 1e-6 and abs(c2[s_idx_05] - 0.5) < 1e-6

    q4_conds = [
        ("S1(s) = S2(s) 对所有 s", c_S_eq_all),
        ("pS1(s) = pS2(s) 对所有 s", c_pS_eq_all),
        ("pS1(s) = pS2(s) 在 s∈[-1,1]", c_pS_eq_01),
        ("pS1@0.5 = pS2@0.5 = 0.5", c_pS_cross_05),
    ]

    print(f"\n  {'条件':<45} | {'候选':>6} | {'命中':>6} | {'精度':>6} | {'召回':>6}")
    print(f"  {'-'*45}-+-{'-'*6}-+-{'-'*6}-+-{'-'*6}-+-{'-'*6}")
    for name, cond in q4_conds:
        n, h, p, r, f = eval_cond(cond, layer123)
        print(f"  {name:<45} | {n:>6} | {h:>6} | {p:>5.1%} | {r:>5.1%}")

    # --- Q5 ---
    print("\n" + "=" * 100)
    print("Q5. 组合条件 + 按 F1 排序")
    print("=" * 100)

    all_conds = (
        [(f"Q1:{n}", c) for n, c in q1_conds] +
        [(f"Q2:{n}", c) for n, c in q2_conds] +
        [(f"Q3:{n}", c) for n, c in q3_conds] +
        [(f"Q4:{n}", c) for n, c in q4_conds]
    )

    # 手工组合
    def c_abs_and_deg1(p):
        c1 = np.array(p["sd1_curve"])
        c2 = np.array(p["sd2_curve"])
        return (np.nanmax(np.abs(np.abs(c1) - np.abs(c2))) < 1e-6
                and p["deg1"] == p["deg2"])

    def c_pS_eq_and_deg1(p):
        c1 = np.array(p["pS1_curve"])
        c2 = np.array(p["pS2_curve"])
        return (np.nanmax(np.abs(c1 - c2)) < 1e-6
                and p["deg1"] == p["deg2"])

    all_conds.append(("Comb: |sd| equal all s & deg1=deg2", c_abs_and_deg1))
    all_conds.append(("Comb: pS equal all s & deg1=deg2", c_pS_eq_and_deg1))

    results = []
    for name, cond in all_conds:
        n, h, p, r, f = eval_cond(cond, layer123)
        results.append((name, n, h, p, r, f))

    results.sort(key=lambda x: -x[5])

    print(f"\n  {'条件':<50} | {'候选':>6} | {'命中':>5} | {'精度':>6} | {'召回':>6} | {'F1':>6}")
    print(f"  {'-'*50}-+-{'-'*6}-+-{'-'*5}-+-{'-'*6}-+-{'-'*6}-+-{'-'*6}")
    for name, nc, nh, p, r, f in results[:15]:
        print(f"  {name:<50} | {nc:>6} | {nh:>5} | {p:>5.1%} | {r:>5.1%} | {f:>5.1%}")

    # ============================================================
    # 深度追问：47 个同响应对的 S=0 / S=1 分解
    # ============================================================
    print("\n" + "=" * 100)
    print("深度追问：47 个同响应对按 S 值分解")
    print("=" * 100)

    same_pairs = [p for p in all_pairs if p["n_true"] > 0]
    same_S0 = [p for p in same_pairs if p["S1"] < 0.5]
    same_S1 = [p for p in same_pairs if p["S1"] > 0.5]
    print(f"\n  同响应 47 对: S=0 → {len(same_S0)}, S=1 → {len(same_S1)}")

    for name, group in [("S=0", same_S0), ("S=1", same_S1)]:
        print(f"\n  --- {name} 分支（{len(group)} 对）---")
        print(f"  {'gid':>4} | {'e1':>8} | {'e2':>8} | {'n_true':>6} | "
              f"{'sd1@0.5':>10} | {'sd2@0.5':>10} | {'deg1':>5} | {'deg2':>5}")
        print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*8}-+-{'-'*6}-+-"
              f"{'-'*10}-+-{'-'*10}-+-{'-'*5}-+-{'-'*5}")
        for p in sorted(group, key=lambda x: (x["gid"], x["e1"])):
            print(f"  {p['gid']:>4} | {str(p['e1']):>8} | {str(p['e2']):>8} | "
                  f"{p['n_true']:>6} | {p['sd1@0.5']:>10.4f} | "
                  f"{p['sd2@0.5']:>10.4f} | {p['deg1']:>5.0f} | {p['deg2']:>5.0f}")

    # ============================================================
    # 导出
    # ============================================================
    out = {
        "n_layer123": len(layer123),
        "n_same_in_layer123": n_same_123,
        "n_diff_in_layer123": n_diff_123,
        "n_S0_layer123": len(S0_candidates),
        "n_S1_layer123": len(S1_candidates),
        "top_conditions": [
            {"name": n, "n_candidates": nc, "n_hits": nh,
             "precision": p, "recall": r, "f1": f}
            for n, nc, nh, p, r, f in results[:15]
        ],
    }
    out_path = os.path.join(WORK_DIR, "照妖镜_v32_下一层.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("v32.0 完成。")
    print("=" * 100)


if __name__ == "__main__":
    main()