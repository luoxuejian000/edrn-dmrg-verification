#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
四种相互作用对比：修正版
============================

修正点：
- 只枚举 N=6 的 112 个连通图，不再枚举 26704 个图。
- 用暴力枚举自同构（N=6 可行），不再用 GraphMatcher。
- 对四种相互作用：heisenberg, xxz, ising, xy 并排比较。

运行：
    python 四种相互作用对比_修正版.py
"""

import sys
import io
import json
import itertools
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from collections import defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)


I2 = np.eye(2, dtype=complex)
SX = np.array([[0, 1], [1, 0]], dtype=complex)
SY = np.array([[0, -1j], [1j, 0]], dtype=complex)
SZ = np.array([[1, 0], [0, -1]], dtype=complex)


def op_on_site(op, site, N):
    ops = [I2] * N
    ops[site] = op
    out = ops[0]
    for o in ops[1:]:
        out = np.kron(out, o)
    return out


def build_site_ops(N):
    return ([op_on_site(SX, i, N) for i in range(N)],
            [op_on_site(SY, i, N) for i in range(N)],
            [op_on_site(SZ, i, N) for i in range(N)])


def edge_matrix(i, j, SX_ops, SY_ops, SZ_ops, rule="heisenberg", delta=1.0):
    if rule == "heisenberg":
        return SX_ops[i] @ SX_ops[j] + SY_ops[i] @ SY_ops[j] + SZ_ops[i] @ SZ_ops[j]
    elif rule == "xxz":
        return SX_ops[i] @ SX_ops[j] + SY_ops[i] @ SY_ops[j] + delta * (SZ_ops[i] @ SZ_ops[j])
    elif rule == "ising":
        return SZ_ops[i] @ SZ_ops[j]
    elif rule == "xy":
        return SX_ops[i] @ SX_ops[j] + SY_ops[i] @ SY_ops[j]
    else:
        raise ValueError(f"未知规则: {rule}")


def ground_state_density(H, tol=1e-8):
    evals, evecs = eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < tol))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    return E0, rho, deg


def edge_correlations(rho, edges, SZ_ops):
    C = {}
    for (i, j) in edges:
        op = SZ_ops[i] @ SZ_ops[j]
        C[(i, j)] = float(np.real(np.trace(rho @ op)))
    return C


def compute_sorted_curve(G, defect_edge, s_vals, SX_ops, SY_ops, SZ_ops,
                         rule="heisenberg", delta=1.0):
    N = G.number_of_nodes()
    edges = [tuple(sorted(e)) for e in G.edges()]
    H_edges = {e: edge_matrix(e[0], e[1], SX_ops, SY_ops, SZ_ops, rule, delta)
               for e in edges}
    H0 = sum(H_edges.values())
    M_defect = H_edges[defect_edge]
    curve = []
    for s in s_vals:
        H = H0 + (s - 1.0) * M_defect
        E0, rho, deg = ground_state_density(H)
        C = edge_correlations(rho, edges, SZ_ops)
        curve.append(tuple(np.round(sorted(C.values()), 12)))
    return curve


def find_automorphisms(G):
    """暴力枚举 N=6 的所有自同构。"""
    nodes = list(G.nodes())
    adj = nx.to_numpy_array(G)
    perms = []
    for p in itertools.permutations(nodes):
        P = np.zeros((len(nodes), len(nodes)))
        for i, pi in enumerate(p):
            P[i, pi] = 1
        if np.allclose(P @ adj @ P.T, adj):
            perms.append(p)
    return perms


def find_edge_orbits(G):
    nodes = list(G.nodes())
    edges = [tuple(sorted(e)) for e in G.edges()]
    perms = find_automorphisms(G)
    orbit_id = {e: None for e in edges}
    oid = 0
    for e in edges:
        if orbit_id[e] is not None:
            continue
        orbit_id[e] = oid
        for p in perms:
            mapping = {nodes[i]: p[i] for i in range(len(nodes))}
            e2 = tuple(sorted((mapping[e[0]], mapping[e[1]])))
            if G.has_edge(*e2):
                orbit_id[e2] = oid
        oid += 1
    return orbit_id


def find_involution_pairs(G):
    nodes = list(G.nodes())
    edges = [tuple(sorted(e)) for e in G.edges()]
    perms = find_automorphisms(G)
    pairs = set()
    for p in perms:
        # 检查对合
        if not all(p[p[i]] == i for i in range(len(p))):
            continue
        if all(p[i] == i for i in range(len(p))):
            continue
        mapping = {i: p[i] for i in range(len(p))}
        for e in edges:
            e2 = tuple(sorted((mapping[e[0]], mapping[e[1]])))
            if e2 != e and G.has_edge(*e2):
                pairs.add(tuple(sorted([e, e2])))
    return pairs


def get_112_connected_graphs():
    """返回 N=6 的 112 个连通图。"""
    atlas = nx.graph_atlas_g()
    graphs = [G for G in atlas if G.number_of_nodes() == 6 and nx.is_connected(G)]
    return graphs


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--rules", type=str, nargs="+",
                        default=["heisenberg", "xxz", "ising", "xy"])
    parser.add_argument("--delta", type=float, default=1.0)
    parser.add_argument("--out", type=str, default="四种相互作用结果_修正版.json")
    args = parser.parse_args()

    s_vals = np.linspace(-1.5, 0.0, 11)
    print("=" * 78)
    print("  四种相互作用对比（修正版，只枚举 112 个连通图）")
    print("=" * 78)
    print(f"  规则: {args.rules}")
    print(f"  s: [{s_vals[0]}, {s_vals[-1]}], {len(s_vals)} 点")
    print()

    graphs = get_112_connected_graphs()
    print(f"  N=6 连通图总数: {len(graphs)}")
    if len(graphs) != 112:
        print(f"  ⚠ 警告: 预期 112 个连通图，实际得到 {len(graphs)} 个")
    print()

    SX_ops, SY_ops, SZ_ops = build_site_ops(6)

    # 预计算自同构轨道和对合像（与模型无关）
    graph_data = []
    for gid, G in enumerate(graphs):
        orbits = find_edge_orbits(G)
        involution_pairs = find_involution_pairs(G)
        edges = [tuple(sorted(e)) for e in G.edges()]
        graph_data.append({
            "gid": gid, "G": G, "edges": edges,
            "orbits": orbits, "involution_pairs": involution_pairs,
        })
    print(f"  预计算完成：{len(graph_data)} 个图")
    print()

    all_results = {}

    for rule in args.rules:
        print("=" * 78)
        print(f"  规则: {rule}")
        print("=" * 78)

        same_orbit_same = 0
        same_orbit_diff = 0
        diff_orbit_same = 0
        diff_orbit_diff = 0
        involution_match = 0
        involution_mismatch = 0

        for gd in graph_data:
            G = gd["G"]
            edges = gd["edges"]
            orbits = gd["orbits"]
            involution_pairs = gd["involution_pairs"]

            curves = {}
            for e in edges:
                curves[e] = compute_sorted_curve(G, e, s_vals,
                                                 SX_ops, SY_ops, SZ_ops,
                                                 rule, args.delta)

            for i, e1 in enumerate(edges):
                for j in range(i + 1, len(edges)):
                    e2 = edges[j]
                    same = all(
                        len(a) == len(b) and np.allclose(a, b, atol=1e-10)
                        for a, b in zip(curves[e1], curves[e2])
                    )
                    same_orbit = (orbits[e1] == orbits[e2])
                    is_inv = tuple(sorted([e1, e2])) in involution_pairs

                    if same_orbit and same:
                        same_orbit_same += 1
                    elif same_orbit and not same:
                        same_orbit_diff += 1
                    elif not same_orbit and same:
                        diff_orbit_same += 1
                        if is_inv:
                            involution_match += 1
                        else:
                            involution_mismatch += 1
                    else:
                        diff_orbit_diff += 1

        print(f"  同轨道同曲线: {same_orbit_same}")
        print(f"  同轨道异曲线: {same_orbit_diff}")
        print(f"  异轨道同曲线: {diff_orbit_same}")
        print(f"  异轨道异曲线: {diff_orbit_diff}")
        print(f"  异轨道同曲线中，是对合像: {involution_match}")
        print(f"  异轨道同曲线中，不是对合像: {involution_mismatch}")
        print()

        all_results[rule] = {
            "same_orbit_same": same_orbit_same,
            "same_orbit_diff": same_orbit_diff,
            "diff_orbit_same": diff_orbit_same,
            "diff_orbit_diff": diff_orbit_diff,
            "involution_match": involution_match,
            "involution_mismatch": involution_mismatch,
        }

    # 并排输出
    print("=" * 78)
    print("  并排：四种相互作用下的核心数据")
    print("=" * 78)
    print()
    print(f"  {'规则':<14}{'同轨道同':<12}{'同轨道异':<12}{'异轨道同':<12}"
          f"{'异轨道异':<12}{'对合匹配':<12}{'对合不匹配':<12}")
    print(f"  {'-'*14}{'-'*12}{'-'*12}{'-'*12}{'-'*12}{'-'*12}{'-'*12}")
    for rule, r in all_results.items():
        print(f"  {rule:<14}{r['same_orbit_same']:<12}{r['same_orbit_diff']:<12}"
              f"{r['diff_orbit_same']:<12}{r['diff_orbit_diff']:<12}"
              f"{r['involution_match']:<12}{r['involution_mismatch']:<12}")
    print()

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(all_results, f, ensure_ascii=False, indent=2, default=str)
    print(f"已保存: {args.out}")


if __name__ == "__main__":
    main()