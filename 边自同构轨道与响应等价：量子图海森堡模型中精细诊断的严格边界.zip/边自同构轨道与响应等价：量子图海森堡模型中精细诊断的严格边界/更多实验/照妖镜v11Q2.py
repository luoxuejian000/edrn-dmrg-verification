#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 v11-Q2：简并子空间的 S_z 分布（独立脚本）
================================================================

目标：
  对每个谐振点（s(p_S=1/2)），输出简并基态子空间中：
  - 每个简并态的 <S_z>
  - 每个简并态的 <S²>
  - 每个简并态的总自旋 S
  - 简并子空间的 S_z 分布结构

修复：
  v11 中 `float(np.real(v.conj().T @ A @ v))` 因为 v 是 (dim,1)，
  返回 (1,1) 数组，float() 报错。改用 `[0, 0]` 取标量。

晶脉哲学：
  · 关系本体论：S_z 是关系网络中的全局方向量
  · 对象化=截断=产生方向：每个简并态都是一个截断
  · 只查同与不同：不筛选，不排序
"""

import sys, io, itertools, json, os
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from scipy.optimize import brentq
from collections import Counter, defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"
N = 6


# ============================================================
# 自旋算符
# ============================================================

I2 = np.eye(2, dtype=complex)
SX = np.array([[0,1],[1,0]], dtype=complex)
SY = np.array([[0,-1j],[1j,0]], dtype=complex)
SZ = np.array([[1,0],[0,-1]], dtype=complex)


def op_on_site(op, site, N):
    ops = [I2]*N; ops[site] = op
    out = ops[0]
    for o in ops[1:]: out = np.kron(out, o)
    return out


def build_site_ops(N):
    return ([op_on_site(SX,i,N) for i in range(N)],
            [op_on_site(SY,i,N) for i in range(N)],
            [op_on_site(SZ,i,N) for i in range(N)])


def edge_matrix(i, j, SXo, SYo, SZo):
    return SXo[i]@SXo[j] + SYo[i]@SYo[j] + SZo[i]@SZo[j]


def partial_trace_2sites(rho, i, j, N):
    dims = [2]*N
    rho_t = rho.reshape(dims + dims)
    perm = []
    for k in [i, j]: perm.append(k)
    for k in range(N):
        if k not in (i, j): perm.append(k)
    for k in [i, j]: perm.append(N+k)
    for k in range(N):
        if k not in (i, j): perm.append(N+k)
    rho_p = np.transpose(rho_t, perm)
    d_keep = 4
    d_trace = 2**(N-2)
    rho_r = rho_p.reshape(d_keep, d_trace, d_keep, d_trace)
    return np.trace(rho_r, axis1=1, axis2=3)


def sz_expect(v):
    """给定单个态向量 v (dim,)，返回 <S_z> 期望值"""
    # 这里 v 是列向量，需要先转成 1D
    v_flat = v.reshape(-1)
    return float(np.real(v_flat.conj() @ Sz_total @ v_flat))


# ============================================================
# 从 v5.1 加载同响应对
# ============================================================

def load_same_response_pairs():
    with open(os.path.join(WORK_DIR, "照妖镜_v5_1_模式.json"), "r",
              encoding="utf-8") as f:
        v51 = json.load(f)
    pairs = set()
    for key, s in v51["patterns"].items():
        gid, e1_str, e2_str = key.split("_", 2)
        gid = int(gid)
        e1 = tuple(map(int, e1_str.strip("()").split(",")))
        e2 = tuple(map(int, e2_str.strip("()").split(",")))
        pairs.add((gid, e1, e2))
    return pairs


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 100)
    print("照妖镜 v11-Q2：简并子空间的 S_z 分布")
    print("=" * 100)

    # 图集
    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    print(f"\n  图集: {len(graphs)} 个 N=6 连通图")

    same_pairs = load_same_response_pairs()
    defect_edges = set()
    for gid, e1, e2 in same_pairs:
        defect_edges.add((gid, e1))
        defect_edges.add((gid, e2))
    print(f"  缺陷边: {len(defect_edges)}")

    SXo, SYo, SZo = build_site_ops(N)

    # 全局 S_z 和 S² 算符（这里是 6 自旋的空间）
    global Sz_total
    Sz_total = sum(SZo)
    # S² 算符
    dim = 2**N
    S2_total = np.zeros((dim, dim), dtype=complex)
    for i in range(N):
        for j in range(N):
            if i == j:
                S2_total += 3/4 * np.eye(dim, dtype=complex)
            else:
                S2_total += 1/4 * (SXo[i]@SXo[j] + SYo[i]@SYo[j] + SZo[i]@SZo[j])

    # 精确定位 s(p_S=1/2)
    print(f"\n  精确定位 s(p_S = 1/2)…")
    coarse_s = np.linspace(0.0, 2.5, 501)
    resonances = []

    for gid, defect in sorted(defect_edges):
        G = graphs[gid]
        edges = [tuple(sorted(e)) for e in G.edges()]
        H_edges = [edge_matrix(e[0], e[1], SXo, SYo, SZo) for e in edges]

        def pS_at_s(s):
            couplings = [s if e == defect else 1.0 for e in edges]
            H = sum(c*M for c, M in zip(couplings, H_edges))
            evals, evecs = eigh(H)
            E0 = evals[0]
            deg = int(np.sum(np.abs(evals - E0) < 1e-8))
            V = evecs[:, :deg]
            rho = V @ V.conj().T / deg
            rho_ij = partial_trace_2sites(rho, defect[0], defect[1], N)
            return 0.5 * (rho_ij[1,1].real - rho_ij[1,2].real
                         - rho_ij[2,1].real + rho_ij[2,2].real)

        pS_vals = np.array([pS_at_s(s) for s in coarse_s])
        for i in range(len(coarse_s) - 1):
            if (pS_vals[i] - 0.5) * (pS_vals[i+1] - 0.5) < 0:
                try:
                    s_exact = brentq(lambda s: pS_at_s(s) - 0.5,
                                     coarse_s[i], coarse_s[i+1], xtol=1e-13)
                    resonances.append((gid, defect, s_exact))
                except Exception:
                    pass

    print(f"  谐振点: {len(resonances)}")

    # ============================================================
    # Q2: 每个简并态的 <S_z> 和 <S²>
    # ============================================================
    print("\n" + "=" * 100)
    print("Q2. 简并子空间的 S_z 分布")
    print("=" * 100)

    print(f"\n  {'gid':>4} | {'defect':>8} | {'s':>10} | {'简并':>4} | {'各态 <S_z>':>40} | {'各态 S':>20}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*10}-+-{'-'*4}-+-{'-'*40}-+-{'-'*20}")

    sz_data = []
    for gid, defect, s in sorted(resonances):
        G = graphs[gid]
        edges = [tuple(sorted(e)) for e in G.edges()]
        H_edges = [edge_matrix(e[0], e[1], SXo, SYo, SZo) for e in edges]
        couplings = [s if e == defect else 1.0 for e in edges]
        H = sum(c*M for c, M in zip(couplings, H_edges))
        evals, evecs = eigh(H)
        E0 = evals[0]
        deg = int(np.sum(np.abs(evals - E0) < 1e-8))
        V = evecs[:, :deg]

        # 每个简并态的 <S_z> 和 <S²>
        sz_vals = []
        s2_vals = []
        s_vals = []
        for k in range(deg):
            v = V[:, k]
            # <S_z>
            sz = float(np.real(v.conj() @ Sz_total @ v))
            # <S²>
            s2 = float(np.real(v.conj() @ S2_total @ v))
            # S 从 S² 反推：S(S+1) = <S²> → S = (-1+sqrt(1+4<S²>))/2
            S_val = (-1 + np.sqrt(1 + 4 * max(s2, 0))) / 2
            sz_vals.append(sz)
            s2_vals.append(s2)
            s_vals.append(S_val)

        sz_str = ", ".join(f"{v:>+.4f}" for v in sz_vals[:6])
        if len(sz_vals) > 6:
            sz_str += f", ... (+{len(sz_vals)-6})"
        s_str = ", ".join(f"{v:.4f}" for v in s_vals[:6])
        if len(s_vals) > 6:
            s_str += f", ..."

        print(f"  {gid:>4} | {str(defect):>8} | {s:>10.6f} | {deg:>4} | "
              f"{sz_str:>40} | {s_str:>20}")

        sz_data.append({
            "gid": gid, "defect": defect, "s": s, "deg": deg,
            "sz_vals": sz_vals, "s2_vals": s2_vals, "s_vals": s_vals,
        })

    # ============================================================
    # 分析：S_z 分布的规律
    # ============================================================
    print("\n" + "=" * 100)
    print("S_z 分布分析")
    print("=" * 100)

    # 1. 简并态的 <S_z> 是否全为 0？
    all_sz_zero = all(all(abs(v) < 1e-10 for v in d["sz_vals"])
                      for d in sz_data)
    print(f"\n  所有简并态的 <S_z> 全为 0：{all_sz_zero}")

    # 2. S_z 的分布类型
    print(f"\n  --- S_z 分布类型 ---")
    for d in sz_data:
        if d["deg"] == 1:
            continue
        sz_vals = d["sz_vals"]
        # 分类
        n_zero = sum(1 for v in sz_vals if abs(v) < 1e-10)
        n_pos = sum(1 for v in sz_vals if v > 1e-10)
        n_neg = sum(1 for v in sz_vals if v < -1e-10)
        if n_zero == len(sz_vals):
            typ = "全零（单态扇区）"
        elif n_zero > 0:
            typ = f"混合（{n_zero}零, {n_pos}正, {n_neg}负）"
        else:
            typ = f"非零（{n_pos}正, {n_neg}负）"
        print(f"  gid={d['gid']}, defect={d['defect']}, deg={d['deg']}: {typ}")

    # ============================================================
    # 分析：S 值的分布
    # ============================================================
    print("\n" + "=" * 100)
    print("总自旋 S 分布分析")
    print("=" * 100)

    print(f"\n  {'gid':>4} | {'defect':>8} | {'s':>10} | {'简并':>4} | {'总 S':>8} | {'每个态的 S':>30}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*10}-+-{'-'*4}-+-{'-'*8}-+-{'-'*30}")

    for d in sz_data:
        # 总 S = max(S_z)？不，是 S(S+1) 的 S
        # 用整个简并子空间的 <S²> 平均
        # 简化：用最大的 S 值（如果简并子空间是纯多重态）
        s_str = ", ".join(f"{v:.4f}" for v in d["s_vals"][:6])
        if len(d["s_vals"]) > 6:
            s_str += f", ..."
        # 总 S（取平均）
        S_total = np.mean(d["s_vals"])
        print(f"  {d['gid']:>4} | {str(d['defect']):>8} | {d['s']:>10.6f} | "
              f"{d['deg']:>4} | {S_total:>8.4f} | {s_str:>30}")

    # ============================================================
    # 交叉分析：S 类型 vs 简并度 vs sigdot 值
    # ============================================================
    print("\n" + "=" * 100)
    print("交叉分析：S 类型 vs 简并度")
    print("=" * 100)

    print(f"\n  {'简并度':>8} | {'数量':>6} | {'S 均值':>8} | {'S 范围':>20}")
    print(f"  {'-'*8}-+-{'-'*6}-+-{'-'*8}-+-{'-'*20}")

    by_deg = defaultdict(list)
    for d in sz_data:
        by_deg[d["deg"]].append(d)

    for deg_val in sorted(by_deg.keys()):
        items = by_deg[deg_val]
        all_S = [v for d in items for v in d["s_vals"]]
        print(f"  {deg_val:>8} | {len(items):>6} | {np.mean(all_S):>8.4f} | "
              f"[{np.min(all_S):.4f}, {np.max(all_S):.4f}]")

    # ============================================================
    # 导出
    # ============================================================
    out = {
        "resonances": [
            {"gid": d["gid"], "defect": list(d["defect"]), "s": d["s"],
             "deg": d["deg"], "sz_vals": d["sz_vals"],
             "s2_vals": d["s2_vals"], "s_vals": d["s_vals"]}
            for d in sz_data
        ],
        "all_sz_zero": all_sz_zero,
    }
    out_path = os.path.join(WORK_DIR, "照妖镜_v11Q2_Sz分布.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("v11-Q2 完成。简并子空间的 S_z 分布被画出。")
    print("=" * 100)


if __name__ == "__main__":
    main()