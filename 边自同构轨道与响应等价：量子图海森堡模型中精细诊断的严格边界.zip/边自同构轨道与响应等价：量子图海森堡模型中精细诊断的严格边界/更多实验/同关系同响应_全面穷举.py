#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
同关系（状态）同响应：全面穷举与画像
========================================

核心命题：
    同关系（状态）⟹ 同响应。

追问：
    1. 什么是“关系状态”？它是单一边的特征，还是整个图的全局模式？
    2. 存在某个关系特征，使得“特征相同 ⟺ 响应相同”吗？
    3. 如果不存在单一特征，那特征组合呢？
    4. N=6 和 N=7 上，答案一样吗？
    5. 四种相互作用下，答案一样吗？

方法：
    穷举 N=6 和 N=7 的全部连通图。
    对每条边，计算响应曲线 + 所有可能的关系特征。
    对每一对边，检查：
        - 响应相同吗？
        - 每个关系特征相同吗？
    统计：特征相同与响应相同的相关性。
    找出能完美匹配“响应相同”的关系特征。

原则：
    只查同与不同。不拟合，不回归，不预设。
    标准物理与关系本体论并排。
    数据说话，只要真相。

运行：
    python 同关系同响应_全面穷举.py
    python 同关系同响应_全面穷举.py --N 6 --rules heisenberg
    python 同关系同响应_全面穷举.py --N 6 7 --rules heisenberg xxz ising xy
"""

import sys
import io
import json
import itertools
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from collections import defaultdict, Counter
from networkx.algorithms.isomorphism import GraphMatcher

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)


I2 = np.eye(2, dtype=complex)
SX = np.array([[0, 1], [1, 0]], dtype=complex)
SY = np.array([[0, -1j], [1j, 0]], dtype=complex)
SZ = np.array([[1, 0], [0, -1]], dtype=complex)


# ============================================================
# 基础工具
# ============================================================

def op_on_site(op, site, N):
    ops = [I2] * N
    ops[site] = op
    out = ops[0]
    for o in ops[1:]:
        out = np.kron(out, o)
    return out


def build_site_ops(N):
    return ([op_on_site(SX, i, N) for i in range(N)],
            [op_on_site(SY, i, N) for i in range(N)],
            [op_on_site(SZ, i, N) for i in range(N)])


def edge_matrix(i, j, SX_ops, SY_ops, SZ_ops, rule="heisenberg", delta=1.0):
    if rule == "heisenberg":
        return SX_ops[i] @ SX_ops[j] + SY_ops[i] @ SY_ops[j] + SZ_ops[i] @ SZ_ops[j]
    elif rule == "xxz":
        return SX_ops[i] @ SX_ops[j] + SY_ops[i] @ SY_ops[j] + delta * (SZ_ops[i] @ SZ_ops[j])
    elif rule == "ising":
        return SZ_ops[i] @ SZ_ops[j]
    elif rule == "xy":
        return SX_ops[i] @ SX_ops[j] + SY_ops[i] @ SY_ops[j]
    raise ValueError(f"未知规则: {rule}")


def ground_state_density(H, tol=1e-8):
    evals, evecs = eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < tol))
    V = evecs[:, :deg]
    rho = V @ V.conj().T / deg
    gap = evals[deg] - E0 if deg < len(evals) else 0.0
    return E0, gap, rho, deg


def edge_correlations(rho, edges, SZ_ops):
    C = {}
    for (i, j) in edges:
        op = SZ_ops[i] @ SZ_ops[j]
        C[(i, j)] = float(np.real(np.trace(rho @ op)))
    return C


def compute_response_curve(G, defect_edge, s_vals, SX_ops, SY_ops, SZ_ops,
                           rule="heisenberg", delta=1.0):
    """计算排序关联分布曲线（响应）。"""
    N = G.number_of_nodes()
    edges = [tuple(sorted(e)) for e in G.edges()]
    H_edges = {e: edge_matrix(e[0], e[1], SX_ops, SY_ops, SZ_ops, rule, delta)
               for e in edges}
    H0 = sum(H_edges.values())
    M_defect = H_edges[defect_edge]
    curve = []
    for s in s_vals:
        H = H0 + (s - 1.0) * M_defect
        E0, gap, rho, deg = ground_state_density(H)
        C = edge_correlations(rho, edges, SZ_ops)
        curve.append(tuple(np.round(sorted(C.values()), 12)))
    return curve


# ============================================================
# 关系特征（穷举）
# ============================================================

def relation_features(G, edge):
    """
    穷举一条边的所有关系特征。
    这是“关系状态”的候选。
    """
    u, v = edge
    edges = [tuple(sorted(e)) for e in G.edges()]
    N = G.number_of_nodes()

    # 局部特征
    deg_u = G.degree(u)
    deg_v = G.degree(v)
    H = G.copy()
    H.remove_edge(u, v)
    is_bridge = not nx.is_connected(H)
    common_neighbors = len(set(G.neighbors(u)) & set(G.neighbors(v)))
    neighbors_u = [G.degree(w) for w in G.neighbors(u) if w != v]
    neighbors_v = [G.degree(w) for w in G.neighbors(v) if w != u]
    neighbor_deg_seq = tuple(sorted(neighbors_u + neighbors_v))

    # 二跳子图
    two_hop = set()
    for w in G.neighbors(u):
        if w != v:
            two_hop.add(G.degree(w))
    for w in G.neighbors(v):
        if w != u:
            two_hop.add(G.degree(w))
    two_hop_deg_seq = tuple(sorted(two_hop))

    # 全局位置
    try:
        ecc_u = nx.eccentricity(G, u)
        ecc_v = nx.eccentricity(G, v)
        ecc_sum = ecc_u + ecc_v
    except Exception:
        ecc_sum = 0
    try:
        edge_bc = nx.edge_betweenness_centrality(G)
        bc = edge_bc.get((u, v), edge_bc.get((v, u), 0.0))
    except Exception:
        bc = 0.0
    cc_sum = nx.clustering(G, u) + nx.clustering(G, v)

    # 删除后
    components_after_del = nx.number_connected_components(H)
    if nx.is_connected(H):
        try:
            diameter_after_del = nx.diameter(H)
        except Exception:
            diameter_after_del = -1
    else:
        diameter_after_del = -1

    # 收缩后
    try:
        G_contracted = nx.contracted_edge(G, edge, self_loops=False)
        contraction_deg_seq = tuple(sorted(dict(G_contracted.degree()).values()))
        try:
            diameter_after_contract = nx.diameter(G_contracted)
        except Exception:
            diameter_after_contract = -1
    except Exception:
        contraction_deg_seq = ()
        diameter_after_contract = -1

    # 环参与
    cycle_lengths = []
    try:
        cycles = nx.cycle_basis(G)
        for cycle in cycles:
            cycle_edges = []
            for i in range(len(cycle)):
                e = tuple(sorted((cycle[i], cycle[(i + 1) % len(cycle)])))
                cycle_edges.append(e)
            if tuple(sorted(edge)) in cycle_edges:
                cycle_lengths.append(len(cycle))
    except Exception:
        pass
    cycle_lengths = tuple(sorted(cycle_lengths))

    # 轨道特征
    try:
        orbits = find_edge_orbits_fast(G)
        orbit_id = orbits[edge]
        orbit_size = sum(1 for e in edges if orbits[e] == orbit_id)
    except Exception:
        orbit_id = -1
        orbit_size = -1

    # 对合特征
    try:
        inv_pairs = find_involution_pairs_fast(G)
        is_involution_image = any(
            tuple(sorted([edge, e2])) in inv_pairs
            for e1, e2 in inv_pairs if e1 == edge or e2 == edge
        )
        n_involution_pairs = len(inv_pairs)
    except Exception:
        is_involution_image = False
        n_involution_pairs = -1

    # 全局图特征
    L = nx.laplacian_matrix(G).toarray().astype(float)
    evals_L = np.sort(np.linalg.eigvalsh(L))
    spectral_gap = float(evals_L[1] - evals_L[0]) if len(evals_L) > 1 else 0.0
    spectral_max = float(evals_L[-1]) if len(evals_L) > 0 else 0.0

    return {
        # 局部
        "deg_pair": tuple(sorted([deg_u, deg_v])),
        "is_bridge": is_bridge,
        "common_neighbors": common_neighbors,
        "neighbor_deg_seq": neighbor_deg_seq,
        "two_hop_deg_seq": two_hop_deg_seq,
        # 全局位置
        "ecc_sum": ecc_sum,
        "edge_betweenness": round(bc, 6),
        "cc_sum": round(cc_sum, 6),
        # 删除/收缩
        "components_after_del": components_after_del,
        "diameter_after_del": diameter_after_del,
        "contraction_deg_seq": contraction_deg_seq,
        "diameter_after_contract": diameter_after_contract,
        # 环
        "cycle_lengths": cycle_lengths,
        # 轨道
        "orbit_size": orbit_size,
        "is_involution_image": is_involution_image,
        "n_involution_pairs": n_involution_pairs,
        # 全局谱
        "spectral_gap": round(spectral_gap, 6),
        "spectral_max": round(spectral_max, 6),
    }


# ============================================================
# 自同构与对合（快速版）
# ============================================================

def find_edge_orbits_fast(G):
    nodes = list(G.nodes())
    edges = [tuple(sorted(e)) for e in G.edges()]
    matcher = GraphMatcher(G, G)
    orbit_id = {e: None for e in edges}
    oid = 0
    for e in edges:
        if orbit_id[e] is not None:
            continue
        orbit_id[e] = oid
        for mapping in matcher.isomorphisms_iter():
            u, v = e
            u2, v2 = mapping[u], mapping[v]
            e2 = tuple(sorted((u2, v2)))
            if G.has_edge(u2, v2):
                orbit_id[e2] = oid
        oid += 1
    return orbit_id


def find_involution_pairs_fast(G):
    nodes = list(G.nodes())
    matcher = GraphMatcher(G, G)
    pairs = set()
    for mapping in matcher.isomorphisms_iter():
        if not all(mapping[mapping[u]] == u for u in nodes):
            continue
        if all(mapping[u] == u for u in nodes):
            continue
        for u, v in G.edges():
            e1 = tuple(sorted((u, v)))
            u2, v2 = mapping[u], mapping[v]
            e2 = tuple(sorted((u2, v2)))
            if e1 != e2 and G.has_edge(u2, v2):
                pairs.add(tuple(sorted([e1, e2])))
    return pairs


# ============================================================
# 图生成
# ============================================================

def get_connected_graphs(N):
    """枚举 N 个节点的所有连通图。"""
    if N == 6:
        atlas = nx.graph_atlas_g()
        return [G for G in atlas
                if G.number_of_nodes() == 6 and nx.is_connected(G)]
    elif N == 7:
        # N=7 有 853 个连通图，用暴力枚举
        all_edges = list(itertools.combinations(range(N), 2))
        graphs = []
        for m in range(N - 1, len(all_edges) + 1):
            for combo in itertools.combinations(all_edges, m):
                G = nx.Graph()
                G.add_nodes_from(range(N))
                G.add_edges_from(combo)
                if nx.is_connected(G):
                    graphs.append(G)
        return graphs
    else:
        raise ValueError(f"N={N} 不支持")


# ============================================================
# 核心分析
# ============================================================

def analyze(N, rule, s_vals):
    """
    对 N 和 rule，穷举所有边，计算响应和关系特征。
    返回所有边的数据。
    """
    print("=" * 78)
    print(f"  N={N}, rule={rule}")
    print("=" * 78)

    graphs = get_connected_graphs(N)
    print(f"  连通图总数: {len(graphs)}")

    SX_ops, SY_ops, SZ_ops = build_site_ops(N)

    all_edges = []
    for gid, G in enumerate(graphs):
        edges = [tuple(sorted(e)) for e in G.edges()]
        orbits = find_edge_orbits_fast(G)
        for e in edges:
            curve = compute_response_curve(G, e, s_vals, SX_ops, SY_ops, SZ_ops,
                                            rule=rule)
            feats = relation_features(G, e)
            feats["orbit_id"] = orbits[e]
            all_edges.append({
                "gid": gid, "edge": e, "curve": curve, "features": feats,
            })
        if (gid + 1) % 100 == 0:
            print(f"    已处理 {gid + 1}/{len(graphs)} 图")

    print(f"  总边数: {len(all_edges)}")
    print()
    return all_edges


def compare_features(all_edges, N, rule):
    """
    对每一对边，检查响应是否相同，每个关系特征是否相同。
    统计特征与响应的相关性。
    """
    # 只比较同一图内的边对
    by_gid = defaultdict(list)
    for idx, ed in enumerate(all_edges):
        by_gid[ed["gid"]].append(idx)

    # 收集所有边对
    pairs = []
    for gid, indices in by_gid.items():
        for i in range(len(indices)):
            for j in range(i + 1, len(indices)):
                pairs.append((indices[i], indices[j]))

    print(f"  总边对数: {len(pairs)}")

    # 对每对，检查响应和特征
    feature_names = None
    results = []
    for i, j in pairs:
        d1 = all_edges[i]
        d2 = all_edges[j]
        if feature_names is None:
            feature_names = list(d1["features"].keys())

        # 响应相同？
        same_response = all(
            len(a) == len(b) and np.allclose(a, b, atol=1e-10)
            for a, b in zip(d1["curve"], d2["curve"])
        )

        # 每个特征相同？
        feat_same = {}
        for fname in feature_names:
            feat_same[fname] = (d1["features"][fname] == d2["features"][fname])

        results.append({
            "same_response": same_response,
            "feat_same": feat_same,
            "same_orbit": d1["features"]["orbit_id"] == d2["features"]["orbit_id"],
        })

    # 统计
    n_pairs = len(results)
    n_same_response = sum(1 for r in results if r["same_response"])
    n_diff_response = n_pairs - n_same_response

    print()
    print(f"  响应相同的边对: {n_same_response}")
    print(f"  响应不同的边对: {n_diff_response}")
    print()

    # 对每个特征，统计：
    # - 特征相同且响应相同（TP）
    # - 特征相同且响应不同（FP）
    # - 特征不同且响应相同（FN）
    # - 特征不同且响应不同（TN）
    print("=" * 78)
    print(f"  特征与响应的相关性（N={N}, rule={rule}）")
    print("=" * 78)
    print()
    print(f"  {'特征':<24}{'TP':<10}{'FP':<10}{'FN':<10}{'TN':<10}"
          f"{'精确率':<10}{'召回率':<10}{'F1':<10}")
    print(f"  {'-'*24}{'-'*10}{'-'*10}{'-'*10}{'-'*10}"
          f"{'-'*10}{'-'*10}{'-'*10}")

    feature_stats = {}
    for fname in feature_names:
        TP = sum(1 for r in results if r["feat_same"][fname] and r["same_response"])
        FP = sum(1 for r in results if r["feat_same"][fname] and not r["same_response"])
        FN = sum(1 for r in results if not r["feat_same"][fname] and r["same_response"])
        TN = sum(1 for r in results if not r["feat_same"][fname] and not r["same_response"])

        precision = TP / (TP + FP) if (TP + FP) > 0 else 0
        recall = TP / (TP + FN) if (TP + FN) > 0 else 0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0

        feature_stats[fname] = {
            "TP": TP, "FP": FP, "FN": FN, "TN": TN,
            "precision": precision, "recall": recall, "f1": f1,
        }

        print(f"  {fname:<24}{TP:<10}{FP:<10}{FN:<10}{TN:<10}"
              f"{precision:<10.4f}{recall:<10.4f}{f1:<10.4f}")

    print()

    # 排序：找 F1 最高的特征
    sorted_features = sorted(feature_stats.items(),
                             key=lambda x: -x[1]["f1"])
    print(f"  按 F1 排序的前 5 个特征：")
    for fname, stats in sorted_features[:5]:
        print(f"    {fname}: F1={stats['f1']:.4f}, "
              f"精确率={stats['precision']:.4f}, 召回率={stats['recall']:.4f}")
    print()

    return feature_stats


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--N", type=int, nargs="+", default=[6])
    parser.add_argument("--rules", type=str, nargs="+",
                        default=["heisenberg"])
    parser.add_argument("--s_min", type=float, default=-1.5)
    parser.add_argument("--s_max", type=float, default=0.0)
    parser.add_argument("--s_steps", type=int, default=11)
    parser.add_argument("--out", type=str, default="同关系同响应结果.json")
    args = parser.parse_args()

    s_vals = np.linspace(args.s_min, args.s_max, args.s_steps)

    print("=" * 78)
    print("  同关系（状态）同响应：全面穷举")
    print("=" * 78)
    print(f"  N: {args.N}")
    print(f"  rules: {args.rules}")
    print(f"  s: [{args.s_min}, {args.s_max}], {args.s_steps} 点")
    print()

    all_results = {}

    for N in args.N:
        for rule in args.rules:
            all_edges = analyze(N, rule, s_vals)
            feature_stats = compare_features(all_edges, N, rule)
            all_results[f"N{N}_{rule}"] = feature_stats

    # ============================================================
    # 并排：跨 N、跨 rule 的 F1 对比
    # ============================================================
    print("=" * 78)
    print("  并排：跨 N、跨 rule 的 F1 对比")
    print("=" * 78)
    print()

    # 收集所有特征名
    all_feature_names = set()
    for key, stats in all_results.items():
        all_feature_names.update(stats.keys())
    all_feature_names = sorted(all_feature_names)

    # 表头
    keys = sorted(all_results.keys())
    header = f"  {'特征':<24}" + "".join(f"{k:<18}" for k in keys)
    print(header)
    print("  " + "-" * (24 + 18 * len(keys)))

    for fname in all_feature_names:
        row = f"  {fname:<24}"
        for k in keys:
            if fname in all_results[k]:
                f1 = all_results[k][fname]["f1"]
                row += f"{f1:<18.4f}"
            else:
                row += f"{'-':<18}"
        print(row)

    print()

    # 找全局最佳
    best_f1 = 0
    best_feature = None
    best_key = None
    for key, stats in all_results.items():
        for fname, s in stats.items():
            if s["f1"] > best_f1:
                best_f1 = s["f1"]
                best_feature = fname
                best_key = key

    print(f"  全局最佳：{best_feature} (在 {best_key})，F1={best_f1:.4f}")
    print()

    # 保存
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(all_results, f, ensure_ascii=False, indent=2, default=str)
    print(f"已保存: {args.out}")


if __name__ == "__main__":
    main()