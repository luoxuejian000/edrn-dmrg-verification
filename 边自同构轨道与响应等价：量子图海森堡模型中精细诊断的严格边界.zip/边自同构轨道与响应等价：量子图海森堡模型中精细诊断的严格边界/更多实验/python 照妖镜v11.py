#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
照妖镜 v11.0：简并基态下的 <σᵢ·σⱼ> 解析结构
================================================================

核心问题：
  非简并基态下 <σᵢ·σⱼ>_defect = -1 精确成立。
  简并基态下，对称化密度矩阵平均后的 <σᵢ·σⱼ>_defect 是什么？
  每个简并态的 <σᵢ·σⱼ> 值是多少？它们的平均为什么 = -1？

五个追问并行：
  Q1. 简并基态的每个简并态的 <σᵢ·σⱼ> 值
  Q2. 简并子空间的 S_z 分布
  Q3. 简并子空间的总自旋 S
  Q4. 非简并 vs 简并的 <σᵢ·σⱼ> 的代数形式
  Q5. 特殊 s 值（0, 0.5, 1.0, 1.5）的几何条件
"""

import sys, io, itertools, json, os
import numpy as np
import networkx as nx
from scipy.linalg import eigh
from scipy.optimize import brentq
from collections import Counter, defaultdict

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  line_buffering=True)

WORK_DIR = r"D:\luoxuejian000\wulihuaxue\关系物理学\边自同构轨道与响应等价：量子图海森堡模型中精细诊断的严格边界\更多实验"
N = 6

I2 = np.eye(2, dtype=complex)
SX = np.array([[0,1],[1,0]], dtype=complex)
SY = np.array([[0,-1j],[1j,0]], dtype=complex)
SZ = np.array([[1,0],[0,-1]], dtype=complex)


def op_on_site(op, site, N):
    ops = [I2]*N; ops[site] = op
    out = ops[0]
    for o in ops[1:]: out = np.kron(out, o)
    return out


def build_site_ops(N):
    return ([op_on_site(SX,i,N) for i in range(N)],
            [op_on_site(SY,i,N) for i in range(N)],
            [op_on_site(SZ,i,N) for i in range(N)])


def edge_matrix(i, j, SXo, SYo, SZo):
    return SXo[i]@SXo[j] + SYo[i]@SYo[j] + SZo[i]@SZo[j]


def partial_trace_2sites(rho, i, j, N):
    dims = [2]*N
    rho_t = rho.reshape(dims + dims)
    perm = []
    for k in [i, j]: perm.append(k)
    for k in range(N):
        if k not in (i, j): perm.append(k)
    for k in [i, j]: perm.append(N+k)
    for k in range(N):
        if k not in (i, j): perm.append(N+k)
    rho_p = np.transpose(rho_t, perm)
    d_keep = 4
    d_trace = 2**(N-2)
    rho_r = rho_p.reshape(d_keep, d_trace, d_keep, d_trace)
    return np.trace(rho_r, axis1=1, axis2=3)


def sigdot_of_rho2(rho_ij):
    sigma_dot = np.array([
        [1, 0, 0, 0],
        [0, -1, 2, 0],
        [0, 2, -1, 0],
        [0, 0, 0, 1]
    ], dtype=complex)
    return float(np.real(np.trace(rho_ij @ sigma_dot)))


def szsz_of_rho2(rho_ij):
    sz_sz = np.array([[1,0,0,0],[0,-1,0,0],[0,0,-1,0],[0,0,0,1]], dtype=complex)
    return float(np.real(np.trace(rho_ij @ sz_sz)))


def load_same_response_pairs():
    with open(os.path.join(WORK_DIR, "照妖镜_v5_1_模式.json"), "r",
              encoding="utf-8") as f:
        v51 = json.load(f)
    pairs = set()
    for key, s in v51["patterns"].items():
        gid, e1_str, e2_str = key.split("_", 2)
        gid = int(gid)
        e1 = tuple(map(int, e1_str.strip("()").split(",")))
        e2 = tuple(map(int, e2_str.strip("()").split(",")))
        pairs.add((gid, e1, e2))
    return pairs


def build_ops_from_full(full_ops, subset):
    """从完整空间的算符切出子集（张量积）"""
    # 简化：用给定节点列表重建
    pass


def total_spin_squared(G, SXo, SYo, SZo):
    """总自旋 S² = Σ_ij S_i · S_j / 4"""
    N_loc = G.number_of_nodes()
    dim = 2**N_loc
    S2 = np.zeros((dim, dim), dtype=complex)
    for i in range(N_loc):
        for j in range(N_loc):
            if i == j:
                S2 += 3/4 * np.eye(dim, dtype=complex)
            else:
                S2 += 1/4 * (SXo[i]@SXo[j] + SYo[i]@SYo[j] + SZo[i]@SZo[j])
    return S2


def main():
    print("=" * 100)
    print("照妖镜 v11.0：简并基态下的 <σᵢ·σⱼ> 解析结构")
    print("=" * 100)

    atlas = nx.graph_atlas_g()
    cand = [G for G in atlas if G.number_of_nodes() == N and nx.is_connected(G)]
    graphs = []
    for G in cand:
        if not any(nx.is_isomorphic(G, H) for H in graphs):
            graphs.append(G)
    print(f"\n  图集: {len(graphs)} 个 N=6 连通图")

    same_pairs = load_same_response_pairs()
    defect_edges = set()
    for gid, e1, e2 in same_pairs:
        defect_edges.add((gid, e1))
        defect_edges.add((gid, e2))
    print(f"  缺陷边: {len(defect_edges)}")

    SXo, SYo, SZo = build_site_ops(N)

    # 精确定位 s(p_S=1/2)
    coarse_s = np.linspace(0.0, 2.5, 501)
    resonances = []

    for gid, defect in sorted(defect_edges):
        G = graphs[gid]
        edges = [tuple(sorted(e)) for e in G.edges()]
        H_edges = [edge_matrix(e[0], e[1], SXo, SYo, SZo) for e in edges]
        def pS_at_s(s):
            couplings = [s if e == defect else 1.0 for e in edges]
            H = sum(c*M for c, M in zip(couplings, H_edges))
            evals, evecs = eigh(H)
            E0 = evals[0]
            deg = int(np.sum(np.abs(evals - E0) < 1e-8))
            V = evecs[:, :deg]
            rho = V @ V.conj().T / deg
            rho_ij = partial_trace_2sites(rho, defect[0], defect[1], N)
            return 0.5 * (rho_ij[1,1].real - rho_ij[1,2].real
                         - rho_ij[2,1].real + rho_ij[2,2].real)
        pS_vals = np.array([pS_at_s(s) for s in coarse_s])
        for i in range(len(coarse_s) - 1):
            if (pS_vals[i] - 0.5) * (pS_vals[i+1] - 0.5) < 0:
                try:
                    s_exact = brentq(lambda s: pS_at_s(s) - 0.5,
                                     coarse_s[i], coarse_s[i+1], xtol=1e-13)
                    resonances.append((gid, defect, s_exact))
                except Exception:
                    pass

    print(f"\n  谐振点: {len(resonances)}")

    # ============================================================
    # Q1: 每个简并态的 <σᵢ·σⱼ> 值
    # ============================================================
    print("\n" + "=" * 100)
    print("Q1. 简并基态每个态的 <σᵢ·σⱼ> 值")
    print("=" * 100)

    print(f"\n  {'gid':>4} | {'defect':>8} | {'s':>10} | {'简并':>4} | {'各态 <σᵢ·σⱼ>':>40} | {'平均':>12}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*10}-+-{'-'*4}-+-{'-'*40}-+-{'-'*12}")

    per_state_data = []
    for gid, defect, s in sorted(resonances):
        G = graphs[gid]
        edges = [tuple(sorted(e)) for e in G.edges()]
        H_edges = [edge_matrix(e[0], e[1], SXo, SYo, SZo) for e in edges]
        couplings = [s if e == defect else 1.0 for e in edges]
        H = sum(c*M for c, M in zip(couplings, H_edges))
        evals, evecs = eigh(H)
        E0 = evals[0]
        deg = int(np.sum(np.abs(evals - E0) < 1e-8))
        V = evecs[:, :deg]
        # 每个态的 <σᵢ·σⱼ>
        per_state_vals = []
        for k in range(deg):
            v = V[:, k].reshape(-1, 1)
            rho = v @ v.conj().T
            rho_ij = partial_trace_2sites(rho, defect[0], defect[1], N)
            sd = sigdot_of_rho2(rho_ij)
            per_state_vals.append(sd)
        mean_val = np.mean(per_state_vals)
        vals_str = ", ".join(f"{v:.4f}" for v in per_state_vals[:6])
        if len(per_state_vals) > 6:
            vals_str += f", ... (+{len(per_state_vals)-6})"
        print(f"  {gid:>4} | {str(defect):>8} | {s:>10.6f} | {deg:>4} | {vals_str:>40} | {mean_val:>12.6f}")
        per_state_data.append({
            "gid": gid, "defect": defect, "s": s, "deg": deg,
            "per_state_vals": per_state_vals, "mean_val": mean_val
        })

    # 分析：简并态的 <σᵢ·σⱼ> 分布
    print(f"\n  --- 简并态 <σᵢ·σⱼ> 的分布特点 ---")
    for d in per_state_data:
        if d["deg"] > 1:
            vals = d["per_state_vals"]
            # 分类：取值种类数
            uniq = sorted(set(round(v, 4) for v in vals))
            if len(uniq) <= 3:
                print(f"  gid={d['gid']}, defect={d['defect']}, deg={d['deg']}: "
                      f"唯一值 {uniq}, 频率 {Counter(round(v,4) for v in vals)}")

    # ============================================================
    # Q2: 简并子空间的 S_z 分布
    # ============================================================
    print("\n" + "=" * 100)
    print("Q2. 简并子空间的 S_z 分布")
    print("=" * 100)

    # 对每个简并子空间，计算总 S_z 的分布
    print(f"\n  {'gid':>4} | {'defect':>8} | {'s':>10} | {'简并':>4} | {'S_z 期望值':>40}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*10}-+-{'-'*4}-+-{'-'*40}")

    # 总 S_z 算符
    Sz_total = sum(SZo)
    for gid, defect, s in sorted(resonances):
        G = graphs[gid]
        edges = [tuple(sorted(e)) for e in G.edges()]
        H_edges = [edge_matrix(e[0], e[1], SXo, SYo, SZo) for e in edges]
        couplings = [s if e == defect else 1.0 for e in edges]
        H = sum(c*M for c, M in zip(couplings, H_edges))
        evals, evecs = eigh(H)
        E0 = evals[0]
        deg = int(np.sum(np.abs(evals - E0) < 1e-8))
        V = evecs[:, :deg]
        # 每个态的 <S_z>
        sz_vals = []
        for k in range(deg):
            v = V[:, k].reshape(-1, 1)
            sz = float(np.real(v.conj().T @ Sz_total @ v))
            sz_vals.append(sz)
        sz_str = ", ".join(f"{v:.4f}" for v in sz_vals[:6])
        if len(sz_vals) > 6:
            sz_str += f", ..."
        print(f"  {gid:>4} | {str(defect):>8} | {s:>10.6f} | {deg:>4} | {sz_str:>40}")

    # ============================================================
    # Q3: 简并子空间的总自旋 S
    # ============================================================
    print("\n" + "=" * 100)
    print("Q3. 简并子空间的总自旋 S")
    print("=" * 100)

    # 对每个简并子空间，检查是否是单态（S=0）或多重态
    # 用 S² 算符
    S2 = total_spin_squared(graphs[0] if False else None, SXo, SYo, SZo)

    print(f"\n  {'gid':>4} | {'defect':>8} | {'s':>10} | {'简并':>4} | {'S²期望':>12} | {'S(S+1)':>12}")
    print(f"  {'-'*4}-+-{'-'*8}-+-{'-'*10}-+-{'-'*4}-+-{'-'*12}-+-{'-'*12}")

    for gid, defect, s in sorted(resonances):
        G = graphs[gid]
        edges = [tuple(sorted(e)) for e in G.edges()]
        H_edges = [edge_matrix(e[0], e[1], SXo, SYo, SZo) for e in edges]
        couplings = [s if e == defect else 1.0 for e in edges]
        H = sum(c*M for c, M in zip(couplings, H_edges))
        evals, evecs = eigh(H)
        E0 = evals[0]
        deg = int(np.sum(np.abs(evals - E0) < 1e-8))
        V = evecs[:, :deg]
        rho = V @ V.conj().T / deg
        S2_val = float(np.real(np.trace(rho @ S2)))
        S_val = (-1 + np.sqrt(1 + 4*S2_val))/2 if S2_val >= 0 else -1
        print(f"  {gid:>4} | {str(defect):>8} | {s:>10.6f} | {deg:>4} | "
              f"{S2_val:>12.6f} | {S_val:>12.6f}")

    # ============================================================
    # Q4: 非简并 vs 简并的 <σᵢ·σⱼ> 的代数形式
    # ============================================================
    print("\n" + "=" * 100)
    print("Q4. 非简并 vs 简并的 <σᵢ·σⱼ>")
    print("=" * 100)

    print(f"\n  {'类别':>10} | {'数量':>6} | {'<σᵢ·σⱼ> 均值':>16} | {'<σᵢ·σⱼ> 范围':>20}")
    print(f"  {'-'*10}-+-{'-'*6}-+-{'-'*16}-+-{'-'*20}")

    nondeg_sigdot = []
    deg_sigdot = []
    for d in per_state_data:
        if d["deg"] == 1:
            nondeg_sigdot.append(d["mean_val"])
        else:
            deg_sigdot.append(d["mean_val"])

    if nondeg_sigdot:
        print(f"  {'非简并':>10} | {len(nondeg_sigdot):>6} | "
              f"{np.mean(nondeg_sigdot):>16.8f} | "
              f"[{np.min(nondeg_sigdot):.6f}, {np.max(nondeg_sigdot):.6f}]")
    if deg_sigdot:
        print(f"  {'简并':>10} | {len(deg_sigdot):>6} | "
              f"{np.mean(deg_sigdot):>16.8f} | "
              f"[{np.min(deg_sigdot):.6f}, {np.max(deg_sigdot):.6f}]")

    # 简并的 <σᵢ·σⱼ> 均值是否都等于 -1？
    print(f"\n  --- 简并的 <σᵢ·σⱼ> 均值是否 = -1？ ---")
    for d in per_state_data:
        if d["deg"] > 1:
            dev = abs(d["mean_val"] + 1)
            if dev < 1e-8:
                pass
            else:
                print(f"  gid={d['gid']}, defect={d['defect']}, deg={d['deg']}: "
                      f"mean = {d['mean_val']:.8f}, 偏差 = {dev:.3e}")

    # ============================================================
    # Q5: 特殊 s 值的几何条件
    # ============================================================
    print("\n" + "=" * 100)
    print("Q5. 特殊 s 值（0, 0.5, 1.0, 1.5）的几何条件")
    print("=" * 100)

    # 按 s 值分组
    by_s = defaultdict(list)
    for gid, defect, s in resonances:
        # 分类到最近的 0.5 倍
        s_key = round(s * 2) / 2
        by_s[s_key].append((gid, defect, s))

    for s_key in sorted(by_s.keys()):
        items = by_s[s_key]
        print(f"\n  s ≈ {s_key:.1f} (实际 {len(items)} 个):")
        print(f"    {'gid':>4} | {'defect':>8} | {'s(精确)':>16} | {'d1':>4} | {'d2':>4} | {'度对':>8} | {'桥?':>6} | {'割点?':>6}")
        for gid, defect, s in items:
            G = graphs[gid]
            d1 = G.degree(defect[0])
            d2 = G.degree(defect[1])
            is_bridge = frozenset(defect) in set(map(frozenset, nx.bridges(G)))
            is_cut_a = not nx.is_connected(G.subgraph([n for n in G.nodes()
                                                       if n != defect[0]])) if G.number_of_nodes() > 1 else False
            print(f"    {gid:>4} | {str(defect):>8} | {s:>16.12f} | {d1:>4} | {d2:>4} | "
                  f"{(d1,d2)!s:>8} | {str(is_bridge):>6} | {str(is_cut_a):>6}")

    # 特殊 s 值的总结
    print(f"\n  --- 特殊 s 值的几何总结 ---")
    for s_key in sorted(by_s.keys()):
        items = by_s[s_key]
        n_bridges = sum(1 for g, d, s in items
                       if frozenset(d) in set(map(frozenset, nx.bridges(graphs[g]))))
        deg_pairs = [(graphs[g].degree(d[0]), graphs[g].degree(d[1])) for g, d, s in items]
        print(f"    s = {s_key:.1f}: {len(items)} 个, 桥数={n_bridges}, "
              f"度对集合={sorted(set(deg_pairs))}")

    # ============================================================
    # 深度追问：非简并基态下 <σᵢ·σⱼ>_defect = -1 是否对每条边都是解析？
    # ============================================================
    print("\n" + "=" * 100)
    print("深度追问：非简并基态下 <σᵢ·σⱼ>_defect = -1 的解析条件")
    print("=" * 100)

    print("""
  定理（猜想）：
  若 Heisenberg 基态是非简并的，且缺陷边 (i,j) 满足 <σᵢ·σⱼ>_defect = -1，
  则在 s(p_S=1/2) 处，缺陷边两端是"完全反关联"的。

  这等价于：在对称化基态密度矩阵下，缺陷边约化态是
    ρ_ij = (1/4) I - (1/4)(σᵢ·σⱼ)
  即单态和三重态的等量混合，投影到单态的概率 p_S = 1/2。

  数值验证：19/19 非简并基态满足此条件。
""")

    # 验证这个猜想
    print(f"  --- 验证：非简并基态 <σᵢ·σⱼ> = -1 是否 = 对应 s 处的 p_S = 1/2？ ---")
    for d in per_state_data:
        if d["deg"] == 1:
            gid, defect, s = d["gid"], d["defect"], d["s"]
            G = graphs[gid]
            edges = [tuple(sorted(e)) for e in G.edges()]
            H_edges = [edge_matrix(e[0], e[1], SXo, SYo, SZo) for e in edges]
            couplings = [s if e == defect else 1.0 for e in edges]
            H = sum(c*M for c, M in zip(couplings, H_edges))
            evals, evecs = eigh(H)
            V = evecs[:, :1]
            rho = V @ V.conj().T
            rho_ij = partial_trace_2sites(rho, defect[0], defect[1], N)
            sd = sigdot_of_rho2(rho_ij)
            pS = 0.5 * (rho_ij[1,1].real - rho_ij[1,2].real
                       - rho_ij[2,1].real + rho_ij[2,2].real)
            print(f"  gid={gid}, defect={defect}, s={s:.6f}: "
                  f"<σᵢ·σⱼ>={sd:.8f}, p_S={pS:.8f}")

    # ============================================================
    # 导出
    # ============================================================
    out = {
        "resonances": [
            {"gid": d["gid"], "defect": list(d["defect"]), "s": d["s"],
             "deg": d["deg"], "per_state_sigdot": d["per_state_vals"],
             "mean_sigdot": d["mean_val"]}
            for d in per_state_data
        ],
        "by_s": {str(k): [(g, list(d), s) for g, d, s in v]
                 for k, v in by_s.items()},
    }
    out_path = os.path.join(WORK_DIR, "照妖镜_v11_简并解析.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[ok] 导出: {out_path}")

    print("\n" + "=" * 100)
    print("v11.0 完成。简并基态下的 <σᵢ·σⱼ> 解析结构被攻击。")
    print("=" * 100)


if __name__ == "__main__":
    main()