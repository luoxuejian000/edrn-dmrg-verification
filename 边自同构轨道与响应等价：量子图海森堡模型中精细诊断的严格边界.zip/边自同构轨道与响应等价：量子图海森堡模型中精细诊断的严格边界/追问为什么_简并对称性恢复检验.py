"""
追问为什么_简并对称性恢复检验.py

目标：
    检验在简并情况下，使用对称性约化密度矩阵后，
    同轨道边是否恢复映射一致性。
    对图82在Δ=0和图111在多个Δ点：
        1. 构建哈密顿量，识别简并子空间
        2. 用简并子空间的均匀混合密度矩阵替代单一基态
        3. 计算关联分布，比较映射后的E_mapped与E_j
    若一致，则证明轨道决定论在简并下也成立，
    之前的反例只是基态选择问题。

方法：
    只查同与不同，不拟合。
    标准物理（能隙、简并度）与晶脉视角（E_mapped vs E_j）并排。

输出：
    jingmai_why_degeneracy_restore.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
TOL_DEGEN = 1e-8

def build_hamiltonian_and_basis(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def compute_corr_from_density_probs(N, edges, basis, probs):
    """用密度矩阵对角元（概率分布）计算关联分布"""
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return np.array(corrs)

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def get_automorphisms(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    GM = iso.GraphMatcher(G, G)
    return list(GM.isomorphisms_iter())

def get_edge_orbits_from_edges(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    automorphisms = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in automorphisms:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return orbits, edge_to_orbit

def build_permutation_matrix(basis, mapping, N):
    new_basis_states = []
    for state in basis:
        new_state = 0
        for i in range(N):
            if (state >> i) & 1:
                new_state |= (1 << mapping[i])
        new_basis_states.append(new_state)
    P = np.zeros((len(basis), len(basis)), dtype=float)
    for old_idx, new_state in enumerate(new_basis_states):
        if new_state in basis:
            new_idx = basis.index(new_state)
            P[new_idx, old_idx] = 1.0
    return P

def main():
    print("=== 追问为什么_简并对称性恢复检验 ===\n")
    
    all_graphs = get_all_N6_graphs()
    
    # 图82（轨道1边5->6）和图111（轨道0边0->10）
    test_cases = [
        {'graph_idx': 82, 'orbit': 1, 'edge_i': 5, 'edge_j': 6, 'delta_values': [0.0]},
        {'graph_idx': 111, 'orbit': 0, 'edge_i': 0, 'edge_j': 10, 'delta_values': [-1.5, -0.5, 0.0]}
    ]
    
    results = []
    
    for tc in test_cases:
        g_idx = tc['graph_idx']
        edges = all_graphs[g_idx]
        n_edges = len(edges)
        automorphisms = get_automorphisms(edges, N)
        ei = tc['edge_i']
        ej = tc['edge_j']
        
        # 找映射
        mapping = None
        for auto in automorphisms:
            mapped_edge = tuple(sorted((auto[edges[ei][0]], auto[edges[ei][1]])))
            if mapped_edge == edges[ej]:
                mapping = auto
                break
        if mapping is None:
            continue
        
        print(f"\n===== 图 {g_idx}，边{ei}->边{ej} =====")
        
        for s_val in tc['delta_values']:
            # 扫描 ei
            J_i = np.ones(n_edges); J_i[ei] = s_val
            H_i, basis_i = build_hamiltonian_and_basis(N, edges, J_i)
            evals_i, evecs_i = np.linalg.eigh(H_i)
            E0_i = evals_i[0]
            degen_indices_i = [k for k in range(len(evals_i)) if abs(evals_i[k]-E0_i) < TOL_DEGEN]
            degen_dim_i = len(degen_indices_i)
            
            # 扫描 ej
            J_j = np.ones(n_edges); J_j[ej] = s_val
            H_j, basis_j = build_hamiltonian_and_basis(N, edges, J_j)
            evals_j, evecs_j = np.linalg.eigh(H_j)
            E0_j = evals_j[0]
            degen_indices_j = [k for k in range(len(evals_j)) if abs(evals_j[k]-E0_j) < TOL_DEGEN]
            degen_dim_j = len(degen_indices_j)
            
            # 使用对称性约化密度矩阵：简并子空间均匀混合
            probs_i = np.zeros(len(basis_i))
            for idx in degen_indices_i:
                probs_i += np.abs(evecs_i[:, idx])**2
            probs_i /= degen_dim_i
            
            probs_j = np.zeros(len(basis_j))
            for idx in degen_indices_j:
                probs_j += np.abs(evecs_j[:, idx])**2
            probs_j /= degen_dim_j
            
            # 计算关联分布
            corrs_i = compute_corr_from_density_probs(N, edges, basis_i, probs_i)
            E_i = float(np.std(corrs_i))
            
            corrs_j = compute_corr_from_density_probs(N, edges, basis_j, probs_j)
            E_j = float(np.std(corrs_j))
            
            # 变换边集和波函数（对于密度分布，需要变换关联分布？这里我们直接比较排序分布）
            # 对 ei 的关联分布按映射重排到 ej 的边集上比较
            transformed_edges = []
            for (u, v) in edges:
                new_u, new_v = mapping[u], mapping[v]
                transformed_edges.append(tuple(sorted((new_u, new_v))))
            
            # 由于我们只有 probs_i（密度对角元），无法直接映射波函数，
            # 但可以映射边集：将 corrs_i 按 transformed_edges 的顺序重排？
            # 实际上，我们需要将 corrs_i 对应到 transformed_edges 的每条边，
            # 而 corrs_i 是按原始 edges 计算的。映射后，原始 edges 的每条边对应到 transformed_edges 中的某条边。
            # 这里简化：直接比较排序后的 corrs_i 和 corrs_j，因为排序后不依赖边标记。
            sorted_i = np.sort(corrs_i)
            sorted_j = np.sort(corrs_j)
            E_sorted_i = float(np.std(sorted_i))
            E_sorted_j = float(np.std(sorted_j))
            
            diff = abs(E_i - E_j)
            diff_sorted = abs(E_sorted_i - E_sorted_j)
            
            print(f"  Δ={s_val:.2f}: 简并度 ei={degen_dim_i}, ej={degen_dim_j}, "
                  f"E_i={E_i:.8f}, E_j={E_j:.8f}, 差异={diff:.6e}, "
                  f"排序后E差异={diff_sorted:.6e}, 一致={diff_sorted<1e-10}")
            
            results.append({
                'graph': g_idx,
                'edge_i': ei,
                'edge_j': ej,
                's_val': s_val,
                'degen_dim_i': degen_dim_i,
                'degen_dim_j': degen_dim_j,
                'E_i': E_i,
                'E_j': E_j,
                'diff': diff,
                'E_sorted_i': E_sorted_i,
                'E_sorted_j': E_sorted_j,
                'diff_sorted': diff_sorted,
                'consistent': diff_sorted < 1e-10
            })
    
    output = {
        'results': results,
        'note': '简并下使用对称性约化密度矩阵后，排序关联分布是否恢复映射一致性。'
    }
    with open('jingmai_why_degeneracy_restore.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_degeneracy_restore.json")

if __name__ == "__main__":
    main()