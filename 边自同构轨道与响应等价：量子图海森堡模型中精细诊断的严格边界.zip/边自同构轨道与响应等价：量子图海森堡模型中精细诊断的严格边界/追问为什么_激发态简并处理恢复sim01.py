"""
追问为什么_激发态简并处理恢复sim01.py

目标：
    继续追问：sim01在同轨道边对中不一致，是否源于激发态简并时的向量选择？
    检验方法：
        对同轨道边对，在每个Δ点：
            1. 基态使用对称性约化密度矩阵（简并基态均匀混合）
            2. 第一激发态也使用对称性约化密度矩阵（简并激发态均匀混合）
            3. 分别计算基态和激发态的关联分布
            4. 计算它们的排序分布相似度 sim01
        比较两边 sim01 是否恢复一致。
    若恢复一致，则之前 sim01 不一致是激发态简并未处理导致的伪影；
    若仍不一致，则 sim01 本身对边位置敏感，与轨道无关。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。
    基态和激发态都用对称性约化密度矩阵。

理论精髓：
    - 数据自己说话。
    - 追问：激发态简并处理能否恢复轨道分类？

输出：
    jingmai_why_ex_degen_restore_sim01.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10
DELTA_VALUES = [-1.5, -1.0, -0.5, -0.25, 0.0]

def build_hamiltonian_and_basis(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def compute_degeneracy_mixed_probs(evals, evecs, target_indices):
    """对给定简并指标集，返回均匀混合后的概率分布（密度对角元）"""
    if not target_indices:
        return None
    probs = np.zeros(len(evecs))
    for idx in target_indices:
        probs += np.abs(evecs[:, idx])**2
    probs /= len(target_indices)
    return probs

def compute_corrs_from_probs(N, edges, basis, probs):
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return np.array(corrs)

def distribution_similarity(dist1, dist2):
    return float(np.linalg.norm(np.sort(dist1) - np.sort(dist2)))

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def get_edge_orbits_from_edges(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    automorphisms = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in automorphisms:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return orbits, edge_to_orbit

def compute_sim01_with_ex_degen(N, edges, J_vals):
    """基态和激发态都使用简并均匀混合，返回sim01"""
    H, basis = build_hamiltonian_and_basis(N, edges, J_vals)
    evals, evecs = np.linalg.eigh(H)
    E0 = evals[0]
    # 基态简并指标
    gs_indices = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
    # 第一激发态能量：最小的非简并能量
    E1 = None
    for ev in evals:
        if ev > E0 + TOL_DEGEN:
            E1 = ev
            break
    if E1 is None:
        E1 = E0
    ex_indices = [k for k in range(len(evals)) if abs(evals[k]-E1) < TOL_DEGEN]
    
    gs_probs = compute_degeneracy_mixed_probs(evals, evecs, gs_indices)
    ex_probs = compute_degeneracy_mixed_probs(evals, evecs, ex_indices)
    
    corrs_gs = compute_corrs_from_probs(N, edges, basis, gs_probs)
    corrs_ex = compute_corrs_from_probs(N, edges, basis, ex_probs)
    sim01 = distribution_similarity(corrs_gs, corrs_ex)
    gap = float(evals[1] - evals[0])
    return sim01, gap, len(gs_indices), len(ex_indices)

def main():
    print("=== 追问为什么_激发态简并处理恢复sim01 ===\n")
    
    all_graphs = get_all_N6_graphs()
    
    # 已知反例图
    target_graphs = [0, 6, 10, 19, 20, 24, 38]
    results = []
    
    for g_idx in target_graphs:
        edges = all_graphs[g_idx]
        n_edges = len(edges)
        orbits, edge_to_orbit = get_edge_orbits_from_edges(edges, N)
        
        multi_orbits = [oi for oi, orbit in enumerate(orbits) if len(orbit) >= 2]
        if not multi_orbits:
            continue
        oi = multi_orbits[0]
        ei = orbits[oi][0]
        ej = orbits[oi][1]
        
        print(f"\n===== 图{g_idx} 边{ei}->边{ej}（轨道{oi}） =====")
        print(f"  {'Δ':<8} {'能隙':<12} {'基态简并':<10} {'激发态简并':<10} {'sim01_i':<12} {'sim01_j':<12} {'差异':<12}")
        
        for s_val in DELTA_VALUES:
            J_i = np.ones(n_edges); J_i[ei] = s_val
            J_j = np.ones(n_edges); J_j[ej] = s_val
            sim_i, gap_i, gs_deg_i, ex_deg_i = compute_sim01_with_ex_degen(N, edges, J_i)
            sim_j, gap_j, gs_deg_j, ex_deg_j = compute_sim01_with_ex_degen(N, edges, J_j)
            diff = abs(sim_i - sim_j)
            
            print(f"  {s_val:<8.2f} {gap_i:<12.8f} {gs_deg_i:<10} {ex_deg_i:<10} "
                  f"{sim_i:<12.8f} {sim_j:<12.8f} {diff:<12.8f}")
            
            results.append({
                'graph': g_idx,
                'orbit': oi,
                'edge_i': ei,
                'edge_j': ej,
                's_val': s_val,
                'gap': gap_i,
                'gs_degeneracy': gs_deg_i,
                'ex_degeneracy': ex_deg_i,
                'sim01_i': sim_i,
                'sim01_j': sim_j,
                'diff': diff
            })
    
    output = {
        'results': results,
        'note': '追问：激发态简并均匀混合后，同轨道边对的sim01是否恢复一致？'
    }
    with open('jingmai_why_ex_degen_restore_sim01.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_ex_degen_restore_sim01.json")

if __name__ == "__main__":
    main()