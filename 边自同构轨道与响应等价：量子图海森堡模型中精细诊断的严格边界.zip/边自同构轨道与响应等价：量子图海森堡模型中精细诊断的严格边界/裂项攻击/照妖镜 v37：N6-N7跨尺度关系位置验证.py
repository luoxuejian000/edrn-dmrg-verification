#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==========================================================================
照妖镜 v37：N=6 vs N=7 跨尺度关系位置验证
==========================================================================

【核心追问】
    N=6 三个结构规律，是否在 N=7 上成立？

【五个穷举方向，两尺度并排】
    方向 1：关系位置分布的跨尺度对比
    方向 2：s* 的 1/(N-2) 网格检验
    方向 3：bound_free/free_bound 镜像对称的跨尺度验证
    方向 4：关系位置对 → 特殊值类型的跨尺度映射
    方向 5：裂项区间与 s* 包裹关系的跨尺度对比

【理论精髓】
    关系本体论：节点无属性，一切来自关系图
    矛盾动力论：缺陷边是矛盾焦点
    谐振调谐论：s* 是谐振点位置
    元反思律：脚本最后声明盲区

【方法论原则】
    只查同与不同：不拟合，不回归，不预设结论
    不筛除数据：所有边、所有结果如实报告
    严防工具理性悖论：不用技术手段解决技术逻辑造成的问题
    反对对齐：让数据说话
    标准物理与关系本体论并排呈现

==========================================================================
"""

import numpy as np
import networkx as nx
from itertools import combinations
from collections import defaultdict
import json, os, time
from math import gcd

print("=" * 70)
print("照妖镜 v37：N=6 vs N=7 跨尺度关系位置验证")
print("=" * 70)
print("""
【元反思律声明】
本脚本盲区：
  1. 只处理 K_N 减两边（每 N 两个关系类）
  2. s 网格 2001 点，分辨率 2e-3
  3. 谐振点判定容差 1e-8
  4. 有理数识别限于分母 ≤ 20
  5. 如果 N=7 不成立，脚本会如实报告"不成立"
  6. N=8（19191 图）未做——体量太大
""")

CONFIG = {
    'Ns': [6, 7],
    's_fine': np.linspace(-2.0, 2.0, 2001),
    'tol_deg': 1e-8,
    'tol_hit': 1e-8,
    'targets': {
        '-2': -2.0,
        '1-sqrt3': 1.0 - np.sqrt(3.0),
        '-1': -1.0,
        '+1/3': 1.0 / 3.0,
        '-1/3': -1.0 / 3.0,
    },
    'output_dir': '照妖镜_v37_输出',
}

os.makedirs(CONFIG['output_dir'], exist_ok=True)


# ============================================================
# 第一部分：关系本体论 —— 构建 K_N 减两边
# ============================================================

def build_K_N_minus_2(N):
    """
    K_N 减两边有两个关系类：
      类 A：两条删除边共享一个节点
      类 B：两条删除边不共享节点
    返回代表图、删除边对、类计数
    """
    base = nx.complete_graph(N)
    all_edges = list(base.edges())
    class_A, class_B = [], []
    for e1, e2 in combinations(all_edges, 2):
        G = base.copy()
        G.remove_edges_from([e1, e2])
        if not nx.is_connected(G):
            continue
        if len(set(e1) & set(e2)) == 1:
            class_A.append((G, e1, e2))
        else:
            class_B.append((G, e1, e2))
    return class_A[0], class_B[0], len(class_A), len(class_B)


def relation_position(defect_edge, removed_pair):
    """
    关系位置三元组 (n1, n2, tag)。
    """
    de = set(defect_edge)
    r1 = set(removed_pair[0])
    r2 = set(removed_pair[1])
    n1 = len(de & r1)
    n2 = len(de & r2)
    if n1 == 0 and n2 == 0:
        tag = 'free_free'
    elif n1 == 1 and n2 == 0:
        tag = 'bound_free'
    elif n1 == 0 and n2 == 1:
        tag = 'free_bound'
    elif n1 == 1 and n2 == 1:
        tag = 'double_bound'
    elif n1 == 2:
        tag = 'is_removed_r1'
    elif n2 == 2:
        tag = 'is_removed_r2'
    else:
        tag = f'mixed_{n1}_{n2}'
    return (n1, n2, tag)


def classify_all_edges(G, removed_pair):
    removed = set(tuple(sorted(e)) for e in removed_pair)
    out = {}
    for e in G.edges():
        e_sorted = tuple(sorted(e))
        if e_sorted in removed:
            continue
        out[e_sorted] = relation_position(e_sorted, removed_pair)
    return out


# ============================================================
# 第二部分：量子力学
# ============================================================

_SX = np.array([[0, 1], [1, 0]], dtype=complex)
_SY = np.array([[0, -1j], [1j, 0]], dtype=complex)
_SZ = np.array([[1, 0], [0, -1]], dtype=complex)
_I2 = np.eye(2, dtype=complex)


def precompute_site_ops(N):
    """预计算所有格点算符，加速哈密顿量构建。"""
    cache = {}
    for a, op in [('x', _SX), ('y', _SY), ('z', _SZ)]:
        for i in range(N):
            ops = [_I2] * N
            ops[i] = op
            r = np.array([[1]], dtype=complex)
            for o in ops:
                r = np.kron(r, o)
            cache[(a, i)] = r
    return cache


def build_H(G, defect_edge, s, cache):
    N = G.number_of_nodes()
    dim = 2 ** N
    H = np.zeros((dim, dim), dtype=complex)
    de = tuple(sorted(defect_edge))
    for e in G.edges():
        i, j = e
        J = s if tuple(sorted(e)) == de else 1.0
        H += J * (cache[('x', i)] @ cache[('x', j)] +
                  cache[('y', i)] @ cache[('y', j)] +
                  cache[('z', i)] @ cache[('z', j)])
    return H


def diagonalize(H, tol_deg):
    evals, evecs = np.linalg.eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < tol_deg))
    if deg == 1:
        psi = evecs[:, 0]
        rho = np.outer(psi, psi.conj())
    else:
        rho = np.zeros_like(H)
        for k in range(deg):
            psi = evecs[:, k]
            rho += np.outer(psi, psi.conj())
        rho /= deg
    gap = float(evals[deg] - E0) if deg < len(evals) else 0.0
    return float(E0), gap, rho


def two_site_corr(rho, cache, e):
    i, j = e
    zz = 0.0; sd = 0.0
    for a in ['x', 'y', 'z']:
        v = float(np.real(np.trace(rho @ cache[(a, i)] @ cache[(a, j)])))
        sd += v
        if a == 'z':
            zz = v
    return zz, sd


# ============================================================
# 第三部分：有理数识别
# ============================================================

def rational_identify(x, max_denom=20, tol=1e-7):
    if abs(x) < tol:
        return (0, 1)
    for q in range(1, max_denom + 1):
        p = round(x * q)
        if abs(x - p / q) < tol:
            g = gcd(abs(p), q)
            return (p // g, q // g)
    return None


# ============================================================
# 第四部分：核心分析
# ============================================================

def analyze_N(N):
    """
    对给定的 N，做完整分析。
    """
    print(f"\n{'=' * 70}")
    print(f"N = {N}")
    print(f"{'=' * 70}")
    
    rep_A, rep_B, n_A, n_B = build_K_N_minus_2(N)
    print(f"类 A（共享节点）: {n_A} 个组合，代表 removed={rep_A[1], rep_A[2]}")
    print(f"类 B（不共享节点）: {n_B} 个组合，代表 removed={rep_B[1], rep_B[2]}")
    
    cache = precompute_site_ops(N)
    s_grid = CONFIG['s_fine']
    
    all_results = {}
    
    for name, rep in [('A', rep_A), ('B', rep_B)]:
        G, r1, r2 = rep
        cls = classify_all_edges(G, (r1, r2))
        edges_list = list(cls.keys())
        print(f"\n--- 类 {name}: |E|={len(edges_list)} ---")
        
        # 关系位置分布
        pos_count = defaultdict(int)
        for e, pos in cls.items():
            pos_count[pos[2]] += 1
        for tag, cnt in sorted(pos_count.items()):
            print(f"  {tag}: {cnt} 条边")
        
        # 扫描所有边的 gap 曲线
        gap_curves = {}
        for e in edges_list:
            gaps = np.zeros(len(s_grid))
            for k, s in enumerate(s_grid):
                H = build_H(G, e, s, cache)
                _, gap, _ = diagonalize(H, CONFIG['tol_deg'])
                gaps[k] = gap
            gap_curves[e] = gaps
        
        # 计算所有边对的 Δ(s)，找特殊值命中
        mappings = []
        for a, b in combinations(edges_list, 2):
            delta = gap_curves[a] - gap_curves[b]
            hits = []
            for k, sv in enumerate(s_grid):
                for tname, tval in CONFIG['targets'].items():
                    if abs(delta[k] - tval) < CONFIG['tol_hit']:
                        hits.append((tname, float(sv)))
            if hits:
                mappings.append({
                    'a': a, 'b': b,
                    'pos_a': cls[a], 'pos_b': cls[b],
                    'hits': hits,
                })
        
        all_results[name] = {
            'cls': cls,
            'gap_curves': gap_curves,
            'mappings': mappings,
        }
    
    return all_results, rep_A, rep_B


# ============================================================
# 第五部分：五方向并排输出
# ============================================================

def main():
    t0 = time.time()
    
    all_analyses = {}
    all_reps = {}
    
    for N in CONFIG['Ns']:
        results, rep_A, rep_B = analyze_N(N)
        all_analyses[N] = results
        all_reps[N] = (rep_A, rep_B)
    
    # ============================================================
    # 方向 1：关系位置分布的跨尺度对比
    # ============================================================
    print("\n" + "=" * 70)
    print("【方向 1】关系位置分布的跨尺度对比")
    print("=" * 70)
    
    print(f"\n  {'关系位置':<15} {'N=6类A':<10} {'N=6类B':<10} "
          f"{'N=7类A':<10} {'N=7类B':<10}")
    print("  " + "-" * 60)
    
    all_tags = set()
    for N in CONFIG['Ns']:
        for cname in ['A', 'B']:
            for pos in all_analyses[N][cname]['cls'].values():
                all_tags.add(pos[2])
    
    for tag in sorted(all_tags):
        row = [tag]
        for N in CONFIG['Ns']:
            for cname in ['A', 'B']:
                cnt = sum(1 for pos in all_analyses[N][cname]['cls'].values()
                          if pos[2] == tag)
                row.append(cnt)
        print(f"  {row[0]:<15} {row[1]:<10} {row[2]:<10} "
              f"{row[3]:<10} {row[4]:<10}")
    
    # ============================================================
    # 方向 2：s* 的 1/(N-2) 网格检验
    # ============================================================
    print("\n" + "=" * 70)
    print("【方向 2】s* 的 1/(N-2) 网格检验")
    print("=" * 70)
    
    for N in CONFIG['Ns']:
        denom_expected = N - 2
        print(f"\n--- N={N}：预期网格分母 = 1/{denom_expected} ---")
        all_s_stars = set()
        for cname in ['A', 'B']:
            for m in all_analyses[N][cname]['mappings']:
                for tname, sv in m['hits']:
                    all_s_stars.add(round(sv, 6))
        print(f"  唯一 s* 数：{len(all_s_stars)}")
        for sv in sorted(all_s_stars):
            rat = rational_identify(sv, max_denom=20)
            if rat:
                p, q = rat
                # 检查分母是否整除 denom_expected
                divides = (denom_expected % q == 0)
                mark = "✓" if divides else "✗"
                print(f"    {mark} s={sv:+.6f}  ->  {p}/{q}  "
                      f"(分母 {q} {'整除' if divides else '不整除'} {denom_expected})")
            else:
                print(f"    ?  s={sv:+.6f}  ->  非有理(≤20)")
    
    # ============================================================
    # 方向 3：bound_free/free_bound 镜像对称的跨尺度验证
    # ============================================================
    print("\n" + "=" * 70)
    print("【方向 3】bound_free/free_bound 镜像对称的跨尺度验证")
    print("=" * 70)
    
    for N in CONFIG['Ns']:
        print(f"\n--- N={N} ---")
        # 收集所有 (pos_a, pos_b) → hits 映射
        pos_pair_map = defaultdict(list)
        for cname in ['A', 'B']:
            for m in all_analyses[N][cname]['mappings']:
                key = (m['pos_a'][2], m['pos_b'][2])
                pos_pair_map[key].append({
                    'hits': m['hits'],
                    'a': m['a'], 'b': m['b'],
                })
        
        # 检查镜像对称
        mirror_pairs = [
            (('bound_free', 'free_free'), ('free_bound', 'free_free')),
        ]
        for (p1, p2) in mirror_pairs:
            hits1 = pos_pair_map.get(p1, [])
            hits2 = pos_pair_map.get(p2, [])
            print(f"  {p1} vs {p2}:")
            print(f"    第一方：{len(hits1)} 对边，命中集合："
                  f"{sorted(set(t for m in hits1 for t, s in m['hits']))}")
            print(f"    第二方：{len(hits2)} 对边，命中集合："
                  f"{sorted(set(t for m in hits2 for t, s in m['hits']))}")
            # s* 对比
            s1 = sorted(set(round(s, 4) for m in hits1 for _, s in m['hits']))
            s2 = sorted(set(round(s, 4) for m in hits2 for _, s in m['hits']))
            same = (s1 == s2)
            print(f"    s* 集合相同：{same}")
            if not same:
                print(f"      第一方 s*: {s1}")
                print(f"      第二方 s*: {s2}")
    
    # ============================================================
    # 方向 4：关系位置对 → 特殊值类型的跨尺度映射
    # ============================================================
    print("\n" + "=" * 70)
    print("【方向 4】关系位置对 → 特殊值类型的跨尺度映射")
    print("=" * 70)
    
    for N in CONFIG['Ns']:
        print(f"\n--- N={N} ---")
        print(f"  {'pos_a':<15} {'pos_b':<15} {'特殊值':<12} {'s* 集合'}")
        print("  " + "-" * 70)
        
        pos_pair_map = defaultdict(lambda: defaultdict(list))
        for cname in ['A', 'B']:
            for m in all_analyses[N][cname]['mappings']:
                key = (m['pos_a'][2], m['pos_b'][2])
                for tname, sv in m['hits']:
                    pos_pair_map[key][tname].append(sv)
        
        for (pa, pb), hits_dict in sorted(pos_pair_map.items()):
            for tname in sorted(hits_dict.keys()):
                svs = sorted(set(round(s, 4) for s in hits_dict[tname]))
                sv_str = ', '.join(f"{x:+.4f}" for x in svs[:5])
                print(f"  {pa:<15} {pb:<15} {tname:<12} {sv_str}")
    
    # ============================================================
    # 方向 5：裂项区间与 s* 包裹关系的跨尺度对比
    # ============================================================
    print("\n" + "=" * 70)
    print("【方向 5】裂项区间与 s* 包裹关系的跨尺度对比")
    print("=" * 70)
    
    for N in CONFIG['Ns']:
        print(f"\n--- N={N} ---")
        for cname in ['A', 'B']:
            print(f"  类 {cname}:")
            for e, pos in all_analyses[N][cname]['cls'].items():
                gaps = all_analyses[N][cname]['gap_curves'][e]
                # 用 gap 的二阶差分找裂项区间
                d2 = np.diff(gaps, n=2)
                flat = np.abs(d2) < 1e-6
                if flat.sum() > 3:
                    idx = np.where(flat)[0]
                    s_start = CONFIG['s_fine'][idx[0]]
                    s_end = CONFIG['s_fine'][idx[-1] + 2]
                    print(f"    {e} ({pos[2]}): gap 裂项区间 = "
                          f"[{s_start:+.4f}, {s_end:+.4f}]")
    
    # ============================================================
    # 跨尺度对比总结
    # ============================================================
    print("\n" + "=" * 70)
    print("跨尺度对比总结")
    print("=" * 70)
    
    summary = {}
    for N in CONFIG['Ns']:
        n_stars = set()
        pos_pair_map = defaultdict(set)
        for cname in ['A', 'B']:
            for m in all_analyses[N][cname]['mappings']:
                for tname, sv in m['hits']:
                    n_stars.add(round(sv, 4))
                key = (m['pos_a'][2], m['pos_b'][2])
                pos_pair_map[key].add(tname)
        summary[N] = {
            'n_unique_s_stars': len(n_stars),
            's_stars': sorted(n_stars),
            'pos_pairs': dict(pos_pair_map),
        }
    
    for N in CONFIG['Ns']:
        s = summary[N]
        print(f"\n  N={N}:")
        print(f"    唯一 s* 数：{s['n_unique_s_stars']}")
        print(f"    s* 集合：{s['s_stars']}")
        print(f"    关系位置对 → 特殊值类型：")
        for k, v in sorted(s['pos_pairs'].items()):
            print(f"      {k} → {sorted(v)}")
    
    # ============================================================
    # 元反思律声明
    # ============================================================
    print("\n" + "=" * 70)
    print("元反思律声明")
    print("=" * 70)
    print("""
本脚本的盲区与未解决问题：

1. 【跨尺度规律的边界】只在 N=6, 7 上验证。
   追问：N=8（19191 图）会继续成立吗？

2. 【1/(N-2) 网格的物理意义】为什么是 N-2？
   追问：N-2 是节点数减去两个端点，还是别的？

3. 【镜像对称的数学来源】
   bound_free 与 free_bound 镜像对称，
   来自 r1 与 r2 的置换对称性。
   追问：如果 r1 与 r2 不等价（非 K_N 情形），
   镜像对称会破缺吗？

4. 【s* 的完备性】只检查了 5 个特殊值。
   追问：N=7 是否产生新的特殊代数数？

5. 【关系位置对假设的边界】
   如果 N=7 出现新的关系位置对类型，
   这些新类型是否也被 s* 的网格规律约束？

6. 【最深的自指】
   我们在用 (pos_a, pos_b) 追问跨尺度规律。
   但 pos 本身是对象化的标签。
   如果关系不能被对象化，
   那么"跨尺度"也可能是一个对象化的幻觉。

7. 【行动追问】
   你准备用哪个 s* 去做什么行动？
   不是写论文，不是投期刊，是行动。
""")
    
    # 保存
    save = {
        'Ns': CONFIG['Ns'],
        'summary': {
            str(N): {
                'n_unique_s_stars': summary[N]['n_unique_s_stars'],
                's_stars': summary[N]['s_stars'],
                'pos_pairs': {str(k): sorted(v)
                              for k, v in summary[N]['pos_pairs'].items()},
            } for N in CONFIG['Ns']
        },
    }
    with open(os.path.join(CONFIG['output_dir'], 'summary.json'),
              'w', encoding='utf-8') as f:
        json.dump(save, f, indent=2, ensure_ascii=False)
    
    print(f"\n完成。耗时 {time.time() - t0:.1f} 秒。")
    print("过程继续。不给结论。")


if __name__ == '__main__':
    main()