#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==========================================================================
照妖镜 v37_fast：N=6 vs N=7 跨尺度关系位置验证（加速版）
==========================================================================

【加速点】
    1. 利用 H(s,e) = H_0 + (s-1) M_e，预计算 H_0 和 M_e
    2. 投影到 S_z 最小子空间（N=6 用 S_z=0，N=7 用 S_z=1/2）
    3. 维度从 2^N 降到 C(N, N//2)：
       N=6: 64 -> 20 （快约 32 倍）
       N=7: 128 -> 35 （快约 48 倍）
    4. 加上预计算，总加速 50-100 倍

【理论精髓，完全不变】
    关系本体论、矛盾动力论、实践介入论、谐振调谐论、元反思律
    只查同与不同，不拟合，不回归，不预设结论
    严防工具理性悖论，反对对齐，让数据说话

==========================================================================
"""

import numpy as np
import networkx as nx
from itertools import combinations
from collections import defaultdict
import json, os, time
from math import gcd

print("=" * 70)
print("照妖镜 v37_fast：N=6 vs N=7 跨尺度关系位置验证（加速版）")
print("=" * 70)
print("""
【元反思律声明】
本脚本盲区：
  1. 只处理 K_N 减两边（每 N 两个关系类）
  2. s 网格 2001 点，分辨率 2e-3
  3. 谐振点判定容差 1e-8
  4. 有理数识别限于分母 ≤ 20
  5. 使用了 S_z 子空间——这本身是一种对象化，
     但 SU(2) 对称性保证结果与完整空间一致
  6. N=8（19191 图）未做——体量太大
""")

CONFIG = {
    'Ns': [6, 7],
    's_fine': np.linspace(-2.0, 2.0, 2001),
    'tol_deg': 1e-8,
    'tol_hit': 1e-8,
    'targets': {
        '-2': -2.0,
        '1-sqrt3': 1.0 - np.sqrt(3.0),
        '-1': -1.0,
        '+1/3': 1.0 / 3.0,
        '-1/3': -1.0 / 3.0,
    },
    'output_dir': '照妖镜_v37_fast_输出',
}

os.makedirs(CONFIG['output_dir'], exist_ok=True)


# ============================================================
# 第一部分：关系本体论 —— 构建 K_N 减两边
# ============================================================

def build_K_N_minus_2(N):
    base = nx.complete_graph(N)
    all_edges = list(base.edges())
    class_A, class_B = [], []
    for e1, e2 in combinations(all_edges, 2):
        G = base.copy()
        G.remove_edges_from([e1, e2])
        if not nx.is_connected(G):
            continue
        if len(set(e1) & set(e2)) == 1:
            class_A.append((G, e1, e2))
        else:
            class_B.append((G, e1, e2))
    return class_A[0], class_B[0], len(class_A), len(class_B)


def relation_position(defect_edge, removed_pair):
    de = set(defect_edge)
    r1 = set(removed_pair[0])
    r2 = set(removed_pair[1])
    n1 = len(de & r1)
    n2 = len(de & r2)
    if n1 == 0 and n2 == 0:
        tag = 'free_free'
    elif n1 == 1 and n2 == 0:
        tag = 'bound_free'
    elif n1 == 0 and n2 == 1:
        tag = 'free_bound'
    elif n1 == 1 and n2 == 1:
        tag = 'double_bound'
    elif n1 == 2:
        tag = 'is_removed_r1'
    elif n2 == 2:
        tag = 'is_removed_r2'
    else:
        tag = f'mixed_{n1}_{n2}'
    return (n1, n2, tag)


def classify_all_edges(G, removed_pair):
    removed = set(tuple(sorted(e)) for e in removed_pair)
    out = {}
    for e in G.edges():
        e_sorted = tuple(sorted(e))
        if e_sorted in removed:
            continue
        out[e_sorted] = relation_position(e_sorted, removed_pair)
    return out


# ============================================================
# 第二部分：S_z 子空间 —— 加速核心
# ============================================================

def build_Sz_basis(N, n_up):
    """
    构造 S_z 子空间的基：N 位中恰好 n_up 个 1（自旋向上）。
    n_up = N//2 (N偶) 或 (N+1)//2 (N奇) 给出最小 |S_z|。
    """
    basis = []
    for i in range(2**N):
        if bin(i).count('1') == n_up:
            basis.append(i)
    return basis


def build_site_ops_in_Sz(N, n_up):
    """
    在 S_z 子空间内构造每个格点的 σ^x, σ^y, σ^z。
    使用 S = σ 约定。
    """
    basis = build_Sz_basis(N, n_up)
    dim = len(basis)
    idx_map = {b: i for i, b in enumerate(basis)}
    
    sigma_ops = {'x': {}, 'y': {}, 'z': {}}
    
    for site in range(N):
        Mx = np.zeros((dim, dim), dtype=complex)
        My = np.zeros((dim, dim), dtype=complex)
        Mz = np.zeros((dim, dim), dtype=complex)
        
        bit_pos = N - 1 - site
        
        for j, j_idx in enumerate(basis):
            bit_j = (j_idx >> bit_pos) & 1
            # σ^z
            Mz[j, j] = 1.0 if bit_j == 0 else -1.0
            
            # σ^x: 翻转 bit
            k_idx = j_idx ^ (1 << bit_pos)
            if k_idx in idx_map:
                k = idx_map[k_idx]
                Mx[k, j] += 1.0
            
            # σ^y: |0> -> i|1>, |1> -> -i|0>
            if k_idx in idx_map:
                k = idx_map[k_idx]
                if bit_j == 0:
                    My[k, j] += 1j
                else:
                    My[k, j] += -1j
        
        sigma_ops['x'][site] = Mx
        sigma_ops['y'][site] = My
        sigma_ops['z'][site] = Mz
    
    return sigma_ops, basis


def build_H_terms(G, sigma_ops):
    """
    预计算每条边的 M_e = σ^x_i σ^x_j + σ^y_i σ^y_j + σ^z_i σ^z_j
    以及 H_0 = Σ_e M_e
    """
    M_e = {}
    for e in G.edges():
        i, j = e
        M = (sigma_ops['x'][i] @ sigma_ops['x'][j] +
             sigma_ops['y'][i] @ sigma_ops['y'][j] +
             sigma_ops['z'][i] @ sigma_ops['z'][j])
        M_e[tuple(sorted(e))] = M
    
    H_0 = sum(M_e.values())
    return H_0, M_e


def build_H_fast(H_0, M_e, defect_edge, s):
    """H(s, e) = H_0 + (s - 1) * M_e。加速的关键。"""
    de = tuple(sorted(defect_edge))
    return H_0 + (s - 1.0) * M_e[de]


def diagonalize(H, tol_deg):
    evals, evecs = np.linalg.eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < tol_deg))
    if deg == 1:
        psi = evecs[:, 0]
        rho = np.outer(psi, psi.conj())
    else:
        rho = np.zeros_like(H)
        for k in range(deg):
            psi = evecs[:, k]
            rho += np.outer(psi, psi.conj())
        rho /= deg
    gap = float(evals[deg] - E0) if deg < len(evals) else 0.0
    return float(E0), gap


# ============================================================
# 第三部分：有理数识别
# ============================================================

def rational_identify(x, max_denom=20, tol=1e-7):
    if abs(x) < tol:
        return (0, 1)
    for q in range(1, max_denom + 1):
        p = round(x * q)
        if abs(x - p / q) < tol:
            g = gcd(abs(p), q)
            return (p // g, q // g)
    return None


# ============================================================
# 第四部分：核心分析
# ============================================================

def analyze_N(N):
    print(f"\n{'=' * 70}")
    print(f"N = {N}")
    print(f"{'=' * 70}")
    
    rep_A, rep_B, n_A, n_B = build_K_N_minus_2(N)
    print(f"类 A（共享节点）: {n_A} 个组合")
    print(f"类 B（不共享节点）: {n_B} 个组合")
    
    # S_z 子空间维度
    n_up = (N + 1) // 2  # N=6 -> 3, N=7 -> 4
    sigma_ops, basis = build_site_ops_in_Sz(N, n_up)
    dim = len(basis)
    print(f"S_z 子空间维度：{dim}（完整空间 2^{N} = {2**N}）")
    
    s_grid = CONFIG['s_fine']
    all_results = {}
    
    for name, rep in [('A', rep_A), ('B', rep_B)]:
        G, r1, r2 = rep
        cls = classify_all_edges(G, (r1, r2))
        edges_list = list(cls.keys())
        
        print(f"\n--- 类 {name}: |E|={len(edges_list)} ---")
        pos_count = defaultdict(int)
        for e, pos in cls.items():
            pos_count[pos[2]] += 1
        for tag, cnt in sorted(pos_count.items()):
            print(f"  {tag}: {cnt} 条边")
        
        # 预计算 H_0 和 M_e —— 加速核心
        H_0, M_e = build_H_terms(G, sigma_ops)
        
        # 扫描所有边的 gap 曲线
        gap_curves = {}
        for e in edges_list:
            gaps = np.zeros(len(s_grid))
            for k, s in enumerate(s_grid):
                H = build_H_fast(H_0, M_e, e, s)
                _, gap = diagonalize(H, CONFIG['tol_deg'])
                gaps[k] = gap
            gap_curves[e] = gaps
        
        # 找特殊值命中
        mappings = []
        for a, b in combinations(edges_list, 2):
            delta = gap_curves[a] - gap_curves[b]
            hits = []
            for k, sv in enumerate(s_grid):
                for tname, tval in CONFIG['targets'].items():
                    if abs(delta[k] - tval) < CONFIG['tol_hit']:
                        hits.append((tname, float(sv)))
            if hits:
                mappings.append({
                    'a': a, 'b': b,
                    'pos_a': cls[a], 'pos_b': cls[b],
                    'hits': hits,
                })
        
        all_results[name] = {
            'cls': cls,
            'gap_curves': gap_curves,
            'mappings': mappings,
        }
    
    return all_results, rep_A, rep_B


# ============================================================
# 第五部分：主流程
# ============================================================

def main():
    t0 = time.time()
    
    all_analyses = {}
    all_reps = {}
    
    for N in CONFIG['Ns']:
        tN = time.time()
        results, rep_A, rep_B = analyze_N(N)
        all_analyses[N] = results
        all_reps[N] = (rep_A, rep_B)
        print(f"  N={N} 耗时：{time.time() - tN:.1f} 秒")
    
    # ============================================================
    # 方向 1：关系位置分布的跨尺度对比
    # ============================================================
    print("\n" + "=" * 70)
    print("【方向 1】关系位置分布的跨尺度对比")
    print("=" * 70)
    
    print(f"\n  {'关系位置':<15} {'N=6类A':<8} {'N=6类B':<8} "
          f"{'N=7类A':<8} {'N=7类B':<8}")
    print("  " + "-" * 55)
    
    all_tags = set()
    for N in CONFIG['Ns']:
        for cname in ['A', 'B']:
            for pos in all_analyses[N][cname]['cls'].values():
                all_tags.add(pos[2])
    
    for tag in sorted(all_tags):
        row = [tag]
        for N in CONFIG['Ns']:
            for cname in ['A', 'B']:
                cnt = sum(1 for pos in all_analyses[N][cname]['cls'].values()
                          if pos[2] == tag)
                row.append(cnt)
        print(f"  {row[0]:<15} {row[1]:<8} {row[2]:<8} "
              f"{row[3]:<8} {row[4]:<8}")
    
    # ============================================================
    # 方向 2：s* 的 1/(N-2) 网格检验
    # ============================================================
    print("\n" + "=" * 70)
    print("【方向 2】s* 的 1/(N-2) 网格检验")
    print("=" * 70)
    
    for N in CONFIG['Ns']:
        denom_expected = N - 2
        print(f"\n--- N={N}：预期网格分母 = 1/{denom_expected} ---")
        all_s_stars = set()
        for cname in ['A', 'B']:
            for m in all_analyses[N][cname]['mappings']:
                for tname, sv in m['hits']:
                    all_s_stars.add(round(sv, 6))
        print(f"  唯一 s* 数：{len(all_s_stars)}")
        for sv in sorted(all_s_stars):
            rat = rational_identify(sv, max_denom=20)
            if rat:
                p, q = rat
                divides = (denom_expected % q == 0)
                mark = "✓" if divides else "✗"
                print(f"    {mark} s={sv:+.6f}  ->  {p}/{q}  "
                      f"(分母 {q} {'整除' if divides else '不整除'} {denom_expected})")
            else:
                print(f"    ?  s={sv:+.6f}  ->  非有理(≤20)")
    
    # ============================================================
    # 方向 3：bound_free/free_bound 镜像对称
    # ============================================================
    print("\n" + "=" * 70)
    print("【方向 3】bound_free/free_bound 镜像对称的跨尺度验证")
    print("=" * 70)
    
    for N in CONFIG['Ns']:
        print(f"\n--- N={N} ---")
        pos_pair_map = defaultdict(list)
        for cname in ['A', 'B']:
            for m in all_analyses[N][cname]['mappings']:
                key = (m['pos_a'][2], m['pos_b'][2])
                pos_pair_map[key].append(m)
        
        for p1, p2 in [(('bound_free', 'free_free'),
                        ('free_bound', 'free_free'))]:
            h1 = pos_pair_map.get(p1, [])
            h2 = pos_pair_map.get(p2, [])
            s1 = sorted(set(round(s, 4) for m in h1 for _, s in m['hits']))
            s2 = sorted(set(round(s, 4) for m in h2 for _, s in m['hits']))
            same = (s1 == s2)
            print(f"  {p1} vs {p2}:")
            print(f"    第一方 {len(h1)} 对边，s* = {s1}")
            print(f"    第二方 {len(h2)} 对边，s* = {s2}")
            print(f"    镜像对称：{'✓ 成立' if same else '✗ 破缺'}")
    
    # ============================================================
    # 方向 4：关系位置对 → 特殊值类型
    # ============================================================
    print("\n" + "=" * 70)
    print("【方向 4】关系位置对 → 特殊值类型的跨尺度映射")
    print("=" * 70)
    
    for N in CONFIG['Ns']:
        print(f"\n--- N={N} ---")
        print(f"  {'pos_a':<15} {'pos_b':<15} {'特殊值':<12} {'s* 集合'}")
        print("  " + "-" * 70)
        
        pos_pair_map = defaultdict(lambda: defaultdict(list))
        for cname in ['A', 'B']:
            for m in all_analyses[N][cname]['mappings']:
                key = (m['pos_a'][2], m['pos_b'][2])
                for tname, sv in m['hits']:
                    pos_pair_map[key][tname].append(sv)
        
        for (pa, pb), hits_dict in sorted(pos_pair_map.items()):
            for tname in sorted(hits_dict.keys()):
                svs = sorted(set(round(s, 4) for s in hits_dict[tname]))
                sv_str = ', '.join(f"{x:+.4f}" for x in svs[:5])
                print(f"  {pa:<15} {pb:<15} {tname:<12} {sv_str}")
    
    # ============================================================
    # 跨尺度对比总结
    # ============================================================
    print("\n" + "=" * 70)
    print("跨尺度对比总结")
    print("=" * 70)
    
    summary = {}
    for N in CONFIG['Ns']:
        n_stars = set()
        pos_pair_map = defaultdict(set)
        for cname in ['A', 'B']:
            for m in all_analyses[N][cname]['mappings']:
                for tname, sv in m['hits']:
                    n_stars.add(round(sv, 4))
                key = (m['pos_a'][2], m['pos_b'][2])
                pos_pair_map[key].add(tname)
        summary[N] = {
            'n_unique_s_stars': len(n_stars),
            's_stars': sorted(n_stars),
            'pos_pairs': dict(pos_pair_map),
        }
    
    for N in CONFIG['Ns']:
        s = summary[N]
        print(f"\n  N={N}:")
        print(f"    唯一 s* 数：{s['n_unique_s_stars']}")
        print(f"    s* 集合：{s['s_stars']}")
        print(f"    关系位置对 → 特殊值类型：")
        for k, v in sorted(s['pos_pairs'].items()):
            print(f"      {k} → {sorted(v)}")
    
    # ============================================================
    # 元反思律声明
    # ============================================================
    print("\n" + "=" * 70)
    print("元反思律声明")
    print("=" * 70)
    print("""
本脚本的盲区与未解决问题：

1. 【跨尺度规律的边界】只在 N=6, 7 上验证。
   追问：N=8（19191 图）会继续成立吗？

2. 【1/(N-2) 网格的物理意义】为什么是 N-2？
   追问：N-2 是"节点数减去两个端点"，还是别的？

3. 【S_z 子空间的对象化】
   我们用了 S_z 子空间加速，这本身是对象化。
   SU(2) 对称性保证结果与完整空间一致，
   但"用对称性约化"是不是已经预设了什么？

4. 【s* 的完备性】只检查了 5 个特殊值。
   追问：N=7 是否产生新的特殊代数数？

5. 【镜像对称的数学来源】
   bound_free 与 free_bound 镜像对称，
   来自 r1 与 r2 的置换对称性。
   追问：如果 r1 与 r2 不等价，镜像对称会破缺吗？

6. 【最深的自指】
   我们在用 (pos_a, pos_b) 追问跨尺度规律。
   但 pos 是对象化标签。
   如果关系不能被对象化，
   那么"跨尺度"也可能是对象化的幻觉。

7. 【行动追问】
   你准备用哪个 s* 去做什么行动？
   不是写论文，不是投期刊，是行动。
""")
    
    save = {
        'Ns': CONFIG['Ns'],
        'summary': {
            str(N): {
                'n_unique_s_stars': summary[N]['n_unique_s_stars'],
                's_stars': summary[N]['s_stars'],
                'pos_pairs': {str(k): sorted(v)
                              for k, v in summary[N]['pos_pairs'].items()},
            } for N in CONFIG['Ns']
        },
    }
    with open(os.path.join(CONFIG['output_dir'], 'summary.json'),
              'w', encoding='utf-8') as f:
        json.dump(save, f, indent=2, ensure_ascii=False)
    
    print(f"\n完成。总耗时 {time.time() - t0:.1f} 秒。")
    print("过程继续。不给结论。")


if __name__ == '__main__':
    main()