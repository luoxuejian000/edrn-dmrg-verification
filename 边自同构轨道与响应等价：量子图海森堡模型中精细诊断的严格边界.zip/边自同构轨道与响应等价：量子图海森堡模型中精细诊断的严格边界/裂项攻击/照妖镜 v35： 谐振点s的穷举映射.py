#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==========================================================================
照妖镜 v35：关系位置 → 谐振点 s* 的穷举映射
==========================================================================

【核心追问】
    特殊值 (-2, 1-√3) 的出现位置 s*，
    是否由"缺陷边相对删除边对的关系位置"唯一决定？
    如果是，s* 就是关系位置的函数。

【理论精髓】
    关系本体论：节点无属性，一切来自关系图
    矛盾动力论：缺陷边是矛盾焦点
    谐振调谐论：s* 是谐振点
    元反思律：脚本最后声明盲区

【五个穷举方向，同时进行】
    方向 1：关系位置三元组的穷举分类
    方向 2：s* 集合的精确有理数识别
    方向 3：s* 是否落在统一有理数网格上
    方向 4：两个关系类的 s* 映射并排
    方向 5：裂项结构在 s* 附近的二阶差分特征

【严防工具理性悖论】
    不拟合，不回归，不预设 s* 是关系位置函数。
    如果数据不成立，脚本如实报告"不成立"。

==========================================================================
"""

import numpy as np
import networkx as nx
from itertools import combinations
from collections import defaultdict
from scipy.optimize import brentq
import json, os, time

print("=" * 70)
print("照妖镜 v35：关系位置 → 谐振点 s* 的穷举映射")
print("=" * 70)
print("""
【元反思律声明】
本脚本盲区：
  1. 只处理 K_6 减两边（2 个关系类）
  2. s 网格 1001 点，分辨率 4e-3
  3. s* 的"有理数识别"限于分母 ≤ 100
  4. 裂项假设可能不成立
  5. 我们不知道"关系位置 → s*"的映射是否是可形式化的
""")

CONFIG = {
    'N': 6,
    's_fine': np.linspace(-2.0, 2.0, 1001),  # 分辨率 4e-3
    'tol_deg': 1e-8,
    'tol_hit': 1e-8,
    'targets': {
        '-2': -2.0,
        '1-sqrt3': 1.0 - np.sqrt(3.0),
        '-1': -1.0,
        '+1/3': 1.0 / 3.0,
        '-1/3': -1.0 / 3.0,
        '+1': 1.0,
        '-3': -3.0,
    },
    'output_dir': '照妖镜_v35_输出',
}

os.makedirs(CONFIG['output_dir'], exist_ok=True)


# ============================================================
# 第一部分：关系本体论 —— 构建两个关系类
# ============================================================

def build_two_relation_classes():
    """
    K_6 减两边只有 2 个同构类：
      类 A：删除的两条边共享一个节点
      类 B：删除的两条边不共享节点
    """
    base = nx.complete_graph(6)
    all_edges = list(base.edges())
    
    class_A = []  # 共享节点
    class_B = []  # 不共享节点
    
    for e1, e2 in combinations(all_edges, 2):
        G = base.copy()
        G.remove_edges_from([e1, e2])
        if not nx.is_connected(G):
            continue
        shared = len(set(e1) & set(e2))
        if shared == 1:
            class_A.append((G, e1, e2))
        elif shared == 0:
            class_B.append((G, e1, e2))
    
    # 从每类取代表
    rep_A = class_A[0]
    rep_B = class_B[0]
    
    return rep_A, rep_B, len(class_A), len(class_B)


# ============================================================
# 第二部分：量子力学 —— 哈密顿量与对角化
# ============================================================

_SX = np.array([[0, 1], [1, 0]], dtype=complex)
_SY = np.array([[0, -1j], [1j, 0]], dtype=complex)
_SZ = np.array([[1, 0], [0, -1]], dtype=complex)
_I2 = np.eye(2, dtype=complex)


def _site_op(op, site, N):
    ops = [_I2] * N
    ops[site] = op
    r = np.array([[1]], dtype=complex)
    for o in ops:
        r = np.kron(r, o)
    return r


def build_H(G, defect_edge, s):
    N = G.number_of_nodes()
    cache = {}
    for a, op in [('x', _SX), ('y', _SY), ('z', _SZ)]:
        for i in range(N):
            cache[(a, i)] = _site_op(op, i, N)
    H = np.zeros((2**N, 2**N), dtype=complex)
    de = tuple(sorted(defect_edge))
    for e in G.edges():
        i, j = e
        J = s if tuple(sorted(e)) == de else 1.0
        H += J * (cache[('x', i)] @ cache[('x', j)] +
                  cache[('y', i)] @ cache[('y', j)] +
                  cache[('z', i)] @ cache[('z', j)])
    return H


def diagonalize(H):
    evals, evecs = np.linalg.eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < CONFIG['tol_deg']))
    if deg == 1:
        psi = evecs[:, 0]
        rho = np.outer(psi, psi.conj())
    else:
        rho = np.zeros_like(H)
        for k in range(deg):
            psi = evecs[:, k]
            rho += np.outer(psi, psi.conj())
        rho /= deg
    gap = float(evals[deg] - E0) if deg < len(evals) else 0.0
    return float(E0), gap, rho, deg


def two_site_corr(rho, G, e):
    N = G.number_of_nodes()
    i, j = e
    zz = 0.0; sd = 0.0
    for a, op in [('x', _SX), ('y', _SY), ('z', _SZ)]:
        oi = _site_op(op, i, N); oj = _site_op(op, j, N)
        v = float(np.real(np.trace(rho @ oi @ oj)))
        sd += v
        if a == 'z':
            zz = v
    return zz, sd


def ps_from_zz(zz):
    return (1.0 - 3.0 * zz) / 4.0


# ============================================================
# 第三部分：方向 1 —— 关系位置三元组
# ============================================================

def relation_position(defect_edge, removed_pair):
    """
    缺陷边相对删除边对的关系位置。
    返回三元组 (rel1, rel2, combined)：
      rel_k = 缺陷边与删除边 k 共享的节点数 (0/1/2)
      combined = 关系类型标签
    """
    de = set(defect_edge)
    r1 = set(removed_pair[0])
    r2 = set(removed_pair[1])
    n1 = len(de & r1)
    n2 = len(de & r2)
    # 关系标签
    if n1 == 0 and n2 == 0:
        tag = 'free_free'
    elif n1 == 1 and n2 == 0:
        tag = 'bound_free'
    elif n1 == 0 and n2 == 1:
        tag = 'free_bound'
    elif n1 == 1 and n2 == 1:
        if len(set(removed_pair[0]) & set(removed_pair[1])) == 1:
            tag = 'double_bound'  # 两条删除边共享节点，缺陷边分别连接
        else:
            tag = 'double_bound'
    elif n1 == 2:
        tag = 'is_removed_1'
    elif n2 == 2:
        tag = 'is_removed_2'
    else:
        tag = f'mixed_{n1}_{n2}'
    return n1, n2, tag


def classify_all_edges(G, removed_pair):
    """对图中所有非删除边做关系位置分类"""
    removed = set(tuple(sorted(e)) for e in removed_pair)
    out = defaultdict(list)
    for e in G.edges():
        if tuple(sorted(e)) in removed:
            continue
        n1, n2, tag = relation_position(e, removed_pair)
        out[tag].append((tuple(sorted(e)), n1, n2))
    return dict(out)


# ============================================================
# 第四部分：方向 2 & 3 —— s* 集合与有理数识别
# ============================================================

def rational_identify(x, max_denom=100, tol=1e-8):
    """识别 x 是否为分母 ≤ max_denom 的有理数"""
    if abs(x) < tol:
        return (0, 1)
    for q in range(1, max_denom + 1):
        p = round(x * q)
        if abs(x - p / q) < tol:
            from math import gcd
            g = gcd(abs(p), q)
            return (p // g, q // g)
    return None


def scan_all_edges(G, removed_pair, s_grid):
    """
    对图中所有非删除边，扫描 s，记录所有特殊值命中。
    """
    removed = set(tuple(sorted(e)) for e in removed_pair)
    results = {}
    for e in G.edges():
        e_sorted = tuple(sorted(e))
        if e_sorted in removed:
            continue
        E0s, gaps, pss, sds = [], [], [], []
        for s in s_grid:
            H = build_H(G, e, s)
            E0, gap, rho, deg = diagonalize(H)
            zz, sd = two_site_corr(rho, G, e)
            E0s.append(E0); gaps.append(gap)
            pss.append(ps_from_zz(zz)); sds.append(sd)
        E0s = np.array(E0s); gaps = np.array(gaps)
        pss = np.array(pss); sds = np.array(sds)
        
        # 特殊值命中
        hits = defaultdict(list)
        for k, sv in enumerate(s_grid):
            for name, target in CONFIG['targets'].items():
                if abs(gaps[k] - target) < CONFIG['tol_hit']:
                    hits[name].append(('gap', float(sv)))
                if abs(sds[k] - target) < CONFIG['tol_hit']:
                    hits[name].append(('sd', float(sv)))
                if abs(pss[k] - target) < CONFIG['tol_hit']:
                    hits[name].append(('ps', float(sv)))
        
        # 二阶差分（裂项结构检验）
        d2_E0 = np.diff(E0s, n=2) if len(E0s) > 2 else np.array([])
        d2_gap = np.diff(gaps, n=2) if len(gaps) > 2 else np.array([])
        d2_sd = np.diff(sds, n=2) if len(sds) > 2 else np.array([])
        
        results[e_sorted] = {
            'E0': E0s, 'gap': gaps, 'ps': pss, 'sd': sds,
            'hits': dict(hits),
            'd2_E0': d2_E0, 'd2_gap': d2_gap, 'd2_sd': d2_sd,
        }
    return results


# ============================================================
# 第五部分：方向 5 —— 裂项结构的二阶差分特征
# ============================================================

def find_flat_segments(d2, s_grid, tol=1e-6):
    """
    找出二阶差分接近零的连续区间（裂项区间）。
    """
    segments = []
    start = None
    for k in range(len(d2)):
        if abs(d2[k]) < tol:
            if start is None:
                start = k
        else:
            if start is not None:
                if k - start >= 3:
                    segments.append({
                        's_start': float(s_grid[start]),
                        's_end': float(s_grid[k]),
                        'length': k - start,
                    })
                start = None
    if start is not None and len(d2) - start >= 3:
        segments.append({
            's_start': float(s_grid[start]),
            's_end': float(s_grid[-1]),
            'length': len(d2) - start,
        })
    return segments


# ============================================================
# 主流程
# ============================================================

def main():
    t0 = time.time()
    
    print("\n" + "=" * 70)
    print("构建两个关系类...")
    print("=" * 70)
    rep_A, rep_B, n_A, n_B = build_two_relation_classes()
    print(f"类 A（删除边共享节点）: {n_A} 个组合")
    print(f"类 B（删除边不共享节点）: {n_B} 个组合")
    print(f"类 A 代表: removed={rep_A[1], rep_A[2]}")
    print(f"类 B 代表: removed={rep_B[1], rep_B[2]}")
    
    print("\n" + "=" * 70)
    print("【方向 1】关系位置三元组的穷举分类")
    print("=" * 70)
    for name, rep in [('A', rep_A), ('B', rep_B)]:
        G, r1, r2 = rep
        cls = classify_all_edges(G, (r1, r2))
        print(f"\n  类 {name}: removed={r1, r2}")
        for tag, edges in sorted(cls.items()):
            print(f"    {tag}: {len(edges)} 条边")
            for e, n1, n2 in edges[:3]:
                print(f"      {e}  (与 r1 共享 {n1}, 与 r2 共享 {n2})")
    
    print("\n" + "=" * 70)
    print("【方向 2 & 3】s* 集合与有理数识别")
    print("=" * 70)
    
    all_results = {}
    all_s_stars = {}
    
    for name, rep in [('A', rep_A), ('B', rep_B)]:
        G, r1, r2 = rep
        print(f"\n--- 类 {name}: removed={r1, r2} ---")
        results = scan_all_edges(G, (r1, r2), CONFIG['s_fine'])
        all_results[name] = results
        
        # 收集所有 s*
        s_stars = defaultdict(list)  # target -> [(edge, s, source)]
        for e, r in results.items():
            for target, hits in r['hits'].items():
                for src, sv in hits:
                    s_stars[target].append((e, sv, src))
        all_s_stars[name] = dict(s_stars)
        
        for target in sorted(s_stars.keys()):
            hit_list = s_stars[target]
            unique_s = sorted(set(round(h[1], 6) for h in hit_list))
            print(f"    {target}: {len(hit_list)} 次命中, "
                  f"{len(unique_s)} 个唯一 s")
            for sv in unique_s[:8]:
                rat = rational_identify(sv)
                rat_str = f"{rat[0]}/{rat[1]}" if rat else "非有理"
                print(f"      s={sv:.6f}  ->  {rat_str}")
    
    print("\n" + "=" * 70)
    print("【方向 4】两个关系类的 s* 映射并排")
    print("=" * 70)
    print(f"\n  {'target':<10} {'类 A s*':<40} {'类 B s*':<40}")
    print("  " + "-" * 90)
    
    all_targets = set(all_s_stars['A'].keys()) | set(all_s_stars['B'].keys())
    for target in sorted(all_targets):
        sa = sorted(set(round(h[1], 4) for h in all_s_stars['A'].get(target, [])))
        sb = sorted(set(round(h[1], 4) for h in all_s_stars['B'].get(target, [])))
        sa_str = ', '.join(f"{x:+.4f}" for x in sa[:5]) if sa else '(none)'
        sb_str = ', '.join(f"{x:+.4f}" for x in sb[:5]) if sb else '(none)'
        print(f"  {target:<10} {sa_str:<40} {sb_str:<40}")
    
    print("\n" + "=" * 70)
    print("【方向 5】裂项结构的二阶差分特征")
    print("=" * 70)
    
    for name, rep in [('A', rep_A), ('B', rep_B)]:
        print(f"\n--- 类 {name} ---")
        results = all_results[name]
        for e, r in list(results.items())[:3]:
            segs_E0 = find_flat_segments(r['d2_E0'], CONFIG['s_fine'][1:-1])
            segs_gap = find_flat_segments(r['d2_gap'], CONFIG['s_fine'][1:-1])
            print(f"    {e}:")
            print(f"      E0 裂项区间: {len(segs_E0)} 段")
            for seg in segs_E0[:2]:
                print(f"        s ∈ [{seg['s_start']:.4f}, {seg['s_end']:.4f}]")
            print(f"      gap 裂项区间: {len(segs_gap)} 段")
            for seg in segs_gap[:2]:
                print(f"        s ∈ [{seg['s_start']:.4f}, {seg['s_end']:.4f}]")
    
    # ============================================================
    # 元反思律声明
    # ============================================================
    print("\n" + "=" * 70)
    print("元反思律声明")
    print("=" * 70)
    print("""
本脚本的盲区与未解决问题：

1. 【关系位置假设】我们假设 s* 由关系位置决定。
   如果没有决定关系，脚本会如实报告。

2. 【有理数识别】分母 ≤ 100，s* 可能是更高分母或无理数。

3. 【二阶差分检验】平坦区间可能受网格分辨率影响。
   更细的网格可能揭示更复杂的裂项结构。

4. 【关系类的完备性】K_6 减两边只有 2 类，
   但 N=7 可能有更多关系类。
   追问：关系类的数量是否随 N 增长？

5. 【最深的自指】
   我们在用"关系位置 → s*"的映射追问关系本体论。
   但映射本身是对象化的。
   如果关系不能被对象化，
   那么所有映射最终都会失败。
   失败本身是否揭示了"关系位置"的真面目？

6. 【行动追问】
   你准备用哪个 s* 去做什么行动？
   不是写论文，不是投期刊，是行动。
""")
    
    # 保存
    print("\n保存结果...")
    save = {
        'class_A_removed': [list(rep_A[1]), list(rep_A[2])],
        'class_B_removed': [list(rep_B[1]), list(rep_B[2])],
        's_stars': {
            name: {t: [(list(e), s, src) for e, s, src in hits]
                   for t, hits in s_stars.items()}
            for name, s_stars in all_s_stars.items()
        },
    }
    with open(os.path.join(CONFIG['output_dir'], 'summary.json'),
              'w', encoding='utf-8') as f:
        json.dump(save, f, indent=2, ensure_ascii=False)
    
    print(f"完成。耗时 {time.time() - t0:.1f} 秒。")
    print("过程继续。不给结论。")


if __name__ == '__main__':
    main()