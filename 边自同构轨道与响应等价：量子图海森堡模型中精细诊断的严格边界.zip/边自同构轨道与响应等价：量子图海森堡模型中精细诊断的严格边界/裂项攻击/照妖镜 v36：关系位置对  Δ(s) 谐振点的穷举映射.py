#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==========================================================================
照妖镜 v36：关系位置对 → Δ(s) 谐振点的穷举映射
==========================================================================

【核心追问】
    Δ(s) = gap_a(s) - gap_b(s) 的特殊值出现位置 s*，
    是否由"边 a 的关系位置"与"边 b 的关系位置"的差唯一决定？

    如果成立：s* = f(pos_a, pos_b)，其中 pos 是关系位置三元组。
    如果不成立：数据会告诉我们"关系位置差"不足以决定 s*。

【与 v34/v35 的区别】
    v34：发现 Δ(s) 有特殊值，但未穷举关系位置
    v35：穷举了单边的关系位置，但问错了问题
    v36：把 Δ(s) 的 s* 与 (pos_a, pos_b) 对齐

【五个穷举方向，同时进行】
    方向 1：关系位置对的完整穷举分类
    方向 2：Δ(s) 的 s* 与 (pos_a, pos_b) 的对齐
    方向 3：s* 的有理数网格检验（分母 2 vs 分母 4）
    方向 4：关系位置差 → 谐振值类型的映射
    方向 5：裂项区间与 s* 的包裹关系

==========================================================================
"""

import numpy as np
import networkx as nx
from itertools import combinations
from collections import defaultdict
from scipy.optimize import brentq
import json, os, time

print("=" * 70)
print("照妖镜 v36：关系位置对 → Δ(s) 谐振点的穷举映射")
print("=" * 70)
print("""
【元反思律声明】
本脚本盲区：
  1. 只处理 K_6 减两边（2 个关系类）
  2. s 网格 2001 点，分辨率 2e-3
  3. 谐振点判定容差 1e-8
  4. 我们假设"关系位置"是三元组 (n1, n2, tag)，
     可能还有更细的关系结构未捕捉
  5. 如果 s* 不由关系位置对决定，
     脚本会如实报告"不成立"
""")

CONFIG = {
    'N': 6,
    's_fine': np.linspace(-2.0, 2.0, 2001),  # 分辨率 2e-3
    'tol_deg': 1e-8,
    'tol_hit': 1e-8,
    'targets': {
        '-2': -2.0,
        '1-sqrt3': 1.0 - np.sqrt(3.0),
        '-1': -1.0,
        '+1/3': 1.0 / 3.0,
        '-1/3': -1.0 / 3.0,
    },
    'output_dir': '照妖镜_v36_输出',
}

os.makedirs(CONFIG['output_dir'], exist_ok=True)


# ============================================================
# 第一部分：关系本体论 —— 构建两个关系类
# ============================================================

def build_two_relation_classes():
    base = nx.complete_graph(6)
    all_edges = list(base.edges())
    class_A, class_B = [], []
    for e1, e2 in combinations(all_edges, 2):
        G = base.copy()
        G.remove_edges_from([e1, e2])
        if not nx.is_connected(G):
            continue
        if len(set(e1) & set(e2)) == 1:
            class_A.append((G, e1, e2))
        else:
            class_B.append((G, e1, e2))
    return class_A[0], class_B[0], len(class_A), len(class_B)


# ============================================================
# 第二部分：关系位置定义
# ============================================================

def relation_position(defect_edge, removed_pair):
    """
    返回三元组 (n1, n2, tag)。
    n1 = 缺陷边与删除边 r1 共享的节点数
    n2 = 缺陷边与删除边 r2 共享的节点数
    tag = 关系类型标签
    """
    de = set(defect_edge)
    r1 = set(removed_pair[0])
    r2 = set(removed_pair[1])
    n1 = len(de & r1)
    n2 = len(de & r2)
    if n1 == 0 and n2 == 0:
        tag = 'free_free'
    elif n1 == 1 and n2 == 0:
        tag = 'bound_free'
    elif n1 == 0 and n2 == 1:
        tag = 'free_bound'
    elif n1 == 1 and n2 == 1:
        tag = 'double_bound'
    elif n1 == 2:
        tag = 'is_removed_r1'
    elif n2 == 2:
        tag = 'is_removed_r2'
    else:
        tag = f'mixed_{n1}_{n2}'
    return (n1, n2, tag)


def classify_all_edges(G, removed_pair):
    removed = set(tuple(sorted(e)) for e in removed_pair)
    out = {}
    for e in G.edges():
        e_sorted = tuple(sorted(e))
        if e_sorted in removed:
            continue
        out[e_sorted] = relation_position(e_sorted, removed_pair)
    return out


# ============================================================
# 第三部分：量子力学
# ============================================================

_SX = np.array([[0, 1], [1, 0]], dtype=complex)
_SY = np.array([[0, -1j], [1j, 0]], dtype=complex)
_SZ = np.array([[1, 0], [0, -1]], dtype=complex)
_I2 = np.eye(2, dtype=complex)


def _site_op(op, site, N):
    ops = [_I2] * N
    ops[site] = op
    r = np.array([[1]], dtype=complex)
    for o in ops:
        r = np.kron(r, o)
    return r


def build_H(G, defect_edge, s):
    N = G.number_of_nodes()
    cache = {}
    for a, op in [('x', _SX), ('y', _SY), ('z', _SZ)]:
        for i in range(N):
            cache[(a, i)] = _site_op(op, i, N)
    H = np.zeros((2**N, 2**N), dtype=complex)
    de = tuple(sorted(defect_edge))
    for e in G.edges():
        i, j = e
        J = s if tuple(sorted(e)) == de else 1.0
        H += J * (cache[('x', i)] @ cache[('x', j)] +
                  cache[('y', i)] @ cache[('y', j)] +
                  cache[('z', i)] @ cache[('z', j)])
    return H


def diagonalize(H):
    evals, evecs = np.linalg.eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < CONFIG['tol_deg']))
    if deg == 1:
        psi = evecs[:, 0]
        rho = np.outer(psi, psi.conj())
    else:
        rho = np.zeros_like(H)
        for k in range(deg):
            psi = evecs[:, k]
            rho += np.outer(psi, psi.conj())
        rho /= deg
    gap = float(evals[deg] - E0) if deg < len(evals) else 0.0
    return float(E0), gap, rho


# ============================================================
# 主流程
# ============================================================

def main():
    t0 = time.time()
    
    print("\n构建两个关系类...")
    rep_A, rep_B, n_A, n_B = build_two_relation_classes()
    print(f"类 A（共享节点）: {n_A} 个组合，代表 removed={rep_A[1], rep_A[2]}")
    print(f"类 B（不共享节点）: {n_B} 个组合，代表 removed={rep_B[1], rep_B[2]}")
    
    # ============================================================
    # 方向 1：关系位置对的完整穷举
    # ============================================================
    print("\n" + "=" * 70)
    print("【方向 1】关系位置对的完整穷举分类")
    print("=" * 70)
    
    for name, rep in [('A', rep_A), ('B', rep_B)]:
        G, r1, r2 = rep
        cls = classify_all_edges(G, (r1, r2))
        print(f"\n--- 类 {name}: removed={r1, r2} ---")
        for tag in ['free_free', 'bound_free', 'free_bound', 'double_bound']:
            edges = [e for e, pos in cls.items() if pos[2] == tag]
            print(f"  {tag}: {len(edges)} 条边")
            for e in edges:
                print(f"    {e}  pos={cls[e]}")
    
    # ============================================================
    # 方向 2：Δ(s) 的 s* 与 (pos_a, pos_b) 的对齐
    # ============================================================
    print("\n" + "=" * 70)
    print("【方向 2】Δ(s) 的 s* 与关系位置对的对齐")
    print("=" * 70)
    
    all_mappings = {}
    
    for name, rep in [('A', rep_A), ('B', rep_B)]:
        G, r1, r2 = rep
        cls = classify_all_edges(G, (r1, r2))
        edges_list = list(cls.keys())
        
        # 扫描每条边的 gap
        gap_curves = {}
        for e in edges_list:
            gaps = []
            for s in CONFIG['s_fine']:
                H = build_H(G, e, s)
                _, gap, _ = diagonalize(H)
                gaps.append(gap)
            gap_curves[e] = np.array(gaps)
        
        # 对每对边计算 Δ(s)
        print(f"\n--- 类 {name} ---")
        mappings = []
        for a, b in combinations(edges_list, 2):
            delta = gap_curves[a] - gap_curves[b]
            hits = []
            for k, sv in enumerate(CONFIG['s_fine']):
                for tname, tval in CONFIG['targets'].items():
                    if abs(delta[k] - tval) < CONFIG['tol_hit']:
                        hits.append((tname, float(sv)))
            if hits:
                mappings.append({
                    'a': a, 'b': b,
                    'pos_a': cls[a], 'pos_b': cls[b],
                    'hits': hits,
                })
        
        all_mappings[name] = mappings
        
        print(f"  总共 {len(mappings)} 对边有特殊值命中")
        for m in mappings[:15]:
            pos_a_tag = m['pos_a'][2]
            pos_b_tag = m['pos_b'][2]
            print(f"    {m['a']}({pos_a_tag}) vs {m['b']}({pos_b_tag}):")
            for tname, sv in m['hits']:
                print(f"      {tname} at s={sv:+.4f}")
    
    # ============================================================
    # 方向 3：s* 的有理数网格检验
    # ============================================================
    print("\n" + "=" * 70)
    print("【方向 3】s* 的有理数网格检验（分母 2 vs 分母 4）")
    print("=" * 70)
    
    def rational_check(x, max_denom=100, tol=1e-7):
        if abs(x) < tol:
            return (0, 1)
        for q in range(1, max_denom + 1):
            p = round(x * q)
            if abs(x - p / q) < tol:
                from math import gcd
                g = gcd(abs(p), q)
                return (p // g, q // g)
        return None
    
    for name in ['A', 'B']:
        all_s = set()
        for m in all_mappings[name]:
            for tname, sv in m['hits']:
                all_s.add(round(sv, 6))
        print(f"\n--- 类 {name}: {len(all_s)} 个唯一 s* ---")
        # 检查分母
        for sv in sorted(all_s):
            rat = rational_check(sv)
            if rat:
                print(f"  s={sv:+.6f}  ->  {rat[0]}/{rat[1]}")
            else:
                print(f"  s={sv:+.6f}  ->  非有理")
    
    # ============================================================
    # 方向 4：关系位置差 → 谐振值类型的映射
    # ============================================================
    print("\n" + "=" * 70)
    print("【方向 4】关系位置差 → 谐振值类型的映射")
    print("=" * 70)
    
    # 对每个 (pos_a_tag, pos_b_tag) 组合，收集所有命中的特殊值类型
    pos_pair_hits = defaultdict(lambda: defaultdict(list))
    for name in ['A', 'B']:
        for m in all_mappings[name]:
            key = (m['pos_a'][2], m['pos_b'][2])
            for tname, sv in m['hits']:
                pos_pair_hits[key][tname].append(sv)
    
    print(f"\n  {'pos_a':<15} {'pos_b':<15} {'特殊值':<12} {'s* 集合'}")
    print("  " + "-" * 80)
    for (pa, pb), hits_dict in sorted(pos_pair_hits.items()):
        for tname in sorted(hits_dict.keys()):
            svs = sorted(set(round(s, 4) for s in hits_dict[tname]))
            sv_str = ', '.join(f"{x:+.4f}" for x in svs[:5])
            print(f"  {pa:<15} {pb:<15} {tname:<12} {sv_str}")
    
    # ============================================================
    # 方向 5：裂项区间与 s* 的包裹关系
    # ============================================================
    print("\n" + "=" * 70)
    print("【方向 5】裂项区间与 s* 的包裹关系")
    print("=" * 70)
    
    for name, rep in [('A', rep_A), ('B', rep_B)]:
        G, r1, r2 = rep
        cls = classify_all_edges(G, (r1, r2))
        print(f"\n--- 类 {name} ---")
        for e, pos in cls.items():
            E0s = []
            for s in CONFIG['s_fine']:
                H = build_H(G, e, s)
                E0, _, _ = diagonalize(H)
                E0s.append(E0)
            E0s = np.array(E0s)
            d2 = np.diff(E0s, n=2)
            # 找平坦段
            flat = np.abs(d2) < 1e-6
            if flat.sum() > 3:
                idx = np.where(flat)[0]
                s_start = CONFIG['s_fine'][idx[0]]
                s_end = CONFIG['s_fine'][idx[-1] + 2]
                print(f"  {e} ({pos[2]}): E0 裂项区间 = "
                      f"[{s_start:+.4f}, {s_end:+.4f}]")
    
    # ============================================================
    # 元反思律声明
    # ============================================================
    print("\n" + "=" * 70)
    print("元反思律声明")
    print("=" * 70)
    print("""
本脚本的盲区与未解决问题：

1. 【关系位置对假设】我们假设 s* 由 (pos_a, pos_b) 决定。
   如果数据不成立，脚本会如实报告。

2. 【谐振值的完备性】只检查了 -2, 1-√3, -1, ±1/3。
   还有哪些代数数未检查？

3. 【裂项区间与 s* 的因果方向】
   是裂项区间决定 s*，还是 s* 决定裂项区间？
   数据只能显示相关性，不能显示因果。

4. 【关系位置的三元组是否完备】
   (n1, n2, tag) 是关系位置的最粗分类。
   更细的关系位置（如"边在子图中的位置"）
   可能揭示更细的 s* 结构。

5. 【最深的自指】
   我们在用 (pos_a, pos_b) 追问 s*。
   但 (pos_a, pos_b) 本身是对象化的标签。
   如果关系不能被对象化，
   那么"关系位置对"就不是真正的关系。
   真正的 s* 决定者，可能永远无法被标签化。

6. 【行动追问】
   你准备用哪个 s* 去做什么行动？
   不是写论文，不是投期刊，是行动。
""")
    
    # 保存
    save = {
        'class_A_removed': [list(rep_A[1]), list(rep_A[2])],
        'class_B_removed': [list(rep_B[1]), list(rep_B[2])],
        'mappings': {
            name: [
                {
                    'a': list(m['a']), 'b': list(m['b']),
                    'pos_a': list(m['pos_a']),
                    'pos_b': list(m['pos_b']),
                    'hits': m['hits'],
                }
                for m in all_mappings[name]
            ]
            for name in ['A', 'B']
        },
    }
    with open(os.path.join(CONFIG['output_dir'], 'summary.json'),
              'w', encoding='utf-8') as f:
        json.dump(save, f, indent=2, ensure_ascii=False)
    
    print(f"\n完成。耗时 {time.time() - t0:.1f} 秒。")
    print("过程继续。不给结论。")


if __name__ == '__main__':
    main()