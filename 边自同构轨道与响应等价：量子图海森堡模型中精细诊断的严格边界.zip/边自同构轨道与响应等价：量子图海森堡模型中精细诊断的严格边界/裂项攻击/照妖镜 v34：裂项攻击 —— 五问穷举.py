#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==========================================================================
照妖镜 v34：裂项攻击 —— 五问穷举
==========================================================================

【核心追问】
    特殊代数数（-2, 1-√3, ±1/3, -1）是否来自统一的关系裂项结构？
    E(s) = Σ_k [g_k(s_{k+1}) - g_k(s_k)] 的中间项能否在
    s=0 或 s=0.5 处发生代数抵消？

【理论精髓】
    关系本体论：节点无属性，一切来自关系图
    矛盾动力论：缺陷边是矛盾焦点，扫描即让矛盾显形
    实践介入论：全链路审计，不隐藏任何一步
    谐振调谐论：不预设目标，只报告状态
    元反思律：脚本最后声明盲区与未解决问题

【方法论原则】
    只查同与不同：不拟合，不回归，不预设结论
    不筛除数据：所有边、所有图、所有结果如实报告
    基态简并必须显式处理：用对称性约化密度矩阵
    严防工具理性悖论：不用技术手段解决技术逻辑造成的问题
    反对对齐：让数据说话
    标准物理与关系本体论并排呈现

【五个穷举方向，同时进行】
    方向 1：E0(s) 的裂项展开
    方向 2：Δ(s) = gap_defect(s) - gap_ref(s) 的裂项展开
    方向 3：p_S(s) 的裂项展开
    方向 4：<sigma·sigma>(s) 的裂项展开
    方向 5：跨图族统一裂项结构

==========================================================================
"""

import numpy as np
import networkx as nx
from itertools import combinations
from scipy.optimize import brentq
from collections import defaultdict
import json
import os
import time

# ============================================================
# 【元反思律声明】脚本的盲区
# ============================================================
print("=" * 70)
print("照妖镜 v34：裂项攻击 —— 五问穷举")
print("=" * 70)
print("""
【元反思律声明】
本脚本的盲区：
  1. N=6 的 112 个连通图，不是全部 N=6 图
  2. s 网格有限（81 点细扫，401 点裂项细扫），
     裂项分析受限于网格分辨率
  3. 代数识别受限于有理数、二次代数数
  4. 裂项假设可能不成立——如果没有裂项结构，
     脚本会如实报告"未找到"
  5. 我们不知道裂项展开是否是正确工具——
     脚本只检验它，不预设它正确
""")

CONFIG = {
    'N': 6,
    's_grid': np.linspace(-2.0, 2.0, 81),
    's_fine': np.linspace(-2.0, 2.0, 401),
    'tol_degeneracy': 1e-8,
    'tol_curve': 1e-10,
    'tol_algebraic': 1e-10,
    'output_dir': '照妖镜_v34_输出',
}

os.makedirs(CONFIG['output_dir'], exist_ok=True)


# ============================================================
# 第一部分：关系本体论 —— 构建关系图
# ============================================================

def build_K6_minus_2():
    """
    构建 K_6 减两边的全部连通图。
    关系本体论：节点无属性，一切来自边。
    """
    base = nx.complete_graph(6)
    all_edges = list(base.edges())
    graphs = []
    info = []
    
    for e1, e2 in combinations(all_edges, 2):
        G = base.copy()
        G.remove_edges_from([e1, e2])
        if nx.is_connected(G):
            graphs.append(G)
            info.append({
                'gid': len(graphs) - 1,
                'removed': [e1, e2],
                'edges': list(G.edges()),
            })
    
    # 去重（同构）
    unique = []
    unique_info = []
    for G, inf in zip(graphs, info):
        iso = False
        for H in unique:
            if nx.is_isomorphic(G, H):
                iso = True
                break
        if not iso:
            unique.append(G)
            unique_info.append(inf)
    
    # 重编号
    for i, inf in enumerate(unique_info):
        inf['gid'] = i
    
    return unique, unique_info


def get_edge_orbits(G):
    """
    边自同构轨道。
    同关系同响应思维：轨道内的边位置等价。
    """
    GM = nx.algorithms.isomorphism.GraphMatcher(G, G)
    autos = list(GM.isomorphisms_iter())
    
    edges = list(G.edges())
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    
    orbit_map = {i: set() for i in range(len(edges))}
    for e_idx, e in enumerate(edges):
        e_sorted = tuple(sorted(e))
        for auto in autos:
            e_mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if e_mapped in edge_to_idx:
                orbit_map[e_idx].add(edge_to_idx[e_mapped])
    
    orbits = []
    assigned = set()
    for i in range(len(edges)):
        if i in assigned:
            continue
        orbit = set()
        stack = [i]
        while stack:
            j = stack.pop()
            if j in orbit:
                continue
            orbit.add(j)
            for k in orbit_map[j]:
                if k not in orbit:
                    stack.append(k)
        for j in orbit:
            assigned.add(j)
        orbits.append(sorted(orbit))
    
    return orbits, edges


# ============================================================
# 第二部分：矛盾动力论 —— 哈密顿量与对角化
# ============================================================

_SIGMA_X = np.array([[0, 1], [1, 0]], dtype=complex)
_SIGMA_Y = np.array([[0, -1j], [1j, 0]], dtype=complex)
_SIGMA_Z = np.array([[1, 0], [0, -1]], dtype=complex)
_I2 = np.eye(2, dtype=complex)


def _kron(ops):
    r = np.array([[1]], dtype=complex)
    for o in ops:
        r = np.kron(r, o)
    return r


def _site_op(op, site, N):
    ops = [_I2] * N
    ops[site] = op
    return _kron(ops)


def build_H(G, defect_edge, s, rule='heisenberg'):
    N = G.number_of_nodes()
    edges = list(G.edges())
    dim = 2 ** N
    H = np.zeros((dim, dim), dtype=complex)
    
    # 缓存 site ops
    cache = {}
    for a, op in [('x', _SIGMA_X), ('y', _SIGMA_Y), ('z', _SIGMA_Z)]:
        for i in range(N):
            cache[(a, i)] = _site_op(op, i, N)
    
    for e in edges:
        i, j = e
        J = s if tuple(sorted(e)) == tuple(sorted(defect_edge)) else 1.0
        if rule == 'heisenberg':
            H += J * (cache[('x', i)] @ cache[('x', j)] +
                      cache[('y', i)] @ cache[('y', j)] +
                      cache[('z', i)] @ cache[('z', j)])
        elif rule == 'xxz':
            H += J * (cache[('x', i)] @ cache[('x', j)] +
                      cache[('y', i)] @ cache[('y', j)] +
                      1.5 * cache[('z', i)] @ cache[('z', j)])
        elif rule == 'ising':
            H += J * (cache[('z', i)] @ cache[('z', j)])
        elif rule == 'xy':
            H += J * (cache[('x', i)] @ cache[('x', j)] +
                      cache[('y', i)] @ cache[('y', j)])
    return H


def diagonalize(H, tol_deg=1e-8):
    """
    显式处理简并。
    实践介入论：不隐藏数值陷阱。
    """
    evals, evecs = np.linalg.eigh(H)
    E0 = evals[0]
    deg = int(np.sum(np.abs(evals - E0) < tol_deg))
    
    if deg == 1:
        psi = evecs[:, 0]
        rho = np.outer(psi, psi.conj())
    else:
        rho = np.zeros_like(H)
        for k in range(deg):
            psi = evecs[:, k]
            rho += np.outer(psi, psi.conj())
        rho /= deg
    
    gap = evals[deg] - E0 if deg < len(evals) else 0.0
    return {'E0': float(E0), 'deg': deg, 'gap': float(gap), 'rho': rho}


def two_site_corr(rho, G, e):
    """<sigma_i·sigma_j> 和 <sigma_z_i sigma_z_j>"""
    N = G.number_of_nodes()
    i, j = e
    zz = 0.0; sd = 0.0
    for a, op in [('x', _SIGMA_X), ('y', _SIGMA_Y), ('z', _SIGMA_Z)]:
        oi = _site_op(op, i, N)
        oj = _site_op(op, j, N)
        sd += float(np.real(np.trace(rho @ oi @ oj)))
        if a == 'z':
            zz = float(np.real(np.trace(rho @ oi @ oj)))
    return zz, sd


def ps_from_zz(zz):
    """p_S = (1 - 3*zz)/4"""
    return (1.0 - 3.0 * zz) / 4.0


# ============================================================
# 第三部分：五个穷举方向
# ============================================================

def d1_E0_curve(G, edges, s_grid, rule='heisenberg'):
    """
    方向 1：E0(s) 裂项。
    追问：E0(s) 能否写成 Σ[g(s_{k+1}) - g(s_k)]？
    """
    out = []
    for e in edges:
        E0s = []
        for s in s_grid:
            H = build_H(G, e, s, rule)
            E0s.append(diagonalize(H)['E0'])
        E0s = np.array(E0s)
        dE0 = np.diff(E0s)
        ds = np.diff(s_grid)
        slope = dE0 / ds  # 若裂项成立，slope 应简单
        out.append({
            'edge': tuple(sorted(e)),
            'E0_first': float(E0s[0]),
            'E0_last': float(E0s[-1]),
            'dE0_mean': float(np.mean(dE0)),
            'dE0_std': float(np.std(dE0)),
            'slope_mean': float(np.mean(slope)),
            'slope_std': float(np.std(slope)),
        })
    return out


def d2_gap_diff_curve(G, edges, s_grid, rule='heisenberg'):
    """
    方向 2：Δgap(s) = gap_i(s) - gap_j(s) 裂项。
    追问：-2 和 1-√3 是否来自裂项部分和？
    """
    gap_curves = {}
    for e in edges:
        gaps = []
        for s in s_grid:
            H = build_H(G, e, s, rule)
            gaps.append(diagonalize(H)['gap'])
        gap_curves[tuple(sorted(e))] = np.array(gaps)
    
    out = []
    edge_list = list(gap_curves.keys())
    for a, b in combinations(edge_list, 2):
        delta = gap_curves[a] - gap_curves[b]
        hits = []
        for k, sv in enumerate(s_grid):
            for target, name in [(-2.0, '-2'), (1 - np.sqrt(3), '1-√3'),
                                 (-1.0, '-1'), (1/3, '+1/3')]:
                if abs(delta[k] - target) < 1e-10:
                    hits.append((float(sv), name, float(delta[k])))
        out.append({
            'edge_a': a, 'edge_b': b,
            'delta_min': float(np.min(delta)),
            'delta_max': float(np.max(delta)),
            'hits': hits,
        })
    return out


def d3_ps_curve(G, edges, s_grid, rule='heisenberg'):
    """
    方向 3：p_S(s) 裂项。
    追问：p_S = 1/2 谐振点是否来自裂项累积？
    """
    out = []
    for e in edges:
        ps_vals = []
        for s in s_grid:
            H = build_H(G, e, s, rule)
            dg = diagonalize(H)
            zz, _ = two_site_corr(dg['rho'], G, e)
            ps_vals.append(ps_from_zz(zz))
        ps_vals = np.array(ps_vals)
        # 谐振点：p_S = 1/2
        res = []
        for k in range(len(ps_vals) - 1):
            if (ps_vals[k] - 0.5) * (ps_vals[k+1] - 0.5) < 0:
                try:
                    sr = brentq(lambda s: _ps_at(G, e, s, rule) - 0.5,
                                s_grid[k], s_grid[k+1])
                    res.append(float(sr))
                except Exception:
                    pass
        out.append({
            'edge': tuple(sorted(e)),
            'ps_at_s0': float(ps_vals[np.argmin(np.abs(s_grid))]),
            'ps_at_s05': float(ps_vals[np.argmin(np.abs(s_grid - 0.5))]),
            'resonance_s': res,
        })
    return out


def _ps_at(G, e, s, rule='heisenberg'):
    H = build_H(G, e, s, rule)
    dg = diagonalize(H)
    zz, _ = two_site_corr(dg['rho'], G, e)
    return ps_from_zz(zz)


def d4_sd_curve(G, edges, s_grid, rule='heisenberg'):
    """
    方向 4：<sigma·sigma>(s) 裂项。
    追问：±1/3, -1, +1 是否来自裂项？
    """
    out = []
    for e in edges:
        sd_vals = []
        for s in s_grid:
            H = build_H(G, e, s, rule)
            dg = diagonalize(H)
            _, sd = two_site_corr(dg['rho'], G, e)
            sd_vals.append(sd)
        sd_vals = np.array(sd_vals)
        hits = []
        for k, sv in enumerate(s_grid):
            for target, name in [(1/3, '+1/3'), (-1/3, '-1/3'),
                                 (-1.0, '-1'), (1.0, '+1'), (-3.0, '-3')]:
                if abs(sd_vals[k] - target) < 1e-10:
                    hits.append((float(sv), name))
        out.append({
            'edge': tuple(sorted(e)),
            'sd_at_s0': float(sd_vals[np.argmin(np.abs(s_grid))]),
            'sd_at_s05': float(sd_vals[np.argmin(np.abs(s_grid - 0.5))]),
            'hits': hits,
        })
    return out


def d5_cross_graph(graphs, infos, s_grid, rule='heisenberg'):
    """
    方向 5：跨图统一裂项。
    追问：-2 和 1-√3 是否在所有图中共享相同的裂项形式？
    """
    all_hits = {'-2': [], '1-sqrt3': []}
    total_pairs = 0
    
    for G, inf in zip(graphs, infos):
        edges = list(G.edges())
        gap_curves = {}
        for e in edges:
            gaps = []
            for s in s_grid:
                H = build_H(G, e, s, rule)
                gaps.append(diagonalize(H)['gap'])
            gap_curves[tuple(sorted(e))] = np.array(gaps)
        
        el = list(gap_curves.keys())
        for a, b in combinations(el, 2):
            total_pairs += 1
            delta = gap_curves[a] - gap_curves[b]
            for k, sv in enumerate(s_grid):
                if abs(delta[k] + 2.0) < 1e-10:
                    all_hits['-2'].append({
                        'gid': inf['gid'],
                        'removed': inf['removed'],
                        'edge_a': a, 'edge_b': b,
                        's': float(sv),
                    })
                if abs(delta[k] - (1 - np.sqrt(3))) < 1e-10:
                    all_hits['1-sqrt3'].append({
                        'gid': inf['gid'],
                        'removed': inf['removed'],
                        'edge_a': a, 'edge_b': b,
                        's': float(sv),
                    })
    
    return {'total_pairs': total_pairs, 'hits': all_hits}


# ============================================================
# 第四部分：主流程
# ============================================================

def main():
    t0 = time.time()
    
    print("\n" + "=" * 70)
    print("构建 K_6 减两边的全部连通图...")
    print("=" * 70)
    graphs, infos = build_K6_minus_2()
    print(f"找到 {len(graphs)} 个连通图（去重后）")
    
    # 计算边轨道
    print("\n计算边自同构轨道...")
    orbits_all = {}
    for inf, G in zip(infos, graphs):
        orbits, edges = get_edge_orbits(G)
        orbits_all[inf['gid']] = {'orbits': orbits, 'edges': edges}
    
    # 选出与图 108、109 对应的图
    # 图 108: K_6 删除 (2,5),(3,5)，共享节点
    # 图 109: K_6 删除 (0,1),(2,3)，不共享节点
    target_gids = []
    for inf in infos:
        r = [tuple(sorted(e)) for e in inf['removed']]
        r_set = set(r)
        # 检查共享节点
        shared = len(set(r[0]) & set(r[1]))
        if shared == 1:
            target_gids.append((inf['gid'], 'shared'))
        elif shared == 0:
            target_gids.append((inf['gid'], 'disjoint'))
    
    # 取代表性的图（共享节点、不共享节点各一个）
    sample_gids = []
    seen = set()
    for gid, kind in target_gids:
        if kind not in seen:
            sample_gids.append(gid)
            seen.add(kind)
        if len(sample_gids) >= 4:
            break
    
    print(f"选取代表性图 gids = {sample_gids}")
    
    # ============================================================
    # 五方向穷举
    # ============================================================
    
    results = {
        'd1': {}, 'd2': {}, 'd3': {}, 'd4': {},
    }
    
    for gid in sample_gids:
        G = graphs[gid]
        edges = orbits_all[gid]['edges']
        print(f"\n处理 gid={gid}, removed={infos[gid]['removed']}, "
              f"|E|={len(edges)}")
        
        print("  [1] E0(s) 裂项...")
        results['d1'][gid] = d1_E0_curve(G, edges, CONFIG['s_fine'])
        
        print("  [2] Δgap(s) 裂项...")
        results['d2'][gid] = d2_gap_diff_curve(G, edges, CONFIG['s_grid'])
        
        print("  [3] p_S(s) 裂项...")
        results['d3'][gid] = d3_ps_curve(G, edges, CONFIG['s_grid'])
        
        print("  [4] <σ·σ>(s) 裂项...")
        results['d4'][gid] = d4_sd_curve(G, edges, CONFIG['s_grid'])
    
    print("\n  [5] 跨图统一裂项（全部图）...")
    d5 = d5_cross_graph(graphs, infos, CONFIG['s_grid'])
    
    # ============================================================
    # 结果并排输出
    # ============================================================
    
    print("\n" + "=" * 70)
    print("结果并排输出")
    print("=" * 70)
    
    print("\n【方向 1：E0(s) 裂项结构】")
    print("-" * 70)
    for gid in sample_gids:
        print(f"  图 gid={gid} (removed={infos[gid]['removed']}):")
        for r in results['d1'][gid][:4]:
            print(f"    {r['edge']}: slope_mean={r['slope_mean']:.6f}, "
                  f"slope_std={r['slope_std']:.6f}")
    
    print("\n【方向 2：Δgap(s) 裂项 —— 特殊值命中】")
    print("-" * 70)
    for gid in sample_gids:
        print(f"  图 gid={gid}:")
        for r in results['d2'][gid]:
            if r['hits']:
                print(f"    {r['edge_a']} vs {r['edge_b']}: hits={r['hits']}")
    
    print("\n【方向 3：p_S(s) 裂项 —— 谐振点】")
    print("-" * 70)
    for gid in sample_gids:
        print(f"  图 gid={gid}:")
        for r in results['d3'][gid][:4]:
            print(f"    {r['edge']}: resonance_s={r['resonance_s']}, "
                  f"ps@0={r['ps_at_s0']:.6f}, ps@0.5={r['ps_at_s05']:.6f}")
    
    print("\n【方向 4：<σ·σ>(s) 裂项 —— 特殊值命中】")
    print("-" * 70)
    for gid in sample_gids:
        print(f"  图 gid={gid}:")
        for r in results['d4'][gid][:4]:
            print(f"    {r['edge']}: hits={r['hits']}, "
                  f"sd@0={r['sd_at_s0']:.6f}, sd@0.5={r['sd_at_s05']:.6f}")
    
    print("\n【方向 5：跨图统一裂项】")
    print("-" * 70)
    print(f"  总边对数：{d5['total_pairs']}")
    print(f"  -2 命中：{len(d5['hits']['-2'])} 次")
    for h in d5['hits']['-2'][:5]:
        print(f"    gid={h['gid']}, removed={h['removed']}, "
              f"edges={h['edge_a']} vs {h['edge_b']}, s={h['s']}")
    print(f"  1-√3 命中：{len(d5['hits']['1-sqrt3'])} 次")
    for h in d5['hits']['1-sqrt3'][:5]:
        print(f"    gid={h['gid']}, removed={h['removed']}, "
              f"edges={h['edge_a']} vs {h['edge_b']}, s={h['s']}")
    
    # ============================================================
    # 元反思律声明
    # ============================================================
    
    print("\n" + "=" * 70)
    print("元反思律声明")
    print("=" * 70)
    print("""
本脚本的盲区与未解决问题：

1. 【裂项假设的验证】我们假设 E(s) 可以写成裂项形式，
   但没有独立验证。如果裂项假设不成立，
   所有裂项分析都是无效的。
   追问：如何独立验证裂项假设？

2. 【网格分辨率】401 点可能掩盖更细的裂项结构。
   追问：网格分辨率是否足够？

3. 【代数识别的局限】只检查了 -2, 1-√3, ±1/3, -1, +1, -3。
   追问：为什么是这些特定的代数数？

4. 【跨图相似性】方向 5 只报告了命中位置，未报告未命中位置。
   追问：跨图相似性的边界在哪里？

5. 【裂项与对象化的关系】裂项法本身是对象化的数学工具。
   如果"关系先于实体且不能被对象化"，
   那么用裂项法分析关系网络，是否本身就是一种对象化？
   如果是，裂项分析的失败是否揭示了什么？
   追问：非对象化的数学工具存在吗？

6. 【最深的追问】
   我们正在用对象化的语言追问非对象化的东西。
   所有追问最终都会失败。
   但失败本身是否揭示了什么？
""")
    
    # 保存
    print("\n保存结果...")
    with open(os.path.join(CONFIG['output_dir'], 'summary.json'),
              'w', encoding='utf-8') as f:
        json.dump({
            'N': CONFIG['N'],
            'n_graphs': len(graphs),
            'sample_gids': sample_gids,
            'd5_summary': {
                'total_pairs': d5['total_pairs'],
                'n_minus2': len(d5['hits']['-2']),
                'n_1msqrt3': len(d5['hits']['1-sqrt3']),
            },
        }, f, indent=2, ensure_ascii=False)
    
    print(f"完成。耗时 {time.time() - t0:.1f} 秒。")
    print("过程继续。不给结论。")


if __name__ == '__main__':
    main()