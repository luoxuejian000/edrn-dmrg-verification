"""
追问为什么_等价边的全局角色.py

目标：
    追问等价边对的全局角色。
    对每对“割点边 vs 分支边”等价对，计算：
        1. 删除该边后图的度序列
        2. 删除该边后图的连通分量数
        3. 删除该边后图的直径
        4. 删除该边后图的自同构群大小
        5. 该边在原图中的轨道大小
        6. 该边端点在图中的顶点轨道大小
    检查：等价对在这些全局特征上是否匹配。
    并排展示标准物理（全局特征）与晶脉视角（等价性）。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。

输出：
    jingmai_why_equivalent_global_role.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
S_POINTS = 11
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10

def build_heisenberg(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def compute_corrs(N, edges, basis, probs):
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return np.array(corrs)

def get_sorted_curves(N, edges, s_values):
    n_edges = len(edges)
    curves = []
    for i in range(n_edges):
        curve = []
        for s in s_values:
            J = np.ones(n_edges); J[i] = s
            H, basis = build_heisenberg(N, edges, J)
            evals, evecs = np.linalg.eigh(H)
            E0 = evals[0]
            degen = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
            probs = np.zeros(len(basis))
            for idx in degen:
                probs += np.abs(evecs[:, idx])**2
            probs /= len(degen)
            corrs = compute_corrs(N, edges, basis, probs)
            curve.append(np.sort(corrs))
        curves.append(curve)
    return curves

def get_edge_orbits(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    autos = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in autos:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    return orbits

def get_vertex_orbits(G):
    import networkx.algorithms.isomorphism as iso
    GM = iso.GraphMatcher(G, G)
    autos = list(GM.isomorphisms_iter())
    remaining = set(G.nodes())
    orbits = []
    while remaining:
        v = remaining.pop()
        orbit = {v}
        for auto in autos:
            mapped = auto[v]
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append(orbit)
    return orbits

def edge_global_role(edges, N, edge_idx):
    """计算边的全局角色特征"""
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    u, v = edges[edge_idx]
    G_del = G.copy()
    G_del.remove_edge(u, v)
    # 删除后图特征
    del_deg_seq = tuple(sorted([d for _, d in G_del.degree()]))
    del_n_comp = nx.number_connected_components(G_del)
    del_diameter = nx.diameter(G_del) if nx.is_connected(G_del) else -1
    import networkx.algorithms.isomorphism as iso
    GM = iso.GraphMatcher(G_del, G_del)
    del_n_autos = len(list(GM.isomorphisms_iter()))
    # 轨道特征
    edge_orbits = get_edge_orbits(edges, N)
    edge_orbit_size = None
    for orbit in edge_orbits:
        if edge_idx in orbit:
            edge_orbit_size = len(orbit)
            break
    vertex_orbits = get_vertex_orbits(G)
    u_orbit_size = None
    v_orbit_size = None
    for orbit in vertex_orbits:
        if u in orbit:
            u_orbit_size = len(orbit)
        if v in orbit:
            v_orbit_size = len(orbit)
    return {
        'del_deg_seq': del_deg_seq,
        'del_n_comp': del_n_comp,
        'del_diameter': del_diameter,
        'del_n_autos': del_n_autos,
        'edge_orbit_size': edge_orbit_size,
        'u_orbit_size': u_orbit_size,
        'v_orbit_size': v_orbit_size,
        'deg_u': G.degree(u),
        'deg_v': G.degree(v)
    }

def main():
    print("=== 追问为什么_等价边的全局角色 ===\n")
    
    all_graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            all_graphs.append(edges)
    
    problem_with_cut = [9, 26, 31, 33, 49, 55, 60, 64, 69]
    s_values = np.linspace(-1.5, 0.0, S_POINTS)
    
    all_equivalences = []
    
    for g_idx in problem_with_cut:
        edges = all_graphs[g_idx]
        n_edges = len(edges)
        G = nx.Graph()
        G.add_nodes_from(range(N))
        G.add_edges_from(edges)
        cut_vertices = list(nx.articulation_points(G))
        curves = get_sorted_curves(N, edges, s_values)
        edge_orbits = get_edge_orbits(edges, N)
        
        # 每条边的轨道编号
        edge_to_orbit = {}
        for oi, orbit in enumerate(edge_orbits):
            for ei in orbit:
                edge_to_orbit[ei] = oi
        
        # 对每对边检查等价性
        for i in range(n_edges):
            for j in range(i+1, n_edges):
                if edge_to_orbit[i] == edge_to_orbit[j]:
                    continue
                same = all(np.allclose(c1, c2, atol=TOL_CURVE)
                          for c1, c2 in zip(curves[i], curves[j]))
                if not same:
                    continue
                # 找出这对边与割点的关系
                u_i, v_i = edges[i]
                u_j, v_j = edges[j]
                # 至少一边触碰割点
                touches_i = any(cv in (u_i, v_i) for cv in cut_vertices)
                touches_j = any(cv in (u_j, v_j) for cv in cut_vertices)
                if not (touches_i or touches_j):
                    continue
                
                role_i = edge_global_role(edges, N, i)
                role_j = edge_global_role(edges, N, j)
                
                # 比较全局角色
                del_deg_seq_same = role_i['del_deg_seq'] == role_j['del_deg_seq']
                del_n_comp_same = role_i['del_n_comp'] == role_j['del_n_comp']
                del_diameter_same = role_i['del_diameter'] == role_j['del_diameter']
                del_n_autos_same = role_i['del_n_autos'] == role_j['del_n_autos']
                
                print(f"\n图{g_idx}: 边{i}({edges[i]}) vs 边{j}({edges[j]})")
                print(f"  割点: {cut_vertices}, 边{i}触碰割点={touches_i}, 边{j}触碰割点={touches_j}")
                print(f"  全局角色_i: 度=({role_i['deg_u']},{role_i['deg_v']}), "
                      f"轨道大小={role_i['edge_orbit_size']}, "
                      f"删除后: 度序列={role_i['del_deg_seq']}, 分量={role_i['del_n_comp']}, "
                      f"直径={role_i['del_diameter']}, 自同构={role_i['del_n_autos']}")
                print(f"  全局角色_j: 度=({role_j['deg_u']},{role_j['deg_v']}), "
                      f"轨道大小={role_j['edge_orbit_size']}, "
                      f"删除后: 度序列={role_j['del_deg_seq']}, 分量={role_j['del_n_comp']}, "
                      f"直径={role_j['del_diameter']}, 自同构={role_j['del_n_autos']}")
                print(f"  匹配: 度序列={del_deg_seq_same}, 分量={del_n_comp_same}, "
                      f"直径={del_diameter_same}, 自同构={del_n_autos_same}")
                
                all_equivalences.append({
                    'graph': g_idx,
                    'edge_i': i,
                    'edge_j': j,
                    'edges_i': edges[i],
                    'edges_j': edges[j],
                    'cut_vertices': cut_vertices,
                    'touches_i': touches_i,
                    'touches_j': touches_j,
                    'role_i': role_i,
                    'role_j': role_j,
                    'del_deg_seq_same': del_deg_seq_same,
                    'del_n_comp_same': del_n_comp_same,
                    'del_diameter_same': del_diameter_same,
                    'del_n_autos_same': del_n_autos_same
                })
    
    # 统计
    print(f"\n===== 统计 =====")
    n_total = len(all_equivalences)
    print(f"等价对总数：{n_total}")
    if n_total > 0:
        n_deg_seq = sum(1 for e in all_equivalences if e['del_deg_seq_same'])
        n_n_comp = sum(1 for e in all_equivalences if e['del_n_comp_same'])
        n_diam = sum(1 for e in all_equivalences if e['del_diameter_same'])
        n_autos = sum(1 for e in all_equivalences if e['del_n_autos_same'])
        n_all = sum(1 for e in all_equivalences 
                   if e['del_deg_seq_same'] and e['del_n_comp_same'] 
                   and e['del_diameter_same'] and e['del_n_autos_same'])
        print(f"删除后度序列相同：{n_deg_seq}/{n_total}")
        print(f"删除后分量数相同：{n_n_comp}/{n_total}")
        print(f"删除后直径相同：{n_diam}/{n_total}")
        print(f"删除后自同构数相同：{n_autos}/{n_total}")
        print(f"所有删除特征都相同：{n_all}/{n_total}")
    
    output = {
        'all_equivalences': all_equivalences,
        'n_total': n_total,
        'note': '追问等价边的全局角色。'
    }
    with open('jingmai_why_equivalent_global_role.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_equivalent_global_role.json")

if __name__ == "__main__":
    main()