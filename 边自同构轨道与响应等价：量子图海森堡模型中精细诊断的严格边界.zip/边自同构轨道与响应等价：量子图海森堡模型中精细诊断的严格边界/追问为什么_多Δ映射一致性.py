"""
追问为什么_多Δ映射一致性.py

目标：
    检验多个Δ值下，映射后的关联分布是否一致。
    对每个反例图，取同轨道边对，在多个Δ点：
        1. 扫描ei和ej，得到基态波函数
        2. 应用自同构映射到ei波函数，在变换边集上计算E_mapped
        3. 计算E_j
        4. 比较E_mapped与E_j，同时输出能隙、基态简并性
    追踪差异是否只在特定Δ出现。

方法：
    只查同与不同，不拟合。
    不筛除任何数据。
    标准物理（能隙、简并）与晶脉视角（E_mapped vs E_j）并排。

输出：
    jingmai_why_multi_delta.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
DELTA_VALUES = [-1.5, -1.0, -0.75, -0.5, -0.25, -0.1, 0.0]

def build_hamiltonian_and_basis(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def compute_corr_from_wavefunction(N, edges, basis, psi):
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(np.abs(psi)**2 * diag_vals)
        corrs.append(corr)
    return np.array(corrs)

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def get_automorphisms(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    GM = iso.GraphMatcher(G, G)
    return list(GM.isomorphisms_iter())

def get_edge_orbits_from_edges(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    automorphisms = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in automorphisms:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return orbits, edge_to_orbit

def build_permutation_matrix(basis, mapping, N):
    new_basis_states = []
    for state in basis:
        new_state = 0
        for i in range(N):
            if (state >> i) & 1:
                new_state |= (1 << mapping[i])
        new_basis_states.append(new_state)
    P = np.zeros((len(basis), len(basis)), dtype=float)
    for old_idx, new_state in enumerate(new_basis_states):
        if new_state in basis:
            new_idx = basis.index(new_state)
            P[new_idx, old_idx] = 1.0
    return P

def main():
    print("=== 追问为什么_多Δ映射一致性 ===\n")
    
    all_graphs = get_all_N6_graphs()
    ce_graph_indices = [38, 80, 82, 89, 93, 110, 111]
    results = []
    
    for g_idx in ce_graph_indices:
        edges = all_graphs[g_idx]
        n_edges = len(edges)
        orbits, edge_to_orbit = get_edge_orbits_from_edges(edges, N)
        automorphisms = get_automorphisms(edges, N)
        
        print(f"\n===== 图 {g_idx}（{n_edges}边，{len(orbits)}轨道） =====")
        
        multi_orbits = [oi for oi, orbit in enumerate(orbits) if len(orbit) >= 2]
        if not multi_orbits:
            continue
        oi = multi_orbits[0]
        ei = orbits[oi][0]
        ej = orbits[oi][1]
        
        mapping = None
        for auto in automorphisms:
            mapped_edge = tuple(sorted((auto[edges[ei][0]], auto[edges[ei][1]])))
            if mapped_edge == edges[ej]:
                mapping = auto
                break
        if mapping is None:
            continue
        
        print(f"  轨道{oi}: 边{ei}->边{ej}")
        print(f"  {'Δ':<8} {'能隙':<12} {'E_mapped':<12} {'E_j':<12} {'差异':<12} {'一致':<6}")
        
        for s_val in DELTA_VALUES:
            J_i = np.ones(n_edges); J_i[ei] = s_val
            H_i, basis_i = build_hamiltonian_and_basis(N, edges, J_i)
            evals_i, evecs_i = np.linalg.eigh(H_i)
            psi_i = evecs_i[:, 0]
            
            J_j = np.ones(n_edges); J_j[ej] = s_val
            H_j, basis_j = build_hamiltonian_and_basis(N, edges, J_j)
            evals_j, evecs_j = np.linalg.eigh(H_j)
            psi_j = evecs_j[:, 0]
            
            P = build_permutation_matrix(basis_i, mapping, N)
            psi_i_mapped = P @ psi_i
            
            transformed_edges = []
            for (u, v) in edges:
                new_u, new_v = mapping[u], mapping[v]
                transformed_edges.append(tuple(sorted((new_u, new_v))))
            
            corrs_mapped = compute_corr_from_wavefunction(N, transformed_edges, basis_i, psi_i_mapped)
            E_mapped = float(np.std(corrs_mapped))
            corrs_j = compute_corr_from_wavefunction(N, edges, basis_j, psi_j)
            E_j = float(np.std(corrs_j))
            
            diff = abs(E_mapped - E_j)
            gap = float(evals_i[1] - evals_i[0])
            consistent = diff < 1e-10
            
            print(f"  {s_val:<8.2f} {gap:<12.8f} {E_mapped:<12.8f} {E_j:<12.8f} {diff:<12.6e} {'是' if consistent else '否':<6}")
            
            results.append({
                'graph': g_idx,
                'orbit': oi,
                'edge_i': ei,
                'edge_j': ej,
                's_val': s_val,
                'gap': gap,
                'E_mapped': E_mapped,
                'E_j': E_j,
                'diff': diff,
                'consistent': consistent
            })
    
    output = {
        'results': results,
        'DELTA_VALUES': DELTA_VALUES,
        'note': '多Δ映射一致性检验。'
    }
    with open('jingmai_why_multi_delta.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_multi_delta.json")

if __name__ == "__main__":
    main()