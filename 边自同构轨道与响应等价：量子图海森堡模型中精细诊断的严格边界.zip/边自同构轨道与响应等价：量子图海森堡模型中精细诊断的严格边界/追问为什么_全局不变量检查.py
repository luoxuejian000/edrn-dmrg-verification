"""
追问为什么_全局不变量检查.py

目标：
    继续追问：32对异轨道同分布边对共享什么？
    检查以下全局量：
        1. 度序列
        2. 邻接矩阵特征值（谱）
        3. 节点偏心率序列
    对每对边，比较这些全局量在两条边对应的图中是否相同。
    注：全局量与边无关，所以比较的是原图。
    但同分布边对可能有特定全局模式。

方法：
    只查同与不同，不拟合。
    不筛除数据。

输出：
    jingmai_why_global_invariants.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
TOL_CURVE = 1e-10

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def get_edge_orbits_from_edges(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    automorphisms = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in automorphisms:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return orbits, edge_to_orbit

def compute_graph_invariants(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    degree_seq = sorted([d for _, d in G.degree()])
    adjacency = nx.adjacency_matrix(G).toarray()
    eigenvalues = np.sort(np.linalg.eigvalsh(adjacency))
    eccentricities = sorted([nx.eccentricity(G, v) for v in range(N)])
    return {
        'degree_seq': degree_seq,
        'eigenvalues': eigenvalues.tolist(),
        'eccentricities': eccentricities
    }

def main():
    print("=== 追问为什么_全局不变量检查 ===\n")
    
    all_graphs = get_all_N6_graphs()
    
    # 已知的32对同分布边对
    # 从之前结果中读取，这里简化重新计算
    s_values = np.linspace(-1.5, 0.0, 21)
    targets = []
    
    # 为节省时间，使用简化重算
    # 先找出所有同分布边对
    for g_idx, edges in enumerate(all_graphs):
        n_edges = len(edges)
        orbits, edge_to_orbit = get_edge_orbits_from_edges(edges, N)
        # 跳过需要重新计算哈密顿量的部分，直接使用已知结果
        # 这里从之前保存的JSON读取
    with open('jingmai_why_distribution_diversity.json', 'r', encoding='utf-8') as f:
        diversity_data = json.load(f)
    
    targets = diversity_data['results']
    
    # 对每个目标，计算图的全局不变量
    results = []
    for t in targets:
        g_idx = t['graph']
        edges = all_graphs[g_idx]
        invariants = compute_graph_invariants(edges, N)
        results.append({
            'graph': g_idx,
            'edge_i': t['edge_i'],
            'edge_j': t['edge_j'],
            'invariants': invariants
        })
    
    # 由于全局不变量与边无关，同一个图内所有边相同，
    # 这里我们只需显示每个反例图的不变量
    seen_graphs = {}
    for r in results:
        g = r['graph']
        if g not in seen_graphs:
            seen_graphs[g] = r['invariants']
    
    print("反例图全局不变量：")
    for g, inv in sorted(seen_graphs.items()):
        print(f"\n图{g}:")
        print(f"  度序列: {inv['degree_seq']}")
        print(f"  邻接矩阵谱: {np.round(inv['eigenvalues'], 4)}")
        print(f"  偏心率序列: {inv['eccentricities']}")
    
    # 这些不变量不能直接解释同分布，但提供了全局特征
    output = {
        'seen_graphs': seen_graphs,
        'note': '全局不变量检查。'
    }
    with open('jingmai_why_global_invariants.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_global_invariants.json")

if __name__ == "__main__":
    main()