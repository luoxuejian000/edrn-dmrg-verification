"""
追问为什么_sim01不一致定位.py

目标：
    继续追问：sim01在同轨道边对中不一致，发生在哪里？
    对反例集中的图，取同轨道边对，在多个Δ点：
        1. 计算能隙、基态简并度、第一激发态简并度
        2. 计算基态与第一激发态关联分布相似度 sim01
        3. 比较两边 sim01 的差异
    定位 sim01 不一致的Δ位置和简并情况。
    并排呈现标准物理（能隙、简并度）与晶脉视角（sim01值）。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。
    基态简并使用对称性约化密度矩阵；激发态处理需记录。

理论精髓：
    - 数据自己说话。
    - 追问：sim01的不一致是否与简并或激发态选择有关？

输出：
    jingmai_why_sim01_inconsistency.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10
DELTA_VALUES = [-1.5, -1.0, -0.5, -0.25, 0.0]

def build_hamiltonian_and_basis(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def compute_probs_with_degen(N, edges, J_vals):
    H, basis = build_hamiltonian_and_basis(N, edges, J_vals)
    evals, evecs = np.linalg.eigh(H)
    E0 = evals[0]
    degen_indices = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
    degen_dim = len(degen_indices)
    probs = np.zeros(len(basis))
    for idx in degen_indices:
        probs += np.abs(evecs[:, idx])**2
    probs /= degen_dim
    return probs, basis, evals, evecs, degen_indices

def compute_corrs_from_probs(N, edges, basis, probs):
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return np.array(corrs)

def distribution_similarity(dist1, dist2):
    return float(np.linalg.norm(np.sort(dist1) - np.sort(dist2)))

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def get_edge_orbits_from_edges(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    automorphisms = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in automorphisms:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return orbits, edge_to_orbit

def compute_sim01_at(N, edges, J_vals):
    """返回 sim01 以及激发态信息"""
    probs, basis, evals, evecs, degen_indices = compute_probs_with_degen(N, edges, J_vals)
    corrs_gs = compute_corrs_from_probs(N, edges, basis, probs)
    E0 = evals[0]
    excited_indices = [k for k in range(len(evals)) if evals[k] > E0 + TOL_DEGEN]
    if excited_indices:
        idx_ex = excited_indices[0]
        psi_ex = evecs[:, idx_ex]
    else:
        idx_ex = degen_indices[0]  # fallback
        psi_ex = evecs[:, idx_ex]
    probs_ex = np.abs(psi_ex)**2
    corrs_ex = compute_corrs_from_probs(N, edges, basis, probs_ex)
    sim01 = distribution_similarity(corrs_gs, corrs_ex)
    # 激发态简并度
    E_ex = evals[idx_ex]
    ex_degen = sum(1 for ev in evals if abs(ev - E_ex) < TOL_DEGEN)
    gap = float(evals[1] - evals[0])
    return sim01, gap, len(degen_indices), ex_degen, idx_ex

def main():
    print("=== 追问为什么_sim01不一致定位 ===\n")
    
    all_graphs = get_all_N6_graphs()
    
    # 已知有同轨道异sim01的图（从前面结果）
    target_graphs = [0, 6, 10, 19, 20, 24, 38]
    results = []
    
    for g_idx in target_graphs:
        edges = all_graphs[g_idx]
        n_edges = len(edges)
        orbits, edge_to_orbit = get_edge_orbits_from_edges(edges, N)
        
        # 找一个多边轨道
        multi_orbits = [oi for oi, orbit in enumerate(orbits) if len(orbit) >= 2]
        if not multi_orbits:
            continue
        oi = multi_orbits[0]
        ei = orbits[oi][0]
        ej = orbits[oi][1]
        
        print(f"\n===== 图{g_idx} 边{ei}->边{ej}（轨道{oi}） =====")
        print(f"  {'Δ':<8} {'能隙':<12} {'基态简并':<10} {'激发态简并':<10} {'sim01_i':<12} {'sim01_j':<12} {'差异':<12}")
        
        for s_val in DELTA_VALUES:
            J_i = np.ones(n_edges); J_i[ei] = s_val
            J_j = np.ones(n_edges); J_j[ej] = s_val
            sim_i, gap_i, gs_deg_i, ex_deg_i, idx_ex_i = compute_sim01_at(N, edges, J_i)
            sim_j, gap_j, gs_deg_j, ex_deg_j, idx_ex_j = compute_sim01_at(N, edges, J_j)
            diff = abs(sim_i - sim_j)
            
            print(f"  {s_val:<8.2f} {gap_i:<12.8f} {gs_deg_i:<10} {ex_deg_i:<10} "
                  f"{sim_i:<12.8f} {sim_j:<12.8f} {diff:<12.8f}")
            
            results.append({
                'graph': g_idx,
                'orbit': oi,
                'edge_i': ei,
                'edge_j': ej,
                's_val': s_val,
                'gap': gap_i,
                'gs_degeneracy': gs_deg_i,
                'ex_degeneracy': ex_deg_i,
                'sim01_i': sim_i,
                'sim01_j': sim_j,
                'diff': diff
            })
    
    output = {
        'results': results,
        'note': '追问：sim01不一致是否与简并或激发态选择有关？'
    }
    with open('jingmai_why_sim01_inconsistency.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_sim01_inconsistency.json")

if __name__ == "__main__":
    main()