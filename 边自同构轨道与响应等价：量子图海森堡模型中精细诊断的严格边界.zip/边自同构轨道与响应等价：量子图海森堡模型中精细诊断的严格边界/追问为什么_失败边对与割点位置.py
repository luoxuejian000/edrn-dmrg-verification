"""
追问为什么_失败边对与割点位置.py

目标：
    追问有割点的问题图中，失败的边对与割点的位置关系。
    对有割点的问题图：
        1. 找出失败的边对（轨道失败或模型依赖的边对）
        2. 对每个失败边对，检查：
            - 两条边是否在割点分隔的不同连通分支中
            - 两条边到割点的距离
            - 删除割点后，两条边是否落在不同分量
    统计：
        - 失败边对被割点分隔的比例
        - 正常图中的边对是否也有类似结构

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。

输出：
    jingmai_why_fail_edges_cut_position.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
S_POINTS = 11
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10

def build_basis(N):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    return basis, state_to_idx

def add_heisenberg_term(H, basis, state_to_idx, edges, J_vals):
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J

def build_heisenberg(N, edges, J_vals):
    basis, state_to_idx = build_basis(N)
    H = np.zeros((len(basis), len(basis)), dtype=float)
    add_heisenberg_term(H, basis, state_to_idx, edges, J_vals)
    return H, basis

def compute_probs(N, edges, J_vals):
    H, basis = build_heisenberg(N, edges, J_vals)
    evals, evecs = np.linalg.eigh(H)
    E0 = evals[0]
    degen = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
    probs = np.zeros(len(basis))
    for idx in degen:
        probs += np.abs(evecs[:, idx])**2
    probs /= len(degen)
    return probs, basis

def compute_corrs(N, edges, basis, probs):
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return np.array(corrs)

def get_sorted_curves(N, edges, s_values):
    n_edges = len(edges)
    curves = []
    for i in range(n_edges):
        curve = []
        for s in s_values:
            J = np.ones(n_edges)
            J[i] = s
            probs, basis = compute_probs(N, edges, J)
            corrs = compute_corrs(N, edges, basis, probs)
            curve.append(np.sort(corrs))
        curves.append(curve)
    return curves

def get_edge_orbits(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    autos = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in autos:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return edge_to_orbit

def find_fail_edges(edges, N, s_values):
    """找出所有异轨道同分布的边对"""
    n_edges = len(edges)
    edge_to_orbit = get_edge_orbits(edges, N)
    curves = get_sorted_curves(N, edges, s_values)
    fail_pairs = []
    for i in range(n_edges):
        for j in range(i+1, n_edges):
            if edge_to_orbit[i] != edge_to_orbit[j]:
                same = all(np.allclose(c1, c2, atol=TOL_CURVE)
                          for c1, c2 in zip(curves[i], curves[j]))
                if same:
                    fail_pairs.append((i, j))
    return fail_pairs

def edge_branch_after_removing_cut(edges, N, cut_vertex, edge):
    """删除割点后，边两端点落在哪个连通分支"""
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    G_removed = G.copy()
    G_removed.remove_node(cut_vertex)
    components = list(nx.connected_components(G_removed))
    u, v = edge
    if u == cut_vertex or v == cut_vertex:
        return ('touches_cut', None)
    for ci, comp in enumerate(components):
        if u in comp and v in comp:
            return ('inside', ci)
    # 边跨两个分支
    comp_u = None
    comp_v = None
    for ci, comp in enumerate(components):
        if u in comp:
            comp_u = ci
        if v in comp:
            comp_v = ci
    if comp_u is not None and comp_v is not None and comp_u != comp_v:
        return ('crosses', (comp_u, comp_v))
    return ('unknown', None)

def main():
    print("=== 追问为什么_失败边对与割点位置 ===\n")
    
    all_graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            all_graphs.append(edges)
    
    # 有问题图的索引
    problem_graphs = [9, 14, 26, 31, 33, 49, 55, 60, 64, 69, 86, 98, 106, 108]
    # 有割点的问题图
    problem_with_cut = [9, 14, 26, 31, 33, 49, 55, 60, 64, 69]
    # 无割点的问题图
    problem_no_cut = [86, 98, 106, 108]
    
    s_values = np.linspace(-1.5, 0.0, S_POINTS)
    
    print("===== 有割点的问题图：失败边对与割点位置 =====")
    
    all_results = []
    
    for g_idx in problem_with_cut:
        edges = all_graphs[g_idx]
        G = nx.Graph()
        G.add_nodes_from(range(N))
        G.add_edges_from(edges)
        cut_vertices = list(nx.articulation_points(G))
        
        print(f"\n图{g_idx}: 割点={cut_vertices}")
        
        fail_pairs = find_fail_edges(edges, N, s_values)
        print(f"  失败边对: {fail_pairs}")
        
        for ei, ej in fail_pairs:
            edge_i = edges[ei]
            edge_j = edges[ej]
            for cv in cut_vertices:
                branch_i = edge_branch_after_removing_cut(edges, N, cv, edge_i)
                branch_j = edge_branch_after_removing_cut(edges, N, cv, edge_j)
                crosses = (branch_i[0] == 'crosses' or branch_j[0] == 'crosses'
                           or (branch_i[0] == 'inside' and branch_j[0] == 'inside'
                               and branch_i[1] != branch_j[1]))
                print(f"    边{ei}({edge_i}) vs 边{ej}({edge_j}), 割点{cv}: "
                      f"分支_i={branch_i}, 分支_j={branch_j}, "
                      f"跨分支={branch_i[1] != branch_j[1] if branch_i[1] and branch_j[1] else 'N/A'}")
                all_results.append({
                    'graph': g_idx,
                    'cut_vertex': cv,
                    'edge_i': ei,
                    'edge_j': ej,
                    'edge_i_nodes': edge_i,
                    'edge_j_nodes': edge_j,
                    'branch_i': branch_i,
                    'branch_j': branch_j,
                    'crosses': crosses
                })
    
    # 统计
    n_crosses = sum(1 for r in all_results if r['crosses'])
    print(f"\n===== 统计 =====")
    print(f"失败边对总数：{len(all_results)}")
    print(f"被割点分隔（跨不同分支）：{n_crosses}/{len(all_results)}")
    
    # 对正常图中有割点的图做同样的检查
    print("\n===== 正常图中有割点的图：边对与割点位置 =====")
    normal_with_cut = []
    for g_idx in range(len(all_graphs)):
        if g_idx in problem_graphs:
            continue
        edges = all_graphs[g_idx]
        G = nx.Graph()
        G.add_nodes_from(range(N))
        G.add_edges_from(edges)
        cut_vertices = list(nx.articulation_points(G))
        if cut_vertices:
            normal_with_cut.append((g_idx, cut_vertices))
    
    print(f"正常图中有割点的图数：{len(normal_with_cut)}")
    
    # 对每个正常图，随机取几对边，看它们是否也被割点分隔
    n_normal_pairs_total = 0
    n_normal_pairs_crosses = 0
    for g_idx, cut_vertices in normal_with_cut[:10]:
        edges = all_graphs[g_idx]
        n_edges = len(edges)
        for ei in range(n_edges):
            for ej in range(ei+1, n_edges):
                for cv in cut_vertices:
                    branch_i = edge_branch_after_removing_cut(edges, N, cv, edges[ei])
                    branch_j = edge_branch_after_removing_cut(edges, N, cv, edges[ej])
                    if branch_i[0] == 'crosses' or branch_j[0] == 'crosses':
                        n_normal_pairs_crosses += 1
                        break
                    if branch_i[0] == 'inside' and branch_j[0] == 'inside' and branch_i[1] != branch_j[1]:
                        n_normal_pairs_crosses += 1
                        break
                n_normal_pairs_total += 1
    
    print(f"正常图中有割点的图：边对被割点分隔的比例：{n_normal_pairs_crosses}/{n_normal_pairs_total}")
    
    output = {
        'problem_with_cut_results': all_results,
        'n_fail_pairs': len(all_results),
        'n_crosses': n_crosses,
        'note': '追问失败边对与割点的位置关系。'
    }
    with open('jingmai_why_fail_edges_cut_position.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_fail_edges_cut_position.json")

if __name__ == "__main__":
    main()