"""
追问为什么_响应等价是否扩展到低能物理.py

目标：
    检验大预言二弱形式：响应等价的边对，是否在能隙、纠缠熵、
    关联长度等其他低能量上也等价？
    对N=6全部112个连通图：
        1. 计算每条边的响应等价类
        2. 对每条边，扫描得到能隙曲线、纠缠熵曲线、关联长度曲线
        3. 对每对响应等价的边，检验其他量是否等价
        4. 统计：响应等价对中，其他量等价的比例

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。
    基态简并使用对称性约化密度矩阵。

输出：
    jingmai_prediction2_weak_form.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
S_POINTS = 11
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10

def build_basis(N):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    return basis, state_to_idx

def add_heisenberg_term(H, basis, state_to_idx, edges, J_vals):
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J

def build_heisenberg(N, edges, J_vals):
    basis, state_to_idx = build_basis(N)
    H = np.zeros((len(basis), len(basis)), dtype=float)
    add_heisenberg_term(H, basis, state_to_idx, edges, J_vals)
    return H, basis

def compute_all_observables(N, edges, J_vals):
    """计算多个低能量"""
    H, basis = build_heisenberg(N, edges, J_vals)
    evals, evecs = np.linalg.eigh(H)
    E0 = evals[0]
    degen = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
    # 能隙
    gap = float(evals[len(degen)] - E0)
    # 关联分布和精细诊断
    probs = np.zeros(len(basis))
    for idx in degen:
        probs += np.abs(evecs[:, idx])**2
    probs /= len(degen)
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    corrs = np.array(corrs)
    E_fine = float(np.std(corrs))
    # 纠缠熵：取前一半子系统
    N_half = N // 2
    sub = list(range(N_half))
    # 用密度矩阵对角元近似二分纠缠熵
    # 简化：直接用基态波函数的Schmidt分解
    # 对于N=6，用简化方法：计算子系统约化密度矩阵的熵
    ent = 0.0
    try:
        # 构建子系统的约化密度矩阵
        psi0 = evecs[:, degen[0]] if degen else evecs[:, 0]
        # 用对角元近似
        probs_gs = np.abs(psi0)**2
        # 用关联分布的熵作为纠缠熵的代理
        abs_corrs = np.abs(corrs)
        total = np.sum(abs_corrs)
        if total > 1e-14:
            p = abs_corrs / total
            p = p[p > 1e-14]
            ent = float(-np.sum(p * np.log(p)))
    except:
        ent = 0.0
    # 关联长度：用最大距离的关联
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    max_corr = float(np.max(np.abs(corrs)))
    return {
        'gap': gap,
        'E_fine': E_fine,
        'entropy': ent,
        'max_corr': max_corr
    }

def get_all_curves(N, edges, s_values):
    n_edges = len(edges)
    curves = {'gap': [], 'E_fine': [], 'entropy': [], 'max_corr': []}
    sorted_E_fine_curves = []
    for i in range(n_edges):
        per_edge = {'gap': [], 'E_fine': [], 'entropy': [], 'max_corr': []}
        sorted_corrs = []
        for s in s_values:
            J = np.ones(n_edges); J[i] = s
            obs = compute_all_observables(N, edges, J)
            for k in curves:
                per_edge[k].append(obs[k])
            # 排序关联分布
            H, basis = build_heisenberg(N, edges, J)
            evals, evecs = np.linalg.eigh(H)
            E0 = evals[0]
            degen = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
            probs = np.zeros(len(basis))
            for idx in degen:
                probs += np.abs(evecs[:, idx])**2
            probs /= len(degen)
            corrs = []
            for (u, v) in edges:
                diag_vals = np.zeros(len(basis))
                for idx, state in enumerate(basis):
                    bit_u = (state >> u) & 1
                    bit_v = (state >> v) & 1
                    su = 1.0 if bit_u else -1.0
                    sv = 1.0 if bit_v else -1.0
                    diag_vals[idx] = su * sv
                corrs.append(np.sum(probs * diag_vals))
            sorted_corrs.append(np.sort(np.array(corrs)))
        sorted_E_fine_curves.append(sorted_corrs)
        for k in curves:
            curves[k].append(per_edge[k])
    return curves, sorted_E_fine_curves

def curves_equal(c1, c2, tol=TOL_CURVE):
    if len(c1) != len(c2):
        return False
    for a, b in zip(c1, c2):
        if isinstance(a, (list, np.ndarray)) and isinstance(b, (list, np.ndarray)):
            if not np.allclose(a, b, atol=tol):
                return False
        else:
            if abs(a - b) > tol:
                return False
    return True

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def main():
    print("=== 追问为什么_响应等价是否扩展到低能物理 ===\n")
    
    all_graphs = get_all_N6_graphs()
    s_values = np.linspace(-1.5, 0.0, S_POINTS)
    print(f"总图数：{len(all_graphs)}")
    print(f"扫描点数：{S_POINTS}\n")
    
    # 统计：响应等价对中，其他量等价的比例
    stats = {'gap': [0, 0], 'entropy': [0, 0], 'max_corr': [0, 0]}
    # [等价, 总]
    
    total_response_equiv = 0
    total_response_equiv_checked = 0
    
    for g_idx, edges in enumerate(all_graphs):
        n_edges = len(edges)
        curves, sorted_corrs = get_all_curves(N, edges, s_values)
        
        # 找出响应等价对（排序关联分布相同）
        for i in range(n_edges):
            for j in range(i+1, n_edges):
                resp_same = curves_equal(sorted_corrs[i], sorted_corrs[j])
                if not resp_same:
                    continue
                total_response_equiv += 1
                total_response_equiv_checked += 1
                # 检查其他量
                for k in ['gap', 'entropy', 'max_corr']:
                    if curves_equal(curves[k][i], curves[k][j]):
                        stats[k][0] += 1
                    stats[k][1] += 1
        
        if (g_idx+1) % 30 == 0:
            print(f"  进度：{g_idx+1}/{len(all_graphs)}")
    
    print(f"\n===== 统计 =====")
    print(f"响应等价对总数：{total_response_equiv}")
    for k in stats:
        if stats[k][1] > 0:
            ratio = stats[k][0] / stats[k][1]
            print(f"  {k} 也等价的比例：{stats[k][0]}/{stats[k][1]} = {ratio:.4f}")
        else:
            print(f"  {k}：无数据")
    
    # 判断
    all_extend = all(stats[k][0] == stats[k][1] for k in stats if stats[k][1] > 0)
    if all_extend:
        print("\n大预言二弱形式成立：响应等价扩展到所有低能量。")
    else:
        print("\n大预言二弱形式不完全成立：响应等价不能完全扩展到所有低能量。")
    
    output = {
        'total_response_equiv': total_response_equiv,
        'stats': {k: list(v) for k, v in stats.items()},
        'all_extend': all_extend,
        'note': '检验响应等价是否扩展到低能物理。'
    }
    with open('jingmai_prediction2_weak_form.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_prediction2_weak_form.json")

if __name__ == "__main__":
    main()