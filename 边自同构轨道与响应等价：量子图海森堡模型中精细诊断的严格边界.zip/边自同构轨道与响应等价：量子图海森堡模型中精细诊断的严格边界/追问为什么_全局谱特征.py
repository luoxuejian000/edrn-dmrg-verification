"""
追问为什么_全局谱特征.py

目标：
    局部特征无法解释异轨道同分布，转向全局谱特征。
    对每条边，计算删除该边后图的：
        1. 拉普拉斯谱（排序后的全部特征值）
        2. 邻接谱（排序后的全部特征值）
        3. 拉普拉斯谱隙（第二小特征值）
        4. 邻接谱半径
        5. 图谱熵
    构建谱等价类，与排序分布等价类比较，
    看是否存在某个谱特征能精确刻画排序分布等价类。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。
    基态简并使用对称性约化密度矩阵。
    谱比较使用容差1e-8。

输出：
    jingmai_why_spectral_features.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
S_POINTS = 11
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10
TOL_SPECTRAL = 1e-8

SPECTRAL_NAMES = ['laplacian_spec', 'adjacency_spec', 'laplacian_gap', 'adj_radius', 'spectral_entropy']

def build_hamiltonian_and_basis(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def compute_probs_with_degen(N, edges, J_vals):
    H, basis = build_hamiltonian_and_basis(N, edges, J_vals)
    evals, evecs = np.linalg.eigh(H)
    E0 = evals[0]
    degen_indices = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
    degen_dim = len(degen_indices)
    probs = np.zeros(len(basis))
    for idx in degen_indices:
        probs += np.abs(evecs[:, idx])**2
    probs /= degen_dim
    return probs, basis

def compute_corrs_from_probs(N, edges, basis, probs):
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return np.array(corrs)

def get_sorted_correlation_curve(N, edges, defect_idx, s_values):
    n_edges = len(edges)
    curve = []
    for s in s_values:
        J = np.ones(n_edges)
        J[defect_idx] = s
        probs, basis = compute_probs_with_degen(N, edges, J)
        corrs = compute_corrs_from_probs(N, edges, basis, probs)
        curve.append(np.sort(corrs))
    return curve

def curves_equal(curve1, curve2, tol=TOL_CURVE):
    if len(curve1) != len(curve2):
        return False
    for c1, c2 in zip(curve1, curve2):
        if not np.allclose(c1, c2, atol=tol):
            return False
    return True

def build_equiv_matrix_from_curves(sorted_curves, n_edges):
    equiv = np.zeros((n_edges, n_edges), dtype=bool)
    for i in range(n_edges):
        for j in range(i+1, n_edges):
            same = curves_equal(sorted_curves[i], sorted_curves[j])
            equiv[i, j] = equiv[j, i] = same
    for i in range(n_edges):
        equiv[i, i] = True
    return equiv

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def spectral_features(edges, N, edge_idx):
    """计算删除边后图的谱特征"""
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    G_del = G.copy()
    G_del.remove_edge(*edges[edge_idx])
    # 拉普拉斯谱
    L = nx.laplacian_matrix(G_del).toarray()
    lap_evals = np.sort(np.linalg.eigvalsh(L))
    # 邻接谱
    A = nx.adjacency_matrix(G_del).toarray()
    adj_evals = np.sort(np.linalg.eigvalsh(A))
    # 拉普拉斯谱隙
    lap_gap = lap_evals[1] if len(lap_evals) > 1 else 0.0
    # 邻接谱半径
    adj_radius = np.max(np.abs(adj_evals))
    # 谱熵：基于拉普拉斯特征值的归一化分布
    abs_lap = np.abs(lap_evals)
    total = np.sum(abs_lap)
    if total < 1e-14:
        spec_ent = 0.0
    else:
        probs = abs_lap / total
        probs = probs[probs > 1e-14]
        spec_ent = float(-np.sum(probs * np.log(probs)))
    return {
        'laplacian_spec': lap_evals,
        'adjacency_spec': adj_evals,
        'laplacian_gap': lap_gap,
        'adj_radius': adj_radius,
        'spectral_entropy': spec_ent
    }

def build_spectral_equiv_matrix(edges, N, feature_name):
    n_edges = len(edges)
    values = []
    for i in range(n_edges):
        feats = spectral_features(edges, N, i)
        values.append(feats[feature_name])
    equiv = np.zeros((n_edges, n_edges), dtype=bool)
    for i in range(n_edges):
        for j in range(i+1, n_edges):
            v_i = values[i]
            v_j = values[j]
            if isinstance(v_i, np.ndarray) or isinstance(v_j, np.ndarray):
                same = np.allclose(np.array(v_i), np.array(v_j), atol=TOL_SPECTRAL)
            else:
                same = abs(float(v_i) - float(v_j)) < TOL_SPECTRAL
            equiv[i, j] = equiv[j, i] = same
    for i in range(n_edges):
        equiv[i, i] = True
    return equiv

def main():
    print("=== 追问为什么_全局谱特征 ===\n")
    
    all_graphs = get_all_N6_graphs()
    s_values = np.linspace(-1.5, 0.0, S_POINTS)
    print(f"总图数：{len(all_graphs)}")
    print(f"候选谱特征：{SPECTRAL_NAMES}\n")
    
    inconsistency_counts = {name: {'n_graphs': 0, 'n_edges': 0} for name in SPECTRAL_NAMES}
    inconsistent_details = {name: [] for name in SPECTRAL_NAMES}
    
    for g_idx, edges in enumerate(all_graphs):
        n_edges = len(edges)
        # 排序分布等价矩阵
        sorted_curves = []
        for i in range(n_edges):
            curve = get_sorted_correlation_curve(N, edges, i, s_values)
            sorted_curves.append(curve)
        sorted_equiv = build_equiv_matrix_from_curves(sorted_curves, n_edges)
        
        # 对每个谱特征，比较等价矩阵
        for name in SPECTRAL_NAMES:
            spec_equiv = build_spectral_equiv_matrix(edges, N, name)
            if np.array_equal(sorted_equiv, spec_equiv):
                continue
            inconsistency_counts[name]['n_graphs'] += 1
            diff_pairs = []
            for i in range(n_edges):
                for j in range(i+1, n_edges):
                    if sorted_equiv[i, j] != spec_equiv[i, j]:
                        typ = 'sorted_same_spec_diff' if sorted_equiv[i, j] else 'sorted_diff_spec_same'
                        diff_pairs.append((i, j, typ))
                        inconsistency_counts[name]['n_edges'] += 1
            inconsistent_details[name].append({
                'graph': g_idx,
                'diff_pairs': diff_pairs
            })
        
        if (g_idx+1) % 30 == 0:
            print(f"  进度：{g_idx+1}/{len(all_graphs)}")
    
    # 输出结果
    print("\n===== 各谱特征与排序分布等价类的一致性 =====")
    print(f"{'谱特征':<20} {'不一致图数':<10} {'不一致边对数':<12}")
    print("-" * 45)
    for name in SPECTRAL_NAMES:
        print(f"{name:<20} {inconsistency_counts[name]['n_graphs']:<10} "
              f"{inconsistency_counts[name]['n_edges']:<12}")
    
    perfect = [name for name in SPECTRAL_NAMES if inconsistency_counts[name]['n_graphs'] == 0]
    if perfect:
        print(f"\n完全一致的谱特征：{perfect}")
    else:
        print("\n不存在单一谱特征与排序分布等价类完全一致。")
    
    best = min(SPECTRAL_NAMES, key=lambda x: inconsistency_counts[x]['n_graphs'])
    print(f"\n最接近的谱特征：{best}")
    print(f"  不一致图数：{inconsistency_counts[best]['n_graphs']}")
    
    output = {
        'inconsistency_counts': inconsistency_counts,
        'inconsistent_details': inconsistent_details,
        'perfect': perfect,
        'best': best,
        'note': '检验全局谱特征能否刻画排序分布等价类。'
    }
    with open('jingmai_why_spectral_features.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_spectral_features.json")

if __name__ == "__main__":
    main()