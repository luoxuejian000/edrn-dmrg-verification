"""
追问为什么_割点分支结构与失败.py

目标：
    追问割点如何通过改变自同构群结构导致轨道失败。
    对有割点的问题图：
        1. 删除割点，得到若干分支
        2. 计算每个分支的自同构群大小
        3. 计算失败边对所在分支的特征
        4. 对比正常图中有割点的分支结构
    统计：
        - 失败边对是否在某个分支内部具有相似位置
        - 割点两侧分支是否结构不对称

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。

输出：
    jingmai_why_cut_branch_structure.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
S_POINTS = 11
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def get_edge_orbits(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    autos = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in autos:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return edge_to_orbit, len(autos)

def find_fail_edges(edges, N, s_values):
    n_edges = len(edges)
    edge_to_orbit, _ = get_edge_orbits(edges, N)
    curves = []
    for i in range(n_edges):
        curve = []
        for s in s_values:
            J = np.ones(n_edges); J[i] = s
            H, basis = build_heisenberg(N, edges, J)
            evals, evecs = np.linalg.eigh(H)
            E0 = evals[0]
            degen = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
            probs = np.zeros(len(basis))
            for idx in degen:
                probs += np.abs(evecs[:, idx])**2
            probs /= len(degen)
            corrs = []
            for (u, v) in edges:
                diag_vals = np.zeros(len(basis))
                for idx, state in enumerate(basis):
                    bit_u = (state >> u) & 1
                    bit_v = (state >> v) & 1
                    su = 1.0 if bit_u else -1.0
                    sv = 1.0 if bit_v else -1.0
                    diag_vals[idx] = su * sv
                corrs.append(np.sum(probs * diag_vals))
            curve.append(np.sort(np.array(corrs)))
        curves.append(curve)
    fail_pairs = []
    for i in range(n_edges):
        for j in range(i+1, n_edges):
            if edge_to_orbit[i] != edge_to_orbit[j]:
                same = all(np.allclose(c1, c2, atol=TOL_CURVE) for c1, c2 in zip(curves[i], curves[j]))
                if same:
                    fail_pairs.append((i, j))
    return fail_pairs

def build_heisenberg(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def main():
    print("=== 追问为什么_割点分支结构与失败 ===\n")
    
    all_graphs = get_all_N6_graphs()
    s_values = np.linspace(-1.5, 0.0, S_POINTS)
    
    problem_with_cut = [9, 26, 31, 33, 49, 55, 60, 64, 69]
    
    print("===== 有割点的问题图：分支结构与失败边对 =====")
    
    results = []
    
    for g_idx in problem_with_cut:
        edges = all_graphs[g_idx]
        G = nx.Graph()
        G.add_nodes_from(range(N))
        G.add_edges_from(edges)
        cut_vertices = list(nx.articulation_points(G))
        
        print(f"\n图{g_idx}: 割点={cut_vertices}")
        
        edge_to_orbit, n_autos = get_edge_orbits(edges, N)
        print(f"  自同构数={n_autos}")
        
        fail_pairs = find_fail_edges(edges, N, s_values)
        
        for cv in cut_vertices:
            G_removed = G.copy()
            G_removed.remove_node(cv)
            components = list(nx.connected_components(G_removed))
            print(f"  割点{cv}删除后分支：{components}")
            
            # 每个分支的边
            for ci, comp in enumerate(components):
                branch_edges = []
                for ei, (u, v) in enumerate(edges):
                    if u in comp and v in comp:
                        branch_edges.append(ei)
                # 分支内的自同构
                subG = G.subgraph(comp)
                import networkx.algorithms.isomorphism as iso
                GM = iso.GraphMatcher(subG, subG)
                n_sub_autos = len(list(GM.isomorphisms_iter()))
                print(f"    分支{ci}: 节点={sorted(comp)}, 边={branch_edges}, "
                      f"子图自同构数={n_sub_autos}")
            
            # 失败边对在哪些分支
            for ei, ej in fail_pairs:
                u_i, v_i = edges[ei]
                u_j, v_j = edges[ej]
                
                def locate(u, v, comps, cv):
                    if u == cv or v == cv:
                        return 'touches_cut'
                    for ci, comp in enumerate(comps):
                        if u in comp and v in comp:
                            return f'branch_{ci}'
                    return 'crosses_branches'
                
                loc_i = locate(u_i, v_i, components, cv)
                loc_j = locate(u_j, v_j, components, cv)
                
                print(f"    失败对({ei},{ej}): {edges[ei]}在{loc_i}, {edges[ej]}在{loc_j}")
                
                results.append({
                    'graph': g_idx,
                    'cut_vertex': cv,
                    'edge_i': ei,
                    'edge_j': ej,
                    'loc_i': loc_i,
                    'loc_j': loc_j,
                    'n_autos': n_autos,
                    'n_components': len(components)
                })
    
    # 统计
    print(f"\n===== 统计 =====")
    n_touches_cut = sum(1 for r in results if 'touches_cut' in [r['loc_i'], r['loc_j']])
    n_same_branch = sum(1 for r in results 
                        if r['loc_i'] == r['loc_j'] and 'branch' in r['loc_i'])
    n_diff_branch = sum(1 for r in results 
                        if r['loc_i'] != r['loc_j'] and 'branch' in r['loc_i'] and 'branch' in r['loc_j'])
    
    print(f"失败边对总数：{len(results)}")
    print(f"至少一边触碰割点：{n_touches_cut}")
    print(f"两边在同一分支：{n_same_branch}")
    print(f"两边在不同分支：{n_diff_branch}")
    
    output = {
        'results': results,
        'n_total': len(results),
        'n_touches_cut': n_touches_cut,
        'n_same_branch': n_same_branch,
        'n_diff_branch': n_diff_branch,
        'note': '追问割点分支结构与失败边对的关系。'
    }
    with open('jingmai_why_cut_branch_structure.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_cut_branch_structure.json")

if __name__ == "__main__":
    main()