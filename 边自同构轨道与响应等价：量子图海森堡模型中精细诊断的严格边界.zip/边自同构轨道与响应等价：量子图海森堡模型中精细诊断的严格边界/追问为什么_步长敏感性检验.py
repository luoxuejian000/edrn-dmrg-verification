"""
追问为什么_步长敏感性检验.py

目标：
    检验29对能隙例外是否是实验步长造成的假象。
    对每对例外，用四种步长重新计算能隙曲线：
        - 11点（原始）
        - 21点
        - 51点
        - 101点
    在每个步长下，检查：
        1. 响应（排序分布）是否仍然等价
        2. 能隙是否仍然不等价
        3. 如果能隙差异随步长变细而消失，则该例外是步长假象
        4. 如果差异在所有步长下稳定，则是真实结构
    并排展示标准物理（能隙差异随步长变化）与晶脉视角（响应等价稳定性）。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。
    基态简并使用对称性约化密度矩阵。

输出：
    jingmai_why_step_sensitivity.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10
S_POINT_OPTIONS = [11, 21, 51, 101]

def build_basis(N):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    return basis, state_to_idx

def add_heisenberg_term(H, basis, state_to_idx, edges, J_vals):
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J

def build_heisenberg(N, edges, J_vals):
    basis, state_to_idx = build_basis(N)
    H = np.zeros((len(basis), len(basis)), dtype=float)
    add_heisenberg_term(H, basis, state_to_idx, edges, J_vals)
    return H, basis

def compute_gap_and_corrs(N, edges, J_vals):
    H, basis = build_heisenberg(N, edges, J_vals)
    evals, evecs = np.linalg.eigh(H)
    E0 = evals[0]
    degen_indices = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
    degen_dim = len(degen_indices)
    # 能隙
    gap = 0.0
    for k in range(len(evals)):
        if abs(evals[k]-E0) > TOL_DEGEN:
            gap = float(evals[k] - E0)
            break
    # 关联分布
    probs = np.zeros(len(basis))
    for idx in degen_indices:
        probs += np.abs(evecs[:, idx])**2
    probs /= degen_dim
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return gap, np.sort(np.array(corrs))

def get_edge_data(N, edges, edge_idx, s_values):
    n_edges = len(edges)
    gap_curve = []
    sorted_curves = []
    for s in s_values:
        J = np.ones(n_edges); J[edge_idx] = s
        gap, sorted_corrs = compute_gap_and_corrs(N, edges, J)
        gap_curve.append(gap)
        sorted_curves.append(sorted_corrs)
    return gap_curve, sorted_curves

def curves_equal(c1, c2, tol=TOL_CURVE):
    if len(c1) != len(c2):
        return False
    for a, b in zip(c1, c2):
        if isinstance(a, np.ndarray) or isinstance(b, np.ndarray):
            if not np.allclose(a, b, atol=tol):
                return False
        else:
            if abs(a - b) > tol:
                return False
    return True

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def main():
    print("=== 追问为什么_步长敏感性检验 ===\n")
    
    # 读取29对例外
    with open('jingmai_why_gap_exceptions.json', 'r', encoding='utf-8') as f:
        prev = json.load(f)
    
    exception_pairs = [(e['graph'], e['edge_i'], e['edge_j']) 
                       for e in prev['exceptions']]
    print(f"待检验的例外对数：{len(exception_pairs)}\n")
    
    all_graphs = get_all_N6_graphs()
    
    results = []
    
    for g_idx, edge_i, edge_j in exception_pairs:
        edges = all_graphs[g_idx]
        n_edges = len(edges)
        
        print(f"\n===== 图{g_idx} 边{edge_i}({edges[edge_i]}) vs 边{edge_j}({edges[edge_j]}) =====")
        
        per_step_results = {}
        
        for n_points in S_POINT_OPTIONS:
            s_values = np.linspace(-1.5, 0.0, n_points)
            gap_i, sorted_i = get_edge_data(N, edges, edge_i, s_values)
            gap_j, sorted_j = get_edge_data(N, edges, edge_j, s_values)
            
            resp_same = curves_equal(sorted_i, sorted_j)
            gap_same = curves_equal(gap_i, gap_j)
            max_gap_diff = max(abs(a-b) for a, b in zip(gap_i, gap_j))
            
            per_step_results[n_points] = {
                'resp_same': resp_same,
                'gap_same': gap_same,
                'max_gap_diff': float(max_gap_diff),
                'gap_i': gap_i,
                'gap_j': gap_j
            }
            
            print(f"  {n_points}点: 响应等价={resp_same}, 能隙等价={gap_same}, "
                  f"最大能隙差异={max_gap_diff:.6f}")
        
        # 判断是否随步长变化
        gaps_same_list = [per_step_results[np_]['gap_same'] for np_ in S_POINT_OPTIONS]
        resp_same_list = [per_step_results[np_]['resp_same'] for np_ in S_POINT_OPTIONS]
        
        # 能隙差异是否随步长单调降低（假象特征）
        max_diffs = [per_step_results[np_]['max_gap_diff'] for np_ in S_POINT_OPTIONS]
        diff_decreasing = all(max_diffs[i] >= max_diffs[i+1] for i in range(len(max_diffs)-1))
        
        # 响应等价是否在所有步长下稳定
        resp_stable = all(resp_same_list)
        
        # 分类
        if all(gaps_same_list):
            category = '步长假象（细步长下能隙也等价）'
        elif diff_decreasing and max_diffs[-1] < 0.01:
            category = '部分步长假象（差异随步长显著减小）'
        else:
            category = '真实结构（差异不随步长消失）'
        
        print(f"  分类：{category}")
        print(f"  响应在所有步长下稳定：{resp_stable}")
        print(f"  能隙差异随步长递减：{diff_decreasing}")
        print(f"  最大差异序列：{[round(d,4) for d in max_diffs]}")
        
        results.append({
            'graph': g_idx,
            'edge_i': edge_i,
            'edge_j': edge_j,
            'edges_i': edges[edge_i],
            'edges_j': edges[edge_j],
            'per_step': {str(np_): {
                'resp_same': per_step_results[np_]['resp_same'],
                'gap_same': per_step_results[np_]['gap_same'],
                'max_gap_diff': per_step_results[np_]['max_gap_diff']
            } for np_ in S_POINT_OPTIONS},
            'category': category,
            'resp_stable': resp_stable,
            'diff_decreasing': diff_decreasing,
            'max_diffs': max_diffs
        })
    
    # 统计
    print(f"\n===== 总统计 =====")
    categories = {}
    for r in results:
        cat = r['category']
        categories[cat] = categories.get(cat, 0) + 1
    
    for cat, count in sorted(categories.items(), key=lambda x: -x[1]):
        print(f"  {cat}: {count}/{len(results)}")
    
    # 输出分类列表
    print(f"\n===== 真实结构（差异不随步长消失） =====")
    for r in results:
        if '真实结构' in r['category']:
            print(f"  图{r['graph']} 边{r['edge_i']}({r['edges_i']}) vs 边{r['edge_j']}({r['edges_j']})")
            print(f"    最大能隙差异序列: {[round(d,4) for d in r['max_diffs']]}")
    
    output = {
        'n_exceptions': len(results),
        'categories': categories,
        'results': results,
        'note': '步长敏感性检验。'
    }
    with open('jingmai_why_step_sensitivity.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_step_sensitivity.json")

if __name__ == "__main__":
    main()