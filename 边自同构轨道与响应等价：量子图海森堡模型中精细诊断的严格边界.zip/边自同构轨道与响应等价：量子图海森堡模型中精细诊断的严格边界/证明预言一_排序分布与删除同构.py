"""
证明预言一：排序关联分布等价类 = 边删除同构类

目标：
    检验大预言一：两条边给出相同排序关联分布的充要条件是删除这两条边后图同构。
    对N=6全部112个连通图：
        1. 对每条边作为缺陷边，在多个Δ点扫描，得到排序关联分布曲线。
        2. 根据排序分布曲线是否逐点相同，构建排序等价类。
        3. 计算每条边的删除同构类：删除该边后的图是否同构。
        4. 比较两个等价类的边对等价关系是否完全一致。
    统计完全一致的图数，对不一致的图输出详细差异。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。
    基态简并使用对称性约化密度矩阵。
    排序分布比较容差 1e-10。
    扫描Δ点数：11（-1.5 到 0.0 等间距）。

理论精髓：
    - 数据自己说话。
    - 并排展示标准物理（边删除同构）与晶脉视角（排序分布等价类）。
    - 追问过程：如果预言不成立，差异在哪里？

输出：
    jingmai_prediction1_proof.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
S_POINTS = 11  # 扫描点数
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10

def build_hamiltonian_and_basis(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def compute_probs_with_degen(N, edges, J_vals):
    H, basis = build_hamiltonian_and_basis(N, edges, J_vals)
    evals, evecs = np.linalg.eigh(H)
    E0 = evals[0]
    degen_indices = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
    degen_dim = len(degen_indices)
    probs = np.zeros(len(basis))
    for idx in degen_indices:
        probs += np.abs(evecs[:, idx])**2
    probs /= degen_dim
    return probs, basis

def compute_corrs_from_probs(N, edges, basis, probs):
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return np.array(corrs)

def get_sorted_correlation_curve(N, edges, defect_idx, s_values):
    """返回缺陷边的排序关联分布曲线（每个Δ点一个排序数组）"""
    n_edges = len(edges)
    curve = []
    for s in s_values:
        J = np.ones(n_edges)
        J[defect_idx] = s
        probs, basis = compute_probs_with_degen(N, edges, J)
        corrs = compute_corrs_from_probs(N, edges, basis, probs)
        curve.append(np.sort(corrs))
    return curve

def curves_equal(curve1, curve2, tol=TOL_CURVE):
    """判断两条排序分布曲线是否逐点相同"""
    if len(curve1) != len(curve2):
        return False
    for c1, c2 in zip(curve1, curve2):
        if not np.allclose(c1, c2, atol=tol):
            return False
    return True

def are_deletions_isomorphic(edges, N, i, j):
    """判断删除边i和删除边j后的图是否同构"""
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    G_del_i = G.copy()
    G_del_i.remove_edge(*edges[i])
    G_del_j = G.copy()
    G_del_j.remove_edge(*edges[j])
    return nx.is_isomorphic(G_del_i, G_del_j)

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def main():
    print("=== 证明预言一：排序分布等价类 = 边删除同构类 ===\n")
    
    all_graphs = get_all_N6_graphs()
    s_values = np.linspace(-1.5, 0.0, S_POINTS)
    print(f"总图数：{len(all_graphs)}")
    print(f"扫描点数：{S_POINTS}")
    
    consistent_count = 0
    inconsistent_graphs = []
    all_differences = []
    
    for g_idx, edges in enumerate(all_graphs):
        n_edges = len(edges)
        # 计算每条边的排序分布曲线
        sorted_curves = []
        for i in range(n_edges):
            curve = get_sorted_correlation_curve(N, edges, i, s_values)
            sorted_curves.append(curve)
        
        # 构建排序等价矩阵和删除同构矩阵
        sorted_equiv = np.zeros((n_edges, n_edges), dtype=bool)
        del_equiv = np.zeros((n_edges, n_edges), dtype=bool)
        for i in range(n_edges):
            for j in range(i+1, n_edges):
                sorted_same = curves_equal(sorted_curves[i], sorted_curves[j])
                sorted_equiv[i, j] = sorted_equiv[j, i] = sorted_same
                del_same = are_deletions_isomorphic(edges, N, i, j)
                del_equiv[i, j] = del_equiv[j, i] = del_same
        
        # 对角线设为 True（自身等价）
        for i in range(n_edges):
            sorted_equiv[i, i] = True
            del_equiv[i, i] = True
        
        # 比较两个等价矩阵是否完全相同
        if np.array_equal(sorted_equiv, del_equiv):
            consistent_count += 1
        else:
            inconsistent_graphs.append(g_idx)
            # 找出差异边对
            for i in range(n_edges):
                for j in range(i+1, n_edges):
                    if sorted_equiv[i, j] != del_equiv[i, j]:
                        diff_type = 'sorted_same_del_diff' if sorted_equiv[i, j] else 'sorted_diff_del_same'
                        all_differences.append({
                            'graph': g_idx,
                            'edge_i': i,
                            'edge_j': j,
                            'type': diff_type
                        })
        if (g_idx+1) % 20 == 0:
            print(f"  进度：{g_idx+1}/{len(all_graphs)}")
    
    print(f"\n===== 结果 =====")
    print(f"排序分布等价类与删除同构类完全一致的图数：{consistent_count}")
    print(f"不一致的图数：{len(inconsistent_graphs)}")
    print(f"不一致边对总数：{len(all_differences)}")
    
    if all_differences:
        print("\n不一致图列表：", inconsistent_graphs)
        print("\n差异边对详情（前20个）：")
        for d in all_differences[:20]:
            print(f"  图{d['graph']} 边{d['edge_i']} vs 边{d['edge_j']} 类型={d['type']}")
    else:
        print("\n预言一在所有N=6连通图中严格成立。")
    
    output = {
        'total_graphs': len(all_graphs),
        'S_POINTS': S_POINTS,
        'consistent_count': consistent_count,
        'inconsistent_graphs': inconsistent_graphs,
        'all_differences': all_differences,
        'note': '证明预言一：排序分布等价类是否等于边删除同构类。'
    }
    with open('jingmai_prediction1_proof.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_prediction1_proof.json")

if __name__ == "__main__":
    main()