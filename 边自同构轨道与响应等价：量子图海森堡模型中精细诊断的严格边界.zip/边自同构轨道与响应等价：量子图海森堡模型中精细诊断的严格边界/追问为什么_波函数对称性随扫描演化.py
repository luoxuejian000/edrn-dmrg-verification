"""
追问为什么_波函数对称性随扫描演化.py

目标：
    检查同轨道边对扫描时波函数对称性随Δ的演化。
    对每个反例图，在多个Δ点上：
        1. 扫描边ei和ej，得到基态波函数
        2. 应用自同构映射到ei的波函数，与ej的波函数比较
        3. 计算绝对内积、符号
        4. 同时计算能隙
    检验波函数对称性破坏是否与能隙闭合相关。
    并排输出标准物理（能隙）与晶脉视角（波函数内积、符号）。

方法：
    只查同与不同，不拟合。
    不筛除任何数据。

输出：
    jingmai_why_wavefunction_scan.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6

def build_hamiltonian_and_basis(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def get_automorphisms(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    GM = iso.GraphMatcher(G, G)
    return list(GM.isomorphisms_iter())

def get_edge_orbits_from_edges(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    automorphisms = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in automorphisms:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return orbits, edge_to_orbit

def build_permutation_matrix(basis, mapping, N):
    new_basis_states = []
    for state in basis:
        new_state = 0
        for i in range(N):
            if (state >> i) & 1:
                new_state |= (1 << mapping[i])
        new_basis_states.append(new_state)
    P = np.zeros((len(basis), len(basis)), dtype=float)
    for old_idx, new_state in enumerate(new_basis_states):
        if new_state in basis:
            new_idx = basis.index(new_state)
            P[new_idx, old_idx] = 1.0
    return P

def main():
    print("=== 追问为什么_波函数对称性随扫描演化 ===\n")
    
    all_graphs = get_all_N6_graphs()
    
    # 选择几个反例图
    ce_graph_indices = [38, 80, 82, 89, 93, 110, 111]
    s_points = [-1.5, -1.0, -0.5, -0.25, 0.0]
    results = []
    
    for g_idx in ce_graph_indices:
        edges = all_graphs[g_idx]
        n_edges = len(edges)
        orbits, edge_to_orbit = get_edge_orbits_from_edges(edges, N)
        automorphisms = get_automorphisms(edges, N)
        
        print(f"\n===== 图 {g_idx}（{n_edges}边，{len(orbits)}轨道） =====")
        
        # 取第一个多边轨道
        multi_orbits = [oi for oi, orbit in enumerate(orbits) if len(orbit) >= 2]
        if not multi_orbits:
            continue
        oi = multi_orbits[0]
        ei = orbits[oi][0]
        ej = orbits[oi][1]
        
        # 找映射
        mapping = None
        for auto in automorphisms:
            mapped_edge = tuple(sorted((auto[edges[ei][0]], auto[edges[ei][1]])))
            if mapped_edge == edges[ej]:
                mapping = auto
                break
        if mapping is None:
            continue
        
        print(f"  轨道{oi}: 边{ei}->边{ej}")
        print(f"  {'Δ':<8} {'能隙':<12} {'内积':<12} {'符号':<6}")
        
        for s_val in s_points:
            # 扫描 ei
            J_i = np.ones(n_edges); J_i[ei] = s_val
            H_i, basis_i = build_hamiltonian_and_basis(N, edges, J_i)
            evals_i, evecs_i = np.linalg.eigh(H_i)
            psi_i = evecs_i[:, 0]
            
            # 扫描 ej
            J_j = np.ones(n_edges); J_j[ej] = s_val
            H_j, basis_j = build_hamiltonian_and_basis(N, edges, J_j)
            evals_j, evecs_j = np.linalg.eigh(H_j)
            psi_j = evecs_j[:, 0]
            
            # 映射 psi_i
            P = build_permutation_matrix(basis_i, mapping, N)
            psi_i_mapped = P @ psi_i
            
            # 计算内积和符号
            dot_val = np.dot(psi_i_mapped, psi_j)
            overlap = np.abs(dot_val)
            sign = np.sign(dot_val)
            
            # 能隙
            gap_i = evals_i[1] - evals_i[0]
            gap_j = evals_j[1] - evals_j[0]
            
            print(f"  {s_val:<8.2f} {gap_i:<12.8f} {overlap:<12.10f} {sign:<6.1f}")
            
            results.append({
                'graph': g_idx,
                'orbit': oi,
                'edge_i': ei,
                'edge_j': ej,
                's_val': s_val,
                'gap_i': float(gap_i),
                'gap_j': float(gap_j),
                'overlap': float(overlap),
                'sign': float(sign)
            })
    
    output = {
        'results': results,
        'note': '波函数对称性随Δ的演化。内积<1说明波函数对称性破坏，可能与能隙闭合相关。'
    }
    with open('jingmai_why_wavefunction_scan.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_wavefunction_scan.json")

if __name__ == "__main__":
    main()