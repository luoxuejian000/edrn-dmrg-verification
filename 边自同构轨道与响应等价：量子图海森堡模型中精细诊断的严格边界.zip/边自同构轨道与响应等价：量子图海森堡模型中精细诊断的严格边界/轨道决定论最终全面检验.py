"""
轨道决定论最终全面检验.py
（修复版：在 main() 中补充 N = 6）
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

TOL = 1e-8

def build_hamiltonian(N, edges, J_vals, N_up=None):
    if N_up is None:
        N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def compute_correlations_thermal(N, edges, J_vals, T=0.0, N_up=None):
    if N_up is None:
        N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    
    evals, evecs = np.linalg.eigh(H)
    
    if T < 1e-10:
        psi = evecs[:, 0]
        probs = np.abs(psi)**2
    else:
        beta = 1.0 / T
        exp_vals = np.exp(-beta * evals)
        Z = np.sum(exp_vals)
        weights = exp_vals / Z
        probs = np.zeros(dim)
        for n in range(dim):
            probs += weights[n] * np.abs(evecs[:, n])**2
    
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(dim)
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return np.array(corrs)

def compute_E_thermal(N, edges, J_vals, T=0.0):
    corrs = compute_correlations_thermal(N, edges, J_vals, T)
    return float(np.std(corrs))

def get_edge_orbits_from_edges(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    automorphisms = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in automorphisms:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return orbits, edge_to_orbit

def same_curve(c1, c2, tol=TOL):
    return np.allclose(c1, c2, atol=tol)

def run_orbit_test(edges, N, n_points=101, T=0.0, s_start=-1.5, s_end=0.0):
    n_edges = len(edges)
    orbits, edge_to_orbit = get_edge_orbits_from_edges(edges, N)
    s_values = np.linspace(s_start, s_end, n_points)
    E_curves = []
    for i in range(n_edges):
        curve = np.zeros(n_points)
        for si, s in enumerate(s_values):
            J = np.ones(n_edges); J[i] = s
            curve[si] = compute_E_thermal(N, edges, J, T)
        E_curves.append(curve)
    stats = {'same_orbit_same': 0, 'same_orbit_diff': 0,
             'diff_orbit_same': 0, 'diff_orbit_diff': 0}
    counterexamples = []
    for i in range(n_edges):
        for j in range(i+1, n_edges):
            cs = same_curve(E_curves[i], E_curves[j])
            os_ = edge_to_orbit[i] == edge_to_orbit[j]
            if os_:
                if cs: stats['same_orbit_same'] += 1
                else: stats['same_orbit_diff'] += 1; counterexamples.append(('same_orbit_diff', i, j))
            else:
                if cs: stats['diff_orbit_same'] += 1; counterexamples.append(('diff_orbit_same', i, j))
                else: stats['diff_orbit_diff'] += 1
    return stats, counterexamples, len(orbits)

def main():
    N = 6  # 补充定义

    print("=== 轨道决定论最终全面检验 ===")
    
    all_results = {}
    
    # 检验一：N=12 链图
    print("\n===== 检验一：N=12 链图 =====")
    N12 = 12
    edges_chain12 = [(i, i+1) for i in range(N12-1)]
    stats, ce, n_orb = run_orbit_test(edges_chain12, N12, n_points=51)
    print(f"  轨道数：{n_orb}, 边数：{len(edges_chain12)}")
    print(f"  同轨道同={stats['same_orbit_same']}, 同轨道异={stats['same_orbit_diff']}, "
          f"异轨道同={stats['diff_orbit_same']}, 异轨道异={stats['diff_orbit_diff']}")
    print(f"  反例数：{len(ce)}")
    all_results['N12_chain'] = {'stats': stats, 'counterexamples': ce, 'n_orbits': n_orb}
    
    # 检验二：完全二分图 K3,3
    print("\n===== 检验二：完全二分图 K3,3 =====")
    edges_bipartite = [(i, j) for i in range(3) for j in range(3, 6)]
    edges_bipartite.sort()
    stats, ce, n_orb = run_orbit_test(edges_bipartite, N, n_points=101)
    print(f"  轨道数：{n_orb}, 边数：{len(edges_bipartite)}")
    print(f"  同轨道同={stats['same_orbit_same']}, 同轨道异={stats['same_orbit_diff']}, "
          f"异轨道同={stats['diff_orbit_same']}, 异轨道异={stats['diff_orbit_diff']}")
    print(f"  反例数：{len(ce)}")
    all_results['K33_bipartite'] = {'stats': stats, 'counterexamples': ce, 'n_orbits': n_orb}
    
    # 检验三：有限温度 T=0.1 和 T=0.5
    print("\n===== 检验三：有限温度（小世界图N=6 seed=42） =====")
    edges_sw = []
    G = nx.watts_strogatz_graph(N, 4, 0.1, seed=42)
    edges_sw = [tuple(sorted(e)) for e in G.edges()]
    edges_sw.sort()
    for T_val in [0.1, 0.5]:
        stats, ce, n_orb = run_orbit_test(edges_sw, N, n_points=51, T=T_val)
        print(f"  T={T_val}: 同轨道同={stats['same_orbit_same']}, 同轨道异={stats['same_orbit_diff']}, "
              f"异轨道同={stats['diff_orbit_same']}, 异轨道异={stats['diff_orbit_diff']}")
        print(f"    反例数：{len(ce)}")
        all_results[f'thermal_T{T_val}'] = {'stats': stats, 'counterexamples': ce, 'n_orbits': n_orb}
    
    # 检验四：所有N=6连通图穷举
    print("\n===== 检验四：所有N=6连通图穷举 =====")
    all_graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == 6 and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges_g = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges_g.sort()
            all_graphs.append(edges_g)
    
    print(f"  N=6连通图数量：{len(all_graphs)}")
    total_same_orbit_same = 0
    total_same_orbit_diff = 0
    total_diff_orbit_same = 0
    total_diff_orbit_diff = 0
    total_counterexamples = 0
    ce_graphs = []
    
    for g_idx, edges_g in enumerate(all_graphs):
        stats, ce, n_orb = run_orbit_test(edges_g, N, n_points=31)
        total_same_orbit_same += stats['same_orbit_same']
        total_same_orbit_diff += stats['same_orbit_diff']
        total_diff_orbit_same += stats['diff_orbit_same']
        total_diff_orbit_diff += stats['diff_orbit_diff']
        total_counterexamples += len(ce)
        if ce:
            ce_graphs.append((g_idx, ce))
        
        if (g_idx+1) % 30 == 0:
            print(f"  进度：{g_idx+1}/{len(all_graphs)}")
    
    print(f"  总统计：同轨道同={total_same_orbit_same}, 同轨道异={total_same_orbit_diff}, "
          f"异轨道同={total_diff_orbit_same}, 异轨道异={total_diff_orbit_diff}")
    print(f"  总反例数：{total_counterexamples}")
    print(f"  有反例的图数：{len(ce_graphs)}")
    if ce_graphs:
        for g_idx, ce in ce_graphs[:5]:
            print(f"    图{g_idx}: {ce[:3]}")
    
    all_results['N6_exhaustive'] = {
        'total_same_orbit_same': total_same_orbit_same,
        'total_same_orbit_diff': total_same_orbit_diff,
        'total_diff_orbit_same': total_diff_orbit_same,
        'total_diff_orbit_diff': total_diff_orbit_diff,
        'total_counterexamples': total_counterexamples,
        'ce_graphs': ce_graphs
    }
    
    output = {
        'all_results': all_results,
        'note': '轨道决定论最终全面检验：N=12链图、K3,3二分图、有限温度、N=6穷举。'
    }
    with open('jingmai_final_comprehensive.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_final_comprehensive.json")

if __name__ == "__main__":
    main()