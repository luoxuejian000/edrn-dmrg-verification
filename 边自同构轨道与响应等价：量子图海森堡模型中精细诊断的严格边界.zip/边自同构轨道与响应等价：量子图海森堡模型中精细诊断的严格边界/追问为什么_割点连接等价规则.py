"""
追问为什么_割点连接等价规则.py

目标：
    检验一个更精确的规则：
    一条分支内边与一条连接割点边，响应是否总是等价？
    对每个有割点的问题图，对每个割点和每个分支：
        1. 收集分支内部边
        2. 收集连接割点与该分支的边
        3. 比较两组边的响应函数
    统计：分支内边与割点连接边等价的比例。
    同时检查反向：分支内边与不属于该分支的割点边是否不等价。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。
    基态简并使用对称性约化密度矩阵。

输出：
    jingmai_why_cut_branch_rule.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
S_POINTS = 11
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10

def build_heisenberg(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def compute_corrs(N, edges, basis, probs):
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return np.array(corrs)

def get_sorted_curves(N, edges, s_values):
    n_edges = len(edges)
    curves = []
    for i in range(n_edges):
        curve = []
        for s in s_values:
            J = np.ones(n_edges); J[i] = s
            H, basis = build_heisenberg(N, edges, J)
            evals, evecs = np.linalg.eigh(H)
            E0 = evals[0]
            degen = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
            probs = np.zeros(len(basis))
            for idx in degen:
                probs += np.abs(evecs[:, idx])**2
            probs /= len(degen)
            corrs = compute_corrs(N, edges, basis, probs)
            curve.append(np.sort(corrs))
        curves.append(curve)
    return curves

def curves_equal(c1, c2):
    return all(np.allclose(a, b, atol=TOL_CURVE) for a, b in zip(c1, c2))

def main():
    print("=== 追问为什么_割点连接等价规则 ===\n")
    
    all_graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            all_graphs.append(edges)
    
    problem_with_cut = [9, 26, 31, 33, 49, 55, 60, 64, 69]
    s_values = np.linspace(-1.5, 0.0, S_POINTS)
    
    total_checks = 0
    total_match = 0
    total_mismatch = 0
    details = []
    
    for g_idx in problem_with_cut:
        edges = all_graphs[g_idx]
        n_edges = len(edges)
        G = nx.Graph()
        G.add_nodes_from(range(N))
        G.add_edges_from(edges)
        cut_vertices = list(nx.articulation_points(G))
        curves = get_sorted_curves(N, edges, s_values)
        
        print(f"\n===== 图{g_idx}: 割点={cut_vertices} =====")
        
        for cv in cut_vertices:
            G_removed = G.copy()
            G_removed.remove_node(cv)
            components = list(nx.connected_components(G_removed))
            
            for ci, comp in enumerate(components):
                # 分支内边：两端都在comp中
                inner_edges = []
                for ei, (u, v) in enumerate(edges):
                    if u in comp and v in comp:
                        inner_edges.append(ei)
                # 连接割点边：一端是cv，另一端在comp中
                connect_edges = []
                for ei, (u, v) in enumerate(edges):
                    if (u == cv and v in comp) or (v == cv and u in comp):
                        connect_edges.append(ei)
                
                if not inner_edges or not connect_edges:
                    continue
                
                print(f"  割点{cv} 分支{ci} (节点{sorted(comp)}):")
                print(f"    分支内边：{inner_edges}")
                print(f"    连接割点边：{connect_edges}")
                
                for ie in inner_edges:
                    for ce in connect_edges:
                        total_checks += 1
                        same = curves_equal(curves[ie], curves[ce])
                        if same:
                            total_match += 1
                        else:
                            total_mismatch += 1
                        details.append({
                            'graph': g_idx,
                            'cut_vertex': cv,
                            'branch': ci,
                            'inner_edge': ie,
                            'connect_edge': ce,
                            'same': same
                        })
                        status = "等价" if same else "不等价"
                        print(f"      内边{ie}({edges[ie]}) vs 连接边{ce}({edges[ce]}): {status}")
    
    print(f"\n===== 统计 =====")
    print(f"总检查数：{total_checks}")
    print(f"等价：{total_match}")
    print(f"不等价：{total_mismatch}")
    if total_checks > 0:
        print(f"等价比例：{total_match/total_checks:.4f}")
    
    if total_mismatch == 0:
        print("\n规则成立：分支内边与连接割点边总是等价。")
    else:
        print(f"\n规则不完全成立：{total_mismatch} 对不等价。")
        for d in details:
            if not d['same']:
                print(f"  图{d['graph']} 割点{d['cut_vertex']} 分支{d['branch']}: "
                      f"内边{d['inner_edge']} vs 连接边{d['connect_edge']}")
    
    output = {
        'total_checks': total_checks,
        'total_match': total_match,
        'total_mismatch': total_mismatch,
        'details': details,
        'note': '检验分支内边与割点连接边的等价规则。'
    }
    with open('jingmai_why_cut_branch_rule.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_cut_branch_rule.json")

if __name__ == "__main__":
    main()