"""
追问为什么_局部对称性精确检验.py

目标：
    上一轮发现：等价对中，"公共端点u的两个邻居c和v与u其他邻居的连接数相同"
    这一特征在等价对中匹配率0.9167，在非等价对中只有0.5758。
    追问：这个局部对称性条件是否就是等价性的精确判据？
    对每个内边-连接边组合：
        1. 计算c和v相对于u的局部对称性特征
        2. 检查等价性与特征是否完全一致
        3. 若不一致，找出反例并分析其特殊之处

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。
    基态简并使用对称性约化密度矩阵。

输出：
    jingmai_why_local_symmetry_precise.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
S_POINTS = 11
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10

def build_heisenberg(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def compute_corrs(N, edges, basis, probs):
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return np.array(corrs)

def get_sorted_curves(N, edges, s_values):
    n_edges = len(edges)
    curves = []
    for i in range(n_edges):
        curve = []
        for s in s_values:
            J = np.ones(n_edges); J[i] = s
            H, basis = build_heisenberg(N, edges, J)
            evals, evecs = np.linalg.eigh(H)
            E0 = evals[0]
            degen = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
            probs = np.zeros(len(basis))
            for idx in degen:
                probs += np.abs(evecs[:, idx])**2
            probs /= len(degen)
            corrs = compute_corrs(N, edges, basis, probs)
            curve.append(np.sort(corrs))
        curves.append(curve)
    return curves

def curves_equal(c1, c2):
    return all(np.allclose(a, b, atol=TOL_CURVE) for a, b in zip(c1, c2))

def local_symmetry_features(G, u, c, v):
    """计算c和v相对于u的局部对称性特征"""
    nbrs_u = set(G.neighbors(u))
    other_nbrs_u = nbrs_u - {c, v}
    nbrs_c = set(G.neighbors(c)) - {u}
    nbrs_v = set(G.neighbors(v)) - {u}
    
    c_conn_other = len(nbrs_c & other_nbrs_u)
    v_conn_other = len(nbrs_v & other_nbrs_u)
    
    # 更细的特征：c和v与other_nbrs_u中每个节点的连接模式
    c_pattern = tuple(1 if x in nbrs_c else 0 for x in sorted(other_nbrs_u))
    v_pattern = tuple(1 if x in nbrs_v else 0 for x in sorted(other_nbrs_u))
    pattern_same = c_pattern == v_pattern
    
    # c和v到u其他邻居的共同连接数
    common_conn = c_conn_other + v_conn_other
    
    # c和v是否互相连接（不含u）
    c_v_connected = G.has_edge(c, v)
    
    return {
        'c_conn_other': c_conn_other,
        'v_conn_other': v_conn_other,
        'conn_other_same': c_conn_other == v_conn_other,
        'c_pattern': c_pattern,
        'v_pattern': v_pattern,
        'pattern_same': pattern_same,
        'common_conn': common_conn,
        'c_v_connected': c_v_connected,
        'deg_c': G.degree(c),
        'deg_v': G.degree(v),
    }

def main():
    print("=== 追问为什么_局部对称性精确检验 ===\n")
    
    all_graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            all_graphs.append(edges)
    
    problem_with_cut = [9, 26, 31, 33, 49, 55, 60, 64, 69]
    s_values = np.linspace(-1.5, 0.0, S_POINTS)
    
    all_results = []
    
    for g_idx in problem_with_cut:
        edges = all_graphs[g_idx]
        G = nx.Graph()
        G.add_nodes_from(range(N))
        G.add_edges_from(edges)
        cut_vertices = list(nx.articulation_points(G))
        curves = get_sorted_curves(N, edges, s_values)
        
        for cv in cut_vertices:
            G_removed = G.copy()
            G_removed.remove_node(cv)
            components = list(nx.connected_components(G_removed))
            
            for ci, comp in enumerate(components):
                inner_edges = []
                for ei, (u, v) in enumerate(edges):
                    if u in comp and v in comp:
                        inner_edges.append(ei)
                connect_edges = []
                for ei, (u, v) in enumerate(edges):
                    if (u == cv and v in comp) or (v == cv and u in comp):
                        connect_edges.append(ei)
                
                if not inner_edges or not connect_edges:
                    continue
                
                for ie in inner_edges:
                    for ce in connect_edges:
                        u_ie, v_ie = edges[ie]
                        u_ce, v_ce = edges[ce]
                        if u_ce == cv:
                            u_common = v_ce
                            c_end = cv
                            other_ie = v_ie if u_ie == u_common else u_ie
                        else:
                            u_common = u_ce
                            c_end = cv
                            other_ie = v_ie if u_ie == u_common else u_ie
                        
                        same = curves_equal(curves[ie], curves[ce])
                        feats = local_symmetry_features(G, u_common, c_end, other_ie)
                        
                        all_results.append({
                            'graph': g_idx,
                            'cut_vertex': cv,
                            'branch': ci,
                            'inner_edge': ie,
                            'connect_edge': ce,
                            'inner_edge_nodes': edges[ie],
                            'connect_edge_nodes': edges[ce],
                            'common_endpoint': u_common,
                            'cut_endpoint': c_end,
                            'other_inner_endpoint': other_ie,
                            'same': same,
                            'features': feats
                        })
    
    # 统计各特征与等价性的关系
    print(f"总检查数：{len(all_results)}")
    n_equiv = sum(1 for r in all_results if r['same'])
    n_non = len(all_results) - n_equiv
    print(f"等价：{n_equiv}")
    print(f"非等价：{n_non}\n")
    
    feature_keys = ['conn_other_same', 'pattern_same', 'c_v_connected']
    
    print(f"{'特征':<25} {'等价中为真':<12} {'非等价中为真':<12} {'区分度':<10}")
    print("-" * 60)
    for key in feature_keys:
        eq_true = sum(1 for r in all_results if r['same'] and r['features'][key])
        neq_true = sum(1 for r in all_results if not r['same'] and r['features'][key])
        eq_ratio = eq_true / n_equiv if n_equiv else 0
        neq_ratio = neq_true / n_non if n_non else 0
        # 区分度：等价中为真比例 - 非等价中为真比例
        discrimination = eq_ratio - neq_ratio
        print(f"{key:<25} {eq_true}({eq_ratio:.3f})   {neq_true}({neq_ratio:.3f})   {discrimination:.4f}")
    
    # 检查 pattern_same 是否能完美区分
    pattern_eq_all = all(r['features']['pattern_same'] for r in all_results if r['same'])
    pattern_neq_none = all(not r['features']['pattern_same'] for r in all_results if not r['same'])
    
    print(f"\n===== pattern_same 区分能力 =====")
    print(f"等价对中 pattern_same 全为真：{pattern_eq_all}")
    print(f"非等价对中 pattern_same 全为假：{pattern_neq_none}")
    
    if pattern_eq_all and pattern_neq_none:
        print("pattern_same 完美区分等价与非等价！")
    else:
        # 找反例
        print("\n反例：")
        for r in all_results:
            if r['same'] and not r['features']['pattern_same']:
                print(f"  等价但pattern不同: 图{r['graph']} 内边{r['inner_edge']} vs 连接边{r['connect_edge']}")
            if not r['same'] and r['features']['pattern_same']:
                print(f"  非等价但pattern相同: 图{r['graph']} 内边{r['inner_edge']} vs 连接边{r['connect_edge']}")
    
    # 找最佳特征组合
    print(f"\n===== 特征组合穷举 =====")
    best_score = -1
    best_combo = None
    perfect_combos = []
    for r in range(1, len(feature_keys) + 1):
        for combo in itertools.combinations(feature_keys, r):
            correct = 0
            for r_ in all_results:
                pred = all(r_['features'][k] for k in combo)
                if pred == r_['same']:
                    correct += 1
            if correct > best_score:
                best_score = correct
                best_combo = combo
            if correct == len(all_results):
                perfect_combos.append(combo)
    
    print(f"最佳组合：{best_combo}，正确率：{best_score}/{len(all_results)}")
    if perfect_combos:
        print(f"完美组合：{perfect_combos}")
    
    output = {
        'all_results': all_results,
        'n_total': len(all_results),
        'n_equiv': n_equiv,
        'n_non': n_non,
        'feature_keys': feature_keys,
        'pattern_eq_all': pattern_eq_all,
        'pattern_neq_none': pattern_neq_none,
        'perfect_combos': [list(c) for c in perfect_combos],
        'best_combo': list(best_combo) if best_combo else None,
        'best_score': best_score,
        'note': '局部对称性精确检验。'
    }
    with open('jingmai_why_local_symmetry_precise.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_local_symmetry_precise.json")

if __name__ == "__main__":
    main()