"""
追问为什么_自同构映射重建检验.py

目标：
    用更可靠的方法检验自同构映射是否保持扫描哈密顿量。
    方法：
        1. 取同轨道边对 ei, ej
        2. 构建扫描 ei 的耦合配置 J_i（仅 ei 为 s）
        3. 应用自同构 φ 到边集和 J_i 上，得到变换后的边集 φ(edges) 和 φ(J_i)
        4. 用 φ(edges), φ(J_i) 构建哈密顿量 H_mapped
        5. 用原始 edges, J_j 构建扫描 ej 的哈密顿量 H_j
        6. 逐元素比较 H_mapped 与 H_j
    如果相等，说明自同构确实保持哈密顿量，反例另有原因；
    如果不等，说明自同构不保持扫描哈密顿量，找到物理根源。
    并排输出差异矩阵和差异来源（哪些边贡献了差异）。

方法：
    只查同与不同，不拟合，不预设。
    标准物理视角（哈密顿量逐元素）与晶脉视角（反例边对）并排。

输出：
    jingmai_why_rebuild_mapping.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6

def build_hamiltonian_from_edges(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def get_automorphisms(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    GM = iso.GraphMatcher(G, G)
    return list(GM.isomorphisms_iter())

def get_edge_orbits_from_edges(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    automorphisms = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in automorphisms:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return orbits, edge_to_orbit

def main():
    print("=== 追问为什么_自同构映射重建检验 ===\n")
    
    all_graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            all_graphs.append(edges)
    
    ce_graph_indices = [38, 80, 82, 89, 93, 110, 111]
    results = []
    
    for g_idx in ce_graph_indices:
        edges = all_graphs[g_idx]
        n_edges = len(edges)
        orbits, edge_to_orbit = get_edge_orbits_from_edges(edges, N)
        automorphisms = get_automorphisms(edges, N)
        
        print(f"\n===== 图 {g_idx}（{n_edges}边，{len(orbits)}轨道） =====")
        
        s_val = -0.5
        J_template = np.ones(n_edges)
        
        # 对每个轨道取一对边
        for oi, orbit in enumerate(orbits):
            if len(orbit) < 2:
                continue
            ei = orbit[0]
            ej = orbit[1]
            
            # 找到映射
            mapping = None
            for auto in automorphisms:
                mapped_edge = tuple(sorted((auto[edges[ei][0]], auto[edges[ei][1]])))
                if mapped_edge == edges[ej]:
                    mapping = auto
                    break
            
            if mapping is None:
                print(f"  轨道{oi}: 边{ei}->边{ej} 未找到映射")
                continue
            
            # 构建扫描 ei 的 J 配置
            J_i = J_template.copy()
            J_i[ei] = s_val
            
            # 应用映射到边集和 J 配置
            # 变换后的边集：每条边 (u,v) -> (mapping[u], mapping[v])
            transformed_edges = []
            transformed_J = []
            for idx, (u, v) in enumerate(edges):
                new_u, new_v = mapping[u], mapping[v]
                new_edge = tuple(sorted((new_u, new_v)))
                transformed_edges.append(new_edge)
                transformed_J.append(J_i[idx])
            
            # 注意：变换后的边列表顺序可能与原始不同，需要按边匹配 J
            # 但这里我们直接构建哈密顿量，边顺序不重要，只要 J 与边对应即可
            H_mapped, _ = build_hamiltonian_from_edges(N, transformed_edges, transformed_J)
            
            # 构建扫描 ej 的 J 配置
            J_j = J_template.copy()
            J_j[ej] = s_val
            H_j, _ = build_hamiltonian_from_edges(N, edges, J_j)
            
            # 逐元素比较
            diff_matrix = np.abs(H_mapped - H_j)
            max_diff = float(np.max(diff_matrix))
            # 找出差异最大的矩阵元位置
            flat_idx = np.argmax(diff_matrix)
            idx_2d = np.unravel_index(flat_idx, diff_matrix.shape)
            
            print(f"  轨道{oi}: 边{ei}->边{ej}")
            print(f"    映射后哈密顿量与扫描{ej}的最大差异 = {max_diff:.10e}")
            print(f"    差异最大位置：矩阵元({idx_2d[0]},{idx_2d[1]})")
            print(f"    是否相等：{max_diff < 1e-10}")
            
            # 检查差异来源：哪些边在映射后与原始不一致
            edge_mismatches = []
            for old_edge, new_edge in zip(edges, transformed_edges):
                # 检查新边是否在原始边集中
                if tuple(sorted(new_edge)) not in [tuple(sorted(e)) for e in edges]:
                    edge_mismatches.append((old_edge, new_edge))
            if edge_mismatches:
                print(f"    映射产生了原始图中不存在的边：{edge_mismatches[:5]}")
            else:
                print(f"    映射保持了边集不变")
            
            results.append({
                'graph': g_idx,
                'orbit': oi,
                'edge_i': ei,
                'edge_j': ej,
                'max_diff': max_diff,
                'is_equal': max_diff < 1e-10,
                'diff_position': [int(idx_2d[0]), int(idx_2d[1])],
                'edge_mismatches': [(list(a), list(b)) for a,b in edge_mismatches]
            })
    
    output = {
        'results': results,
        'note': '用重建方法检验自同构映射是否保持扫描哈密顿量。'
    }
    with open('jingmai_why_rebuild_mapping.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_rebuild_mapping.json")

if __name__ == "__main__":
    main()