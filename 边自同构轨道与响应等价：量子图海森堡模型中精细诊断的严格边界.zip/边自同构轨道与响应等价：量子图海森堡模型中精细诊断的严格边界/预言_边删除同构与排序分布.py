"""
预言_边删除同构与排序分布.py

目标：
    检验预言：异轨道同分布反例是否对应“边删除同构”。
    对N=6穷举中所有异轨道同分布边对，检查：
        删除边ei后的图 与 删除边ej后的图 是否同构？
    同时检查同轨道同分布边对是否也满足此条件。
    统计：
        异轨道同分布且删除同构：多少对？
        异轨道同分布但删除不同构：多少对？
        异轨道不同分布且删除同构：多少对？
        异轨道不同分布且删除不同构：多少对？
    如果删除同构与排序分布等价强相关，则预言成立。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。
    基态简并使用对称性约化密度矩阵。

理论精髓：
    - 数据自己说话。
    - 追问：排序分布等价类是否对应删除同构等价类？

输出：
    jingmai_prediction_deletion_isomorphism.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
S_POINTS = 21
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10

def build_hamiltonian_and_basis(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def compute_probs_with_degen(N, edges, J_vals):
    H, basis = build_hamiltonian_and_basis(N, edges, J_vals)
    evals, evecs = np.linalg.eigh(H)
    E0 = evals[0]
    degen_indices = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
    degen_dim = len(degen_indices)
    probs = np.zeros(len(basis))
    for idx in degen_indices:
        probs += np.abs(evecs[:, idx])**2
    probs /= degen_dim
    return probs, basis

def compute_corrs_from_probs(N, edges, basis, probs):
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return np.array(corrs)

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def get_edge_orbits_from_edges(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    automorphisms = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in automorphisms:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return orbits, edge_to_orbit

def are_graphs_deletion_isomorphic(edges, N, ei, ej):
    """检查删除边ei和删除边ej后的图是否同构"""
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    G_del_i = G.copy()
    G_del_i.remove_edge(*edges[ei])
    G_del_j = G.copy()
    G_del_j.remove_edge(*edges[ej])
    return nx.is_isomorphic(G_del_i, G_del_j)

def main():
    print("=== 预言_边删除同构与排序分布 ===\n")
    
    all_graphs = get_all_N6_graphs()
    s_values = np.linspace(-1.5, 0.0, S_POINTS)
    
    # 四类计数
    stats = {
        'diff_orbit_same_dist_del_iso': 0,
        'diff_orbit_same_dist_del_not_iso': 0,
        'diff_orbit_diff_dist_del_iso': 0,
        'diff_orbit_diff_dist_del_not_iso': 0,
    }
    
    results = []
    
    for g_idx, edges in enumerate(all_graphs):
        n_edges = len(edges)
        orbits, edge_to_orbit = get_edge_orbits_from_edges(edges, N)
        
        # 扫描所有边，得到排序分布曲线
        sorted_curves = []
        for i in range(n_edges):
            sorted_curve = []
            for s in s_values:
                J = np.ones(n_edges); J[i] = s
                probs, basis = compute_probs_with_degen(N, edges, J)
                corrs = compute_corrs_from_probs(N, edges, basis, probs)
                sorted_curve.append(np.sort(corrs))
            sorted_curves.append(sorted_curve)
        
        # 比较异轨道边对
        for i in range(n_edges):
            for j in range(i+1, n_edges):
                if edge_to_orbit[i] == edge_to_orbit[j]:
                    continue
                # 检查排序分布是否相同（所有Δ点）
                dist_same = True
                for si in range(S_POINTS):
                    if not np.allclose(sorted_curves[i][si], sorted_curves[j][si], atol=TOL_CURVE):
                        dist_same = False
                        break
                del_iso = are_graphs_deletion_isomorphic(edges, N, i, j)
                
                if dist_same and del_iso:
                    stats['diff_orbit_same_dist_del_iso'] += 1
                elif dist_same and not del_iso:
                    stats['diff_orbit_same_dist_del_not_iso'] += 1
                elif not dist_same and del_iso:
                    stats['diff_orbit_diff_dist_del_iso'] += 1
                else:
                    stats['diff_orbit_diff_dist_del_not_iso'] += 1
                
                results.append({
                    'graph': g_idx,
                    'edge_i': i,
                    'edge_j': j,
                    'orbit_i': edge_to_orbit[i],
                    'orbit_j': edge_to_orbit[j],
                    'dist_same': dist_same,
                    'del_iso': del_iso
                })
        
        if (g_idx+1) % 30 == 0:
            print(f"  进度：{g_idx+1}/{len(all_graphs)}")
    
    # 打印统计
    print("\n===== 统计 =====")
    print(f"异轨道同分布且删除同构：{stats['diff_orbit_same_dist_del_iso']}")
    print(f"异轨道同分布但删除不同构：{stats['diff_orbit_same_dist_del_not_iso']}")
    print(f"异轨道不同分布但删除同构：{stats['diff_orbit_diff_dist_del_iso']}")
    print(f"异轨道不同分布且删除不同构：{stats['diff_orbit_diff_dist_del_not_iso']}")
    
    # 计算预言的命中率
    same_dist = stats['diff_orbit_same_dist_del_iso'] + stats['diff_orbit_same_dist_del_not_iso']
    same_dist_del_iso = stats['diff_orbit_same_dist_del_iso']
    if same_dist > 0:
        hit_rate = same_dist_del_iso / same_dist
    else:
        hit_rate = 0.0
    print(f"\n异轨道同分布边对总数：{same_dist}")
    print(f"其中删除同构的比例：{hit_rate:.4f}")
    
    # 检查是否所有异轨道同分布都满足删除同构
    if stats['diff_orbit_same_dist_del_not_iso'] == 0:
        print("\n预言成立：所有异轨道同分布边对都满足删除同构。")
    else:
        print(f"\n预言不完全成立：{stats['diff_orbit_same_dist_del_not_iso']} 对不满足删除同构。")
    
    output = {
        'stats': stats,
        'results': results,
        'same_dist': same_dist,
        'same_dist_del_iso': same_dist_del_iso,
        'hit_rate': hit_rate,
        'note': '检验异轨道同分布是否对应边删除同构。'
    }
    with open('jingmai_prediction_deletion_isomorphism.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_prediction_deletion_isomorphism.json")

if __name__ == "__main__":
    main()