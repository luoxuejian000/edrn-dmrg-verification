"""
大预言_关系位置不变量存在性检验.py

目标：
    检验大预言：是否存在一个可计算的关系位置不变量，
    它由图结构和相互作用层联合决定，能精确刻画响应等价类。

    方法：
        1. 对N=6全部112个连通图，在三种模型（海森堡、XXZ、次近邻）下
           计算排序分布等价矩阵。
        2. 对每条边计算高维关系位置特征向量，包含：
            - 自同构轨道编号
            - 端点度对
            - 边介数
            - 环长集合
            - 邻居度分布
            - 距离-2度分布
            - 删除后图度序列
            - 拉普拉斯谱隙
            - 邻接谱半径
            - 是否桥
        3. 对所有可能的特征子集（布尔AND组合），检查其等价矩阵
           是否与响应等价矩阵完全一致。
        4. 输出完美匹配的特征组合，或最接近的组合。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。
    基态简并使用对称性约化密度矩阵。

理论精髓：
    - 数据自己说话。
    - 并排展示标准物理（各特征）与晶脉视角（响应等价类）。

输出：
    jingmai_big_prediction_relation_invariant.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
S_POINTS = 11
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10
TOL_FEATURE = 1e-8

def build_basis(N):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    return basis, state_to_idx

def add_heisenberg_term(H, basis, state_to_idx, edges, J_vals):
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J

def build_heisenberg(N, edges, J_vals):
    basis, state_to_idx = build_basis(N)
    H = np.zeros((len(basis), len(basis)), dtype=float)
    add_heisenberg_term(H, basis, state_to_idx, edges, J_vals)
    return H, basis

def build_xxz(N, edges, J_vals, delta_zz=1.5):
    basis, state_to_idx = build_basis(N)
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * delta_zz * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def build_nnn(N, edges, J_vals, strength=0.2):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    nnn_edges = []
    for i in range(N):
        for j in range(i+1, N):
            if not G.has_edge(i, j) and nx.has_path(G, i, j):
                if nx.shortest_path_length(G, i, j) == 2:
                    nnn_edges.append((i, j))
    nnn_edges.sort()
    basis, state_to_idx = build_basis(N)
    H = np.zeros((len(basis), len(basis)), dtype=float)
    add_heisenberg_term(H, basis, state_to_idx, edges, J_vals)
    nnn_J = [strength] * len(nnn_edges)
    add_heisenberg_term(H, basis, state_to_idx, nnn_edges, nnn_J)
    return H, basis

def compute_probs(N, edges, J_vals, model):
    if model == 'heisenberg':
        H, basis = build_heisenberg(N, edges, J_vals)
    elif model == 'xxz':
        H, basis = build_xxz(N, edges, J_vals)
    elif model == 'nnn':
        H, basis = build_nnn(N, edges, J_vals)
    else:
        raise ValueError(model)
    evals, evecs = np.linalg.eigh(H)
    E0 = evals[0]
    degen = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
    probs = np.zeros(len(basis))
    for idx in degen:
        probs += np.abs(evecs[:, idx])**2
    probs /= len(degen)
    return probs, basis

def compute_corrs(N, edges, basis, probs):
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return np.array(corrs)

def get_sorted_curves(N, edges, model, s_values):
    n_edges = len(edges)
    curves = []
    for i in range(n_edges):
        curve = []
        for s in s_values:
            J = np.ones(n_edges)
            J[i] = s
            probs, basis = compute_probs(N, edges, J, model)
            corrs = compute_corrs(N, edges, basis, probs)
            curve.append(np.sort(corrs))
        curves.append(curve)
    return curves

def build_equiv(sorted_curves, n_edges):
    equiv = np.zeros((n_edges, n_edges), dtype=bool)
    for i in range(n_edges):
        for j in range(i+1, n_edges):
            same = all(np.allclose(c1, c2, atol=TOL_CURVE)
                       for c1, c2 in zip(sorted_curves[i], sorted_curves[j]))
            equiv[i, j] = equiv[j, i] = same
    for i in range(n_edges):
        equiv[i, i] = True
    return equiv

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def get_edge_orbits(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    autos = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in autos:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return edge_to_orbit

def edge_features(edges, N, edge_idx):
    """计算边的多维特征"""
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    u, v = edges[edge_idx]
    
    # 自同构轨道
    edge_to_orbit = get_edge_orbits(edges, N)
    orbit = edge_to_orbit[edge_idx]
    
    # 端点度对
    deg_pair = tuple(sorted([G.degree(u), G.degree(v)]))
    
    # 边介数
    bc = nx.edge_betweenness_centrality(G)
    betweenness = bc.get((u, v), bc.get((v, u), 0.0))
    
    # 环长集合
    cycles = []
    for cycle in nx.cycle_basis(G):
        for i in range(len(cycle)):
            a, b = cycle[i], cycle[(i+1)%len(cycle)]
            if (a == u and b == v) or (a == v and b == u):
                cycles.append(len(cycle))
    cycles = tuple(sorted(cycles))
    
    # 邻居度分布
    nbr_u = tuple(sorted([G.degree(x) for x in G.neighbors(u)]))
    nbr_v = tuple(sorted([G.degree(x) for x in G.neighbors(v)]))
    
    # 距离-2度分布
    def dist2_deg(node):
        nodes = set()
        for x in G.neighbors(node):
            for y in G.neighbors(x):
                if y != node:
                    nodes.add(y)
        return tuple(sorted([G.degree(y) for y in nodes]))
    dist2_u = dist2_deg(u)
    dist2_v = dist2_deg(v)
    
    # 删除后图
    G_del = G.copy()
    G_del.remove_edge(u, v)
    del_deg_seq = tuple(sorted([d for _, d in G_del.degree()]))
    del_n_comp = nx.number_connected_components(G_del)
    
    # 谱特征
    L = nx.laplacian_matrix(G_del).toarray()
    lap_evals = np.sort(np.linalg.eigvalsh(L))
    lap_gap = float(lap_evals[1]) if len(lap_evals) > 1 else 0.0
    A = nx.adjacency_matrix(G_del).toarray()
    adj_evals = np.sort(np.linalg.eigvalsh(A))
    adj_radius = float(np.max(np.abs(adj_evals)))
    
    return {
        'orbit': orbit,
        'deg_pair': deg_pair,
        'betweenness': round(betweenness, 6),
        'cycles': cycles,
        'nbr_u': nbr_u,
        'nbr_v': nbr_v,
        'dist2_u': dist2_u,
        'dist2_v': dist2_v,
        'del_deg_seq': del_deg_seq,
        'del_n_comp': del_n_comp,
        'lap_gap': round(lap_gap, 6),
        'adj_radius': round(adj_radius, 6),
    }

FEATURE_KEYS = ['orbit', 'deg_pair', 'betweenness', 'cycles', 'nbr_u', 'nbr_v',
                'dist2_u', 'dist2_v', 'del_deg_seq', 'del_n_comp', 'lap_gap', 'adj_radius']

def feature_equal(f1, f2, key):
    v1, v2 = f1[key], f2[key]
    if isinstance(v1, float) and isinstance(v2, float):
        return abs(v1 - v2) < TOL_FEATURE
    return v1 == v2

def main():
    print("=== 大预言_关系位置不变量存在性检验 ===\n")
    
    all_graphs = get_all_N6_graphs()
    s_values = np.linspace(-1.5, 0.0, S_POINTS)
    models = ['heisenberg', 'xxz', 'nnn']
    print(f"总图数：{len(all_graphs)}")
    print(f"模型：{models}")
    print(f"特征维度：{len(FEATURE_KEYS)}\n")
    
    # 存储所有图的数据
    all_data = []
    
    for g_idx, edges in enumerate(all_graphs):
        n_edges = len(edges)
        
        # 三种模型的响应等价矩阵
        equiv_matrices = {}
        for model in models:
            curves = get_sorted_curves(N, edges, model, s_values)
            equiv_matrices[model] = build_equiv(curves, n_edges)
        
        # 边特征
        features = [edge_features(edges, N, i) for i in range(n_edges)]
        
        all_data.append({
            'graph': g_idx,
            'edges': edges,
            'n_edges': n_edges,
            'equiv_matrices': {m: equiv_matrices[m] for m in models},
            'features': features
        })
        
        if (g_idx+1) % 30 == 0:
            print(f"  进度：{g_idx+1}/{len(all_graphs)}")
    
    # 第一阶段：检查单特征是否在所有图中匹配
    print("\n===== 第一阶段：单特征匹配 =====")
    single_match = {}
    for key in FEATURE_KEYS:
        n_match = 0
        for data in all_data:
            n_edges = data['n_edges']
            features = data['features']
            # 用海森堡模型作为基准
            equiv = data['equiv_matrices']['heisenberg']
            feat_equiv = np.zeros((n_edges, n_edges), dtype=bool)
            for i in range(n_edges):
                for j in range(i+1, n_edges):
                    same = feature_equal(features[i], features[j], key)
                    feat_equiv[i, j] = feat_equiv[j, i] = same
            for i in range(n_edges):
                feat_equiv[i, i] = True
            if np.array_equal(equiv, feat_equiv):
                n_match += 1
        single_match[key] = n_match
        print(f"  {key}: {n_match}/{len(all_data)}")
    
    # 第二阶段：穷举特征AND组合
    print("\n===== 第二阶段：特征AND组合穷举 =====")
    best_combo = None
    best_match_count = -1
    perfect_combos = []
    
    # 只考虑单特征中表现较好的前6个
    top_keys = sorted(FEATURE_KEYS, key=lambda k: -single_match[k])[:6]
    print(f"  候选特征（前6）：{top_keys}")
    
    for r in range(1, len(top_keys) + 1):
        for combo in itertools.combinations(top_keys, r):
            n_match = 0
            for data in all_data:
                n_edges = data['n_edges']
                features = data['features']
                equiv = data['equiv_matrices']['heisenberg']
                feat_equiv = np.zeros((n_edges, n_edges), dtype=bool)
                for i in range(n_edges):
                    for j in range(i+1, n_edges):
                        same = all(feature_equal(features[i], features[j], k) for k in combo)
                        feat_equiv[i, j] = feat_equiv[j, i] = same
                for i in range(n_edges):
                    feat_equiv[i, i] = True
                if np.array_equal(equiv, feat_equiv):
                    n_match += 1
            if n_match > best_match_count:
                best_match_count = n_match
                best_combo = combo
            if n_match == len(all_data):
                perfect_combos.append(combo)
    
    print(f"\n  最佳组合：{best_combo}")
    print(f"  最佳匹配图数：{best_match_count}/{len(all_data)}")
    if perfect_combos:
        print(f"  完美匹配组合数：{len(perfect_combos)}")
        for c in perfect_combos[:5]:
            print(f"    {c}")
    
    # 第三阶段：检查模型无关性
    print("\n===== 第三阶段：模型无关性 =====")
    model_independent = 0
    for data in all_data:
        base = data['equiv_matrices']['heisenberg']
        if all(np.array_equal(base, data['equiv_matrices'][m]) for m in models[1:]):
            model_independent += 1
    print(f"  三模型下等价类相同的图：{model_independent}/{len(all_data)}")
    
    output = {
        'total_graphs': len(all_data),
        'models': models,
        'feature_keys': FEATURE_KEYS,
        'single_match': single_match,
        'best_combo': list(best_combo) if best_combo else None,
        'best_match_count': best_match_count,
        'perfect_combos': [list(c) for c in perfect_combos],
        'model_independent': model_independent,
        'note': '大预言：关系位置不变量存在性检验。'
    }
    with open('jingmai_big_prediction_relation_invariant.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_big_prediction_relation_invariant.json")

if __name__ == "__main__":
    main()