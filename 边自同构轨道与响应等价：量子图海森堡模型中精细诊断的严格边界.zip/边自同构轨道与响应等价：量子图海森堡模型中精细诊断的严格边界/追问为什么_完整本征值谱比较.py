"""
追问为什么_完整本征值谱比较.py

目标：
    继续追问：32对异轨道同分布边对，其完整本征值谱是否也相同？
    对每对边，在多个Δ点：
        1. 扫描ei和ej，得到完整本征值谱
        2. 比较全谱是否逐点相同
    若全谱相同，则同分布的根源是谱等价，
    而非任何图结构量；若全谱不同，则同分布更加隐秘。
    并排呈现标准物理视角（谱差异）与晶脉视角（同分布边对）。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。
    使用精确对角化，完整本征值。

理论精髓：
    - 数据自己说话。
    - 追问：同分布是否来自谱等价？

输出：
    jingmai_why_full_spectrum.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10
DELTA_VALUES = [-1.5, -1.0, -0.5, -0.25, 0.0]

def build_hamiltonian_and_basis(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def compute_full_spectrum(N, edges, J_vals):
    H, basis = build_hamiltonian_and_basis(N, edges, J_vals)
    evals = np.linalg.eigvalsh(H)
    return np.sort(evals)

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def get_edge_orbits_from_edges(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    automorphisms = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in automorphisms:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return orbits, edge_to_orbit

def main():
    print("=== 追问为什么_完整本征值谱比较 ===\n")
    
    all_graphs = get_all_N6_graphs()
    
    # 从之前结果读取32对同分布边对
    with open('jingmai_why_distribution_diversity.json', 'r', encoding='utf-8') as f:
        diversity_data = json.load(f)
    
    targets = diversity_data['results']
    print(f"同分布边对数：{len(targets)}")
    
    results = []
    n_spectrum_same = 0
    n_spectrum_diff = 0
    
    for t in targets:
        g_idx = t['graph']
        edges = all_graphs[g_idx]
        n_edges = len(edges)
        ei = t['edge_i']
        ej = t['edge_j']
        
        print(f"\n图{g_idx} 边{ei}(轨道{t['orbit_i']}) vs 边{ej}(轨道{t['orbit_j']})")
        
        for s_val in DELTA_VALUES:
            J_i = np.ones(n_edges); J_i[ei] = s_val
            J_j = np.ones(n_edges); J_j[ej] = s_val
            spectrum_i = compute_full_spectrum(N, edges, J_i)
            spectrum_j = compute_full_spectrum(N, edges, J_j)
            diff = np.max(np.abs(spectrum_i - spectrum_j))
            same = diff < TOL_CURVE
            
            if same:
                n_spectrum_same += 1
            else:
                n_spectrum_diff += 1
            
            print(f"  Δ={s_val:.2f}: 谱最大差异={diff:.6e}, 相同={same}")
            
            results.append({
                'graph': g_idx,
                'edge_i': ei,
                'edge_j': ej,
                's_val': s_val,
                'spectrum_diff': float(diff),
                'spectrum_same': same
            })
    
    n_total = len(results)
    print(f"\n===== 统计 =====")
    print(f"总检查点：{n_total}")
    print(f"谱相同：{n_spectrum_same}")
    print(f"谱不同：{n_spectrum_diff}")
    
    output = {
        'results': results,
        'n_spectrum_same': n_spectrum_same,
        'n_spectrum_diff': n_spectrum_diff,
        'note': '追问：同分布边对是否也谱等价？'
    }
    with open('jingmai_why_full_spectrum.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_full_spectrum.json")

if __name__ == "__main__":
    main()