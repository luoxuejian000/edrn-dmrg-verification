"""
追问为什么_高阶分布泛函.py

目标：
    追问：异轨道边对的E(s)标准差相同，但排序分布不同。
    进一步追问：是否存在高阶分布泛函能区分这些边对？
    对每个“异轨道同E但排序分布不同”的检查点，计算并比较：
        1. 标准差 std
        2. 极差 range
        3. 熵 entropy
        4. 偏度 skewness
        5. 峰度 kurtosis
        6. 最大绝对值 max_abs
    统计哪些泛函在两边相同，哪些不同。
    并排呈现标准物理视角（轨道编号）与晶脉视角（各泛函对比）。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。
    基态简并使用对称性约化密度矩阵。

理论精髓：
    - 数据自己说话。
    - 追问过程：标准差丢失了什么？更高阶泛函能否恢复区分？

输出：
    jingmai_why_higher_order_functionals.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
S_POINTS = 21
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10
DELTA_VALUES = [-1.5, -1.0, -0.5, -0.25, 0.0]

def build_hamiltonian_and_basis(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def compute_probs_with_degen(N, edges, J_vals):
    H, basis = build_hamiltonian_and_basis(N, edges, J_vals)
    evals, evecs = np.linalg.eigh(H)
    E0 = evals[0]
    degen_indices = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
    degen_dim = len(degen_indices)
    probs = np.zeros(len(basis))
    for idx in degen_indices:
        probs += np.abs(evecs[:, idx])**2
    probs /= degen_dim
    return probs, basis

def compute_corrs_from_probs(N, edges, basis, probs):
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return np.array(corrs)

def compute_functionals(corrs):
    corrs = np.array(corrs)
    std = float(np.std(corrs))
    rng = float(np.max(corrs) - np.min(corrs))
    mean = np.mean(corrs)
    std_ = np.std(corrs)
    if std_ < 1e-12:
        skew = 0.0
        kurt = 0.0
    else:
        skew = float(np.mean(((corrs - mean)/std_)**3))
        kurt = float(np.mean(((corrs - mean)/std_)**4))
    abs_corrs = np.abs(corrs)
    total = np.sum(abs_corrs)
    if total < 1e-14:
        ent = 0.0
    else:
        probs = abs_corrs / total
        probs = probs[probs > 1e-14]
        ent = float(-np.sum(probs * np.log(probs)))
    max_abs = float(np.max(np.abs(corrs)))
    return {
        'std': std,
        'range': rng,
        'entropy': ent,
        'skewness': skew,
        'kurtosis': kurt,
        'max_abs': max_abs
    }

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def get_edge_orbits_from_edges(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    automorphisms = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in automorphisms:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return orbits, edge_to_orbit

def main():
    print("=== 追问为什么_高阶分布泛函 ===\n")
    
    all_graphs = get_all_N6_graphs()
    s_values = np.linspace(-1.5, 0.0, S_POINTS)
    
    # 找出“异轨道同E但排序分布不同”的检查点
    targets = []
    for g_idx, edges in enumerate(all_graphs):
        n_edges = len(edges)
        orbits, edge_to_orbit = get_edge_orbits_from_edges(edges, N)
        
        # 扫描所有边，计算排序分布
        sorted_curves = []
        for i in range(n_edges):
            sorted_curve = []
            for s in s_values:
                J = np.ones(n_edges); J[i] = s
                probs, basis = compute_probs_with_degen(N, edges, J)
                corrs = compute_corrs_from_probs(N, edges, basis, probs)
                sorted_curve.append(np.sort(corrs))
            sorted_curves.append(sorted_curve)
        
        for i in range(n_edges):
            for j in range(i+1, n_edges):
                if edge_to_orbit[i] == edge_to_orbit[j]:
                    continue
                # 检查所有Δ点：E相同但排序分布不同
                for si, s in enumerate(s_values):
                    corrs_i = sorted_curves[i][si]
                    corrs_j = sorted_curves[j][si]
                    E_i = float(np.std(corrs_i))
                    E_j = float(np.std(corrs_j))
                    if abs(E_i - E_j) < TOL_CURVE and not np.allclose(corrs_i, corrs_j, atol=TOL_CURVE):
                        targets.append({
                            'graph': g_idx,
                            'edge_i': i,
                            'edge_j': j,
                            'orbit_i': edge_to_orbit[i],
                            'orbit_j': edge_to_orbit[j],
                            's_val': s
                        })
    
    print(f"异轨道同E但排序分布不同的检查点数量：{len(targets)}")
    
    # 对每个目标，计算高阶泛函并比较
    functional_names = ['std', 'range', 'entropy', 'skewness', 'kurtosis', 'max_abs']
    # 统计每个泛函相同/不同的次数
    same_counts = {name: 0 for name in functional_names}
    diff_counts = {name: 0 for name in functional_names}
    results = []
    
    for t in targets:
        g_idx = t['graph']
        edges = all_graphs[g_idx]
        n_edges = len(edges)
        s_val = t['s_val']
        ei = t['edge_i']
        ej = t['edge_j']
        
        J_i = np.ones(n_edges); J_i[ei] = s_val
        J_j = np.ones(n_edges); J_j[ej] = s_val
        probs_i, basis_i = compute_probs_with_degen(N, edges, J_i)
        corrs_i = compute_corrs_from_probs(N, edges, basis_i, probs_i)
        probs_j, basis_j = compute_probs_with_degen(N, edges, J_j)
        corrs_j = compute_corrs_from_probs(N, edges, basis_j, probs_j)
        
        func_i = compute_functionals(corrs_i)
        func_j = compute_functionals(corrs_j)
        
        record = {
            'graph': g_idx,
            'edge_i': ei,
            'edge_j': ej,
            'orbit_i': t['orbit_i'],
            'orbit_j': t['orbit_j'],
            's_val': s_val
        }
        for name in functional_names:
            same = abs(func_i[name] - func_j[name]) < TOL_CURVE
            if same:
                same_counts[name] += 1
            else:
                diff_counts[name] += 1
            record[f'{name}_i'] = func_i[name]
            record[f'{name}_j'] = func_j[name]
            record[f'{name}_same'] = same
        results.append(record)
    
    # 打印统计
    print("\n===== 各泛函区分能力 =====")
    print(f"{'泛函':<12} {'相同':<8} {'不同':<8} {'区分比例':<10}")
    print("-" * 40)
    for name in functional_names:
        total = same_counts[name] + diff_counts[name]
        if total > 0:
            ratio = diff_counts[name] / total
        else:
            ratio = 0.0
        print(f"{name:<12} {same_counts[name]:<8} {diff_counts[name]:<8} {ratio:<10.4f}")
    
    # 输出几个例子
    print("\n===== 前5个检查点详情 =====")
    for r in results[:5]:
        print(f"图{r['graph']} 边{r['edge_i']}(轨道{r['orbit_i']}) vs 边{r['edge_j']}(轨道{r['orbit_j']}), Δ={r['s_val']:.2f}")
        for name in functional_names:
            print(f"  {name}: {r[f'{name}_i']:.8f} vs {r[f'{name}_j']:.8f}, 相同={r[f'{name}_same']}")
    
    output = {
        'target_count': len(targets),
        'same_counts': same_counts,
        'diff_counts': diff_counts,
        'results': results,
        'note': '追问：高阶分布泛函能否区分异轨道同E的边对？'
    }
    with open('jingmai_why_higher_order_functionals.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_higher_order_functionals.json")

if __name__ == "__main__":
    main()