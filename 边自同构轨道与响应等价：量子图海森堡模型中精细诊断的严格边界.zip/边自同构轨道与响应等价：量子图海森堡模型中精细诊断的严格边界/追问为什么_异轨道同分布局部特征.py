"""
追问为什么_异轨道同分布局部特征.py

目标：
    深挖32对"异轨道同分布"边对，追问它们的共同结构。
    对每对边，计算：
        1. 两个端点的邻居度分布（距离-1环境）
        2. 距离-2子图的度分布
        3. 删除边后图的自同构群大小
        4. 两个端点在图中的位置类型（是否在对称位置）
        5. 边对是否共享某种"局部同构"关系
    并排展示标准物理（局部拓扑）与晶脉视角（排序分布同）。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。
    基态简并使用对称性约化密度矩阵。

输出：
    jingmai_why_diff_orbit_same_local.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
S_POINTS = 11
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10

def build_hamiltonian_and_basis(N, edges, J_vals):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    dim = len(basis)
    H = np.zeros((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def compute_probs_with_degen(N, edges, J_vals):
    H, basis = build_hamiltonian_and_basis(N, edges, J_vals)
    evals, evecs = np.linalg.eigh(H)
    E0 = evals[0]
    degen_indices = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
    degen_dim = len(degen_indices)
    probs = np.zeros(len(basis))
    for idx in degen_indices:
        probs += np.abs(evecs[:, idx])**2
    probs /= degen_dim
    return probs, basis

def compute_corrs_from_probs(N, edges, basis, probs):
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return np.array(corrs)

def get_sorted_correlation_curve(N, edges, defect_idx, s_values):
    n_edges = len(edges)
    curve = []
    for s in s_values:
        J = np.ones(n_edges)
        J[defect_idx] = s
        probs, basis = compute_probs_with_degen(N, edges, J)
        corrs = compute_corrs_from_probs(N, edges, basis, probs)
        curve.append(np.sort(corrs))
    return curve

def curves_equal(curve1, curve2, tol=TOL_CURVE):
    if len(curve1) != len(curve2):
        return False
    for c1, c2 in zip(curve1, curve2):
        if not np.allclose(c1, c2, atol=tol):
            return False
    return True

def get_edge_orbits(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    automorphisms = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in automorphisms:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return edge_to_orbit

def get_all_N6_graphs():
    graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            graphs.append(edges)
    return graphs

def local_features(G, edge):
    """计算边的局部拓扑特征"""
    u, v = edge
    # 端点邻居度分布
    nbr_u = sorted([G.degree(x) for x in G.neighbors(u)])
    nbr_v = sorted([G.degree(x) for x in G.neighbors(v)])
    # 距离-2子图的度分布
    def dist2_deg(u_node):
        nodes = set()
        for x in G.neighbors(u_node):
            for y in G.neighbors(x):
                if y != u_node:
                    nodes.add(y)
        return sorted([G.degree(y) for y in nodes])
    dist2_u = dist2_deg(u)
    dist2_v = dist2_deg(v)
    return {
        'nbr_deg_u': nbr_u,
        'nbr_deg_v': nbr_v,
        'dist2_deg_u': dist2_u,
        'dist2_deg_v': dist2_v
    }

def main():
    print("=== 追问为什么_异轨道同分布局部特征 ===\n")
    
    all_graphs = get_all_N6_graphs()
    s_values = np.linspace(-1.5, 0.0, S_POINTS)
    
    # 找出所有异轨道同分布边对
    ce_pairs = []
    for g_idx, edges in enumerate(all_graphs):
        n_edges = len(edges)
        edge_to_orbit = get_edge_orbits(edges, N)
        
        sorted_curves = []
        for i in range(n_edges):
            curve = get_sorted_correlation_curve(N, edges, i, s_values)
            sorted_curves.append(curve)
        
        for i in range(n_edges):
            for j in range(i+1, n_edges):
                if edge_to_orbit[i] != edge_to_orbit[j]:
                    if curves_equal(sorted_curves[i], sorted_curves[j]):
                        ce_pairs.append({
                            'graph': g_idx,
                            'edge_i': i,
                            'edge_j': j,
                            'orbit_i': edge_to_orbit[i],
                            'orbit_j': edge_to_orbit[j]
                        })
    
    print(f"异轨道同分布边对总数：{len(ce_pairs)}")
    
    # 对每对边，计算局部特征
    results = []
    for ce in ce_pairs:
        g_idx = ce['graph']
        edges = all_graphs[g_idx]
        G = nx.Graph()
        G.add_nodes_from(range(N))
        G.add_edges_from(edges)
        
        feat_i = local_features(G, edges[ce['edge_i']])
        feat_j = local_features(G, edges[ce['edge_j']])
        
        # 检查局部特征是否匹配
        nbr_u_same = feat_i['nbr_deg_u'] == feat_j['nbr_deg_u']
        nbr_v_same = feat_i['nbr_deg_v'] == feat_j['nbr_deg_v']
        dist2_u_same = feat_i['dist2_deg_u'] == feat_j['dist2_deg_u']
        dist2_v_same = feat_i['dist2_deg_v'] == feat_j['dist2_deg_v']
        all_same = nbr_u_same and nbr_v_same and dist2_u_same and dist2_v_same
        
        results.append({
            'graph': g_idx,
            'edge_i': ce['edge_i'],
            'edge_j': ce['edge_j'],
            'orbit_i': ce['orbit_i'],
            'orbit_j': ce['orbit_j'],
            'nbr_u_same': nbr_u_same,
            'nbr_v_same': nbr_v_same,
            'dist2_u_same': dist2_u_same,
            'dist2_v_same': dist2_v_same,
            'all_local_same': all_same,
            'feat_i': feat_i,
            'feat_j': feat_j
        })
    
    # 统计
    n_all_local_same = sum(1 for r in results if r['all_local_same'])
    n_nbr_u_same = sum(1 for r in results if r['nbr_u_same'])
    n_nbr_v_same = sum(1 for r in results if r['nbr_v_same'])
    n_dist2_u_same = sum(1 for r in results if r['dist2_u_same'])
    n_dist2_v_same = sum(1 for r in results if r['dist2_v_same'])
    
    print(f"\n===== 局部特征匹配统计 =====")
    print(f"端点u邻居度分布相同：{n_nbr_u_same}/{len(results)}")
    print(f"端点v邻居度分布相同：{n_nbr_v_same}/{len(results)}")
    print(f"端点u距离-2度分布相同：{n_dist2_u_same}/{len(results)}")
    print(f"端点v距离-2度分布相同：{n_dist2_v_same}/{len(results)}")
    print(f"所有局部特征都相同：{n_all_local_same}/{len(results)}")
    
    # 输出前10个反例详情
    print(f"\n===== 前10个反例详情 =====")
    for r in results[:10]:
        print(f"\n图{r['graph']} 边{r['edge_i']}(轨道{r['orbit_i']}) vs 边{r['edge_j']}(轨道{r['orbit_j']})")
        print(f"  端点u邻居度_i: {r['feat_i']['nbr_deg_u']}, _j: {r['feat_j']['nbr_deg_u']}, 同={r['nbr_u_same']}")
        print(f"  端点v邻居度_i: {r['feat_i']['nbr_deg_v']}, _j: {r['feat_j']['nbr_deg_v']}, 同={r['nbr_v_same']}")
        print(f"  距离-2度_i: {r['feat_i']['dist2_deg_u']}, _j: {r['feat_j']['dist2_deg_u']}, 同={r['dist2_u_same']}")
    
    # 保存
    output = {
        'n_ce_pairs': len(ce_pairs),
        'n_all_local_same': n_all_local_same,
        'n_nbr_u_same': n_nbr_u_same,
        'n_nbr_v_same': n_nbr_v_same,
        'n_dist2_u_same': n_dist2_u_same,
        'n_dist2_v_same': n_dist2_v_same,
        'results': results,
        'note': '深挖异轨道同分布边对的局部特征。'
    }
    with open('jingmai_why_diff_orbit_same_local.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_diff_orbit_same_local.json")

if __name__ == "__main__":
    main()