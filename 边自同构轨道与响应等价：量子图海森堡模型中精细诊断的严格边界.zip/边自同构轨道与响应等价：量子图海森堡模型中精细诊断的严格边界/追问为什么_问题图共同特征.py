"""
追问为什么_问题图共同特征.py

目标：
    追问：那些让轨道决定论失败、或让等价类依赖于模型的图，有什么共同结构？
    对N=6全部112个连通图，标记每个图属于以下哪一类：
        - 正常图：轨道等价类 = 响应等价类，且三模型下等价类相同
        - 轨道失败图：轨道等价类 ≠ 响应等价类
        - 模型依赖图：三模型下响应等价类不同
        - 双重失败图：既轨道失败又模型依赖
    对每类图，计算并对比以下图结构特征：
        1. 自同构群阶
        2. 边轨道数量
        3. 顶点轨道数量
        4. 轨道大小分布
        5. 最大基态简并度（扫描中）
        6. 是否顶点传递
        7. 是否边传递
        8. 图直径、平均度
        9. 边连通度、顶点连通度
    并排展示标准物理视角（图结构）与晶脉视角（分类）。

方法：
    只查同与不同，不拟合，不预设。
    不筛除任何数据。
    基态简并使用对称性约化密度矩阵。

输出：
    jingmai_why_problem_graphs_common.json
"""

import numpy as np
import networkx as nx
import itertools
import json
import warnings
warnings.filterwarnings('ignore')

N = 6
S_POINTS = 11
TOL_DEGEN = 1e-8
TOL_CURVE = 1e-10

def build_basis(N):
    N_up = N // 2
    basis_tuples = list(itertools.combinations(range(N), N_up))
    basis = []
    for st in basis_tuples:
        state = 0
        for b in st:
            state |= (1 << b)
        basis.append(state)
    state_to_idx = {st: i for i, st in enumerate(basis)}
    return basis, state_to_idx

def add_heisenberg_term(H, basis, state_to_idx, edges, J_vals):
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J

def build_heisenberg(N, edges, J_vals):
    basis, state_to_idx = build_basis(N)
    H = np.zeros((len(basis), len(basis)), dtype=float)
    add_heisenberg_term(H, basis, state_to_idx, edges, J_vals)
    return H, basis

def build_xxz(N, edges, J_vals, delta_zz=1.5):
    basis, state_to_idx = build_basis(N)
    H = np.zeros((len(basis), len(basis)), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            H[idx, idx] += J * delta_zz * si * sj
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            if bit_i != bit_j:
                flipped = state ^ (1 << i) ^ (1 << j)
                jdx = state_to_idx.get(flipped)
                if jdx is not None:
                    H[idx, jdx] += 2.0 * J
    return H, basis

def build_nnn(N, edges, J_vals, strength=0.2):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    nnn_edges = []
    for i in range(N):
        for j in range(i+1, N):
            if not G.has_edge(i, j) and nx.has_path(G, i, j):
                if nx.shortest_path_length(G, i, j) == 2:
                    nnn_edges.append((i, j))
    nnn_edges.sort()
    basis, state_to_idx = build_basis(N)
    H = np.zeros((len(basis), len(basis)), dtype=float)
    add_heisenberg_term(H, basis, state_to_idx, edges, J_vals)
    add_heisenberg_term(H, basis, state_to_idx, nnn_edges, [strength]*len(nnn_edges))
    return H, basis

def compute_probs(N, edges, J_vals, model):
    if model == 'heisenberg':
        H, basis = build_heisenberg(N, edges, J_vals)
    elif model == 'xxz':
        H, basis = build_xxz(N, edges, J_vals)
    elif model == 'nnn':
        H, basis = build_nnn(N, edges, J_vals)
    evals, evecs = np.linalg.eigh(H)
    E0 = evals[0]
    degen = [k for k in range(len(evals)) if abs(evals[k]-E0) < TOL_DEGEN]
    probs = np.zeros(len(basis))
    for idx in degen:
        probs += np.abs(evecs[:, idx])**2
    probs /= len(degen)
    return probs, basis, len(degen)

def compute_corrs(N, edges, basis, probs):
    corrs = []
    for (i, j) in edges:
        diag_vals = np.zeros(len(basis))
        for idx, state in enumerate(basis):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            si = 1.0 if bit_i else -1.0
            sj = 1.0 if bit_j else -1.0
            diag_vals[idx] = si * sj
        corr = np.sum(probs * diag_vals)
        corrs.append(corr)
    return np.array(corrs)

def get_sorted_curves(N, edges, model, s_values):
    n_edges = len(edges)
    curves = []
    max_degen = 0
    for i in range(n_edges):
        curve = []
        for s in s_values:
            J = np.ones(n_edges)
            J[i] = s
            probs, basis, degen = compute_probs(N, edges, J, model)
            if degen > max_degen:
                max_degen = degen
            corrs = compute_corrs(N, edges, basis, probs)
            curve.append(np.sort(corrs))
        curves.append(curve)
    return curves, max_degen

def build_equiv(sorted_curves, n_edges):
    equiv = np.zeros((n_edges, n_edges), dtype=bool)
    for i in range(n_edges):
        for j in range(i+1, n_edges):
            same = all(np.allclose(c1, c2, atol=TOL_CURVE)
                       for c1, c2 in zip(sorted_curves[i], sorted_curves[j]))
            equiv[i, j] = equiv[j, i] = same
    for i in range(n_edges):
        equiv[i, i] = True
    return equiv

def get_edge_orbits(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    edge_to_idx = {tuple(sorted(e)): i for i, e in enumerate(edges)}
    GM = iso.GraphMatcher(G, G)
    autos = list(GM.isomorphisms_iter())
    remaining = set(edge_to_idx.keys())
    orbits = []
    while remaining:
        e = remaining.pop()
        orbit = {e}
        for auto in autos:
            mapped = tuple(sorted((auto[e[0]], auto[e[1]])))
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append([edge_to_idx[x] for x in orbit])
    edge_to_orbit = {}
    for oi, orbit in enumerate(orbits):
        for ei in orbit:
            edge_to_orbit[ei] = oi
    return edge_to_orbit, len(autos), orbits

def get_vertex_orbits(G):
    import networkx.algorithms.isomorphism as iso
    GM = iso.GraphMatcher(G, G)
    autos = list(GM.isomorphisms_iter())
    remaining = set(G.nodes())
    orbits = []
    while remaining:
        v = remaining.pop()
        orbit = {v}
        for auto in autos:
            mapped = auto[v]
            if mapped in remaining:
                orbit.add(mapped)
                remaining.remove(mapped)
        orbits.append(orbit)
    return orbits

def graph_features(edges, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    edge_to_orbit, n_autos, edge_orbits = get_edge_orbits(edges, N)
    vertex_orbits = get_vertex_orbits(G)
    orbit_sizes = [len(o) for o in edge_orbits]
    vertex_orbit_sizes = [len(o) for o in vertex_orbits]
    # 是否边传递
    edge_transitive = len(edge_orbits) == 1
    # 是否顶点传递
    vertex_transitive = len(vertex_orbits) == 1
    # 直径
    diameter = nx.diameter(G)
    # 平均度
    avg_deg = 2 * len(edges) / N
    # 边连通度
    try:
        edge_conn = nx.edge_connectivity(G)
    except:
        edge_conn = 0
    try:
        node_conn = nx.node_connectivity(G)
    except:
        node_conn = 0
    return {
        'n_autos': n_autos,
        'n_edge_orbits': len(edge_orbits),
        'n_vertex_orbits': len(vertex_orbits),
        'orbit_sizes': sorted(orbit_sizes),
        'vertex_orbit_sizes': sorted(vertex_orbit_sizes),
        'max_orbit_size': max(orbit_sizes),
        'edge_transitive': edge_transitive,
        'vertex_transitive': vertex_transitive,
        'diameter': diameter,
        'avg_degree': avg_deg,
        'edge_connectivity': edge_conn,
        'node_connectivity': node_conn
    }

def main():
    print("=== 追问为什么_问题图共同特征 ===\n")
    
    all_graphs = []
    for G_atlas in nx.graph_atlas_g():
        n = G_atlas.number_of_nodes()
        if n == N and nx.is_connected(G_atlas) and G_atlas.number_of_edges() > 0:
            edges = [tuple(sorted(e)) for e in G_atlas.edges()]
            edges.sort()
            all_graphs.append(edges)
    
    s_values = np.linspace(-1.5, 0.0, S_POINTS)
    models = ['heisenberg', 'xxz', 'nnn']
    
    print(f"总图数：{len(all_graphs)}\n")
    
    classifications = []
    
    for g_idx, edges in enumerate(all_graphs):
        n_edges = len(edges)
        edge_to_orbit, _, _ = get_edge_orbits(edges, N)
        
        # 三种模型下的响应等价矩阵
        equiv_matrices = {}
        max_degen_all = 0
        for model in models:
            curves, max_degen = get_sorted_curves(N, edges, model, s_values)
            equiv_matrices[model] = build_equiv(curves, n_edges)
            if max_degen > max_degen_all:
                max_degen_all = max_degen
        
        # 轨道等价矩阵
        orbit_equiv = np.zeros((n_edges, n_edges), dtype=bool)
        for i in range(n_edges):
            for j in range(i+1, n_edges):
                same = edge_to_orbit[i] == edge_to_orbit[j]
                orbit_equiv[i, j] = orbit_equiv[j, i] = same
        for i in range(n_edges):
            orbit_equiv[i, i] = True
        
        # 分类
        base = equiv_matrices['heisenberg']
        orbit_match = np.array_equal(base, orbit_equiv)
        model_independent = all(np.array_equal(base, equiv_matrices[m]) for m in models[1:])
        
        if orbit_match and model_independent:
            category = 'normal'
        elif not orbit_match and model_independent:
            category = 'orbit_fail'
        elif orbit_match and not model_independent:
            category = 'model_dependent'
        else:
            category = 'double_fail'
        
        feats = graph_features(edges, N)
        feats['max_degen'] = max_degen_all
        
        classifications.append({
            'graph': g_idx,
            'category': category,
            'features': feats
        })
        
        if (g_idx+1) % 30 == 0:
            print(f"  进度：{g_idx+1}/{len(all_graphs)}")
    
    # 按类别分组统计
    print("\n===== 分类统计 =====")
    categories = ['normal', 'orbit_fail', 'model_dependent', 'double_fail']
    category_lists = {c: [x for x in classifications if x['category'] == c] for c in categories}
    
    for c in categories:
        print(f"  {c}: {len(category_lists[c])} 个图")
    
    # 对每类，计算特征的平均值和范围
    print("\n===== 各类图特征对比 =====")
    feature_keys = ['n_autos', 'n_edge_orbits', 'n_vertex_orbits', 'max_orbit_size',
                    'edge_transitive', 'vertex_transitive', 'diameter', 'avg_degree',
                    'edge_connectivity', 'node_connectivity', 'max_degen']
    
    for key in feature_keys:
        print(f"\n特征：{key}")
        for c in categories:
            vals = [x['features'][key] for x in category_lists[c]]
            if not vals:
                continue
            if isinstance(vals[0], bool):
                n_true = sum(vals)
                print(f"  {c}: {n_true}/{len(vals)} 为 True")
            elif isinstance(vals[0], (int, float)):
                print(f"  {c}: 平均={np.mean(vals):.4f}, 范围=[{min(vals)}, {max(vals)}]")
    
    # 输出问题图列表
    print("\n===== 问题图列表 =====")
    for c in ['orbit_fail', 'model_dependent', 'double_fail']:
        if category_lists[c]:
            print(f"\n{c}:")
            for x in category_lists[c]:
                print(f"  图{x['graph']}: 边数={len(all_graphs[x['graph']])}, "
                      f"自同构数={x['features']['n_autos']}, "
                      f"轨道数={x['features']['n_edge_orbits']}, "
                      f"max_degen={x['features']['max_degen']}")
    
    output = {
        'total_graphs': len(all_graphs),
        'categories': {c: len(category_lists[c]) for c in categories},
        'classifications': classifications,
        'note': '追问问题图的共同特征。'
    }
    with open('jingmai_why_problem_graphs_common.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print("\n结果已保存至 jingmai_why_problem_graphs_common.json")

if __name__ == "__main__":
    main()