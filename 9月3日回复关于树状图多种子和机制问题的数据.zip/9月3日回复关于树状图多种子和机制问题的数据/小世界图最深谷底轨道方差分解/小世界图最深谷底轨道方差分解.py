"""
小世界图最深谷底轨道方差分解.py

目的：
    找出小世界图（N=10, k=4, p=0.1, seed=42）中深度最大的谷底边，
    在谷底 s_valley 处按自同构轨道分解增强诊断，检查轨道内方差
    是否为零（或接近零）。

实验逻辑：
    - 如果谷底处轨道内方差为零 → 塌缩与谷底可能相关
    - 如果谷底处轨道内方差不为零且不显著 → 塌缩与谷底无关

方法论：
    - 关系本体论：轨道分解揭示关系场中不同层次的方差贡献
    - 矛盾动力论：谷底是矛盾被关系拓扑驯服的位置
    - 实践介入论：轨道划分基于均匀图 s=1 的自同构，这一介入被标注
    - 谐振调谐论：不预设轨道内方差必须在谷底处为零
    - 元反思律：如果谷底处轨道内方差不为零，结论将直接否证机制

输出：
    smallworld_deepest_valley_orbit_decomposition.csv
"""

import numpy as np
import networkx as nx
import itertools
from scipy.sparse import lil_matrix, csr_matrix
from scipy.sparse.linalg import eigsh
import json
import warnings
warnings.filterwarnings('ignore')

# ========== 参数 ==========
N = 10
N_UP = 5  # N//2
S_VALUES = np.linspace(0.0, 3.0, 151)  # 步长 0.02，较密
N_V0 = 3
EPS_DEGEN = 1e-8
N_EIGS = 4  # 小世界图 N=10，扇区维度252，简并度通常小

# ========== 生成小世界图 ==========
def generate_small_world(seed=42):
    G = nx.watts_strogatz_graph(N, 4, 0.1, seed=seed)
    G = nx.relabel_nodes(G, {old: new for new, old in enumerate(G.nodes())})
    return G

# ========== 哈密顿量构建 ==========
def build_hamiltonian_sector(N, edges, J_vals, N_up):
    basis_states = list(itertools.combinations(range(N), N_up))
    state_to_idx = {st: i for i, st in enumerate(basis_states)}
    dim = len(basis_states)
    H = lil_matrix((dim, dim), dtype=float)
    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis_states):
            si = 1 if i in state else -1
            sj = 1 if j in state else -1
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis_states):
            i_up = i in state
            j_up = j in state
            if i_up and not j_up:
                ns = list(state)
                ns.remove(i)
                ns.append(j)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2.0 * J
            elif j_up and not i_up:
                ns = list(state)
                ns.remove(j)
                ns.append(i)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2.0 * J
    return csr_matrix(H), basis_states

def lanczos_sa_multi(H, n_eigs=4, v0_seed=0, maxiter=10000):
    dim = H.shape[0]
    if dim == 0:
        return None, None, False
    rng = np.random.default_rng(v0_seed)
    v0 = rng.standard_normal(dim)
    k = min(n_eigs, dim)
    try:
        evals, evecs = eigsh(H, k=k, which='SA', v0=v0, maxiter=maxiter, tol=1e-9)
        idx = np.argsort(evals)
        return evals[idx], evecs[:, idx], True
    except Exception:
        return None, None, False

# ========== 计算边关联（对称投影平均，用于轨道分解） ==========
def compute_edge_correlations(N, edges, J_vals, degen_sectors, v0_seed=0):
    n_edges = len(edges)
    corr_sum = np.zeros(n_edges)
    n_states = 0

    # 动态 E0_local
    sector_evals = {}
    for N_up in degen_sectors:
        H, basis = build_hamiltonian_sector(N, edges, J_vals, N_up)
        if H.shape[0] == 0:
            continue
        dim = H.shape[0]
        if dim <= 1500:
            evals = np.linalg.eigh(H.toarray())[0]
            sector_evals[N_up] = evals
        else:
            evals, evecs, ok = lanczos_sa_multi(H, n_eigs=N_EIGS, v0_seed=v0_seed)
            if ok:
                sector_evals[N_up] = evals
    if not sector_evals:
        return None

    E0_local = min(evals[0] for evals in sector_evals.values())

    for N_up, evals in sector_evals.items():
        H, basis = build_hamiltonian_sector(N, edges, J_vals, N_up)
        if H.shape[0] == 0:
            continue
        dim = H.shape[0]
        if dim <= 1500:
            _, evecs = np.linalg.eigh(H.toarray())
            for idx, E in enumerate(evals):
                if abs(E - E0_local) < EPS_DEGEN:
                    psi = evecs[:, idx]
                    n_states += 1
                    for e_idx, (i, j) in enumerate(edges):
                        diag = np.array([(1 if i in st else -1)*(1 if j in st else -1) for st in basis])
                        corr_sum[e_idx] += np.sum(np.abs(psi)**2 * diag)
        else:
            _, evecs, ok = lanczos_sa_multi(H, n_eigs=N_EIGS, v0_seed=v0_seed)
            if not ok:
                continue
            for idx in range(len(evals)):
                if abs(evals[idx] - E0_local) < EPS_DEGEN:
                    psi = evecs[:, idx]
                    n_states += 1
                    for e_idx, (i, j) in enumerate(edges):
                        diag = np.array([(1 if i in st else -1)*(1 if j in st else -1) for st in basis])
                        corr_sum[e_idx] += np.sum(np.abs(psi)**2 * diag)

    if n_states == 0:
        return None
    return corr_sum / n_states

# ========== 计算自同构边轨道 ==========
def compute_edge_orbits(edges):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edges)
    import networkx.algorithms.isomorphism as iso
    GM = iso.GraphMatcher(G, G)
    automorphisms = list(GM.isomorphisms_iter())
    remaining = set(edges)
    orbits = []
    while remaining:
        edge = remaining.pop()
        orbit = [edge]
        for auto in automorphisms:
            mapped = tuple(sorted((auto[edge[0]], auto[edge[1]])))
            if mapped in remaining:
                orbit.append(mapped)
                remaining.remove(mapped)
        orbits.append(sorted(orbit))
    return orbits

# ========== 分解方差 ==========
def decompose_variance(edge_corrs, edge_indices, orbits):
    total_var = np.var(edge_corrs)
    total_mean = np.mean(edge_corrs)
    within_sum = 0.0
    between_sum = 0.0
    for orbit in orbits:
        indices = [edge_indices[e] for e in orbit]
        if len(indices) == 0:
            continue
        orbit_corrs = edge_corrs[indices]
        orbit_mean = np.mean(orbit_corrs)
        within_sum += np.sum((orbit_corrs - orbit_mean)**2)
        between_sum += len(indices) * (orbit_mean - total_mean)**2
    n_edges = len(edge_corrs)
    within_var = within_sum / n_edges
    between_var = between_sum / n_edges
    return {
        'total_var': float(total_var),
        'within_var': float(within_var),
        'between_var': float(between_var),
        'within_ratio': float(within_var/total_var) if total_var > 1e-20 else 0.0
    }

# ========== 主程序 ==========
def main():
    print("=== 小世界图最深谷底轨道方差分解 ===")
    print(f"N={N}, k=4, p=0.1, seed=42")

    G = generate_small_world(seed=42)
    edges = [tuple(sorted(e)) for e in G.edges()]
    edge_indices = {e: i for i, e in enumerate(edges)}
    print(f"边数: {len(edges)}")

    # 预扫描确定简并扇区
    J_vals_probe = np.ones(len(edges))
    sector_energies = {}
    for N_up in range(N+1):
        H, basis = build_hamiltonian_sector(N, edges, J_vals_probe, N_up)
        if H.shape[0] == 0:
            continue
        dim = H.shape[0]
        if dim <= 1500:
            evals = np.linalg.eigh(H.toarray())[0]
            E0 = evals[0]
        else:
            evals, evecs, ok = lanczos_sa_multi(H, n_eigs=1, v0_seed=0)
            if not ok:
                sector_energies[N_up] = np.inf
                continue
            E0 = evals[0]
        sector_energies[N_up] = E0
    min_E = min(sector_energies.values())
    degen_sectors = [nup for nup, E in sector_energies.items() if abs(E-min_E) < EPS_DEGEN]
    print(f"简并扇区: {degen_sectors}")

    # 计算轨道
    orbits = compute_edge_orbits(edges)
    print(f"边轨道数: {len(orbits)}")
    for i, o in enumerate(orbits):
        print(f"  轨道{i} (大小{len(o)}): {o}")

    # 扫描所有边找最深谷（标准视角即可，单态）
    print("\n扫描所有边找最深谷...")
    N_up_standard = N // 2
    edge_depths = []
    for edge_idx, edge in enumerate(edges):
        J_vals = np.ones(len(edges))
        fine_curve = np.full(len(S_VALUES), np.nan)
        for si, s in enumerate(S_VALUES):
            J_vals[edge_idx] = s
            H, basis = build_hamiltonian_sector(N, edges, J_vals, N_up_standard)
            evals, evecs, ok = lanczos_sa_multi(H, n_eigs=1, v0_seed=0)
            if ok:
                psi = evecs[:, 0]
                corrs = []
                for (i, j) in edges:
                    diag = np.array([(1 if i in st else -1)*(1 if j in st else -1) for st in basis])
                    corrs.append(np.sum(np.abs(psi)**2 * diag))
                fine_curve[si] = np.std(np.array(corrs))
            J_vals[edge_idx] = 1.0
        # 找谷底
        valid = np.where(~np.isnan(fine_curve))[0]
        if len(valid) >= 3:
            valleys = []
            for idx in range(1, len(valid)-1):
                curr = valid[idx]
                if fine_curve[curr] < fine_curve[valid[idx-1]] and fine_curve[curr] < fine_curve[valid[idx+1]]:
                    depth = fine_curve[valid[0]] - fine_curve[curr]
                    valleys.append((S_VALUES[curr], depth, curr))
            if valleys:
                deepest = max(valleys, key=lambda x: x[1])
                edge_depths.append({'edge': edge, 'valley_s': deepest[0], 'depth': deepest[1]})
        print(f"  边 {edge}: ", end='')
        if edge_depths and edge_depths[-1]['edge'] == edge:
            print(f"谷 s={edge_depths[-1]['valley_s']:.3f}, 深={edge_depths[-1]['depth']:.6f}")
        else:
            print("无谷")

    if not edge_depths:
        print("未找到任何谷底")
        return

    # 找最深谷
    deepest_overall = max(edge_depths, key=lambda x: x['depth'])
    print(f"\n最深谷: 边 {deepest_overall['edge']}, s={deepest_overall['valley_s']:.4f}, 深度={deepest_overall['depth']:.6f}")

    # 在谷底处做轨道分解
    edge_idx = edges.index(deepest_overall['edge'])
    s_valley = deepest_overall['valley_s']
    J_vals = np.ones(len(edges))
    J_vals[edge_idx] = s_valley
    corrs = compute_edge_correlations(N, edges, J_vals, degen_sectors, v0_seed=0)
    if corrs is None:
        print("无法计算谷底处边关联")
        return
    decomp = decompose_variance(corrs, edge_indices, orbits)
    print(f"\n谷底 s={s_valley:.4f} 处轨道分解：")
    print(f"  总方差: {decomp['total_var']:.8f}")
    print(f"  轨道内方差: {decomp['within_var']:.8f}")
    print(f"  轨道间方差: {decomp['between_var']:.8f}")
    print(f"  轨道内占比: {decomp['within_ratio']:.4f}")

    # 也在 s=1.0 处计算，对比
    J_vals[edge_idx] = 1.0
    corrs_s1 = compute_edge_correlations(N, edges, J_vals, degen_sectors, v0_seed=0)
    if corrs_s1 is not None:
        decomp_s1 = decompose_variance(corrs_s1, edge_indices, orbits)
        print(f"\ns=1.000 处轨道分解：")
        print(f"  总方差: {decomp_s1['total_var']:.8f}")
        print(f"  轨道内方差: {decomp_s1['within_var']:.8f}")
        print(f"  轨道间方差: {decomp_s1['between_var']:.8f}")
        print(f"  轨道内占比: {decomp_s1['within_ratio']:.4f}")

    # 保存
    output = {
        'deepest_valley': {
            'edge': list(deepest_overall['edge']),
            's': float(s_valley),
            'depth': float(deepest_overall['depth'])
        },
        'decomposition_at_valley': decomp,
        'decomposition_at_s1': decomp_s1 if corrs_s1 is not None else None,
        'orbits': [[list(e) for e in o] for o in orbits]
    }
    with open('smallworld_deepest_valley_decomposition.json', 'w') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    print("\n结果已保存至 smallworld_deepest_valley_decomposition.json")

if __name__ == "__main__":
    main()