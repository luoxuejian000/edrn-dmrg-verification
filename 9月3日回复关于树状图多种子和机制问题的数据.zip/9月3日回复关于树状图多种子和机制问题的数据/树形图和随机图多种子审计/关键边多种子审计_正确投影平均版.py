"""
关键边多种子审计_正确投影平均版.py

实验目的：
    对论文关键边执行多种子审计，正确实现对称投影平均。
    每个 s 点独立确定基态能量，筛选简并态，再做等权平均。

核心修正（相比上一版）：
    上一版用固定的全局能量 E0 筛选简并态，但扫描中基态能量随 s 变化，
    导致筛选失效。本脚本对每个 s 点动态确定基态能量。

方法论（晶脉哲学五重公理）：
    - 关系本体论：轨道一致性是关系网络自同构对称性的体现，只有对称投影
      平均才能揭示它；单态计算看到的只是简并流形中的任意方向。
    - 矛盾动力论：矛盾强度扫描驱动关系场演化，谷底是矛盾被驯服的位置。
    - 实践介入论：标准视角（单扇区单态）和理论视角（全流形投影平均）是
      两种不同的介入方式，各自的结果并排呈现，不判断谁对谁错。
    - 谐振调谐论：不预设轨道必须一致；如果投影平均后仍不一致，那是数据
      在说话，不是错误。
    - 元反思律：本脚本修正了上一版固定全局能量的缺陷，修正本身被记录在
      参数中，作为方法演化的审计痕迹。

输出：critical_edges_audit_projected_corrected.json
"""

import numpy as np
import networkx as nx
import itertools
from scipy.sparse import lil_matrix, csr_matrix
from scipy.sparse.linalg import eigsh
import json
import time
import warnings
warnings.filterwarnings('ignore')

# ========== 参数 ==========
N = 15
S_VALUES = np.linspace(0.0, 3.0, 61)  # 步长 0.05
N_V0 = 3
EPS_DEGEN = 1e-8
N_EIGS_PER_SECTOR = 6  # 每个扇区求前6个本征态，足够覆盖简并流形

# ========== 图生成 ==========
def generate_tree():
    tree = nx.random_labeled_tree(15, seed=42)
    tree = nx.relabel_nodes(tree, {old: new for new, old in enumerate(tree.nodes())})
    return tree

def generate_random():
    random_graph = nx.gnm_random_graph(15, 27, seed=42)
    random_graph = nx.relabel_nodes(random_graph, {old: new for new, old in enumerate(random_graph.nodes())})
    return random_graph

# ========== 哈密顿量构建 ==========
def build_hamiltonian_sector(N, edges, J_vals, N_up):
    basis_states = list(itertools.combinations(range(N), N_up))
    state_to_idx = {st: i for i, st in enumerate(basis_states)}
    dim = len(basis_states)
    H = lil_matrix((dim, dim), dtype=float)

    for (i, j), J in zip(edges, J_vals):
        for idx, state in enumerate(basis_states):
            si = 1 if i in state else -1
            sj = 1 if j in state else -1
            H[idx, idx] += J * si * sj
        for idx, state in enumerate(basis_states):
            i_up = i in state
            j_up = j in state
            if i_up and not j_up:
                ns = list(state)
                ns.remove(i)
                ns.append(j)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2.0 * J
            elif j_up and not i_up:
                ns = list(state)
                ns.remove(j)
                ns.append(i)
                jdx = state_to_idx[tuple(sorted(ns))]
                H[idx, jdx] += 2.0 * J
    return csr_matrix(H), basis_states

# ========== Lanczos 求解（SA 模式，求多个本征态） ==========
def lanczos_sa_multi(H, n_eigs=6, v0_seed=0, maxiter=10000):
    dim = H.shape[0]
    if dim == 0:
        return None, None, False
    rng = np.random.default_rng(v0_seed)
    v0 = rng.standard_normal(dim)
    k = min(n_eigs, dim)
    try:
        evals, evecs = eigsh(H, k=k, which='SA', v0=v0, maxiter=maxiter, tol=1e-9)
        idx = np.argsort(evals)
        return evals[idx], evecs[:, idx], True
    except Exception:
        return None, None, False

# ========== 预扫描：确定简并扇区列表 ==========
def prescan_degenerate_sectors(N, edges, J_vals):
    """
    只在 s=1.0 均匀点扫描所有扇区，确定简并扇区列表。
    后续扫描中假设该列表不变（对于当前图结构成立）。
    """
    sector_energies = {}
    for N_up in range(N + 1):
        H, basis = build_hamiltonian_sector(N, edges, J_vals, N_up)
        if H.shape[0] == 0:
            continue
        dim = H.shape[0]
        if dim <= 1500:
            evals = np.linalg.eigh(H.toarray())[0]
            E0 = evals[0]
        else:
            evals, evecs, ok = lanczos_sa_multi(H, n_eigs=1, v0_seed=0)
            if not ok:
                sector_energies[N_up] = np.inf
                continue
            E0 = evals[0]
        sector_energies[N_up] = E0

    if not sector_energies:
        raise RuntimeError("预扫描失败")
    min_E = min(sector_energies.values())
    degenerate_N_ups = [nup for nup, E in sector_energies.items() if abs(E - min_E) < EPS_DEGEN]
    return sorted(degenerate_N_ups), min_E

# ========== 标准视角 fine（单扇区，单态） ==========
def compute_fine_standard(N, edges, J_vals, N_up_standard, v0_seed):
    H, basis = build_hamiltonian_sector(N, edges, J_vals, N_up_standard)
    if H.shape[0] == 0:
        return None
    evals, evecs, ok = lanczos_sa_multi(H, n_eigs=1, v0_seed=v0_seed)
    if not ok:
        return None
    psi = evecs[:, 0]
    corrs = []
    for (i, j) in edges:
        diag_vals = np.array([(1 if i in state else -1) * (1 if j in state else -1) for state in basis])
        corrs.append(np.sum(np.abs(psi)**2 * diag_vals))
    return np.std(np.array(corrs))

# ========== 理论视角 fine（动态基态能量的投影平均） ==========
def compute_fine_theoretical_dynamic(N, edges, J_vals, degen_sectors, v0_seed):
    """
    对每个 s 点：
    1. 在简并扇区内求最低本征值，确定该点的基态能量 E0_local
    2. 筛选能量与 E0_local 差 < EPS_DEGEN 的所有态
    3. 等权平均这些态上的边关联
    """
    n_edges = len(edges)
    corr_sum = np.zeros(n_edges)
    n_states = 0

    # 第一步：确定该 s 点的基态能量 E0_local
    sector_evals = {}
    for N_up in degen_sectors:
        H, basis = build_hamiltonian_sector(N, edges, J_vals, N_up)
        if H.shape[0] == 0:
            continue
        dim = H.shape[0]
        if dim <= 1500:
            evals = np.linalg.eigh(H.toarray())[0]
            sector_evals[N_up] = evals
        else:
            evals, evecs, ok = lanczos_sa_multi(H, n_eigs=N_EIGS_PER_SECTOR, v0_seed=v0_seed)
            if ok:
                sector_evals[N_up] = evals

    if not sector_evals:
        return None, 0

    E0_local = min(evals[0] for evals in sector_evals.values())

    # 第二步：筛选简并态并等权平均
    for N_up, evals in sector_evals.items():
        H, basis = build_hamiltonian_sector(N, edges, J_vals, N_up)
        if H.shape[0] == 0:
            continue
        dim = H.shape[0]

        if dim <= 1500:
            # 全谱对角化
            _, evecs = np.linalg.eigh(H.toarray())
            for idx, E in enumerate(evals):
                if abs(E - E0_local) < EPS_DEGEN:
                    psi = evecs[:, idx]
                    n_states += 1
                    for e_idx, (i, j) in enumerate(edges):
                        diag_vals = np.array([(1 if i in state else -1) * (1 if j in state else -1) for state in basis])
                        corr_sum[e_idx] += np.sum(np.abs(psi)**2 * diag_vals)
        else:
            # Lanczos
            _, evecs, ok = lanczos_sa_multi(H, n_eigs=N_EIGS_PER_SECTOR, v0_seed=v0_seed)
            if not ok:
                continue
            for idx in range(len(evals)):
                if abs(evals[idx] - E0_local) < EPS_DEGEN:
                    psi = evecs[:, idx]
                    n_states += 1
                    for e_idx, (i, j) in enumerate(edges):
                        diag_vals = np.array([(1 if i in state else -1) * (1 if j in state else -1) for state in basis])
                        corr_sum[e_idx] += np.sum(np.abs(psi)**2 * diag_vals)

    if n_states == 0:
        return None, 0
    corr_avg = corr_sum / n_states
    fine = np.std(corr_avg)
    return fine, n_states

# ========== 单次双视角扫描 ==========
def scan_edge_dual_view(N, edges, edge_idx, s_values, degen_sectors, N_up_standard, v0_seed):
    J_vals = np.ones(len(edges))
    fine_std = np.full(len(s_values), np.nan)
    fine_theo = np.full(len(s_values), np.nan)
    n_states_list = []

    for si, s in enumerate(s_values):
        J_vals[edge_idx] = s
        # 标准视角
        f_std = compute_fine_standard(N, edges, J_vals, N_up_standard, v0_seed)
        if f_std is not None:
            fine_std[si] = f_std
        # 理论视角
        f_theo, n_states = compute_fine_theoretical_dynamic(
            N, edges, J_vals, degen_sectors, v0_seed)
        if f_theo is not None:
            fine_theo[si] = f_theo
            n_states_list.append(n_states)
        J_vals[edge_idx] = 1.0

        if (si+1) % 15 == 0 or si == len(s_values)-1:
            print(f"    v0={v0_seed} 进度: {si+1}/{len(s_values)} (s={s:.2f})")
    return fine_std, fine_theo, n_states_list

# ========== 谷底检测 ==========
def detect_valley_standard(s_values, fine_values):
    valid = np.where(~np.isnan(fine_values))[0]
    if len(valid) < 3:
        return [], "insufficient_data"
    valleys = []
    for idx in range(1, len(valid)-1):
        curr = valid[idx]
        left = valid[idx-1]
        right = valid[idx+1]
        if fine_values[curr] < fine_values[left] and fine_values[curr] < fine_values[right]:
            depth = fine_values[valid[0]] - fine_values[curr]
            if depth > 0:
                valleys.append({'s': float(s_values[curr]), 'depth': float(depth), 'type': 'valid'})
    if not valleys:
        return [], "no_valid_valley"
    valleys.sort(key=lambda x: x['depth'], reverse=True)
    return valleys, "ok"

def detect_valleys_theoretical(s_values, fine_values):
    valid = np.where(~np.isnan(fine_values))[0]
    if len(valid) < 3:
        return [], "insufficient_data"
    valleys = []
    for idx in range(1, len(valid)-1):
        curr = valid[idx]
        left = valid[idx-1]
        right = valid[idx+1]
        if fine_values[curr] < fine_values[left] and fine_values[curr] < fine_values[right]:
            depth = fine_values[valid[0]] - fine_values[curr]
            vtype = 'internal_minimum'
            if depth < 0:
                vtype = 'internal_minimum_negative_depth'
            valleys.append({'s': float(s_values[curr]), 'depth': float(depth), 'type': vtype})
    if valid[0] > 0 and len(valid) > 1:
        if fine_values[valid[0]] < fine_values[valid[1]]:
            valleys.append({'s': float(s_values[valid[0]]), 'depth': 0.0, 'type': 'left_boundary_minimum'})
    if valid[-1] < len(s_values)-1 and len(valid) > 1:
        if fine_values[valid[-1]] < fine_values[valid[-2]]:
            depth = fine_values[valid[0]] - fine_values[valid[-1]]
            vtype = 'right_boundary_minimum'
            if depth < 0:
                vtype = 'right_boundary_minimum_negative_depth'
            valleys.append({'s': float(s_values[valid[-1]]), 'depth': float(depth), 'type': vtype})
    if not valleys:
        return [], "no_valley_detected"
    valleys.sort(key=lambda x: x['depth'], reverse=True)
    return valleys, "ok"

# ========== 多种子审计 ==========
def multi_seed_audit(N, edges, edge_idx, s_values, degen_sectors, N_up_standard, n_v0=3):
    std_depths = []
    std_valley_s = []
    std_failed = []
    theo_all_depths = []
    theo_all_valley_s = []
    theo_neg_count = 0
    theo_boundary_count = 0
    theo_failed = []
    theo_n_states_list = []

    print(f"  对边 {edges[edge_idx]} 进行 {n_v0} 种子审计...")
    for v0 in range(n_v0):
        fine_std, fine_theo, n_states_list = scan_edge_dual_view(
            N, edges, edge_idx, s_values, degen_sectors, N_up_standard, v0)

        std_valleys, std_status = detect_valley_standard(s_values, fine_std)
        if std_valleys:
            std_depths.append(std_valleys[0]['depth'])
            std_valley_s.append(std_valleys[0]['s'])
        else:
            std_failed.append(v0)

        theo_valleys, theo_status = detect_valleys_theoretical(s_values, fine_theo)
        if theo_valleys:
            for v in theo_valleys:
                theo_all_depths.append(v['depth'])
                theo_all_valley_s.append(v['s'])
                if 'negative_depth' in v['type']:
                    theo_neg_count += 1
                if 'boundary' in v['type']:
                    theo_boundary_count += 1
        else:
            theo_failed.append(v0)

        if n_states_list:
            theo_n_states_list.append(n_states_list[0])

    std_result = {
        'mean_depth': float(np.mean(std_depths)) if std_depths else None,
        'std_depth': float(np.std(std_depths, ddof=1)) if len(std_depths) > 1 else 0.0,
        'depth_distribution': [float(d) for d in std_depths],
        'valley_s_distribution': [float(s) for s in std_valley_s],
        'failed_v0': std_failed,
        'n_valid': len(std_depths),
        'n_total': n_v0
    }
    theo_result = {
        'all_depths': [float(d) for d in theo_all_depths],
        'all_valley_s': [float(s) for s in theo_all_valley_s],
        'negative_depth_count': theo_neg_count,
        'boundary_valley_count': theo_boundary_count,
        'failed_v0': theo_failed,
        'n_v0_with_valley': n_v0 - len(theo_failed),
        'n_v0_total': n_v0,
        'n_states_in_projection': theo_n_states_list
    }
    return std_result, theo_result

# ========== 主程序 ==========
def main():
    print("=== 关键边多种子审计（正确投影平均版） ===")
    print(f"N={N}, 步长 {S_VALUES[1]-S_VALUES[0]:.4f}, v0数={N_V0}")
    print(f"每个扇区求 {N_EIGS_PER_SECTOR} 个本征态\n")

    tree_G = generate_tree()
    random_G = generate_random()
    tree_edges = list(tree_G.edges())
    random_edges = list(random_G.edges())
    N_up_standard = N // 2

    tree_target = (1, 10)
    random_target = (8, 14)
    orbit_edges = [(0, 7), (13, 14)]
    negative_edge = (6, 11)

    # 预扫描（只在均匀点 s=1.0 确定简并扇区列表）
    print("预扫描确定简并扇区列表...")
    J_vals_probe = np.ones(len(tree_edges))
    tree_degen, tree_E0 = prescan_degenerate_sectors(N, tree_edges, J_vals_probe)
    print(f"树图简并扇区: {tree_degen}, E0={tree_E0:.8f}")

    J_vals_probe = np.ones(len(random_edges))
    random_degen, random_E0 = prescan_degenerate_sectors(N, random_edges, J_vals_probe)
    print(f"随机图简并扇区: {random_degen}, E0={random_E0:.8f}")

    output = {
        'parameters': {
            'N': N,
            's_min': float(S_VALUES[0]),
            's_max': float(S_VALUES[-1]),
            'step': float(S_VALUES[1]-S_VALUES[0]),
            'n_v0': N_V0,
            'N_up_standard': N_up_standard,
            'tree_degen_sectors': tree_degen,
            'random_degen_sectors': random_degen,
            'tree_E0_uniform': tree_E0,
            'random_E0_uniform': random_E0,
            'n_eigs_per_sector': N_EIGS_PER_SECTOR,
            'method_note': '标准视角=单扇区单态；理论视角=动态基态能量的全流形投影平均'
        },
        'tree_audit': {},
        'random_audit': {},
        'orbit_audit': {},
        'negative_depth_check': {}
    }

    # 树图关键边
    if tree_target in tree_edges:
        idx = tree_edges.index(tree_target)
        print(f"\n树图边 {tree_target} 多种子审计...")
        std_view, theo_view = multi_seed_audit(
            N, tree_edges, idx, S_VALUES, tree_degen, N_up_standard, N_V0)
        output['tree_audit'] = {
            'edge': list(tree_target),
            'standard_physics_view': std_view,
            'theoretical_view': theo_view
        }
        print(f"  标准：深度均值={std_view['mean_depth']:.10f}")
        print(f"  理论：深度分布={[f'{d:.10f}' for d in theo_view['all_depths']]}")
        print(f"  理论：投影态数={theo_view['n_states_in_projection']}")

    # 随机图关键边
    if random_target in random_edges:
        idx = random_edges.index(random_target)
        print(f"\n随机图边 {random_target} 多种子审计...")
        std_view, theo_view = multi_seed_audit(
            N, random_edges, idx, S_VALUES, random_degen, N_up_standard, N_V0)
        output['random_audit'] = {
            'edge': list(random_target),
            'standard_physics_view': std_view,
            'theoretical_view': theo_view
        }
        print(f"  标准：深度均值={std_view['mean_depth']:.10f}")
        print(f"  理论：深度分布={[f'{d:.10f}' for d in theo_view['all_depths']]}")
        print(f"  理论：投影态数={theo_view['n_states_in_projection']}")

    # 轨道边
    print("\n轨道边多种子审计...")
    orbit_results = {}
    for edge in orbit_edges:
        if edge not in tree_edges:
            continue
        idx = tree_edges.index(edge)
        std_view, theo_view = multi_seed_audit(
            N, tree_edges, idx, S_VALUES, tree_degen, N_up_standard, N_V0)
        orbit_results[str(edge)] = {
            'standard_physics_view': std_view,
            'theoretical_view': theo_view
        }
    output['orbit_audit'] = {
        'orbit_edges': [list(e) for e in orbit_edges],
        'per_edge_results': orbit_results
    }

    # 轨道一致性
    consistency = {
        'standard_view': {'depths_per_edge': {}, 'within_orbit_spread': None},
        'theoretical_view': {'depths_per_edge': {}, 'within_orbit_spread': None}
    }
    for edge_str, res in orbit_results.items():
        consistency['standard_view']['depths_per_edge'][edge_str] = res['standard_physics_view']['depth_distribution']
        consistency['theoretical_view']['depths_per_edge'][edge_str] = res['theoretical_view']['all_depths']

    for view_name in ['standard_view', 'theoretical_view']:
        all_depths = []
        for edge_str, depths in consistency[view_name]['depths_per_edge'].items():
            if depths:
                all_depths.extend(depths)
        if len(all_depths) > 1:
            consistency[view_name]['within_orbit_spread'] = float(np.max(all_depths) - np.min(all_depths))
    output['orbit_audit']['consistency'] = consistency

    print(f"\n轨道一致性：")
    if consistency['standard_view']['within_orbit_spread'] is not None:
        print(f"  标准视角轨道内深度差: {consistency['standard_view']['within_orbit_spread']:.15f}")
    if consistency['theoretical_view']['within_orbit_spread'] is not None:
        print(f"  理论视角轨道内深度差: {consistency['theoretical_view']['within_orbit_spread']:.15f}")

    # 负深度边
    if negative_edge in random_edges:
        idx = random_edges.index(negative_edge)
        print(f"\n负深度边 {negative_edge} 检查...")
        fine_std, fine_theo, n_states = scan_edge_dual_view(
            N, random_edges, idx, S_VALUES, random_degen, N_up_standard, 0)
        std_valleys, std_status = detect_valley_standard(S_VALUES, fine_std)
        theo_valleys, theo_status = detect_valleys_theoretical(S_VALUES, fine_theo)
        output['negative_depth_check'] = {
            'edge': list(negative_edge),
            'standard_view': {'valleys': std_valleys, 'status': std_status},
            'theoretical_view': {'valleys': theo_valleys, 'status': theo_status}
        }
        print(f"  标准视角: {std_status}")
        print(f"  理论视角: {theo_status}, 谷底数={len(theo_valleys)}")
        for v in theo_valleys:
            print(f"    谷底: s={v['s']}, 深度={v['depth']:.10f}, 类型={v['type']}")

    with open('critical_edges_audit_projected_corrected.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    print("\n结果已保存至 critical_edges_audit_projected_corrected.json")

if __name__ == "__main__":
    main()