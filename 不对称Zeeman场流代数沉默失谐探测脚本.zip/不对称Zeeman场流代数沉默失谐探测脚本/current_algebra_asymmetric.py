"""
不对称Zeeman场流代数沉默失谐探测
左半链 +hz，右半链 -hz，模拟不对称矛盾注入
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tenpy.models.model import CouplingMPOModel
from tenpy.models.lattice import Chain
from tenpy.networks.site import SpinHalfSite
from tenpy.networks.mps import MPS
from tenpy.algorithms import dmrg

class AsymmetricZeemanModel(CouplingMPOModel):
    """链式 Heisenberg 模型 + 不对称 Zeeman 场：左半链 +hz，右半链 -hz"""
    def __init__(self, model_params):
        L = model_params.get('L', 6)
        self.hz = model_params.get('hz', 0.0)
        lat = Chain(L, SpinHalfSite(conserve='Sz'), bc='open')
        model_params['lattice'] = lat
        CouplingMPOModel.__init__(self, model_params)

    def init_terms(self, model_params=None):
        L = self.lat.N_sites
        # Heisenberg 耦合
        self.add_coupling(0.5, 0, 'Sp', 0, 'Sm', 1, plus_hc=True)
        self.add_coupling(1.0, 0, 'Sz', 0, 'Sz', 1)
        # 不对称 Zeeman 场：左半链 +hz，右半链 -hz
        mid = L // 2
        hz_array = np.array([+1.0 if i < mid else -1.0 for i in range(L)]) * self.hz
        self.add_onsite(-hz_array, 0, 'Sz')


def run_asymmetric_scan(L=6, hz_values=None, chi_max=100):
    if hz_values is None:
        hz_values = np.linspace(0.0, 3.0, 13)
    
    gaps, coarse_vals, fine_vals = [], [], []
    print(f"\n=== 不对称Zeeman场沉默失谐探测 (L={L}) ===")
    
    for hz in hz_values:
        M = AsymmetricZeemanModel(dict(L=L, hz=hz, bc_MPS='finite', conserve='Sz'))
        init = ['up', 'down'] * (L // 2)
        if L % 2 == 1:
            init.append('up')
        psi = MPS.from_product_state(M.lat.mps_sites(), init, bc='finite')
        dmrg_params = {'mixer': True, 'chi_max': chi_max, 'max_sweeps': 50, 'verbose': 0}
        
        eng = dmrg.run(psi, M, dmrg_params)
        E0 = eng['E']
        
        init_ex = init.copy()
        center = L // 2
        init_ex[center] = 'down' if init[center] == 'up' else 'up'
        psi_ex = MPS.from_product_state(M.lat.mps_sites(), init_ex, bc='finite')
        eng_ex = dmrg.run(psi_ex, M, dmrg_params)
        E1 = eng_ex['E']
        gap = E1 - E0

        Sz = psi.expectation_value('Sz')
        coarse = np.mean(np.abs(Sz))
        corrs = []
        for i in range(L - 1):
            corr = psi.correlation_function('Sz', 'Sz', [i], [i+1])
            corrs.append(corr[0])
        fine = np.std(corrs) if corrs else 0.0
        
        gaps.append(gap); coarse_vals.append(coarse); fine_vals.append(fine)
        print(f"hz={hz:.2f}: gap={gap:.6f}, coarse={coarse:.4f}, fine={fine:.4f}")
    
    return np.array(hz_values), np.array(gaps), np.array(coarse_vals), np.array(fine_vals)


if __name__ == "__main__":
    L = 6
    hz_values = np.linspace(0.0, 3.0, 13)
    hz_vals, gaps, coarse, fine = run_asymmetric_scan(L, hz_values, chi_max=100)
    
    np.savetxt('current_algebra_asymmetric.csv', 
               np.column_stack((hz_vals, gaps, coarse, fine)), 
               header='hz,gap,coarse,fine', delimiter=',')
    
    fig, ax1 = plt.subplots(figsize=(10,6))
    ax1.plot(hz_vals, coarse, 'o-', label='Default diagnosis (coarse)')
    ax2 = ax1.twinx()
    ax2.plot(hz_vals, fine, 's-', color='red', label='Enhanced diagnosis (fine)')
    ax1.set_xlabel('hz (asymmetric Zeeman field)')
    ax1.set_ylabel('Default metric'); ax2.set_ylabel('Enhanced metric')
    ax1.legend(loc='upper left'); ax2.legend(loc='upper right')
    plt.title(f'Silent Discordance in Asymmetric Zeeman Model (L={L})')
    plt.tight_layout()
    plt.savefig('current_algebra_asymmetric.png')
    print("数据已保存至 current_algebra_asymmetric.csv")