"""
针对s=0处的精确诊断脚本
修复graph_to_hamiltonian中的bug后，重新测量s=0附近精细诊断值
"""
import numpy as np
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh

# =============================================
# 哈密顿量构建（修复bug后，标准泡利矩阵）
# =============================================
def build_hamiltonian(N, contradiction_edge, contradiction_strength):
    """构建标准各向同性Heisenberg模型，修复0.0被视为假值的bug"""
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)

    def to_full(op, site):
        ops = [I2] * N
        ops[site] = op
        result = ops[0]
        for k in range(1, N):
            result = np.kron(result, ops[k])
        return result

    for i in range(N-1):
        if (i, i+1) == contradiction_edge or (i+1, i) == contradiction_edge:
            J = float(contradiction_strength)  # 修复：0.0保持为0.0
        else:
            J = 1.0
        H += J * (to_full(sx, i) @ to_full(sx, i+1)).real
        H += J * (to_full(sy, i) @ to_full(sy, i+1)).real
        H += J * (to_full(sz, i) @ to_full(sz, i+1)).real

    return H.tocsc()


def compute_fine_diagnosis(N, contradiction_edge, s, D=0.0, num_eig=5):
    """计算精细诊断值（边关联涨落标准差）"""
    H = build_hamiltonian(N, contradiction_edge, s)
    energies, states = eigsh(H, k=min(num_eig, 2**N-1), which='SA')
    gs = states[:, 0]  # 基态

    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    corrs = []
    for i in range(N-1):
        ops = [I2] * N
        ops[i] = sz
        ops[i+1] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        corr = np.real(gs.conj().T @ op_full @ gs)
        corrs.append(corr)
    fine = np.std(corrs) if corrs else 0.0
    return fine


if __name__ == "__main__":
    N = 6
    contradiction_edge = (2, 3)
    # 关键：s=0.00 以及接近零的值
    s_vals = [0.0, 1e-12, 1e-9, 1e-6, 1e-3, 0.01, 0.1, 0.25, 0.5, 1.0]

    print(f"=== 修复bug后的s=0附近精细诊断值 (N={N}, edge={contradiction_edge}) ===")
    print(f"{'s':>12} | {'fine (D=0)':>16} | {'fine (D=0.3)':>16}")
    print("-" * 55)

    for s in s_vals:
        fine_D0 = compute_fine_diagnosis(N, contradiction_edge, s, D=0.0)
        fine_D03 = compute_fine_diagnosis(N, contradiction_edge, s, D=0.3)
        print(f"{s:12.8f} | {fine_D0:16.8f} | {fine_D03:16.8f}")

    # 验证：fine(s=1.0)应该与之前正向扫描的0.2447完全一致
    print("\n=== 验证 ===")
    fine_s1 = compute_fine_diagnosis(N, contradiction_edge, 1.0, D=0.0)
    print(f"fine(s=1.0) = {fine_s1:.8f}")
    print(f"预期（修复前正向扫描s=1.0）= 0.2447000000")
    print(f"偏差 = {abs(fine_s1 - 0.2447):.8f}")

    print("\n=== 关键发现 ===")
    print("修复前：s=0.0被静默替换为1.0，所以fine(s=0.0) = fine(s=1.0) = 0.2447")
    print("修复后：s=0.0保持为0.0，fine(s=0.0)应显著不同于0.2447")