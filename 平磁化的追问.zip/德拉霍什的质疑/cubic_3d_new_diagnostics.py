"""
三维简单立方晶格：新默认诊断框架（修复版）
手动构建三维耦合，使用 add_coupling_term 直接指定站点索引
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import skew
from tenpy.models.model import CouplingMPOModel
from tenpy.models.lattice import Chain
from tenpy.networks.site import SpinHalfSite
from tenpy.networks.mps import MPS
from tenpy.algorithms import dmrg

class CubicHeisenbergModel(CouplingMPOModel):
    """3D 简单立方 Heisenberg 模型，手动构建耦合"""
    def __init__(self, model_params):
        self.Nx = model_params.get('Nx', 2)
        self.Ny = model_params.get('Ny', 2)
        self.Nz = model_params.get('Nz', 2)
        L = self.Nx * self.Ny * self.Nz
        
        lat = Chain(L, SpinHalfSite(conserve='Sz'), bc='open')
        model_params['lattice'] = lat
        
        self.contradiction_strength = model_params.get('contradiction_strength', 1.0)
        self.contradiction_bond = model_params.get('contradiction_bond', (0, 1))
        
        CouplingMPOModel.__init__(self, model_params)

    def init_sites(self, model_params):
        return [SpinHalfSite(conserve='Sz')] * (self.Nx * self.Ny * self.Nz)

    def init_terms(self, model_params=None):
        for x in range(self.Nx):
            for y in range(self.Ny):
                for z in range(self.Nz):
                    i = self._idx(x, y, z)
                    if x < self.Nx - 1:
                        j = self._idx(x+1, y, z)
                        self._add_bond(i, j)
                    if y < self.Ny - 1:
                        j = self._idx(x, y+1, z)
                        self._add_bond(i, j)
                    if z < self.Nz - 1:
                        j = self._idx(x, y, z+1)
                        self._add_bond(i, j)

    def _idx(self, x, y, z):
        return x * (self.Ny * self.Nz) + y * self.Nz + z

    def _add_bond(self, i, j):
        J = self.contradiction_strength if (i, j) == self.contradiction_bond or (j, i) == self.contradiction_bond else 1.0
        self.add_coupling_term(J * 0.5, i, j, 'Sp', 'Sm', plus_hc=True)
        self.add_coupling_term(J, i, j, 'Sz', 'Sz')


# =============================================
# 新默认诊断函数
# =============================================
def new_default_diagnostics(psi, model):
    Nx, Ny, Nz = model.Nx, model.Ny, model.Nz
    nn_corrs = []
    for x in range(Nx - 1):
        for y in range(Ny):
            for z in range(Nz):
                i = model._idx(x, y, z)
                j = model._idx(x+1, y, z)
                corr = psi.correlation_function('Sz', 'Sz', [i], [j])[0]
                nn_corrs.append(corr)
    nn_corrs = np.array(nn_corrs)
    defect_corr = nn_corrs[0]
    corr_skewness = skew(nn_corrs) if len(nn_corrs) > 2 else 0.0
    corr_mean = np.mean(nn_corrs)
    corr_std = np.std(nn_corrs)
    corr_cv = corr_std / abs(corr_mean) if abs(corr_mean) > 1e-12 else 0.0
    return defect_corr, corr_skewness, corr_cv


def run_3d_scan(delta_vals, chi_max=200):
    model_params = {
        'Nx': 2, 'Ny': 2, 'Nz': 2,
        'contradiction_bond': (0, 1),
        'bc_MPS': 'finite', 'conserve': 'Sz'
    }
    data = {'delta': [], 'fine': [], 'defect_corr': [], 'corr_skewness': [], 'corr_cv': []}
    print(f"三维简单立方晶格超精细扫描（新默认诊断）")
    print(f"晶格: 2x2x2 = 8 节点, 矛盾边: (0,1), 扫描点数: {len(delta_vals)}")
    for i, delta in enumerate(delta_vals):
        params = model_params.copy()
        params['contradiction_strength'] = delta
        M = CubicHeisenbergModel(params)
        init = ['up', 'down'] * (M.Nx * M.Ny * M.Nz // 2)
        if (M.Nx * M.Ny * M.Nz) % 2 == 1:
            init.append('up')
        psi = MPS.from_product_state(M.lat.mps_sites(), init, bc='finite')
        dmrg_params = {'mixer': True, 'chi_max': chi_max, 'max_sweeps': 100, 'verbose': 0}
        eng = dmrg.run(psi, M, dmrg_params)
        corrs = []
        for x in range(M.Nx - 1):
            for y in range(M.Ny):
                for z in range(M.Nz):
                    i = M._idx(x, y, z)
                    j = M._idx(x+1, y, z)
                    corr = psi.correlation_function('Sz', 'Sz', [i], [j])[0]
                    corrs.append(corr)
        fine = np.std(corrs) if corrs else 0.0
        defect_corr, corr_skewness, corr_cv = new_default_diagnostics(psi, M)
        data['delta'].append(delta)
        data['fine'].append(fine)
        data['defect_corr'].append(defect_corr)
        data['corr_skewness'].append(corr_skewness)
        data['corr_cv'].append(corr_cv)
        if i % 100 == 0:
            print(f"  进度: {i+1}/{len(delta_vals)}, Δ={delta:.3f}, fine={fine:.6f}, defect_corr={defect_corr:.6f}, skewness={corr_skewness:.4f}, cv={corr_cv:.4f}")
    return data


def plot_new_diagnostics(data):
    delta_arr = np.array(data['delta'])
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))
    fig.suptitle('3D Cubic Lattice: New Default Diagnostics', fontsize=14, fontweight='bold')
    axes[0,0].plot(delta_arr, data['fine'], '-', color='#d62728', linewidth=0.5)
    axes[0,0].set_title('Enhanced Diagnosis (Old)')
    axes[0,1].plot(delta_arr, data['defect_corr'], '-', color='#1f77b4', linewidth=0.5)
    axes[0,1].set_title('New Default 1: Defect Bond Response')
    axes[1,0].plot(delta_arr, data['corr_skewness'], '-', color='#2ca02c', linewidth=0.5)
    axes[1,0].set_title('New Default 2: Relational Field Asymmetry')
    axes[1,1].plot(delta_arr, data['corr_cv'], '-', color='#9467bd', linewidth=0.5)
    axes[1,1].set_title('New Default 3: Global Relational Coordination')
    for ax in axes.flat:
        ax.set_xlabel('Δ'); ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('cubic_3d_new_diagnostics.png', dpi=150)
    print("图表已保存至 cubic_3d_new_diagnostics.png")


if __name__ == "__main__":
    delta_vals = np.linspace(0.0, 3.0, 601)
    data = run_3d_scan(delta_vals, chi_max=200)
    np.savetxt('cubic_3d_new_diagnostics.csv', 
               np.column_stack((data['delta'], data['fine'], 
                                data['defect_corr'], data['corr_skewness'], data['corr_cv'])), 
               header='delta,fine,defect_corr,corr_skewness,corr_cv', delimiter=',')
    print("数据已保存至 cubic_3d_new_diagnostics.csv")
    plot_new_diagnostics(data)