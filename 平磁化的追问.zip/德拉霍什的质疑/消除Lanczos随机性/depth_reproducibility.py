"""
Depth Reproducibility Audit
只针对一个问题：ED 运行时，谷深度的数值可复现性。
严格遵循：关系本体论、防工具理性、反对对齐。
不预设“应该有20%散布”或“应该完全一致”，只输出多次运行的真实数据。
"""
import numpy as np
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh
import networkx as nx

# =============================================
# 工具函数：构建 star 树图（与论文一致）
# =============================================
def star_tree_graph(N):
    """生成 N 个节点的星形图（中心节点0连接所有其他节点）"""
    G = nx.star_graph(N-1)
    for u, v in G.edges():
        G[u][v]['weight'] = 1.0
    return G

def build_hamiltonian_for_star(N, contradiction_edge, contradiction_strength):
    """构建星形图 Heisenberg 哈密顿量，指定矛盾边和强度"""
    G = star_tree_graph(N)
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)

    def to_full(op, site):
        ops = [I2] * N
        ops[site] = op
        result = ops[0]
        for k in range(1, N):
            result = np.kron(result, ops[k])
        return result

    for (i, j, w) in G.edges(data='weight'):
        J = float(w)
        if (i, j) == contradiction_edge or (j, i) == contradiction_edge:
            J = contradiction_strength
        H += J * (to_full(sx, i) @ to_full(sx, j)).real
        H += J * (to_full(sy, i) @ to_full(sy, j)).real
        H += J * (to_full(sz, i) @ to_full(sz, j)).real
    return H.tocsc()

def compute_fine_for_s(N, contradiction_edge, s, seed):
    """给定s，计算精细诊断（边关联涨落标准差）"""
    H = build_hamiltonian_for_star(N, contradiction_edge, s)
    dim = H.shape[0]
    # 使用随机实数 v0，模拟 Lanczos 起始随机性
    rng = np.random.default_rng(seed)
    v0 = rng.uniform(-1, 1, dim)
    v0 /= np.linalg.norm(v0)
    # 只求基态
    eigvals, eigvecs = eigsh(H, k=1, which='SA', v0=v0)
    gs = eigvecs[:, 0]

    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)

    def full_op(op, site):
        ops = [I2] * N
        ops[site] = op
        res = ops[0]
        for k in range(1, N):
            res = np.kron(res, ops[k])
        return res

    corrs = []
    G = star_tree_graph(N)
    for (i, j, _) in G.edges(data='weight'):
        op_i = full_op(sz, i)
        op_j = full_op(sz, j)
        corr = np.real(gs.conj().T @ (op_i @ op_j) @ gs)
        corrs.append(corr)
    fine = np.std(corrs) if corrs else 0.0
    return fine

def run_full_scan(N, contradiction_edge, s_values, seed):
    """对整个s序列进行扫描，返回 (s_values, fine_vals)"""
    fine_vals = []
    for s in s_values:
        fine = compute_fine_for_s(N, contradiction_edge, s, seed)
        fine_vals.append(fine)
    return np.array(fine_vals)

# =============================================
# 主实验：5次独立运行，观测深度和位置
# =============================================
if __name__ == "__main__":
    N = 7
    contradiction_edge = (0, 1)  # 星形图中心节点0与第一个叶子节点的边
    s_values = np.linspace(0.0, 3.0, 301)

    print("=== 谷深度可复现性审计 ===")
    print(f"模型：star N={N}, 矛盾边={contradiction_edge}, 扫描点数={len(s_values)}")
    print(f"每次运行使用不同的随机v0（Lanczos起始向量）。\n")

    depths = []
    positions = []
    max_fines = []
    min_fines = []

    for run_id in range(1, 6):
        seed = 100 + run_id * 37  # 每次不同种子
        fine_vals = run_full_scan(N, contradiction_edge, s_values, seed)
        max_f = np.max(fine_vals)
        min_f = np.min(fine_vals)
        depth = max_f - min_f
        pos = s_values[np.argmin(fine_vals)]
        depths.append(depth)
        positions.append(pos)
        max_fines.append(max_f)
        min_fines.append(min_f)
        print(f"运行 #{run_id} (seed={seed}): max={max_f:.6f}, min={min_f:.6f}, depth={depth:.6f}, valley_s={pos:.3f}")

    depths = np.array(depths)
    positions = np.array(positions)
    print("\n=== 汇总统计 ===")
    print(f"深度: 均值 = {np.mean(depths):.6f}, 标准差 = {np.std(depths, ddof=1):.6f}")
    print(f"深度相对散布 (std/mean) = {np.std(depths, ddof=1)/np.mean(depths)*100:.1f}%")
    print(f"位置: 均值 = {np.mean(positions):.6f}, 标准差 = {np.std(positions, ddof=1):.6f}")

    # 对比德拉霍什报告的star N=7深度：0.1330, 0.1100, 0.1341
    print("\n（德拉霍什对star N=7报告的深度：0.1330, 0.1100, 0.1341）")

    # 保存数据
    np.savetxt('depth_reproducibility.csv',
               np.column_stack((np.arange(1,6), depths, positions, max_fines, min_fines)),
               header='run,depth,valley_s,max_fine,min_fine', delimiter=',')
    print("\n数据已保存至 depth_reproducibility.csv")