"""
默认诊断可靠性审计 —— 精确对角化版本
针对德拉霍什质疑：默认诊断（coarse）是否真的可靠地“盲视”？
修复 s=0 代码bug + 固定本征求解器初始向量 + 多次重复运行
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh

# =============================================
# 哈密顿量构建（泡利矩阵版，修复 s=0 bug）
# =============================================
def build_hamiltonian(N, contradiction_edge, contradiction_strength):
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)

    def to_full(op, site):
        ops = [I2] * N
        ops[site] = op
        result = ops[0]
        for k in range(1, N):
            result = np.kron(result, ops[k])
        return result

    for i in range(N-1):
        # 修复德拉霍什发现的bug：w=0.0时不能变成1.0
        if (i, i+1) == contradiction_edge or (i+1, i) == contradiction_edge:
            J = float(contradiction_strength)  # 显式类型转换，不经过 if-else
        else:
            J = 1.0
        j = i + 1
        H += J * (to_full(sx, i) @ to_full(sx, j)).real
        H += J * (to_full(sy, i) @ to_full(sy, j)).real
        H += J * (to_full(sz, i) @ to_full(sz, j)).real

    return H.tocsc()


def compute_diagnostics_with_fixed_v0(N, contradiction_edge, s, num_eig=6, v0_seed=42):
    """用固定初始向量求解，确保可重复性"""
    H = build_hamiltonian(N, contradiction_edge, s)
    dim = 2**N

    # 固定初始向量：排除Lanczos随机性
    rng = np.random.RandomState(v0_seed)
    v0 = rng.randn(dim)

    energies, states = eigsh(H, k=min(num_eig, dim-1), which='SA', v0=v0)

    gap = energies[1] - energies[0] if len(energies) > 1 else np.nan
    gs = states[:, 0]  # 基态

    # 默认诊断：平均磁化
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    mag = 0.0
    for i in range(N):
        ops = [I2] * N
        ops[i] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        mag += np.real(gs.conj().T @ op_full @ gs)
    coarse = abs(mag / N)

    # 增强诊断：边关联涨落标准差
    corrs = []
    for i in range(N-1):
        ops = [I2] * N
        ops[i] = sz
        ops[i+1] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        corr = np.real(gs.conj().T @ op_full @ gs)
        corrs.append(corr)
    fine = np.std(corrs) if corrs else 0.0

    return gap, coarse, fine, corrs


def run_coarse_reliability_audit(N=6, contradiction_edge=(2,3),
                                  s_values=np.linspace(0.0, 3.0, 25),
                                  n_repeats=5):
    """
    核心审计：默认诊断在不同重复运行下是否稳定？
    是否存在数值伪影导致的虚假“盲视”或虚假“非盲视”？
    """
    print(f"=== 默认诊断可靠性审计 (N={N}, 矛盾边={contradiction_edge}) ===")
    print(f"重复次数: {n_repeats}，s点数: {len(s_values)}")
    print(f"固定v0种子: 42（排除Lanczos随机性）\n")

    all_coarse = []
    all_fine = []
    all_gaps = []

    for run_id in range(n_repeats):
        coarse_list = []
        fine_list = []
        gap_list = []

        # 每次重复使用相同的固定v0，检验是否完全可重复
        for s in s_values:
            gap, coarse, fine, _ = compute_diagnostics_with_fixed_v0(
                N, contradiction_edge, s, v0_seed=42
            )
            coarse_list.append(coarse)
            fine_list.append(fine)
            gap_list.append(gap)

        all_coarse.append(coarse_list)
        all_fine.append(fine_list)
        all_gaps.append(gap_list)

        print(f"重复#{run_id+1}: s=0.00 coarse={coarse_list[0]:.6f}, "
              f"s=0.38 coarse={coarse_list[4]:.6f}, s=3.00 coarse={coarse_list[-1]:.6f}")

    all_coarse = np.array(all_coarse)
    all_fine = np.array(all_fine)
    all_gaps = np.array(all_gaps)

    # 计算跨重复的平均值和标准差
    coarse_mean = np.mean(all_coarse, axis=0)
    coarse_std = np.std(all_coarse, axis=0)
    fine_mean = np.mean(all_fine, axis=0)
    fine_std = np.std(all_fine, axis=0)

    print("\n=== 关键统计 ===")
    print(f"默认诊断跨重复最大标准差: {np.max(coarse_std):.6f}")
    print(f"增强诊断跨重复最大标准差: {np.max(fine_std):.6f}")
    print(f"s=0.00处默认诊断: 均值={coarse_mean[0]:.6f}, 标准差={coarse_std[0]:.6f}")
    print(f"s=0.38处默认诊断: 均值={coarse_mean[4]:.6f}, 标准差={coarse_std[4]:.6f}")
    print(f"s=3.00处默认诊断: 均值={coarse_mean[-1]:.6f}, 标准差={coarse_std[-1]:.6f}")

    # 核心检验：默认诊断在增强诊断的谷底处是否真的盲视？
    valley_idx = np.argmin(fine_mean)
    valley_s = s_values[valley_idx]
    print(f"\n增强诊断谷底位置: s={valley_s:.4f}")
    print(f"谷底处默认诊断: {coarse_mean[valley_idx]:.6f} ± {coarse_std[valley_idx]:.6f}")
    print(f"谷底处增强诊断: {fine_mean[valley_idx]:.6f} ± {fine_std[valley_idx]:.6f}")

    # 检验默认诊断是否在整个扫描区间内保持平滑
    # 用二阶差分检测是否存在隐藏的非单调结构
    coarse_d2 = np.diff(coarse_mean, n=2)
    fine_d2 = np.diff(fine_mean, n=2)
    print(f"\n默认诊断二阶差分最大绝对值: {np.max(np.abs(coarse_d2)):.6f}")
    print(f"增强诊断二阶差分最大绝对值: {np.max(np.abs(fine_d2)):.6f}")
    print(f"（如果默认诊断的二阶差分远小于增强诊断，则盲视性可靠）")

    # 保存数据
    np.savetxt('coarse_reliability_audit.csv',
               np.column_stack((s_values, coarse_mean, coarse_std, fine_mean, fine_std)),
               header='s,coarse_mean,coarse_std,fine_mean,fine_std', delimiter=',')

    # 可视化
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    # 左图：默认诊断 + 误差棒
    ax = axes[0]
    ax.errorbar(s_values, coarse_mean, yerr=coarse_std, fmt='o-', capsize=3,
                color='#1f77b4', label='Coarse (mean ± std)')
    ax.axvline(valley_s, color='red', linestyle='--', alpha=0.5,
               label=f'Valley s={valley_s:.3f}')
    ax.set_xlabel('s')
    ax.set_ylabel('Coarse diagnosis')
    ax.set_title(f'Coarse Diagnosis Reliability (N={N})')
    ax.legend(fontsize=8)
    ax.grid(True, alpha=0.3)

    # 右图：增强诊断 + 误差棒
    ax = axes[1]
    ax.errorbar(s_values, fine_mean, yerr=fine_std, fmt='s-', capsize=3,
                color='#d62728', label='Fine (mean ± std)')
    ax.axvline(valley_s, color='red', linestyle='--', alpha=0.5,
               label=f'Valley s={valley_s:.3f}')
    ax.set_xlabel('s')
    ax.set_ylabel('Fine diagnosis')
    ax.set_title(f'Enhanced Diagnosis Reliability (N={N})')
    ax.legend(fontsize=8)
    ax.grid(True, alpha=0.3)

    plt.suptitle(f'Coarse vs Enhanced Diagnosis Audit (N={N}, fixed v0, {n_repeats} repeats)')
    plt.tight_layout()
    plt.savefig('coarse_reliability_audit.png', dpi=150)
    print("\n结果已保存: coarse_reliability_audit.csv / .png")
    print("Done.")

    return s_values, coarse_mean, coarse_std, fine_mean, fine_std


if __name__ == "__main__":
    N = 6
    contradiction_edge = (2, 3)
    s_values = np.linspace(0.0, 3.0, 25)  # 更高分辨率
    run_coarse_reliability_audit(N, contradiction_edge, s_values, n_repeats=5)