"""
树状图沉默失谐证伪测试 —— N=7 微调版
五种树拓扑 × 三种随机种子 × Heisenberg
检验：N=6 上全部出现V形谷底，N=7上是否全部消失？
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import networkx as nx
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh
import warnings
warnings.filterwarnings('ignore')

# =============================================
# 五种树拓扑（N=7）
# =============================================
def random_tree(N, seed):
    np.random.seed(seed)
    G = nx.random_labeled_tree(N, seed=seed)
    for u, v in G.edges(): G[u][v]['weight'] = 1.0
    return G

def star_tree(N):
    G = nx.star_graph(N - 1)
    for u, v in G.edges(): G[u][v]['weight'] = 1.0
    return G

def binary_tree(h):
    G = nx.balanced_tree(2, h)
    for u, v in G.edges(): G[u][v]['weight'] = 1.0
    return G

def path_graph_tree(N):
    G = nx.path_graph(N)
    for u, v in G.edges(): G[u][v]['weight'] = 1.0
    return G

def random_labeled_tree(N, seed):
    np.random.seed(seed)
    seq = np.random.randint(0, N, N - 2)
    G = nx.from_prufer_sequence(seq)
    for u, v in G.edges(): G[u][v]['weight'] = 1.0
    return G

# =============================================
# 哈密顿量与诊断
# =============================================
def graph_to_hamiltonian(G):
    N = G.number_of_nodes()
    dim = 2 ** N
    H = lil_matrix((dim, dim), dtype=float)
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    def to_full(op, site):
        ops = [I2] * N; ops[site] = op
        result = ops[0]
        for k in range(1, N): result = np.kron(result, ops[k])
        return result
    for i, j, w in G.edges(data='weight'):
        w = w if w else 1.0
        H += w * (to_full(sx, i) @ to_full(sx, j)).real
        H += w * (to_full(sy, i) @ to_full(sy, j)).real
        H += w * (to_full(sz, i) @ to_full(sz, j)).real
    return H.tocsc()

def introduce_contradiction(G, edge, strength):
    G_mod = G.copy()
    if G_mod.has_edge(*edge): G_mod[edge[0]][edge[1]]['weight'] = strength
    else: G_mod.add_edge(*edge, weight=strength)
    return G_mod

def diagnose(G, num_eig=5):
    H = graph_to_hamiltonian(G)
    N = G.number_of_nodes()
    energies, states = eigsh(H, k=min(num_eig, 2**N-1), which='SA')
    gap = energies[1] - energies[0] if len(energies) > 1 else np.nan
    return energies, gap, states[:, 0]

def fine_diagnosis(G, gs):
    N = G.number_of_nodes(); dim = len(gs)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    corrs = []
    for i, j in G.edges():
        ops = [I2] * N; ops[i] = sz; ops[j] = sz
        op_full = ops[0]
        for k in range(1, N): op_full = np.kron(op_full, ops[k])
        corr = np.real(gs.conj().T @ op_full @ gs)
        corrs.append(corr)
    return np.std(corrs) if corrs else 0.0

# =============================================
# V形谷底检测
# =============================================
def detect_valley(s_values, fine_values):
    n = len(fine_values)
    if n < 3: return False, None, 0.0
    min_idx = None
    for i in range(1, n-1):
        if fine_values[i] < fine_values[i-1] and fine_values[i] < fine_values[i+1]:
            if min_idx is None or fine_values[i] < fine_values[min_idx]:
                min_idx = i
    if min_idx is None: return False, None, 0.0
    left_max = np.max(fine_values[:min_idx+1])
    right_max = np.max(fine_values[min_idx:])
    valley_depth = min(left_max, right_max) - fine_values[min_idx]
    threshold = 0.2 * np.std(fine_values)
    if valley_depth < threshold: return False, None, 0.0
    return True, s_values[min_idx], valley_depth

# =============================================
# 单树测试
# =============================================
def test_tree(G, contradiction_edge, strengths, label):
    fine_vals = []
    for s in strengths:
        G_mod = introduce_contradiction(G, contradiction_edge, s)
        _, gap, gs = diagnose(G_mod, num_eig=5)
        fine_vals.append(fine_diagnosis(G_mod, gs))
    has_valley, valley_s, valley_depth = detect_valley(strengths, np.array(fine_vals))
    status = "⚠️ 发现V形谷底！" if has_valley else "✓ 无V形谷底"
    print(f"  {label}: {status}")
    if has_valley: print(f"    谷底 s={valley_s:.4f}, 深度={valley_depth:.6f}")
    return {'label': label, 'has_valley': has_valley, 'valley_s': valley_s, 
            'valley_depth': valley_depth, 'fine_values': fine_vals}

# =============================================
# 主程序：N=7 微调
# =============================================
if __name__ == "__main__":
    N = 7  # 关键修改：从N=6改为N=7
    strengths = np.linspace(0.0, 3.0, 13)
    seeds = [42, 123, 789]
    
    tree_generators = [
        ("随机树", lambda s: random_tree(N, s)),
        ("星形树", lambda s: star_tree(N)),
        ("二叉树(h=2)", lambda s: binary_tree(2)),
        ("路径图", lambda s: path_graph_tree(N)),
        ("Prüfer树", lambda s: random_labeled_tree(N, s)),
    ]
    
    all_results = []
    valley_count = 0
    
    print(f"树状图沉默失谐证伪测试 —— N={N} 微调版")
    print(f"五种拓扑 × 三种种子, ED精确对角化")
    print("=" * 60)
    
    for gen_name, gen_func in tree_generators:
        for seed in seeds:
            G = gen_func(seed)
            degrees = dict(G.degree())
            max_deg_node = max(degrees, key=degrees.get)
            neighbors = list(G.neighbors(max_deg_node))
            contradiction_edge = (max_deg_node, neighbors[0]) if neighbors else list(G.edges())[0]
            
            label = f"{gen_name} (seed={seed})"
            result = test_tree(G, contradiction_edge, strengths, label)
            result['topology'] = gen_name; result['seed'] = seed
            all_results.append(result)
            if result['has_valley']: valley_count += 1
    
    total_tests = len(all_results)
    print(f"\n总测试数: {total_tests}")
    print(f"发现V形谷底的树: {valley_count}/{total_tests}")
    
    if valley_count == 0:
        print("结论：N=7上所有树均未出现V形谷底。环路必要性在小系统(N=6)有例外，在N≥7成立。")
    else:
        for r in all_results:
            if r['has_valley']:
                print(f"  {r['label']}: s={r['valley_s']:.4f}, depth={r['valley_depth']:.6f}")
    
    import json
    with open('tree_falsification_N7.json', 'w') as f:
        json.dump({'N': N, 'total': total_tests, 'valley_count': valley_count,
                   'results': [{'label': r['label'], 'has_valley': r['has_valley'],
                                'valley_s': r['valley_s'], 'valley_depth': r['valley_depth']} 
                               for r in all_results]}, f, indent=2)
    print("Done.")