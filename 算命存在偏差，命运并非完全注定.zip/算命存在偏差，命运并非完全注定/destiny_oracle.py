"""
命运预言实验 —— 金箍棒 ED 版
基于"时间静止、关系场预存"原理的算命模拟
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh

# =============================================
# 哈密顿量构建（泡利矩阵版，标准Heisenberg）
# =============================================
def build_hamiltonian(N, contradiction_edge, contradiction_strength):
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    
    def to_full(op, site):
        ops = [I2] * N
        ops[site] = op
        result = ops[0]
        for k in range(1, N):
            result = np.kron(result, ops[k])
        return result
    
    for i in range(N-1):
        if (i, i+1) == contradiction_edge or (i+1, i) == contradiction_edge:
            J = contradiction_strength
        else:
            J = 1.0
        j = i + 1
        H += J * (to_full(sx, i) @ to_full(sx, j)).real
        H += J * (to_full(sy, i) @ to_full(sy, j)).real
        H += J * (to_full(sz, i) @ to_full(sz, j)).real
    
    return H.tocsc()


def compute_fine(N, contradiction_edge, s):
    """用ED计算给定s下的精细诊断值"""
    H = build_hamiltonian(N, contradiction_edge, s)
    energies, states = eigsh(H, k=2, which='SA')
    gs = states[:, 0]
    
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    corrs = []
    for i in range(N-1):
        ops = [I2] * N
        ops[i] = sz
        ops[i+1] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        corr = np.real(gs.conj().T @ op_full @ gs)
        corrs.append(corr)
    fine = np.std(corrs) if corrs else 0.0
    return fine


def generate_life_path(start_s=1.5, steps=20, step_range=0.2, s_min=0.0, s_max=3.0):
    """随机生成一条人生路径：s值随机游走，限制在[s_min, s_max]内"""
    path = [start_s]
    for _ in range(steps - 1):
        delta = np.random.uniform(-step_range, step_range)
        next_s = np.clip(path[-1] + delta, s_min, s_max)
        path.append(next_s)
    return np.array(path)

if __name__ == "__main__":
    N = 6
    contradiction_edge = (N//2 - 1, N//2)  # (2,3)
    
    # === 编制"命运簿"：正向扫描 s=0 到 3 ===
    s_book = np.linspace(0.0, 3.0, 31)  # 更密的网格
    fine_book = []
    print("编制命运簿...")
    for s in s_book:
        fine = compute_fine(N, contradiction_edge, s)
        fine_book.append(fine)
        print(f"  s={s:.2f}: fine={fine:.6f}")
    fine_book = np.array(fine_book)
    
    # === 生成一条"人生路径" ===
    np.random.seed(42)  # 固定随机种子，可复现
    life_path = generate_life_path(start_s=1.5, steps=20, step_range=0.25)
    print(f"\n人生路径: {life_path}")
    
    # === 算命：从命运簿中查找人生路径上每个点的预言 ===
    oracle_fine = []
    actual_fine = []
    for s in life_path:
        # 算命：从命运簿中插值查找
        idx = np.argmin(np.abs(s_book - s))
        pred = fine_book[idx]
        oracle_fine.append(pred)
        
        # 实际经历：独立用ED计算（不依赖路径历史）
        actual = compute_fine(N, contradiction_edge, s)
        actual_fine.append(actual)
        
        diff = abs(pred - actual)
        note = ""
        if s == 0.0:
            note = " (简并点，不可预测)"
        print(f"  处境s={s:.2f}: 算命={pred:.6f}, 实际={actual:.6f}, 偏差={diff:.6f}{note}")
    
    oracle_fine = np.array(oracle_fine)
    actual_fine = np.array(actual_fine)
    
    # === 保存数据 ===
    np.savetxt('destiny_oracle_results.csv', 
               np.column_stack((life_path, oracle_fine, actual_fine, np.abs(oracle_fine - actual_fine))), 
               header='s,oracle,actual,diff', delimiter=',')
    
    # === 对比图 ===
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.plot(s_book, fine_book, '-', color='gray', alpha=0.5, label='Destiny Book (pre-existing)')
    ax.plot(life_path, oracle_fine, 'o-', color='#1f77b4', label='Oracle (lookup)')
    ax.plot(life_path, actual_fine, 's--', color='#d62728', label='Actual (path)')
    ax.set_xlabel('Contradiction strength s')
    ax.set_ylabel('Fine diagnosis')
    ax.set_title('Destiny Oracle: Can the future be foretold?')
    ax.legend()
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('destiny_oracle.png', dpi=150)
    
    # === 定量统计 ===
    non_degenerate_mask = life_path != 0.0
    max_dev_nondeg = np.max(np.abs(oracle_fine[non_degenerate_mask] - actual_fine[non_degenerate_mask])) if np.any(non_degenerate_mask) else 0
    print(f"\n非简并点的最大算命偏差: {max_dev_nondeg:.6f}")
    if max_dev_nondeg < 1e-4:
        print("结论：在非简并处境下，算命完全准确。命运已由关系场预存。")
    else:
        print("结论：算命存在偏差，命运并非完全注定。")
    
    print("\nDone. 数据已保存。")