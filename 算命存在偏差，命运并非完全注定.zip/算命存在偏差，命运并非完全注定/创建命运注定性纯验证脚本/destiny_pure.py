"""
命运注定性纯验证 —— 金箍棒 ED 版
验证：给定关系结构 s，系统状态是否与历史路径无关？
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh

# =============================================
# 哈密顿量构建（链式 Heisenberg）
# =============================================
def build_hamiltonian(N, contradiction_edge, s):
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    
    def to_full(op, site):
        ops = [I2] * N
        ops[site] = op
        result = ops[0]
        for k in range(1, N):
            result = np.kron(result, ops[k])
        return result
    
    for i in range(N-1):
        if (i, i+1) == contradiction_edge or (i+1, i) == contradiction_edge:
            J = s
        else:
            J = 1.0
        j = i + 1
        H += J * (to_full(sx, i) @ to_full(sx, j)).real
        H += J * (to_full(sy, i) @ to_full(sy, j)).real
        H += J * (to_full(sz, i) @ to_full(sz, j)).real
    
    return H.tocsc()


def compute_fine(N, contradiction_edge, s):
    """计算给定 s 下的精细诊断（边关联涨落标准差）"""
    H = build_hamiltonian(N, contradiction_edge, s)
    energies, states = eigsh(H, k=2, which='SA')
    gs = states[:, 0]
    
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    corrs = []
    for i in range(N-1):
        ops = [I2] * N
        ops[i] = sz
        ops[i+1] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        corr = np.real(gs.conj().T @ op_full @ gs)
        corrs.append(corr)
    fine = np.std(corrs) if corrs else 0.0
    return fine


def generate_paths_to_target(target_s, num_paths=10, steps=10, step_range=0.3, s_min=0.1, s_max=3.0):
    """生成多条随机路径，每条路径的终点都落在 target_s 上"""
    paths = []
    for _ in range(num_paths):
        path = [target_s]
        # 从 target_s 反向生成前 steps-1 个点，随机游走，最后回到 target_s
        for _ in range(steps - 1):
            delta = np.random.uniform(-step_range, step_range)
            next_s = np.clip(path[-1] + delta, s_min, s_max)
            path.append(next_s)
        # 保证终点是 target_s（可能最后一步会偏离，强制修正）
        path[-1] = target_s
        paths.append(path)
    return np.array(paths)

if __name__ == "__main__":
    N = 6
    contradiction_edge = (N//2 - 1, N//2)  # (2,3)
    
    # 选取一组 s 值（非简并点）
    target_s_values = [0.5, 1.0, 1.5, 2.0, 2.5]
    
    results = {}
    
    print("=== 命运注定性纯验证 ===")
    print(f"N={N}, 矛盾边={contradiction_edge}\n")
    
    for target_s in target_s_values:
        print(f"--- 目标 s = {target_s:.2f} ---")
        # 生成多条路径，每条路径最终到达 target_s
        paths = generate_paths_to_target(target_s, num_paths=8, steps=8, step_range=0.3)
        
        fine_values = []
        for idx, path in enumerate(paths):
            # 只取终点处的 s 值（即 path[-1]）
            # 但为了诊断，我们仍然记录整个路径，但比较的是终点
            s_end = path[-1]
            fine = compute_fine(N, contradiction_edge, s_end)
            fine_values.append(fine)
            print(f"  路径{idx+1}: 终点s={s_end:.2f}, fine={fine:.6f}")
        
        # 统计分析
        fine_array = np.array(fine_values)
        mean_fine = np.mean(fine_array)
        std_fine = np.std(fine_array)
        max_diff = np.max(fine_array) - np.min(fine_array)
        print(f"  统计: mean={mean_fine:.6f}, std={std_fine:.6f}, max_diff={max_diff:.6f}")
        
        if max_diff < 1e-4:
            print("  >> 判定: 注定（同一s下不同路径结果一致）")
        else:
            print("  >> 判定: 非注定（同一s下不同路径结果存在差异）")
        results[target_s] = {'fine': fine_values, 'mean': mean_fine, 'std': std_fine, 'max_diff': max_diff}
        print()
    
    # === 保存数据 ===
    with open('destiny_pure_results.csv', 'w') as f:
        f.write("target_s,path_index,fine\n")
        for target_s, data in results.items():
            for idx, fine in enumerate(data['fine']):
                f.write(f"{target_s:.2f},{idx+1},{fine:.6f}\n")
    
    # === 可视化：每个s值下的fine分布 ===
    fig, ax = plt.subplots(figsize=(10, 6))
    positions = []
    labels = []
    for i, (target_s, data) in enumerate(results.items()):
        positions.append(i)
        labels.append(f"s={target_s:.2f}")
        ax.scatter([i] * len(data['fine']), data['fine'], color='#1f77b4', s=30, alpha=0.7)
        ax.errorbar(i, data['mean'], yerr=data['std'], fmt='o', color='red', capsize=5)
    
    ax.set_xticks(positions)
    ax.set_xticklabels(labels)
    ax.set_ylabel('Fine diagnosis')
    ax.set_title('Destiny Test: Same s, different paths')
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('destiny_pure.png', dpi=150)
    
    # === 最终判定 ===
    all_max_diffs = [data['max_diff'] for data in results.values()]
    overall_max = max(all_max_diffs)
    print("\n=== 最终判定 ===")
    print(f"所有s值下，同一s不同路径的最大差异: {overall_max:.6f}")
    if overall_max < 1e-4:
        print("结论：系统状态仅由当前关系结构s决定，与历史路径无关。命运注定。")
    else:
        print("结论：系统状态受历史路径影响，命运并非完全注定。")
    print("\nDone. 数据已保存。")