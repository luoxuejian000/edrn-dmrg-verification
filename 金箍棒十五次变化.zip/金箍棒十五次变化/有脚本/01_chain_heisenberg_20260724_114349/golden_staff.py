"""
金箍棒 —— 五重公理自洽诊断器终极版
从任意关系图生成量子多体系统，支持多规则，内嵌完整五重公理。
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import networkx as nx

# =============================================
# 公理一：关系图工厂 & 编译为哈密顿量（内存安全版）
# =============================================
def build_graph(graph_type, N, **kwargs):
    """生成各种类型的关系图"""
    if graph_type == 'chain':
        G = nx.Graph()
        G.add_nodes_from(range(N))
        for i in range(N-1): G.add_edge(i, i+1, weight=1.0)
        return G
    elif graph_type == 'star':
        G = nx.star_graph(N-1)
        for u,v in G.edges(): G[u][v]['weight'] = 1.0
        return G
    elif graph_type == 'ring':
        G = nx.cycle_graph(N)
        for u,v in G.edges(): G[u][v]['weight'] = 1.0
        return G
    elif graph_type == 'small_world':
        k = kwargs.get('k', 4); p = kwargs.get('p', 0.1)
        G = nx.watts_strogatz_graph(N, k, p)
        for u,v in G.edges(): G[u][v]['weight'] = 1.0
        return G
    elif graph_type == 'fractal':
        level = kwargs.get('level', 2)
        return sierpinski_graph(level)
    elif graph_type == 'tree':
        r = kwargs.get('r', 2); h = kwargs.get('h', 2)
        G = nx.balanced_tree(r, h)
        for u,v in G.edges(): G[u][v]['weight'] = 1.0
        return G
    elif graph_type == 'random':
        p = kwargs.get('p', 0.3); seed = kwargs.get('seed', None)
        G = nx.erdos_renyi_graph(N, p, seed=seed)
        for u,v in G.edges(): G[u][v]['weight'] = 1.0
        return G
    else:
        raise ValueError(f"Unknown graph type: {graph_type}")

def sierpinski_graph(level):
    """Sierpinski 分形图生成器"""
    G = nx.Graph()
    def add_triangle(a,b,c):
        G.add_edge(a,b,weight=1.0); G.add_edge(b,c,weight=1.0); G.add_edge(c,a,weight=1.0)
    def rec(v1,v2,v3,depth):
        if depth==0: add_triangle(v1,v2,v3)
        else:
            m12=max(G.nodes)+1 if G.nodes else 0; G.add_node(m12)
            m23=m12+1; G.add_node(m23); m31=m23+1; G.add_node(m31)
            rec(v1,m12,m31,depth-1); rec(v2,m23,m12,depth-1); rec(v3,m31,m23,depth-1)
    G.add_nodes_from([0,1,2]); rec(0,1,2,level)
    return G

def graph_to_hamiltonian_sparse(G, rule='heisenberg', delta=1.0):
    """关系图编译为哈密顿量，支持 Heisenberg/Ising/XY/XXZ"""
    N = G.number_of_nodes()
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    for i, j, w in G.edges(data='weight'):
        w = w if w else 1.0
        for state in range(dim):
            bit_i = (state>>i)&1; bit_j = (state>>j)&1
            flipped = state ^ (1<<i) ^ (1<<j)
            if rule in ['heisenberg','xy','xxz']:
                H[state, flipped] += w
            if rule in ['heisenberg','ising','xxz']:
                zz = delta if rule=='xxz' else 1.0
                if bit_i==bit_j: H[state,state] += w*zz
                else: H[state,state] -= w*zz
    return H.tocsc()

# =============================================
# 公理二：矛盾动力论
# =============================================
def introduce_contradiction(G, edge, strength):
    G_mod = G.copy()
    if G_mod.has_edge(*edge): G_mod[edge[0]][edge[1]]['weight'] = strength
    else: G_mod.add_edge(edge[0], edge[1], weight=strength)
    return G_mod

# =============================================
# 公理三：诊断函数
# =============================================
def diagnose(G, rule='heisenberg', delta=1.0, num_eig=5):
    H = graph_to_hamiltonian_sparse(G, rule=rule, delta=delta)
    N = G.number_of_nodes()
    energies, states = eigsh(H, k=min(num_eig,2**N-1), which='SA')
    gap = energies[1]-energies[0] if len(energies)>1 else np.nan
    return energies, gap, states[:,0]

def coarse_diagnosis(N, gs):
    mag = 0.0; dim = len(gs)
    for state in range(dim):
        prob = np.abs(gs[state])**2
        bits = [(state>>k)&1 for k in range(N)]
        mag += prob * sum(1-2*b for b in bits)
    return abs(mag/N)

def fine_diagnosis(G, gs):
    N = G.number_of_nodes(); dim = len(gs); corrs = []
    for i,j in G.edges():
        corr = 0.0
        for state in range(dim):
            prob = np.abs(gs[state])**2
            bit_i = (state>>i)&1; bit_j = (state>>j)&1
            corr += prob * (1-2*bit_i) * (1-2*bit_j)
        corrs.append(corr)
    return np.std(corrs) if corrs else 0.0

# =============================================
# 公理四 & 五：探索流程 + 元反思审计
# =============================================
def explore(graph_type='chain', N=6, rule='heisenberg', delta=1.0,
            contradiction_edge=None, strengths=None):
    """矛盾强度扫描（公理四：让稳定点自然涌现）"""
    print(f"=== 金箍棒探索: {graph_type} N={N} rule={rule} ===")
    G = build_graph(graph_type, N)
    print(f"边数: {G.number_of_edges()}, 维度: {2**N}")
    if contradiction_edge is None:
        contradiction_edge = (0,1) if G.has_edge(0,1) else list(G.edges())[0]
    if strengths is None:
        strengths = np.linspace(0.0, 3.0, 9)

    gaps, coarse_vals, fine_vals, audit_gaps = [], [], [], []
    for s in strengths:
        G_mod = introduce_contradiction(G, contradiction_edge, s)
        _, gap, gs = diagnose(G_mod, rule=rule, delta=delta, num_eig=5)
        coarse = coarse_diagnosis(N, gs); fine = fine_diagnosis(G_mod, gs)
        _, gap2, _ = diagnose(G_mod, rule=rule, delta=delta, num_eig=6)
        gaps.append(gap); coarse_vals.append(coarse); fine_vals.append(fine)
        audit_gaps.append(abs(gap-gap2))
        print(f"  s={s:.2f}: gap={gap:.4f}, coarse={coarse:.4f}, fine={fine:.4f}, audit={audit_gaps[-1]:.6f}")

    np.savetxt('golden_staff_explore.csv',
               np.column_stack((strengths, gaps, coarse_vals, fine_vals, audit_gaps)),
               header='strength,gap,coarse,fine,audit', delimiter=',')
    fig, ax1 = plt.subplots(figsize=(10,6))
    ax1.plot(strengths, coarse_vals, 'o-', color='#1f77b4', label='Coarse')
    ax2 = ax1.twinx()
    ax2.plot(strengths, fine_vals, 's-', color='#d62728', label='Fine')
    ax1.set_xlabel('Contradiction strength'); ax1.legend(loc='upper left')
    ax2.legend(loc='upper right')
    plt.title(f'Golden Staff: {graph_type} N={N} rule={rule}')
    plt.tight_layout(); plt.savefig('golden_staff_explore.png', dpi=150)
    print("数据已保存。")

def explore_random(N=6, rule='heisenberg', delta=1.0, p_vals=None, seed=None):
    """连接概率扫描"""
    print(f"=== 金箍棒随机探索: N={N} rule={rule} ===")
    if p_vals is None: p_vals = np.linspace(0.1, 1.0, 10)
    gaps, coarse_vals, fine_vals, audit_gaps = [], [], [], []
    for p in p_vals:
        G = build_graph('random', N, p=p, seed=seed)
        if G.number_of_edges()==0:
            print(f"  p={p:.2f}: edges=0, SKIPPED")
            continue
        _, gap, gs = diagnose(G, rule=rule, delta=delta, num_eig=5)
        coarse = coarse_diagnosis(N, gs); fine = fine_diagnosis(G, gs)
        _, gap2, _ = diagnose(G, rule=rule, delta=delta, num_eig=6)
        gaps.append(gap); coarse_vals.append(coarse); fine_vals.append(fine)
        audit_gaps.append(abs(gap-gap2))
        print(f"  p={p:.2f}: gap={gap:.4f}, coarse={coarse:.4f}, fine={fine:.4f}, audit={audit_gaps[-1]:.6f}")
    np.savetxt('golden_staff_random.csv',
               np.column_stack((p_vals[:len(gaps)], gaps, coarse_vals, fine_vals, audit_gaps)),
               header='p,gap,coarse,fine,audit', delimiter=',')
    fig, ax1 = plt.subplots(figsize=(10,6))
    ax1.plot(p_vals[:len(gaps)], coarse_vals, 'o-', color='#1f77b4', label='Coarse')
    ax2 = ax1.twinx()
    ax2.plot(p_vals[:len(gaps)], fine_vals, 's-', color='#d62728', label='Fine')
    ax1.set_xlabel('Connection probability p'); ax1.legend(loc='upper left')
    ax2.legend(loc='upper right')
    plt.title(f'Golden Staff Random: N={N} rule={rule}')
    plt.tight_layout(); plt.savefig('golden_staff_random.png', dpi=150)
    print("数据已保存。")

if __name__ == "__main__":
    # 默认：链式图 + Heisenberg 规则，矛盾强度扫描
    explore(graph_type='chain', N=6, rule='heisenberg')
    # 可取消注释以探索其他模式：
    # explore(graph_type='fractal', N=15, rule='heisenberg')
    # explore_random(N=6, rule='heisenberg')
    # explore(graph_type='small_world', N=6, rule='ising')