"""
一键运行金箍棒所有实验，每个实验自动保存到独立文件夹
"""
import os
import sys
from datetime import datetime
from golden_staff import explore, explore_random

# 根输出目录 —— 改这里
BASE_DIR = r"D:\luoxuejian000\wulihuaxue\预言菜单二周期练\菜单二修改后论文及附录\寻找关系先于实体\金箍棒十五次变化"
os.makedirs(BASE_DIR, exist_ok=True)

# 所有实验配置列表
experiments = [
    # === 链式图系列 ===
    ("chain_heisenberg", lambda: explore(graph_type='chain', N=6, rule='heisenberg')),
    ("chain_ising",      lambda: explore(graph_type='chain', N=6, rule='ising')),
    ("chain_xy",         lambda: explore(graph_type='chain', N=6, rule='xy')),
    ("chain_xxz_d0.3",   lambda: explore(graph_type='chain', N=6, rule='xxz', delta=0.3)),
    ("chain_xxz_d2.0",   lambda: explore(graph_type='chain', N=6, rule='xxz', delta=2.0)),
    ("chain_N8",         lambda: explore(graph_type='chain', N=8, rule='heisenberg')),

    # === 分形图系列 ===
    ("fractal_edge02",   lambda: explore(graph_type='fractal', N=15, rule='heisenberg', contradiction_edge=(0,2))),
    ("fractal_edge01",   lambda: explore(graph_type='fractal', N=15, rule='heisenberg', contradiction_edge=(0,1))),

    # === 星形图 ===
    ("star",             lambda: explore(graph_type='star', N=6, rule='heisenberg')),

    # === 环形图 ===
    ("ring",             lambda: explore(graph_type='ring', N=6, rule='heisenberg')),

    # === 小世界图 ===
    ("small_world",      lambda: explore(graph_type='small_world', N=6, rule='heisenberg')),

    # === 随机图系列 ===
    ("random_heisenberg", lambda: explore_random(N=6, rule='heisenberg')),
    ("random_ising",      lambda: explore_random(N=6, rule='ising')),
    ("random_xy",         lambda: explore_random(N=6, rule='xy')),
    ("random_xxz_d0.3",   lambda: explore_random(N=6, rule='xxz', delta=0.3)),
]

total = len(experiments)
print(f"开始运行全部 {total} 个实验...")

for idx, (name, func) in enumerate(experiments, start=1):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    folder_name = f"{name}_{timestamp}"
    folder_path = os.path.join(BASE_DIR, folder_name)
    os.makedirs(folder_path, exist_ok=True)
    
    print(f"\n{'='*60}")
    print(f"实验 [{idx}/{total}]: {name}")
    print(f"保存路径: {folder_path}")
    print(f"{'='*60}")
    
    # 切换到目标文件夹运行实验
    original_cwd = os.getcwd()
    os.chdir(folder_path)
    try:
        func()
    finally:
        os.chdir(original_cwd)
    
    print(f"实验 [{idx}/{total}] 完成。")

print(f"\n全部实验结束。结果保存在: {BASE_DIR}")