"""
类内重复修正实验 —— 金箍棒 3.0 ED
针对随机树拓扑生成多个独立实例，统计谷底位置和深度的类内分布
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# =============================================
# 哈密顿量构建（泡利矩阵版，标准Heisenberg）
# =============================================
def build_hamiltonian_pauli(N, edges, contradiction_edge, contradiction_strength):
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)

    def to_full(op, site):
        ops = [I2] * N
        ops[site] = op
        result = ops[0]
        for k in range(1, N):
            result = np.kron(result, ops[k])
        return result

    for (i, j, w) in edges:
        if (i, j) == contradiction_edge or (j, i) == contradiction_edge:
            w = contradiction_strength
        H += w * (to_full(sx, i) @ to_full(sx, j)).real
        H += w * (to_full(sy, i) @ to_full(sy, j)).real
        H += w * (to_full(sz, i) @ to_full(sz, j)).real
    return H.tocsc()


def fine_diagnosis(N, edges, gs):
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    corrs = []
    for (i, j, w) in edges:
        ops = [I2] * N
        ops[i] = sz
        ops[j] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        corr = np.real(gs.conj().T @ op_full @ gs)
        corrs.append(corr)
    return np.std(corrs) if corrs else 0.0


def generate_random_tree_edges(N, seed):
    """生成随机树：节点0为根，依次连接新节点到已有随机节点"""
    np.random.seed(seed)
    edges = []
    for i in range(1, N):
        parent = np.random.randint(0, i)
        edges.append((parent, i, 1.0))
    return edges


def find_valley(N, edges, contradiction_edge, s_grid):
    """扫描s，返回谷底位置和深度，要求内部谷底"""
    fine_vals = []
    for s in s_grid:
        H = build_hamiltonian_pauli(N, edges, contradiction_edge, s)
        energies, states = eigsh(H, k=3, which='SA')
        gs = states[:, 0]
        fine = fine_diagnosis(N, edges, gs)
        fine_vals.append(fine)
    fine_vals = np.array(fine_vals)
    argmin = np.argmin(fine_vals)
    if argmin == 0 or argmin == len(fine_vals) - 1:
        return None, None  # 端点不是内部谷底
    # 深度定义为与两端最大值的平均差
    depth = 0.5 * ((fine_vals[0] - fine_vals[argmin]) + (fine_vals[-1] - fine_vals[argmin]))
    return s_grid[argmin], depth


if __name__ == "__main__":
    N = 7
    contradiction_edge = (0, 1)  # 随机树的固定矛盾边
    s_grid = np.linspace(0.0, 3.0, 151)
    
    # 生成10个独立随机树实例
    num_instances = 10
    positions = []
    depths = []
    fine_curves = []
    
    print(f"=== 类内重复修正：随机树 N={N}，实例数={num_instances} ===\n")
    
    for idx in range(num_instances):
        seed = 100 + idx * 7  # 用不同种子生成不同实例
        edges = generate_random_tree_edges(N, seed)
        pos, depth = find_valley(N, edges, contradiction_edge, s_grid)
        
        print(f"实例 {idx+1} (seed={seed}):")
        print(f"  谷底位置 s = {pos:.4f}" if pos is not None else "  未找到内部谷底")
        print(f"  谷底深度 = {depth:.6f}" if depth is not None else "")
        
        if pos is not None:
            positions.append(pos)
            depths.append(depth)
            
            # 重新扫描获取完整曲线（用于后续绘图）
            curve = []
            for s in s_grid:
                H = build_hamiltonian_pauli(N, edges, contradiction_edge, s)
                energies, states = eigsh(H, k=3, which='SA')
                gs = states[:, 0]
                curve.append(fine_diagnosis(N, edges, gs))
            fine_curves.append(curve)
    
    # 统计
    positions = np.array(positions)
    depths = np.array(depths)
    
    print("\n=== 类内统计 ===")
    print(f"有效实例数: {len(positions)}/{num_instances}")
    if len(positions) > 0:
        print(f"谷底位置: 中位数={np.median(positions):.4f}, 标准差={np.std(positions):.4f}")
        print(f"谷底位置四分位区间: [{np.percentile(positions,25):.4f}, {np.percentile(positions,75):.4f}]")
        print(f"谷底深度: 中位数={np.median(depths):.6f}, 标准差={np.std(depths):.6f}")
    
    # 保存所有曲线数据
    np.savez('random_tree_class_replication.npz',
             positions=positions, depths=depths,
             fine_curves=np.array(fine_curves),
             s_grid=s_grid)
    
    # 绘制所有实例的曲线
    if len(fine_curves) > 0:
        plt.figure(figsize=(10, 6))
        for curve in fine_curves:
            plt.plot(s_grid, curve, alpha=0.5, lw=1)
        plt.xlabel('s')
        plt.ylabel('Fine diagnosis')
        plt.title(f'Random Tree Class Replication (N={N}, {len(fine_curves)} instances)')
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig('random_tree_class_replication.png', dpi=150)
    
    print("\nDone. 数据已保存到 random_tree_class_replication.npz")