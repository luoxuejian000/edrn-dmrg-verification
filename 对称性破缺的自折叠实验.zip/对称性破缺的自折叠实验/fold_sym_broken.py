"""
对称性破缺的自折叠实验 —— 金箍棒 3.0 DMRG
在z方向加均匀磁场，打破Sz守恒，检验真正的"实体盲视"
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tenpy.models.model import CouplingMPOModel
from tenpy.models.lattice import Chain
from tenpy.networks.site import SpinHalfSite
from tenpy.networks.mps import MPS
from tenpy.algorithms import dmrg

class FoldModelSymBroken(CouplingMPOModel):
    """带z方向均匀磁场的链式Heisenberg模型，矛盾边可动态设置"""
    def __init__(self, model_params):
        L = model_params.get('L', 10)
        self.hz = model_params.get('hz', 0.1)
        self.contradiction_strength = model_params.get('contradiction_strength', 0.5)
        self.contradiction_edge = model_params.get('contradiction_edge', (L//2 - 1, L//2))
        lat = Chain(L, SpinHalfSite(conserve=None), bc='open')
        model_params['lattice'] = lat
        CouplingMPOModel.__init__(self, model_params)

    def init_terms(self, model_params=None):
        if model_params is None:
            model_params = {}
        L = self.lat.N_sites
        # 构建耦合强度数组（矛盾边用 contradiction_strength，其余用 1.0）
        J_arr = np.ones(L - 1)
        edge_i, edge_j = self.contradiction_edge
        if 0 <= edge_i < L - 1:
            J_arr[edge_i] = self.contradiction_strength
        # XX+YY 项 (非对角)，数组形式与 destiny_test.py 一致
        self.add_coupling(J_arr * 0.5, 0, 'Sp', 0, 'Sm', dx=[1], plus_hc=True)
        # ZZ 项 (对角)
        self.add_coupling(J_arr, 0, 'Sz', 0, 'Sz', dx=[1])
        # z方向均匀磁场（破缺项）
        for i in range(L):
            self.add_onsite_term(-self.hz, i, 'Sz')


def compute_diagnostics_sym_broken(L, contradiction_edge, s, hz=0.1, chi_max=100):
    """计算对称性破缺下的基态诊断数据，同时返回边关联列表"""
    M = FoldModelSymBroken(dict(
        L=L, contradiction_edge=contradiction_edge,
        contradiction_strength=s, hz=hz
    ))
    init = ['up'] * L
    psi = MPS.from_product_state(M.lat.mps_sites(), init, bc='finite')
    dmrg_params = {'mixer': True, 'chi_max': chi_max, 'max_sweeps': 50, 'verbose': 0}
    eng = dmrg.run(psi, M, dmrg_params)
    E0 = eng['E']

    init_ex = init.copy()
    center = L // 2
    init_ex[center] = 'down' if init_ex[center] == 'up' else 'up'
    psi_ex = MPS.from_product_state(M.lat.mps_sites(), init_ex, bc='finite')
    eng_ex = dmrg.run(psi_ex, M, dmrg_params)
    E1 = eng_ex['E']
    gap = E1 - E0

    Sz = psi.expectation_value('Sz')
    coarse = np.mean(np.abs(Sz))
    corrs = []
    for i in range(L - 1):
        corr = psi.correlation_function('Sz', 'Sz', [i], [i+1])
        corrs.append(corr[0])
    fine = np.std(corrs) if corrs else 0.0
    return gap, coarse, fine, corrs


def find_max_correlation_edge(corrs):
    abs_corrs = np.abs(corrs)
    max_idx = np.argmax(abs_corrs)
    return (max_idx, max_idx + 1)


def run_fold_sym_broken(L=10, fold_steps=30, s=0.5, hz=0.1, epsilon=0.1, seed=42, chi_max=100):
    """对称性破缺下的关系场自折叠实验"""
    np.random.seed(seed)
    gaps, coarse_vals, fine_vals = [], [], []
    current_edge = (L//2 - 1, L//2)

    for step in range(fold_steps):
        gap, coarse, fine, corrs = compute_diagnostics_sym_broken(
            L, current_edge, s, hz, chi_max
        )
        gaps.append(gap)
        coarse_vals.append(coarse)
        fine_vals.append(fine)
        print(f"Step {step}: edge={current_edge}, gap={gap:.6f}, coarse={coarse:.6f}, fine={fine:.6f}")

        if np.random.rand() < epsilon:
            i = np.random.randint(0, L-1)
            next_edge = (i, i+1)
        else:
            next_edge = find_max_correlation_edge(corrs)
        current_edge = next_edge

    return np.array(gaps), np.array(coarse_vals), np.array(fine_vals)


if __name__ == "__main__":
    L = 10
    fold_steps = 30
    hz = 0.1
    epsilon = 0.1
    print(f"=== 对称性破缺的自折叠实验 (L={L}, hz={hz}, epsilon={epsilon}) ===")
    gaps, coarse_vals, fine_vals = run_fold_sym_broken(
        L, fold_steps, s=0.5, hz=hz, epsilon=epsilon, seed=42
    )

    np.savetxt('fold_sym_broken_results.csv',
               np.column_stack((np.arange(fold_steps), gaps, coarse_vals, fine_vals)),
               header='step,gap,coarse,fine', delimiter=',')

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
    steps = np.arange(fold_steps)
    ax1.plot(steps, coarse_vals, 'o-', label='Default diagnosis (coarse)', color='#1f77b4')
    ax1.set_xlabel('Fold step')
    ax1.set_ylabel('Coarse metric')
    ax1.set_title('Default Diagnosis (Entity Blindness Test)')
    ax1.grid(True, alpha=0.3)

    ax2.plot(steps, fine_vals, 's-', label='Enhanced diagnosis (fine)', color='#d62728')
    ax2.set_xlabel('Fold step')
    ax2.set_ylabel('Fine metric')
    ax2.set_title('Enhanced Diagnosis (Structure Explorer)')
    ax2.grid(True, alpha=0.3)

    plt.suptitle(f'Symmetry-Broken Self-Folding (L={L}, hz={hz}, epsilon={epsilon})')
    plt.tight_layout()
    plt.savefig('fold_sym_broken_diagnosis.png', dpi=150)
    print("Done. Data saved.")
