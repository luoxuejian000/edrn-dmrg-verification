"""
BKT-稳定岛探索器（修复版）：在XXZ链的超精细扫描中寻找“表面光滑”信号
修复内容：
1. 修正哈密顿量构建中的维度错误，确保to_full正确扩展到2^N维
2. 增加ARPACK迭代次数，并采用shift-invert模式提升收敛性
3. 添加扫描进度保存与断点续跑支持
遵循晶脉哲学五重公理：关系本体论、矛盾动力论、实践介入论、谐振调谐论、元反思律
"""
import numpy as np
from scipy.sparse import lil_matrix, csc_matrix
from scipy.sparse.linalg import eigsh
import matplotlib.pyplot as plt
import os, sys

# ==========================================
# 1. XXZ 哈密顿量构建（修复版）
# ==========================================
def build_xxz_hamiltonian(N, delta, defect_edge=None, defect_strength=1.0):
    """构建一维XXZ模型，返回稀疏矩阵"""
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)

    # 关键修复：使用显式kron循环构建全空间算符，确保维度正确
    for i in range(N - 1):
        J = defect_strength if (defect_edge is not None and ((i, i+1) == defect_edge or (i+1, i) == defect_edge)) else 1.0

        # 构建 σ^x_i σ^x_{i+1} 的全空间矩阵
        op_list = [I2] * N
        op_list[i] = sx
        op_list[i+1] = sx
        mat = op_list[0]
        for k in range(1, N):
            mat = np.kron(mat, op_list[k])
        H += J * mat.real

        # 构建 σ^y_i σ^y_{i+1} 的全空间矩阵
        op_list = [I2] * N
        op_list[i] = sy
        op_list[i+1] = sy
        mat = op_list[0]
        for k in range(1, N):
            mat = np.kron(mat, op_list[k])
        H += J * mat.real

        # 构建 σ^z_i σ^z_{i+1} 的全空间矩阵
        op_list = [I2] * N
        op_list[i] = sz
        op_list[i+1] = sz
        mat = op_list[0]
        for k in range(1, N):
            mat = np.kron(mat, op_list[k])
        H += J * delta * mat.real

    return H.tocsc()


def compute_observables(N, delta, defect_edge=None, defect_strength=1.0, v0=None):
    """
    计算基态可观测量：能隙、默认诊断(平均磁化)、增强诊断(关联涨落标准差)
    使用shift-invert模式以提升收敛性，并返回新的初始向量供下次使用
    """
    H = build_xxz_hamiltonian(N, delta, defect_edge, defect_strength)

    # 使用shift-invert模式：求解最接近0能量的本征值，收敛更稳定
    try:
        energies, states = eigsh(H, k=2, sigma=0.0, which='LM', v0=v0, maxiter=2000, tol=1e-10)
    except Exception:
        # 如果shift-invert失败，尝试标准模式
        energies, states = eigsh(H, k=2, which='SA', v0=v0, maxiter=3000, tol=1e-10)

    gap = energies[1] - energies[0] if len(energies) > 1 else 0.0
    gs = states[:, 0]

    # 默认诊断：平均磁化强度
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    mag = 0.0
    for i in range(N):
        op_list = [I2] * N
        op_list[i] = sz
        mat = op_list[0]
        for k in range(1, N):
            mat = np.kron(mat, op_list[k])
        mag += np.real(gs.conj().T @ mat @ gs)
    coarse = abs(mag / N)

    # 增强诊断：最近邻自旋关联的标准差
    corrs = []
    for i in range(N - 1):
        op_list = [I2] * N
        op_list[i] = sz
        op_list[i+1] = sz
        mat = op_list[0]
        for k in range(1, N):
            mat = np.kron(mat, op_list[k])
        corrs.append(np.real(gs.conj().T @ mat @ gs))
    fine = np.std(corrs) if corrs else 0.0

    return gap, coarse, fine, gs  # 返回基态向量，用于热启动


# ==========================================
# 2. 超精细扫描（带进度与备份）
# ==========================================
def run_ultra_fine_scan(N, delta_vals, defect_edge=None, defect_strength=1.0, backup_file="scan_backup.npz"):
    """执行超精细扫描，支持断点续跑"""
    n_points = len(delta_vals)
    fine_vals = np.zeros(n_points)
    coarse_vals = np.zeros(n_points)
    gaps = np.zeros(n_points)
    v0 = None  # 热启动初始向量

    start_idx = 0
    # 如果存在备份文件，则从断点恢复
    if os.path.exists(backup_file):
        data = np.load(backup_file)
        saved_idx = data['idx']
        fine_vals[:saved_idx] = data['fine']
        coarse_vals[:saved_idx] = data['coarse']
        gaps[:saved_idx] = data['gaps']
        start_idx = saved_idx
        print(f"从断点恢复，已计算 {start_idx}/{n_points} 个点")

    for idx in range(start_idx, n_points):
        delta = delta_vals[idx]
        gap, coarse, fine, v0 = compute_observables(N, delta, defect_edge, defect_strength, v0)
        gaps[idx] = gap
        coarse_vals[idx] = coarse
        fine_vals[idx] = fine

        if idx % 1000 == 0 or idx == n_points - 1:
            print(f"  进度: {idx}/{n_points}, Δ={delta:.4f}, fine={fine:.6f}, gap={gap:.6f}")
            # 定期保存备份
            np.savez(backup_file, idx=idx+1, fine=fine_vals[:idx+1],
                     coarse=coarse_vals[:idx+1], gaps=gaps[:idx+1], delta_vals=delta_vals[:idx+1])

    return gaps, coarse_vals, fine_vals


# ==========================================
# 3. 稳定岛探测器
# ==========================================
def find_stable_islands(delta_vals, fine_vals, global_std, window_size=50, rel_threshold=0.05):
    """基于局部标准差的稳定岛检测"""
    islands = []
    half_win = window_size // 2
    n_points = len(fine_vals)
    local_std = np.zeros(n_points)
    for i in range(n_points):
        start = max(0, i - half_win)
        end = min(n_points, i + half_win)
        local_std[i] = np.std(fine_vals[start:end])

    abs_threshold = global_std * rel_threshold
    is_calm = local_std < abs_threshold

    in_island = False
    start = 0.0
    for i in range(1, n_points):
        if is_calm[i] and not is_calm[i-1]:
            start = delta_vals[i]
            in_island = True
        elif not is_calm[i] and is_calm[i-1] and in_island:
            end = delta_vals[i-1]
            width = end - start
            if width > 0.02:  # 最小宽度过滤
                mask = (delta_vals >= start) & (delta_vals <= end)
                islands.append({
                    'start': start,
                    'end': end,
                    'width': width,
                    'mean_fine': np.mean(fine_vals[mask]),
                    'local_std': np.mean(local_std[mask])
                })
            in_island = False
    return islands, local_std


# ==========================================
# 主程序
# ==========================================
if __name__ == "__main__":
    N = 6
    DELTA_START = -1.5
    DELTA_END = 1.5
    STEP = 0.0002          # 超精细步长
    delta_vals = np.arange(DELTA_START, DELTA_END + STEP, STEP)

    print(f"====== BKT-稳定岛探索器（修复版）======")
    print(f"XXZ链 N={N}, Δ ∈ [{DELTA_START}, {DELTA_END}], 步长={STEP}, 采样点={len(delta_vals)}")
    print("正在执行超精细扫描...")

    gaps, coarse_vals, fine_vals = run_ultra_fine_scan(N, delta_vals)

    global_std = np.std(fine_vals)
    print(f"全局精细诊断标准差 σ = {global_std:.6f}")

    islands, local_std = find_stable_islands(delta_vals, fine_vals, global_std)
    print(f"\n发现候选稳定岛: {len(islands)} 个")
    for i, island in enumerate(islands):
        print(f"  岛{i+1}: Δ ∈ [{island['start']:.4f}, {island['end']:.4f}], 宽度={island['width']:.4f}, 局部σ={island['local_std']:.6f}")

    # 可视化
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    axes[0,0].plot(delta_vals, fine_vals, lw=0.5)
    for island in islands:
        axes[0,0].axvspan(island['start'], island['end'], alpha=0.3, color='red')
    axes[0,0].set_title('Fine Diagnosis')
    axes[0,1].plot(delta_vals, local_std, lw=0.5)
    axes[0,1].axhline(global_std*0.05, color='red', ls='--', label='5% global std')
    axes[0,1].set_title('Local Stability (Local Std)')
    axes[0,1].legend()
    axes[1,0].plot(delta_vals, coarse_vals, lw=0.5)
    axes[1,0].set_title('Coarse Diagnosis')
    axes[1,1].plot(delta_vals, gaps, lw=0.5)
    axes[1,1].set_title('Energy Gap')
    plt.suptitle(f'BKT-Stable Islands in XXZ Chain (N={N})')
    plt.tight_layout()
    plt.savefig('bkt_stable_islands.png', dpi=150)
    plt.show()
    print("实验完成。")