"""
拓扑序沉默失谐诊断 —— 金箍棒编译器
检验文小刚拓扑序框架与沉默失谐的深层关联
分形图(N=15)、环状图(N=15)、树状图(N=15)
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import networkx as nx

# =============================================
# 公理一：关系图生成
# =============================================
def sierpinski_graph(level=2):
    """生成 Sierpinski 分形图（N=15, 27条边, 32768维）"""
    G = nx.Graph()
    def add_triangle(a, b, c):
        G.add_edge(a, b, weight=1.0)
        G.add_edge(b, c, weight=1.0)
        G.add_edge(c, a, weight=1.0)
    def rec(v1, v2, v3, depth):
        if depth == 0:
            add_triangle(v1, v2, v3)
        else:
            m12 = max(G.nodes) + 1 if G.nodes else 0
            G.add_node(m12)
            m23 = m12 + 1
            G.add_node(m23)
            m31 = m23 + 1
            G.add_node(m31)
            rec(v1, m12, m31, depth-1)
            rec(v2, m23, m12, depth-1)
            rec(v3, m31, m23, depth-1)
    G.add_nodes_from([0, 1, 2])
    rec(0, 1, 2, level)
    return G

def ring_graph(N=15):
    """生成环状图（N=15, 15条边）"""
    G = nx.cycle_graph(N)
    for u, v in G.edges():
        G[u][v]['weight'] = 1.0
    return G

def tree_graph(r=2, h=3):
    """生成树状图（2叉树, N=15, 14条边, 无环）"""
    G = nx.balanced_tree(r, h)
    G = G.subgraph(range(15)).copy()
    for u, v in G.edges():
        G[u][v]['weight'] = 1.0
    return G

# =============================================
# 公理一（续）：哈密顿量编译（内存安全版）
# =============================================
def graph_to_hamiltonian_sparse(G, contradiction_edge, contradiction_strength):
    """关系图编译为 Heisenberg 哈密顿量（XX+YY+ZZ）"""
    N = G.number_of_nodes()
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    for i, j, w in G.edges(data='weight'):
        w = w if w else 1.0
        if (i, j) == contradiction_edge or (j, i) == contradiction_edge:
            w = contradiction_strength
        for state in range(dim):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            flipped = state ^ (1 << i) ^ (1 << j)
            H[state, flipped] += w
            if bit_i == bit_j:
                H[state, state] += w
            else:
                H[state, state] -= w
    return H.tocsc()

# =============================================
# 公理三：沉默失谐诊断（默认+增强）
# =============================================
def diagnose(G, contradiction_edge, s, num_eig=5):
    """求解基态和低激发态，返回能隙、默认诊断、增强诊断、低能谱"""
    H = graph_to_hamiltonian_sparse(G, contradiction_edge, s)
    N = G.number_of_nodes()
    energies, states = eigsh(H, k=min(num_eig, 2**N-1), which='SA')
    gap = energies[1] - energies[0] if len(energies) > 1 else np.nan
    gs = states[:, 0]

    # 默认诊断：平均磁化
    mag = 0.0
    dim = len(gs)
    for state in range(dim):
        prob = np.abs(gs[state])**2
        bits = [(state >> k) & 1 for k in range(N)]
        magnetization = sum(1 - 2*b for b in bits)
        mag += prob * magnetization
    coarse = abs(mag / N)

    # 增强诊断：边关联涨落标准差
    corrs = []
    for i, j in G.edges():
        corr = 0.0
        for state in range(dim):
            prob = np.abs(gs[state])**2
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            corr += prob * (1 - 2*bit_i) * (1 - 2*bit_j)
        corrs.append(corr)
    fine = np.std(corrs) if corrs else 0.0

    # 拓扑诊断：基态简并度（通过低能谱判断）
    degeneracy = 1
    for k in range(1, len(energies)):
        if energies[k] - energies[0] < 1e-6:
            degeneracy += 1
        else:
            break

    return gap, coarse, fine, energies[:num_eig], degeneracy


# =============================================
# 公理二+四：主扫描流程
# =============================================
def run_topology_scan(strengths=None):
    """对分形图、环状图、树状图分别扫描矛盾强度"""
    if strengths is None:
        strengths = np.linspace(0.0, 3.0, 13)

    # 定义三种关系图和对应的矛盾边
    configs = [
        ("fractal", sierpinski_graph(level=2), (0, 2)),
        ("ring", ring_graph(N=15), (7, 8)),
        ("tree", tree_graph(r=2, h=3), (0, 1)),
    ]

    results = {}

    for name, G, contradiction_edge in configs:
        N = G.number_of_nodes()
        edges_count = G.number_of_edges()
        print(f"\n=== {name} (N={N}, edges={edges_count}) ===")

        gaps, coarse_vals, fine_vals = [], [], []
        degeneracies = []
        low_spectra = []

        for s in strengths:
            gap, coarse, fine, spectrum, degen = diagnose(G, contradiction_edge, s, num_eig=5)
            gaps.append(gap)
            coarse_vals.append(coarse)
            fine_vals.append(fine)
            degeneracies.append(degen)
            low_spectra.append(spectrum)
            print(f"s={s:.2f}: gap={gap:.6f}, coarse={coarse:.4f}, fine={fine:.4f}, degen={degen}")

        results[name] = {
            'strengths': strengths,
            'gaps': np.array(gaps),
            'coarse': np.array(coarse_vals),
            'fine': np.array(fine_vals),
            'degeneracies': degeneracies,
            'low_spectra': low_spectra,
            'N': N,
            'edges': edges_count
        }

        # 保存 CSV
        csv_name = f"topology_{name}_N{N}.csv"
        np.savetxt(csv_name,
                   np.column_stack((strengths, gaps, coarse_vals, fine_vals, degeneracies)),
                   header='strength,gap,coarse,fine,degeneracy', delimiter=',')
        print(f"数据已保存: {csv_name}")

    # 并排诊断图
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    for ax, (name, data) in zip(axes, results.items()):
        ax_ = ax.twinx()
        ax.plot(data['strengths'], data['coarse'], 'o-', label='Default')
        ax_.plot(data['strengths'], data['fine'], 's-', color='red', label='Enhanced')
        ax.set_xlabel('s')
        ax.set_ylabel('Default metric')
        ax_.set_ylabel('Enhanced metric')
        ax.set_title(f'{name} (N={data["N"]})')
        ax.legend(loc='upper left')
        ax_.legend(loc='upper right')
        ax.grid(True, alpha=0.3)
    plt.suptitle('Silent Discordance across Different Topologies')
    plt.tight_layout()
    plt.savefig('topology_comparison.png', dpi=150)
    print("\n诊断图已保存: topology_comparison.png")

    return results


if __name__ == "__main__":
    strengths = np.linspace(0.0, 3.0, 13)
    run_topology_scan(strengths)