"""
黎曼零点沉默失谐诊断 —— 献给希尔伯特-波利亚猜想的数值献礼
检验：黎曼ζ函数零点的统计涨落中，是否隐藏着“关系场重组”的临界特征？
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.interpolate import UnivariateSpline

# =============================================
# 公理一：关系本体论 —— 黎曼零点作为“关系场”的本征值
# =============================================
def get_riemann_zeros(N):
    """
    获取前N个黎曼ζ函数非平凡零点（虚部为正）
    使用 mpmath 库，如果不可用则使用近似公式
    """
    try:
        from mpmath import zetazero
        zeros = [float(zetazero(k).imag) for k in range(1, N+1)]
        return np.array(zeros)
    except ImportError:
        print("mpmath not installed. Using GUE approximation for Riemann zeros.")
        # 使用高斯酉系综(GUE)的Wigner半圆律近似黎曼零点分布
        # 黎曼零点的平均密度: N(T) ~ (T/2π) log(T/2π) - T/2π
        # 这里用一个简化的GUE生成器来模拟零点
        return generate_gue_zeros(N)


def generate_gue_zeros(N, seed=42):
    """
    生成符合GUE统计的“模拟黎曼零点”
    黎曼零点的统计性质与GUE随机矩阵的本征值高度吻合
    """
    np.random.seed(seed)
    # GUE矩阵的维度需要足够大才能产生稳定的统计
    dim = max(N * 5, 100)
    # 生成GUE矩阵: H = (A + A†)/2, 其中A是复高斯随机矩阵
    A = np.random.randn(dim, dim) + 1j * np.random.randn(dim, dim)
    H = (A + A.conj().T) / 2
    eigenvalues = np.linalg.eigvalsh(H)
    # GUE本征值在[-sqrt(2*dim), sqrt(2*dim)]范围内
    # 黎曼零点的平均间距在高度T处约为 2π/log(T/2π)
    # 这里简单取前N个正本征值作为“模拟零点”
    eigenvalues = np.sort(eigenvalues)
    # 映射到正半轴
    eigenvalues = eigenvalues[eigenvalues > 0]
    # 取前N个
    return eigenvalues[:N]


# =============================================
# 公理三：实践介入论 —— 默认诊断与增强诊断
# =============================================
def compute_diagnostics(zeros, window_size):
    """
    在给定的“尺度窗口”下，计算零点间距涨落的诊断指标
    
    参数:
        zeros: 黎曼零点（虚部值）
        window_size: 滑动窗口的大小（包含的零点数量）
    
    返回:
        default_metric: 默认诊断（零点密度的平滑趋势）
        enhanced_metric: 增强诊断（窗口内零点间距涨落的标准差）
    """
    N = len(zeros)
    # 计算零点间距
    spacings = np.diff(zeros)
    
    # 默认诊断：零点密度的局部平均值（平滑、粗粒化）
    default_metrics = []
    # 增强诊断：窗口内间距涨落的标准差（对关联结构敏感）
    enhanced_metrics = []
    
    for i in range(N - window_size):
        window_spacings = spacings[i:i+window_size]
        # 默认诊断：窗口内的平均间距（平滑趋势）
        default_metrics.append(np.mean(window_spacings))
        # 增强诊断：窗口内间距的标准差（涨落）
        enhanced_metrics.append(np.std(window_spacings))
    
    # 计算“矛盾强度”——窗口中心的高度T
    T_values = zeros[window_size//2 : N - window_size//2]
    
    return np.array(T_values), np.array(default_metrics), np.array(enhanced_metrics)


# =============================================
# 公理四：谐振调谐论 —— 扫描窗口尺度，寻找临界点
# =============================================
def scan_window_sizes(zeros, window_sizes):
    """
    扫描不同的窗口尺度，寻找增强诊断的非单调响应
    """
    results = {}
    for w in window_sizes:
        T_vals, default_metric, enhanced_metric = compute_diagnostics(zeros, w)
        results[w] = (T_vals, default_metric, enhanced_metric)
    return results


# =============================================
# 主程序
# =============================================
if __name__ == "__main__":
    print("=== 黎曼零点沉默失谐诊断 ===")
    print("检验：零点间距涨落中是否隐藏着关系场重组的临界特征？\n")
    
    # 获取前N个黎曼零点
    N = 500
    print(f"获取前{N}个黎曼零点...")
    zeros = get_riemann_zeros(N)
    print(f"零点范围: [{zeros[0]:.2f}, {zeros[-1]:.2f}]")
    
    # 扫描不同的窗口尺度（模拟“矛盾强度”扫描）
    window_sizes = [5, 10, 20, 30, 50, 75, 100, 150, 200]
    
    print("\n扫描窗口尺度...")
    results = scan_window_sizes(zeros, window_sizes)
    
    # 寻找增强诊断的非单调特征
    # 对每个窗口，计算增强诊断的峰度（衡量非单调性）
    print("\n=== 诊断报告 ===")
    for w in window_sizes:
        T_vals, default_metric, enhanced_metric = results[w]
        # 计算增强诊断的波动幅度
        fluctuation = np.std(enhanced_metric) / np.mean(enhanced_metric)
        print(f"窗口大小={w:3d}: 增强诊断波动幅度={fluctuation:.4f}")
    
    # 绘制诊断图
    fig, axes = plt.subplots(2, 3, figsize=(18, 10))
    for idx, w in enumerate([10, 30, 50, 100, 150, 200]):
        ax = axes[idx//3, idx%3]
        T_vals, default_metric, enhanced_metric = results[w]
        ax.plot(T_vals, enhanced_metric, 'o-', markersize=2, label=f'Enhanced (w={w})')
        ax.set_xlabel('Height T')
        ax.set_ylabel('Enhanced metric')
        ax.set_title(f'Window size = {w}')
        ax.grid(True, alpha=0.3)
    
    plt.suptitle(f'Riemann Zeros Silent Discordance Diagnosis (N={N})', fontsize=14)
    plt.tight_layout()
    plt.savefig('riemann_silent_discordance.png', dpi=150)
    print("\n诊断图已保存: riemann_silent_discordance.png")
