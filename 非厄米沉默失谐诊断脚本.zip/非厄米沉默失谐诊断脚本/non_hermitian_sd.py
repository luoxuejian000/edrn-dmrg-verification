"""
非厄米沉默失谐诊断 —— 献给龚明教授团队的学术回礼
检验：自恢复态的涌现是否伴随关系场的突变性重组？
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh

def build_non_hermitian_hamiltonian(N, gamma, contradiction_edge, contradiction_strength):
    """
    构建非厄米自旋链哈密顿量
    H = H_Heisenberg + i*gamma*Sz_1 (虚数边界势模拟增益/损耗)
    """
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=complex)
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    
    def to_full(op, site):
        ops = [I2] * N
        ops[site] = op
        result = ops[0]
        for k in range(1, N):
            result = np.kron(result, ops[k])
        return result
    
    # 自旋-自旋相互作用
    for i in range(N-1):
        J = contradiction_strength if (i, i+1) == contradiction_edge or (i+1, i) == contradiction_edge else 1.0
        H += J * (to_full(sx, i) @ to_full(sx, j := i+1))
        H += J * (to_full(sy, i) @ to_full(sy, j))
        H += J * (to_full(sz, i) @ to_full(sz, j))
    
    # 非厄米项：虚数边界势
    H += 1j * gamma * to_full(sz, 0)
    
    return H.tocsc()


def compute_diagnostics(N, gamma, contradiction_edge, s, num_eig=5):
    """计算非厄米系统的本征态和诊断指标"""
    H = build_non_hermitian_hamiltonian(N, gamma, contradiction_edge, s)
    energies, states = eigsh(H, k=min(num_eig, 2**N-1), which='SR')
    
    # 取虚部最大的本征态（模拟“主导传播态”）
    imag_parts = np.imag(energies)
    dominant_idx = np.argmax(imag_parts)
    gs = states[:, dominant_idx]
    
    gap = np.abs(energies[1] - energies[0]) if len(energies) > 1 else np.nan
    
    # 默认诊断：平均磁化
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    mag = 0.0
    for i in range(N):
        ops = [I2] * N
        ops[i] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        mag += np.real(gs.conj().T @ op_full @ gs)
    coarse = abs(mag / N)
    
    # 精细诊断：边关联涨落标准差
    corrs = []
    for i in range(N-1):
        ops = [I2] * N
        ops[i] = sz
        ops[i+1] = sz
        op_full = ops[0]
        for k in range(1, N):
            op_full = np.kron(op_full, ops[k])
        corr = np.real(gs.conj().T @ op_full @ gs)
        corrs.append(corr)
    fine = np.std(corrs) if corrs else 0.0
    
    return gap, coarse, fine

if __name__ == "__main__":
    N = 8
    contradiction_edge = (N//2 - 1, N//2)
    s = 1.0
    
    # 扫描非厄米参数γ
    gamma_values = np.linspace(0.0, 2.0, 21)
    gaps, coarse_vals, fine_vals = [], [], []
    
    print(f"=== 非厄米沉默失谐诊断 (N={N}) ===")
    print("扫描虚数边界势γ，寻找自恢复态涌现的沉默失谐信号\n")
    
    for gamma in gamma_values:
        gap, coarse, fine = compute_diagnostics(N, gamma, contradiction_edge, s)
        gaps.append(gap)
        coarse_vals.append(coarse)
        fine_vals.append(fine)
        print(f"γ={gamma:.2f}: gap={gap:.6f}, coarse={coarse:.4f}, fine={fine:.6f}")
    
    # 保存数据
    np.savetxt('non_hermitian_sd_results.csv', 
               np.column_stack((gamma_values, gaps, coarse_vals, fine_vals)), 
               header='gamma,gap,coarse,fine', delimiter=',')
    
    # 沉默失谐诊断图
    fig, ax1 = plt.subplots(figsize=(10, 6))
    ax1.plot(gamma_values, coarse_vals, 'o-', label='Default diagnosis (coarse)', color='#1f77b4')
    ax1.set_xlabel('γ (boundary potential strength)')
    ax1.set_ylabel('Default metric', color='#1f77b4')
    ax1.tick_params(axis='y', labelcolor='#1f77b4')
    
    ax2 = ax1.twinx()
    ax2.plot(gamma_values, fine_vals, 's-', label='Enhanced diagnosis (fine)', color='#d62728')
    ax2.set_ylabel('Enhanced metric', color='#d62728')
    ax2.tick_params(axis='y', labelcolor='#d62728')
    
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1+lines2, labels1+labels2, loc='upper left')
    
    plt.title(f'Non-Hermitian Silent Discordance (N={N})')
    plt.tight_layout()
    plt.savefig('non_hermitian_sd_diagnosis.png', dpi=150)
    
    print("\nDone. 数据已保存。")