"""
树状图量子系统 —— 纯粹探索玩具
从树状关系图生成量子多体系统，无预设目标诊断。
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import networkx as nx

# =============================================
# 公理一：树状图生成 & 编译为哈密顿量（内存安全版）
# =============================================
def tree_graph(r=2, h=3):
    """生成平衡树状图 (r叉树, 高度h, 节点数约 (r^(h+1)-1)/(r-1))"""
    G = nx.balanced_tree(r, h)
    for u, v in G.edges():
        G[u][v]['weight'] = 1.0
    return G

def graph_to_hamiltonian_sparse(G):
    """
    关系图编译为量子哈密顿量 (每条边 → XX+YY+ZZ)
    内存安全版本：遍历计算基矢，直接填充稀疏矩阵
    """
    N = G.number_of_nodes()
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    for i, j, w in G.edges(data='weight'):
        w = w if w else 1.0
        for state in range(dim):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            # XX + YY 项：翻转两个自旋
            flipped_state = state ^ (1 << i) ^ (1 << j)
            H[state, flipped_state] += w
            # ZZ 项：对角贡献
            if bit_i == bit_j:
                H[state, state] += w
            else:
                H[state, state] -= w
    return H.tocsc()

# =============================================
# 公理二：矛盾动力论 —— 植入矛盾边
# =============================================
def introduce_contradiction(G, edge, strength):
    G_mod = G.copy()
    if G_mod.has_edge(*edge):
        G_mod[edge[0]][edge[1]]['weight'] = strength
    else:
        G_mod.add_edge(edge[0], edge[1], weight=strength)
    return G_mod

# =============================================
# 公理三：实践介入论 —— 粗粒化与精细诊断
# =============================================
def diagnose(G, num_eig=5):
    H = graph_to_hamiltonian_sparse(G)
    N = G.number_of_nodes()
    energies, states = eigsh(H, k=min(num_eig, 2**N-1), which='SA')
    gap = energies[1] - energies[0] if len(energies) > 1 else np.nan
    return energies, gap, states[:, 0]

def coarse_diagnosis(N, gs):
    """粗粒化诊断：平均磁化（从波函数直接计算）"""
    mag = 0.0
    dim = len(gs)
    for state in range(dim):
        prob = np.abs(gs[state])**2
        bits = [(state >> k) & 1 for k in range(N)]
        magnetization = sum(1 - 2*b for b in bits)
        mag += prob * magnetization
    return abs(mag / N)

def fine_diagnosis(G, gs):
    """精细诊断：边关联涨落（标准差）"""
    N = G.number_of_nodes()
    dim = len(gs)
    corrs = []
    for i, j in G.edges():
        corr = 0.0
        for state in range(dim):
            prob = np.abs(gs[state])**2
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            corr += prob * (1 - 2*bit_i) * (1 - 2*bit_j)
        corrs.append(corr)
    return np.std(corrs) if corrs else 0.0

# =============================================
# 公理四 & 五：谐振调谐 + 元反思审计 + 探索入口
# =============================================
def explore_tree(r=2, h=2, contradiction_edge=None, strengths=None):
    """纯粹探索：扫描矛盾强度，观察树状量子系统的响应"""
    print(f"=== 树状图量子系统探索 (r={r}, h={h}) ===")
    G = tree_graph(r, h)
    N = G.number_of_nodes()
    print(f"节点数: {N}, 边数: {G.number_of_edges()}, 维度: {2**N}")

    if contradiction_edge is None:
        # 默认选择树状图中根节点与其第一个子节点的边
        contradiction_edge = (0, 1) if G.has_edge(0, 1) else list(G.edges())[0]
    if strengths is None:
        strengths = np.linspace(0.0, 3.0, 9)

    gaps, coarse_vals, fine_vals = [], [], []
    audit_gaps = []

    print("矛盾强度扫描 (无预设目标)...")
    for s in strengths:
        G_mod = introduce_contradiction(G, contradiction_edge, s)
        _, gap, gs = diagnose(G_mod, num_eig=5)
        coarse = coarse_diagnosis(N, gs)
        fine = fine_diagnosis(G_mod, gs)

        gaps.append(gap)
        coarse_vals.append(coarse)
        fine_vals.append(fine)

        # 元反思审计：用不同本征值数量再次诊断
        _, gap2, _ = diagnose(G_mod, num_eig=6)
        audit_gaps.append(abs(gap - gap2))

        print(f"  s={s:.2f}: gap={gap:.4f}, coarse={coarse:.4f}, fine={fine:.4f}, audit={audit_gaps[-1]:.6f}")

    # 保存探索数据
    np.savetxt('tree_explore.csv',
               np.column_stack((strengths, gaps, coarse_vals, fine_vals, audit_gaps)),
               header='strength,gap,coarse,fine,audit_gap_diff', delimiter=',')

    # 绘制诊断图（并排展示不同介入视角）
    fig, ax1 = plt.subplots(figsize=(10,6))
    ax1.plot(strengths, coarse_vals, 'o-', color='#1f77b4', label='Coarse Diagnosis')
    ax2 = ax1.twinx()
    ax2.plot(strengths, fine_vals, 's-', color='#d62728', label='Fine Diagnosis')
    ax1.set_xlabel('Contradiction Strength'); ax1.set_ylabel('Coarse Metric')
    ax2.set_ylabel('Fine Metric'); ax1.legend(loc='upper left'); ax2.legend(loc='upper right')
    plt.title(f'Tree Quantum Exploration (r={r}, h={h}, N={N})')
    plt.tight_layout()
    plt.savefig('tree_explore.png', dpi=150)
    print("探索数据已保存至 tree_explore.csv 和 tree_explore.png")

if __name__ == "__main__":
    explore_tree(r=2, h=2)