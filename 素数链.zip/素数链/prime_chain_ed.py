"""
素数链沉默失谐诊断 —— 精确对角化版 (ED)
N = 5, 7, 11, 13 (素数链)
为马拉特 TAT-7 盲测准备数据
"""
import numpy as np
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def chain_graph(N):
    """生成链式图边列表"""
    return [(i, i+1, 1.0) for i in range(N-1)]

def graph_to_hamiltonian_sparse(edges, N, contradiction_edge=None, contradiction_strength=1.0):
    """Heisenberg 哈密顿量 (稀疏矩阵, 遍历计算基矢)"""
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    for i, j, w in edges:
        if contradiction_edge is not None:
            if (i, j) == contradiction_edge or (j, i) == contradiction_edge:
                w = contradiction_strength
        for state in range(dim):
            bit_i = (state >> i) & 1
            bit_j = (state >> j) & 1
            # XX + YY
            flipped = state ^ (1 << i) ^ (1 << j)
            H[state, flipped] += w
            # ZZ
            if bit_i == bit_j:
                H[state, state] += w
            else:
                H[state, state] -= w
    return H.tocsc()

def diagnose(edges, N, contradiction_edge, contradiction_strength, num_eig=5):
    H = graph_to_hamiltonian_sparse(edges, N, contradiction_edge, contradiction_strength)
    energies, states = eigsh(H, k=min(num_eig, 2**N-1), which='SA')
    gap = energies[1] - energies[0] if len(energies) > 1 else np.nan
    gs = states[:, 0]
    # 粗粒化 (平均磁化绝对值)
    mag = 0.0
    for state in range(len(gs)):
        prob = np.abs(gs[state])**2
        bits = [(state >> k) & 1 for k in range(N)]
        mag += prob * sum(1 - 2*b for b in bits)
    coarse = abs(mag / N)
    # 精细 (最近邻关联涨落标准差)
    corrs = []
    for i in range(N-1):
        corr = 0.0
        for state in range(len(gs)):
            prob = np.abs(gs[state])**2
            bi = (state >> i) & 1
            bj = (state >> (i+1)) & 1
            corr += prob * (1 - 2*bi) * (1 - 2*bj)
        corrs.append(corr)
    fine = np.std(corrs)
    return gap, coarse, fine

if __name__ == "__main__":
    primes = [5, 7, 11, 13]
    strengths = np.linspace(0.0, 3.0, 9)

    for N in primes:
        edges = chain_graph(N)
        center_edge = (N//2 - 1, N//2)
        print(f"\n=== 素数链 N={N}, 矛盾边={center_edge} ===")
        gaps, coarse_vals, fine_vals = [], [], []
        for s in strengths:
            gap, coarse, fine = diagnose(edges, N, center_edge, s)
            gaps.append(gap)
            coarse_vals.append(coarse)
            fine_vals.append(fine)
            print(f"  s={s:.2f}: gap={gap:.6f}, coarse={coarse:.4f}, fine={fine:.4f}")

        # 保存 CSV
        csv_name = f"prime_chain_N{N}.csv"
        np.savetxt(csv_name,
                   np.column_stack((strengths, gaps, coarse_vals, fine_vals)),
                   header='strength,gap,coarse,fine', delimiter=',')
        print(f"数据已保存: {csv_name}")

        # 保存诊断图
        fig, ax1 = plt.subplots(figsize=(10,6))
        ax1.plot(strengths, coarse_vals, 'o-', label='Coarse')
        ax2 = ax1.twinx()
        ax2.plot(strengths, fine_vals, 's-', color='red', label='Fine')
        ax1.set_xlabel('Contradiction strength')
        ax1.legend(loc='upper left'); ax2.legend(loc='upper right')
        plt.title(f'Prime Chain N={N} (center edge {center_edge})')
        plt.tight_layout()
        plt.savefig(f'prime_chain_N{N}.png', dpi=150)
        plt.close()
        print(f"图片已保存: prime_chain_N{N}.png")

    print("\n全部素数链扫描完成。将 CSV 文件发给马拉特即可。")