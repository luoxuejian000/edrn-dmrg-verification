"""
素数链沉默失谐诊断 —— 金箍棒 3.0 DMRG 版（修正版）
为马拉特 TAT-7 盲测准备数据
N = 5, 7, 11, 13 (素数链)
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tenpy.models.model import CouplingMPOModel
from tenpy.models.lattice import Chain
from tenpy.networks.site import SpinHalfSite
from tenpy.networks.mps import MPS
from tenpy.algorithms import dmrg

class PrimeChainModel(CouplingMPOModel):
    """素数链 Heisenberg 模型，带矛盾边"""
    def __init__(self, model_params):
        # 从 model_params 中提取自定义参数
        self.contradiction_edge = model_params.get('contradiction_edge', None)
        self.contradiction_strength = model_params.get('contradiction_strength', 1.0)
        # 调用父类，它会自动创建 lattice
        super().__init__(model_params)

    def init_sites(self, model_params):
        # 父类 CouplingMPOModel 会调用此方法创建格点
        return SpinHalfSite(conserve='Sz')

    def init_lattice(self, model_params):
        L = model_params['L']
        return Chain(L, self.init_sites(model_params), bc='open')

    def init_terms(self):
        L = self.lat.N_sites
        # 默认边：链式最近邻
        for i in range(L - 1):
            w = 1.0
            # 矛盾边替换权重
            if self.contradiction_edge is not None:
                if (i, i+1) == self.contradiction_edge or (i+1, i) == self.contradiction_edge:
                    w = self.contradiction_strength
            self.add_coupling(w * 0.5, i, 'Sp', i+1, 'Sm', plus_hc=True)  # XX+YY
            self.add_coupling(w, i, 'Sz', i+1, 'Sz')                      # ZZ


def run_prime_chain(N, contradiction_edge, strengths, chi_max=100):
    """扫描矛盾强度，返回诊断数据"""
    gaps, coarse_vals, fine_vals = [], [], []
    for s in strengths:
        M = PrimeChainModel(dict(
            L=N,
            contradiction_edge=contradiction_edge,
            contradiction_strength=s,
            bc_MPS='finite'
        ))
        init = ['up', 'down'] * (N // 2)
        if N % 2 == 1:
            init.append('up')
        psi = MPS.from_product_state(M.lat.mps_sites(), init, bc='finite')
        dmrg_params = {'mixer': True, 'chi_max': chi_max, 'max_sweeps': 50, 'verbose': 0}
        
        # 基态
        eng = dmrg.run(psi, M, dmrg_params)
        E0 = eng.eigenvalues[0]
        
        # 第一激发态 (Sz=1)，翻转中心自旋
        init_ex = init.copy()
        center = N // 2
        init_ex[center] = 'down' if init[center] == 'up' else 'up'
        psi_ex = MPS.from_product_state(M.lat.mps_sites(), init_ex, bc='finite')
        eng_ex = dmrg.run(psi_ex, M, dmrg_params)
        E1 = eng_ex.eigenvalues[0]
        gap = E1 - E0

        # 粗粒化诊断 (平均磁化绝对值)
        Sz = psi.expectation_value('Sz')
        coarse = np.mean(np.abs(Sz))
        
        # 精细诊断 (最近邻关联涨落的标准差)
        corrs = []
        for i in range(N - 1):
            corr = psi.correlation_function('Sz', 'Sz', [i], [i+1])
            corrs.append(corr[0])
        fine = np.std(corrs) if corrs else 0.0
        
        gaps.append(gap)
        coarse_vals.append(coarse)
        fine_vals.append(fine)
        print(f"  s={s:.2f}: gap={gap:.6f}, coarse={coarse:.4f}, fine={fine:.4f}")
    
    return np.array(strengths), np.array(gaps), np.array(coarse_vals), np.array(fine_vals)


# =============================================
if __name__ == "__main__":
    primes = [5, 7, 11, 13]
    strengths = np.linspace(0.0, 3.0, 9)

    for N in primes:
        center_edge = (N//2 - 1, N//2)  # 中心键
        print(f"\n=== 素数链 N={N}, 矛盾边={center_edge} ===")
        s_vals, gaps, coarse, fine = run_prime_chain(N, center_edge, strengths, chi_max=100)

        # 保存 CSV
        csv_name = f"prime_chain_N{N}.csv"
        np.savetxt(csv_name,
                   np.column_stack((s_vals, gaps, coarse, fine)),
                   header='strength,gap,coarse,fine', delimiter=',')
        print(f"数据已保存: {csv_name}")

        # 保存诊断图
        fig, ax1 = plt.subplots(figsize=(10,6))
        ax1.plot(s_vals, coarse, 'o-', label='Coarse')
        ax2 = ax1.twinx()
        ax2.plot(s_vals, fine, 's-', color='red', label='Fine')
        ax1.set_xlabel('Contradiction strength')
        ax1.legend(loc='upper left'); ax2.legend(loc='upper right')
        plt.title(f'Prime Chain N={N} (center edge {center_edge})')
        plt.tight_layout()
        plt.savefig(f'prime_chain_N{N}.png', dpi=150)
        plt.close()
        print(f"图片已保存: prime_chain_N{N}.png")

    print("\n全部素数链扫描完成。将 CSV 文件发给马拉特即可。")