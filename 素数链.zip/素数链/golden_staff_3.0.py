"""
金箍棒 3.0 —— 基于 TeNPy DMRG 的关系图量子多体系统编译器
支持: Heisenberg, Ising, XY, XXZ, Rashba SOC
严格遵循: 关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tenpy.models.model import CouplingMPOModel
from tenpy.models.lattice import Chain
from tenpy.networks.site import SpinHalfSite
from tenpy.networks.mps import MPS
from tenpy.algorithms import dmrg

class GoldenStaffDMRG(CouplingMPOModel):
    """金箍棒关系图模型 (TeNPy DMRG 版本)"""
    
    def __init__(self, model_params):
        # 读取参数
        L = model_params['L']
        self.graph_edges = model_params.get('edges', [])
        self.rule = model_params.get('rule', 'heisenberg')
        self.delta = model_params.get('delta', 1.0)   # XXZ各向异性
        self.D = model_params.get('D', 0.0)           # Rashba SOC DM强度
        self.contradiction_edge = model_params.get('contradiction_edge', None)
        self.contradiction_strength = model_params.get('contradiction_strength', 1.0)
        
        # 格点
        lat = Chain(L, SpinHalfSite(conserve='Sz'), bc='open')
        CouplingMPOModel.__init__(self, lat)
    
    def init_terms(self):
        """根据关系图和规则添加相互作用项"""
        for edge in self.graph_edges:
            i, j = edge[0], edge[1]
            w = edge[2] if len(edge) > 2 else 1.0
            
            # 矛盾边：替换权重
            if self.contradiction_edge is not None:
                if (i, j) == self.contradiction_edge or (j, i) == self.contradiction_edge:
                    w = self.contradiction_strength
            
            # Heisenberg部分 (XX+YY)
            if self.rule in ['heisenberg', 'xy', 'xxz']:
                self.add_coupling(w * 0.5, i, 'Sp', j, 'Sm', plus_hc=True)
            # Ising部分 (ZZ)
            if self.rule in ['heisenberg', 'ising', 'xxz']:
                factor = self.delta if self.rule == 'xxz' else 1.0
                self.add_coupling(w * factor, i, 'Sz', j, 'Sz')
            # Rashba SOC (DM向量沿y轴): D * (σ_i × σ_j)_y = D*(σ^z_i σ^x_j - σ^x_i σ^z_j)
            if self.D != 0.0:
                # 实空间算符: Sp = (Sx + i Sy)/2, Sm = (Sx - i Sy)/2
                # σ^z_i σ^x_j 项 → 需要 i Sp + i Sm 组合，这里简化用直接耦合，但TeNPy无法直接添加σ^z σ^x。
                # 我们用更通用的方式：通过Sz和Sp,Sm组合实现DM_y。
                # DM_y = D*(S^z_i S^x_j - S^x_i S^z_j) = D*(S^z_i (S^+_j + S^-_j) - (S^+_i + S^-_i) S^z_j)
                # 但TeNPy的add_coupling可处理Sz与Sp的组合。
                self.add_coupling(self.D * 0.5, i, 'Sz', j, 'Sp', plus_hc=True)
                self.add_coupling(-self.D * 0.5, i, 'Sz', j, 'Sm', plus_hc=True)
                # 注意：上面已经加了 plus_hc，会自动处理另一部分。


def run_golden_staff_dmrg(edges, N, contradiction_edge, strengths,
                           rule='heisenberg', delta=1.0, D=0.0, chi_max=100, verbose=0):
    """
    用 DMRG 扫描矛盾强度
    返回: strengths, gaps, coarse_vals, fine_vals
    """
    gaps, coarse_vals, fine_vals = [], [], []
    
    for s in strengths:
        model_params = dict(
            L=N, edges=edges,
            contradiction_edge=contradiction_edge,
            contradiction_strength=s,
            rule=rule, delta=delta, D=D,
            bc_MPS='finite', conserve='Sz'
        )
        
        M = GoldenStaffDMRG(model_params)
        # 初态：反铁磁序
        init = ['up', 'down'] * (N // 2)
        if N % 2 == 1:
            init.append('up')
        psi = MPS.from_product_state(M.lat.mps_sites(), init, bc='finite')
        
        dmrg_params = {
            'mixer': True,
            'chi_max': chi_max,
            'max_sweeps': 50,
            'verbose': verbose,
        }
        
        # 基态 (Sz=0 扇区已通过conserve保证)
        eng = dmrg.run(psi, M, dmrg_params)
        E0 = eng.eigenvalues[0]
        
        # 第一激发态：构造Sz=1的初态（翻转中心自旋）
        init_ex = init.copy()
        center = N // 2
        init_ex[center] = 'down' if init[center] == 'up' else 'up'
        psi_ex = MPS.from_product_state(M.lat.mps_sites(), init_ex, bc='finite')
        eng_ex = dmrg.run(psi_ex, M, dmrg_params)
        E1 = eng_ex.eigenvalues[0]
        gap = E1 - E0
        
        # 粗粒化诊断 (平均磁化绝对值)
        Sz = psi.expectation_value('Sz')
        coarse = np.mean(np.abs(Sz))
        
        # 精细诊断 (最近邻关联涨落的标准差)
        corrs = []
        for i in range(N - 1):
            corr = psi.correlation_function('Sz', 'Sz', [i], [i+1])
            corrs.append(corr[0])
        fine = np.std(corrs)
        
        gaps.append(gap)
        coarse_vals.append(coarse)
        fine_vals.append(fine)
        
        if verbose:
            print(f"s={s:.2f}: gap={gap:.6f}, coarse={coarse:.4f}, fine={fine:.4f}")
    
    return np.array(strengths), np.array(gaps), np.array(coarse_vals), np.array(fine_vals)


# =============================================
# 示例：链式图 N=20, Heisenberg规则
# =============================================
if __name__ == "__main__":
    # 参数设置
    N = 20
    edges = [(i, i+1, 1.0) for i in range(N-1)]
    contradiction_edge = (N//2 - 1, N//2)  # 中心键
    strengths = np.linspace(0.0, 3.0, 13)
    
    print(f"金箍棒 3.0 (DMRG) —— 链式图 N={N}, Heisenberg")
    s_vals, gaps, coarse, fine = run_golden_staff_dmrg(
        edges, N, contradiction_edge, strengths,
        rule='heisenberg', chi_max=100, verbose=1
    )
    
    # 保存数据
    np.savetxt('golden_staff_3.0_N20.csv',
               np.column_stack((s_vals, gaps, coarse, fine)),
               header='strength,gap,coarse,fine', delimiter=',')
    
    # 简单绘图
    fig, ax1 = plt.subplots(figsize=(10,6))
    ax1.plot(s_vals, coarse, 'o-', label='Coarse')
    ax2 = ax1.twinx()
    ax2.plot(s_vals, fine, 's-', color='red', label='Fine')
    ax1.set_xlabel('Contradiction strength')
    ax1.legend(loc='upper left'); ax2.legend(loc='upper right')
    plt.title(f'Golden Staff 3.0: Chain N={N}')
    plt.tight_layout()
    plt.savefig('golden_staff_3.0_N20.png')
    print("Done.")