"""
终极版 DMRG 常数验证 —— 手动构建 MPO，不继承任何模型类
完全回避 TeNPy 版本兼容问题。
只跑 N=12 和 N=14，完成德拉霍什常数跨尺寸验证。
"""
import numpy as np
import warnings
warnings.filterwarnings('ignore')

import tenpy
from tenpy.networks.site import SpinHalfSite
from tenpy.models.lattice import Chain
from tenpy.networks.mps import MPS
from tenpy.networks.mpo import MPO
from tenpy.algorithms import dmrg
from tenpy.linalg import np_conserved as npc

def build_mpo(L, D, contradiction_edge, contradiction_strength):
    """
    手动构建 Heisenberg + Rashba SOC 哈密顿量的 MPO。
    直接操作格点算符，不依赖任何模型类的 init_terms。
    """
    site = SpinHalfSite(conserve='Sz')
    lat = Chain(L, site, bc='open')
    
    # 定义单个键上的相互作用矩阵（4x4，基矢顺序 |↑↑>, |↑↓>, |↓↑>, |↓↓>）
    def bond_matrix(w, D):
        mat = np.zeros((4, 4), dtype=float)
        # Heisenberg XX+YY+ZZ
        mat[0, 0] = 0.25 * w
        mat[1, 1] = -0.25 * w
        mat[2, 2] = -0.25 * w
        mat[3, 3] = 0.25 * w
        mat[1, 2] = 0.5 * w
        mat[2, 1] = 0.5 * w
        # Rashba SOC (DM_y): D*(σ^z_i σ^x_j - σ^x_i σ^z_j)
        if D != 0.0:
            # σ^z_i σ^x_j = Sz_i ⊗ Sx_j
            # 在 4x4 空间中
            mat[0, 2] += D * 0.5
            mat[2, 0] += D * 0.5
            mat[1, 3] -= D * 0.5
            mat[3, 1] -= D * 0.5
            # -σ^x_i σ^z_j
            mat[0, 1] -= D * 0.5
            mat[1, 0] -= D * 0.5
            mat[2, 3] += D * 0.5
            mat[3, 2] += D * 0.5
        return mat

    # 使用 tenpy 的 Grid 方式构建 MPO
    # 对于有限链，MPO 由 L 个网格组成，每个网格是一个 4 秩张量
    # 我们使用 MPO.from_grids 方法
    
    leg_wL = npc.LegCharge.from_trivial(1)  # 左虚拟键，维度为1
    leg_wR = npc.LegCharge.from_trivial(1)  # 右虚拟键，维度为1
    
    # 构建网格列表
    grids = []
    for i in range(L):
        w = 1.0
        if contradiction_edge is not None:
            if (i, i+1) == contradiction_edge or (i+1, i) == contradiction_edge:
                w = contradiction_strength if i < L-1 else 1.0
        
        if i == 0:
            # 第一个格点：左键维度1，右键维度5（恒等算符和四个相互作用项）
            phys_leg = site.leg
            # 简化：用更直接的方式
            pass
    
    # 上面的网格方式太复杂，改用 tenpy 自带的 SpinChain 模型作为基础，
    # 然后直接修改其 MPO 矩阵来添加 Rashba SOC。
    # 这是最稳妥的方式。
    
    from tenpy.models.spins import SpinChain
    # SpinChain 的参数
    spin_params = dict(
        L=L,
        Jx=1.0, Jy=1.0, Jz=1.0,  # Heisenberg
        bc_MPS='finite',
        conserve='Sz'
    )
    M = SpinChain(spin_params)
    
    # 现在 M 是一个完整的模型，有 H_MPO。
    # 我们需要在 H_MPO 上添加 Rashba SOC 项。
    # 最简单的方式：直接在 M 上使用 add_coupling（SpinChain 内部已经调用了 add_coupling）
    # 但我们不能再调用 init_terms，所以需要在创建后手动修改 MPO。
    
    # 实际上，我们可以创建一个新的 CouplingModel，手动添加所有项：
    from tenpy.models.model import CouplingModel, MPOModel
    
    class FinalModel(CouplingModel, MPOModel):
        def __init__(self):
            lat = Chain(L, SpinHalfSite(conserve='Sz'), bc='open')
            CouplingModel.__init__(self, lat)
            # 手动添加所有耦合，不通过 init_terms
            for i in range(L - 1):
                w = 1.0
                if contradiction_edge is not None:
                    if (i, i+1) == contradiction_edge or (i+1, i) == contradiction_edge:
                        w = contradiction_strength
                # Heisenberg
                self.add_coupling(w * 0.5, i, 'Sp', i+1, 'Sm', dx=0, plus_hc=True)
                self.add_coupling(w, i, 'Sz', i+1, 'Sz', dx=0)
                # Rashba SOC
                if D != 0.0:
                    self.add_coupling(D * 0.5, i, 'Sz', i+1, 'Sp', dx=0, plus_hc=True)
                    self.add_coupling(-D * 0.5, i, 'Sz', i+1, 'Sm', dx=0, plus_hc=True)
            H_MPO = self.calc_H_MPO()
            MPOModel.__init__(self, lat, H_MPO)
    
    return FinalModel()


def run_single_scan(N, center_edge, strengths, D, chi_max=100):
    """单次扫描，返回精细诊断数组"""
    fine_vals = []
    for s in strengths:
        print(f"    s={s:.2f}...", end=' ', flush=True)
        M = build_mpo(N, D, center_edge, s)
        init = ['up', 'down'] * (N // 2)
        if N % 2 == 1:
            init.append('up')
        psi = MPS.from_product_state(M.lat.mps_sites(), init, bc='finite')
        dmrg_params = {'mixer': True, 'chi_max': chi_max, 'max_sweeps': 50, 'verbose': 0}
        eng = dmrg.run(psi, M, dmrg_params)
        corrs = []
        for i in range(N - 1):
            corr = psi.correlation_function('Sz', 'Sz', [i], [i+1])
            corrs.append(corr[0])
        fine = np.std(corrs) if corrs else 0.0
        fine_vals.append(fine)
        print(f"fine={fine:.4f}")
    return np.array(fine_vals)


if __name__ == "__main__":
    strengths = np.linspace(0.0, 3.0, 9)
    D_val = 0.3
    results = []

    print("=== 终极版 DMRG 常数验证: N=12, 14 ===")
    for N in [12, 14]:
        center_edge = (N//2 - 1, N//2) if N % 2 == 1 else (N//2 - 1, N//2)
        print(f"\nN={N}, center_edge={center_edge}")
        print("  纯Heisenberg...")
        fine_heis = run_single_scan(N, center_edge, strengths, D=0.0, chi_max=100)
        print("  Rashba SOC...")
        fine_soc = run_single_scan(N, center_edge, strengths, D=D_val, chi_max=100)
        ratios = fine_soc / fine_heis
        mean_r = np.mean(ratios)
        std_r = np.std(ratios, ddof=1)
        results.append({'N': N, 'mean': mean_r, 'std': std_r})
        print(f"  N={N}: mean ratio={mean_r:.6f}, std={std_r:.6f}")

        csv_name = f"constant_N{N}_dmrg.csv"
        with open(csv_name, 'w') as f:
            f.write("strength,Heisenberg,SOC,ratio\n")
            for i, s in enumerate(strengths):
                f.write(f"{s:.2f},{fine_heis[i]:.6f},{fine_soc[i]:.6f},{ratios[i]:.6f}\n")
        print(f"  已保存: {csv_name}")

    with open('constant_validation_dmrg_final.csv', 'w') as f:
        f.write("N,mean_ratio,std_ratio\n")
        for r in results:
            f.write(f"{r['N']},{r['mean']:.6f},{r['std']:.6f}\n")
    print("\n全部完成。结果已保存。")