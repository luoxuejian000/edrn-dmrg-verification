"""
Rashba SOC 等比缩放常数验证脚本
检验德拉霍什常数 (0.958) 在跨系统尺寸、跨参数强度、跨拓扑结构下的稳定性。
严格遵循：关系本体论、防工具理性、反对对齐
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import eigsh
import networkx as nx
import warnings
warnings.filterwarnings('ignore')

# =============================================
# 公理一：关系图生成 & 哈密顿量编译（内存安全版）
# =============================================
def chain_graph(N):
    """生成链式图"""
    G = nx.Graph()
    G.add_nodes_from(range(N))
    for i in range(N-1):
        G.add_edge(i, i+1, weight=1.0)
    return G

def small_world_graph(N, k=4, p=0.1, seed=42):
    """生成小世界图"""
    G = nx.watts_strogatz_graph(N, k, p, seed=seed)
    for u, v in G.edges():
        G[u][v]['weight'] = 1.0
    return G

def random_graph(N, p_edge=0.3, seed=42):
    """生成随机图"""
    G = nx.erdos_renyi_graph(N, p_edge, seed=seed)
    for u, v in G.edges():
        G[u][v]['weight'] = 1.0
    return G

def graph_to_hamiltonian_sparse(G, D=0.0):
    """
    关系图 → Heisenberg + Rashba SOC 哈密顿量（内存安全版）
    D: DM相互作用强度 (沿y轴), D=0 为纯Heisenberg
    """
    N = G.number_of_nodes()
    dim = 2**N
    H = lil_matrix((dim, dim), dtype=float)
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)

    def to_full(op, site):
        ops = [I2] * N
        ops[site] = op
        result = ops[0]
        for k in range(1, N): result = np.kron(result, ops[k])
        return result

    for i, j, w in G.edges(data='weight'):
        w = w if w else 1.0
        # Heisenberg: XX + YY
        H += w * (to_full(sx, i) @ to_full(sx, j)).real
        H += w * (to_full(sy, i) @ to_full(sy, j)).real
        # Heisenberg: ZZ
        H += w * (to_full(sz, i) @ to_full(sz, j)).real
        # Rashba SOC (DM_y): D*(σ^z_i σ^x_j - σ^x_i σ^z_j)
        if D != 0.0:
            H += D * (to_full(sz, i) @ to_full(sx, j)).real
            H -= D * (to_full(sx, i) @ to_full(sz, j)).real
    return H.tocsc()

# =============================================
# 公理二：矛盾动力论
# =============================================
def introduce_contradiction(G, edge, strength):
    G_mod = G.copy()
    if G_mod.has_edge(*edge): G_mod[edge[0]][edge[1]]['weight'] = strength
    else: G_mod.add_edge(edge[0], edge[1], weight=strength)
    return G_mod

# =============================================
# 诊断函数
# =============================================
def diagnose(G, D=0.0, num_eig=5):
    H = graph_to_hamiltonian_sparse(G, D=D)
    N = G.number_of_nodes()
    energies, states = eigsh(H, k=min(num_eig, 2**N-1), which='SA')
    gap = energies[1] - energies[0] if len(energies) > 1 else np.nan
    return energies, gap, states[:, 0]

def fine_diagnosis(G, gs):
    N = G.number_of_nodes()
    dim = len(gs)
    corrs = []
    for i, j in G.edges():
        corr = 0.0
        for state in range(dim):
            prob = np.abs(gs[state])**2
            bit_i = (state>>i)&1; bit_j = (state>>j)&1
            corr += prob * (1-2*bit_i) * (1-2*bit_j)
        corrs.append(corr)
    return np.std(corrs) if corrs else 0.0

# =============================================
# 等比缩放常数分析（核心实验）
# =============================================
def analyze_scaling_constant(G, center_edge, strengths, D=0.3):
    """对给定关系图，跑纯Heisenberg和Rashba SOC扫描，计算逐点比值"""
    fine_heis = []
    fine_soc = []
    for s in strengths:
        # 纯Heisenberg
        G_heis = introduce_contradiction(G, center_edge, s)
        _, _, gs_heis = diagnose(G_heis, D=0.0, num_eig=5)
        fine_heis.append(fine_diagnosis(G_heis, gs_heis))
        # Rashba SOC
        G_soc = introduce_contradiction(G, center_edge, s)
        _, _, gs_soc = diagnose(G_soc, D=D, num_eig=5)
        fine_soc.append(fine_diagnosis(G_soc, gs_soc))
    fine_heis = np.array(fine_heis)
    fine_soc = np.array(fine_soc)
    ratios = fine_soc / fine_heis
    return fine_heis, fine_soc, ratios

# =============================================
# 主验证流程
# =============================================
def run_constant_validation():
    """
    三组检验：
    1. 跨N检验 (链式图, D=0.3, N=6,8,10,12,14)
    2. 跨D检验 (链式图, N=6, D=0.1, 0.5, 1.0)
    3. 跨拓扑检验 (N=8, D=0.3, 链式/小世界/随机)
    """
    strengths = np.linspace(0.0, 3.0, 9)
    results = []

    # ---- 检验1: 跨N ----
    print("=== 检验1: 跨系统尺寸 (链式图, D=0.3) ===")
    for N in [6, 8, 10, 12, 14]:
        G = chain_graph(N)
        center_edge = (N//2 - 1, N//2) if N%2==1 else (N//2 - 1, N//2)
        fine_heis, fine_soc, ratios = analyze_scaling_constant(G, center_edge, strengths, D=0.3)
        mean_r = np.mean(ratios)
        std_r = np.std(ratios, ddof=1)
        results.append({'N': N, 'graph': 'chain', 'D': 0.3, 'mean': mean_r, 'std': std_r})
        print(f"  N={N}: mean ratio={mean_r:.6f}, std={std_r:.6f}")

    # ---- 检验2: 跨D ----
    print("\n=== 检验2: 跨DM强度 (链式图, N=6) ===")
    G = chain_graph(6)
    center_edge = (2, 3)
    for D in [0.1, 0.5, 1.0]:
        fine_heis, fine_soc, ratios = analyze_scaling_constant(G, center_edge, strengths, D=D)
        mean_r = np.mean(ratios)
        std_r = np.std(ratios, ddof=1)
        results.append({'N': 6, 'graph': 'chain', 'D': D, 'mean': mean_r, 'std': std_r})
        print(f"  D={D}: mean ratio={mean_r:.6f}, std={std_r:.6f}")

    # ---- 检验3: 跨拓扑 ----
    print("\n=== 检验3: 跨拓扑结构 (N=8, D=0.3) ===")
    for graph_name, graph_fn in [('small_world', lambda: small_world_graph(8)),
                                  ('random', lambda: random_graph(8))]:
        G = graph_fn()
        center_edge = (3, 4)
        fine_heis, fine_soc, ratios = analyze_scaling_constant(G, center_edge, strengths, D=0.3)
        mean_r = np.mean(ratios)
        std_r = np.std(ratios, ddof=1)
        results.append({'N': 8, 'graph': graph_name, 'D': 0.3, 'mean': mean_r, 'std': std_r})
        print(f"  {graph_name}: mean ratio={mean_r:.6f}, std={std_r:.6f}")

    # 保存完整结果
    with open('constant_validation_results.csv', 'w') as f:
        f.write("N,graph,D,mean_ratio,std_ratio\n")
        for r in results:
            f.write(f"{r['N']},{r['graph']},{r['D']},{r['mean']:.6f},{r['std']:.6f}\n")
    print("\n结果已保存至 constant_validation_results.csv")

    # 绘制汇总图
    labels = [f"N={r['N']},{r['graph']},D={r['D']}" for r in results]
    means = [r['mean'] for r in results]
    stds = [r['std'] for r in results]
    fig, ax = plt.subplots(figsize=(12, 6))
    x = np.arange(len(results))
    ax.bar(x, means, yerr=stds, capsize=4, color='steelblue', alpha=0.8)
    ax.axhline(0.958, color='red', linestyle='--', linewidth=1.5, label='Drahoš constant (0.958)')
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=45, ha='right', fontsize=8)
    ax.set_ylabel('Mean ratio (SOC / Heisenberg)')
    ax.set_title('Validation of the Drahoš Constant across N, D, and Graph Topology')
    ax.legend()
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('constant_validation_summary.png', dpi=150)
    print("汇总图已保存至 constant_validation_summary.png")

if __name__ == "__main__":
    run_constant_validation()